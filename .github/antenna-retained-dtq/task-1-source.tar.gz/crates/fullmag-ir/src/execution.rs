//! Execution-policy and boundary-condition enums for `ProblemIR`.
//!
//! Contains: discretization/device/precision choices, integrator selection,
//! relaxation algorithm variants, exchange/axis/demag boundary conditions,
//! FDM periodicity, spin-wave boundary conditions, and imported geometry scale.

use crate::PhaseConventionIR;
use serde::{Deserialize, Serialize};

// ── Core execution choices ────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ExecutionMode {
    Strict,
    Extended,
    Hybrid,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum BackendTarget {
    Auto,
    Fdm,
    Fem,
    Hybrid,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum ExecutionPrecision {
    Single,
    #[default]
    Double,
}

/// Fully resolved numeric policy for the production CUDA FDM lane.
///
/// The public execution precision selects one of the two supported policies;
/// arbitrary mixed-precision combinations are intentionally not representable
/// until they have an independent qualification contract.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct FdmPrecisionPolicyIR {
    pub storage: ExecutionPrecision,
    pub compute: ExecutionPrecision,
    pub fft: ExecutionPrecision,
    pub reduction: ExecutionPrecision,
    pub realization_id: String,
}

impl FdmPrecisionPolicyIR {
    pub const FULL_DOUBLE_REALIZATION_ID: &'static str =
        "fullmag.fdm.cuda.precision.full_double.v1";
    pub const SINGLE_STORAGE_FP64_REDUCTION_REALIZATION_ID: &'static str =
        "fullmag.fdm.cuda.precision.single_storage_fp64_reduction.v1";

    pub fn resolve(requested: ExecutionPrecision) -> Self {
        match requested {
            ExecutionPrecision::Single => Self {
                storage: ExecutionPrecision::Single,
                compute: ExecutionPrecision::Single,
                fft: ExecutionPrecision::Single,
                reduction: ExecutionPrecision::Double,
                realization_id: Self::SINGLE_STORAGE_FP64_REDUCTION_REALIZATION_ID.to_string(),
            },
            ExecutionPrecision::Double => Self::default(),
        }
    }

    pub fn validate_for(&self, requested: ExecutionPrecision) -> Result<(), String> {
        let expected = Self::resolve(requested);
        if self != &expected {
            return Err(format!(
                "fdm_precision_policy_mismatch: requested={requested:?} resolved={self:?} expected={expected:?}"
            ));
        }
        Ok(())
    }
}

impl Default for FdmPrecisionPolicyIR {
    fn default() -> Self {
        Self {
            storage: ExecutionPrecision::Double,
            compute: ExecutionPrecision::Double,
            fft: ExecutionPrecision::Double,
            reduction: ExecutionPrecision::Double,
            realization_id: Self::FULL_DOUBLE_REALIZATION_ID.to_string(),
        }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum ExecutionDevice {
    #[default]
    Auto,
    Cpu,
    Gpu,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum IntegratorChoice {
    #[default]
    Heun,
    Rk4,
    Rk23,
    Rk45,
    Abm3,
}

/// FDM projected-RK state constraint policy.
///
/// The policy is carried in the resolved plan so that the CPU/GPU realizations
/// cannot silently disagree about whether intermediate RK states are
/// normalized.  `unit_sphere` is currently the only qualified realization.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum FdmProjectionPolicyIR {
    #[default]
    UnitSphere,
}

impl FdmProjectionPolicyIR {
    pub const UNIT_SPHERE_REALIZATION_VERSION: &'static str =
        "fullmag.fdm.rk_projection.unit_sphere.v1";

    pub const fn as_str(self) -> &'static str {
        match self {
            Self::UnitSphere => "unit_sphere",
        }
    }

    pub const fn realization_version(self) -> &'static str {
        match self {
            Self::UnitSphere => Self::UNIT_SPHERE_REALIZATION_VERSION,
        }
    }
}

// ── Relaxation algorithm ──────────────────────────────────────────────────────

/// Algorithm selection for relaxation (energy-minimization) studies.
///
/// See `docs/physics/0500-fdm-relaxation-algorithms.md` for full specification.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum RelaxationAlgorithmIR {
    /// Overdamped Landau–Lifshitz–Gilbert time-stepping with high damping.
    /// Reuses the standard LLG integration pipeline.  Public-executable on FDM and FEM.
    LlgOverdamped,
    /// Projected steepest descent with Barzilai–Borwein step selection on the
    /// sphere product manifold.  Uses alternating BB1/BB2 step sizes with Armijo
    /// backtracking line search.  Public-executable on FDM.
    ProjectedGradientBb,
    /// Nonlinear conjugate gradient (Polak–Ribière+) with tangent-space vector
    /// transport, periodic restarts, and Armijo backtracking.  Public-executable
    /// on FDM.
    NonlinearCg,
    /// FEM-only linearly implicit tangent-plane relaxation.  Public-executable
    /// on the native CPU/MFEM backend; GPU/libCEED execution is still pending.
    TangentPlaneImplicit,
}

// ── Exchange and axis boundary conditions ─────────────────────────────────────

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum ExchangeBoundaryCondition {
    #[default]
    Neumann,
}

// ── Periodic Boundary Conditions (FDM) ───────────────────────────────────────

/// Resolved exchange rule for one pair of FDM regions (physics note 0104,
/// `material-fdm-connection-coefficient`).
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
#[serde(tag = "mode", rename_all = "snake_case")]
pub enum FdmExchangePairModeIR {
    /// `A_ij = scale * H(A_i, A_j)` with the realized cell stiffnesses.
    HarmonicScale { scale: f64 },
    /// `A_ij` replaced by an authored stiffness [J/m].
    Explicit { exchange_stiffness: f64 },
    /// No direct exchange across the interface.
    Disabled,
}

/// Sparse, symmetric exchange rule between two named FDM regions.
///
/// Stored plans written before typed rules used `(region_i, region_j, A)`
/// triples; those deserialize as [`FdmExchangePairModeIR::Explicit`].
#[derive(Debug, Clone, Copy, Serialize, PartialEq)]
pub struct FdmExchangePairRuleIR {
    pub region_i: u32,
    pub region_j: u32,
    pub mode: FdmExchangePairModeIR,
}

impl<'de> Deserialize<'de> for FdmExchangePairRuleIR {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        #[derive(Deserialize)]
        struct Typed {
            region_i: u32,
            region_j: u32,
            mode: FdmExchangePairModeIR,
        }
        #[derive(Deserialize)]
        #[serde(untagged)]
        enum Wire {
            Typed(Typed),
            LegacyTriple(u32, u32, f64),
        }
        Ok(match Wire::deserialize(deserializer)? {
            Wire::Typed(rule) => Self {
                region_i: rule.region_i,
                region_j: rule.region_j,
                mode: rule.mode,
            },
            Wire::LegacyTriple(region_i, region_j, exchange_stiffness) => Self {
                region_i,
                region_j,
                mode: FdmExchangePairModeIR::Explicit { exchange_stiffness },
            },
        })
    }
}

impl FdmExchangePairRuleIR {
    /// Region pair with the smaller index first.
    pub fn normalized_pair(&self) -> (u32, u32) {
        (
            self.region_i.min(self.region_j),
            self.region_i.max(self.region_j),
        )
    }
}

/// Validate resolved FDM exchange pair rules. Region indices are unbounded
/// `u32` values; `0` (unnamed base region) and `u32::MAX` (inactive sentinel)
/// cannot be rule endpoints.
pub fn validate_fdm_exchange_pair_rules(rules: &[FdmExchangePairRuleIR]) -> Result<(), String> {
    let mut seen = std::collections::BTreeMap::new();
    for (index, rule) in rules.iter().enumerate() {
        let (low, high) = rule.normalized_pair();
        if low == high {
            return Err(format!(
                "fdm_exchange_pair_rule_invalid: rule_index={index} connects region {low} to itself"
            ));
        }
        if low == 0 || high == u32::MAX {
            return Err(format!(
                "fdm_exchange_pair_rule_invalid: rule_index={index} regions=({low}, {high}) must name two realized regions"
            ));
        }
        let valid_value = match rule.mode {
            FdmExchangePairModeIR::HarmonicScale { scale } => scale.is_finite() && scale >= 0.0,
            FdmExchangePairModeIR::Explicit { exchange_stiffness } => {
                exchange_stiffness.is_finite() && exchange_stiffness >= 0.0
            }
            FdmExchangePairModeIR::Disabled => true,
        };
        if !valid_value {
            return Err(format!(
                "fdm_exchange_pair_rule_invalid: rule_index={index} regions=({low}, {high}) value must be finite and >= 0"
            ));
        }
        if let Some(previous) = seen.insert((low, high), rule.mode) {
            if previous != rule.mode {
                return Err(format!(
                    "fdm_exchange_pair_rule_conflict: regions=({low}, {high}) have conflicting rules"
                ));
            }
        }
    }
    Ok(())
}

/// Per-axis boundary policy for FDM PBC.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum AxisBoundary {
    #[default]
    Open,
    Periodic,
}

/// FDM periodicity configuration, carried in `FdmPlanIR`.
///
/// See `docs/physics/0600-periodic-boundary-conditions.md`.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct FdmPeriodicityIR {
    /// Per-axis boundary: `[x, y, z]`.
    pub axes: [AxisBoundary; 3],
    /// Demagnetization periodicity semantics.
    pub demag: FdmDemagPeriodicityIR,
    /// Per-axis image count for `TruncatedImages` demag.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub image_counts: Option<[u32; 3]>,
}

/// Checked, lane-neutral cost of the resolved truncated-image workspace.
/// This is published as provenance and is computed before FFT allocation.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ResolvedPeriodicImagesIR {
    pub requested_image_counts: [u32; 3],
    pub resolved_image_counts: [u32; 3],
    pub padded_counts: [u64; 3],
    pub image_terms: u64,
    pub estimated_bytes: u64,
    pub kernel: String,
}

/// Planner-resolved demagnetization boundary realization for FDM.
///
/// `FdmPeriodicityIR` remains the requested public policy.  Runtime lanes
/// must consume this resolved value so that CPU and CUDA cannot reinterpret
/// `open` differently when local operators are periodic.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ResolvedFdmDemagBoundaryIR {
    Open,
    PeriodicTruncatedImages { image_counts: [u32; 3] },
}

/// Demag periodicity semantics for FDM.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum FdmDemagPeriodicityIR {
    /// Standard open-boundary zero-padded FFT convolution.
    #[default]
    Open,
    /// Truncated periodic images (MuMax-style N^pbc kernel).
    TruncatedImages,
    /// Static k=0 FEM periodic-airbox demag.
    PeriodicAirboxK0,
}

impl FdmPeriodicityIR {
    /// Returns `true` if any axis is periodic.
    pub fn has_any_periodic(&self) -> bool {
        self.axes
            .iter()
            .any(|a| matches!(a, AxisBoundary::Periodic))
    }

    /// Returns `true` if a specific axis index (0=x, 1=y, 2=z) is periodic.
    pub fn is_periodic(&self, axis: usize) -> bool {
        matches!(self.axes[axis], AxisBoundary::Periodic)
    }

    /// Resolve the requested demagnetization policy for one executable FDM
    /// plan.  Periodic local operators plus an open demagnetization kernel are
    /// not a legal physical realization and must fail before either runtime
    /// lane is constructed.
    pub fn resolve_demag_boundary(
        &self,
        demag_enabled: bool,
    ) -> Result<ResolvedFdmDemagBoundaryIR, String> {
        if self.demag == FdmDemagPeriodicityIR::PeriodicAirboxK0 {
            return Err(
                "FDM periodic demag does not support pbc.demag='periodic_airbox_k0'; use 'open' without periodic axes or 'truncated_images'".to_string(),
            );
        }
        if !demag_enabled {
            return Ok(ResolvedFdmDemagBoundaryIR::Open);
        }
        if self.has_any_periodic() && self.demag == FdmDemagPeriodicityIR::Open {
            return Err(
                "FDM periodic demag requires pbc.demag='truncated_images'; pbc.demag='open' is incompatible with periodic axes".to_string(),
            );
        }
        if self.demag == FdmDemagPeriodicityIR::TruncatedImages && self.has_any_periodic() {
            let requested = self.image_counts.unwrap_or([10, 10, 10]);
            let mut image_counts = [0; 3];
            let mut image_terms = 1_u64;
            for (axis, count) in image_counts.iter_mut().enumerate() {
                if self.is_periodic(axis) {
                    *count = requested[axis];
                    let span = u64::from(*count)
                        .checked_mul(2)
                        .and_then(|value| value.checked_add(1))
                        .ok_or_else(|| {
                            format!(
                                "FDM periodic image count overflow on axis {axis}: {}",
                                requested[axis]
                            )
                        })?;
                    image_terms = image_terms
                        .checked_mul(span)
                        .ok_or_else(|| "FDM periodic image term count overflow".to_string())?;
                }
            }
            const MAX_PERIODIC_IMAGE_TERMS: u64 = 1_000_000;
            if image_terms > MAX_PERIODIC_IMAGE_TERMS {
                return Err(format!(
                    "FDM periodic image budget exceeded: {image_terms} image terms > {MAX_PERIODIC_IMAGE_TERMS}"
                ));
            }
            return Ok(ResolvedFdmDemagBoundaryIR::PeriodicTruncatedImages { image_counts });
        }
        Ok(ResolvedFdmDemagBoundaryIR::Open)
    }

    /// Resolve image work and padded FFT dimensions with checked arithmetic.
    /// `grid_counts` are the resolved cells, not a requested hint. Open axes
    /// use the conventional `2N` padding while periodic axes use `N`.
    pub fn resolve_periodic_images(
        &self,
        grid_counts: [u32; 3],
        precision: ExecutionPrecision,
    ) -> Result<Option<ResolvedPeriodicImagesIR>, String> {
        if !self.has_any_periodic() || self.demag != FdmDemagPeriodicityIR::TruncatedImages {
            return Ok(None);
        }
        let requested = self.image_counts.unwrap_or([10, 10, 10]);
        let mut resolved = [0_u32; 3];
        let mut image_terms = 1_u64;
        let mut padded_counts = [0_u64; 3];
        for axis in 0..3 {
            let cells = u64::from(grid_counts[axis]);
            if cells == 0 {
                return Err(format!(
                    "FDM periodic image budget requires positive grid count on axis {axis}"
                ));
            }
            let periodic = self.is_periodic(axis);
            let padded = if periodic {
                cells
            } else {
                cells.checked_mul(2).ok_or_else(|| {
                    format!("FDM padded grid count overflow on axis {axis}: {cells}")
                })?
            };
            padded_counts[axis] = padded;
            if periodic {
                resolved[axis] = requested[axis];
                let span = u64::from(resolved[axis])
                    .checked_mul(2)
                    .and_then(|value| value.checked_add(1))
                    .ok_or_else(|| {
                        format!(
                            "FDM periodic image count overflow on axis {axis}: {}",
                            requested[axis]
                        )
                    })?;
                image_terms = image_terms
                    .checked_mul(span)
                    .ok_or_else(|| "FDM periodic image term count overflow".to_string())?;
            }
        }
        const MAX_PERIODIC_IMAGE_TERMS: u64 = 1_000_000;
        if image_terms > MAX_PERIODIC_IMAGE_TERMS {
            return Err(format!(
                "FDM periodic image budget exceeded: {image_terms} image terms > {MAX_PERIODIC_IMAGE_TERMS}"
            ));
        }
        let padded_cells = padded_counts.iter().try_fold(1_u64, |acc, count| {
            acc.checked_mul(*count)
                .ok_or_else(|| "FDM padded grid cell count overflow".to_string())
        })?;
        let bytes_per_value = match precision {
            ExecutionPrecision::Single => 4_u64,
            ExecutionPrecision::Double => 8_u64,
        };
        // Three real-domain buffers plus six half-spectrum kernels and six
        // half-spectrum work buffers.
        let spectral_x = padded_counts[0] / 2 + 1;
        let spectral_cells = spectral_x
            .checked_mul(padded_counts[1])
            .and_then(|value| value.checked_mul(padded_counts[2]))
            .ok_or_else(|| "FDM half-spectrum cell count overflow".to_string())?;
        let real_buffer_bytes = padded_cells
            .checked_mul(3)
            .and_then(|value| value.checked_mul(bytes_per_value))
            .ok_or_else(|| "FDM real workspace byte estimate overflow".to_string())?;
        let spectral_buffer_bytes = spectral_cells
            .checked_mul(12)
            .and_then(|value| value.checked_mul(2))
            .and_then(|value| value.checked_mul(bytes_per_value))
            .ok_or_else(|| "FDM spectral workspace byte estimate overflow".to_string())?;
        let estimated_bytes = real_buffer_bytes
            .checked_add(spectral_buffer_bytes)
            .ok_or_else(|| "FDM periodic workspace byte estimate overflow".to_string())?;
        const MAX_PERIODIC_WORKSPACE_BYTES: u64 = 8 * 1024 * 1024 * 1024;
        if estimated_bytes > MAX_PERIODIC_WORKSPACE_BYTES {
            return Err(format!(
                "FDM periodic workspace budget exceeded: {estimated_bytes} bytes > {MAX_PERIODIC_WORKSPACE_BYTES}"
            ));
        }
        Ok(Some(ResolvedPeriodicImagesIR {
            requested_image_counts: requested,
            resolved_image_counts: resolved,
            padded_counts,
            image_terms,
            estimated_bytes,
            kernel: "newell_truncated_images_fft".to_string(),
        }))
    }
}

// ── Spin-wave boundary conditions ────────────────────────────────────────────

/// Spin-wave boundary condition applied to the linearised LLG eigenvalue problem.
///
/// * `Free` (default) — natural Neumann BC: ∂m/∂n = 0 at the magnetic surface.
///   This is equivalent to zero surface torque and is the standard choice for
///   fully unpinned spins.
/// * `Pinned` — homogeneous Dirichlet BC: m = 0 at the magnetic surface.
///   Surface spins are frozen; precession amplitude is forced to zero there.
///   Computed by removing surface DOFs from the assembled eigenvalue problem.
/// * `Periodic` — periodic (Bloch) BC on the specified boundary pair.
///   Opposite-face DOFs are merged.  Requires a mesh with matched periodic
///   node pairs; the runner will return an error until that is implemented.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum SpinWaveBoundaryKindIR {
    #[default]
    Free,
    Pinned,
    Periodic,
    Floquet,
    SurfaceAnisotropy,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SpinWaveBoundaryConfigIR {
    pub kind: SpinWaveBoundaryKindIR,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub boundary_pair_id: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub pair_ids: Vec<String>,
    #[serde(default)]
    pub phase_convention: PhaseConventionIR,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub surface_anisotropy_ks: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub surface_anisotropy_axis: Option<[f64; 3]>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(untagged)]
pub enum SpinWaveBoundaryConditionIR {
    Legacy(SpinWaveBoundaryKindIR),
    Config(SpinWaveBoundaryConfigIR),
}

impl Default for SpinWaveBoundaryConditionIR {
    fn default() -> Self {
        Self::Legacy(SpinWaveBoundaryKindIR::Free)
    }
}

impl SpinWaveBoundaryConditionIR {
    pub fn kind(&self) -> SpinWaveBoundaryKindIR {
        match self {
            Self::Legacy(kind) => *kind,
            Self::Config(config) => config.kind,
        }
    }

    pub fn boundary_pair_id(&self) -> Option<&str> {
        match self {
            Self::Legacy(_) => None,
            Self::Config(config) => config
                .boundary_pair_id
                .as_deref()
                .or_else(|| config.pair_ids.first().map(String::as_str)),
        }
    }

    pub fn boundary_pair_ids(&self) -> Vec<&str> {
        match self {
            Self::Legacy(_) => Vec::new(),
            Self::Config(config) => {
                if config.pair_ids.is_empty() {
                    config.boundary_pair_id.iter().map(String::as_str).collect()
                } else {
                    config.pair_ids.iter().map(String::as_str).collect()
                }
            }
        }
    }

    pub fn surface_anisotropy_ks(&self) -> Option<f64> {
        match self {
            Self::Legacy(_) => None,
            Self::Config(config) => config.surface_anisotropy_ks,
        }
    }

    pub fn phase_convention(&self) -> PhaseConventionIR {
        match self {
            Self::Legacy(_) => PhaseConventionIR::default(),
            Self::Config(config) => config.phase_convention,
        }
    }

    pub fn surface_anisotropy_axis(&self) -> Option<[f64; 3]> {
        match self {
            Self::Legacy(_) => None,
            Self::Config(config) => config.surface_anisotropy_axis,
        }
    }
}

// ── Magnetostatic boundary conditions for frequency-domain demag ─────────────

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum MagnetostaticBoundaryConditionIR {
    #[default]
    Open,
    PeriodicAirboxK0,
    FloquetAirbox,
}

// ── Geometry scale ────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(untagged)]
pub enum ImportedGeometryScaleIR {
    Uniform(f64),
    Anisotropic([f64; 3]),
}

impl Default for ImportedGeometryScaleIR {
    fn default() -> Self {
        Self::Uniform(1.0)
    }
}

impl ImportedGeometryScaleIR {
    pub fn is_positive(&self) -> bool {
        match self {
            Self::Uniform(scale) => *scale > 0.0,
            Self::Anisotropic(scale) => scale.iter().all(|component| *component > 0.0),
        }
    }
}

impl BackendTarget {
    pub fn as_str(self) -> &'static str {
        match self {
            BackendTarget::Auto => "auto",
            BackendTarget::Fdm => "fdm",
            BackendTarget::Fem => "fem",
            BackendTarget::Hybrid => "hybrid",
        }
    }
}

impl RelaxationAlgorithmIR {
    pub fn as_str(self) -> &'static str {
        match self {
            RelaxationAlgorithmIR::LlgOverdamped => "llg_overdamped",
            RelaxationAlgorithmIR::ProjectedGradientBb => "projected_gradient_bb",
            RelaxationAlgorithmIR::NonlinearCg => "nonlinear_cg",
            RelaxationAlgorithmIR::TangentPlaneImplicit => "tangent_plane_implicit",
        }
    }

    /// Default integrator for the LLG relaxation family.
    ///
    /// Direct minimizers do not integrate dynamics and therefore resolve no
    /// time integrator.
    pub fn default_integrator(self) -> Option<IntegratorChoice> {
        match self {
            Self::LlgOverdamped => Some(IntegratorChoice::Rk23),
            Self::ProjectedGradientBb | Self::NonlinearCg | Self::TangentPlaneImplicit => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn truncated(counts: [u32; 3]) -> FdmPeriodicityIR {
        FdmPeriodicityIR {
            axes: [
                AxisBoundary::Periodic,
                AxisBoundary::Periodic,
                AxisBoundary::Periodic,
            ],
            demag: FdmDemagPeriodicityIR::TruncatedImages,
            image_counts: Some(counts),
        }
    }

    #[test]
    fn periodic_image_budget_accepts_boundary_case() {
        let resolved = truncated([49, 49, 49])
            .resolve_demag_boundary(true)
            .expect("49^3 image spans should fit the production budget");
        assert_eq!(
            resolved,
            ResolvedFdmDemagBoundaryIR::PeriodicTruncatedImages {
                image_counts: [49, 49, 49]
            }
        );
    }

    #[test]
    fn periodic_image_budget_rejects_excessive_work() {
        let error = truncated([100, 100, 100])
            .resolve_demag_boundary(true)
            .expect_err("excessive periodic image work must fail before runtime");
        assert!(error.contains("periodic image budget exceeded"));
    }

    #[test]
    fn periodic_image_budget_checks_u32_arithmetic() {
        let error = truncated([u32::MAX, 0, 0])
            .resolve_demag_boundary(true)
            .expect_err("u32 image span must be checked");
        assert!(error.contains("periodic image budget exceeded"));
    }

    #[test]
    fn periodic_workspace_resolves_checked_padding_and_provenance() {
        let resolved = truncated([0, 0, 0])
            .resolve_periodic_images([64, 32, 8], ExecutionPrecision::Double)
            .expect("checked workspace should resolve")
            .expect("periodic truncated-images policy should resolve");
        assert_eq!(resolved.requested_image_counts, [0, 0, 0]);
        assert_eq!(resolved.resolved_image_counts, [0, 0, 0]);
        assert_eq!(resolved.padded_counts, [64, 32, 8]);
        assert_eq!(resolved.image_terms, 1);
        assert_eq!(
            resolved.estimated_bytes,
            64 * 32 * 8 * 3 * 8 + (64 / 2 + 1) * 32 * 8 * 12 * 2 * 8
        );
        assert_eq!(resolved.kernel, "newell_truncated_images_fft");
    }

    #[test]
    fn periodic_workspace_uses_two_n_padding_on_open_axes() {
        let mut policy = truncated([1, 0, 0]);
        policy.axes[1] = AxisBoundary::Open;
        policy.axes[2] = AxisBoundary::Open;
        let resolved = policy
            .resolve_periodic_images([4, 3, 2], ExecutionPrecision::Single)
            .expect("checked workspace should resolve")
            .expect("periodic truncated-images policy should resolve");
        assert_eq!(resolved.padded_counts, [4, 6, 4]);
        assert_eq!(resolved.image_terms, 3);
        assert_eq!(
            resolved.estimated_bytes,
            4 * 6 * 4 * 3 * 4 + (4 / 2 + 1) * 6 * 4 * 12 * 2 * 4
        );
    }

    #[test]
    fn periodic_workspace_rejects_first_image_budget_overflow() {
        let error = truncated([50, 50, 50])
            .resolve_periodic_images([8, 8, 8], ExecutionPrecision::Double)
            .expect_err("the first image count above the budget must fail");
        assert!(error.contains("periodic image budget exceeded"));
    }

    #[test]
    fn periodic_workspace_rejects_non_positive_grid_and_checked_padding_overflow() {
        let zero = truncated([0, 0, 0])
            .resolve_periodic_images([0, 1, 1], ExecutionPrecision::Double)
            .expect_err("zero grid counts are not executable");
        assert!(zero.contains("positive grid count"));

        let mut open_policy = truncated([0, 0, 0]);
        open_policy.axes = [
            AxisBoundary::Periodic,
            AxisBoundary::Open,
            AxisBoundary::Open,
        ];
        let overflow = open_policy
            .resolve_periodic_images([u32::MAX, u32::MAX, u32::MAX], ExecutionPrecision::Double)
            .expect_err("padded cell multiplication must be checked");
        assert!(overflow.contains("overflow"));
    }
}

//! Physical model types for `ProblemIR`.
//!
//! Contains: problem metadata, geometry (entries, CSG), region/material/magnet
//! definitions, initial magnetization (texture/uniform/sampled), and the
//! time-dependence envelope used by fields and currents.

use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;

use crate::{
    AntennaConductorPartIR, AntennaRigidTransformIR, AntennaTerminalFaceSelectorsIR,
    CpwWidthStationIR, ImportedGeometryScaleIR, MicrostripWidthStationIR,
};

// ── Problem metadata ──────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ProblemMeta {
    pub name: String,
    pub description: Option<String>,
    pub script_language: String,
    pub script_source: Option<String>,
    pub script_api_version: String,
    pub serializer_version: String,
    pub entrypoint_kind: String,
    pub source_hash: Option<String>,
    pub runtime_metadata: BTreeMap<String, Value>,
    pub backend_revision: Option<String>,
    pub seeds: Vec<u64>,
}

// ── Geometry ──────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct GeometryIR {
    pub entries: Vec<GeometryEntryIR>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum GeometryEntryIR {
    ImportedGeometry {
        name: String,
        source: String,
        format: String,
        #[serde(default)]
        scale: ImportedGeometryScaleIR,
    },
    Box {
        name: String,
        size: [f64; 3],
    },
    Cylinder {
        name: String,
        radius: f64,
        height: f64,
        axis: [f64; 3],
    },
    SinWaveguide {
        name: String,
        length: f64,
        width: f64,
        height: f64,
        period: f64,
        amplitude: f64,
        #[serde(default)]
        phase: f64,
        #[serde(default)]
        z0: f64,
    },
    ArchWaveguide {
        name: String,
        length: f64,
        width: f64,
        height: f64,
        arch_height: f64,
        #[serde(default)]
        z0: f64,
    },
    #[serde(rename = "microstrip")]
    MicrostripAntenna {
        name: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        r#loop: Option<crate::antenna::MicrostripClosedLoopIR>,
        length_m: f64,
        thickness_m: f64,
        conductivity_s_per_m: f64,
        transform: AntennaRigidTransformIR,
        stations: Vec<MicrostripWidthStationIR>,
        return_width_m: f64,
        return_offset_m: f64,
        conductors: Vec<AntennaConductorPartIR>,
        terminal_faces: BTreeMap<String, AntennaTerminalFaceSelectorsIR>,
    },
    #[serde(rename = "cpw")]
    CpwAntenna {
        name: String,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        r#loop: Option<crate::antenna::CpwClosedLoopIR>,
        length_m: f64,
        thickness_m: f64,
        conductivity_s_per_m: f64,
        transform: AntennaRigidTransformIR,
        stations: Vec<CpwWidthStationIR>,
        conductors: Vec<AntennaConductorPartIR>,
        terminal_faces: BTreeMap<String, AntennaTerminalFaceSelectorsIR>,
    },
    Ellipsoid {
        name: String,
        radii: [f64; 3],
    },
    Sphere {
        name: String,
        radius: f64,
    },
    Ellipse {
        name: String,
        radii: [f64; 2],
        height: f64,
    },
    Difference {
        name: String,
        base: std::boxed::Box<GeometryEntryIR>,
        tool: std::boxed::Box<GeometryEntryIR>,
    },
    Union {
        name: String,
        a: std::boxed::Box<GeometryEntryIR>,
        b: std::boxed::Box<GeometryEntryIR>,
    },
    Intersection {
        name: String,
        a: std::boxed::Box<GeometryEntryIR>,
        b: std::boxed::Box<GeometryEntryIR>,
    },
    Translate {
        name: String,
        base: std::boxed::Box<GeometryEntryIR>,
        by: [f64; 3],
    },
}

impl GeometryEntryIR {
    pub fn name(&self) -> &str {
        match self {
            Self::ImportedGeometry { name, .. }
            | Self::Box { name, .. }
            | Self::Cylinder { name, .. }
            | Self::SinWaveguide { name, .. }
            | Self::ArchWaveguide { name, .. }
            | Self::MicrostripAntenna { name, .. }
            | Self::CpwAntenna { name, .. }
            | Self::Ellipsoid { name, .. }
            | Self::Sphere { name, .. }
            | Self::Ellipse { name, .. }
            | Self::Difference { name, .. }
            | Self::Union { name, .. }
            | Self::Intersection { name, .. }
            | Self::Translate { name, .. } => name,
        }
    }
}

// ── Region / material / magnet ────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RegionIR {
    pub name: String,
    pub geometry: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ObjectRegionIR {
    pub region_id: String,
    pub owner_object: String,
    pub name: String,
    pub shape: RegionShapeIR,
    #[serde(default)]
    pub frame: RegionFrameIR,
    #[serde(default = "default_object_region_enabled")]
    pub enabled: bool,
    #[serde(default)]
    pub priority: i32,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mesh_policy: Option<RegionMeshPolicyIR>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub material_overrides: Vec<RegionMaterialOverrideIR>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub texture_override: Option<RegionTextureOverrideIR>,
    #[serde(default)]
    pub realization_policy: RegionRealizationPolicyIR,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub material_transition: Option<MaterialTransitionSpecIR>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum RegionShapeIR {
    Box {
        size: [f64; 3],
        center: [f64; 3],
    },
    Cylinder {
        radius: f64,
        height: f64,
        center: [f64; 3],
        axis: [f64; 3],
    },
    Sphere {
        radius: f64,
        center: [f64; 3],
    },
    Csg {
        expression: std::boxed::Box<GeometryEntryIR>,
    },
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum RegionFrameIR {
    #[default]
    Object,
    World,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum RegionRealizationPolicyIR {
    #[default]
    Inherit,
    Conformal,
    Project,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum MaterialTransitionSpecIR {
    MeshRelative {
        cells: u32,
        #[serde(default = "default_material_transition_scope")]
        scope: MaterialTransitionScopeIR,
    },
    Metric {
        width: f64,
        #[serde(default = "default_material_transition_scope")]
        scope: MaterialTransitionScopeIR,
    },
    Sharp,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum MaterialTransitionScopeIR {
    Boundary,
    Inside,
    Outside,
}

fn default_material_transition_scope() -> MaterialTransitionScopeIR {
    MaterialTransitionScopeIR::Boundary
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct RegionMeshPolicyIR {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub maximum_element_size: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub minimum_element_size: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub transition_distance: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub order: Option<u32>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct RegionMaterialOverrideIR {
    pub parameter: MaterialParameterNameIR,
    pub value: MaterialParameterFieldIR,
    #[serde(default)]
    pub priority: i32,
    #[serde(default)]
    pub conflict_policy: RegionConflictPolicyIR,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum MaterialParameterNameIR {
    Ms,
    Aex,
    Alpha,
    Ku1,
    Ku2,
    AnisotropyAxis,
    Kc1,
    Kc2,
    Kc3,
    Dind,
    Dbulk,
}

impl MaterialParameterNameIR {
    /// SI unit of field values; a unit label never rescales the payload.
    pub fn canonical_unit(self) -> &'static str {
        match self {
            Self::Ms => "A/m",
            Self::Aex => "J/m",
            Self::Alpha | Self::AnisotropyAxis => "1",
            Self::Ku1 | Self::Ku2 | Self::Kc1 | Self::Kc2 | Self::Kc3 => "J/m^3",
            Self::Dind | Self::Dbulk => "J/m^2",
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum MaterialParameterFieldIR {
    Constant {
        value: Value,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        unit: Option<String>,
    },
    Linear {
        base: f64,
        gradient: [f64; 3],
        #[serde(default)]
        frame: RegionFrameIR,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        unit: Option<String>,
    },
    Radial {
        center: [f64; 3],
        radius: f64,
        inside: f64,
        outside: f64,
        #[serde(default)]
        frame: RegionFrameIR,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        unit: Option<String>,
    },
    Sampled {
        asset_id: String,
        component_count: u32,
        location: MaterialFieldLocationIR,
        unit: String,
    },
}

impl MaterialParameterFieldIR {
    /// Validate once the field is associated with a physical parameter.
    pub fn validate_unit(&self, parameter: MaterialParameterNameIR) -> Result<(), String> {
        let unit = match self {
            Self::Constant { unit, .. } | Self::Linear { unit, .. } | Self::Radial { unit, .. } => {
                unit.as_deref()
            }
            Self::Sampled { unit, .. } => Some(unit.as_str()),
        };
        let Some(unit) = unit else {
            return Ok(());
        };
        let expected = parameter.canonical_unit();
        if unit.trim() == expected || (expected == "1" && unit.trim() == "dimensionless") {
            Ok(())
        } else {
            Err(format!(
                "{parameter:?} field unit must be '{expected}' (SI), got '{unit}'; values are not converted automatically"
            ))
        }
    }
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum MaterialFieldLocationIR {
    Cell,
    Node,
    Element,
    Quadrature,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum RegionConflictPolicyIR {
    #[default]
    Error,
    HigherPriorityWins,
    MinMeshSizeWins,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct RegionTextureOverrideIR {
    pub initial_magnetization: InitialMagnetizationIR,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct MaterialParameterAssignmentIR {
    pub assignment_id: String,
    pub owner_object: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub region_id: Option<String>,
    pub parameter: MaterialParameterNameIR,
    pub value: MaterialParameterFieldIR,
    #[serde(default)]
    pub priority: i32,
    #[serde(default)]
    pub conflict_policy: RegionConflictPolicyIR,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct CouplingIR {
    pub coupling_id: String,
    pub kind: CouplingKindIR,
    pub source: CouplingEndpointIR,
    pub target: CouplingEndpointIR,
    #[serde(default = "default_object_region_enabled")]
    pub enabled: bool,
    pub parameters: CouplingParametersIR,
    #[serde(default)]
    pub capability_policy: CouplingCapabilityPolicyIR,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum CouplingKindIR {
    Exchange,
    Rkky,
    InterlayerExchange,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum CouplingEndpointIR {
    Object { object: String },
    Region { object: String, region_id: String },
    Surface { object: String, selector: String },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum CouplingParametersIR {
    Exchange {
        mode: ExchangeCouplingModeIR,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        scale: Option<f64>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        inter_exchange: Option<f64>,
    },
    Rkky {
        j1: f64,
    },
    InterlayerExchange {
        j1: f64,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        j2: Option<f64>,
    },
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ExchangeCouplingModeIR {
    HarmonicMean,
    Explicit,
    Disabled,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum CouplingCapabilityPolicyIR {
    #[default]
    RequireRuntime,
    AuthoredOnly,
}

fn default_object_region_enabled() -> bool {
    true
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct MaterialIR {
    pub name: String,
    pub saturation_magnetisation: f64,
    pub exchange_stiffness: f64,
    pub damping: f64,
    pub uniaxial_anisotropy: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub uniaxial_anisotropy_k2: Option<f64>,
    pub anisotropy_axis: Option<[f64; 3]>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cubic_anisotropy_kc1: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cubic_anisotropy_kc2: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cubic_anisotropy_kc3: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cubic_anisotropy_axis1: Option<[f64; 3]>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub cubic_anisotropy_axis2: Option<[f64; 3]>,
    // Per-node spatially varying fields (when Some, override the scalar)
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub ms_field: Option<Vec<f64>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub a_field: Option<Vec<f64>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub alpha_field: Option<Vec<f64>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub ku_field: Option<Vec<f64>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub ku2_field: Option<Vec<f64>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub kc1_field: Option<Vec<f64>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub kc2_field: Option<Vec<f64>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub kc3_field: Option<Vec<f64>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub interfacial_dmi: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub bulk_dmi: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub dind_field: Option<Vec<f64>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub dbulk_field: Option<Vec<f64>>,
}

/// Non-physical zero/default material scaffold for programmatic plan builders.
/// A resolved execution plan must overwrite the scalar material parameters;
/// this implementation only makes `FemPlanIR::default()` ergonomic for tests
/// and runtime probe construction.
impl Default for MaterialIR {
    fn default() -> Self {
        Self {
            name: String::new(),
            saturation_magnetisation: 0.0,
            exchange_stiffness: 0.0,
            damping: 0.0,
            uniaxial_anisotropy: None,
            uniaxial_anisotropy_k2: None,
            anisotropy_axis: None,
            cubic_anisotropy_kc1: None,
            cubic_anisotropy_kc2: None,
            cubic_anisotropy_kc3: None,
            cubic_anisotropy_axis1: None,
            cubic_anisotropy_axis2: None,
            ms_field: None,
            a_field: None,
            alpha_field: None,
            ku_field: None,
            ku2_field: None,
            kc1_field: None,
            kc2_field: None,
            kc3_field: None,
            interfacial_dmi: None,
            bulk_dmi: None,
            dind_field: None,
            dbulk_field: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct MagnetIR {
    #[serde(default)]
    pub object_id: Option<String>,
    pub name: String,
    pub region: String,
    pub material: String,
    pub initial_magnetization: Option<InitialMagnetizationIR>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub absorbing_boundary: Option<AbsorbingBoundaryLayerIR>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct AbsorbingBoundaryLayerIR {
    pub total_width_m: f64,
    pub ramp_width_m: f64,
    pub max_damping: f64,
    pub faces: Vec<AbsorbingBoundaryFaceIR>,
    pub profile: AbsorbingBoundaryProfileIR,
    pub frame: AbsorbingBoundaryFrameIR,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, PartialOrd, Ord)]
pub enum AbsorbingBoundaryFaceIR {
    #[serde(rename = "x+")]
    XPlus,
    #[serde(rename = "x-")]
    XMinus,
    #[serde(rename = "y+")]
    YPlus,
    #[serde(rename = "y-")]
    YMinus,
    #[serde(rename = "z+")]
    ZPlus,
    #[serde(rename = "z-")]
    ZMinus,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum AbsorbingBoundaryProfileIR {
    Linear,
    Quadratic,
    Smootherstep,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum AbsorbingBoundaryFrameIR {
    Object,
    Universe,
}

// ── Initial magnetization / texture ──────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum InitialMagnetizationIR {
    Uniform {
        value: [f64; 3],
    },
    #[serde(alias = "random")]
    RandomSeeded {
        seed: u64,
    },
    SampledField {
        values: Vec<[f64; 3]>,
    },
    PresetTexture {
        preset_kind: String,
        #[serde(default = "default_preset_version")]
        preset_version: u32,
        #[serde(default, alias = "params")]
        preset_params: BTreeMap<String, Value>,
        #[serde(default)]
        mapping: TextureMappingIR,
        #[serde(default)]
        texture_transform: TextureTransform3DIR,
    },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct TextureMappingIR {
    #[serde(default = "default_texture_mapping_space")]
    pub space: String,
    #[serde(default)]
    pub projection: TextureProjectionMode,
    #[serde(default = "default_texture_mapping_clamp_mode")]
    pub clamp_mode: String,
}

/// Supported texture projection modes.
///
/// Kept in sync with the frontend `TextureProjectionMode` union
/// and the planner `match mapping.projection { … }`.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
#[serde(rename_all = "snake_case")]
pub enum TextureProjectionMode {
    #[default]
    ObjectLocal,
    PlanarXy,
    PlanarXz,
    PlanarYz,
}

impl std::fmt::Display for TextureProjectionMode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::ObjectLocal => write!(f, "object_local"),
            Self::PlanarXy => write!(f, "planar_xy"),
            Self::PlanarXz => write!(f, "planar_xz"),
            Self::PlanarYz => write!(f, "planar_yz"),
        }
    }
}

impl Default for TextureMappingIR {
    fn default() -> Self {
        Self {
            space: default_texture_mapping_space(),
            projection: TextureProjectionMode::default(),
            clamp_mode: default_texture_mapping_clamp_mode(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct TextureTransform3DIR {
    #[serde(default = "default_texture_translation")]
    pub translation: [f64; 3],
    #[serde(default = "default_texture_rotation_quat")]
    pub rotation_quat: [f64; 4],
    #[serde(default = "default_texture_scale")]
    pub scale: [f64; 3],
    #[serde(default = "default_texture_pivot")]
    pub pivot: [f64; 3],
}

impl Default for TextureTransform3DIR {
    fn default() -> Self {
        Self {
            translation: default_texture_translation(),
            rotation_quat: default_texture_rotation_quat(),
            scale: default_texture_scale(),
            pivot: default_texture_pivot(),
        }
    }
}

fn default_texture_mapping_space() -> String {
    "object".to_string()
}

fn default_texture_mapping_clamp_mode() -> String {
    "clamp".to_string()
}

fn default_texture_translation() -> [f64; 3] {
    [0.0, 0.0, 0.0]
}

fn default_texture_rotation_quat() -> [f64; 4] {
    [0.0, 0.0, 0.0, 1.0]
}

fn default_texture_scale() -> [f64; 3] {
    [1.0, 1.0, 1.0]
}

fn default_texture_pivot() -> [f64; 3] {
    [0.0, 0.0, 0.0]
}

// ── Time-dependence envelope ──────────────────────────────────────────────────

/// Time-dependence envelope for fields and currents.
///
/// The effective value at time `t` is: `amplitude(t) = base * f(t)`
/// where `f(t)` is defined by the variant.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum TimeDependenceIR {
    /// Constant: f(t) = 1
    Constant,
    /// Sinusoidal: f(t) = sin(2π·freq·t + phase) + offset
    Sinusoidal {
        frequency_hz: f64,
        #[serde(default)]
        phase_rad: f64,
        #[serde(default)]
        offset: f64,
    },
    /// Rectangular pulse: f(t) = 1 for t_on ≤ t < t_off, else 0
    Pulse { t_on: f64, t_off: f64 },
    /// Piecewise linear: pairs of (time, value), linearly interpolated
    PiecewiseLinear { points: Vec<[f64; 2]> },
    /// Normalized sinc pulse: f(t) = amplitude * sinc(2 * cutoff_hz * (t - t0))
    SincPulse {
        cutoff_hz: f64,
        #[serde(default)]
        t0: f64,
        #[serde(default = "default_unit_amplitude")]
        amplitude: f64,
    },
}

fn default_unit_amplitude() -> f64 {
    1.0
}

fn default_preset_version() -> u32 {
    1
}

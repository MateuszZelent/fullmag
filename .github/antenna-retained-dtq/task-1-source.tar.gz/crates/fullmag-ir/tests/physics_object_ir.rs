use fullmag_ir::*;

#[test]
fn v0_4_object_type_does_not_imply_magnetization() {
    let mut problem = ProblemIRV04::bootstrap_example();
    problem.objects = vec![PhysicsObjectIR::new(
        "obj_hm",
        "heavy_metal",
        PhysicsObjectTypeIR::Conductor,
        "heavy_metal_geom",
    )];
    problem.magnetization_modules.clear();

    let value = serde_json::to_value(problem).unwrap();
    assert_eq!(value["objects"][0]["type"], "conductor");
    assert_eq!(value["magnetization_modules"], serde_json::json!([]));
    assert!(value.get("magnets").is_none());
}

#[test]
fn public_problem_ir_writer_remains_v0_3() {
    let value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();

    assert_eq!(value["ir_version"], "0.3.0");
    assert!(value.get("objects").is_none());
    assert!(value.get("magnets").is_some());
}

#[test]
fn v0_3_public_python_mesh_writer_golden_migrates_or_fails_closed() {
    let fixture: serde_json::Value = serde_json::from_str(include_str!(
        "../../../tests/golden/mesh-policy/v03-python-writer.v1.json"
    ))
    .expect("public Python mesh writer golden must be valid JSON");

    for case in fixture["cases"].as_array().unwrap() {
        let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
        let metadata = case["writer_metadata"].as_object().unwrap();
        let runtime_metadata = value["problem_meta"]["runtime_metadata"]
            .as_object_mut()
            .unwrap();
        if let Some(mesh_workflow) = metadata.get("mesh_workflow") {
            runtime_metadata.insert("mesh_workflow".to_string(), mesh_workflow.clone());
        }
        if let Some(study_universe) = metadata.get("study_universe") {
            runtime_metadata.insert("study_universe".to_string(), study_universe.clone());
        }

        match case["id"].as_str().unwrap() {
            "numeric_thin_film_airbox" => {
                migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
                let problem: ProblemIRV04 = serde_json::from_value(value).unwrap();
                problem.validate().unwrap();
                let policy = problem.fem_mesh_policy().unwrap();
                assert_eq!(policy.geometric_element_order, 1);
                assert_eq!(policy.materials.len(), 1);
                assert_eq!(policy.materials[0].target.object_id, "obj_strip");
                assert_eq!(
                    policy.materials[0].strategy_intent,
                    FemMeshStrategyIntentIR::ThinFilmTetrahedral
                );
                assert_eq!(policy.interfaces.len(), 1);
                assert_eq!(policy.interfaces[0].maximum_element_size, 8e-9);
                assert_eq!(policy.sweeps.len(), 1);
                assert_eq!(policy.sweeps[0].family_intent, FemElementFamilyIR::Tet4);
                assert_eq!(policy.sweeps[0].layers, 1);
                let airbox = policy.airbox.as_ref().unwrap();
                assert_eq!(airbox.law, FemAirboxGradingLawIR::Geometric);
                assert_eq!(airbox.near_element_size, Some(5e-9));
                assert_eq!(airbox.far_element_size, 80e-9);
                assert_eq!(airbox.element_ratio, Some(1.4));
                assert_eq!(policy.growth.as_ref().unwrap().max_neighbor_ratio, 1.4);
            }
            "explicit_hmax_auto" => {
                let error = migrate_v0_3_problem_ir_to_v0_4(&mut value)
                    .expect_err("explicit hmax='auto' must fail closed");
                assert!(
                    error.contains("fem_mesh_policy_unsupported_legacy_control"),
                    "{error}"
                );
                assert!(error.contains(
                    "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/maximum_element_size"
                ));
            }
            "boundary_layer_control" => {
                let error = migrate_v0_3_problem_ir_to_v0_4(&mut value)
                    .expect_err("boundary-layer controls must fail closed");
                assert!(error.contains("fem_mesh_policy_unsupported_legacy_control"));
                assert!(error.contains(
                    "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/boundary_layer_count"
                ));
            }
            "size_field_control" => {
                let error = migrate_v0_3_problem_ir_to_v0_4(&mut value)
                    .expect_err("size fields must fail closed");
                assert!(error.contains("fem_mesh_policy_unsupported_legacy_control"));
                assert!(error.contains(
                    "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/size_fields"
                ));
            }
            other => panic!("unexpected mesh-policy golden case: {other}"),
        }
    }
}

#[test]
fn v0_3_magnet_migrates_to_object_and_magnetization_module() {
    let mut value: serde_json::Value = serde_json::from_str(include_str!(
        "../../../tests/golden/problem_ir/bootstrap_v0_3_object_migration.json"
    ))
    .unwrap();

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();

    assert_eq!(value["ir_version"], "0.4.0");
    assert_eq!(value["objects"].as_array().unwrap().len(), 2);
    assert_eq!(value["magnetization_modules"].as_array().unwrap().len(), 1);
    assert_eq!(
        value["objects"]
            .as_array()
            .unwrap()
            .iter()
            .find(|object| object["name"] == "heavy_metal")
            .unwrap()["type"],
        "antenna"
    );
    assert_eq!(
        value["unresolved"][0]["source_path"],
        "/legacy/ambiguous_reference"
    );
    assert_eq!(
        value["material_assignments"][0]["target"],
        serde_json::json!({"object_id": "obj_free_layer"})
    );
    assert_eq!(
        value["magnetization_modules"][0]["target"],
        serde_json::json!({"object_id": "obj_free_layer"})
    );
    assert_eq!(
        value["material_parameter_fields"][0]["owner_object"],
        "obj_free_layer"
    );
    assert_eq!(
        value["surface_boundary_conditions"][0]["surface"]["object_id"],
        "obj_heavy_metal"
    );
    let problem: ProblemIRV04 = serde_json::from_value(value.clone()).unwrap();
    problem
        .validate()
        .expect("migrated whole-object magnet target must validate");
    let round_trip = serde_json::to_value(problem).unwrap();
    assert_eq!(
        round_trip["surface_boundary_conditions"],
        value["surface_boundary_conditions"]
    );
    assert_eq!(round_trip["unresolved"], value["unresolved"]);
    assert!(value.get("magnets").is_none());
}

#[test]
fn v0_4_material_assignments_preserve_object_and_region_targets() {
    let mut problem = ProblemIRV04::bootstrap_example();
    problem.object_regions.push(ObjectRegionIR {
        region_id: "core".into(),
        owner_object: "obj_strip".into(),
        name: "Core".into(),
        shape: RegionShapeIR::Box {
            size: [1.0, 1.0, 1.0],
            center: [0.0, 0.0, 0.0],
        },
        frame: RegionFrameIR::Object,
        enabled: true,
        priority: 0,
        mesh_policy: None,
        material_overrides: Vec::new(),
        texture_override: None,
        realization_policy: RegionRealizationPolicyIR::Inherit,
        material_transition: None,
    });
    problem
        .material_assignments
        .push(ObjectMaterialAssignmentIR::new(
            "assignment_region_level",
            RegionRefIR {
                object_id: "obj_strip".into(),
                region_id: Some("core".into()),
            },
            "Py",
        ));

    let value = serde_json::to_value(problem).unwrap();
    assert_eq!(
        value["material_assignments"][0]["target"],
        serde_json::json!({"object_id": "obj_strip"})
    );
    assert_eq!(
        value["material_assignments"][1]["target"],
        serde_json::json!({"object_id": "obj_strip", "region_id": "core"})
    );
}

#[test]
fn v0_4_validation_rejects_reference_and_identity_errors_without_type_heuristics() {
    let mut problem = ProblemIRV04::bootstrap_example();
    problem.objects[0].object_id = "duplicate".into();
    problem.objects.push(PhysicsObjectIR::new(
        "duplicate",
        "strip",
        PhysicsObjectTypeIR::Conductor,
        "missing_geometry",
    ));
    problem
        .material_assignments
        .push(ObjectMaterialAssignmentIR::new(
            "assignment",
            RegionRefIR {
                object_id: "missing_object".into(),
                region_id: None,
            },
            "missing_material",
        ));
    problem.interfaces.push(PhysicsInterfaceIR::new(
        "interface",
        "same owner",
        SurfaceRefIR {
            object_id: "duplicate".into(),
            surface_id: "top".into(),
            orientation: [0.0, 0.0, 1.0],
        },
        SurfaceRefIR {
            object_id: "duplicate".into(),
            surface_id: "bottom".into(),
            orientation: [0.0, 0.0, -1.0],
        },
        [0.0, 0.0, 1.0],
    ));
    problem
        .material_assignments
        .push(problem.material_assignments[0].clone());
    problem.interfaces.push(problem.interfaces[0].clone());
    problem.magnetization_modules[0].target.object_id = "missing_module_target".into();
    problem.magnetization_modules[0].material_id = "missing_module_material".into();

    let errors = problem
        .validate()
        .expect_err("invalid V04 problem must fail");
    let joined = errors.join("\n");
    assert!(joined.contains("duplicate object_id 'duplicate'"));
    assert!(joined.contains("duplicate name 'strip'"));
    assert!(joined.contains("geometry_id 'missing_geometry' does not exist"));
    assert!(joined.contains("missing target object 'missing_object'"));
    assert!(joined.contains("missing material 'missing_material'"));
    assert!(joined.contains("duplicate assignment_id 'assignment_obj_strip'"));
    assert!(
        joined.contains("magnetization_modules[0] missing target object 'missing_module_target'")
    );
    assert!(joined.contains("magnetization_modules[0] missing material 'missing_module_material'"));
    assert!(joined.contains("interfaces[1].interface_id must be non-empty and unique"));
    assert!(joined.contains("must reference two different object owners"));
}

fn test_object_region(region_id: &str, owner_object: &str, enabled: bool) -> ObjectRegionIR {
    ObjectRegionIR {
        region_id: region_id.into(),
        owner_object: owner_object.into(),
        name: "test region".into(),
        shape: RegionShapeIR::Box {
            size: [1.0, 1.0, 1.0],
            center: [0.0, 0.0, 0.0],
        },
        frame: RegionFrameIR::Object,
        enabled,
        priority: 0,
        mesh_policy: None,
        material_overrides: Vec::new(),
        texture_override: None,
        realization_policy: RegionRealizationPolicyIR::Inherit,
        material_transition: None,
    }
}

#[test]
fn v0_4_validation_rejects_empty_and_duplicate_material_names() {
    for invalid_name in ["", " \t "] {
        let mut problem = ProblemIRV04::bootstrap_example();
        problem.materials[0].name = invalid_name.into();

        let errors = problem
            .validate()
            .expect_err("empty material name must fail");
        assert!(
            errors
                .iter()
                .any(|error| error == "materials[0].name must not be empty"),
            "{errors:?}"
        );
    }

    let mut problem = ProblemIRV04::bootstrap_example();
    let duplicate_name = problem.materials[0].name.clone();
    let duplicate_material = problem.materials[0].clone();
    problem.materials.push(duplicate_material);
    let errors = problem
        .validate()
        .expect_err("duplicate exact name must fail");
    assert!(
        errors
            .iter()
            .any(|error| { error == &format!("materials[1] duplicate name '{duplicate_name}'") }),
        "{errors:?}"
    );
}

#[test]
fn v0_4_validation_preserves_exact_whitespace_material_names_and_references() {
    let mut problem = ProblemIRV04::bootstrap_example();
    let mut leading = problem.materials[0].clone();
    leading.name = " Py ".into();
    let mut trailing = problem.materials[0].clone();
    trailing.name = "Py ".into();
    problem.materials.extend([leading, trailing]);
    problem.material_assignments[0].material_id = " Py ".into();
    problem.magnetization_modules[0].material_id = " Py ".into();

    problem
        .validate()
        .expect("exact names must not be normalized");
    assert_eq!(problem.materials[1].name, " Py ");
    assert_eq!(problem.materials[2].name, "Py ");
    assert_eq!(problem.material_assignments[0].material_id, " Py ");
    assert_eq!(problem.magnetization_modules[0].material_id, " Py ");
}

#[test]
fn v0_4_validation_rejects_empty_region_ids_and_unknown_owners() {
    let mut problem = ProblemIRV04::bootstrap_example();
    let display_name = problem.objects[0].name.clone();
    let display_type = serde_json::to_value(problem.objects[0].object_type)
        .unwrap()
        .as_str()
        .unwrap()
        .to_owned();
    problem.object_regions = vec![
        test_object_region("", "obj_strip", true),
        test_object_region(" \t ", "obj_strip", true),
        test_object_region("blank-owner", "", true),
        test_object_region("whitespace-owner", " \t ", true),
        test_object_region("missing-owner", "missing_object_id", true),
        test_object_region("display-name", &display_name, true),
        test_object_region("display-type", &display_type, true),
    ];

    let errors = problem
        .validate()
        .expect_err("invalid registries must fail");
    for expected in [
        "object_regions[0].region_id must not be empty",
        "object_regions[1].region_id must not be empty",
        "object_regions[2].owner_object must not be empty",
        "object_regions[3].owner_object must not be empty",
    ] {
        assert!(errors.iter().any(|error| error == expected), "{errors:?}");
    }
    for index in 4..=6 {
        assert!(
            errors.iter().any(|error| {
                error == &format!(
                    "object_regions[{index}].owner_object '{}' does not reference an existing object_id",
                    problem.object_regions[index].owner_object
                )
            }),
            "{errors:?}"
        );
    }
}

#[test]
fn v0_4_validation_rejects_global_region_id_duplicates_across_owners_and_disabled_regions() {
    let mut problem = ProblemIRV04::bootstrap_example();
    let geometry_id = problem.objects[0].geometry_id.clone();
    problem.objects.push(PhysicsObjectIR::new(
        "obj_second",
        "second",
        PhysicsObjectTypeIR::Ferromagnet,
        geometry_id,
    ));
    problem.object_regions = vec![
        test_object_region("active-shared", "obj_strip", true),
        test_object_region("active-shared", "obj_second", true),
        test_object_region("disabled-shared", "obj_strip", false),
        test_object_region("disabled-shared", "obj_second", false),
    ];

    let errors = problem
        .validate()
        .expect_err("global duplicate regions must fail");
    assert!(
        errors
            .iter()
            .any(|error| error == "object_regions[1] duplicate region_id 'active-shared'"),
        "{errors:?}"
    );
    assert!(
        errors
            .iter()
            .any(|error| error == "object_regions[3] duplicate region_id 'disabled-shared'"),
        "{errors:?}"
    );
}

#[test]
fn v0_4_validation_accepts_multiple_exact_registry_references() {
    let mut problem = ProblemIRV04::bootstrap_example();
    let geometry_id = problem.objects[0].geometry_id.clone();
    problem.objects.push(PhysicsObjectIR::new(
        "obj_second",
        "second",
        PhysicsObjectTypeIR::Ferromagnet,
        geometry_id,
    ));
    let mut second_material = problem.materials[0].clone();
    second_material.name = "CoFe".into();
    problem.materials.push(second_material);
    problem.object_regions = vec![
        test_object_region("region_strip", "obj_strip", true),
        test_object_region("region_second", "obj_second", true),
    ];

    let second_target = RegionRefIR {
        object_id: "obj_second".into(),
        region_id: Some("region_second".into()),
    };
    let second_assignment =
        ObjectMaterialAssignmentIR::new("assignment_second_region", second_target.clone(), "CoFe");
    problem.objects[1]
        .material_assignment_ids
        .push(second_assignment.assignment_id.clone());
    problem.material_assignments.push(second_assignment);
    let mut second_module = problem.magnetization_modules[0].clone();
    second_module.module_id = "module_second".into();
    second_module.target = second_target;
    second_module.material_id = "CoFe".into();
    problem.magnetization_modules.push(second_module);

    problem
        .validate()
        .expect("multiple valid registries must pass");
}

#[test]
fn v0_3_migration_rejects_missing_geometry_and_identifier_collisions() {
    let fixture: serde_json::Value = serde_json::from_str(include_str!(
        "../../../tests/golden/problem_ir/bootstrap_v0_3_object_migration.json"
    ))
    .unwrap();

    let mut missing_geometry = fixture.clone();
    missing_geometry["magnets"][0]["region"] = serde_json::json!("absent");
    assert!(migrate_v0_3_problem_ir_to_v0_4(&mut missing_geometry)
        .expect_err("unresolved magnet region must fail closed")
        .contains("/magnets/0/region"));

    let mut region_missing_geometry: serde_json::Value = serde_json::from_str(include_str!(
        "../../../tests/golden/problem_ir/bootstrap_v0_3_object_migration.json"
    ))
    .unwrap();
    region_missing_geometry["regions"][0]["geometry"] = serde_json::json!("missing_geometry");
    assert!(
        migrate_v0_3_problem_ir_to_v0_4(&mut region_missing_geometry)
            .expect_err("region geometry must resolve before magnet migration")
            .contains("/regions/0/geometry")
    );

    let mut collision = fixture;
    collision["geometry"]["entries"] = serde_json::json!([
        {"kind": "box", "name": "free_layer", "size": [1.0, 1.0, 1.0]},
        {"kind": "box", "name": "free_layer", "size": [2.0, 1.0, 1.0]}
    ]);
    assert!(migrate_v0_3_problem_ir_to_v0_4(&mut collision)
        .expect_err("ambiguous geometry identity must fail closed")
        .contains("/geometry/entries/1/name"));

    let mut name_collision: serde_json::Value = serde_json::from_str(include_str!(
        "../../../tests/golden/problem_ir/bootstrap_v0_3_object_migration.json"
    ))
    .unwrap();
    let duplicate_magnet = name_collision["magnets"][0].clone();
    name_collision["magnets"]
        .as_array_mut()
        .unwrap()
        .push(duplicate_magnet);
    assert!(migrate_v0_3_problem_ir_to_v0_4(&mut name_collision)
        .expect_err("legacy name collision must fail closed")
        .contains("/magnets/1/name"));
}

#[test]
fn v0_3_mesh_workflow_migrates_once_into_v0_4_requested_policy() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "per_geometry": [{
            "geometry": "strip",
            "maximum_element_size": 3e-9,
            "minimum_element_size": 1e-9,
            "order": 1,
            "mesh_strategy": "swept_prism",
            "through_thickness_elements": 3,
            "through_thickness_distribution": "fixed",
            "through_thickness_element_ratio": 1.0,
            "through_thickness_symmetric": false,
            "sweep_face_meshing": "triangular",
            "sweep_direction": "auto",
            "element_family": "prism",
            "transition_policy": "pyramid_to_tetrahedra",
            "exact_layer_count": true,
            "interface_hmax": 2e-9,
            "interface_thickness": 2e-9
        }],
        "airbox": {
            "grading": "geometric",
            "minimum_element_size": 2e-9,
            "maximum_element_size": 20e-9,
            "transition_distance": 80e-9,
            "maximum_element_growth_rate": 1.3
        }
    });

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    let migration_fingerprint = value["problem_meta"]["runtime_metadata"]["mesh_policy_migration"]
        ["requested_policy_fingerprint"]
        .as_str()
        .unwrap()
        .to_string();
    let decoded: ProblemIRV04 = serde_json::from_value(value).unwrap();
    let policy = decoded
        .mesh_semantics
        .as_ref()
        .and_then(|semantics| semantics.requested_policy.as_ref())
        .expect("legacy workflow must migrate to typed requested policy");
    policy.validate().unwrap();
    assert_eq!(policy.geometric_element_order, 1);
    assert_eq!(policy.materials[0].target.object_id, "obj_strip");
    assert_eq!(policy.sweeps[0].requested_axis, FemSweepAxisIR::Auto);
    assert_eq!(policy.sweeps[0].family_intent, FemElementFamilyIR::Prism6);
    assert_eq!(policy.policy_fingerprint().unwrap(), migration_fingerprint);
}

#[test]
fn v0_3_real_mesh_workflow_shape_preserves_policy_without_silent_defaults() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["study_universe"] = serde_json::json!({
        "mode": "manual",
        "size": [300e-9, 220e-9, 180e-9],
        "center": [0.0, 0.0, 0.0],
        "airbox_hmax": 40e-9,
        "airbox_hmin": 2e-9,
        "airbox_growth_rate": 1.3,
        "airbox_grading": "auto"
    });
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "explicit_mesh_api": true,
        "build_requested": true,
        "build_target": "domain",
        "fem": {"order": 1, "hmax": 4e-9},
        "mesh_options": {
            "maximum_element_size": 4e-9,
            "minimum_element_size": 1e-9,
            "maximum_element_growth_rate": 1.4,
            "curvature_factor": 0.25,
            "narrow_region_resolution": 2e-9,
            "compute_quality": true,
            "per_element_quality": true
        },
        "default_mesh": {
            "order": 1,
            "mesh_strategy": "free_tetrahedral"
        },
        "per_geometry": [{
            "geometry": "strip",
            "mode": "inherit",
            "interface_hmax": 2e-9,
            "interface_thickness": 2e-9,
            "transition_distance": "airbox_boundary",
            "edge_hmax": 1.5e-9,
            "edge_thickness": 2e-9,
            "edge_transition_distance": "airbox_boundary"
        }]
    });

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    let migration_fingerprint = value["problem_meta"]["runtime_metadata"]["mesh_policy_migration"]
        ["requested_policy_fingerprint"]
        .as_str()
        .unwrap()
        .to_string();
    let decoded: ProblemIRV04 = serde_json::from_value(value).unwrap();
    decoded.validate().unwrap();
    let policy = decoded.fem_mesh_policy().unwrap();
    let material = &policy.materials[0];
    assert_eq!(
        material.strategy_intent,
        FemMeshStrategyIntentIR::Tetrahedral
    );
    assert_eq!(material.maximum_element_size, Some(4e-9));
    assert_eq!(material.minimum_element_size, Some(1e-9));
    assert_eq!(material.curvature_factor, Some(0.25));
    assert_eq!(material.narrow_region_resolution, Some(2e-9));
    assert_eq!(
        material.edge_transition_distance,
        Some(FemMeshTransitionDistanceIR::Boundary(
            FemMeshTransitionBoundaryIR::AirboxBoundary
        ))
    );
    assert_eq!(
        policy.interfaces[0].transition_distance,
        Some(FemMeshTransitionDistanceIR::Boundary(
            FemMeshTransitionBoundaryIR::AirboxBoundary
        ))
    );
    let airbox = policy.airbox.as_ref().unwrap();
    assert_eq!(airbox.law, FemAirboxGradingLawIR::Geometric);
    assert_eq!(airbox.near_element_size, Some(2e-9));
    assert_eq!(airbox.far_element_size, 40e-9);
    assert_eq!(airbox.element_ratio, Some(1.3));
    assert_eq!(
        airbox.transition_distance,
        Some(FemMeshTransitionDistanceIR::Boundary(
            FemMeshTransitionBoundaryIR::AirboxBoundary
        ))
    );
    assert_eq!(policy.growth.as_ref().unwrap().max_neighbor_ratio, 1.3);
    assert_eq!(
        policy.growth.as_ref().unwrap().cell_size_definition_id,
        CELL_MAX_EDGE_SIZE_DEFINITION_ID
    );
    let quality = policy.quality.as_ref().unwrap();
    assert!(quality.compute_summary);
    assert!(quality.per_element);
    assert_eq!(policy.policy_fingerprint().unwrap(), migration_fingerprint);
}

#[test]
fn v0_3_study_universe_airbox_migrates_without_mesh_workflow() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["study_universe"] = serde_json::json!({
        "mode": "manual",
        "size": [300e-9, 220e-9, 180e-9],
        "center": [0.0, 0.0, 0.0],
        "airbox_hmax": 40e-9,
        "airbox_hmin": 2e-9,
        "airbox_growth_rate": 1.3,
        "airbox_grading": "geometric"
    });
    value["problem_meta"]["runtime_metadata"]
        .as_object_mut()
        .unwrap()
        .remove("mesh_workflow");

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    let decoded: ProblemIRV04 = serde_json::from_value(value.clone()).unwrap();
    decoded.validate().unwrap();
    let airbox = decoded.fem_mesh_policy().unwrap().airbox.as_ref().unwrap();
    assert_eq!(airbox.law, FemAirboxGradingLawIR::Geometric);
    assert_eq!(airbox.near_element_size, Some(2e-9));
    assert_eq!(airbox.far_element_size, 40e-9);
    assert_eq!(airbox.element_ratio, Some(1.3));
    assert_eq!(
        value["problem_meta"]["runtime_metadata"]["mesh_policy_migration"]["source_path"],
        "/problem_meta/runtime_metadata/study_universe"
    );
    assert_eq!(
        value["problem_meta"]["runtime_metadata"]["mesh_policy_migration"]["source_paths"],
        serde_json::json!(["/problem_meta/runtime_metadata/study_universe"])
    );
    assert!(
        value["problem_meta"]["runtime_metadata"]["mesh_policy_migration"]["source_fingerprint"]
            .as_str()
            .unwrap()
            .starts_with("sha256:")
    );
    assert_eq!(
        value["problem_meta"]["runtime_metadata"]["mesh_policy_migration"]["resolver_version"],
        "fem_mesh_policy_v03_adapter.v1"
    );
}

#[test]
fn v0_3_study_universe_air_feature_controls_migrate_to_canonical_airbox() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["study_universe"] = serde_json::json!({
        "mode": "manual",
        "size": [400e-9, 240e-9, 240e-9],
        "center": [0.0, 0.0, 0.0],
        "airbox_hmax": 40e-9,
        // The default geometric law needs a near-air size.
        "airbox_hmin": 3e-9,
        "airbox_curvature_factor": 0.3,
        "airbox_narrow_region_resolution": 0.5
    });
    value["problem_meta"]["runtime_metadata"]
        .as_object_mut()
        .unwrap()
        .remove("mesh_workflow");

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    let decoded: ProblemIRV04 = serde_json::from_value(value).unwrap();
    decoded.validate().unwrap();
    let airbox = decoded.fem_mesh_policy().unwrap().airbox.as_ref().unwrap();
    assert_eq!(airbox.far_element_size, 40e-9);
    assert_eq!(airbox.curvature_factor, Some(0.3));
    assert_eq!(airbox.narrow_region_resolution, Some(0.5));
}

#[test]
fn v0_3_air_feature_controls_require_far_air_size() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["study_universe"] = serde_json::json!({
        "mode": "auto",
        "airbox_curvature_factor": 0.3
    });
    value["problem_meta"]["runtime_metadata"]
        .as_object_mut()
        .unwrap()
        .remove("mesh_workflow");

    let error = migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap_err();
    assert!(error.contains("far-air maximum is required"), "{error}");
}

#[test]
fn v0_3_global_material_controls_apply_without_per_geometry_entries() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "default_mesh": {
            "order": 1,
            "mesh_strategy": "free_tetrahedral",
            "maximum_element_size": 4e-9,
            "minimum_element_size": 1e-9
        }
    });

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    let problem: ProblemIRV04 = serde_json::from_value(value).unwrap();
    let policy = problem.fem_mesh_policy().unwrap();
    assert_eq!(policy.materials.len(), 1);
    assert_eq!(policy.materials[0].target.object_id, "obj_strip");
    assert_eq!(policy.materials[0].maximum_element_size, Some(4e-9));
    assert_eq!(policy.materials[0].minimum_element_size, Some(1e-9));
}

#[test]
fn v0_3_thin_film_layer_controls_migrate_as_tet4_layer_policy() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "per_geometry": [{
            "geometry": "strip",
            "mode": "custom",
            "order": 1,
            "mesh_strategy": "thin_film_tetrahedral",
            "topology": "tetrahedral",
            "through_thickness_elements": 3,
            "through_thickness_distribution": "fixed",
            "through_thickness_element_ratio": 1.0,
            "through_thickness_symmetric": false,
            "sweep_face_meshing": "triangular",
            "exact_layer_count": true
        }]
    });

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    let problem: ProblemIRV04 = serde_json::from_value(value).unwrap();
    let policy = problem.fem_mesh_policy().unwrap();
    assert_eq!(policy.sweeps.len(), 1);
    assert_eq!(policy.sweeps[0].family_intent, FemElementFamilyIR::Tet4);
    assert_eq!(policy.sweeps[0].transition, FemTransitionPolicyIR::Reject);
    assert_eq!(policy.sweeps[0].layers, 3);
    assert!(policy.sweeps[0].exact_layers);
}

#[test]
fn v0_3_migration_rejects_unrepresentable_or_symbolic_mesh_controls() {
    for (case_id, workflow, expected_path) in [
        (
            "boundary_layer",
            serde_json::json!({
                "per_geometry": [{
                    "geometry": "strip",
                    "mesh_strategy": "free_tetrahedral",
                    "boundary_layer_count": 2
                }]
            }),
            "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/boundary_layer_count",
        ),
        (
            "symbolic_auto",
            serde_json::json!({
                "per_geometry": [{
                    "geometry": "strip",
                    "mesh_strategy": "free_tetrahedral",
                    "maximum_element_size": "auto"
                }]
            }),
            "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/maximum_element_size",
        ),
    ] {
        let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
        value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = workflow;
        let error = migrate_v0_3_problem_ir_to_v0_4(&mut value).expect_err(case_id);
        assert!(
            error.contains("fem_mesh_policy_unsupported_legacy_control"),
            "{case_id}: {error}"
        );
        assert!(error.contains(expected_path), "{case_id}: {error}");
    }
}

#[test]
fn v0_3_rejects_typed_v0_4_policy_even_without_legacy_workflow() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["mesh_semantics"] = serde_json::json!({
        "requested_policy": {
            "schema_version": "fem_mesh_policy.v1",
            "geometric_element_order": 1,
            "materials": [],
            "interfaces": [],
            "sweeps": []
        }
    });
    value["problem_meta"]["runtime_metadata"]
        .as_object_mut()
        .unwrap()
        .remove("mesh_workflow");
    value["problem_meta"]["runtime_metadata"]
        .as_object_mut()
        .unwrap()
        .remove("study_universe");

    let error = migrate_v0_3_problem_ir_to_v0_4(&mut value)
        .expect_err("mixed V03/V04 mesh policy must fail closed");
    assert!(error.contains("/mesh_semantics/requested_policy"));
}

#[test]
fn v0_3_fem_hint_p2_fails_without_per_geometry_entries() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "fem": {"order": 2, "hmax": 4e-9}
    });

    let error = migrate_v0_3_problem_ir_to_v0_4(&mut value)
        .expect_err("flat FEM P2 hint must fail before Gmsh");
    assert!(error.contains("fem_mesh_policy_unsupported_element_order"));
    assert!(error.contains("/mesh_semantics/requested_policy/geometric_element_order"));
}

#[test]
fn v0_3_flat_mesh_options_do_not_bleed_first_object_controls_into_other_objects() {
    let mut value: serde_json::Value = serde_json::from_str(include_str!(
        "../../../tests/golden/problem_ir/bootstrap_v0_3_object_migration.json"
    ))
    .unwrap();
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "mesh_options": {"maximum_element_size": 99e-9},
        "per_geometry": [
            {
                "geometry": "free_layer",
                "mode": "custom",
                "mesh_strategy": "free_tetrahedral",
                "maximum_element_size": 4e-9
            },
            {
                "geometry": "heavy_metal",
                "mode": "custom",
                "mesh_strategy": "free_tetrahedral",
                "minimum_element_size": 1e-9
            }
        ]
    });

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    let problem: ProblemIRV04 = serde_json::from_value(value).unwrap();
    let policy = problem.fem_mesh_policy().unwrap();
    let free_layer = policy
        .materials
        .iter()
        .find(|material| material.target.object_id == "obj_free_layer")
        .unwrap();
    let heavy_metal = policy
        .materials
        .iter()
        .find(|material| material.target.object_id == "obj_heavy_metal")
        .unwrap();
    assert_eq!(free_layer.maximum_element_size, Some(4e-9));
    assert_eq!(heavy_metal.maximum_element_size, None);
    assert_eq!(heavy_metal.minimum_element_size, Some(1e-9));
}

#[test]
fn v0_4_execution_policy_and_fingerprint_ignore_legacy_extensions() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "per_geometry": [{
            "geometry": "strip",
            "maximum_element_size": 3e-9,
            "order": 1,
            "mesh_strategy": "thin_film_tetrahedral"
        }],
        "retained_unknown": {"future": true}
    });
    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    value["unknown_retained_extension"] = serde_json::json!({"opaque": 1});

    let first: ProblemIRV04 = serde_json::from_value(value.clone()).unwrap();
    let first_policy = first.fem_mesh_policy().unwrap();
    let first_fingerprint = first_policy.policy_fingerprint().unwrap();
    let migration_source_snapshot = value["problem_meta"]["runtime_metadata"]
        ["mesh_policy_migration"]["source_snapshot"]
        .clone();

    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] =
        serde_json::json!({"unrelated": "changed after migration"});
    value["unknown_retained_extension"] = serde_json::json!({"opaque": 2});
    let second: ProblemIRV04 = serde_json::from_value(value).unwrap();
    let second_policy = second.fem_mesh_policy().unwrap();

    assert_eq!(second_policy, first_policy);
    assert_eq!(
        second_policy.policy_fingerprint().unwrap(),
        first_fingerprint
    );
    assert_eq!(
        second.problem_meta.runtime_metadata["mesh_policy_migration"]["source_snapshot"],
        migration_source_snapshot
    );
}

#[test]
fn migrated_p2_geometric_element_order_fails_without_downgrade() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "per_geometry": [{
            "geometry": "strip",
            "maximum_element_size": 3e-9,
            "order": 2,
            "mesh_strategy": "thin_film_tetrahedral"
        }]
    });

    let error = migrate_v0_3_problem_ir_to_v0_4(&mut value)
        .expect_err("P2 geometry must fail during migration without downgrade");
    assert!(error.contains("fem_mesh_policy_unsupported_element_order"));
    assert!(error.contains("/mesh_semantics/requested_policy/geometric_element_order"));
}

#[test]
fn v0_3_mesh_aliases_reject_malformed_or_conflicting_present_values() {
    for (case_id, hmax, expected_path) in [
        (
            "malformed_alias",
            serde_json::json!("3 nm"),
            "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/hmax",
        ),
        (
            "conflicting_alias",
            serde_json::json!(4e-9),
            "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/hmax",
        ),
    ] {
        let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
        value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
            "per_geometry": [{
                "geometry": "strip",
                "maximum_element_size": 3e-9,
                "hmax": hmax,
                "order": 1,
                "mesh_strategy": "free_tetrahedral"
            }]
        });
        let error = migrate_v0_3_problem_ir_to_v0_4(&mut value).expect_err(case_id);
        assert!(error.contains(expected_path), "{case_id}: {error}");
    }
}

#[test]
fn v0_3_mesh_policy_migration_rejects_explicit_null_known_fields() {
    let cases = [
        (
            "per_geometry_order",
            serde_json::json!({
                "per_geometry": [{"geometry": "strip", "order": null}]
            }),
            None,
            "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/order",
        ),
        (
            "per_geometry_maximum_element_size",
            serde_json::json!({
                "per_geometry": [{
                    "geometry": "strip",
                    "maximum_element_size": null
                }]
            }),
            None,
            "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/maximum_element_size",
        ),
        (
            "per_geometry_mode",
            serde_json::json!({
                "per_geometry": [{"geometry": "strip", "mode": null}]
            }),
            None,
            "/problem_meta/runtime_metadata/mesh_workflow/per_geometry/0/mode",
        ),
        (
            "study_universe_airbox_grading",
            serde_json::json!({}),
            Some(serde_json::json!({"airbox_grading": null})),
            "/problem_meta/runtime_metadata/study_universe/airbox_grading",
        ),
    ];

    for (case_id, workflow, study_universe, expected_path) in cases {
        let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
        let runtime_metadata = value["problem_meta"]["runtime_metadata"]
            .as_object_mut()
            .unwrap();
        runtime_metadata.insert("mesh_workflow".to_string(), workflow);
        if let Some(study_universe) = study_universe {
            runtime_metadata.insert("study_universe".to_string(), study_universe);
        }

        let error = migrate_v0_3_problem_ir_to_v0_4(&mut value)
            .expect_err("present known mesh-policy field must not silently default");
        assert!(error.contains(expected_path), "{case_id}: {error}");
    }
}

#[test]
fn v0_3_mesh_policy_migration_keeps_nullable_writer_envelopes() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "fem": {"order": 1, "hmax": 20e-9, "mesh": null},
        "mesh_options": null
    });
    value["problem_meta"]["runtime_metadata"]["study_universe"] = serde_json::Value::Null;

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    let decoded: ProblemIRV04 = serde_json::from_value(value).unwrap();
    decoded.validate().unwrap();
    assert!(decoded.fem_mesh_policy().is_some());
}

#[test]
fn v0_3_mesh_policy_migration_is_atomic_on_late_error() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "per_geometry": [{
            "geometry": "strip",
            "maximum_element_size": 3e-9,
            "order": 2,
            "mesh_strategy": "thin_film_tetrahedral"
        }]
    });
    let before = value.clone();

    migrate_v0_3_problem_ir_to_v0_4(&mut value)
        .expect_err("unsupported P2 must fail after exercising the migration path");
    assert_eq!(value, before, "failed migration must not mutate its input");
}

#[test]
fn v0_3_global_defaults_cover_nonmagnetic_object_self_aliases() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    let mut spacer = value["geometry"]["entries"][0].clone();
    spacer["name"] = serde_json::json!("spacer");
    value["geometry"]["entries"]
        .as_array_mut()
        .unwrap()
        .push(spacer);
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "default_mesh": {
            "maximum_element_size": 4e-9,
            "mesh_strategy": "free_tetrahedral"
        }
    });

    migrate_v0_3_problem_ir_to_v0_4(&mut value).unwrap();
    let decoded: ProblemIRV04 = serde_json::from_value(value).unwrap();
    let policy = decoded.fem_mesh_policy().unwrap();
    let targets = policy
        .materials
        .iter()
        .map(|material| material.target.object_id.as_str())
        .collect::<std::collections::BTreeSet<_>>();
    assert_eq!(
        targets,
        std::collections::BTreeSet::from(["obj_spacer", "obj_strip"])
    );
}
#[test]
fn v0_3_migration_rejects_cross_namespace_object_alias_collision_atomically() {
    let mut value = serde_json::to_value(ProblemIR::bootstrap_example()).unwrap();
    value["magnets"][0]["object_id"] = serde_json::json!("spacer");
    let mut spacer = value["geometry"]["entries"][0].clone();
    spacer["name"] = serde_json::json!("spacer");
    value["geometry"]["entries"]
        .as_array_mut()
        .unwrap()
        .push(spacer);
    value["problem_meta"]["runtime_metadata"]["mesh_workflow"] = serde_json::json!({
        "per_geometry": [{
            "geometry": "spacer",
            "maximum_element_size": 4e-9,
            "mesh_strategy": "free_tetrahedral"
        }]
    });
    let before = value.clone();

    let error = migrate_v0_3_problem_ir_to_v0_4(&mut value)
        .expect_err("object aliases from names and custom object IDs must not be ambiguous");
    assert!(
        error.contains("/geometry/entries/1/name"),
        "unexpected collision pointer: {error}"
    );
    assert!(
        error.contains("ambiguous legacy object alias 'spacer'"),
        "{error}"
    );
    assert_eq!(value, before, "failed alias migration must remain atomic");
}

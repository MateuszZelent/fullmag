//! Resolve accepted study inputs without mutable session state.
use anyhow::{bail, Context, Result};
use fullmag_application::{
    COORDINATOR_TRANSITION_SCHEMA, CoordinatorError, CoordinatorMessage, CoordinatorTransition,
    DurableWorkerCoordinator, AcceptedPreparationReceipt, ClosedLoopPreparationReceipt, PreparationBinding, PreparationReceipt, ProjectId, ResolvedInput,
    ResolvedStudyArtifact, ResolvedTaskInput, RunId, RunSpecification, TaskClaim, TaskRecord,
    WorkerCommand, WorkerCommandEnvelope,
};
use fullmag_authoring::{
    StudyInputPort, StudyInputSource, StudyPlan, StudyPortDataKind, StudyStep,
};
use fullmag_ir::{
    BackendTarget, ExecutionDevice, ExecutionMode, ExecutionPlanIR, ExecutionPrecision, ProblemIR,
};
use fullmag_plan::{
    lower_study_plan_with_catalog, PreparationMaterialization, PreparationPlanSource,
    StudyExecutionPlan, StudyProblemCatalog, StudyStepLoweringStatus,
};
use fullmag_session::{FmsTaskPreparationReceipt, SessionStore};
use serde::Deserialize;
use sha2::{Digest, Sha256};

#[path = "study_retained_current_publication.rs"]
mod study_retained_current_publication;

pub struct AcceptedStudySnapshot {
    pub run: crate::AcceptedRunSnapshot,
    pub study: StudyPlan,
    pub catalog: StudyProblemCatalog,
    pub lowered: StudyExecutionPlan,
}

#[derive(Clone, Copy)]
enum NativeFemPreparationKind {
    TimeDomain,
    AntennaExternalLeadInspection,
}

impl AcceptedStudySnapshot {
    /// Materialize an FDM preparation receipt from one exact planned step in
    /// this immutable accepted snapshot. The preparation plan is bound to its
    /// RunSpec and step and does not use Live scene revision state. The
    /// accepted-run display projection is deterministic and view-independent.
    pub fn materialize_fdm_preparation_receipt(
        &self,
        preparation_id: impl Into<String>,
        step_id: &str,
    ) -> Result<PreparationReceipt> {
        let step = self
            .lowered
            .steps
            .iter()
            .find(|step| step.step_id == step_id)
            .with_context(|| format!("accepted study has no step `{step_id}`"))?;
        if !matches!(&step.status, StudyStepLoweringStatus::Planned) {
            bail!("accepted study step `{step_id}` is not planned");
        }
        let execution_plan = step
            .execution_plan
            .as_ref()
            .with_context(|| format!("accepted study step `{step_id}` has no execution plan"))?;
        let entry = self
            .catalog
            .entries()
            .iter()
            .find(|entry| entry.step_id() == step_id)
            .with_context(|| format!("accepted study step `{step_id}` has no ProblemIR"))?;
        let problem = entry.problem();
        let replanned = fullmag_plan::plan(problem)
            .with_context(|| format!("replan accepted ProblemIR for `{step_id}`"))?;
        if serde_json::to_value(&replanned)? != serde_json::to_value(execution_plan)? {
            bail!("accepted execution plan differs from canonical planner for `{step_id}`");
        }
        let specification_fingerprint = self.run.specification.fingerprint()?;
        let source = PreparationPlanSource::accepted_run_step(
            self.run.specification.run_id.as_str(),
            format!("sha256:{specification_fingerprint}"),
            step_id,
        )?;
        let problem_fingerprint = preparation_fingerprint(&serde_json::to_value(problem)?);
        let geometry_projection = serde_json::json!({
            "schema_version": "geometry_projection.v1",
            "geometry": &problem.geometry,
            "geometry_assets": &problem.geometry_assets,
            "regions": &problem.regions,
            "object_regions": &problem.object_regions,
            "mesh_semantics": &problem.mesh_semantics,
        });
        let display_projection = serde_json::json!({
            "schema_version": "display_projection.v1",
            "payload": {"source": "accepted_run_default"},
        });
        let materialization = PreparationMaterialization::from_fdm_execution_plan_for_accepted_run(
            problem_fingerprint,
            source,
            problem.backend_policy.requested_backend,
            execution_plan,
            preparation_fingerprint(&geometry_projection),
            preparation_fingerprint(&display_projection),
        )?;
        PreparationReceipt::ready_for_accepted_run(
            preparation_id,
            materialization.plan,
            materialization.certificates,
            Vec::new(),
            &self.run.specification,
            step_id,
        )
        .map_err(Into::into)
    }

    /// Materialize a native FEM preparation receipt for one exact planned
    /// step in this immutable accepted snapshot. The caller must supply
    /// evidence produced from the pinned FEM mesh and finite-element order;
    /// Live scene state is never consulted or rebound.
    pub fn materialize_fem_preparation_receipt(
        &self,
        preparation_id: impl Into<String>,
        step_id: &str,
        native: &fullmag_plan::NativeFemMeshSpaceEvidence,
    ) -> Result<PreparationReceipt> {
        self.materialize_native_fem_preparation_receipt(
            preparation_id,
            step_id,
            native,
            NativeFemPreparationKind::TimeDomain,
        )
    }

    /// Prepare the combined conductor/lead H1 P1 mesh of a pinned inspection
    /// step. This does not certify current, Oersted fields, or LLG coupling.
    pub fn materialize_antenna_external_lead_inspection_preparation_receipt(
        &self,
        preparation_id: impl Into<String>,
        step_id: &str,
        native: &fullmag_plan::NativeFemMeshSpaceEvidence,
    ) -> Result<PreparationReceipt> {
        self.materialize_native_fem_preparation_receipt(
            preparation_id,
            step_id,
            native,
            NativeFemPreparationKind::AntennaExternalLeadInspection,
        )
    }

    fn materialize_native_fem_preparation_receipt(
        &self,
        preparation_id: impl Into<String>,
        step_id: &str,
        native: &fullmag_plan::NativeFemMeshSpaceEvidence,
        kind: NativeFemPreparationKind,
    ) -> Result<PreparationReceipt> {
        let step = self
            .lowered
            .steps
            .iter()
            .find(|step| step.step_id == step_id)
            .with_context(|| format!("accepted study has no step `{step_id}`"))?;
        if !matches!(&step.status, StudyStepLoweringStatus::Planned) {
            bail!("accepted study step `{step_id}` is not planned");
        }
        let execution_plan = step
            .execution_plan
            .as_ref()
            .with_context(|| format!("accepted study step `{step_id}` has no execution plan"))?;
        let entry = self
            .catalog
            .entries()
            .iter()
            .find(|entry| entry.step_id() == step_id)
            .with_context(|| format!("accepted study step `{step_id}` has no ProblemIR"))?;
        let problem = entry.problem();
        let replanned = fullmag_plan::plan(problem)
            .with_context(|| format!("replan accepted ProblemIR for `{step_id}`"))?;
        if serde_json::to_value(&replanned)? != serde_json::to_value(execution_plan)? {
            bail!("accepted execution plan differs from canonical planner for `{step_id}`");
        }
        let specification_fingerprint = self.run.specification.fingerprint()?;
        let source = PreparationPlanSource::accepted_run_step(
            self.run.specification.run_id.as_str(),
            format!("sha256:{specification_fingerprint}"),
            step_id,
        )?;
        let problem_fingerprint = preparation_fingerprint(&serde_json::to_value(problem)?);
        let geometry_projection = serde_json::json!({
            "schema_version": "geometry_projection.v1",
            "geometry": &problem.geometry,
            "geometry_assets": &problem.geometry_assets,
            "regions": &problem.regions,
            "object_regions": &problem.object_regions,
            "mesh_semantics": &problem.mesh_semantics,
        });
        let display_projection = serde_json::json!({
            "schema_version": "display_projection.v1",
            "payload": {"source": "accepted_run_default"},
        });
        let geometry_fingerprint = preparation_fingerprint(&geometry_projection);
        let display_fingerprint = preparation_fingerprint(&display_projection);
        let materialization = match kind {
            NativeFemPreparationKind::TimeDomain =>
                PreparationMaterialization::from_fem_execution_plan_for_accepted_run(
                    problem_fingerprint,
                    source,
                    problem.backend_policy.requested_backend,
                    execution_plan,
                    geometry_fingerprint,
                    display_fingerprint,
                    native,
                )?,
            NativeFemPreparationKind::AntennaExternalLeadInspection =>
                PreparationMaterialization::from_antenna_external_lead_inspection_execution_plan_for_accepted_run(
                    problem_fingerprint,
                    source,
                    problem.backend_policy.requested_backend,
                    execution_plan,
                    geometry_fingerprint,
                    display_fingerprint,
                    native,
                )?,
        };
        PreparationReceipt::ready_for_accepted_run(
            preparation_id,
            materialization.plan,
            materialization.certificates,
            Vec::new(),
            &self.run.specification,
            step_id,
        )
        .map_err(Into::into)
    }

    /// Bind a prepared receipt only after matching it to this immutable study
    /// snapshot's planned step and canonical ProblemIR.
    pub fn bind_preparation_receipt(
        &self,
        step_id: &str,
        receipt: PreparationReceipt,
    ) -> Result<PreparationReceipt> {
        let step = self
            .lowered
            .steps
            .iter()
            .find(|step| step.step_id == step_id)
            .with_context(|| format!("accepted study has no step `{step_id}`"))?;
        if !matches!(&step.status, StudyStepLoweringStatus::Planned) {
            bail!("accepted study step `{step_id}` is not planned");
        }
        let pinned_plan = step
            .execution_plan
            .as_ref()
            .with_context(|| format!("accepted study step `{step_id}` has no execution plan"))?;
        let entry = self
            .catalog
            .entries()
            .iter()
            .find(|entry| entry.step_id() == step_id)
            .with_context(|| format!("accepted study step `{step_id}` has no ProblemIR"))?;
        let problem = entry.problem();
        let problem_value = serde_json::to_value(problem)
            .context("serialize accepted ProblemIR for preparation binding")?;
        let problem_fingerprint = format!(
            "sha256:{}",
            fullmag_session::canonical_json_sha256(&problem_value)
        );
        if receipt.plan.problem_fingerprint != problem_fingerprint {
            bail!("preparation receipt does not match accepted ProblemIR for `{step_id}`");
        }

        let replanned = fullmag_plan::plan(problem)
            .with_context(|| format!("replan accepted ProblemIR for `{step_id}`"))?;
        let replanned_value =
            serde_json::to_value(&replanned).context("serialize replanned execution plan")?;
        let pinned_plan_value =
            serde_json::to_value(pinned_plan).context("serialize accepted execution plan")?;
        if replanned_value != pinned_plan_value
            || receipt.plan.requested_backend != replanned.common.requested_backend
            || receipt.plan.resolved_backend != replanned.common.resolved_backend
        {
            bail!("preparation receipt differs from accepted execution plan for `{step_id}`");
        }

        receipt
            .bind_to_accepted_run(&self.run.specification, step_id)
            .map_err(Into::into)
    }

    /// Read one durable task receipt and validate its typed application
    /// payload against this immutable accepted study snapshot. SessionStore
    /// validates the envelope, catalog, and RunIntent; this boundary also
    /// verifies the application plan fingerprint, certificates, ProblemIR,
    /// canonical execution plan, RunSpec, and step identity.
    pub fn read_task_preparation_receipt(
        &self,
        store: &SessionStore,
        task_id: &str,
    ) -> Result<PreparationReceipt> {
        let run_id = self.run.specification.run_id.as_str();
        let durable = store
            .read_task_preparation_receipt(run_id, task_id)?
            .with_context(|| {
                format!("accepted run `{run_id}` has no preparation receipt for task `{task_id}`")
            })?;
        match self.validate_task_preparation_envelope(&durable, task_id)? {
            AcceptedPreparationReceipt::Solver(receipt) => Ok(receipt),
            AcceptedPreparationReceipt::ClosedLoop(_) => {
                bail!("closed-loop inspection receipt is not a solver preparation receipt")
            }
            AcceptedPreparationReceipt::RetainedCurrent(_) | AcceptedPreparationReceipt::RetainedAssetField(_) => {
                bail!("retained-current H-only receipt is not a solver preparation receipt")
            }
        }
    }

    fn validate_task_preparation_envelope(
        &self,
        durable: &FmsTaskPreparationReceipt,
        task_id: &str,
    ) -> Result<AcceptedPreparationReceipt> {
        let run_id = self.run.specification.run_id.as_str();
        if durable.run_id != run_id || durable.task_id != task_id {
            bail!("durable task preparation receipt identity differs from requested task");
        }
        let step = self
            .lowered
            .steps
            .iter()
            .find(|step| step.step_id == durable.step_id)
            .context("preparation has no accepted step")?;
        let expected_task_id = fullmag_session::task_id_for_study_step(run_id, &step.step_id)?;
        if task_id != expected_task_id || durable.task_id != expected_task_id {
            bail!("preparation receipt has another canonical accepted task identity");
        }

        if matches!(step.kind, fullmag_authoring::StudyStepKind::RetainedCurrentFieldInspection { .. }) {
            durable.validate().context("retained-current durable preparation envelope is invalid")?;
            if matches!(step.execution_plan.as_ref().map(|plan| &plan.backend_plan),
                Some(fullmag_ir::BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)
                    | fullmag_ir::BackendPlanIR::AntennaRetainedDirectFieldInspection(_))) {
                let receipt: fullmag_application::RetainedAssetFieldPreparationReceipt = serde_json::from_value(durable.payload.clone())
                    .context("retained-asset field readiness is not its strict receipt")?;
                let entry = self.catalog.entries().iter().find(|entry| entry.step_id() == step.step_id)
                    .context("retained-asset field readiness has no captured ProblemIR")?;
                receipt.validate_for_accepted_input(&self.run.specification, &expected_task_id, step, entry.problem())?;
                if durable.preparation_id != receipt.preparation_id || durable.plan_fingerprint != receipt.plan_fingerprint
                    || durable.input_fingerprint != fullmag_application::study_task_input_fingerprint(&self.run.specification, step)? {
                    bail!("retained-asset field readiness differs from its durable task envelope");
                }
                return Ok(AcceptedPreparationReceipt::RetainedAssetField(receipt));
            }
            let receipt: fullmag_application::RetainedCurrentPreparationReceipt = serde_json::from_value(durable.payload.clone())
                .context("retained-current readiness is not its strict parent-bound receipt")?;
            let entry = self.catalog.entries().iter().find(|entry| entry.step_id() == step.step_id)
                .context("retained-current readiness has no captured ProblemIR")?;
            // Stored pins are checked here; durable parent admission is repeated
            // by the preparation and worker owners, never inferred from this DTO.
            receipt.validate_for_accepted_input(&self.run.specification, &expected_task_id, step, entry.problem())?;
            if durable.preparation_id != receipt.preparation_id || durable.plan_fingerprint != receipt.plan_fingerprint
                || durable.input_fingerprint != fullmag_application::study_task_input_fingerprint(&self.run.specification, step)? {
                bail!("retained-current readiness differs from its durable task envelope");
            }
            return Ok(AcceptedPreparationReceipt::RetainedCurrent(receipt));
        }
        if !matches!(step.kind, fullmag_authoring::StudyStepKind::ClosedLoopInspection { .. }) {
            let receipt: PreparationReceipt = serde_json::from_value(durable.payload.clone())
                .context("durable task preparation payload is not an application receipt")?;
            receipt
                .validate()
                .context("durable task preparation application receipt is invalid")?;
            if receipt.preparation_id != durable.preparation_id
                || receipt.plan_fingerprint != durable.plan_fingerprint
            {
                bail!("application receipt identity differs from durable task envelope");
            }
            return self
                .bind_preparation_receipt(&durable.step_id, receipt)
                .map(AcceptedPreparationReceipt::Solver)
                .context("durable task preparation receipt does not match accepted study snapshot");
        }

        let receipt: ClosedLoopPreparationReceipt = serde_json::from_value(durable.payload.clone())
            .context("inspection readiness is not a strict operation receipt")?;
        let entry = self
            .catalog
            .entries()
            .iter()
            .find(|entry| entry.step_id() == step.step_id)
            .context("inspection readiness has no captured ProblemIR")?;
        receipt.validate_for(
            &self.run.specification,
            &expected_task_id,
            step,
            entry.problem(),
        )?;
        if durable.preparation_id != receipt.preparation_id
            || durable.plan_fingerprint != receipt.plan_fingerprint
        {
            bail!("inspection readiness differs from durable envelope");
        }
        Ok(AcceptedPreparationReceipt::ClosedLoop(receipt))
    }

    /// Read readiness using the immutable step kind, never by silently upgrading a legacy receipt.
    pub fn read_task_preparation(
        &self, store: &SessionStore, task_id: &str,
    ) -> Result<AcceptedPreparationReceipt> {
        let durable = store.read_task_preparation_receipt(self.run.specification.run_id.as_str(), task_id)?
            .context("accepted task has no durable preparation")?;
        self.validate_task_preparation_envelope(&durable, task_id)
    }

    /// Validate portable readiness evidence without creating execution authority.
    pub fn bind_closed_inspection_preparation(
        &self, durable: &fullmag_session::FmsTaskPreparationReceipt, task_id: &str,
    ) -> Result<ClosedLoopPreparationReceipt> {
        match self.validate_task_preparation_envelope(durable, task_id)? {
            AcceptedPreparationReceipt::ClosedLoop(receipt) => Ok(receipt),
            AcceptedPreparationReceipt::Solver(_) | AcceptedPreparationReceipt::RetainedCurrent(_) | AcceptedPreparationReceipt::RetainedAssetField(_) => {
                bail!("inspection readiness requires a typed closed-loop step")
            }
        }
    }

    /// Validate stored H-only readiness pins, without granting parent admission.
    /// The preparer and worker must independently revalidate the durable parent.
    pub fn bind_retained_current_preparation(
        &self, durable: &FmsTaskPreparationReceipt, task_id: &str,
    ) -> Result<fullmag_application::RetainedCurrentPreparationReceipt> {
        match self.validate_task_preparation_envelope(durable, task_id)? {
            AcceptedPreparationReceipt::RetainedCurrent(receipt) => Ok(receipt),
            _ => bail!("retained-current readiness requires its exact typed H-only step"),
        }
    }

    /// Bind the distinct frozen-asset family; parent and input projection remain independently authenticated.
    pub fn bind_retained_asset_field_preparation(
        &self, durable: &FmsTaskPreparationReceipt, task_id: &str,
    ) -> Result<fullmag_application::RetainedAssetFieldPreparationReceipt> {
        match self.validate_task_preparation_envelope(durable, task_id)? {
            AcceptedPreparationReceipt::RetainedAssetField(receipt) => Ok(receipt),
            _ => bail!("retained-asset field readiness requires its exact typed carrier"),
        }
    }

    /// Resolve a claimed study task using only its durable preparation receipt
    /// and this immutable accepted snapshot. This does not create or persist a
    /// claim, admit execution, or change task readiness. The dispatch boundary
    /// must revalidate the lease when it atomically publishes the worker command.
    pub fn resolve_task_input_from_store(
        &self,
        store: &SessionStore,
        task: &TaskRecord,
        claim: &TaskClaim,
        step_id: &str,
        inputs: std::collections::BTreeMap<String, ResolvedInput>,
    ) -> Result<ResolvedTaskInput> {
        self.resolve_task_input_and_receipt_from_store(store, task, claim, step_id, inputs)
            .map(|(_, resolved_input)| resolved_input)
    }

    fn resolve_task_input_and_receipt_from_store(
        &self,
        store: &SessionStore,
        task: &TaskRecord,
        claim: &TaskClaim,
        step_id: &str,
        inputs: std::collections::BTreeMap<String, ResolvedInput>,
    ) -> Result<(AcceptedPreparationReceipt, ResolvedTaskInput)> {
        let run_id = self.run.specification.run_id.as_str();
        let expected_task_id = fullmag_session::task_id_for_study_step(run_id, step_id)?;
        if task.task_id.as_str() != expected_task_id.as_str()
            || claim.task_id.as_str() != expected_task_id.as_str()
            || claim.run_id != self.run.specification.run_id
        {
            bail!("task, claim, and accepted study step identities do not match");
        }
        let catalog = store
            .read_run_catalog(run_id)?
            .context("claimed task resolution requires a durable run catalog")?;
        let durable_task = catalog
            .tasks
            .iter()
            .find(|entry| entry.task_id == expected_task_id)
            .context("claimed task is missing from the durable run catalog")?;
        let study_step = self
            .study
            .steps
            .iter()
            .find(|step| step.step_id == step_id)
            .with_context(|| format!("accepted study has no step `{step_id}`"))?;
        let resolved_inputs = resolve_accepted_study_inputs(
            store,
            run_id,
            &self.study.steps,
            study_step,
            inputs,
            &catalog,
        )?;
        if durable_task.input_fingerprint != task.input_fingerprint
            || durable_task.attempt_id.as_deref() != Some(claim.attempt_id.as_str())
            || durable_task.ownership_epoch != Some(claim.ownership_epoch.value())
            || durable_task.resource_id.as_deref() != Some(claim.lease.resource_id.as_str())
            || !matches!(
                &durable_task.readiness,
                fullmag_session::FmsTaskReadiness::Ready
            )
            || !matches!(
                durable_task.lifecycle,
                fullmag_session::FmsTaskLifecycle::Preparing
                    | fullmag_session::FmsTaskLifecycle::Running
                    | fullmag_session::FmsTaskLifecycle::Stopping
            )
        {
            bail!("task claim is not current and ready in the durable run catalog");
        }
        let stored_lease = store.require_active_resource_lease(
            run_id,
            expected_task_id.as_str(),
            claim.attempt_id.as_str(),
            claim.ownership_epoch.value(),
            claim.lease.resource_id.as_str(),
            claim.lease.lease_token.as_str(),
            claim.lease.heartbeat_sequence,
        )?;
        let expected_kind = match &claim.lease.kind {
            fullmag_application::ResourceKind::Cpu => fullmag_session::FmsResourceKind::Cpu,
            fullmag_application::ResourceKind::Gpu => fullmag_session::FmsResourceKind::Gpu,
            fullmag_application::ResourceKind::Storage => fullmag_session::FmsResourceKind::Storage,
            fullmag_application::ResourceKind::Meshing => fullmag_session::FmsResourceKind::Meshing,
        };
        let expected_budget = fullmag_session::FmsResourceBudget {
            cpu_millis: claim.lease.budget.cpu_millis,
            memory_bytes: claim.lease.budget.memory_bytes,
            gpu_memory_bytes: claim.lease.budget.gpu_memory_bytes,
            storage_bytes: claim.lease.budget.storage_bytes,
        };
        if stored_lease.kind != expected_kind || stored_lease.budget != expected_budget {
            bail!("durable resource lease kind or budget differs from the task claim");
        }
        let receipt = self.read_task_preparation(store, &expected_task_id)?;
        let source = receipt.source()?;
        if source.step_id != step_id || source.run_id != self.run.specification.run_id {
            bail!("durable task preparation receipt is bound to another study step");
        }
        let resolved_input = match &receipt {
            AcceptedPreparationReceipt::Solver(receipt) => self.resolved_task_input_from_bound_receipt(task, claim, step_id, receipt, resolved_inputs)?,
            AcceptedPreparationReceipt::ClosedLoop(receipt) => {
                if !resolved_inputs.is_empty() { bail!("inspection cannot consume solver state inputs"); }
                let step = self.lowered.steps.iter().find(|step| step.step_id == step_id).context("inspection step is missing")?;
                let entry = self.catalog.entries().iter().find(|entry| entry.step_id() == step_id).context("inspection ProblemIR is missing")?;
                task.resolved_closed_loop_study_input(claim, &self.run.specification, step, entry.problem(), receipt)?
            }
            AcceptedPreparationReceipt::RetainedCurrent(receipt) => {
                if !resolved_inputs.is_empty() { bail!("retained-current H-only cannot consume solver state inputs"); }
                let step = self.lowered.steps.iter().find(|step| step.step_id == step_id).context("retained-current step is missing")?;
                let entry = self.catalog.entries().iter().find(|entry| entry.step_id() == step_id).context("retained-current ProblemIR is missing")?;
                task.resolved_retained_current_study_input(claim, &self.run.specification, step, entry.problem(), receipt)?
            }
            AcceptedPreparationReceipt::RetainedAssetField(receipt) => {
                if !resolved_inputs.is_empty() { bail!("retained-asset field H-only cannot consume solver state inputs"); }
                let step = self.lowered.steps.iter().find(|step| step.step_id == step_id).context("retained-asset field step is missing")?;
                let entry = self.catalog.entries().iter().find(|entry| entry.step_id() == step_id).context("retained-asset field ProblemIR is missing")?;
                task.resolved_retained_asset_field_study_input(claim, &self.run.specification, step, entry.problem(), receipt)?
            }
        };
        Ok((receipt, resolved_input))
    }

    /// Resolve one task only from this accepted snapshot's step and catalog.
    pub fn resolve_task_input(
        &self,
        task: &TaskRecord,
        claim: &TaskClaim,
        step_id: &str,
        receipt: PreparationReceipt,
        inputs: std::collections::BTreeMap<String, ResolvedInput>,
    ) -> Result<ResolvedTaskInput> {
        let receipt = self.bind_preparation_receipt(step_id, receipt)?;
        self.resolved_task_input_from_bound_receipt(task, claim, step_id, &receipt, inputs)
    }

    fn resolved_task_input_from_bound_receipt(
        &self,
        task: &TaskRecord,
        claim: &TaskClaim,
        step_id: &str,
        receipt: &PreparationReceipt,
        inputs: std::collections::BTreeMap<String, ResolvedInput>,
    ) -> Result<ResolvedTaskInput> {
        let step = self
            .lowered
            .steps
            .iter()
            .find(|step| step.step_id == step_id)
            .with_context(|| format!("accepted study has no step `{step_id}`"))?;
        let entry = self
            .catalog
            .entries()
            .iter()
            .find(|entry| entry.step_id() == step_id)
            .with_context(|| format!("accepted study step `{step_id}` has no ProblemIR"))?;
        task.resolved_study_input(
            claim,
            &self.run.specification,
            step,
            entry.problem(),
            receipt,
            inputs,
        )
        .map_err(Into::into)
    }
}

/// Stable initial blocked reason assigned when accepted study tasks are
/// materialized. Only this scheduler-owned state may be advanced to `Queued`.
pub const ACCEPTED_TASK_AWAITING_DEPENDENCY_RESOLUTION: &str =
    fullmag_session::FMS_TASK_AWAITING_DEPENDENCY_RESOLUTION_REASON;

/// A dependency-checked task that is durably queued and ready for a later
/// explicit resource claim. Queueing does not choose a device or start a
/// worker process.
#[derive(Clone, Debug, PartialEq)]
pub struct QueuedAcceptedStudyTask {
    pub task: TaskRecord,
    pub step_id: String,
    pub resolved_inputs: std::collections::BTreeMap<String, ResolvedInput>,
}

/// Resolve the durable preparation receipt and every declared input before
/// advancing one accepted study task to the durable ready queue.
///
/// This is a single-task scheduler boundary: it does not select a resource,
/// allocate a lease, create a coordinator, or start a solver. Replaying an
/// already queued, still-unclaimed task is idempotent. A competing catalog
/// update is rejected by the monotonic catalog revision check and can be
/// retried from a fresh snapshot.
pub fn queue_accepted_study_task(
    store: &SessionStore,
    project_id: &ProjectId,
    run_id: &RunId,
    step_id: &str,
    inputs: std::collections::BTreeMap<String, ResolvedInput>,
) -> Result<QueuedAcceptedStudyTask> {
    let accepted = load_accepted_study_snapshot(store, run_id, project_id)?;
    let _writer = store.write_transaction()?;
    if !store.accepted_run_start_permitted(run_id.as_str())? {
        bail!("accepted run is waiting for explicit Compute release");
    }
    require_current_accepted_study_intent(store, &accepted)?;
    queue_accepted_study_task_locked(store, &accepted, run_id, step_id, inputs)
}

/// Queue using the immutable snapshot already validated by one scheduler
/// candidate pass. The writer still fences the exact RunIntent and every
/// mutable queue prerequisite before publishing readiness.
pub(crate) fn queue_accepted_study_task_from_snapshot(
    store: &SessionStore,
    accepted: &AcceptedStudySnapshot,
    run_id: &RunId,
    step_id: &str,
    inputs: std::collections::BTreeMap<String, ResolvedInput>,
) -> Result<QueuedAcceptedStudyTask> {
    let _writer = store.write_transaction()?;
    if !store.accepted_run_start_permitted(run_id.as_str())? {
        bail!("accepted run is waiting for explicit Compute release");
    }
    require_current_accepted_study_intent(store, accepted)?;
    queue_accepted_study_task_locked(store, accepted, run_id, step_id, inputs)
}

fn queue_accepted_study_task_locked(
    store: &SessionStore,
    accepted: &AcceptedStudySnapshot,
    run_id: &RunId,
    step_id: &str,
    inputs: std::collections::BTreeMap<String, ResolvedInput>,
) -> Result<QueuedAcceptedStudyTask> {
    if accepted.run.specification.run_id != *run_id {
        bail!("accepted task queue run differs from its immutable snapshot");
    }
    let study_step = accepted
        .study
        .steps
        .iter()
        .find(|step| step.step_id == step_id)
        .with_context(|| format!("accepted study has no step `{step_id}`"))?;
    let execution_step = accepted
        .lowered
        .steps
        .iter()
        .find(|step| step.step_id == step_id)
        .with_context(|| {
            format!("accepted study step `{step_id}` has no lowered execution record")
        })?;
    if !study_step.enabled
        || !execution_step.enabled
        || !matches!(&execution_step.status, StudyStepLoweringStatus::Planned)
    {
        bail!("only an enabled, planned accepted study step can enter the ready queue");
    }
    if !crate::study_completion::dependencies_ready_locked(store, &accepted, study_step)? {
        bail!("accepted task is blocked until its completion dependencies succeed");
    }
    let expected_task_id = fullmag_session::task_id_for_study_step(run_id.as_str(), step_id)?;
    let expected_fingerprint = fullmag_application::study_task_input_fingerprint(
        &accepted.run.specification,
        execution_step,
    )?;
    let mut catalog = store
        .read_run_catalog(run_id.as_str())?
        .context("accepted task queue requires a durable run catalog")?;
    let task_index = catalog
        .tasks
        .iter()
        .position(|task| task.task_id == expected_task_id)
        .context("accepted study task is missing from the durable run catalog")?;
    let durable_task = &catalog.tasks[task_index];
    if durable_task.input_fingerprint != expected_fingerprint {
        bail!("durable task fingerprint differs from the accepted study step");
    }
    let has_no_claim_or_runtime_progress = durable_task.attempt_id.is_none()
        && durable_task.ownership_epoch.is_none()
        && durable_task.resolved_input_fingerprint.is_none()
        && durable_task.artifact_ids.is_empty()
        && durable_task.resource_id.is_none()
        && durable_task.coordinator_watermark.is_none()
        && durable_task.coordinator_genesis.is_none();
    let retry_queue_replay = if durable_task.lifecycle == fullmag_session::FmsTaskLifecycle::Queued
        && matches!(
            &durable_task.readiness,
            fullmag_session::FmsTaskReadiness::Ready
        )
        && durable_task.attempt_id.is_none()
        && durable_task.resolved_input_fingerprint.is_none()
        && durable_task.artifact_ids.is_empty()
        && durable_task.resource_id.is_none()
    {
        match durable_task.ownership_epoch {
            Some(ownership_epoch) => {
                let matching_decisions = store
                    .list_retry_decisions(run_id.as_str())?
                    .into_iter()
                    .filter(|decision| {
                        decision.task_id == durable_task.task_id
                            && decision.ownership_epoch == ownership_epoch
                            && decision.action == fullmag_session::FmsRetryAction::Retry
                    })
                    .count();
                if matching_decisions > 1 {
                    bail!("multiple retry decisions authorize the same queued task epoch");
                }
                matching_decisions == 1
            }
            None => false,
        }
    } else {
        false
    };
    let should_publish_queue = durable_task.lifecycle
        == fullmag_session::FmsTaskLifecycle::Accepted
        && matches!(
            &durable_task.readiness,
            fullmag_session::FmsTaskReadiness::Blocked { reason }
                if reason == ACCEPTED_TASK_AWAITING_DEPENDENCY_RESOLUTION
        )
        && has_no_claim_or_runtime_progress;
    let is_queue_replay = durable_task.lifecycle == fullmag_session::FmsTaskLifecycle::Queued
        && matches!(
            &durable_task.readiness,
            fullmag_session::FmsTaskReadiness::Ready
        )
        && (has_no_claim_or_runtime_progress || retry_queue_replay);
    if !should_publish_queue && !is_queue_replay {
        bail!("accepted study task is not in the unclaimed scheduler-owned queue state");
    }

    // Receipt and inputs are revalidated on both first queueing and replay;
    // readiness cannot be preserved after its durable prerequisites diverge.
    accepted.read_task_preparation(store, &expected_task_id)?;
    let resolved_inputs = resolve_accepted_study_inputs(
        store,
        run_id.as_str(),
        &accepted.study.steps,
        study_step,
        inputs,
        &catalog,
    )?;

    if should_publish_queue {
        let task = &mut catalog.tasks[task_index];
        task.lifecycle = fullmag_session::FmsTaskLifecycle::Queued;
        task.readiness = fullmag_session::FmsTaskReadiness::Ready;
        catalog.revision = catalog
            .revision
            .checked_add(1)
            .context("run catalog revision exhausted")?;
        catalog.updated_at = chrono::Utc::now();
        store
            .commit_run_catalog(&catalog)
            .context("publish dependency-checked accepted task queue state")?;
    }

    let durable_task = catalog.tasks[task_index].clone();
    let mut task = TaskRecord::new(run_id.clone(), expected_fingerprint)?;
    task.task_id = fullmag_application::TaskId::parse(expected_task_id)?;
    task.queue()?;
    task.ownership_epoch = durable_task
        .ownership_epoch
        .map(fullmag_application::OwnershipEpoch::new)
        .transpose()?;
    task.observation = durable_task.observation.map(|value| match value {
        fullmag_session::FmsObservationState::Live => fullmag_application::ObservationState::Live,
        fullmag_session::FmsObservationState::Stale => fullmag_application::ObservationState::Stale,
        fullmag_session::FmsObservationState::Disconnected => {
            fullmag_application::ObservationState::Disconnected
        }
        fullmag_session::FmsObservationState::Reconciling => {
            fullmag_application::ObservationState::Reconciling
        }
    });
    Ok(QueuedAcceptedStudyTask {
        task,
        step_id: step_id.into(),
        resolved_inputs,
    })
}

pub(crate) fn require_current_accepted_study_intent(
    store: &SessionStore,
    accepted: &AcceptedStudySnapshot,
) -> Result<()> {
    let run_id = accepted.run.specification.run_id.as_str();
    if accepted.run.intent.run_id != run_id {
        bail!("accepted study snapshot intent belongs to another run");
    }
    let current_intent = store.read_run_intent(run_id)?;
    if current_intent.as_ref() != Some(&accepted.run.intent) {
        bail!("accepted run intent changed after its study snapshot was validated");
    }
    Ok(())
}

/// Immutable execution context reconstructed for a worker from the accepted
/// study and a durable, claim-fenced Prepare command.
#[derive(Clone, Debug, PartialEq)]
pub struct AcceptedWorkerStep {
    pub claim: TaskClaim,
    pub step_id: String,
    pub study_inputs: Vec<StudyInputPort>,
    pub problem: ProblemIR,
    pub execution_plan: ExecutionPlanIR,
    pub until_seconds: Option<f64>,
    pub resolved_input: ResolvedTaskInput,
}

struct PrevalidatedAcceptedWorkerStep {
    prepare: WorkerCommandEnvelope,
    preparation_envelope: FmsTaskPreparationReceipt,
    step_id: String,
    study_inputs: Vec<StudyInputPort>,
    problem: ProblemIR,
    execution_plan: ExecutionPlanIR,
    until_seconds: Option<f64>,
    resolved_input: ResolvedTaskInput,
}

/// Rehydrate one accepted study step only from its exact persisted Prepare
/// command. This verifies the current claim/lease, coordinator outbox,
/// preparation receipt, dependency manifest, RunSpec, and canonical plan
/// before exposing solver inputs to a process adapter.
pub fn load_accepted_worker_step(
    store: &SessionStore,
    project_id: &ProjectId,
    envelope: &WorkerCommandEnvelope,
) -> Result<AcceptedWorkerStep> {
    let accepted = load_accepted_study_snapshot(store, &envelope.claim.run_id, project_id)?;
    load_accepted_worker_step_from_snapshot(store, &accepted, envelope)
}

/// Validate a scheduler-published Prepare against its already validated
/// immutable study snapshot. Expensive plan/receipt validation and worker-step
/// construction occur outside the writer; the mutable task and input bindings
/// are rechecked before the prepared value is returned.
pub(crate) fn load_accepted_worker_step_from_snapshot(
    store: &SessionStore,
    accepted: &AcceptedStudySnapshot,
    envelope: &WorkerCommandEnvelope,
) -> Result<AcceptedWorkerStep> {
    let prepared = prevalidate_accepted_worker_step(store, accepted, envelope)?;
    let _writer = store.write_transaction()?;
    require_current_accepted_study_intent(store, accepted)?;
    let current_claim = crate::load_current_task_claim(
        store,
        &envelope.claim.run_id,
        envelope.claim.task_id.as_str(),
    )
    .context("worker Prepare has no current durable task claim")?;
    load_accepted_worker_step_locked(store, accepted, envelope, prepared, current_claim)
}

/// Rehydrate the accepted step when a worker receives its durable Start command.
/// Recover the exact preceding Prepare under a short writer fence, validate its
/// immutable execution inputs outside the fence, then refence the Start and
/// mutable task bindings before exposing the step.
pub fn load_accepted_worker_step_for_start_from_snapshot(
    store: &SessionStore,
    accepted: &AcceptedStudySnapshot,
    start_envelope: &WorkerCommandEnvelope,
) -> Result<AcceptedWorkerStep> {
    validate_start_envelope(accepted, start_envelope)?;
    let prepare = {
        let _writer = store.write_transaction()?;
        require_current_accepted_study_intent(store, accepted)?;
        let current_claim = current_claim_for_start(store, start_envelope)?;
        preceding_prepare_for_start_locked(store, &current_claim, start_envelope)?
    };

    let prepared = prevalidate_accepted_worker_step(store, accepted, &prepare)?;
    let _writer = store.write_transaction()?;
    require_current_accepted_study_intent(store, accepted)?;
    let current_claim = current_claim_for_start(store, start_envelope)?;
    let current_prepare = preceding_prepare_for_start_locked(store, &current_claim, start_envelope)?;
    if current_prepare != prepare {
        bail!("worker Start preceding Prepare changed during immutable validation");
    }
    load_accepted_worker_step_locked(store, accepted, &prepare, prepared, current_claim)
}

/// Compatibility facade for callers that do not already own a validated
/// accepted snapshot. The snapshot is loaded once, then Start uses the same
/// two short mutable fences as the snapshot-aware entry point.
pub fn load_accepted_worker_step_for_start(
    store: &SessionStore,
    project_id: &ProjectId,
    start_envelope: &WorkerCommandEnvelope,
) -> Result<AcceptedWorkerStep> {
    let accepted = load_accepted_study_snapshot(
        store,
        &start_envelope.claim.run_id,
        project_id,
    )?;
    load_accepted_worker_step_for_start_from_snapshot(store, &accepted, start_envelope)
}

fn prevalidate_accepted_worker_step(
    store: &SessionStore,
    accepted: &AcceptedStudySnapshot,
    envelope: &WorkerCommandEnvelope,
) -> Result<PrevalidatedAcceptedWorkerStep> {
    let resolved_input = match &envelope.command {
        WorkerCommand::Prepare { resolved_input } => resolved_input,
        _ => bail!("accepted worker step requires a Prepare command"),
    };
    envelope
        .validate_for_claim(&envelope.claim)
        .context("worker Prepare command is invalid")?;

    let run_id = accepted.run.specification.run_id.as_str();
    if envelope.claim.run_id.as_str() != run_id {
        bail!("worker Prepare claim differs from the accepted snapshot run");
    }
    let task_id = envelope.claim.task_id.as_str();

    let mut matching_steps = Vec::new();
    for step in &accepted.study.steps {
        let candidate = fullmag_session::task_id_for_study_step(run_id, &step.step_id)?;
        if candidate == task_id {
            matching_steps.push(step);
        }
    }
    if matching_steps.len() != 1 {
        bail!("worker task does not identify exactly one accepted study step");
    }
    let study_step = matching_steps[0];
    let step_id = study_step.step_id.as_str();
    let execution_step = accepted
        .lowered
        .steps
        .iter()
        .find(|step| step.step_id == step_id)
        .context("accepted study step has no lowered execution record")?;
    if !execution_step.enabled
        || !matches!(&execution_step.status, StudyStepLoweringStatus::Planned)
        || execution_step.until_seconds != study_step.until_seconds
        || execution_step.completion_dependencies != study_step.completion_dependencies
    {
        bail!("accepted study step is disabled or its execution controls differ");
    }
    let execution_plan = execution_step
        .execution_plan
        .as_ref()
        .context("accepted study step has no canonical execution plan")?;
    let problem = accepted
        .catalog
        .entries()
        .iter()
        .find(|entry| entry.step_id() == step_id)
        .context("accepted study step has no immutable ProblemIR")?
        .problem()
        .clone();
    // `accepted` is the canonical snapshot produced by
    // `load_accepted_study_snapshot`. Its preparation receipt is rebound to
    // the ProblemIR below, outside the writer; a separate replan here would
    // duplicate that full mesh validation. Keep using the matching plan from
    // `accepted.lowered` and retain the other checks across the writer fence.
    let inspection = matches!(
        &execution_plan.backend_plan,
        fullmag_ir::BackendPlanIR::AntennaExternalLeadInspection(_)
    );
    if inspection && (execution_step.until_seconds.is_some() || !execution_step.inputs.is_empty()) {
        bail!("accepted antenna inspection must not declare a magnetic horizon or inputs");
    }
    if !inspection
        && matches!(&problem.study, fullmag_ir::StudyIR::TimeEvolution { .. })
        && execution_step.until_seconds.is_none()
    {
        bail!("accepted TimeEvolution worker step has no pinned until_seconds");
    }
    if execution_step
        .until_seconds
        .is_some_and(|until| !until.is_finite() || until <= 0.0)
    {
        bail!("accepted worker step until_seconds is invalid");
    }

    if resolved_input.run_id != accepted.run.specification.run_id
        || resolved_input.task_id.as_str() != task_id
        || resolved_input.attempt_id.as_str() != envelope.claim.attempt_id.as_str()
        || resolved_input.ownership_epoch != envelope.claim.ownership_epoch
    {
        bail!("worker Prepare input differs from the accepted RunSpec or claim");
    }
    resolved_input
        .validate_execution_for_problem(&accepted.run.specification, &problem)
        .map_err(anyhow::Error::msg)
        .context("worker Prepare input execution differs from the accepted RunSpec or step")?;
    let plan_fingerprint =
        fullmag_session::canonical_json_sha256(&serde_json::to_value(execution_plan)?);
    if resolved_input.plan_fingerprint != plan_fingerprint {
        bail!("worker Prepare input differs from the accepted execution plan digest");
    }

    let preparation_envelope = store
        .read_task_preparation_receipt(run_id, task_id)?
        .context("accepted task has no durable preparation")?;
    let receipt = accepted.validate_task_preparation_envelope(&preparation_envelope, task_id)?;
    let preparation = receipt.binding()?;
    if resolved_input.preparation != preparation {
        bail!("worker Prepare input differs from its accepted preparation receipt");
    }

    Ok(PrevalidatedAcceptedWorkerStep {
        prepare: envelope.clone(),
        preparation_envelope,
        step_id: step_id.to_owned(),
        study_inputs: study_step.inputs.clone(),
        problem,
        execution_plan: execution_plan.clone(),
        until_seconds: execution_step.until_seconds,
        resolved_input: resolved_input.clone(),
    })
}

fn load_accepted_worker_step_locked(
    store: &SessionStore,
    accepted: &AcceptedStudySnapshot,
    envelope: &WorkerCommandEnvelope,
    prepared: PrevalidatedAcceptedWorkerStep,
    current_claim: TaskClaim,
) -> Result<AcceptedWorkerStep> {
    if prepared.prepare != *envelope {
        bail!("prevalidated worker step belongs to a different Prepare envelope");
    }
    if !envelope.claim.matches_claim(&current_claim) {
        bail!("worker Prepare command belongs to a stale task claim");
    }
    let run_id = accepted.run.specification.run_id.as_str();
    let task_id = envelope.claim.task_id.as_str();
    let run_catalog = store
        .read_run_catalog(run_id)?
        .context("worker Prepare run catalog is missing")?;
    let durable_task = run_catalog
        .tasks
        .iter()
        .find(|task| task.task_id == task_id)
        .context("worker Prepare task is missing from the run catalog")?;
    if !matches!(
        durable_task.lifecycle,
        fullmag_session::FmsTaskLifecycle::Preparing
            | fullmag_session::FmsTaskLifecycle::Running
            | fullmag_session::FmsTaskLifecycle::Stopping
    ) || !matches!(
        durable_task.readiness,
        fullmag_session::FmsTaskReadiness::Ready
    ) {
        bail!("worker Prepare requires a ready task under an active claim");
    }
    if !crate::study_completion::dependencies_ready_locked(
        store,
        accepted,
        accepted
            .study
            .steps
            .iter()
            .find(|step| step.step_id == prepared.step_id)
            .context("prevalidated worker step is missing from the accepted study")?,
    )? {
        bail!("worker Prepare is blocked by completion dependencies");
    }

    let resolved_input = match &envelope.command {
        WorkerCommand::Prepare { resolved_input } => resolved_input,
        _ => bail!("accepted worker step requires a Prepare command"),
    };
    if resolved_input.run_id != accepted.run.specification.run_id
        || resolved_input.task_id.as_str() != task_id
        || resolved_input.attempt_id.as_str() != current_claim.attempt_id.as_str()
        || resolved_input.ownership_epoch != current_claim.ownership_epoch
    {
        bail!("worker Prepare input differs from the current accepted claim");
    }
    let current_preparation_envelope = store
        .read_task_preparation_receipt(run_id, task_id)?
        .context("accepted task has no durable preparation")?;
    if current_preparation_envelope != prepared.preparation_envelope {
        bail!("accepted task preparation envelope changed during worker-step validation");
    }

    let study_step = accepted
        .study
        .steps
        .iter()
        .find(|step| step.step_id == prepared.step_id)
        .context("prevalidated worker step is missing from the accepted study")?;
    let resolved_inputs = resolve_accepted_study_inputs(
        store,
        run_id,
        &accepted.study.steps,
        study_step,
        resolved_input.inputs.clone(),
        &run_catalog,
    )?;
    if resolved_inputs != resolved_input.inputs {
        bail!("worker Prepare inputs differ from accepted dependency artifacts");
    }

    let journal = store
        .read_coordinator_journal_entry(
            run_id,
            fullmag_session::FmsCoordinatorJournalDirection::Command,
            &envelope.message_id,
        )?
        .context("worker Prepare command is not present in the durable coordinator outbox")?;
    journal.validate_for_task(durable_task)?;
    if journal.sequence != envelope.sequence
        || journal.lease_token != envelope.claim.lease_token.as_str()
        || journal.terminal
    {
        bail!("worker Prepare command identity differs from its durable outbox entry");
    }
    let watermark = durable_task
        .coordinator_watermark
        .as_ref()
        .context("worker Prepare has no projected coordinator watermark")?;
    if watermark.command_sequence < journal.sequence {
        bail!("worker Prepare is ahead of the durable run-catalog watermark");
    }
    let transition: CoordinatorTransition = serde_json::from_value(journal.payload)
        .context("durable worker Prepare payload is not a coordinator transition")?;
    if transition.schema_version != COORDINATOR_TRANSITION_SCHEMA
        || transition.message != CoordinatorMessage::Command(envelope.clone())
        || !transition
            .checkpoint
            .claim
            .is_same_or_renewed_by(&current_claim)
        || transition.checkpoint.command_sequence != envelope.sequence
        || transition.checkpoint.task.input_fingerprint != durable_task.input_fingerprint
    {
        bail!("durable worker Prepare transition differs from its command or current claim");
    }
    fullmag_application::WorkerCoordinator::restore(
        transition.checkpoint,
        &[envelope.clone()],
        &[],
    )
    .context("durable worker Prepare checkpoint is inconsistent")?;

    if let Some(binding) = &resolved_input.frozen_stage_context {
        let fullmag_ir::BackendPlanIR::Fdm(plan) = &prepared.execution_plan.backend_plan else {
            bail!("frozen history cannot dispatch through another backend");
        };
        crate::frozen_stage_lifecycle::load_execution_context(store,
            &accepted.run.specification.run_id, &prepared.step_id, plan, &current_claim, binding)?;
    }

    Ok(AcceptedWorkerStep {
        claim: current_claim,
        step_id: prepared.step_id,
        study_inputs: prepared.study_inputs,
        problem: prepared.problem,
        execution_plan: prepared.execution_plan,
        until_seconds: prepared.until_seconds,
        resolved_input: prepared.resolved_input,
    })
}

/// Shared physical input owner for execution and bounded historical validation.
/// Preserve the exact existing state transfer; no V1 hash or normalization change.
pub fn materialize_accepted_worker_execution_plan(
    store: &SessionStore,
    accepted_step: &AcceptedWorkerStep,
) -> Result<ExecutionPlanIR> {
    let resolved_input = &accepted_step.resolved_input;
    resolved_input
        .validate()
        .map_err(|error| anyhow::anyhow!(error.to_string()))?;
    if resolved_input.run_id != accepted_step.claim.run_id
        || resolved_input.task_id != accepted_step.claim.task_id
        || resolved_input.attempt_id != accepted_step.claim.attempt_id
        || resolved_input.ownership_epoch != accepted_step.claim.ownership_epoch
    {
        bail!("accepted worker inputs differ from the current task claim");
    }
    let plan_fingerprint = fullmag_session::canonical_json_sha256(
        &serde_json::to_value(&accepted_step.execution_plan)
            .context("serialize accepted worker execution plan")?,
    );
    if resolved_input.plan_fingerprint != plan_fingerprint {
        bail!("accepted worker inputs differ from the pinned execution plan");
    }

    let mut declared = std::collections::BTreeMap::<&str, &StudyInputPort>::new();
    for port in &accepted_step.study_inputs {
        fullmag_session::repository_path::validate_store_id(&port.port_id)
            .with_context(|| format!("accepted study input port `{}` is invalid", port.port_id))?;
        if declared.insert(port.port_id.as_str(), port).is_some() {
            bail!("accepted study input port `{}` is duplicated", port.port_id);
        }
    }
    for port in &accepted_step.study_inputs {
        // Authored initial conditions are already part of the immutable
        // ProblemIR and canonical plan reconstructed by the accepted loader.
        if port.required
            && !resolved_input.inputs.contains_key(&port.port_id)
            && !matches!(&port.source, StudyInputSource::AuthoredInitialState { .. })
        {
            bail!(
                "required accepted study input `{}` has no resolved artifact",
                port.port_id
            );
        }
    }

    let mut execution_plan = accepted_step.execution_plan.clone();
    let mut materialized_state = false;
    for (port_id, input) in &resolved_input.inputs {
        let port = declared.get(port_id.as_str()).with_context(|| {
            format!("resolved input `{port_id}` is not declared by the accepted study")
        })?;
        input
            .validate()
            .map_err(|error| anyhow::anyhow!(error.to_string()))?;
        let artifact = input.study_artifact.as_ref().with_context(|| {
            format!("resolved study input `{port_id}` has no typed CAS artifact binding")
        })?;
        let expected_data_kind = match port.data_kind {
            StudyPortDataKind::InitialState => "initial_state",
            StudyPortDataKind::State => "state",
            unsupported => bail!(
                "accepted worker has no solver input binding for `{unsupported:?}` port `{port_id}`"
            ),
        };
        if artifact.data_kind != expected_data_kind {
            bail!(
                "accepted study input `{port_id}` expects `{expected_data_kind}` but its artifact is `{}`",
                artifact.data_kind
            );
        }
        if let StudyInputSource::PinnedArtifact {
            artifact_id,
            content_sha256,
        } = &port.source
        {
            if artifact.artifact_id != *artifact_id || artifact.object_ref != *content_sha256 {
                bail!("pinned artifact input `{port_id}` differs from its accepted identity");
            }
        }
        if materialized_state {
            bail!("accepted worker cannot bind multiple magnetization inputs to one initial state");
        }
        let bytes = if resolved_input.frozen_stage_context.is_some() {
            store.cas().get_bounded(
                &artifact.object_ref,
                crate::frozen_stage_lifecycle::MAX_FROZEN_STATE_ENVELOPE_BYTES
                    .min(accepted_step.claim.lease.budget.storage_bytes),
            )?
        } else {
            store.cas().get(&artifact.object_ref)?
        }
        .with_context(|| format!("accepted input `{port_id}` CAS object is missing"))?;
        let decoded = fullmag_application::decode_study_artifact(artifact, &bytes)
            .map_err(|error| anyhow::anyhow!(error.to_string()))
            .with_context(|| format!("decode accepted study input `{port_id}`"))?;
        let state = match decoded {
            fullmag_application::DecodedStudyArtifact::MagnetizationState(state) => state,
            fullmag_application::DecodedStudyArtifact::FrozenMagnetizationState(state) => {
                let binding = resolved_input.frozen_stage_context.as_ref()
                    .context("full-history state input has no admitted lifecycle binding")?;
                let fullmag_ir::BackendPlanIR::Fdm(plan) = &accepted_step.execution_plan.backend_plan else {
                    bail!("full-history state input is not admitted for this backend");
                };
                crate::frozen_stage_lifecycle::load_execution_context(store,
                    &accepted_step.claim.run_id, &accepted_step.step_id, plan,
                    &accepted_step.claim, binding)?;
                state.state
            }
            _ => bail!("accepted state input `{port_id}` decoded to a non-state artifact"),
        };
        execution_plan = fullmag_runner::materialize_study_magnetization_input(
            &execution_plan,
            &state.layout,
            &state.values,
        )
        .with_context(|| {
            format!("materialize accepted state input `{port_id}` into runner plan")
        })?;
        materialized_state = true;
    }

    Ok(execution_plan)
}

fn validate_start_envelope(
    accepted: &AcceptedStudySnapshot,
    start_envelope: &WorkerCommandEnvelope,
) -> Result<()> {
    if !matches!(&start_envelope.command, WorkerCommand::Start) {
        bail!("accepted worker start requires a Start command");
    }
    start_envelope
        .validate_for_claim(&start_envelope.claim)
        .context("worker Start command is invalid")?;
    if start_envelope.claim.run_id != accepted.run.specification.run_id {
        bail!("worker Start differs from the accepted snapshot run");
    }
    Ok(())
}

fn current_claim_for_start(
    store: &SessionStore,
    start_envelope: &WorkerCommandEnvelope,
) -> Result<TaskClaim> {
    let current_claim = crate::load_current_task_claim(
        store,
        &start_envelope.claim.run_id,
        start_envelope.claim.task_id.as_str(),
    )
    .context("worker Start has no current durable task claim")?;
    if !start_envelope.claim.matches_claim(&current_claim) {
        bail!("worker Start command belongs to a stale task claim");
    }

    Ok(current_claim)
}

fn preceding_prepare_for_start_locked(
    store: &SessionStore,
    current_claim: &TaskClaim,
    start_envelope: &WorkerCommandEnvelope,
) -> Result<WorkerCommandEnvelope> {
    let recovered = crate::recover_coordinator_locked(store, current_claim)
        .context("worker Start coordinator journal could not be recovered")?;
    let starts = recovered
        .commands
        .iter()
        .enumerate()
        .filter(|(_, command)| {
            command.claim.matches_claim(current_claim)
                && matches!(&command.command, WorkerCommand::Start)
        })
        .collect::<Vec<_>>();
    if starts.len() != 1 || starts[0].1 != start_envelope {
        bail!("worker Start is not the exact unique Start in the current coordinator journal");
    }
    let start_index = starts[0].0;
    let prepares = recovered.commands[..start_index]
        .iter()
        .filter(|command| {
            command.claim.matches_claim(current_claim)
                && matches!(&command.command, WorkerCommand::Prepare { .. })
        })
        .collect::<Vec<_>>();
    if prepares.len() != 1 {
        bail!("worker Start requires exactly one preceding durable Prepare command");
    }
    Ok((*prepares[0]).clone())
}

/// Bytes emitted for one declared output port and study case.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct StudyOutputPayload {
    pub port_id: String,
    pub case_id: String,
    pub codec_id: String,
    pub codec_version: String,
    pub bytes: Vec<u8>,
}

/// System-owned bytes needed to rebuild one historical FDM CPU observation
/// runtime. They are published beside, but never masquerade as, declared study
/// outputs.
#[derive(Clone, Debug, PartialEq)]
pub struct ObservationSourcePayload {
    pub accepted_state_ref: fullmag_quantities::AcceptedStateRef,
    pub snapshot_bytes: Vec<u8>,
    pub state_bytes: Vec<u8>,
    pub grid_cells: [u32; 3],
}

impl ObservationSourcePayload {
    pub fn validate(&self) -> Result<()> {
        validate_observation_source_payload(self)
    }
}

/// Historical evaluator reconstructed only from one immutable accepted source.
/// It owns no live runtime, publisher, worker, or command handle.
pub struct LoadedStudyObservationRuntime {
    pub descriptor: fullmag_session::FmsObservationSourceDescriptor,
    pub runtime: fullmag_runner::ObservationRuntime,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct FdmCpuObservationSnapshotWire {
    schema_version: String,
    clock: fullmag_quantities::ObservationClock,
    #[serde(default)]
    transactional_state_digest: Option<String>,
    #[serde(default)]
    magnetization_digest: Option<String>,
    clock_digest: String,
    state_digest: String,
    primary_carrier_ids: Vec<String>,
}

fn validate_observation_source_payload(payload: &ObservationSourcePayload) -> Result<()> {
    payload
        .accepted_state_ref
        .validate()
        .map_err(|error| anyhow::anyhow!(error.to_string()))?;
    let snapshot: FdmCpuObservationSnapshotWire =
        serde_json::from_slice(&payload.snapshot_bytes)
            .context("observation source snapshot is not strict FDM CPU v1 JSON")?;
    if snapshot.schema_version != fullmag_session::FMS_FDM_CPU_ACCEPTED_STATE_SNAPSHOT_SCHEMA {
        bail!("observation source has an unsupported accepted-state snapshot schema");
    }
    snapshot
        .clock
        .validate()
        .map_err(|error| anyhow::anyhow!(error.to_string()))?;
    if snapshot
        .clock
        .digest()
        .map_err(|error| anyhow::anyhow!(error.to_string()))?
        != snapshot.clock_digest
        || snapshot.clock_digest != payload.accepted_state_ref.id.clock_digest
        || snapshot.state_digest != payload.accepted_state_ref.id.state_digest
        || snapshot.clock.accepted_step != payload.accepted_state_ref.id.accepted_step
    {
        bail!("observation snapshot identity differs from accepted_state_ref");
    }
    let transactional_state_digest = snapshot
        .transactional_state_digest
        .as_deref()
        .context("observation snapshot lacks the transactional-state preimage")?;
    let magnetization_digest = snapshot
        .magnetization_digest
        .as_deref()
        .context("observation snapshot lacks a magnetization binding")?;
    if !fullmag_quantities::is_canonical_sha256(transactional_state_digest)
        || !fullmag_quantities::is_canonical_sha256(magnetization_digest)
        || snapshot.primary_carrier_ids != ["fdm.cpu.transactional-state-digest.v1"]
    {
        bail!("observation snapshot primary carriers are invalid");
    }
    let digests = fullmag_quantities::accepted_state_digests(
        snapshot.clock,
        &[fullmag_quantities::AcceptedPrimaryCarrier {
            carrier_id: "fdm.cpu.transactional-state-digest.v1",
            canonical_bytes: transactional_state_digest.as_bytes(),
        }],
    )
    .map_err(|error| anyhow::anyhow!(error.to_string()))?;
    if digests.clock_digest != snapshot.clock_digest
        || digests.state_digest != snapshot.state_digest
    {
        bail!("observation snapshot digest preimage differs from its accepted identity");
    }

    let decoded = fullmag_application::decode_study_artifact_bytes(
        "state",
        fullmag_application::STUDY_MAGNETIZATION_CODEC_ID,
        fullmag_application::STUDY_MAGNETIZATION_CODEC_VERSION,
        &payload.state_bytes,
    )
    .context("observation terminal state does not match the registered codec")?;
    let fullmag_application::DecodedStudyArtifact::MagnetizationState(state) = decoded else {
        bail!("observation terminal state is not a magnetization state");
    };
    let snapshot_dt_bits = snapshot.clock.dt_seconds.map(f64::to_bits);
    let state_dt_bits = (state.solver_dt_s > 0.0).then(|| state.solver_dt_s.to_bits());
    if state.step != snapshot.clock.accepted_step
        || state.time_s.to_bits() != snapshot.clock.time_seconds.to_bits()
        || state_dt_bits != snapshot_dt_bits
    {
        bail!("observation terminal state clock differs from its accepted snapshot");
    }
    let layout_grid = state
        .layout
        .get("grid_cells")
        .and_then(serde_json::Value::as_array)
        .filter(|values| values.len() == 3)
        .and_then(|values| {
            Some([
                u32::try_from(values[0].as_u64()?).ok()?,
                u32::try_from(values[1].as_u64()?).ok()?,
                u32::try_from(values[2].as_u64()?).ok()?,
            ])
        })
        .context("observation terminal state has no valid FDM grid")?;
    if layout_grid != payload.grid_cells {
        bail!("observation terminal state grid differs from its descriptor");
    }
    let expected_cell_count = payload
        .grid_cells
        .into_iter()
        .try_fold(1_usize, |count, extent| {
            usize::try_from(extent)
                .ok()
                .filter(|extent| *extent > 0)
                .and_then(|extent| count.checked_mul(extent))
        })
        .context("observation source grid cell count is invalid")?;
    if state.values.len() != expected_cell_count {
        bail!("observation terminal state sample count differs from its grid");
    }
    let mut canonical = Vec::with_capacity(8 + state.values.len() * 24);
    canonical.extend_from_slice(&(state.values.len() as u64).to_be_bytes());
    for value in state.values.iter().flat_map(|value| value.iter()) {
        canonical.extend_from_slice(&value.to_bits().to_be_bytes());
    }
    let actual_magnetization_digest = format!("sha256:{:x}", Sha256::digest(canonical));
    if actual_magnetization_digest != magnetization_digest {
        bail!("observation terminal magnetization differs from its accepted snapshot");
    }
    Ok(())
}

/// Reconstruct the observation runtime for one exact completed study source.
///
/// The accepted-state generation is an optimistic precondition. The loader
/// rejects a different current attempt, an ambiguous or unlisted manifest,
/// missing catalog lineage, missing CAS bytes, and every carrier mismatch
/// before constructing the isolated evaluator.
pub fn load_study_observation_runtime(
    store: &SessionStore,
    expected_source: &fullmag_quantities::AcceptedStateRef,
) -> Result<LoadedStudyObservationRuntime> {
    expected_source
        .validate()
        .map_err(|error| anyhow::anyhow!(error.to_string()))?;
    let run_id = expected_source.id.run_id.as_str();
    let step_id = expected_source
        .id
        .stage_id
        .as_deref()
        .context("study observation source has no stage identity")?;
    let task_id = fullmag_session::task_id_for_study_step(run_id, step_id)?;
    let run_catalog = store
        .read_run_catalog(run_id)?
        .context("study observation source has no durable run catalog")?;
    let task = run_catalog
        .tasks
        .iter()
        .find(|task| task.task_id == task_id)
        .context("study observation source task is absent from the run catalog")?;
    let attempt_id = task
        .attempt_id
        .as_deref()
        .context("study observation source task has no accepted attempt")?;
    let ownership_epoch = task
        .ownership_epoch
        .context("study observation source task has no ownership epoch")?;
    if task.lifecycle != fullmag_session::FmsTaskLifecycle::Succeeded
        || ownership_epoch != expected_source.generation.runtime_epoch
    {
        bail!("study observation source is not the succeeded current attempt");
    }

    let artifact_catalog = store
        .read_artifact_catalog(run_id)?
        .context("study observation source has no artifact catalog")?;
    artifact_catalog.validate()?;
    let mut manifests = artifact_catalog.entries.iter().filter(|entry| {
        entry.artifact_type == "study_output_manifest"
            && entry.task_id == task_id
            && entry.attempt_id == attempt_id
            && entry.ownership_epoch == ownership_epoch
            && entry.status == fullmag_session::FmsArtifactStatus::Published
            && task.artifact_ids.contains(&entry.artifact_id)
    });
    let manifest_artifact = manifests
        .next()
        .context("study observation source has no published manifest")?;
    if manifests.next().is_some() {
        bail!("study observation source manifest is ambiguous");
    }
    let manifest_ref = manifest_artifact
        .object_ref
        .as_deref()
        .context("study observation source manifest has no CAS reference")?;
    if manifest_ref != manifest_artifact.content_sha256 {
        bail!("study observation source manifest digest differs from its CAS reference");
    }
    let manifest_bytes = store
        .cas()
        .get(manifest_ref)?
        .context("study observation source manifest is missing from CAS")?;
    let manifest: fullmag_session::FmsStudyOutputManifest = serde_json::from_slice(&manifest_bytes)
        .context("study observation source manifest is not a typed document")?;
    manifest.validate()?;
    if manifest.run_id != run_id
        || manifest.task_id != task_id
        || manifest.step_id != step_id
        || manifest.attempt_id != attempt_id
        || manifest.ownership_epoch != ownership_epoch
        || manifest.accepted_state_ref.as_ref() != Some(expected_source)
    {
        bail!("study observation source manifest differs from the requested accepted state");
    }
    let descriptor = manifest
        .observation_source
        .context("study observation source manifest has no observation descriptor")?;
    if descriptor.accepted_state_ref != *expected_source {
        bail!("study observation descriptor differs from the requested accepted state");
    }

    for (artifact_id, artifact_type, object_ref) in [
        (
            descriptor.snapshot_artifact_id.as_str(),
            fullmag_session::FMS_OBSERVATION_SNAPSHOT_ARTIFACT_TYPE,
            descriptor.snapshot_object_ref.as_str(),
        ),
        (
            descriptor.state_artifact_id.as_str(),
            fullmag_session::FMS_OBSERVATION_STATE_ARTIFACT_TYPE,
            descriptor.state_object_ref.as_str(),
        ),
    ] {
        let mut matches = artifact_catalog.entries.iter().filter(|entry| {
            entry.artifact_id == artifact_id
                && entry.task_id == task_id
                && entry.attempt_id == attempt_id
                && entry.ownership_epoch == ownership_epoch
                && entry.artifact_type == artifact_type
                && entry.object_ref.as_deref() == Some(object_ref)
                && entry.content_sha256 == object_ref
                && entry.status == fullmag_session::FmsArtifactStatus::Published
                && entry.study_output.is_none()
                && task.artifact_ids.contains(&entry.artifact_id)
        });
        matches
            .next()
            .context("study observation carrier is absent from the artifact catalog")?;
        if matches.next().is_some() {
            bail!("study observation carrier is ambiguous in the artifact catalog");
        }
    }

    let snapshot_bytes = store
        .cas()
        .get(&descriptor.snapshot_object_ref)?
        .context("study observation snapshot is missing from CAS")?;
    let state_bytes = store
        .cas()
        .get(&descriptor.state_object_ref)?
        .context("study observation state is missing from CAS")?;
    ObservationSourcePayload {
        accepted_state_ref: expected_source.clone(),
        snapshot_bytes: snapshot_bytes.clone(),
        state_bytes: state_bytes.clone(),
        grid_cells: descriptor.grid_cells,
    }
    .validate()?;
    let snapshot: fullmag_runner::FdmCpuAcceptedStateSnapshotV1 =
        serde_json::from_slice(&snapshot_bytes)
            .context("study observation snapshot cannot initialize its adapter")?;
    let decoded = fullmag_application::decode_study_artifact_bytes(
        "state",
        &descriptor.state_codec_id,
        &descriptor.state_codec_version,
        &state_bytes,
    )
    .context("study observation state cannot initialize its adapter")?;
    let fullmag_application::DecodedStudyArtifact::MagnetizationState(state) = decoded else {
        bail!("study observation state adapter requires magnetization");
    };
    let runtime = fullmag_runner::ObservationRuntime::from_fdm_cpu_accepted_state(
        expected_source.id.clone(),
        snapshot,
        descriptor.grid_cells,
        state.values,
    )
    .map_err(|error| anyhow::anyhow!(error.to_string()))
    .context("reconstruct isolated study observation runtime")?;
    Ok(LoadedStudyObservationRuntime {
        descriptor,
        runtime,
    })
}

/// Persist study outputs under the task's exact active lease before completion.
///
/// Output ports are taken from the immutable accepted study. Bytes and a
/// versioned typed manifest are stored in CAS, and the session store atomically
/// fences their catalog append against lease release or retry. The worker must
/// publish outputs before it emits its terminal `Completed` event; a repeated
/// exact publication is safe after completion.
pub fn publish_study_outputs(
    store: &SessionStore,
    accepted: &AcceptedStudySnapshot,
    claim: &TaskClaim,
    step_id: &str,
    outputs: &[StudyOutputPayload],
    accepted_state_ref: Option<&fullmag_quantities::AcceptedStateRef>,
    observation_source: Option<&ObservationSourcePayload>,
) -> Result<fullmag_session::FmsArtifactCatalog> {
    publish_study_outputs_internal(store,accepted,claim,step_id,outputs,accepted_state_ref,observation_source,None)
}

pub fn publish_terminal_study_outputs(
    store: &SessionStore, accepted: &AcceptedStudySnapshot, claim: &TaskClaim, step_id: &str,
    outputs: &[StudyOutputPayload], prepared: &crate::PreparedTerminalPublicationV4,
) -> Result<fullmag_session::FmsArtifactCatalog> {
    publish_study_outputs_internal(store,accepted,claim,step_id,outputs,Some(&prepared.manifest.accepted_state_ref),None,Some(prepared))
}

fn publish_study_outputs_internal(
    store: &SessionStore,
    accepted: &AcceptedStudySnapshot,
    claim: &TaskClaim,
    step_id: &str,
    outputs: &[StudyOutputPayload],
    accepted_state_ref: Option<&fullmag_quantities::AcceptedStateRef>,
    observation_source: Option<&ObservationSourcePayload>,
    terminal: Option<&crate::PreparedTerminalPublicationV4>,
) -> Result<fullmag_session::FmsArtifactCatalog> {
    let run_id = accepted.run.specification.run_id.as_str();
    let expected_task_id = fullmag_session::task_id_for_study_step(run_id, step_id)?;
    if claim.run_id.as_str() != run_id || claim.task_id.as_str() != expected_task_id {
        bail!("study output claim does not match the accepted run and step");
    }
    if let Some(reference) = accepted_state_ref {
        reference
            .validate()
            .map_err(|error| anyhow::anyhow!(error.to_string()))?;
        if reference.id.run_id != run_id
            || reference.id.stage_id.as_deref() != Some(step_id)
            || reference.generation.runtime_epoch != claim.ownership_epoch.value()
        {
            bail!("accepted state reference does not match the output publication claim");
        }
    }
    if let Some(source) = observation_source {
        source.validate()?;
        if accepted_state_ref != Some(&source.accepted_state_ref) {
            bail!("observation source differs from the published accepted state reference");
        }
    }
    let step = accepted
        .study
        .steps
        .iter()
        .find(|step| step.step_id == step_id)
        .with_context(|| format!("accepted study has no step `{step_id}`"))?;
    let retained_current = matches!(step.kind, fullmag_authoring::StudyStepKind::RetainedCurrentFieldInspection { .. });
    let _retained_publication = if retained_current {
        if outputs.len() != 1 || accepted_state_ref.is_some() || observation_source.is_some() || terminal.is_some() {
            bail!("retained-current H-only publication requires one Artifact and cannot contain magnetic state");
        }
        // Re-entrant with the worker's publication lease; all parent and child writes share this fence.
        Some(store.write_transaction()?)
    } else { None };
    let run_catalog = store
        .read_run_catalog(run_id)?
        .context("study output publication requires a durable run catalog")?;
    let durable_task = run_catalog
        .tasks
        .iter()
        .find(|task| task.task_id == expected_task_id)
        .context("study output task is missing from the durable run catalog")?;
    if !matches!(
        durable_task.lifecycle,
        fullmag_session::FmsTaskLifecycle::Preparing
            | fullmag_session::FmsTaskLifecycle::Running
            | fullmag_session::FmsTaskLifecycle::Stopping
            | fullmag_session::FmsTaskLifecycle::Succeeded
    ) || durable_task.attempt_id.as_deref() != Some(claim.attempt_id.as_str())
        || durable_task.ownership_epoch != Some(claim.ownership_epoch.value())
        || durable_task.resource_id.as_deref() != Some(claim.lease.resource_id.as_str())
    {
        bail!("study output claim is not the current task owner");
    }

    let durable_lease = store
        .read_resource_lease(
            run_id,
            claim.lease.resource_id.as_str(),
            claim.lease.lease_token.as_str(),
        )?
        .context("study output publication lease is missing")?;
    let expected_kind = match &claim.lease.kind {
        fullmag_application::ResourceKind::Cpu => fullmag_session::FmsResourceKind::Cpu,
        fullmag_application::ResourceKind::Gpu => fullmag_session::FmsResourceKind::Gpu,
        fullmag_application::ResourceKind::Storage => fullmag_session::FmsResourceKind::Storage,
        fullmag_application::ResourceKind::Meshing => fullmag_session::FmsResourceKind::Meshing,
    };
    let expected_budget = fullmag_session::FmsResourceBudget {
        cpu_millis: claim.lease.budget.cpu_millis,
        memory_bytes: claim.lease.budget.memory_bytes,
        gpu_memory_bytes: claim.lease.budget.gpu_memory_bytes,
        storage_bytes: claim.lease.budget.storage_bytes,
    };
    if durable_lease.state != fullmag_session::FmsResourceLeaseState::Active
        || durable_lease.run_id != run_id
        || durable_lease.task_id != expected_task_id
        || durable_lease.attempt_id != claim.attempt_id.as_str()
        || durable_lease.ownership_epoch != claim.ownership_epoch.value()
        || durable_lease.resource_id != claim.lease.resource_id
        || durable_lease.lease_token != claim.lease.lease_token.as_str()
        || durable_lease.heartbeat_sequence < claim.lease.heartbeat_sequence
        || durable_lease.kind != expected_kind
        || durable_lease.budget != expected_budget
    {
        bail!("study output publication lease does not match the active task claim");
    }

    let mut output_identities = std::collections::BTreeSet::new();
    let mut output_port_ids = std::collections::BTreeSet::new();
    for output in outputs {
        if !output_identities.insert((output.port_id.as_str(), output.case_id.as_str())) {
            bail!(
                "study output `{}/{}` was included more than once",
                output.port_id,
                output.case_id
            );
        }
        let declared = step
            .outputs
            .iter()
            .find(|declared| declared.port_id == output.port_id)
            .with_context(|| {
                format!(
                    "step `{step_id}` does not declare output port `{}`",
                    output.port_id
                )
            })?;
        let data_kind = study_port_data_kind_label(&declared.data_kind);
        if retained_current {
            study_retained_current_publication::validate_output_identity(
                &output.codec_id, &output.codec_version, &output.port_id, &output.case_id, data_kind)?;
            let bundle = validate_retained_current_publication_output(store, accepted, claim, step,
                &output.bytes, crate::study_inspection::inspection_bundle_budget(claim)?)?;
            if bundle.manifest().codec_version() != output.codec_version {
                bail!("retained publication codec differs from its typed validated package");
            }
        } else if output.codec_id == fullmag_antenna_artifacts::retained_current::RETAINED_CURRENT_FIELD_CODEC_ID {
            bail!("retained-current H-only codec cannot be published by another study operation");
        } else if output.codec_id==fullmag_application::ANTENNA_INSPECTION_BUNDLE_CODEC_ID {
            if accepted_state_ref.is_some() || observation_source.is_some() || output.port_id!="inspection" || output.case_id!="default" { bail!("inspection output cannot fabricate magnetic state or another case"); }
            let problem=accepted.catalog.entries().iter().find(|entry|entry.step_id()==step_id).context("inspection publication ProblemIR missing")?.problem();
            crate::study_inspection::validate_accepted_inspection_bytes(problem,step,&output.bytes,crate::study_inspection::inspection_bundle_budget(claim)?)?;
        } else if matches!(step.kind, fullmag_authoring::StudyStepKind::ClosedLoopInspection { .. }) { bail!("inspection output requires its single registered bundle codec"); }
        let decoded = fullmag_application::decode_study_artifact_bytes(
            data_kind,
            &output.codec_id,
            &output.codec_version,
            &output.bytes,
        )
        .with_context(|| {
            format!(
                "study output `{}/{}` does not match a supported typed artifact codec",
                output.port_id, output.case_id
            )
        })?;
        if let fullmag_application::DecodedStudyArtifact::FrozenMagnetizationState(artifact) = decoded {
            crate::frozen_stage_lifecycle::validate_terminal_output(store, accepted, claim, step_id, artifact)?;
        }
        fullmag_session::repository_path::validate_store_id(&output.case_id)?;
        fullmag_session::repository_path::validate_store_id(&output.codec_id)?;
        fullmag_session::repository_path::validate_store_id(&output.codec_version)?;
        output_port_ids.insert(output.port_id.as_str());
    }
    for declared in &step.outputs {
        if !output_port_ids.contains(declared.port_id.as_str()) {
            bail!(
                "study output publication omitted declared port `{}`",
                declared.port_id
            );
        }
    }

    if let Some(prepared) = terminal {
        let historical = cold_accepted_worker_step(store,accepted,step_id,&expected_task_id,
            claim.attempt_id.as_str(),claim.ownership_epoch.value())?;
        crate::validate_prepared_terminal_publication(store,&historical,prepared)?;
        let manifest = &prepared.manifest;
        if manifest.outputs.len() != outputs.len() || outputs.iter().any(|output| !manifest.outputs.iter().any(|entry|
            entry.port_id == output.port_id && entry.case_id == output.case_id && entry.codec_id == output.codec_id
            && entry.codec_version == output.codec_version && entry.object_ref == fullmag_session::hex_sha256(&output.bytes))) {
            bail!("prepared terminal output bindings differ from the immutable completed receipt");
        }
        let catalog = store.append_artifact_catalog_entries_for_lease(&durable_lease,&prepared.entries)?;
        crate::solution_set::publish_open_study_solution(store,accepted,claim,step_id,&catalog)?;
        return Ok(catalog);
    }

    // Validate the complete declared output set before pinning any CAS object.
    let mut entries = Vec::with_capacity(outputs.len() + 3);
    let mut manifest_outputs = Vec::with_capacity(outputs.len());
    for output in outputs {
        let declared = step
            .outputs
            .iter()
            .find(|declared| declared.port_id == output.port_id)
            .with_context(|| {
                format!(
                    "step `{step_id}` does not declare output port `{}`",
                    output.port_id
                )
            })?;
        let object_ref = store.cas().put(&output.bytes)?;
        let study_output = fullmag_session::FmsStudyArtifactOutput {
            step_id: step_id.to_owned(),
            port_id: output.port_id.clone(),
            case_id: output.case_id.clone(),
        };
        let data_kind = study_port_data_kind_label(&declared.data_kind);
        let artifact_id = format!(
            "artifact-{}",
            fullmag_session::canonical_json_sha256(&serde_json::json!({
                "run_id": run_id,
                "task_id": expected_task_id,
                "attempt_id": claim.attempt_id.as_str(),
                "ownership_epoch": claim.ownership_epoch.value(),
                "logical_output": &study_output,
                "data_kind": data_kind,
                "codec_id": output.codec_id,
                "codec_version": output.codec_version,
                "object_ref": object_ref,
            }))
        );
        manifest_outputs.push(fullmag_session::FmsStudyOutputManifestEntry {
            port_id: output.port_id.clone(),
            case_id: output.case_id.clone(),
            data_kind: data_kind.into(),
            codec_id: output.codec_id.clone(),
            codec_version: output.codec_version.clone(),
            artifact_id: artifact_id.clone(),
            object_ref: object_ref.clone(),
            content_sha256: object_ref.clone(),
        });
        entries.push(fullmag_session::FmsArtifactCatalogEntry {
            artifact_id,
            task_id: expected_task_id.clone(),
            attempt_id: claim.attempt_id.as_str().to_owned(),
            ownership_epoch: claim.ownership_epoch.value(),
            logical_path: format!(
                "outputs/{expected_task_id}/{}/{}/{}/output.bin",
                claim.attempt_id.as_str(),
                output.port_id,
                output.case_id
            ),
            artifact_type: data_kind.into(),
            content_sha256: object_ref.clone(),
            object_ref: Some(object_ref),
            status: fullmag_session::FmsArtifactStatus::Published,
            required: true,
            study_output: Some(study_output),
        });
    }

    manifest_outputs.sort_by(|left, right| {
        (&left.port_id, &left.case_id).cmp(&(&right.port_id, &right.case_id))
    });
    let observation_source = if let Some(source) = observation_source {
        let snapshot_object_ref = store.cas().put(&source.snapshot_bytes)?;
        let state_object_ref = store.cas().put(&source.state_bytes)?;
        let snapshot_artifact_id = format!(
            "artifact-{}",
            fullmag_session::canonical_json_sha256(&serde_json::json!({
                "run_id": run_id,
                "task_id": expected_task_id,
                "attempt_id": claim.attempt_id.as_str(),
                "ownership_epoch": claim.ownership_epoch.value(),
                "artifact_type": fullmag_session::FMS_OBSERVATION_SNAPSHOT_ARTIFACT_TYPE,
                "object_ref": snapshot_object_ref,
            }))
        );
        let state_artifact_id = format!(
            "artifact-{}",
            fullmag_session::canonical_json_sha256(&serde_json::json!({
                "run_id": run_id,
                "task_id": expected_task_id,
                "attempt_id": claim.attempt_id.as_str(),
                "ownership_epoch": claim.ownership_epoch.value(),
                "artifact_type": fullmag_session::FMS_OBSERVATION_STATE_ARTIFACT_TYPE,
                "object_ref": state_object_ref,
            }))
        );
        entries.push(fullmag_session::FmsArtifactCatalogEntry {
            artifact_id: snapshot_artifact_id.clone(),
            task_id: expected_task_id.clone(),
            attempt_id: claim.attempt_id.as_str().to_owned(),
            ownership_epoch: claim.ownership_epoch.value(),
            logical_path: format!(
                "outputs/{expected_task_id}/{}/observation/accepted-state-snapshot.v1.json",
                claim.attempt_id.as_str()
            ),
            artifact_type: fullmag_session::FMS_OBSERVATION_SNAPSHOT_ARTIFACT_TYPE.into(),
            content_sha256: snapshot_object_ref.clone(),
            object_ref: Some(snapshot_object_ref.clone()),
            status: fullmag_session::FmsArtifactStatus::Published,
            required: true,
            study_output: None,
        });
        entries.push(fullmag_session::FmsArtifactCatalogEntry {
            artifact_id: state_artifact_id.clone(),
            task_id: expected_task_id.clone(),
            attempt_id: claim.attempt_id.as_str().to_owned(),
            ownership_epoch: claim.ownership_epoch.value(),
            logical_path: format!(
                "outputs/{expected_task_id}/{}/observation/magnetization-state.v1.json",
                claim.attempt_id.as_str()
            ),
            artifact_type: fullmag_session::FMS_OBSERVATION_STATE_ARTIFACT_TYPE.into(),
            content_sha256: state_object_ref.clone(),
            object_ref: Some(state_object_ref.clone()),
            status: fullmag_session::FmsArtifactStatus::Published,
            required: true,
            study_output: None,
        });
        Some(fullmag_session::FmsObservationSourceDescriptor {
            schema_version: fullmag_session::FMS_OBSERVATION_SOURCE_SCHEMA.into(),
            adapter_id: fullmag_session::FMS_FDM_CPU_OBSERVATION_ADAPTER_ID.into(),
            accepted_state_ref: source.accepted_state_ref.clone(),
            snapshot_schema_version: fullmag_session::FMS_FDM_CPU_ACCEPTED_STATE_SNAPSHOT_SCHEMA
                .into(),
            snapshot_artifact_id,
            snapshot_object_ref,
            state_codec_id: fullmag_application::STUDY_MAGNETIZATION_CODEC_ID.into(),
            state_codec_version: fullmag_application::STUDY_MAGNETIZATION_CODEC_VERSION.into(),
            state_artifact_id,
            state_object_ref,
            grid_cells: source.grid_cells,
            quantity_ids: vec!["m".into()],
        })
    } else {
        None
    };
    let manifest = fullmag_session::FmsStudyOutputManifest {
        schema_version: fullmag_session::FMS_STUDY_OUTPUT_MANIFEST_SCHEMA.into(),
        run_id: run_id.into(),
        task_id: expected_task_id.clone(),
        step_id: step_id.into(),
        attempt_id: claim.attempt_id.as_str().into(),
        ownership_epoch: claim.ownership_epoch.value(),
        accepted_state_ref: accepted_state_ref.cloned(),
        observation_source,
        outputs: manifest_outputs,
    };
    manifest.validate()?;
    let manifest_bytes = serde_json::to_vec(&manifest)?;
    let manifest_object_ref = store.cas().put(&manifest_bytes)?;
    let manifest_artifact_id = format!(
        "artifact-{}",
        fullmag_session::canonical_json_sha256(&serde_json::json!({
            "run_id": run_id,
            "task_id": expected_task_id,
            "attempt_id": claim.attempt_id.as_str(),
            "ownership_epoch": claim.ownership_epoch.value(),
            "manifest_schema": fullmag_session::FMS_STUDY_OUTPUT_MANIFEST_SCHEMA,
            "object_ref": manifest_object_ref,
        }))
    );
    entries.push(fullmag_session::FmsArtifactCatalogEntry {
        artifact_id: manifest_artifact_id,
        task_id: expected_task_id.clone(),
        attempt_id: claim.attempt_id.as_str().to_owned(),
        ownership_epoch: claim.ownership_epoch.value(),
        logical_path: format!(
            "outputs/{expected_task_id}/{}/study-output-manifest.v3.json",
            claim.attempt_id.as_str()
        ),
        artifact_type: "study_output_manifest".into(),
        content_sha256: manifest_object_ref.clone(),
        object_ref: Some(manifest_object_ref),
        status: fullmag_session::FmsArtifactStatus::Published,
        required: true,
        study_output: None,
    });
    let catalog = store.append_artifact_catalog_entries_for_lease(&durable_lease, &entries)?;
    crate::solution_set::publish_open_study_solution(store, accepted, claim, step_id, &catalog)?;
    Ok(catalog)
}

pub(crate) fn study_port_data_kind_label(kind: &StudyPortDataKind) -> &'static str {
    match kind {
        StudyPortDataKind::InitialState => "initial_state",
        StudyPortDataKind::State => "state",
        StudyPortDataKind::Field => "field",
        StudyPortDataKind::Scalar => "scalar",
        StudyPortDataKind::Table => "table",
        StudyPortDataKind::Mesh => "mesh",
        StudyPortDataKind::Operator => "operator",
        StudyPortDataKind::Artifact => "artifact",
        StudyPortDataKind::RunRecord => "run_record",
    }
}

/// Do not persist a successful coordinator transition for an accepted study
/// until the current attempt has published a complete, verified manifest.
pub fn validate_study_task_completion(store: &SessionStore, claim: &TaskClaim) -> Result<()> {
    let run_id = claim.run_id.as_str();
    let Some(intent) = store.read_run_intent(run_id)? else {
        // Historical/non-study coordinator streams do not carry an accepted
        // StudyPlan and retain their existing completion contract.
        return Ok(());
    };
    if intent.study_object_ref.is_none() {
        return Ok(());
    }
    let specification: RunSpecification = serde_json::from_value(intent.specification.clone())
        .context("accepted study completion has an invalid RunSpec")?;
    if specification.run_id != claim.run_id {
        bail!("accepted study completion claim belongs to another run");
    }
    let accepted = load_accepted_study_snapshot(
        store,
        &specification.run_id,
        &specification.snapshot.project_id,
    )?;
    if accepted.run.intent != intent {
        bail!("accepted run intent changed while loading the study completion snapshot");
    }
    validate_study_task_completion_for_snapshot(store, claim, &accepted)
}

/// Validate completion against an already fully validated accepted snapshot.
/// The fresh immutable intent fence is checked while the caller holds the
/// store writer or shared read transaction; all catalog, artifact and CAS checks
/// remain here. A shared transaction excludes writers for the entire cold read.
pub(crate) fn validate_study_task_completion_for_snapshot(
    store: &SessionStore,
    claim: &TaskClaim,
    accepted: &AcceptedStudySnapshot,
) -> Result<()> {
    let retained_current = accepted.study.steps.iter().any(|step|
        matches!(step.kind, fullmag_authoring::StudyStepKind::RetainedCurrentFieldInspection { .. })
            && fullmag_session::task_id_for_study_step(claim.run_id.as_str(), &step.step_id)
                .is_ok_and(|task_id| task_id == claim.task_id.as_str()));
    // Validation-only callers may already own EX. Keep H-only's entire completion
    // under a real re-entrant writer fence; shared cold readers use the custom callback below.
    let _retained_completion = if retained_current { Some(store.write_transaction()?) } else { None };
    read_study_task_completion_for_snapshot(store, claim, accepted, false).map(|_| ())
}

/// Immutable readers are released only after every completion fence succeeds.
/// Fields stay private so callers cannot manufacture a verified completion.
pub(crate) struct VerifiedStudyCompletion<T = Option<fullmag_runner::LoadedAntennaClosedLoopInspection>> {
    inspections: Vec<(String, usize, T)>,
}

impl<T> VerifiedStudyCompletion<T> {
    pub(crate) fn into_inspection(self, expected_object: &str)
        -> Result<(usize, T)> {
        let mut inspections = self.inspections.into_iter();
        let (object, byte_count, loaded) = inspections.next().context("completion has no verified inspection")?;
        if inspections.next().is_some() || object != expected_object {
            bail!("inspection public CAS object differs from verified completion");
        }
        Ok((byte_count, loaded))
    }
}

/// Validation-only H-only calls require the writer fence owned by the wrapper above.
/// SH cold readers must use `read_study_task_completion_with_inspection` and their own decoder.
pub(crate) fn read_study_task_completion_for_snapshot(
    store: &SessionStore,
    claim: &TaskClaim,
    accepted: &AcceptedStudySnapshot,
    retain_inspection: bool,
) -> Result<VerifiedStudyCompletion> {
    read_study_task_completion_with_inspection(store, claim, accepted, |problem, step, bytes, maximum| {
        if matches!(step.kind, fullmag_authoring::StudyStepKind::RetainedCurrentFieldInspection { .. }) {
            // The validation-only wrapper owns EX; never acquire SH under its writer fence.
            validate_retained_current_publication_output(store, accepted, claim, step, bytes, maximum)?;
            return Ok(None);
        }
        if retain_inspection {
            crate::study_inspection::load_accepted_inspection_bytes(problem, step, bytes, maximum).map(Some)
        } else {
            crate::study_inspection::validate_accepted_inspection_bytes(problem, step, bytes, maximum)?;
            Ok(None)
        }
    })
}

/// Publication/tensor owners already hold EX; use the same canonical parent/content gate without SH.
pub(crate) fn validate_retained_current_publication_output(
    store: &SessionStore, accepted: &AcceptedStudySnapshot, claim: &TaskClaim,
    step: &StudyStep, bytes: &[u8], maximum: usize,
) -> Result<fullmag_antenna_artifacts::retained_current::RetainedCurrentFieldBundleAny> {
    if accepted.lowered.steps.iter().any(|entry| entry.step_id == step.step_id
        && matches!(entry.execution_plan.as_ref().map(|plan| &plan.backend_plan),
            Some(fullmag_ir::BackendPlanIR::AntennaRetainedDirectFieldInspection(_)))) {
        return study_retained_current_publication::validate_direct_output(store, accepted, claim, step, bytes, maximum, true);
    }
    if accepted.lowered.steps.iter().any(|entry| entry.step_id == step.step_id
        && matches!(entry.execution_plan.as_ref().map(|plan| &plan.backend_plan),
            Some(fullmag_ir::BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)))) {
        study_retained_current_publication::validate_retained_preparation_field_publication_output(store, accepted, claim, step, bytes, maximum)
    } else {
        study_retained_current_publication::validate_output(store, accepted, claim, step, bytes, maximum, true)
    }.map(fullmag_antenna_artifacts::retained_current::RetainedCurrentFieldBundleAny::SurfaceV1)
}

/// Child cold readers may retain this result; it never passes through the full V/J/H source decoder.
/// Caller must keep its existing shared snapshot while validating the surrounding completion fences.
pub(crate) fn validate_retained_current_completion_output(
    store: &SessionStore, accepted: &AcceptedStudySnapshot, claim: &TaskClaim,
    step: &StudyStep, bytes: &[u8], maximum: usize,
) -> Result<fullmag_antenna_artifacts::retained_current::RetainedCurrentFieldBundleAny> {
    if accepted.lowered.steps.iter().any(|entry| entry.step_id == step.step_id
        && matches!(entry.execution_plan.as_ref().map(|plan| &plan.backend_plan),
            Some(fullmag_ir::BackendPlanIR::AntennaRetainedDirectFieldInspection(_)))) {
        return study_retained_current_publication::validate_direct_output(store, accepted, claim, step, bytes, maximum, false);
    }
    if accepted.lowered.steps.iter().any(|entry| entry.step_id == step.step_id
        && matches!(entry.execution_plan.as_ref().map(|plan| &plan.backend_plan),
            Some(fullmag_ir::BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)))) {
        study_retained_current_publication::validate_retained_preparation_field_completion_output(store, accepted, claim, step, bytes, maximum)
    } else {
        study_retained_current_publication::validate_output(store, accepted, claim, step, bytes, maximum, false)
    }.map(fullmag_antenna_artifacts::retained_current::RetainedCurrentFieldBundleAny::SurfaceV1)
}

/// The callback owns physical decoding; its private result cannot escape before
/// all original terminal, catalog and typed artifact fences have succeeded.
pub(crate) fn read_study_task_completion_with_inspection<T>(
    store: &SessionStore,
    claim: &TaskClaim,
    accepted: &AcceptedStudySnapshot,
    mut decode_inspection: impl FnMut(&fullmag_ir::ProblemIR, &StudyStep, &[u8], usize) -> Result<T>,
) -> Result<VerifiedStudyCompletion<T>> {
    let mut inspections = Vec::new();
    let run_id = claim.run_id.as_str();
    let current_intent = store.read_run_intent(run_id)?;
    if current_intent.as_ref() != Some(&accepted.run.intent) {
        bail!("accepted run intent changed during study completion validation");
    }
    if accepted.run.intent.run_id != run_id
        || accepted.run.specification.run_id != claim.run_id
    {
        bail!("accepted study completion claim belongs to another run");
    }
    if accepted.run.intent.study_object_ref.is_none() {
        bail!("study completion snapshot has no immutable study object");
    }

    let mut source_step = None;
    for step in &accepted.study.steps {
        if fullmag_session::task_id_for_study_step(run_id, &step.step_id)? == claim.task_id.as_str()
        {
            source_step = Some(step);
            break;
        }
    }
    let source_step =
        source_step.context("completed study task is not a step in the accepted plan")?;
    let retained_current = matches!(source_step.kind,
        fullmag_authoring::StudyStepKind::RetainedCurrentFieldInspection { .. });
    let run_catalog = store
        .read_run_catalog(run_id)?
        .context("study completion requires a durable run catalog")?;
    let task = run_catalog
        .tasks
        .iter()
        .find(|task| task.task_id == claim.task_id.as_str())
        .context("study completion task is missing from the run catalog")?;
    if task.attempt_id.as_deref() != Some(claim.attempt_id.as_str())
        || task.ownership_epoch != Some(claim.ownership_epoch.value())
    {
        bail!("study completion claim does not match the current attempt and epoch");
    }

    let artifact_catalog = store
        .read_artifact_catalog(run_id)?
        .context("study completion requires a durable artifact catalog")?;
    artifact_catalog
        .validate()
        .context("study completion artifact catalog is invalid")?;
    let task_id = claim.task_id.as_str();
    let attempt_id = claim.attempt_id.as_str();
    let ownership_epoch = claim.ownership_epoch.value();
    let mut manifests = artifact_catalog.entries.iter().filter(|entry| {
        entry.artifact_type == "study_output_manifest"
            && entry.task_id == task_id
            && entry.attempt_id == attempt_id
            && entry.ownership_epoch == ownership_epoch
    });
    let manifest_artifact = manifests
        .next()
        .context("study completion requires one output manifest for the current attempt")?;
    if manifests.next().is_some()
        || manifest_artifact.status != fullmag_session::FmsArtifactStatus::Published
    {
        bail!("study completion output manifest is ambiguous or unpublished");
    }
    let manifest_ref = manifest_artifact
        .object_ref
        .as_deref()
        .context("study completion output manifest has no CAS reference")?;
    if manifest_ref != manifest_artifact.content_sha256 {
        bail!("study completion manifest digest differs from its CAS reference");
    }
    let manifest_bytes = store
        .cas()
        .get_bounded(manifest_ref, fullmag_session::MAX_TERMINAL_CATALOG_METADATA_BYTES)?
        .with_context(|| format!("study completion manifest `{manifest_ref}` is missing"))?;
    crate::study_output_history::open_published_terminal_manifest(store,&accepted,claim,&source_step.step_id,
        &manifest_bytes,manifest_artifact,&artifact_catalog)?;
    let manifest = crate::study_output_history::read_manifest_projection(&manifest_bytes)
        .context("study completion manifest is not a typed document")?;
    if manifest.run_id != run_id
        || manifest.task_id != task_id
        || manifest.step_id != source_step.step_id
        || manifest.attempt_id != attempt_id
        || manifest.ownership_epoch != ownership_epoch
    {
        bail!("study completion manifest identity differs from its accepted attempt");
    }
    if let Some(source) = &manifest.observation_source {
        let find_source_artifact = |artifact_id: &str,
                                    artifact_type: &str,
                                    object_ref: &str|
         -> Result<&fullmag_session::FmsArtifactCatalogEntry> {
            let mut matches = artifact_catalog.entries.iter().filter(|entry| {
                entry.artifact_id == artifact_id
                    && entry.task_id == task_id
                    && entry.attempt_id == attempt_id
                    && entry.ownership_epoch == ownership_epoch
                    && entry.artifact_type == artifact_type
                    && entry.object_ref.as_deref() == Some(object_ref)
                    && entry.content_sha256 == object_ref
                    && entry.status == fullmag_session::FmsArtifactStatus::Published
                    && entry.study_output.is_none()
            });
            let artifact = matches
                .next()
                .context("observation source artifact is absent from the catalog")?;
            if matches.next().is_some() {
                bail!("observation source artifact is ambiguous in the catalog");
            }
            Ok(artifact)
        };
        find_source_artifact(
            &source.snapshot_artifact_id,
            fullmag_session::FMS_OBSERVATION_SNAPSHOT_ARTIFACT_TYPE,
            &source.snapshot_object_ref,
        )?;
        find_source_artifact(
            &source.state_artifact_id,
            fullmag_session::FMS_OBSERVATION_STATE_ARTIFACT_TYPE,
            &source.state_object_ref,
        )?;
        let snapshot_bytes = store
            .cas()
            .get(&source.snapshot_object_ref)?
            .context("observation source snapshot CAS object is missing")?;
        let state_bytes = store
            .cas()
            .get(&source.state_object_ref)?
            .context("observation source state CAS object is missing")?;
        ObservationSourcePayload {
            accepted_state_ref: source.accepted_state_ref.clone(),
            snapshot_bytes,
            state_bytes,
            grid_cells: source.grid_cells,
        }
        .validate()?;
    }

    for declared in &source_step.outputs {
        if !manifest
            .outputs
            .iter()
            .any(|output| output.port_id == declared.port_id)
        {
            bail!(
                "study completion manifest omitted declared port `{}`",
                declared.port_id
            );
        }
    }
    for output in &manifest.outputs {
        let declared = source_step
            .outputs
            .iter()
            .find(|port| port.port_id == output.port_id)
            .with_context(|| {
                format!(
                    "study completion manifest has undeclared port `{}`",
                    output.port_id
                )
            })?;
        let data_kind = study_port_data_kind_label(&declared.data_kind);
        if output.data_kind != data_kind {
            bail!(
                "study completion data kind differs for port `{}`",
                output.port_id
            );
        }
        let identity = fullmag_session::FmsStudyArtifactOutput {
            step_id: source_step.step_id.clone(),
            port_id: output.port_id.clone(),
            case_id: output.case_id.clone(),
        };
        let mut artifacts = artifact_catalog.entries.iter().filter(|entry| {
            entry.artifact_id == output.artifact_id
                && entry.task_id == task_id
                && entry.attempt_id == attempt_id
                && entry.ownership_epoch == ownership_epoch
                && entry.study_output.as_ref() == Some(&identity)
        });
        let artifact = artifacts.next().with_context(|| {
            format!(
                "study completion output `{}/{}` is absent from the artifact catalog",
                output.port_id, output.case_id
            )
        })?;
        if artifacts.next().is_some()
            || artifact.status != fullmag_session::FmsArtifactStatus::Published
            || artifact.artifact_type != data_kind
            || artifact.object_ref.as_deref() != Some(output.object_ref.as_str())
            || artifact.content_sha256 != output.content_sha256
            || output.object_ref != output.content_sha256
        {
            bail!("study completion manifest entry differs from its published artifact");
        }
        let inspection=retained_current || matches!(source_step.kind,fullmag_authoring::StudyStepKind::ClosedLoopInspection { .. });
        let maximum=if inspection { Some(crate::study_inspection::inspection_bundle_budget(claim)?) } else {None};
        let output_bytes = if let Some(maximum)=maximum {
            store.cas().get_bounded(&output.object_ref,maximum as u64)?
        } else { store.cas().get(&output.object_ref)? }.with_context(|| {
            format!(
                "study completion output `{}` CAS object is missing",
                output.artifact_id
            )
        })?;
        if let Some(maximum)=maximum {
            if manifest.accepted_state_ref.is_some() || manifest.observation_source.is_some() {
                bail!("inspection completion cannot accept solver outputs or state");
            }
            if retained_current {
                if manifest.outputs.len() != 1 || source_step.outputs.len() != 1 {
                    bail!("retained-current completion requires exactly one output");
                }
                study_retained_current_publication::validate_output_identity(&output.codec_id,
                    &output.codec_version, &output.port_id, &output.case_id, &output.data_kind)?;
                let direct = accepted.lowered.steps.iter().any(|entry| entry.step_id == source_step.step_id
                    && matches!(entry.execution_plan.as_ref().map(|plan| &plan.backend_plan),
                        Some(fullmag_ir::BackendPlanIR::AntennaRetainedDirectFieldInspection(_))));
                if output.codec_version != if direct { "v2" } else { "v1" } {
                    bail!("retained completion codec differs from accepted typed operation");
                }
            } else if output.codec_id!=fullmag_application::ANTENNA_INSPECTION_BUNDLE_CODEC_ID
                || output.codec_version!=fullmag_application::ANTENNA_INSPECTION_BUNDLE_CODEC_VERSION
                || output.case_id!="default" {
                bail!("inspection completion cannot accept another codec or case");
            }
            let problem=accepted.catalog.entries().iter().find(|entry|entry.step_id()==source_step.step_id).context("inspection completion ProblemIR missing")?.problem();
            let loaded = decode_inspection(problem, source_step, &output_bytes, maximum)?;
            inspections.push((output.object_ref.clone(), output_bytes.len(), loaded));
        }
        if !retained_current && output.codec_id == fullmag_antenna_artifacts::retained_current::RETAINED_CURRENT_FIELD_CODEC_ID {
            bail!("retained-current H-only completion codec belongs to another operation");
        }
        let resolved_artifact = fullmag_application::ResolvedStudyArtifact {
            artifact_id: output.artifact_id.clone(),
            object_ref: output.object_ref.clone(),
            data_kind: output.data_kind.clone(),
            codec_id: output.codec_id.clone(),
            codec_version: output.codec_version.clone(),
        };
        fullmag_application::decode_study_artifact(&resolved_artifact, &output_bytes)
            .map_err(|error| anyhow::anyhow!(error.to_string()))
            .with_context(|| {
                format!(
                    "study completion output `{}` failed typed decoding",
                    output.artifact_id
                )
            })?;
    }
    for artifact in &artifact_catalog.entries {
        let Some(identity) = &artifact.study_output else {
            continue;
        };
        if artifact.task_id == task_id
            && artifact.attempt_id == attempt_id
            && artifact.ownership_epoch == ownership_epoch
            && identity.step_id == source_step.step_id
            && !manifest.outputs.iter().any(|output| {
                output.artifact_id == artifact.artifact_id
                    && output.port_id == identity.port_id
                    && output.case_id == identity.case_id
            })
        {
            bail!("study completion found an output artifact outside its manifest allow-list");
        }
    }
    // Reserved terminal observables are evaluated by the admitted worker,
    // not a declared Study port. They must still bind to this exact manifest
    // state before the task can cross its completion barrier.
    let mut quantity_bundles = artifact_catalog.entries.iter().filter(|entry| {
        entry.task_id == task_id && entry.attempt_id == attempt_id
            && entry.ownership_epoch == ownership_epoch
            && entry.artifact_type == "accepted_quantity_bundle"
    });
    if let Some(artifact) = quantity_bundles.next() {
        if quantity_bundles.next().is_some() || artifact.study_output.is_some()
            || artifact.status != fullmag_session::FmsArtifactStatus::Published
            || artifact.object_ref.as_deref() != Some(artifact.content_sha256.as_str()) {
            bail!("accepted quantity bundle artifact is ambiguous or unbound");
        }
        let bytes = store.cas().get(&artifact.content_sha256)?
            .context("accepted quantity bundle is missing from CAS")?;
        if fullmag_application::study_artifact_content_sha256(&bytes) != artifact.content_sha256 {
            bail!("accepted quantity bundle CAS digest differs");
        }
        let record: serde_json::Value = serde_json::from_slice(&bytes)?;
        let source: fullmag_quantities::AcceptedStateRef = serde_json::from_value(
            record.get("source").cloned().context("accepted quantity source missing")?)?;
        source.validate().map_err(|error| anyhow::anyhow!(error.to_string()))?;
        if record.get("schema_version").and_then(serde_json::Value::as_str) != Some("accepted_quantity_bundle.v1")
            || manifest.accepted_state_ref.as_ref() != Some(&source)
            || !manifest.outputs.iter().any(|output| output.data_kind == "state"
                && Some(output.object_ref.as_str()) == record.get("state_object_ref").and_then(serde_json::Value::as_str)) {
            bail!("accepted quantity bundle differs from its manifest state");
        }
        let has_batch = record.get("batch").is_some_and(|value| !value.is_null());
        let has_error = record.get("error").and_then(serde_json::Value::as_str)
            .is_some_and(|value| !value.is_empty());
        if has_batch == has_error { bail!("accepted quantity bundle outcome invalid"); }
        if has_batch {
            let batch: fullmag_runner::AcceptedMaterializationBatch = serde_json::from_value(record["batch"].clone())?;
            batch.clock.validate().map_err(|error| anyhow::anyhow!(error.to_string()))?;
            if batch.source != source || batch.clock.accepted_step != source.id.accepted_step
                || batch.clock.digest().map_err(|error| anyhow::anyhow!(error.to_string()))? != source.id.clock_digest
                || Some(batch.magnetization_content_sha256.as_str()) != record.get("state_object_ref").and_then(serde_json::Value::as_str)
                || batch.plan_sha256.trim_start_matches("sha256:") != source.id.plan_digest.trim_start_matches("sha256:") {
                bail!("accepted quantity result source differs");
            }
        }
    }
    for artifact in artifact_catalog.entries.iter().filter(|entry| {
        entry.task_id == task_id
            && entry.attempt_id == attempt_id
            && entry.ownership_epoch == ownership_epoch
            && matches!(
                entry.artifact_type.as_str(),
                fullmag_session::FMS_OBSERVATION_SNAPSHOT_ARTIFACT_TYPE
                    | fullmag_session::FMS_OBSERVATION_STATE_ARTIFACT_TYPE
            )
    }) {
        let listed = manifest.observation_source.as_ref().is_some_and(|source| {
            (artifact.artifact_id == source.snapshot_artifact_id
                && artifact.object_ref.as_deref() == Some(source.snapshot_object_ref.as_str()))
                || (artifact.artifact_id == source.state_artifact_id
                    && artifact.object_ref.as_deref() == Some(source.state_object_ref.as_str()))
        });
        if !listed {
            bail!("study completion found an observation artifact outside its manifest allow-list");
        }
    }
    Ok(VerifiedStudyCompletion { inspections })
}

/// Bind the accepted StepOutput identity to the manifest and immutable bytes
/// exposed at the worker boundary. A catalog entry without its exact manifest
/// remains archival and cannot be dispatched as a new study dependency.
fn bind_step_output_manifests(
    store: &SessionStore,
    run_id: &str,
    accepted_steps: &[StudyStep],
    input_ports: &[StudyInputPort],
    resolved_inputs: &mut std::collections::BTreeMap<String, ResolvedInput>,
    catalog: &fullmag_session::FmsRunCatalog,
    artifact_catalog: Option<&fullmag_session::FmsArtifactCatalog>,
) -> Result<()> {
    let Some(artifact_catalog) = artifact_catalog else {
        if input_ports.iter().any(|port| {
            matches!(&port.source, StudyInputSource::StepOutput { .. })
                && resolved_inputs.contains_key(&port.port_id)
        }) {
            bail!("StepOutput dispatch requires a durable artifact catalog");
        }
        return Ok(());
    };
    artifact_catalog
        .validate()
        .context("accepted run artifact catalog is invalid before manifest binding")?;
    if artifact_catalog.run_id != run_id {
        bail!("study input artifact catalog belongs to another run");
    }

    for input in input_ports {
        let StudyInputSource::StepOutput {
            step_id,
            port: output_port,
            case_id,
        } = &input.source
        else {
            continue;
        };
        let Some(resolved) = resolved_inputs.get_mut(&input.port_id) else {
            continue;
        };

        let dependency_task_id = fullmag_session::task_id_for_study_step(run_id, step_id)?;
        let dependency = catalog
            .tasks
            .iter()
            .find(|task| task.task_id == dependency_task_id)
            .with_context(|| {
                format!("StepOutput dependency task `{dependency_task_id}` is missing")
            })?;
        if dependency.lifecycle != fullmag_session::FmsTaskLifecycle::Succeeded {
            bail!("StepOutput dependency `{step_id}` is not successful");
        }
        let attempt_id = dependency
            .attempt_id
            .as_deref()
            .context("successful StepOutput dependency has no attempt identity")?;
        let ownership_epoch = dependency
            .ownership_epoch
            .context("successful StepOutput dependency has no ownership epoch")?;

        let source_step = accepted_steps
            .iter()
            .find(|step| step.step_id == *step_id)
            .with_context(|| format!("accepted StepOutput source step `{step_id}` is missing"))?;
        let declared_output = source_step
            .outputs
            .iter()
            .find(|port| port.port_id == *output_port)
            .with_context(|| {
                format!("accepted source step `{step_id}` does not declare output `{output_port}`")
            })?;
        if declared_output.data_kind != input.data_kind {
            bail!(
                "StepOutput input `{}` data kind differs from its accepted source",
                input.port_id
            );
        }

        let mut manifest_artifacts = artifact_catalog.entries.iter().filter(|entry| {
            entry.artifact_type == "study_output_manifest"
                && entry.task_id == dependency_task_id
                && entry.attempt_id == attempt_id
                && entry.ownership_epoch == ownership_epoch
        });
        let manifest_artifact = manifest_artifacts
            .next()
            .with_context(|| format!("successful step `{step_id}` has no output manifest"))?;
        if manifest_artifacts.next().is_some() {
            bail!("successful step `{step_id}` has ambiguous output manifests");
        }
        if manifest_artifact.status != fullmag_session::FmsArtifactStatus::Published {
            bail!("successful step `{step_id}` output manifest is not published");
        }
        let manifest_ref = manifest_artifact
            .object_ref
            .as_deref()
            .context("published study output manifest has no CAS reference")?;
        if manifest_ref != manifest_artifact.content_sha256 {
            bail!("study output manifest catalog digest differs from its CAS reference");
        }
        let manifest_bytes = store
            .cas()
            .get_bounded(manifest_ref,fullmag_session::MAX_TERMINAL_CATALOG_METADATA_BYTES)?
            .with_context(|| format!("study output manifest `{manifest_ref}` is missing"))?;
        let manifest = crate::study_output_history::read_manifest_projection(&manifest_bytes)
            .context("study output manifest is not a supported typed document")?;
        if serde_json::from_slice::<serde_json::Value>(&manifest_bytes)?.get("schema_version").and_then(serde_json::Value::as_str)
            == Some(fullmag_session::FMS_STUDY_OUTPUT_MANIFEST_SCHEMA_V4) {
            let reference = manifest.accepted_state_ref.as_ref().context("terminal dependency has no accepted source")?;
            crate::load_study_observation_runtime_v2(store,reference)?;
        }
        if manifest.run_id != run_id
            || manifest.task_id != dependency_task_id
            || manifest.step_id != *step_id
            || manifest.attempt_id != attempt_id
            || manifest.ownership_epoch != ownership_epoch
        {
            bail!("study output manifest identity differs from the current successful attempt");
        }

        // Validate the complete manifest against the immutable output
        // declarations and the matching catalog rows, not just the requested
        // port. This prevents a partial or fabricated manifest from opening a
        // worker dispatch path.
        for declared in &source_step.outputs {
            if !manifest
                .outputs
                .iter()
                .any(|entry| entry.port_id == declared.port_id)
            {
                bail!(
                    "study output manifest omitted declared port `{}`",
                    declared.port_id
                );
            }
        }
        for output in &manifest.outputs {
            let declared = source_step
                .outputs
                .iter()
                .find(|port| port.port_id == output.port_id)
                .with_context(|| {
                    format!(
                        "study output manifest contains undeclared port `{}`",
                        output.port_id
                    )
                })?;
            let data_kind = study_port_data_kind_label(&declared.data_kind);
            if output.data_kind != data_kind {
                bail!(
                    "study output manifest data kind differs for port `{}`",
                    output.port_id
                );
            }
            let expected_identity = fullmag_session::FmsStudyArtifactOutput {
                step_id: step_id.clone(),
                port_id: output.port_id.clone(),
                case_id: output.case_id.clone(),
            };
            let mut matching_artifacts = artifact_catalog.entries.iter().filter(|entry| {
                entry.artifact_id == output.artifact_id
                    && entry.task_id == dependency_task_id
                    && entry.attempt_id == attempt_id
                    && entry.ownership_epoch == ownership_epoch
                    && entry.study_output.as_ref() == Some(&expected_identity)
            });
            let output_artifact = matching_artifacts.next().with_context(|| {
                format!(
                    "manifest output `{}/{}` has no matching catalog artifact",
                    output.port_id, output.case_id
                )
            })?;
            if matching_artifacts.next().is_some()
                || output_artifact.status != fullmag_session::FmsArtifactStatus::Published
                || output_artifact.artifact_type != data_kind
                || output_artifact.object_ref.as_deref() != Some(output.object_ref.as_str())
                || output_artifact.content_sha256 != output.content_sha256
                || output.object_ref != output.content_sha256
            {
                bail!(
                    "study output manifest entry `{}/{}` differs from its published catalog artifact",
                    output.port_id,
                    output.case_id
                );
            }
        }
        for catalog_entry in artifact_catalog.entries.iter().filter(|entry| {
            entry.task_id == dependency_task_id
                && entry.attempt_id == attempt_id
                && entry.ownership_epoch == ownership_epoch
                && entry
                    .study_output
                    .as_ref()
                    .is_some_and(|output| output.step_id == *step_id)
        }) {
            if !manifest.outputs.iter().any(|output| {
                output.artifact_id == catalog_entry.artifact_id
                    && catalog_entry.study_output.as_ref().is_some_and(|identity| {
                        output.port_id == identity.port_id && output.case_id == identity.case_id
                    })
            }) {
                bail!(
                    "published artifact `{}` is not allow-listed by the study output manifest",
                    catalog_entry.artifact_id
                );
            }
        }

        let expected_identity = fullmag_session::FmsStudyArtifactOutput {
            step_id: step_id.clone(),
            port_id: output_port.clone(),
            case_id: case_id.clone(),
        };
        let selected = manifest
            .outputs
            .iter()
            .find(|entry| entry.port_id == *output_port && entry.case_id == *case_id)
            .with_context(|| {
                format!("study output manifest has no entry for `{output_port}/{case_id}`")
            })?;
        if selected.data_kind != study_port_data_kind_label(&input.data_kind)
            || selected.artifact_id != resolved.source
            || selected.content_sha256 != resolved.content_sha256
        {
            bail!(
                "resolved StepOutput `{}` differs from its typed manifest entry",
                input.port_id
            );
        }
        let output_artifact = artifact_catalog
            .entries
            .iter()
            .find(|entry| {
                entry.artifact_id == resolved.source
                    && entry.study_output.as_ref() == Some(&expected_identity)
                    && entry.task_id == dependency_task_id
                    && entry.attempt_id == attempt_id
                    && entry.ownership_epoch == ownership_epoch
            })
            .context("resolved StepOutput catalog artifact disappeared during manifest binding")?;
        if output_artifact.object_ref.as_deref() != Some(selected.object_ref.as_str()) {
            bail!("resolved StepOutput CAS reference differs from its typed manifest entry");
        }
        let study_artifact = ResolvedStudyArtifact {
            artifact_id: selected.artifact_id.clone(),
            object_ref: selected.object_ref.clone(),
            data_kind: selected.data_kind.clone(),
            codec_id: selected.codec_id.clone(),
            codec_version: selected.codec_version.clone(),
        };
        let artifact_bytes = store
            .cas()
            .get(&study_artifact.object_ref)?
            .with_context(|| {
                format!(
                    "resolved StepOutput `{}` CAS object is missing",
                    input.port_id
                )
            })?;
        fullmag_application::decode_study_artifact(&study_artifact, &artifact_bytes)
            .map_err(|error| anyhow::anyhow!(error.to_string()))
            .with_context(|| {
                format!(
                    "resolved StepOutput `{}` failed typed decoding",
                    input.port_id
                )
            })?;
        resolved.study_artifact = Some(study_artifact);
    }
    Ok(())
}

/// Fill StepOutput inputs from the accepted port declaration and durable
/// catalogs. Caller-provided values remain necessary for sources which require
/// an external resolver, but cannot override a study output artifact identity.
fn resolve_step_output_inputs(
    run_id: &str,
    ports: &[StudyInputPort],
    supplied_inputs: &std::collections::BTreeMap<String, ResolvedInput>,
    catalog: &fullmag_session::FmsRunCatalog,
    artifact_catalog: Option<&fullmag_session::FmsArtifactCatalog>,
) -> Result<std::collections::BTreeMap<String, ResolvedInput>> {
    if catalog.run_id != run_id {
        bail!("study input dependency catalog belongs to another run");
    }
    for name in supplied_inputs.keys() {
        if !ports.iter().any(|port| port.port_id == *name) {
            bail!("resolved study input `{name}` is not declared by the accepted step");
        }
    }
    let mut resolved = supplied_inputs.clone();
    let mut artifact_catalog_validated = false;
    for port in ports {
        let StudyInputSource::StepOutput {
            step_id,
            port: output_port,
            case_id,
        } = &port.source
        else {
            continue;
        };
        let dependency_task_id = fullmag_session::task_id_for_study_step(run_id, step_id)?;
        let dependency = catalog
            .tasks
            .iter()
            .find(|task| task.task_id == dependency_task_id)
            .with_context(|| {
                format!(
                    "study input `{}` depends on missing task `{dependency_task_id}`",
                    port.port_id
                )
            })?;
        if dependency.lifecycle != fullmag_session::FmsTaskLifecycle::Succeeded {
            bail!(
                "study input `{}` is blocked until dependency step `{step_id}` succeeds",
                port.port_id
            );
        }
        let attempt_id = dependency
            .attempt_id
            .as_deref()
            .context("successful study dependency has no attempt identity")?;
        let ownership_epoch = dependency
            .ownership_epoch
            .context("successful study dependency has no ownership epoch")?;
        let Some(artifact_catalog) = artifact_catalog else {
            if port.required || resolved.contains_key(&port.port_id) {
                bail!("StepOutput resolution requires a durable artifact catalog");
            }
            continue;
        };
        if !artifact_catalog_validated {
            artifact_catalog
                .validate()
                .context("accepted run artifact catalog is invalid")?;
            if artifact_catalog.run_id != run_id {
                bail!("study input artifact catalog belongs to another run");
            }
            artifact_catalog_validated = true;
        }
        let output_identity = fullmag_session::FmsStudyArtifactOutput {
            step_id: step_id.clone(),
            port_id: output_port.clone(),
            case_id: case_id.clone(),
        };
        let artifact = artifact_catalog.entries.iter().find(|entry| {
            entry.study_output.as_ref() == Some(&output_identity)
                && entry.task_id == dependency_task_id
                && entry.attempt_id == attempt_id
                && entry.ownership_epoch == ownership_epoch
        });
        let Some(artifact) = artifact else {
            if port.required || resolved.contains_key(&port.port_id) {
                bail!(
                    "study input `{}` has no published artifact for step `{step_id}`, port `{output_port}`, case `{case_id}`",
                    port.port_id
                );
            }
            continue;
        };
        if artifact.status != fullmag_session::FmsArtifactStatus::Published
            || artifact.object_ref.is_none()
        {
            bail!(
                "study input `{}` artifact is not published by the current successful dependency attempt",
                port.port_id
            );
        }
        let from_catalog = ResolvedInput {
            source: artifact.artifact_id.clone(),
            content_sha256: artifact.content_sha256.clone(),
            study_artifact: None,
        };
        if let Some(supplied) = supplied_inputs.get(&port.port_id) {
            if supplied != &from_catalog {
                bail!(
                    "study input `{}` does not match its pinned artifact identity and digest",
                    port.port_id
                );
            }
        }
        resolved.insert(port.port_id.clone(), from_catalog);
    }
    Ok(resolved)
}

fn validate_study_input_dependencies(
    run_id: &str,
    ports: &[StudyInputPort],
    resolved_inputs: &std::collections::BTreeMap<String, ResolvedInput>,
    catalog: &fullmag_session::FmsRunCatalog,
    artifact_catalog: Option<&fullmag_session::FmsArtifactCatalog>,
) -> Result<()> {
    if catalog.run_id != run_id {
        bail!("study input dependency catalog belongs to another run");
    }
    for name in resolved_inputs.keys() {
        if !ports.iter().any(|port| port.port_id == *name) {
            bail!("resolved study input `{name}` is not declared by the accepted step");
        }
    }
    for port in ports {
        if port.required && !resolved_inputs.contains_key(&port.port_id) {
            bail!(
                "required study input `{}` has not been resolved",
                port.port_id
            );
        }
        let StudyInputSource::StepOutput {
            step_id,
            port: output_port,
            case_id,
        } = &port.source
        else {
            continue;
        };
        let dependency_task_id = fullmag_session::task_id_for_study_step(run_id, step_id)?;
        let dependency = catalog
            .tasks
            .iter()
            .find(|task| task.task_id == dependency_task_id)
            .with_context(|| {
                format!(
                    "study input `{}` depends on missing task `{dependency_task_id}`",
                    port.port_id
                )
            })?;
        if dependency.lifecycle != fullmag_session::FmsTaskLifecycle::Succeeded
            || dependency.attempt_id.is_none()
            || dependency.ownership_epoch.is_none()
        {
            bail!(
                "study input `{}` is blocked until dependency step `{step_id}` succeeds",
                port.port_id
            );
        }
        let dependency_attempt_id = dependency
            .attempt_id
            .as_deref()
            .context("successful study dependency has no attempt identity")?;
        let dependency_epoch = dependency
            .ownership_epoch
            .context("successful study dependency has no ownership epoch")?;
        let Some(resolved) = resolved_inputs.get(&port.port_id) else {
            continue;
        };
        let artifact_catalog = artifact_catalog
            .context("StepOutput resolution requires a durable artifact catalog")?;
        artifact_catalog
            .validate()
            .context("accepted run artifact catalog is invalid")?;
        if artifact_catalog.run_id != run_id {
            bail!("study input artifact catalog belongs to another run");
        }
        let output_identity = fullmag_session::FmsStudyArtifactOutput {
            step_id: step_id.clone(),
            port_id: output_port.clone(),
            case_id: case_id.clone(),
        };
        let artifact = artifact_catalog
            .entries
            .iter()
            .find(|entry| {
                entry.study_output.as_ref() == Some(&output_identity)
                    && entry.task_id == dependency_task_id
                    && entry.attempt_id == dependency_attempt_id
                    && entry.ownership_epoch == dependency_epoch
            })
            .with_context(|| {
                format!(
                    "study input `{}` has no published artifact for step `{step_id}`, port `{output_port}`, case `{case_id}`",
                    port.port_id
                )
            })?;
        if artifact.status != fullmag_session::FmsArtifactStatus::Published
            || artifact.object_ref.is_none()
        {
            bail!(
                "study input `{}` artifact is not published by the current successful dependency attempt",
                port.port_id
            );
        }
        if resolved.source != artifact.artifact_id
            || resolved.content_sha256 != artifact.content_sha256
        {
            bail!(
                "study input `{}` does not match its pinned artifact identity and digest",
                port.port_id
            );
        }
    }
    Ok(())
}

/// Bind `PinnedArtifact` magnetization inputs by content alone (ADR 0068 F5).
///
/// A live command that continues the previous command's final state pins the
/// exact CAS object at accept time. Resolution is deterministic: the same
/// port always yields the same typed binding, so claim, Prepare rehydration
/// and scheduler recovery agree. The worker still decodes the bytes and
/// requires an exact layout match against the accepted execution plan.
fn resolve_pinned_state_inputs(
    store: &SessionStore,
    ports: &[StudyInputPort],
    resolved: &mut std::collections::BTreeMap<String, ResolvedInput>,
) -> Result<()> {
    for port in ports {
        let StudyInputSource::PinnedArtifact {
            artifact_id,
            content_sha256,
        } = &port.source
        else {
            continue;
        };
        let data_kind = match port.data_kind {
            fullmag_authoring::StudyPortDataKind::State => "state",
            fullmag_authoring::StudyPortDataKind::InitialState => "initial_state",
            unsupported => bail!(
                "pinned study input `{}` has unsupported data kind {unsupported:?}",
                port.port_id
            ),
        };
        if !store.cas().contains(content_sha256) {
            bail!(
                "pinned study input `{}` CAS object {content_sha256} is missing",
                port.port_id
            );
        }
        let binding = ResolvedInput {
            source: artifact_id.clone(),
            content_sha256: content_sha256.clone(),
            study_artifact: Some(fullmag_application::ResolvedStudyArtifact {
                artifact_id: artifact_id.clone(),
                object_ref: content_sha256.clone(),
                data_kind: data_kind.to_string(),
                codec_id: fullmag_application::STUDY_MAGNETIZATION_CODEC_ID.to_string(),
                codec_version: fullmag_application::STUDY_MAGNETIZATION_CODEC_VERSION.to_string(),
            }),
        };
        if let Some(supplied) = resolved.get(&port.port_id) {
            if supplied.source != binding.source || supplied.content_sha256 != binding.content_sha256 {
                bail!(
                    "pinned study input `{}` differs from its accepted artifact identity",
                    port.port_id
                );
            }
        }
        resolved.insert(port.port_id.clone(), binding);
    }
    Ok(())
}

/// Resolve the exact accepted step's declared inputs from durable artifact and
/// run catalogs. This read-only projection does not create or claim a task.
pub fn resolve_accepted_study_inputs(
    store: &SessionStore,
    run_id: &str,
    accepted_steps: &[StudyStep],
    study_step: &StudyStep,
    supplied_inputs: std::collections::BTreeMap<String, ResolvedInput>,
    catalog: &fullmag_session::FmsRunCatalog,
) -> Result<std::collections::BTreeMap<String, ResolvedInput>> {
    let artifact_catalog = store.read_artifact_catalog(run_id)?;
    let mut resolved_inputs = resolve_step_output_inputs(
        run_id,
        &study_step.inputs,
        &supplied_inputs,
        catalog,
        artifact_catalog.as_ref(),
    )?;
    bind_step_output_manifests(
        store,
        run_id,
        accepted_steps,
        &study_step.inputs,
        &mut resolved_inputs,
        catalog,
        artifact_catalog.as_ref(),
    )?;
    resolve_pinned_state_inputs(store, &study_step.inputs, &mut resolved_inputs)?;
    validate_study_input_dependencies(
        run_id,
        &study_step.inputs,
        &resolved_inputs,
        catalog,
        artifact_catalog.as_ref(),
    )?;
    for input in resolved_inputs.values() {
        input
            .validate()
            .map_err(|error| anyhow::anyhow!(error.to_string()))?;
    }
    Ok(resolved_inputs)
}

#[cfg(test)]
mod dependency_tests {
    use super::*;
    use fullmag_authoring::StudyPortDataKind;
    use fullmag_session::{
        FmsArtifactCatalog, FmsArtifactCatalogEntry, FmsArtifactStatus, FmsObservationState,
        FmsRunCatalog, FmsStudyArtifactOutput, FmsTaskCatalogEntry, FmsTaskLifecycle,
        FmsTaskReadiness, FMS_ARTIFACT_CATALOG_SCHEMA, FMS_RUN_CATALOG_SCHEMA,
    };
    use std::collections::BTreeMap;

    fn catalog(source_lifecycle: FmsTaskLifecycle) -> FmsRunCatalog {
        let run_id = "run-study-dependency";
        let source_task_id = fullmag_session::task_id_for_study_step(run_id, "source-step")
            .expect("valid source step");
        let consumer_task_id = fullmag_session::task_id_for_study_step(run_id, "consumer-step")
            .expect("valid consumer step");
        let task = |task_id: String,
                    lifecycle: FmsTaskLifecycle,
                    attempt_id: &str,
                    ownership_epoch: u64,
                    resource_id: Option<&str>| {
            FmsTaskCatalogEntry {
                task_id,
                input_fingerprint: "a".repeat(64),
                lifecycle,
                readiness: FmsTaskReadiness::Ready,
                observation: Some(FmsObservationState::Stale),
                attempt_id: Some(attempt_id.into()),
                ownership_epoch: Some(ownership_epoch),
                resolved_input_fingerprint: None,
                artifact_ids: vec![],
                resource_id: resource_id.map(str::to_owned),
                coordinator_watermark: None,
                coordinator_genesis: None,
            }
        };
        let source = task(
            source_task_id,
            source_lifecycle,
            "attempt-source-current",
            2,
            Some("cpu-source"),
        );
        FmsRunCatalog {
            schema_version: FMS_RUN_CATALOG_SCHEMA.into(),
            run_id: run_id.into(),
            revision: 1,
            updated_at: chrono::Utc::now(),
            tasks: vec![
                source,
                task(
                    consumer_task_id,
                    FmsTaskLifecycle::Preparing,
                    "attempt-consumer",
                    1,
                    Some("cpu-consumer"),
                ),
            ],
        }
    }

    fn ports() -> Vec<StudyInputPort> {
        vec![StudyInputPort {
            port_id: "initial_state".into(),
            data_kind: StudyPortDataKind::State,
            required: true,
            source: StudyInputSource::StepOutput {
                step_id: "source-step".into(),
                port: "final_state".into(),
                case_id: "default".into(),
            },
        }]
    }

    fn resolved_inputs() -> BTreeMap<String, ResolvedInput> {
        BTreeMap::from([(
            "initial_state".into(),
            ResolvedInput {
                source: "artifact-source".into(),
                content_sha256: "b".repeat(64),
                study_artifact: None,
            },
        )])
    }

    fn artifact_catalog() -> FmsArtifactCatalog {
        let run_id = "run-study-dependency";
        FmsArtifactCatalog {
            schema_version: FMS_ARTIFACT_CATALOG_SCHEMA.into(),
            run_id: run_id.into(),
            revision: 1,
            updated_at: chrono::Utc::now(),
            entries: vec![
                FmsArtifactCatalogEntry {
                    artifact_id: "artifact-source-old".into(),
                    task_id: fullmag_session::task_id_for_study_step(run_id, "source-step")
                        .expect("valid source step"),
                    attempt_id: "attempt-source-old".into(),
                    ownership_epoch: 1,
                    logical_path: "outputs/old/final-state.bin".into(),
                    artifact_type: "state".into(),
                    content_sha256: "d".repeat(64),
                    object_ref: Some("e".repeat(64)),
                    status: FmsArtifactStatus::Published,
                    required: true,
                    study_output: Some(FmsStudyArtifactOutput {
                        step_id: "source-step".into(),
                        port_id: "final_state".into(),
                        case_id: "default".into(),
                    }),
                },
                FmsArtifactCatalogEntry {
                    artifact_id: "artifact-source".into(),
                    task_id: fullmag_session::task_id_for_study_step(run_id, "source-step")
                        .expect("valid source step"),
                    attempt_id: "attempt-source-current".into(),
                    ownership_epoch: 2,
                    logical_path: "outputs/current/final-state.bin".into(),
                    artifact_type: "state".into(),
                    content_sha256: "b".repeat(64),
                    object_ref: Some("c".repeat(64)),
                    status: FmsArtifactStatus::Published,
                    required: true,
                    study_output: Some(FmsStudyArtifactOutput {
                        step_id: "source-step".into(),
                        port_id: "final_state".into(),
                        case_id: "default".into(),
                    }),
                },
            ],
        }
    }

    #[test]
    fn study_dispatch_requires_declared_inputs_and_succeeded_step_outputs() {
        let inputs = ports();
        let run_catalog = catalog(FmsTaskLifecycle::Succeeded);
        assert!(validate_study_input_dependencies(
            "run-study-dependency",
            &inputs,
            &resolved_inputs(),
            &run_catalog,
            Some(&artifact_catalog()),
        )
        .is_ok());
        assert!(validate_study_input_dependencies(
            "run-study-dependency",
            &inputs,
            &BTreeMap::new(),
            &run_catalog,
            Some(&artifact_catalog()),
        )
        .is_err());
        let mut extra = resolved_inputs();
        extra.insert(
            "undeclared".into(),
            ResolvedInput {
                source: "artifact-source".into(),
                content_sha256: "b".repeat(64),
                study_artifact: None,
            },
        );
        assert!(validate_study_input_dependencies(
            "run-study-dependency",
            &inputs,
            &extra,
            &run_catalog,
            Some(&artifact_catalog()),
        )
        .is_err());
        assert!(validate_study_input_dependencies(
            "run-study-dependency",
            &inputs,
            &resolved_inputs(),
            &catalog(FmsTaskLifecycle::Running),
            Some(&artifact_catalog()),
        )
        .is_err());

        let mut wrong_digest = resolved_inputs();
        wrong_digest
            .get_mut("initial_state")
            .expect("resolved input")
            .content_sha256 = "d".repeat(64);
        assert!(validate_study_input_dependencies(
            "run-study-dependency",
            &inputs,
            &wrong_digest,
            &catalog(FmsTaskLifecycle::Succeeded),
            Some(&artifact_catalog()),
        )
        .is_err());

        let mut wrong_artifact = resolved_inputs();
        wrong_artifact
            .get_mut("initial_state")
            .expect("resolved input")
            .source = "another-artifact".into();
        assert!(validate_study_input_dependencies(
            "run-study-dependency",
            &inputs,
            &wrong_artifact,
            &catalog(FmsTaskLifecycle::Succeeded),
            Some(&artifact_catalog()),
        )
        .is_err());

        let mut wrong_output = artifact_catalog();
        wrong_output.entries[1]
            .study_output
            .as_mut()
            .expect("study output")
            .case_id = "other-case".into();
        assert!(validate_study_input_dependencies(
            "run-study-dependency",
            &inputs,
            &resolved_inputs(),
            &catalog(FmsTaskLifecycle::Succeeded),
            Some(&wrong_output),
        )
        .is_err());
    }

    #[test]
    fn step_output_inputs_are_derived_from_the_current_successful_attempt() {
        let ports = ports();
        let run_catalog = catalog(FmsTaskLifecycle::Succeeded);
        let artifact_catalog = artifact_catalog();
        let derived = resolve_step_output_inputs(
            "run-study-dependency",
            &ports,
            &BTreeMap::new(),
            &run_catalog,
            Some(&artifact_catalog),
        )
        .unwrap();
        assert_eq!(derived, resolved_inputs());

        let mut forged = resolved_inputs();
        forged
            .get_mut("initial_state")
            .expect("resolved input")
            .content_sha256 = "f".repeat(64);
        assert!(resolve_step_output_inputs(
            "run-study-dependency",
            &ports,
            &forged,
            &run_catalog,
            Some(&artifact_catalog),
        )
        .is_err());

        let mut missing_case = artifact_catalog;
        missing_case.entries[1]
            .study_output
            .as_mut()
            .expect("study output")
            .case_id = "other-case".into();
        assert!(resolve_step_output_inputs(
            "run-study-dependency",
            &ports,
            &BTreeMap::new(),
            &run_catalog,
            Some(&missing_case),
        )
        .is_err());
    }
}

fn apply_admitted_frozen_binding(resolved: &mut ResolvedTaskInput,
    snapshot: &fullmag_session::FmsResolvedInputsSnapshot, stage: &str) -> Result<()> {
    snapshot.validate()?;
    if snapshot.inputs != serde_json::to_value(&resolved.inputs)? { bail!("physical input differs from its immutable admission"); }
    if let Some(context) = &snapshot.frozen_stage_context {
        let binding: fullmag_application::FrozenStageContextRefV1 = serde_json::from_value(context.clone())?;
        binding.validate()?;
        if binding.stage_id != stage || binding.run_id != resolved.run_id.as_str() {
            bail!("admitted frozen binding belongs to another stage/run");
        }
        resolved.schema_version = fullmag_application::TERMINAL_RESOLVED_TASK_INPUT_SCHEMA.into();
        resolved.frozen_stage_context = Some(binding);
        resolved.validate()?;
    }
    Ok(())
}

/// Recover a read-only source from the original genesis/admission, including
/// after success/lease release. This does not acquire a claim or dispatch work.
pub(crate) fn cold_accepted_worker_step(store: &SessionStore,
    accepted: &AcceptedStudySnapshot, stage: &str, task_id: &str, attempt: &str, epoch: u64)
    -> Result<AcceptedWorkerStep> {
    let run = accepted.run.specification.run_id.as_str();
    if fullmag_session::task_id_for_study_step(run, stage)? != task_id { bail!("cold source task differs from its immutable stage"); }
    let catalog = store.read_run_catalog(run)?.context("cold source run catalog is absent")?;
    let task = catalog.tasks.iter().find(|task| task.task_id == task_id).context("cold source task is absent")?;
    if task.attempt_id.as_deref() != Some(attempt) || task.ownership_epoch != Some(epoch) {
        bail!("cold source no longer belongs to the published attempt");
    }
    let genesis = task.coordinator_genesis.as_ref().context("cold source has no historical coordinator genesis")?;
    let checkpoint: fullmag_application::CoordinatorCheckpoint = serde_json::from_value(genesis.checkpoint.clone())?;
    if genesis.run_id != run || genesis.task_id != task_id || genesis.attempt_id != attempt
        || genesis.ownership_epoch != epoch || checkpoint.claim.run_id.as_str() != run
        || checkpoint.claim.task_id.as_str() != task_id || checkpoint.claim.attempt_id.as_str() != attempt
        || checkpoint.claim.ownership_epoch.value() != epoch || checkpoint.task.input_fingerprint != task.input_fingerprint
        || checkpoint.command_sequence != 0 || checkpoint.event_sequence != 0
        || fullmag_session::canonical_json_sha256(&genesis.checkpoint) != genesis.checkpoint_sha256
    { bail!("cold source genesis differs from its immutable published identity"); }
    fullmag_application::WorkerCoordinator::restore(checkpoint.clone(), &[], &[])?;
    let admission = store.read_task_admission(run, task_id, attempt)?.context("cold source has no historical admission")?;
    admission.validate()?;
    let snapshot = admission.resolved_inputs_snapshot.context("cold source has no captured physical inputs/history")?;
    snapshot.validate()?;
    if snapshot.frozen_stage_context.is_none() { bail!("cold v2 source lacks the actual historical activation set"); }
    let inputs: std::collections::BTreeMap<String, ResolvedInput> = serde_json::from_value(snapshot.inputs.clone())?;
    let receipt = accepted.read_task_preparation(store, task_id)?;
    let AcceptedPreparationReceipt::Solver(receipt) = receipt else { bail!("cold M3 source is not a solver stage"); };
    let mut resolved = accepted.resolved_task_input_from_bound_receipt(&checkpoint.task,
        &checkpoint.claim, stage, &receipt, inputs)?;
    apply_admitted_frozen_binding(&mut resolved, &snapshot, stage)?;
    let lowered = accepted.lowered.steps.iter().find(|step| step.step_id == stage).context("cold source has no accepted plan")?;
    let authored = accepted.study.steps.iter().find(|step| step.step_id == stage).context("cold source has no accepted stage")?;
    let problem = accepted.catalog.entries().iter().find(|entry| entry.step_id() == stage)
        .context("cold source has no immutable ProblemIR")?.problem().clone();
    let plan = lowered.execution_plan.clone().context("cold source has no resolved execution plan")?;
    resolved.validate_execution_for_problem(&accepted.run.specification, &problem)?;
    Ok(AcceptedWorkerStep { claim: checkpoint.claim, step_id: stage.into(), study_inputs: authored.inputs.clone(),
        problem, execution_plan: plan, until_seconds: lowered.until_seconds, resolved_input: resolved })
}

/// Publish a worker Prepare command only after resolving its task input from
/// the durable receipt and immutable accepted-study snapshot. The coordinator
/// journal is the outbox boundary: this does not send a transport message,
/// admit a solver process, or update task readiness.
pub fn publish_accepted_task_prepare(
    store: &SessionStore,
    study: &AcceptedStudySnapshot,
    coordinator: &mut DurableWorkerCoordinator,
    step_id: &str,
    inputs: std::collections::BTreeMap<String, ResolvedInput>,
) -> Result<WorkerCommandEnvelope> {
    let checkpoint = coordinator.checkpoint();
    let (receipt, mut resolved_input) = study.resolve_task_input_and_receipt_from_store(
        store,
        &checkpoint.task,
        &checkpoint.claim,
        step_id,
        inputs,
    )?;

    if let Some(admission) = store.read_task_admission(checkpoint.claim.run_id.as_str(),
        checkpoint.claim.task_id.as_str(), checkpoint.claim.attempt_id.as_str())? {
        if let Some(snapshot) = admission.resolved_inputs_snapshot {
            apply_admitted_frozen_binding(&mut resolved_input, &snapshot, step_id)?;
        }
    }

    retry_store_writer_busy(|| crate::commit_coordinator_genesis(store, &checkpoint))
        .context("publishing accepted task coordinator genesis")?;

    let mut publication_error = None;
    let result = coordinator.commit_command(
        WorkerCommand::Prepare { resolved_input },
        Some(&receipt),
        |transition| {
            crate::commit_transition_with_accepted_snapshot(store, transition, study)
                .map(|_| ())
                .map_err(|error| {
                    publication_error = Some(error);
                    CoordinatorError::Invalid("durable Prepare publication failed".into())
                })
        },
    );
    match (result, publication_error) {
        (Ok(envelope), None) => Ok(envelope),
        (_, Some(error)) if is_store_writer_busy(&error) => retry_pending_command_publication(
            store,
            coordinator,
            Some(study),
            "publishing accepted task Prepare command",
        ),
        (_, Some(error)) => Err(error).context("publishing accepted task Prepare command"),
        (Err(error), None) => {
            Err(anyhow::Error::new(error)).context("committing accepted task Prepare command")
        }
    }
}

/// Publish the exact Start command after a durable Prepare for the same claim.
/// The coordinator journal remains the transport outbox and the worker side
/// effect stays owned by the process supervisor.
pub fn publish_accepted_task_start(
    store: &SessionStore,
    coordinator: &mut DurableWorkerCoordinator,
) -> Result<WorkerCommandEnvelope> {
    publish_accepted_task_start_inner(store, coordinator, None)
}

/// Publish Start using the accepted snapshot already validated by the
/// scheduler operation. The transition writer still fences current intent,
/// task identity, and dependency state before publication.
pub(crate) fn publish_accepted_task_start_from_snapshot(
    store: &SessionStore,
    study: &AcceptedStudySnapshot,
    coordinator: &mut DurableWorkerCoordinator,
) -> Result<WorkerCommandEnvelope> {
    publish_accepted_task_start_inner(store, coordinator, Some(study))
}

fn publish_accepted_task_start_inner(
    store: &SessionStore,
    coordinator: &mut DurableWorkerCoordinator,
    study: Option<&AcceptedStudySnapshot>,
) -> Result<WorkerCommandEnvelope> {
    let mut publication_error = None;
    let result = coordinator.commit_command(WorkerCommand::Start, None, |transition| {
        let commit = match study {
            Some(study) => {
                crate::commit_transition_with_accepted_snapshot(store, transition, study)
            }
            None => crate::commit_transition(store, transition),
        };
        commit
            .map(|_| ())
            .map_err(|error| {
                publication_error = Some(error);
                CoordinatorError::Invalid("durable Start publication failed".into())
            })
    });
    match (result, publication_error) {
        (Ok(envelope), None) => Ok(envelope),
        (_, Some(error)) if is_store_writer_busy(&error) => retry_pending_command_publication(
            store,
            coordinator,
            study,
            "publishing accepted task Start command",
        ),
        (_, Some(error)) => Err(error).context("publishing accepted task Start command"),
        (Err(error), None) => {
            Err(anyhow::Error::new(error)).context("committing accepted task Start command")
        }
    }
}

fn retry_pending_command_publication(
    store: &SessionStore,
    coordinator: &mut DurableWorkerCoordinator,
    study: Option<&AcceptedStudySnapshot>,
    context: &'static str,
) -> Result<WorkerCommandEnvelope> {
    let expected = match &coordinator
        .pending_transition()
        .context("coordinator lost the pending command publication")?
        .message
    {
        CoordinatorMessage::Command(envelope) => envelope.clone(),
        CoordinatorMessage::Event(_) => bail!("pending coordinator publication is not a command"),
    };
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
    loop {
        let mut publication_error = None;
        let result = coordinator.retry_publication(|transition| {
            let commit = match study {
                Some(study) => {
                    crate::commit_transition_with_accepted_snapshot(store, transition, study)
                }
                None => crate::commit_transition(store, transition),
            };
            commit
                .map(|_| ())
                .map_err(|error| {
                    publication_error = Some(error);
                    CoordinatorError::Invalid("durable command publication retry failed".into())
                })
        });
        match (result, publication_error) {
            (Ok(CoordinatorMessage::Command(envelope)), None) if envelope == expected => {
                return Ok(envelope);
            }
            (Ok(CoordinatorMessage::Command(_)), None) => {
                bail!("retried coordinator command differs from the retained publication");
            }
            (Ok(CoordinatorMessage::Event(_)), None) => {
                bail!("retried coordinator publication is not a command");
            }
            (_, Some(error))
                if is_store_writer_busy(&error) && std::time::Instant::now() < deadline =>
            {
                std::thread::sleep(std::time::Duration::from_millis(10));
            }
            (_, Some(error)) => return Err(error).context(context),
            (Err(error), None) => return Err(anyhow::Error::new(error)).context(context),
        }
    }
}

fn is_store_writer_busy(error: &anyhow::Error) -> bool {
    error
        .chain()
        .any(|cause| cause.is::<fullmag_session::StoreWriterBusy>())
}

fn retry_store_writer_busy<T>(mut action: impl FnMut() -> Result<T>) -> Result<T> {
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
    loop {
        match action() {
            Ok(value) => return Ok(value),
            Err(error) if is_store_writer_busy(&error) && std::time::Instant::now() < deadline => {
                std::thread::sleep(std::time::Duration::from_millis(10));
            }
            Err(error) => return Err(error),
        }
    }
}

fn preparation_fingerprint(value: &serde_json::Value) -> String {
    format!("sha256:{}", fullmag_session::canonical_json_sha256(value))
}

/// Validate every pinned input before exposing the study to an entry point.
pub fn load_accepted_study_snapshot(
    store: &SessionStore,
    run_id: &RunId,
    project_id: &ProjectId,
) -> Result<AcceptedStudySnapshot> {
    let run = crate::load_accepted_run_snapshot(store, run_id, project_id)?;
    let intent = &run.intent;
    let study_ref = intent
        .study_object_ref
        .as_deref()
        .context("accepted run has no immutable study object")?;
    let catalog_ref = intent
        .study_catalog_object_ref
        .as_deref()
        .context("accepted run has no immutable study catalog object")?;
    let key = crate::study_snapshot_cache::AcceptedStudyKey::new(
        store.root(),
        run_id.as_str(),
        &intent.payload_sha256,
        study_ref,
        catalog_ref,
    );
    let validated = crate::study_snapshot_cache::get_or_try_insert(key, || {
        validate_accepted_study_inputs(store.cas(), &run, study_ref, catalog_ref)
    })?;
    let (study, catalog, lowered) = (*validated).clone();
    Ok(AcceptedStudySnapshot {
        run,
        study,
        catalog,
        lowered,
    })
}

/// Share canonical planning/input verification with an imported evidence-only CAS.
pub fn load_accepted_study_snapshot_from_run(
    cas: &fullmag_session::CasStore,
    run: crate::AcceptedRunSnapshot,
) -> Result<AcceptedStudySnapshot> {
    let study_ref = run
        .intent
        .study_object_ref
        .as_deref()
        .context("accepted run has no immutable study object")?;
    let catalog_ref = run
        .intent
        .study_catalog_object_ref
        .as_deref()
        .context("accepted run has no immutable study catalog object")?;
    let (study, catalog, lowered) =
        validate_accepted_study_inputs(cas, &run, study_ref, catalog_ref)?;
    Ok(AcceptedStudySnapshot {
        run,
        study,
        catalog,
        lowered,
    })
}

/// Immutable validation is shared by native cached and imported evidence-only reads.
fn validate_accepted_study_inputs(
    cas: &fullmag_session::CasStore,
    run: &crate::AcceptedRunSnapshot,
    study_ref: &str,
    catalog_ref: &str,
) -> Result<crate::study_snapshot_cache::ValidatedAcceptedStudy> {
    let intent = &run.intent;
    let specification = &run.specification;
    let study_bytes = cas
        .get_bounded(study_ref, fullmag_session::MAX_TERMINAL_CATALOG_METADATA_BYTES)?
        .context("accepted run study object is missing")?;
    let catalog_bytes = cas
        .get_bounded(catalog_ref, crate::MAX_ACCEPTED_MODEL_DOCUMENT_BYTES)?
        .context("accepted run study catalog object is missing")?;
    let study: StudyPlan =
        serde_json::from_slice(&study_bytes).context("accepted run study object is not typed")?;
    let catalog: StudyProblemCatalog = serde_json::from_slice(&catalog_bytes)
        .context("accepted run study catalog object is not typed")?;
    if study.canonical_sha256()? != study_ref
        || study_ref != specification.study.plan_sha256
        || study.study_id != specification.study.study_id.as_str()
        || study.schema_version != specification.study.plan_version
        || fullmag_session::canonical_json_sha256(&serde_json::to_value(&catalog)?) != catalog_ref
        || catalog_ref != specification.study_catalog_sha256
    {
        bail!("accepted run study or catalog differs from immutable RunSpec");
    }
    if intent.asset_object_refs.len() != specification.immutable_assets.len() {
        bail!("accepted run asset references differ from immutable RunSpec");
    }
    for asset in &specification.immutable_assets {
        let object_ref = intent
            .asset_object_refs
            .get(&asset.asset_id)
            .with_context(|| format!("accepted run asset `{}` is missing", asset.asset_id))?;
        if object_ref != &asset.content_sha256 {
            bail!(
                "accepted run asset `{}` differs from immutable RunSpec",
                asset.asset_id
            );
        }
        // Verify all bytes without retaining a discarded buffer, preserving the v4 cap.
        let length = cas.verified_length(object_ref)?;
        if study.schema_version == fullmag_authoring::STUDY_PLAN_SCHEMA_VERSION_V4
            && length.is_some_and(|bytes| bytes > 32 * 1024 * 1024) {
            bail!("accepted v4 run asset exceeds its metadata budget");
        }
        length.with_context(|| {
            format!("accepted run asset `{}` object is missing", asset.asset_id)
        })?;
    }
    if study.schema_version==fullmag_authoring::STUDY_PLAN_SCHEMA_VERSION_V4 {
        let asset=specification.immutable_assets.iter().find(|asset|asset.asset_id==fullmag_application::SCRIPT_PIPELINE_SOURCE_ASSET_ID)
            .context("accepted v4 requires captured compiled source asset")?;
        let bytes=cas.get_bounded(&asset.content_sha256,16*1024*1024)?.context("accepted v4 source asset missing")?;
        let source=fullmag_application::validate_accepted_script_pipeline_source(&study,&catalog,&bytes)?;
        fullmag_application::validate_script_source_assets(specification,&source,|hash,maximum|cas.get_bounded(hash,maximum)?.context("accepted source file missing"))?;
    }
    let lowered = lower_study_plan_with_catalog(&study, &catalog)
        .context("lower immutable study through canonical planner")?;
    validate_requested_execution(specification, &catalog, &lowered)?;
    Ok((study, catalog, lowered))
}

pub fn validate_requested_execution(
    specification: &RunSpecification,
    catalog: &StudyProblemCatalog,
    plan: &StudyExecutionPlan,
) -> Result<()> {
    let requested = &specification.requested_execution;

    // This check is deliberately snapshot-only. In particular, do not call
    // the runner's host resolver here: submit validation must not inspect the
    // current host or mutate process-wide device environment. Preparation has
    // its own CPU lease and is not a solver-task execution lane.
    for step in plan
        .steps
        .iter()
        .filter(|step| matches!(step.status, StudyStepLoweringStatus::Planned))
    {
        let execution = step.execution_plan.as_ref().with_context(|| {
            format!(
                "planned study step `{}` has no execution plan",
                step.step_id
            )
        })?;
        let entry = catalog
            .entries()
            .iter()
            .find(|entry| entry.step_id() == step.step_id)
            .with_context(|| {
                format!(
                    "study step `{}` has no immutable catalog entry",
                    step.step_id
                )
            })?;
        let problem = entry.problem();
        if let Some(materialization) = entry.execution_materialization() {
            fullmag_application::validate_execution_materialization(materialization)
                .map_err(anyhow::Error::msg)
                .with_context(|| {
                    format!(
                        "study step `{}` execution materialization is invalid",
                        step.step_id
                    )
                })?;
        }
        let step_requested = requested.for_problem(problem).map_err(|error| {
            anyhow::anyhow!(
                "study step `{}` execution request is invalid: {error}",
                step.step_id
            )
        })?;

        if execution.common.requested_backend != problem.backend_policy.requested_backend {
            bail!(
                "study step `{}` execution plan requested backend differs from its immutable ProblemIR",
                step.step_id
            );
        }
        if step_requested.backend != "auto"
            && (execution.common.requested_backend.as_str() != step_requested.backend
                || execution.common.resolved_backend.as_str() != step_requested.backend)
        {
            bail!(
                "study step `{}` backend differs from its effective execution request `{}`",
                step.step_id,
                step_requested.backend
            );
        }

        if execution.common.execution_mode != problem.validation_profile.execution_mode {
            bail!(
                "study step `{}` execution plan mode differs from its immutable ProblemIR",
                step.step_id
            );
        }
        let planned_mode = match execution.common.execution_mode {
            ExecutionMode::Strict => "strict",
            ExecutionMode::Extended => "extended",
            ExecutionMode::Hybrid => "hybrid",
        };
        if planned_mode != step_requested.mode {
            bail!(
                "study step `{}` mode `{planned_mode}` differs from its effective execution request `{}`",
                step.step_id,
                step_requested.mode
            );
        }

        let requested_precision = match problem.backend_policy.execution_precision {
            ExecutionPrecision::Single => "single",
            ExecutionPrecision::Double => "double",
        };
        if requested_precision != step_requested.precision {
            bail!(
                "study step `{}` requested precision `{requested_precision}` differs from its effective execution request `{}`",
                step.step_id,
                step_requested.precision
            );
        }

        let planned_precision = match &execution.backend_plan {
            fullmag_ir::BackendPlanIR::AntennaRetainedCurrentFieldInspection(operation) => {
                let fullmag_authoring::StudyStepKind::RetainedCurrentFieldInspection {
                    stage_id, port_mode_id, output_id,
                } = &step.kind else {
                    bail!("retained-current H-only carrier requires its exact typed accepted operation");
                };
                let canonical = fullmag_plan::validate_retained_current_field_operation(
                    problem, stage_id, port_mode_id, output_id)?;
                let intent = &operation.requested_execution;
                if operation != &canonical
                    || step_requested.backend != "fem" || step_requested.device != "cpu"
                    || step_requested.precision != "double" || step_requested.mode != "strict"
                    || intent.discretization != BackendTarget::Fem || intent.device != ExecutionDevice::Cpu
                    || intent.precision != ExecutionPrecision::Double || intent.execution_mode != ExecutionMode::Strict
                    || execution.common.resolved_backend != BackendTarget::Fem
                    || step.until_seconds.is_some() || !step.inputs.is_empty()
                    || step.outputs.len() != 1
                    || step.outputs[0].port_id != fullmag_authoring::ANTENNA_INSPECTION_OUTPUT_PORT_ID
                    || step.outputs[0].data_kind != fullmag_authoring::StudyPortDataKind::Artifact
                {
                    bail!("retained-current H-only accepted operation differs from its canonical plan or explicit FEM CPU double strict static request");
                }
                Some(intent.precision)
            }            fullmag_ir::BackendPlanIR::AntennaRetainedPreparationFieldInspection(operation) => {
                let fullmag_authoring::StudyStepKind::RetainedCurrentFieldInspection {
                    stage_id, port_mode_id, output_id,
                } = &step.kind else {
                    bail!("retained-asset field H-only carrier requires its exact typed accepted operation");
                };
                let canonical = fullmag_plan::validate_retained_preparation_field_operation(
                    problem, stage_id, port_mode_id, output_id)?;
                let intent = &operation.requested_execution;
                if operation != &canonical
                    || step_requested.backend != "fem" || step_requested.device != "cpu"
                    || step_requested.precision != "double" || step_requested.mode != "strict"
                    || intent.discretization != BackendTarget::Fem || intent.device != ExecutionDevice::Cpu
                    || intent.precision != ExecutionPrecision::Double || intent.execution_mode != ExecutionMode::Strict
                    || execution.common.resolved_backend != BackendTarget::Fem
                    || step.until_seconds.is_some() || !step.inputs.is_empty()
                    || step.outputs.len() != 1
                    || step.outputs[0].port_id != fullmag_authoring::ANTENNA_INSPECTION_OUTPUT_PORT_ID
                    || step.outputs[0].data_kind != fullmag_authoring::StudyPortDataKind::Artifact
                {
                    bail!("retained-asset field H-only accepted operation differs from its canonical plan or explicit FEM CPU double strict static request");
                }
                Some(intent.precision)
            }
            fullmag_ir::BackendPlanIR::AntennaRetainedDirectFieldInspection(operation) => {
                let fullmag_authoring::StudyStepKind::RetainedCurrentFieldInspection {
                    stage_id, port_mode_id, output_id,
                } = &step.kind else {
                    bail!("retained-asset field H-only carrier requires its exact typed accepted operation");
                };
                let canonical = fullmag_plan::validate_retained_direct_field_operation(
                    problem, stage_id, port_mode_id, output_id)?;
                let intent = &operation.requested_execution;
                if operation != &canonical
                    || step_requested.backend != "fem" || step_requested.device != "cpu"
                    || step_requested.precision != "double" || step_requested.mode != "strict"
                    || intent.discretization != BackendTarget::Fem || intent.device != ExecutionDevice::Cpu
                    || intent.precision != ExecutionPrecision::Double || intent.execution_mode != ExecutionMode::Strict
                    || execution.common.resolved_backend != BackendTarget::Fem
                    || step.until_seconds.is_some() || !step.inputs.is_empty()
                    || step.outputs.len() != 1
                    || step.outputs[0].port_id != fullmag_authoring::ANTENNA_INSPECTION_OUTPUT_PORT_ID
                    || step.outputs[0].data_kind != fullmag_authoring::StudyPortDataKind::Artifact
                {
                    bail!("retained-asset field H-only accepted operation differs from its canonical plan or explicit FEM CPU double strict static request");
                }
                Some(intent.precision)
            }
            fullmag_ir::BackendPlanIR::AntennaFieldOnly(_) => Some(fullmag_ir::ExecutionPrecision::Double),
            fullmag_ir::BackendPlanIR::AntennaExternalLeadInspection(inspection) => {
                let intent = &inspection.requested_execution;
                if step_requested.backend != "fem"
                    || !matches!(step_requested.device.as_str(), "cpu" | "auto")
                    || step_requested.precision != "double"
                    || step_requested.mode != "strict"
                    || intent.discretization != BackendTarget::Fem
                    || !matches!(intent.device, ExecutionDevice::Cpu | ExecutionDevice::Auto)
                    || intent.precision != ExecutionPrecision::Double
                    || intent.execution_mode != ExecutionMode::Strict
                    || device_name(intent.device) != step_requested.device
                    || execution.common.resolved_backend != BackendTarget::Fem
                    || step.until_seconds.is_some()
                    || !matches!(
                        &step.kind,
                        fullmag_authoring::StudyStepKind::Primitive {
                            stage_kind:
                                fullmag_authoring::StudyPrimitiveStageKind::AntennaFieldSolve,
                        }
                    )
                    || !step.inputs.is_empty()
                    || step.outputs.len() != 1
                    || step.outputs[0].port_id
                        != fullmag_authoring::ANTENNA_INSPECTION_OUTPUT_PORT_ID
                    || step.outputs[0].data_kind != fullmag_authoring::StudyPortDataKind::Artifact
                {
                    bail!(
                        "antenna inspection accepted-study requires FEM CPU-or-auto double strict and its sole inspection/Artifact port, without magnetic inputs or horizon"
                    );
                }
                Some(intent.precision)
            }
            fullmag_ir::BackendPlanIR::Fdm(plan) => Some(plan.precision),
            fullmag_ir::BackendPlanIR::FdmMultilayer(plan) => Some(plan.precision),
            fullmag_ir::BackendPlanIR::FemEigen(plan) => Some(plan.precision),
            fullmag_ir::BackendPlanIR::FemFrequencyResponse(plan) => Some(plan.precision),
            // The current generic FEM plan has no separate resolved-precision
            // field. Its planner validates the requested precision before it
            // emits this plan; a typed execution receipt remains future work.
            fullmag_ir::BackendPlanIR::Fem(_) => None,
        };
        if planned_precision
            .is_some_and(|precision| precision_name(precision) != step_requested.precision)
        {
            bail!(
                "study step `{}` resolved precision differs from its effective execution request `{}`",
                step.step_id,
                step_requested.precision
            );
        }

        let step_requested_device = problem_requested_device(problem, &step.step_id)?;
        let effective_requested_device = match step_requested.device.as_str() {
            "auto" => ExecutionDevice::Auto,
            "cpu" => ExecutionDevice::Cpu,
            "gpu" => ExecutionDevice::Gpu,
            _ => bail!(
                "study step `{}` has an invalid effective device",
                step.step_id
            ),
        };

        if let Some(resolution) = &execution.provenance.fem_eigen_execution_resolution {
            if resolution.requested_device != step_requested_device {
                bail!(
                    "study step `{}` FEM eigen requested-device provenance differs from its immutable ProblemIR",
                    step.step_id
                );
            }
            if resolution.resolved_device == ExecutionDevice::Auto
                || (resolution.requested_device != ExecutionDevice::Auto
                    && resolution.resolved_device != resolution.requested_device)
            {
                bail!(
                    "study step `{}` FEM eigen device resolution is inconsistent with its requested device",
                    step.step_id
                );
            }
            if resolution.requested_precision != problem.backend_policy.execution_precision
                || resolution.resolved_precision != problem.backend_policy.execution_precision
            {
                bail!(
                    "study step `{}` FEM eigen precision provenance differs from its immutable ProblemIR",
                    step.step_id
                );
            }
            if effective_requested_device != ExecutionDevice::Auto
                && resolution.resolved_device != effective_requested_device
            {
                bail!(
                    "study step `{}` resolved device `{}` differs from its effective execution request `{}`",
                    step.step_id,
                    device_name(resolution.resolved_device),
                    step_requested.device
                );
            }
        }
    }
    Ok(())
}

fn problem_requested_device(problem: &ProblemIR, step_id: &str) -> Result<ExecutionDevice> {
    let Some(selection) = problem
        .problem_meta
        .runtime_metadata
        .get("runtime_selection")
    else {
        return Ok(ExecutionDevice::Auto);
    };
    let Some(selection) = selection.as_object() else {
        bail!("study step `{step_id}` runtime_selection must be an object");
    };
    let Some(value) = selection.get("device") else {
        return Ok(ExecutionDevice::Auto);
    };
    let Some(value) = value.as_str() else {
        bail!("study step `{step_id}` runtime_selection.device must be a string");
    };
    match value {
        "auto" => Ok(ExecutionDevice::Auto),
        "cpu" => Ok(ExecutionDevice::Cpu),
        "gpu" | "cuda" => Ok(ExecutionDevice::Gpu),
        _ => bail!("study step `{step_id}` runtime_selection.device `{value}` is unsupported"),
    }
}

fn precision_name(precision: ExecutionPrecision) -> &'static str {
    match precision {
        ExecutionPrecision::Single => "single",
        ExecutionPrecision::Double => "double",
    }
}

fn device_name(device: ExecutionDevice) -> &'static str {
    match device {
        ExecutionDevice::Auto => "auto",
        ExecutionDevice::Cpu => "cpu",
        ExecutionDevice::Gpu => "gpu",
    }
}

#[cfg(test)]
mod accepted_start_preparation_tests {
    use super::*;
    use fullmag_application::{
        ProjectId, ProjectSnapshot, RequestedExecution, RequestedResourceBudget, RunId,
        RunSpecification, StudyId, StudyReference,
    };
    use fullmag_authoring::{
        PrimitiveStageNode, StudyDiscretizationReference, StudyExecutionProfileReference,
        StudyModelReference, StudyPipelineDocument, StudyPipelineNode, StudyPipelineNodeSource,
        StudyPlanMigrationDefaults, StudyPrimitiveStageKind, StudySolverConfigReference,
    };
    use fullmag_ir::{BackendTarget, ProblemIR};
    use fullmag_plan::{lower_study_plan_with_catalog, StudyProblemCatalog, StudyProblemCatalogEntry};
    use fullmag_session::FmsRunIntent;
    use serde_json::json;

    fn manual_run_snapshot(
        mut problem: ProblemIR,
        backend: &str,
        run_id: &str,
    ) -> AcceptedStudySnapshot {
        problem
            .problem_meta
            .runtime_metadata
            .insert("runtime_selection".into(), json!({"device": "cpu", "precision": "double"}));
        let study = fullmag_authoring::StudyPlan::from_pipeline(
            format!("{run_id}-study"),
            1,
            &StudyPipelineDocument {
                version: "study_pipeline.v2".into(),
                nodes: vec![StudyPipelineNode::Primitive(PrimitiveStageNode {
                    id: "step:run".into(),
                    label: "Run".into(),
                    enabled: true,
                    notes: None,
                    source: Some(StudyPipelineNodeSource::UiAuthored),
                    stage_kind: StudyPrimitiveStageKind::Run,
                    payload: [("until_seconds".into(), json!("1e-9"))]
                        .into_iter()
                        .collect(),
                })],
            },
            &StudyPlanMigrationDefaults {
                model: StudyModelReference {
                    model_id: "model:one".into(),
                    version: "v1".into(),
                },
                solver_config: StudySolverConfigReference {
                    preset_id: "solver:default".into(),
                    version: "v1".into(),
                },
                discretization: StudyDiscretizationReference {
                    recipe_id: "mesh:default".into(),
                    version: "v1".into(),
                },
                execution_profile: StudyExecutionProfileReference {
                    profile_id: "exec:auto".into(),
                    version: "v1".into(),
                },
            },
        )
        .expect("accepted preparation study fixture is valid");
        let catalog = StudyProblemCatalog::from_entries(
            &study,
            study
                .steps
                .iter()
                .map(|step| StudyProblemCatalogEntry::from_step(step, problem.clone()))
                .collect(),
        )
        .expect("accepted preparation catalog is valid");
        let lowered = lower_study_plan_with_catalog(&study, &catalog)
            .expect("accepted preparation plan is valid");
        let mut specification = RunSpecification::new(
            ProjectSnapshot {
                project_id: ProjectId::new(),
                definition_revision: 1,
                definition_sha256: "a".repeat(64),
            },
            StudyReference {
                study_id: StudyId::parse(study.study_id.clone()).unwrap(),
                plan_version: study.schema_version.clone(),
                plan_sha256: "b".repeat(64),
            },
            "c".repeat(64),
            json!({
                (fullmag_session::ACCEPTED_RUN_START_POLICY_KEY): {
                    "schema_version": "accepted_run_start_policy.v1",
                    "mode": "manual"
                }
            }),
            RequestedExecution {
                backend: backend.into(),
                device: "cpu".into(),
                precision: "double".into(),
                mode: "strict".into(),
                minimum_resources: Some(RequestedResourceBudget {
                    cpu_millis: 100,
                    memory_bytes: 1,
                    gpu_memory_bytes: 0,
                    storage_bytes: 1,
                }),
            },
        );
        specification.run_id = RunId::parse(run_id).expect("accepted preparation run id is valid");
        let intent = FmsRunIntent::new(
            run_id,
            format!("intent-{run_id}"),
            serde_json::to_value(&specification).unwrap(),
        );
        AcceptedStudySnapshot {
            run: crate::AcceptedRunSnapshot {
                intent,
                specification,
                definition_bytes: Vec::new(),
            },
            study,
            catalog,
            lowered,
        }
    }

    fn fem_problem_with_mesh_asset() -> ProblemIR {
        let mut problem = ProblemIR::bootstrap_example();
        problem.backend_policy.requested_backend = BackendTarget::Fem;
        problem.air_box_policy = Some(fullmag_ir::AirBoxPolicyIR {
            boundary_marker: Some(99),
            ..Default::default()
        });
        problem.geometry_assets = Some(fullmag_ir::GeometryAssetsIR {
            fdm_grid_assets: Vec::new(),
            fem_mesh_assets: Vec::new(),
            fem_domain_mesh_asset: Some(fullmag_ir::FemDomainMeshAssetIR {
                mesh_source: None,
                mesh: Some(fullmag_ir::MeshIR {
                    mesh_name: "preparation-strip".into(),
                    nodes: vec![
                        [0.0, 0.0, 0.0],
                        [1.0e-9, 0.0, 0.0],
                        [0.0, 1.0e-9, 0.0],
                        [0.0, 0.0, 1.0e-9],
                        [-2.0e-9, -2.0e-9, -2.0e-9],
                        [2.0e-9, -2.0e-9, -2.0e-9],
                        [-2.0e-9, 2.0e-9, -2.0e-9],
                        [-2.0e-9, -2.0e-9, 2.0e-9],
                    ],
                    cells: fullmag_ir::FemConnectivityIR::from_tet4(vec![
                        [0, 1, 2, 3],
                        [4, 5, 6, 7],
                    ]),
                    element_markers: vec![1, 0],
                    facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(vec![
                        [0, 1, 2],
                        [4, 5, 6],
                    ]),
                    boundary_markers: vec![1, 99],
                    periodic_boundary_pairs: Vec::new(),
                    periodic_node_pairs: Vec::new(),
                    per_domain_quality: std::collections::HashMap::new(),
                }),
                region_markers: vec![fullmag_ir::FemDomainRegionMarkerIR {
                    geometry_name: "strip".into(),
                    marker: 1,
                }],
                object_region_markers: Vec::new(),
                build_report: None,
            }),
        });
        problem.energy_terms = vec![fullmag_ir::EnergyTermIR::Exchange];
        if let fullmag_ir::StudyIR::TimeEvolution {
            dynamics: fullmag_ir::DynamicsIR::Llg { fixed_timestep, .. },
            ..
        } = &mut problem.study
        {
            *fixed_timestep = Some(1.0e-15);
        }
        problem
    }

    fn fingerprint(hex: char) -> String {
        format!("sha256:{}", hex.to_string().repeat(64))
    }

    fn native_evidence_for_problem(
        problem: &ProblemIR,
    ) -> fullmag_plan::NativeFemMeshSpaceEvidence {
        let execution_plan = fullmag_plan::plan(problem).expect("FEM fixture plans");
        let fullmag_ir::BackendPlanIR::Fem(fem) = execution_plan.backend_plan else {
            panic!("FEM fixture must resolve to FEM");
        };
        let mesh = fem.mesh;
        fullmag_plan::NativeFemMeshSpaceEvidence {
            abi_version: fullmag_plan::preparation::NATIVE_FEM_MESH_SPACE_ABI_VERSION,
            producer_id: fullmag_plan::preparation::NATIVE_FEM_MESH_SPACE_PRODUCER_ID.into(),
            schema_version: fullmag_plan::preparation::NATIVE_FEM_MESH_SPACE_SCHEMA_VERSION.into(),
            producer_version: fullmag_plan::preparation::NATIVE_FEM_MESH_SPACE_PRODUCER_VERSION
                .into(),
            mesh_matches_canonical_input: true,
            canonical_mesh_fingerprint: mesh.topology_fingerprint_v6(),
            topology_fingerprint: fingerprint('8'),
            marker_map_fingerprint: fingerprint('9'),
            quality_fingerprint: fingerprint('a'),
            space_fingerprint: fingerprint('b'),
            mesh_dimension: 3,
            fe_family: "H1".into(),
            fe_order: fem.fe_order,
            node_count: mesh.nodes.len() as u64,
            cell_count: mesh.cells.len() as u64,
            boundary_element_count: mesh.facets.len() as u64,
            local_dof_count: mesh.nodes.len() as u64,
            true_dof_count: mesh.nodes.len() as u64,
            quality_sample_count: 4,
            invalid_cell_count: 0,
            min_jacobian_determinant: 1.0e-27,
            max_jacobian_determinant: 2.0e-27,
        }
    }

    #[test]
    fn manual_accepted_run_allows_fdm_and_fem_preparation_before_release() {
        let mut fdm_problem = ProblemIR::bootstrap_example();
        fdm_problem.backend_policy.requested_backend = BackendTarget::Fdm;
        fdm_problem.object_regions.push(fullmag_ir::ObjectRegionIR {
            region_id: "strip:core".into(),
            owner_object: "strip".into(),
            name: "core".into(),
            shape: fullmag_ir::RegionShapeIR::Box {
                size: [200e-9, 20e-9, 6e-9],
                center: [0.0, 0.0, 0.0],
            },
            frame: fullmag_ir::RegionFrameIR::Object,
            enabled: true,
            priority: 1,
            mesh_policy: None,
            material_overrides: Vec::new(),
            texture_override: None,
            material_transition: None,
            realization_policy: fullmag_ir::RegionRealizationPolicyIR::Inherit,
        });
        let fdm = manual_run_snapshot(
            fdm_problem,
            "fdm",
            "run-manual-fdm-preparation",
        );
        let fdm_receipt = fdm
            .materialize_fdm_preparation_receipt("prep-manual-fdm", "step:run")
            .expect("manual FDM preparation must remain independent of Compute release");
        assert_eq!(fdm_receipt.plan.resolved_backend, BackendTarget::Fdm);
        assert_eq!(
            fdm_receipt
                .accepted_run_source
                .as_ref()
                .map(|source| source.run_id.as_str()),
            Some("run-manual-fdm-preparation")
        );

        let fem_problem = fem_problem_with_mesh_asset();
        let fem = manual_run_snapshot(
            fem_problem,
            "fem",
            "run-manual-fem-preparation",
        );
        let native = native_evidence_for_problem(fem.catalog.entries()[0].problem());
        let fem_receipt = fem
            .materialize_fem_preparation_receipt("prep-manual-fem", "step:run", &native)
            .expect("manual FEM preparation must remain independent of Compute release");
        assert_eq!(fem_receipt.plan.requested_backend, BackendTarget::Fem);
        assert_eq!(fem_receipt.plan.resolved_backend, BackendTarget::Fem);
        assert_eq!(
            fem_receipt
                .accepted_run_source
                .as_ref()
                .map(|source| source.run_id.as_str()),
            Some("run-manual-fem-preparation")
        );
    }
}

#[cfg(test)]
#[path = "study_tests.rs"]
mod tests;

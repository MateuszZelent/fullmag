//! Atomic journal adapter. A transition and its resulting application
//! checkpoint share one payload and one session-store publication.
use anyhow::{bail, Context, Result};
pub mod accepted_store;
pub mod study_inspection;
mod study_inspection_integrity;
mod study_retained_current;
mod study_source_preparation_binding;
pub use study_source_preparation_binding::{load_retained_source_preparation_binding, validate_retained_source_preparation_binding};
mod study_source_preparation;
pub use study_source_preparation::{encode_saved_antenna_source_preparation,
    load_saved_retained_current_source_preparation_with_store_evidence,
    load_saved_retained_current_source_preparation_with_pinned_evidence,
    AntennaSourcePreparationExport, AntennaSourcePreparationExportReceipt};
pub use study_retained_current::{load_saved_retained_current, load_saved_retained_current_with_evidence,
    load_saved_retained_current_with_pinned_evidence, load_saved_retained_current_with_store_evidence, LoadedSavedRetainedCurrent, LoadedSavedRetainedCurrentEvidence};
pub use study_inspection_integrity::{load_imported_study_evidence, load_imported_inspection, load_imported_retained_current_field_inspection, load_imported_study_evidence_for_inspection, ImportedStudyEvidence, load_saved_inspection, verify_saved_inspection};
pub mod application_attach;
pub mod application_service_status;
pub mod compute_node_probe;
pub mod cuda_device_identity;
pub(crate) mod nvml_gpu_partition;
pub mod development_cold_idle;
pub mod host_allocation;
pub mod host_runtime;
pub mod local_resources;
pub mod process_environment;
pub mod runtime_service_client;
#[cfg(target_os = "linux")]
pub mod worker_cgroup;
use fullmag_application::{
    CoordinatorMessage, CoordinatorTransition, WorkerEvent, COORDINATOR_TRANSITION_SCHEMA,
};
use fullmag_session::{
    canonical_json_sha256, CoordinatorGenesisCommitDisposition,
    CoordinatorJournalCommitDisposition, FmsCoordinatorGenesis, FmsCoordinatorJournalDirection,
    FmsCoordinatorJournalEntry, FmsCoordinatorWatermark, SessionStore,
    FMS_COORDINATOR_JOURNAL_SCHEMA,
};

/// Retry only a transient native store-writer conflict, or transient store
/// I/O (see `is_transient_store_io`), for the same idempotent operation.
/// Process- and thread-dependent jitter prevents
/// scheduler, supervisor, and worker loops from repeatedly colliding in
/// lockstep while preserving the five-second bounded wait.
pub fn retry_store_writer_busy<T>(operation: impl FnMut() -> Result<T>) -> Result<T> {
    retry_store_writer_busy_within(std::time::Duration::from_secs(5), operation)
}

/// Bounded wait for a running worker. The writer lock is a non-blocking,
/// unfair try-lock shared by the API, both schedulers and every worker, so a
/// five-second poll can starve while they keep taking it. Losing a computed
/// result to that is worse than waiting; schedulers keep the short bound and
/// defer their pass instead.
pub const WORKER_STORE_WRITER_WAIT: std::time::Duration = std::time::Duration::from_secs(120);

pub fn retry_store_writer_busy_within<T>(
    wait: std::time::Duration,
    mut operation: impl FnMut() -> Result<T>,
) -> Result<T> {
    use std::hash::{Hash, Hasher};
    use std::time::{Duration, Instant};

    let deadline = Instant::now() + wait;
    let mut attempt = 0_u64;
    loop {
        match operation() {
            Ok(value) => return Ok(value),
            Err(error)
                if (error
                    .chain()
                    .any(|cause| cause.is::<fullmag_session::StoreWriterBusy>())
                    || is_transient_store_io(&error))
                    && Instant::now() < deadline =>
            {
                let mut hasher = std::collections::hash_map::DefaultHasher::new();
                std::process::id().hash(&mut hasher);
                std::thread::current().id().hash(&mut hasher);
                attempt.hash(&mut hasher);
                let delay = Duration::from_millis(5 + hasher.finish() % 36);
                attempt = attempt.saturating_add(1);
                std::thread::sleep(delay.min(deadline.saturating_duration_since(Instant::now())));
            }
            Err(error) => return Err(error),
        }
    }
}

/// A store I/O failure that a later attempt can be expected to clear. A
/// Windows-folder (9p/drvfs) store under load intermittently fails reads and
/// writes with ENOMEM although the container has free memory; that failure
/// changes no durable state, so a scheduler can defer and retry the pass.
pub fn is_transient_store_io(error: &anyhow::Error) -> bool {
    const ENOMEM: i32 = 12;
    error.chain().any(|cause| {
        cause
            .downcast_ref::<std::io::Error>()
            .is_some_and(|io| io.raw_os_error() == Some(ENOMEM))
    })
}

/// Worker retry for idempotent store operations: a busy writer or transient
/// store I/O is waited for up to `WORKER_STORE_WRITER_WAIT`, and a file that
/// briefly reads as missing (an atomic replace seen through a Docker Desktop
/// host folder) for a few seconds. A genuinely missing file still fails after
/// that short bound.
pub fn retry_worker_store_transient<T>(mut operation: impl FnMut() -> Result<T>) -> Result<T> {
    use std::time::{Duration, Instant};

    let missing_deadline = Instant::now() + Duration::from_secs(3);
    loop {
        match retry_store_writer_busy_within(WORKER_STORE_WRITER_WAIT, &mut operation) {
            Err(error)
                if error.chain().any(|cause| {
                    cause
                        .downcast_ref::<std::io::Error>()
                        .is_some_and(|io| io.kind() == std::io::ErrorKind::NotFound)
                }) && Instant::now() < missing_deadline =>
            {
                std::thread::sleep(Duration::from_millis(50));
            }
            result => return result,
        }
    }
}

pub fn commit_worker_checkpoint(
    store: &SessionStore,
    claim: &fullmag_application::TaskClaim,
    checkpoint: &fullmag_application::WorkerInboxCheckpoint,
) -> Result<()> {
    fullmag_application::WorkerCommandInbox::restore(claim, checkpoint.clone())?;
    let record = fullmag_session::FmsWorkerInboxRecord::new(serde_json::to_value(checkpoint)?)?;
    store.commit_worker_inbox(&record)
}

/// Recovery never treats a missing record as permission to execute again.
pub fn recover_worker_inbox(
    store: &SessionStore,
    claim: &fullmag_application::TaskClaim,
) -> Result<fullmag_application::WorkerCommandInbox> {
    let _transaction = store.write_transaction()?;
    let catalog = store
        .read_run_catalog(claim.run_id.as_str())?
        .context("worker inbox run missing")?;
    let task = catalog
        .tasks
        .iter()
        .find(|task| task.task_id == claim.task_id.as_str())
        .context("worker inbox task missing")?;
    if task.attempt_id.as_deref() != Some(claim.attempt_id.as_str())
        || task.ownership_epoch != Some(claim.ownership_epoch.value())
    {
        bail!("worker inbox recovery claim is stale");
    }
    let empty = fullmag_application::WorkerCommandInbox::new(claim).checkpoint();
    let key = fullmag_session::FmsWorkerInboxRecord::new(serde_json::to_value(empty)?)?
        .relative_path()?;
    let bytes = store
        .read_document(&key)?
        .context("worker inbox checkpoint missing; execution requires reconciliation")?;
    let record: fullmag_session::FmsWorkerInboxRecord = serde_json::from_slice(&bytes)?;
    if record.relative_path()? != key {
        bail!("worker inbox checkpoint path mismatch");
    }
    let checkpoint = serde_json::from_value(record.payload)?;
    Ok(fullmag_application::WorkerCommandInbox::restore(
        claim, checkpoint,
    )?)
}

/// Preserve typed storage errors, including PublicationUncertain. Reading a
/// visible file after such an error is not proof of directory durability.
pub fn commit_transition(
    store: &SessionStore,
    transition: &CoordinatorTransition,
) -> Result<CoordinatorJournalCommitDisposition> {
    commit_transition_with_catalog_revision(store, transition).map(|(disposition, _)| disposition)
}

fn commit_transition_with_catalog_revision(
    store: &SessionStore,
    transition: &CoordinatorTransition,
) -> Result<(CoordinatorJournalCommitDisposition, u64)> {
    commit_transition_with_catalog_revision_and_snapshot(store, transition, None)
}

/// Commit a Prepare/Start transition using the accepted snapshot already
/// validated by its scheduler operation. Mutable run intent and dependency
/// state remain fenced again under the session-store writer.
pub(crate) fn commit_transition_with_accepted_snapshot(
    store: &SessionStore,
    transition: &CoordinatorTransition,
    accepted: &study::AcceptedStudySnapshot,
) -> Result<CoordinatorJournalCommitDisposition> {
    commit_transition_with_catalog_revision_and_snapshot(store, transition, Some(accepted))
        .map(|(disposition, _)| disposition)
}

fn commit_transition_with_catalog_revision_and_snapshot(
    store: &SessionStore,
    transition: &CoordinatorTransition,
    accepted: Option<&study::AcceptedStudySnapshot>,
) -> Result<(CoordinatorJournalCommitDisposition, u64)> {
    let dependencies = if let CoordinatorMessage::Command(envelope) = &transition.message {
        if matches!(
            &envelope.command,
            fullmag_application::WorkerCommand::Prepare { .. }
                | fullmag_application::WorkerCommand::Start
        ) {
            let claim = &transition.checkpoint.claim;
            Some(match accepted {
                Some(accepted) => study_completion::prepare_task_dependencies_from_snapshot(
                    store,
                    &claim.run_id,
                    claim.task_id.as_str(),
                    accepted,
                )?,
                None => study_completion::prepare_task_dependencies(
                    store,
                    &claim.run_id,
                    claim.task_id.as_str(),
                )?,
            })
        } else {
            None
        }
    } else {
        None
    };
    let _writer = store.write_transaction()?;
    if let Some(dependencies) = dependencies.as_ref() {
        dependencies.require_locked(store)?;
    }
    if let CoordinatorMessage::Event(envelope) = &transition.message {
        if matches!(&envelope.event, WorkerEvent::Completed { .. }) {
            study::validate_study_task_completion(store, &transition.checkpoint.claim)?;
        }
    }
    let mut entry = encode_transition(transition, chrono::Utc::now())?;
    if let Some(prior) =
        store.read_coordinator_journal_entry(&entry.run_id, entry.direction, &entry.entry_id)?
    {
        entry.created_at = prior.created_at;
    }
    let disposition = store.commit_coordinator_journal_entry(&entry)?;
    let (catalog, projected_task) =
        reconcile_coordinator_catalog_locked(store, &transition.checkpoint.claim)?;
    drop(_writer);
    solution_set::reconcile_study_solution(store, &transition.checkpoint.claim, &projected_task)?;
    Ok((disposition, catalog.revision))
}

/// Persist the zero-watermark checkpoint before exposing a newly admitted
/// coordinator claim to a worker transport.
pub fn commit_coordinator_genesis(
    store: &SessionStore,
    checkpoint: &fullmag_application::CoordinatorCheckpoint,
) -> Result<CoordinatorGenesisCommitDisposition> {
    fullmag_application::WorkerCoordinator::restore(checkpoint.clone(), &[], &[])?;
    let genesis = FmsCoordinatorGenesis::new(
        checkpoint.claim.run_id.as_str(),
        checkpoint.claim.task_id.as_str(),
        checkpoint.claim.attempt_id.as_str(),
        checkpoint.claim.ownership_epoch.value(),
        checkpoint.claim.lease.lease_token.as_str(),
        checkpoint.claim.lease.heartbeat_sequence,
        serde_json::to_value(checkpoint)?,
    )?;
    store.commit_coordinator_genesis(
        checkpoint.claim.run_id.as_str(),
        checkpoint.claim.task_id.as_str(),
        &genesis,
    )
}

fn encode_transition(
    transition: &CoordinatorTransition,
    created_at: chrono::DateTime<chrono::Utc>,
) -> Result<FmsCoordinatorJournalEntry> {
    if transition.schema_version != COORDINATOR_TRANSITION_SCHEMA {
        bail!("unsupported coordinator transition schema");
    }
    let checkpoint = &transition.checkpoint;
    if checkpoint.schema_version != fullmag_application::COORDINATOR_CHECKPOINT_SCHEMA {
        bail!("unsupported coordinator checkpoint schema");
    }
    let claim = checkpoint.claim.identity();
    if checkpoint.task.run_id != claim.run_id
        || checkpoint.task.task_id != claim.task_id
        || checkpoint.task.attempt_id.as_ref() != Some(&claim.attempt_id)
        || checkpoint.task.ownership_epoch != Some(claim.ownership_epoch)
    {
        bail!("coordinator checkpoint task identity mismatch");
    }
    checkpoint.task.fence(&checkpoint.claim)?;
    let (id, sequence, direction, terminal) = match &transition.message {
        CoordinatorMessage::Command(envelope) => {
            envelope.validate_for_claim(&claim)?;
            if checkpoint.command_sequence != envelope.sequence {
                bail!("command checkpoint watermark mismatch");
            }
            (
                &envelope.message_id,
                envelope.sequence,
                FmsCoordinatorJournalDirection::Command,
                false,
            )
        }
        CoordinatorMessage::Event(envelope) => {
            envelope.validate_for_claim(&claim)?;
            if checkpoint.event_sequence != envelope.sequence {
                bail!("event checkpoint watermark mismatch");
            }
            let terminal = matches!(
                envelope.event,
                WorkerEvent::Completed { .. }
                    | WorkerEvent::Failed { .. }
                    | WorkerEvent::Rejected { .. }
            );
            (
                &envelope.message_id,
                envelope.sequence,
                FmsCoordinatorJournalDirection::Event,
                terminal,
            )
        }
    };
    let payload = serde_json::to_value(transition)?;
    let entry = FmsCoordinatorJournalEntry {
        schema_version: FMS_COORDINATOR_JOURNAL_SCHEMA.into(),
        entry_id: id.clone(),
        run_id: claim.run_id.as_str().into(),
        task_id: claim.task_id.as_str().into(),
        attempt_id: claim.attempt_id.as_str().into(),
        ownership_epoch: claim.ownership_epoch.value(),
        lease_token: claim.lease_token.as_str().into(),
        direction,
        sequence,
        terminal,
        payload_sha256: canonical_json_sha256(&payload),
        payload,
        created_at,
    };
    Ok(entry)
}

pub struct RecoveredCoordinator {
    pub coordinator: fullmag_application::WorkerCoordinator,
    /// Original command identities for reconciliation, not automatic dispatch.
    pub commands: Vec<fullmag_application::WorkerCommandEnvelope>,
    /// Original event identities for deciding whether a process side effect began.
    pub events: Vec<fullmag_application::WorkerEventEnvelope>,
    pub catalog_revision: u64,
}

/// Repair the catalog projection from the complete durable journal. Journal
/// publication remains the source of truth; this can be repeated after a
/// process stops between the journal write and catalog projection.
pub fn reconcile_coordinator_catalog(
    store: &SessionStore,
    claim: &fullmag_application::TaskClaim,
) -> Result<fullmag_session::FmsRunCatalog> {
    let (catalog, projected_task) = {
        let _transaction = store.write_transaction()?;
        reconcile_coordinator_catalog_locked(store, claim)?
    };
    solution_set::reconcile_study_solution(store, claim, &projected_task)?;
    Ok(catalog)
}

/// Project only the mutable coordinator/catalog state under the caller's
/// writer. Portable result reconciliation must run after the outer writer
/// has been released, including when this follows a journal publication.
fn reconcile_coordinator_catalog_locked(
    store: &SessionStore,
    claim: &fullmag_application::TaskClaim,
) -> Result<(fullmag_session::FmsRunCatalog, fullmag_application::TaskRecord)> {
    use fullmag_application::{ObservationState as Observation, TaskLifecycle as Lifecycle};
    use fullmag_session::{
        FmsObservationState as StoredObservation, FmsTaskLifecycle as StoredLifecycle,
    };
    let recovered = recover_coordinator_locked(store, claim)?;
    let recovered_task = recovered.coordinator.task().clone();
    if recovered_task.lifecycle == fullmag_application::TaskLifecycle::Succeeded {
        study::validate_study_task_completion(store, claim)?;
    }
    let mut catalog = store
        .read_run_catalog(claim.run_id.as_str())?
        .context("coordinator catalog disappeared")?;
    let task = catalog
        .tasks
        .iter_mut()
        .find(|task| task.task_id == claim.task_id.as_str())
        .context("coordinator catalog task disappeared")?;
    if task.input_fingerprint != recovered_task.input_fingerprint
        || task.resource_id.as_deref() != Some(claim.lease.resource_id.as_str())
    {
        bail!("coordinator catalog input or resource identity mismatch");
    }
    let lifecycle = match recovered_task.lifecycle {
        Lifecycle::Accepted => StoredLifecycle::Accepted,
        Lifecycle::Queued => StoredLifecycle::Queued,
        Lifecycle::Preparing => StoredLifecycle::Preparing,
        Lifecycle::Running => StoredLifecycle::Running,
        Lifecycle::Stopping => StoredLifecycle::Stopping,
        Lifecycle::Succeeded => StoredLifecycle::Succeeded,
        Lifecycle::Failed => StoredLifecycle::Failed,
        Lifecycle::Cancelled => StoredLifecycle::Cancelled,
        Lifecycle::Interrupted => StoredLifecycle::Interrupted,
    };
    if matches!(
        task.lifecycle,
        StoredLifecycle::Succeeded
            | StoredLifecycle::Failed
            | StoredLifecycle::Cancelled
            | StoredLifecycle::Interrupted
    ) && task.lifecycle != lifecycle
    {
        bail!("coordinator recovery cannot replace a conflicting terminal catalog state");
    }
    let observation = recovered_task.observation.map(|value| match value {
        Observation::Live => StoredObservation::Live,
        Observation::Stale => StoredObservation::Stale,
        Observation::Disconnected => StoredObservation::Disconnected,
        Observation::Reconciling => StoredObservation::Reconciling,
    });
    let checkpoint = recovered.coordinator.checkpoint();
    let watermark = FmsCoordinatorWatermark {
        command_sequence: checkpoint.command_sequence,
        event_sequence: checkpoint.event_sequence,
    };
    let projected_watermark = Some(watermark);
    if task.lifecycle != lifecycle
        || task.observation != observation
        || task.coordinator_watermark != projected_watermark
    {
        task.lifecycle = lifecycle;
        task.observation = observation;
        task.coordinator_watermark = projected_watermark;
        catalog.revision = catalog
            .revision
            .checked_add(1)
            .context("run catalog revision exhausted")?;
        catalog.updated_at = chrono::Utc::now();
        store.commit_run_catalog(&catalog)?;
    }
    Ok((catalog, recovered_task))
}

/// Recover one current claim from a complete causal chain of transition
/// watermarks. Neither filesystem enumeration nor timestamps define order.
pub fn recover_coordinator(
    store: &SessionStore,
    claim: &fullmag_application::TaskClaim,
) -> Result<RecoveredCoordinator> {
    let _transaction = store.write_transaction()?;
    recover_coordinator_locked(store, claim)
}

/// Replay an exact coordinator under an existing shared store fence without repairs.
pub fn recover_coordinator_readonly(
    store: &SessionStore,
    claim: &fullmag_application::TaskClaim,
    transaction: &fullmag_session::ReadTransaction,
) -> Result<RecoveredCoordinator> {
    recover_coordinator_with_journal(store, claim, ||
        store.read_coordinator_journal_readonly(claim.run_id.as_str(), transaction))
}

/// Caller already holds this store handle's native writer.
pub(crate) fn recover_coordinator_locked(store: &SessionStore, claim: &fullmag_application::TaskClaim) -> Result<RecoveredCoordinator> {
    recover_coordinator_with_journal(store, claim, || store.read_coordinator_journal(claim.run_id.as_str()))
}

// Both writer recovery and shared cold reads replay the same validated causal chain.
fn recover_coordinator_with_journal(
    store: &SessionStore,
    claim: &fullmag_application::TaskClaim,
    read_journal: impl FnOnce() -> Result<Vec<fullmag_session::FmsCoordinatorJournalEntry>>,
) -> Result<RecoveredCoordinator> {
    let catalog = store
        .read_run_catalog(claim.run_id.as_str())?
        .context("coordinator recovery requires a run catalog")?;
    let task = catalog
        .tasks
        .iter()
        .find(|task| task.task_id == claim.task_id.as_str())
        .context("coordinator recovery task is missing")?;
    if task.attempt_id.as_deref() != Some(claim.attempt_id.as_str())
        || task.ownership_epoch != Some(claim.ownership_epoch.value())
    {
        bail!("coordinator recovery claim is stale");
    }
    let genesis_coordinator = if let Some(genesis) = &task.coordinator_genesis {
        if genesis.run_id != claim.run_id.as_str()
            || genesis.task_id != claim.task_id.as_str()
            || genesis.attempt_id != claim.attempt_id.as_str()
            || genesis.ownership_epoch != claim.ownership_epoch.value()
            || genesis.lease_token != claim.lease.lease_token.as_str()
        {
            bail!("coordinator genesis identity differs from the expected claim");
        }
        let checkpoint: fullmag_application::CoordinatorCheckpoint =
            serde_json::from_value(genesis.checkpoint.clone())?;
        if checkpoint.command_sequence != 0
            || checkpoint.event_sequence != 0
            || checkpoint.claim.identity() != claim.identity()
            || checkpoint.claim.lease.heartbeat_sequence != genesis.lease_heartbeat_sequence
        {
            bail!("coordinator genesis checkpoint differs from its durable identity");
        }
        Some(fullmag_application::WorkerCoordinator::restore(
            checkpoint,
            &[],
            &[],
        )?)
    } else {
        None
    };
    let mut transitions = Vec::new();
    for entry in read_journal()? {
        if entry.task_id != claim.task_id.as_str()
            || entry.attempt_id != claim.attempt_id.as_str()
            || entry.ownership_epoch != claim.ownership_epoch.value()
        {
            continue;
        }
        let transition: CoordinatorTransition = serde_json::from_value(entry.payload.clone())?;
        if encode_transition(&transition, entry.created_at)? != entry
            || transition.checkpoint.claim.identity() != claim.identity()
        {
            bail!("coordinator transition identity differs from journal or expected claim");
        }
        transitions.push(transition);
    }
    transitions.sort_by_key(|entry| {
        u128::from(entry.checkpoint.command_sequence) + u128::from(entry.checkpoint.event_sequence)
    });
    let mut commands = Vec::new();
    let mut events = Vec::new();
    let mut checkpoint = None;
    for transition in transitions {
        let mut expected_commands = commands.len() as u64;
        let mut expected_events = events.len() as u64;
        match &transition.message {
            CoordinatorMessage::Command(_) => expected_commands += 1,
            CoordinatorMessage::Event(_) => expected_events += 1,
        }
        if transition.checkpoint.command_sequence != expected_commands
            || transition.checkpoint.event_sequence != expected_events
        {
            bail!("coordinator journal has a missing or divergent transition");
        }
        match transition.message {
            CoordinatorMessage::Command(envelope) => commands.push(envelope),
            CoordinatorMessage::Event(envelope) => events.push(envelope),
        }
        checkpoint = Some(transition.checkpoint);
    }
    let coordinator = if let Some(checkpoint) = checkpoint {
        fullmag_application::WorkerCoordinator::restore(checkpoint, &commands, &events)?
    } else {
        let coordinator = genesis_coordinator
            .context("coordinator claim has no durable transitions or genesis")?;
        if coordinator.claim() != claim {
            bail!("empty coordinator journal has a stale durable genesis claim");
        }
        coordinator
    };
    if let Some(watermark) = task.coordinator_watermark {
        if watermark.command_sequence > commands.len() as u64
            || watermark.event_sequence > events.len() as u64
        {
            bail!("coordinator catalog watermark is ahead of the durable journal");
        }
    }
    Ok(RecoveredCoordinator {
        coordinator,
        commands,
        events,
        catalog_revision: catalog.revision,
    })
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum AcceptedTaskStopDisposition {
    Accepted,
    Replayed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AcceptedTaskStop {
    pub disposition: AcceptedTaskStopDisposition,
    pub command: fullmag_application::WorkerCommandEnvelope,
    pub catalog_revision: u64,
}

/// Durably request cancellation of the exact currently-owned task attempt.
/// Repeating the same reason while the task is already stopping returns the
/// original command. A different reason or a non-running lifecycle fails
/// closed instead of inventing a second control sequence.
pub fn request_accepted_task_stop(
    store: &SessionStore,
    run_id: &fullmag_application::RunId,
    task_id: &str,
    reason: &str,
) -> Result<AcceptedTaskStop> {
    request_accepted_task_stop_inner(store, run_id, task_id, reason, true)
}

/// A recorded pre-claim intent can stop its repaired, genuine admission
/// before Start. This does not authorize the legacy public Stop branch.
pub(crate) fn request_cancelled_admission_stop(
    store: &SessionStore,
    run_id: &fullmag_application::RunId,
    task_id: &str,
) -> Result<AcceptedTaskStop> {
    let intent = store
        .read_task_cancellation_intent(run_id.as_str(), task_id)?
        .context("pre-Start admission cancellation requires its durable intent")?;
    store.request_task_cancellation_intent(
        run_id.as_str(),
        task_id,
        &intent.cancellation_id,
        intent.expected_catalog_revision,
        &intent.reason,
    )?;
    request_accepted_task_stop_inner(store, run_id, task_id, &intent.reason, false)
}

/// Request Stop after the runtime-service failed/no-spawn recovery checks.
///
/// The caller must hold the startup, launch and owner locks and authenticate the
/// failed terminal owner, config, exact claim and lease, Pending/Closed launch
/// gate, and absence of both Started events and worker exit receipts. This is
/// only for that recovery path; ordinary Stop still requires a durable Start.
pub fn request_failed_no_spawn_task_stop(
    store: &SessionStore,
    run_id: &fullmag_application::RunId,
    task_id: &str,
    reason: &str,
) -> Result<AcceptedTaskStop> {
    request_accepted_task_stop_inner(store, run_id, task_id, reason, false)
}

fn request_accepted_task_stop_inner(
    store: &SessionStore,
    run_id: &fullmag_application::RunId,
    task_id: &str,
    reason: &str,
    require_start: bool,
) -> Result<AcceptedTaskStop> {
    if reason.trim().is_empty() {
        bail!("accepted task stop reason must not be empty");
    }
    // Contention must be retried before recovery, not only inside the Stop
    // publisher. Hold the same writer through claim validation, recovery and
    // commit so another stream cannot advance between them. Only acquiring
    // this fence is retried here; after a possible publication, the callback
    // below retries the exact same transition rather than creating a new Stop.
    let _stop_transaction = retry_store_writer_busy(|| store.write_transaction())
        .context("acquire accepted task Stop transaction")?;
    let claim = claim::load_current_task_claim(store, run_id, task_id)?;
    for _ in 0..8 {
        let recovered = recover_coordinator_locked(store, &claim)?;
        if recovered.coordinator.phase() == fullmag_application::CoordinatorPhase::Stopping {
            let existing = recovered
                .commands
                .iter()
                .find(|command| {
                    matches!(
                        &command.command,
                        fullmag_application::WorkerCommand::Stop { .. }
                    )
                })
                .context("stopping task has no durable Stop command")?;
            let fullmag_application::WorkerCommand::Stop {
                reason: existing_reason,
            } = &existing.command
            else {
                unreachable!("filtered Stop command")
            };
            if existing_reason != reason {
                bail!("accepted task already has a different durable Stop reason");
            }
            return Ok(AcceptedTaskStop {
                disposition: AcceptedTaskStopDisposition::Replayed,
                command: existing.clone(),
                catalog_revision: recovered.catalog_revision,
            });
        }
        if recovered.coordinator.phase() == fullmag_application::CoordinatorPhase::Running
            && recovered
                .events
                .iter()
                .any(|event| matches!(&event.event, fullmag_application::WorkerEvent::Completing))
        {
            bail!("accepted task is already completing");
        }
        if require_start
            && recovered.coordinator.phase() == fullmag_application::CoordinatorPhase::Preparing
            && !matches!(
                recovered.commands.last().map(|command| &command.command),
                Some(fullmag_application::WorkerCommand::Start)
            )
        {
            bail!("accepted task pre-start stop requires a durable Start command");
        }
        if !matches!(
            recovered.coordinator.phase(),
            fullmag_application::CoordinatorPhase::Preparing
                | fullmag_application::CoordinatorPhase::Running
        ) {
            bail!("accepted task stop requires a preparing or running task");
        }
        let mut coordinator =
            fullmag_application::DurableWorkerCoordinator::new(recovered.coordinator);
        let mut catalog_revision = None;
        let command = match coordinator.commit_command(
            fullmag_application::WorkerCommand::Stop {
                reason: reason.to_owned(),
            },
            None,
            |transition| {
                retry_store_writer_busy(|| {
                    commit_transition_with_catalog_revision(store, transition)
                })
                .map(|(_, revision)| {
                    catalog_revision = Some(revision);
                })
                .map_err(|error| {
                    fullmag_application::CoordinatorError::Invalid(format!("{error:#}"))
                })
            },
        ) {
            Ok(command) => command,
            Err(error)
                if error
                    .to_string()
                    .contains("coordinator journal cross-stream watermark changed") =>
            {
                continue;
            }
            Err(error) => return Err(anyhow::anyhow!(error.to_string())),
        };
        return Ok(AcceptedTaskStop {
            disposition: AcceptedTaskStopDisposition::Accepted,
            command,
            catalog_revision: catalog_revision
                .context("accepted task Stop commit did not return a catalog revision")?,
        });
    }
    bail!("accepted task Stop exceeded concurrent transition retry limit")
}

/// Immutable bytes accepted by Submit, independent of the active UI project.
pub struct AcceptedRunSnapshot {
    pub intent: fullmag_session::FmsRunIntent,
    pub specification: fullmag_application::RunSpecification,
    pub definition_bytes: Vec<u8>,
}

/// Model-bearing documents can contain an inline FEM mesh. Their bounded
/// decode budget is separate from the small control-plane metadata budget.
pub const MAX_ACCEPTED_MODEL_DOCUMENT_BYTES: u64 = 256 * 1024 * 1024;

/// Resolve the pinned definition; a missing CAS object never falls back to current.
pub fn load_accepted_run_snapshot(
    store: &SessionStore,
    run_id: &fullmag_application::RunId,
    project_id: &fullmag_application::ProjectId,
) -> Result<AcceptedRunSnapshot> {
    let intent = store
        .read_run_intent(run_id.as_str())?
        .context("accepted run intent is missing")?;
    load_accepted_run_snapshot_from_intent(store.cas(), intent, run_id, project_id)
}

/// Validate the same immutable intent against a read-only imported CAS.
/// This returns data only; it never grants scheduler or worker authority.
pub fn load_accepted_run_snapshot_from_intent(
    cas: &fullmag_session::CasStore,
    intent: fullmag_session::FmsRunIntent,
    run_id: &fullmag_application::RunId,
    project_id: &fullmag_application::ProjectId,
) -> Result<AcceptedRunSnapshot> {
    intent.validate()?;
    let specification: fullmag_application::RunSpecification =
        serde_json::from_value(intent.specification.clone())
            .context("accepted run specification is not typed")?;
    if specification.run_id != *run_id
        || specification.snapshot.project_id != *project_id
        || specification.fingerprint()? != intent.payload_sha256
    {
        bail!("accepted run specification identity or fingerprint differs from intent");
    }
    let definition_ref = intent
        .definition_object_ref
        .as_deref()
        .context("accepted run has no immutable definition object")?;
    if definition_ref != specification.snapshot.definition_sha256 {
        bail!("accepted run definition reference differs from snapshot");
    }
    let definition_bytes = cas
        .get_bounded(definition_ref, MAX_ACCEPTED_MODEL_DOCUMENT_BYTES)?
        .context("accepted run definition object is missing")?;
    Ok(AcceptedRunSnapshot {
        intent,
        specification,
        definition_bytes,
    })
}

pub mod python_runtime;

mod claim;
pub use claim::{
    commit_claimed_task_admission, commit_claimed_task_admission_with_host,
    load_current_task_claim, try_commit_claimed_task_admission_with_host,
    StaleTaskAdmissionCandidate,
};

mod scheduler;
pub use scheduler::{
    accepted_run_has_scheduler_ready_task, accepted_run_step_is_preparation_frontier,
    accepted_run_step_is_preparation_frontier_from_snapshot,
    accepted_run_step_is_scheduler_ready, accepted_run_step_is_scheduler_ready_from_snapshot,
    resume_next_admitted_accepted_task_with_host,
    schedule_next_ready_accepted_task, schedule_next_ready_accepted_task_with_host,
    ScheduledAcceptedTask,
};

mod solution_set;
pub use solution_set::retained_current_tensor::{read_saved_retained_current_geometry_parent, SavedRetainedCurrentGeometryParent};
pub use solution_set::publish_recovered_inspection_solution;
mod study_field_tensor;
pub use study_field_tensor::{
    read_pinned_study_tensor_snapshot, verify_pinned_native_fem_snapshot,
};
mod study_inspection_tensor;
mod study_inspection_sample_geometry;
mod study_dataset;

pub mod frozen_stage_lifecycle;
mod study_output_history;
pub use study_output_history::read_manifest_projection as read_study_output_manifest_projection;
pub use study_output_history::{load_study_observation_runtime_v2, LoadedStudyObservationRuntimeV2, ObservationSourcePayloadV2, PreparedTerminalPublicationV4, prepare_terminal_study_publication, validate_prepared_terminal_publication};
mod study;
mod study_snapshot_cache;
mod study_completion;
pub use study::{
    materialize_accepted_worker_execution_plan,
    load_accepted_study_snapshot, load_accepted_study_snapshot_from_run, load_accepted_worker_step,
    load_accepted_worker_step_for_start, load_accepted_worker_step_for_start_from_snapshot,
    load_study_observation_runtime, publish_accepted_task_prepare, publish_accepted_task_start,
    publish_study_outputs, publish_terminal_study_outputs, queue_accepted_study_task, resolve_accepted_study_inputs,
    validate_requested_execution, validate_study_task_completion, AcceptedStudySnapshot,
    AcceptedWorkerStep, LoadedStudyObservationRuntime, ObservationSourcePayload,
    QueuedAcceptedStudyTask, StudyOutputPayload, ACCEPTED_TASK_AWAITING_DEPENDENCY_RESOLUTION,
};

mod worker_inbox;
pub use worker_inbox::DurableWorkerInbox;

#[cfg(test)]
mod tests {
    use super::*;
    use fullmag_application::{
        CoordinatorError, CoordinatorPhase, DurableWorkerCoordinator, ResourceBudget, ResourceKind,
        ResourceLease, RunId, TaskLifecycle, TaskRecord, WorkerCommand, WorkerCoordinator,
        WorkerEvent, WorkerEventEnvelope, WORKER_PROTOCOL_SCHEMA,
    };
    use fullmag_session::{
        FmsCoordinatorWatermark, FmsResourceBudget, FmsResourceKind, FmsResourceLease,
        FmsResourceLeaseState, FmsRunCatalog, FmsTaskCatalogEntry, FmsTaskLifecycle,
        FmsTaskReadiness, FMS_RESOURCE_LEASE_SCHEMA, FMS_RUN_CATALOG_SCHEMA,
    };

    #[test]
    fn only_enomem_store_io_is_transient() {
        let enomem = anyhow::Error::from(std::io::Error::from_raw_os_error(12))
            .context("reconcile released host reservations");
        assert!(super::is_transient_store_io(&enomem));
        let denied =
            anyhow::Error::from(std::io::Error::from(std::io::ErrorKind::PermissionDenied));
        assert!(!super::is_transient_store_io(&denied));
        assert!(!super::is_transient_store_io(&anyhow::anyhow!(
            "lease identity differs"
        )));
    }

    #[test]
    fn store_retry_repeats_transient_enomem_but_not_other_io_errors() {
        let mut attempts = 0;
        let value = super::retry_store_writer_busy(|| {
            attempts += 1;
            if attempts < 3 {
                return Err(anyhow::Error::from(std::io::Error::from_raw_os_error(12))
                    .context("list run intents"));
            }
            Ok(attempts)
        })
        .unwrap();
        assert_eq!(value, 3);

        let mut denied_attempts = 0;
        let error = super::retry_store_writer_busy(|| -> anyhow::Result<()> {
            denied_attempts += 1;
            Err(std::io::Error::from(std::io::ErrorKind::PermissionDenied).into())
        })
        .unwrap_err();
        assert_eq!(denied_attempts, 1);
        assert!(!super::is_transient_store_io(&error));
    }

    #[test]
    fn accepted_task_stop_is_durable_idempotent_and_terminal_after_stopped_event() {
        assert_task_stop_recovery(false, false);
    }

    #[test]
    fn failed_no_spawn_stop_without_start_preserves_public_stop_fence_and_replays() {
        assert_task_stop_recovery(true, false);
    }

    #[test]
    fn accepted_task_stop_waits_for_writer_before_recovery_without_duplicating_stop() {
        assert_task_stop_recovery(false, true);
    }

    fn assert_task_stop_recovery(no_spawn: bool, writer_contention: bool) {
        let directory = tempfile::tempdir().unwrap();
        let store = SessionStore::open(directory.path().join("store")).unwrap();
        let mut task =
            TaskRecord::new(RunId::parse("run-operator-stop").unwrap(), "a".repeat(64)).unwrap();
        task.queue().unwrap();
        let claim = task
            .claim(
                ResourceLease::new(
                    "cpu-stop",
                    ResourceKind::Cpu,
                    ResourceBudget {
                        cpu_millis: 100,
                        memory_bytes: 1,
                        gpu_memory_bytes: 0,
                        storage_bytes: 1,
                    },
                )
                .unwrap(),
            )
            .unwrap();
        let now = chrono::Utc::now();
        store
            .commit_run_catalog(&FmsRunCatalog {
                schema_version: FMS_RUN_CATALOG_SCHEMA.into(),
                run_id: claim.run_id.as_str().into(),
                revision: 1,
                updated_at: now,
                tasks: vec![FmsTaskCatalogEntry {
                    task_id: claim.task_id.as_str().into(),
                    input_fingerprint: "a".repeat(64),
                    lifecycle: FmsTaskLifecycle::Preparing,
                    readiness: FmsTaskReadiness::Ready,
                    observation: None,
                    attempt_id: Some(claim.attempt_id.as_str().into()),
                    ownership_epoch: Some(claim.ownership_epoch.value()),
                    resolved_input_fingerprint: None,
                    artifact_ids: Vec::new(),
                    resource_id: Some(claim.lease.resource_id.clone()),
                    coordinator_watermark: Some(FmsCoordinatorWatermark::default()),
                    coordinator_genesis: None,
                }],
            })
            .unwrap();
        let durable_lease = FmsResourceLease {
            schema_version: FMS_RESOURCE_LEASE_SCHEMA.into(),
            resource_id: claim.lease.resource_id.clone(),
            kind: FmsResourceKind::Cpu,
            budget: FmsResourceBudget {
                cpu_millis: 100,
                memory_bytes: 1,
                gpu_memory_bytes: 0,
                storage_bytes: 1,
            },
            run_id: claim.run_id.as_str().into(),
            task_id: claim.task_id.as_str().into(),
            attempt_id: claim.attempt_id.as_str().into(),
            ownership_epoch: claim.ownership_epoch.value(),
            lease_token: claim.lease.lease_token.as_str().into(),
            state: FmsResourceLeaseState::Active,
            acquired_at: now,
            heartbeat_at: now,
            heartbeat_sequence: 0,
            released_at: None,
            host_launch_binding: None,
        };
        store.commit_resource_lease(&durable_lease).unwrap();

        let mut coordinator =
            DurableWorkerCoordinator::new(WorkerCoordinator::new(task, claim.clone()).unwrap());
        commit_coordinator_genesis(&store, &coordinator.checkpoint()).unwrap();
        if !no_spawn {
            coordinator
                .commit_command(WorkerCommand::Start, None, |transition| {
                    commit_transition(&store, transition)
                        .map(|_| ())
                        .map_err(|error| CoordinatorError::Invalid(format!("{error:#}")))
                })
                .unwrap();
            coordinator
                .commit_event(
                    WorkerEventEnvelope {
                        schema_version: WORKER_PROTOCOL_SCHEMA.into(),
                        message_id: "event-started-operator-stop".into(),
                        sequence: 1,
                        claim: claim.identity(),
                        event: WorkerEvent::Started,
                    },
                    |transition| {
                        commit_transition(&store, transition)
                            .map(|_| ())
                            .map_err(|error| CoordinatorError::Invalid(format!("{error:#}")))
                    },
                )
                .unwrap();
        } else {
            let receipt = fullmag_application::materialize_fdm_preparation_from_problem(
                "prep-failed-no-spawn",
                1,
                &fullmag_ir::ProblemIR::bootstrap_example(),
                &serde_json::json!({}),
            )
            .unwrap();
            let binding = fullmag_application::PreparationBinding::from_receipt(&receipt).unwrap();
            let resolved = fullmag_application::ResolvedTaskInput {
                schema_version: fullmag_application::RESOLVED_TASK_INPUT_SCHEMA.into(),
                run_id: claim.run_id.clone(),
                task_id: claim.task_id.clone(),
                attempt_id: claim.attempt_id.clone(),
                ownership_epoch: claim.ownership_epoch,
                specification_fingerprint: "a".repeat(64),
                plan_fingerprint: binding.plan_fingerprint.trim_start_matches("sha256:").into(),
                requested_execution: fullmag_application::RequestedExecution {
                    backend: "fdm".into(),
                    device: "cpu".into(),
                    precision: "double".into(),
                    mode: "strict".into(),
                    minimum_resources: None,
                },
                preparation: binding,
                inputs: Default::default(),
                frozen_stage_context: None,
            };
            let prepare = coordinator
                .commit_command(
                    WorkerCommand::Prepare { resolved_input: resolved },
                    Some(&receipt),
                    |transition| {
                        commit_transition(&store, transition)
                            .map(|_| ())
                            .map_err(|error| CoordinatorError::Invalid(format!("{error:#}")))
                    },
                )
                .unwrap();
            assert_eq!(prepare.sequence, 1);
            let error = request_accepted_task_stop(
                &store,
                &claim.run_id,
                claim.task_id.as_str(),
                "operator requested cancellation",
            )
            .unwrap_err();
            assert!(error.to_string().contains("requires a durable Start"));
            assert_eq!(
                recover_coordinator(&store, &claim).unwrap().commands,
                vec![prepare]
            );
        }
        let request_stop = if no_spawn {
            request_failed_no_spawn_task_stop
        } else {
            request_accepted_task_stop
        };

        let competing_writer = if writer_contention {
            let root = store.root().to_path_buf();
            let (ready, acquired) = std::sync::mpsc::sync_channel(0);
            let holder = std::thread::spawn(move || {
                let competing = SessionStore::open_existing(root).unwrap();
                let transaction = competing.write_transaction().unwrap();
                ready.send(()).unwrap();
                std::thread::sleep(std::time::Duration::from_millis(100));
                drop(transaction);
            });
            acquired.recv().unwrap();
            Some(holder)
        } else { None };
        let accepted = request_stop(
            &store,
            &claim.run_id,
            claim.task_id.as_str(),
            "operator requested cancellation",
        )
        .unwrap();
        if let Some(holder) = competing_writer { holder.join().unwrap(); }
        assert_eq!(accepted.disposition, AcceptedTaskStopDisposition::Accepted);
        assert_eq!(accepted.catalog_revision, if no_spawn { 4 } else { 5 });
        assert_eq!(accepted.command.sequence, 2);
        assert!(matches!(
            accepted.command.command,
            WorkerCommand::Stop { .. }
        ));
        let replayed = request_stop(
            &store,
            &claim.run_id,
            claim.task_id.as_str(),
            "operator requested cancellation",
        )
        .unwrap();
        assert_eq!(replayed.disposition, AcceptedTaskStopDisposition::Replayed);
        assert_eq!(replayed.catalog_revision, accepted.catalog_revision);
        assert_eq!(replayed.command, accepted.command);
        assert!(request_stop(
            &store,
            &claim.run_id,
            claim.task_id.as_str(),
            "different operator reason",
        )
        .is_err());

        let current_claim =
            load_current_task_claim(&store, &claim.run_id, claim.task_id.as_str()).unwrap();
        let recovered = recover_coordinator(&store, &current_claim).unwrap();
        assert_eq!(recovered.coordinator.phase(), CoordinatorPhase::Stopping);
        assert_eq!(recovered.commands.iter().filter(|command|
            matches!(&command.command, WorkerCommand::Stop { .. })).count(), 1);
        let mut stopping = DurableWorkerCoordinator::new(recovered.coordinator);
        stopping
            .commit_event(
                WorkerEventEnvelope {
                    schema_version: WORKER_PROTOCOL_SCHEMA.into(),
                    message_id: "event-stopped-operator-stop".into(),
                    sequence: if no_spawn { 1 } else { 2 },
                    claim: claim.identity(),
                    event: WorkerEvent::Stopped,
                },
                |transition| {
                    commit_transition(&store, transition)
                        .map(|_| ())
                        .map_err(|error| CoordinatorError::Invalid(format!("{error:#}")))
                },
            )
            .unwrap();
        assert_eq!(stopping.phase(), CoordinatorPhase::Terminal);
        assert_eq!(
            stopping.checkpoint().task.lifecycle,
            TaskLifecycle::Cancelled
        );
        let catalog = store
            .read_run_catalog(claim.run_id.as_str())
            .unwrap()
            .unwrap();
        assert_eq!(catalog.tasks[0].lifecycle, FmsTaskLifecycle::Cancelled);
        store.release_resource_lease(&durable_lease).unwrap();
        let owner_before = std::fs::read(store.root().join("WRITER.owner.json")).unwrap();
        let catalog_before = std::fs::read(store.root().join(format!("runs/{}/run_catalog.json", claim.run_id.as_str()))).unwrap();
        let transaction = store.read_transaction().unwrap();
        // The writer getter conflicts with this shared snapshot: cold replay must use the guarded reader.
        assert!(store.read_coordinator_journal(claim.run_id.as_str()).is_err());
        let shared = recover_coordinator_with_journal(&store, &current_claim, ||
            store.read_coordinator_journal_readonly(claim.run_id.as_str(), &transaction)).unwrap();
        assert_eq!(shared.coordinator.task().lifecycle, TaskLifecycle::Cancelled);
        assert_eq!(shared.coordinator.checkpoint(), stopping.checkpoint());
        assert_eq!(std::fs::read(store.root().join("WRITER.owner.json")).unwrap(), owner_before);
        assert_eq!(std::fs::read(store.root().join(format!("runs/{}/run_catalog.json", claim.run_id.as_str()))).unwrap(), catalog_before);
    }
}

mod study_retained_current_field;
pub use study_retained_current_field::{validate_retained_current_field_output, validate_retained_preparation_field_bundle, validate_retained_direct_field_bundle, load_saved_retained_current_field_inspection};

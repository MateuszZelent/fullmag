import { act, type ReactNode } from "react";
import { createRoot, hydrateRoot } from "react-dom/client";
import { renderToStaticMarkup, renderToString } from "react-dom/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

import type { DomainMetaResource, PlanarFieldMetaResource, VisualizationStateResource } from "@/kernel/api/apiTypes";
import { installSimulationPreparationTestDom } from "@/kernel/layout/simulationPreparationTestDom.test-support";
import type { Selection } from "@/kernel/selection/selectionTypes";
import { fieldMapSurfaceStore } from "@/kernel/visualization/fieldMapSurfaceStore";

import FieldMapModule from "./FieldMapModule";
import { getRegisteredFieldMapCapture } from "./fieldMapCaptureRegistry";

const mocks = vi.hoisted(() => ({
  meta: vi.fn(),
  metaData: new Map<boolean, unknown>(),
  scalarData: { data: new ArrayBuffer(8), etag: "scalar-authoritative" },
  projectionStatus: vi.fn((meta: { fold_count: number; non_injective: boolean; overlap_count: number }) =>
    meta.non_injective || meta.fold_count > 0 || meta.overlap_count > 0 ? "ambiguous" : "resolved"),
  metaAvailable: true,
  domain: null as DomainMetaResource | null,
  section: null as PlanarFieldMetaResource["section"] | null,
  probeData: null as null | { occupancy: string; scalar: number | null; u_m: number; v_m: number },
  queuePatch: vi.fn(),
  renderModel: vi.fn(),
  renderReady: false,
  scalarPending: false,
  metaPending: false,
  sourceDefinitionHash: null as string | null,
  selection: null as unknown as Selection,
  surface: vi.fn(),
  visualization: {
    data: null as Record<string, unknown> | null,
    error: null as Error | null,
    status: "loading" as "error" | "loading" | "ready",
    optimisticData: null as Record<string, unknown> | null,
  },
}));

vi.mock("@/kernel/KernelContext", async (importOriginal) => {
  const { ObjectVisualizationController } = await import("@/kernel/visualization/ObjectVisualizationController");
  const visualization = new ObjectVisualizationController();
  return {
    ...(await importOriginal<typeof import("@/kernel/KernelContext")>()),
    useKernel: () => ({
      api: { resourceCacheScope: "field-map-test" },
      layout: { get: () => ({ activeViewportMainModuleId: "field-map" }) },
      visualization,
      visualizationSync: { queuePatch: mocks.queuePatch },
    }),
  };
});

vi.mock("@/kernel/api/codecs", () => ({
  decodeFieldVector: () => ({ values: new Float64Array([1]) }),
}));

vi.mock("./model/fieldMapRenderModel", () => ({
  buildFieldMapRenderModel: (input: unknown) => {
    const override = mocks.renderModel(input);
    return override ?? {
      diagnostics: [],
      display: { axisUnit: "m", legendUnit: "A/m", probeScale: 1 },
      layers: (input as { layers: unknown }).layers,
      range: null,
    };
  },
  normalizePlanarColorRange: () => null,
  projectPlanarVectors: () => null,
  resolveFieldMapAuxiliaryDiagnostics: () => [],
  surfaceProjectionStatus: mocks.projectionStatus,
}));

vi.mock("./renderer/PlanarSurface", () => ({
  PlanarSurface: ({
    model,
    probeOverlay,
  }: {
    model: unknown;
    probeOverlay?: ReactNode;
  }) => {
    mocks.surface(model);
    return (
      <div className="fm-field-map__canvas-stack">
        <output data-planar-render-layers={JSON.stringify((model as { layers: unknown }).layers)} />
        {probeOverlay}
      </div>
    );
  },
}));

vi.mock("@/kernel/resources/planarFieldResources", () => ({
  planarFieldQueryFromMeta: () => ({
    ok: true,
    query: {
      component: "magnitude",
      quality: "interactive",
      resolution_x: 256,
      resolution_y: 128,
      scope_kind: "monitor_target",
      vector_budget: 512,
    },
  }),
  usePlanarFieldMetaResource: (...args: unknown[]) => {
    mocks.meta(...args);
    const requestedSource = args[1] as { kind?: string } | undefined;
    const isDefault = requestedSource?.kind === "default";
    const resource = mocks.renderReady && mocks.metaAvailable && !mocks.metaPending
      ? {
          data: {
            canonical_unit: "A/m",
            etag: "meta-authoritative",
            field_backend: "fdm",
            field_device: "cpu",
            field_precision: "double",
            field_source: "live",
            field_revision: "4",
            fold_count: 0,
            frame: {
              bounds_uv_m: [0, 1, 0, 1],
              normal: [0, 0, 1],
              origin_m: isDefault ? [11, 22, 32] : [0, 0, 0],
              u_axis: [1, 0, 0],
              v_axis: [0, 1, 0],
            },
            mesh_overlay_descriptor: {
              available: true,
              boundary_classification: "exact",
              codec: "fmcs.v4",
            },
            operator: { kind: "plane_sample" },
            source: isDefault
              ? {
                  default_slice_hash: mocks.sourceDefinitionHash ?? "default-slice-hash",
                  default_slice_revision: "3",
                  domain_generation_id: "domain-generation-1",
                  kind: "default",
                }
              : {
                  kind: "monitor",
                  monitor_hash: mocks.sourceDefinitionHash ?? "monitor-hash",
                  monitor_id: "plane-1",
                  monitor_revision: "2",
                },
            overlap_count: 0,
            resolution: [256, 128],
            section: mocks.section,
            sample_token: "planar-sample-v3:current",
            sampling_execution: "cpu",
          },
          error: null,
          status: "ready",
        }
      : { data: null, error: null, status: mocks.renderReady ? "loading" : "idle" };
    // Resource hooks retain the same data object until its revision changes.
    if (resource.data) {
      const cached = mocks.metaData.get(isDefault) as { source?: unknown } | undefined;
      if (!cached || JSON.stringify(cached.source) !== JSON.stringify(resource.data.source)) {
        mocks.metaData.set(isDefault, resource.data);
      }
      return { ...resource, data: mocks.metaData.get(isDefault) };
    }
    return resource;
  },
  // Auxiliary layers settle with the sample: since PR 350 a frame is
  // published only after every requested layer finished loading.
  usePlanarMaskResource: () => ({ data: null, error: null, status: mocks.renderReady ? "ready" : "idle" }),
  usePlanarMeshOverlayResource: () => ({ data: null, error: null, status: mocks.renderReady ? "ready" : "idle" }),
  usePlanarProbeResource: () => ({ data: mocks.probeData, error: null, status: mocks.probeData ? "ready" : "idle" }),
  usePlanarProfileResource: () => ({ data: null, error: null, status: "idle" }),
  usePlanarScalarResource: () => mocks.renderReady && !mocks.scalarPending
    ? { data: mocks.scalarData, error: null, status: "ready" }
    : { data: null, error: null, status: "idle" },
  usePlanarVectorResource: () => ({ data: null, error: null, status: mocks.renderReady ? "ready" : "idle" }),
}));

vi.mock("@/kernel/resources/planarMonitorResources", () => ({
  usePlanarMonitorResource: () => ({ data: null, error: null, status: "idle" }),
  usePlanarMonitorsResource: () => ({
    data: { monitors: [{ id: "plane-1" }] },
    error: null,
    status: "ready",
  }),
}));

vi.mock("@/kernel/resources/geometryLifecycleResources", () => ({
  useDomainMetaResource: () => ({
    data: mocks.domain,
    error: null,
    status: mocks.domain ? "ready" : "idle",
  }),
}));

vi.mock("@/kernel/resources/studyRuntimeResources", () => ({
  useFieldCatalogResource: () => ({ data: null, error: null, status: "idle" }),
  useHysteresisPointsResource: () => ({ data: null, error: null, status: "idle" }),
  useQuantityCatalogResource: () => ({ data: null, error: null, status: "idle" }),
}));

vi.mock("@/kernel/resources/useGeometryRealizationResource", () => ({
  useGeometryRealizationResource: () => ({ data: null, error: null, status: "idle" }),
}));

vi.mock("@/kernel/resources/useSessionStatus", async (importOriginal) => ({
  ...(await importOriginal<typeof import("@/kernel/resources/useSessionStatus")>()),
  useSessionStatusSelector: () => null,
}));

vi.mock("@/kernel/resources/useSessionScopedResourceKey", () => ({
  useSessionScopedResourceKey: () => ({
    resourceKey: "session=A&epoch=1&request_scope_epoch=api:1|planar-render-frame",
    sessionIdentity: { sessionId: "A", sessionEpoch: "1", requestScopeEpoch: "api:1" },
  }),
}));

vi.mock("@/kernel/selection/useSelection", () => ({
  useSelectionSelector: (selector: (selection: Selection) => unknown) =>
    selector(mocks.selection),
}));

vi.mock("@/kernel/visualization/useVisualizationStateResource", () => ({
  useVisualizationStateResource: () => mocks.visualization,
}));

describe("FieldMapModule planar state ownership", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    fieldMapSurfaceStore.reset();
    mocks.metaData.clear();
    mocks.renderModel.mockReset();
    mocks.visualization.data = null;
    mocks.visualization.error = null;
    mocks.visualization.status = "loading";
    mocks.visualization.optimisticData = null;
    mocks.renderReady = false;
    mocks.metaAvailable = true;
    mocks.domain = null;
    mocks.section = null;
    mocks.scalarPending = false;
    mocks.metaPending = false;
    mocks.sourceDefinitionHash = null;
    mocks.probeData = null;
    mocks.selection = emptySelection();
  });

  it("does not invent a quantity or component while the server profile is loading", () => {
    const html = renderToStaticMarkup(<FieldMapModule />);

    expect(html).toContain("Loading planar visualization state");
    expect(html).not.toContain("magnitude");
    expect(mocks.meta).toHaveBeenCalledWith("", { kind: "default" }, expect.any(Object), {
      enabled: false,
    });
  });

  it("registers and releases the current session capture with the mounted 2D module", async () => {
    const sessionScopeKey = "session=A&epoch=1&request_scope_epoch=api%3A1";
    const dom = installSimulationPreparationTestDom();
    const container = dom.document.createElement("div");
    const root = createRoot(container as unknown as Element);
    try {
      await act(async () => root.render(<FieldMapModule />));
      expect(getRegisteredFieldMapCapture(sessionScopeKey)).not.toBeNull();

      await act(async () => root.unmount());
      expect(getRegisteredFieldMapCapture(sessionScopeKey)).toBeNull();
    } finally {
      dom.restore();
    }
  });

  it("keeps the retained frame without reading missing metadata during refresh", async () => {
    mocks.visualization.data = {
      planar: {
        component: "magnitude", quantity_id: "m", source: { kind: "default" },
        colormap: "viridis", range: { mode: "auto" },
        interaction: { pan_u_m: 0, pan_v_m: 0, zoom: 1 },
        vector_style: { color_mode: "orientation", length_mode: "uniform", scale: 1 },
        default_slice: { operator: { kind: "plane_sample" }, plane: "xy", position_fraction: 0.5 },
        layers: { raster: true, mesh: false, vectors: false },
        resolution: { width: 256, height: 128 }, view_scope: { kind: "monitor_target" },
      },
    };
    mocks.visualization.status = "ready";
    mocks.renderReady = true;
    const dom = installSimulationPreparationTestDom();
    const container = dom.document.createElement("div");
    const root = createRoot(container as unknown as Element);
    try {
      await act(async () => root.render(<FieldMapModule />));
      expect(mocks.projectionStatus).toHaveBeenCalled();
      mocks.projectionStatus.mockClear();
      mocks.renderReady = false;
      await act(async () => root.render(<FieldMapModule />));
      expect(container.innerHTML).toContain("fm-field-map__canvas-stack");
      expect(mocks.projectionStatus).not.toHaveBeenCalled();
      const previous = mocks.visualization.data!;
      mocks.visualization.data = {
        ...previous,
        planar: { ...(previous.planar as object), component: "x" },
      };
      await act(async () => root.render(<FieldMapModule />));
      expect(container.innerHTML).not.toContain("fm-field-map__canvas-stack");
    } finally {
      await act(async () => root.unmount());
      dom.restore();
    }
  });

  it("hydrates the same loading snapshot without reading client-only field-map identity", async () => {
    const serverHtml = renderToString(<FieldMapModule />);
    const dom = installSimulationPreparationTestDom();
    const container = dom.document.createElement("div");
    (container as unknown as { innerHTML: string }).innerHTML = serverHtml;
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => undefined);
    let root: ReturnType<typeof hydrateRoot>;
    try {
      await act(async () => {
        root = hydrateRoot(container as unknown as Element, <FieldMapModule />);
        await Promise.resolve();
      });

      expect(serverHtml).toContain("Loading planar visualization state");
      expect(consoleError.mock.calls.flat().join(" ")).not.toContain("hydration");
    } finally {
      await act(async () => root!.unmount());
      consoleError.mockRestore();
      dom.restore();
    }
  });

  it("renders the default source without selecting the first monitor", async () => {
    mocks.visualization.data = {
      planar: {
        component: "magnitude",
        layers: { mesh: true, vectors: false },
        quantity_id: "m",
        resolution: { height: 128, width: 256 },
        source: { kind: "default" },
        default_slice: {
          operator: { kind: "plane_sample" },
          plane: "xy",
          position_fraction: 0.5,
        },
        view_scope: { kind: "monitor_target" },
      },
    };
    mocks.visualization.status = "ready";
    mocks.visualization.optimisticData = null;
    const dom = installSimulationPreparationTestDom();
    const container = dom.document.createElement("div");
    const root = createRoot(container as unknown as Element);
    try {
      await act(async () => {
        root.render(<FieldMapModule />);
        await Promise.resolve();
      });

      expect(mocks.queuePatch).not.toHaveBeenCalled();
      expect(mocks.meta).toHaveBeenCalledWith(
        "m",
        expect.objectContaining({ kind: "default", sliceKey: expect.any(String) }),
        expect.any(Object),
        { enabled: true },
      );
    } finally {
      await act(async () => root.unmount());
      dom.restore();
    }
  });

  it("publishes base sample Airbox geometry instead of the magnetic domain grid", async () => {
    const airboxPlanar = {
      colormap: "viridis",
      component: "magnitude",
      default_slice: {
        operator: { kind: "plane_sample" },
        plane: "xy",
        position_fraction: 0.5,
      },
      interaction: { pan_u_m: 0, pan_v_m: 0, zoom: 1 },
      layers: {
        boundaries: false,
        bounds: true,
        contours: false,
        mesh: true,
        points: false,
        probes: false,
        raster: true,
        vectors: false,
      },
      point_style: { color: "#ffffff", opacity: 1, size: 1 },
      quality: "interactive",
      quantity_id: "m",
      resolution: { height: 128, vector_budget: 512, width: 256 },
      source: { kind: "default" },
      vector_style: {
        color_mode: "orientation",
        length_mode: "uniform",
        monochrome_color: "#ffffff",
        opacity: 1,
        scale: 1,
        thickness: 1,
      },
      view_scope: { kind: "airbox" },
      viewport_colorbar_visible: true,
      visible: true,
      wireframe_style: { color: "#ffffff", opacity: 1 },
    } satisfies NonNullable<VisualizationStateResource["planar"]>;
    mocks.visualization.data = {
      planar: airboxPlanar,
    };
    mocks.visualization.status = "ready";
    mocks.renderReady = true;
    mocks.domain = {
      bounds: { min: [0, 0, 10e-9], max: [100e-9, 100e-9, 40e-9] },
      discretization: "fdm",
      grid: {
        origin: [0, 0, 10e-9],
        shape: [40, 40, 12],
        spacing: [2.5e-9, 2.5e-9, 2.5e-9],
      },
    } as unknown as DomainMetaResource;
    mocks.section = {
      cut_element_count: null,
      layer_count: 26,
      layer_index: 12,
      layer_spacing_m: 2.5e-9,
      layer_stops_m: [],
      navigation_step_kind: "fdm_cell",
      navigation_step_m: 2.5e-9,
      normal_axis: "z",
      normal_max_m: 60e-9,
      normal_min_m: -5e-9,
      plane: "xy",
      requested_coordinate_m: 27.5e-9,
      requested_fraction: 0.5,
      resolved_coordinate_m: 26.25e-9,
      stops_kind: "fdm_cell_layers",
    };
    const dom = installSimulationPreparationTestDom();
    const container = dom.document.createElement("div");
    const root = createRoot(container as unknown as Element);
    try {
      await act(async () => root.render(<FieldMapModule />));

      expect(fieldMapSurfaceStore.get().sectionGeometry).toMatchObject({
        normalMin: -5e-9,
        normalMax: 60e-9,
        layerCount: 26,
        layerSpacing: 2.5e-9,
        nativeResolution: null,
      });
    } finally {
      await act(async () => root.unmount());
      dom.restore();
    }
  });

  it("retains the planar surface while metadata refresh has no data", async () => {
    mocks.visualization.data = {
      planar: {
        colormap: "viridis",
        component: "magnitude",
        display_unit: "A/m",
        interaction: { pan_u_m: 0, pan_v_m: 0, zoom: 1 },
        layers: { mesh: false, vectors: false },
        quantity_id: "m",
        quality: "interactive",
        range: { mode: "auto" },
        resolution: { height: 128, width: 256 },
        source: { kind: "default" },
        default_slice: { operator: { kind: "plane_sample" }, plane: "xy", position_fraction: 0.5 },
        vector_style: { color_mode: "orientation", length_mode: "uniform", scale: 1 },
        view_scope: { kind: "monitor_target" },
      },
    };
    mocks.visualization.status = "ready";
    mocks.renderReady = true;
    const dom = installSimulationPreparationTestDom();
    const container = dom.document.createElement("div");
    const root = createRoot(container as unknown as Element);
    try {
      await act(async () => root.render(<FieldMapModule />));
      expect(container.querySelector(".fm-field-map__canvas-stack")).toBeDefined();
      mocks.metaAvailable = false;
      await act(async () => root.render(<FieldMapModule />));
      expect(container.querySelector(".fm-field-map__canvas-stack")).toBeDefined();
      expect(container.textContent).not.toContain("Ambiguous surface");
    } finally {
      await act(async () => root.unmount());
      dom.restore();
    }
  });

  it("publishes source and runtime provenance for a default sample in the DOM", () => {
    mocks.visualization.data = {
      planar: {
        colormap: "viridis",
        component: "magnitude",
        default_slice: {
          operator: { kind: "plane_sample" },
          plane: "xz",
          position_fraction: 0.25,
        },
        display_unit: "A/m",
        interaction: { pan_u_m: 0, pan_v_m: 0, zoom: 1 },
        layers: { mesh: true, vectors: false },
        quantity_id: "m",
        quality: "interactive",
        range: { mode: "auto" },
        resolution: { height: 128, width: 256 },
        source: { kind: "default" },
        vector_style: { color_mode: "orientation", length_mode: "uniform", scale: 1 },
        view_scope: { kind: "monitor_target" },
      },
    };
    mocks.visualization.status = "ready";
    mocks.renderReady = true;

    const html = renderToStaticMarkup(<FieldMapModule />);

    expect(html).toContain('data-planar-source-kind="default"');
    expect(html).toContain('data-planar-source-id="default"');
    expect(html).toContain('data-planar-source-hash="default-slice-hash"');
    expect(html).toContain('data-planar-source-revision="3"');
    expect(html).toContain('data-planar-default-plane="xz"');
    expect(html).toContain('data-planar-position-fraction="0.25"');
    expect(html).toContain('data-planar-resolved-coordinate-m="22"');
    expect(html).toContain('data-planar-domain-generation-id="domain-generation-1"');
    expect(html).toContain('data-planar-field-backend="fdm"');
    expect(html).toContain('data-planar-field-device="cpu"');
    expect(html).toContain('data-planar-field-precision="double"');
    expect(html).toContain('data-planar-sample-token="planar-sample-v3:current"');
    expect(mocks.renderModel).toHaveBeenCalledWith(expect.objectContaining({
      frame: expect.objectContaining({ origin: [11, 22, 32] }),
    }));
  });

  it.each([
    ["plane", { default_slice: { plane: "xz", position_fraction: 0.5, operator: { kind: "plane_sample" } } }, null, false],
    ["operator", { default_slice: { plane: "xy", position_fraction: 0.5, operator: { kind: "slab_average", thickness_m: 1e-9 } } }, null, false],
    ["vector budget", { resolution: { width: 256, height: 128, vector_budget: 1024 } }, null, false],
    ["monitor source definition", {}, "changed-monitor-hash", false],
    // A layer step keeps the previous frame mounted (mumax3 parity); the
    // section readout names the shown and the loading layer.
    ["position", { default_slice: { plane: "xy", position_fraction: 0.75, operator: { kind: "plane_sample" } } }, null, true],
    ["default source definition", {}, "changed-default-hash", true],
  ])("retention when %s changes during scalar refresh", async (_label, patch, sourceHash, retained) => {
    const planar = {
      component: "magnitude",
      quantity_id: "m",
      source: _label === "monitor source definition" ? { kind: "monitor", monitor_id: "plane-1" } : { kind: "default" },
      default_slice: { plane: "xy", position_fraction: 0.5, operator: { kind: "plane_sample" } },
      resolution: { width: 256, height: 128, vector_budget: 512 },
      interaction: { pan_u_m: 0, pan_v_m: 0, zoom: 1 },
      layers: { raster: true, vectors: false },
      vector_style: { color_mode: "orientation", length_mode: "uniform", scale: 1 },
      view_scope: { kind: "monitor_target" },
    };
    mocks.visualization.data = { planar };
    mocks.visualization.status = "ready";
    mocks.renderReady = true;
    const dom = installSimulationPreparationTestDom();
    const container = dom.document.createElement("div");
    const root = createRoot(container as unknown as Element);
    const render = async () => {
      await act(async () => {
        root.render(<FieldMapModule />);
        await Promise.resolve();
      });
    };
    try {
      await render();
      expect(mocks.surface).toHaveBeenCalled();
      mocks.surface.mockClear();
      mocks.scalarPending = true;
      await render();
      expect(mocks.surface).toHaveBeenCalled();
      mocks.surface.mockClear();
      mocks.metaPending = true;
      await render();
      expect(mocks.surface).toHaveBeenCalled();
      mocks.surface.mockClear();
      mocks.metaPending = false;
      mocks.visualization.data = { planar: { ...planar, ...patch } };
      mocks.sourceDefinitionHash = sourceHash as string | null;
      await render();
      if (retained) expect(mocks.surface).toHaveBeenCalled();
      else expect(mocks.surface).not.toHaveBeenCalled();
    } finally {
      await act(async () => root.unmount());
      dom.restore();
    }
  });

  it("keeps source selection in the Inspector and exposes the D2D-01 toolbar over the same state", () => {
    mocks.visualization.data = {
      planar: {
        colormap: "viridis",
        component: "magnitude",
        default_slice: {
          operator: { kind: "plane_sample" },
          plane: "xy",
          position_fraction: 0.5,
        },
        display_unit: "A/m",
        interaction: { pan_u_m: 0, pan_v_m: 0, zoom: 1 },
        layers: { mesh: true, raster: true, vectors: false },
        quantity_id: "m",
        quality: "interactive",
        range: { mode: "auto" },
        resolution: { height: 128, width: 256 },
        source: { kind: "default" },
        vector_style: { color_mode: "orientation", length_mode: "uniform", scale: 1 },
        view_scope: { kind: "monitor_target" },
      },
    };
    mocks.visualization.status = "ready";
    mocks.renderReady = true;

    const html = renderToStaticMarkup(<FieldMapModule />);

    expect(html).not.toContain('aria-label="Planar field selection controls"');
    expect(html).not.toContain('aria-label="Source"');
    // D2D-01: quantity, component, plane and layer controls sit above the map
    // and write the same visualization/state.planar as the Inspector.
    expect(html).toContain('aria-label="2D view controls"');
    expect(html).toContain('aria-label="Component"');
  });

  it("renders a horizontal scalar instrument with min, ramp, and max in display units", () => {
    mocks.visualization.data = {
      planar: {
        colormap: "viridis",
        component: "magnitude",
        display_unit: "kA/m",
        interaction: { pan_u_m: 0, pan_v_m: 0, zoom: 1 },
        layers: { mesh: true, probes: true, raster: true, vectors: false },
        quantity_id: "m",
        range: { mode: "auto" },
        resolution: { height: 128, width: 256 },
        source: { kind: "default" },
        default_slice: {
          operator: { kind: "plane_sample" },
          plane: "xy",
          position_fraction: 0.5,
        },
        vector_style: { color_mode: "orientation", length_mode: "uniform", scale: 1 },
        view_scope: { kind: "monitor_target" },
      },
    };
    mocks.visualization.status = "ready";
    mocks.renderReady = true;
    mocks.renderModel.mockImplementation((input: unknown) => ({
      diagnostics: [],
      bounds: [0, 1, 0, 1],
      frame: {
        normal: [0, 0, 1],
        origin: [11, 22, 32],
        uAxis: [1, 0, 0],
        vAxis: [0, 1, 0],
      },
      viewport: [0, 1, 0, 1],
      display: { axisUnit: "m", legendUnit: "kA/m", probeScale: 1e-3 },
      layers: (input as { layers: unknown }).layers,
      range: { max: 2_000, min: -1_000 },
    }));

    mocks.probeData = { occupancy: "occupied", scalar: 1_000, u_m: 2, v_m: 3 };
    const html = renderToStaticMarkup(<FieldMapModule />);

    expect(html).toContain('class="fm-field-map__colorbar"');
    // Static SSR has no PlanarSurface raster evidence yet; preserve the range
    // while exposing its truthful stale-compatible status.
    expect(html).toContain("Previous compatible range");
    expect(html).toContain("-1 kA/m");
    expect(html).toContain("2 kA/m");
    expect(html).toContain('class="fm-field-map__colorbar-ramp" data-colormap="viridis"');
    expect(html).toContain(
      "background:linear-gradient(to right in srgb, rgb(68, 1, 84), rgb(49, 104, 142), rgb(53, 183, 121), rgb(253, 231, 37))",
    );

    const minIndex = html.indexOf("-1 kA/m");
    const rampIndex = html.indexOf('class="fm-field-map__colorbar-ramp"');
    const maxIndex = html.indexOf("2 kA/m");
    expect(minIndex).toBeLessThan(rampIndex);
    expect(rampIndex).toBeLessThan(maxIndex);
    expect(html).toContain(
      '<div class="fm-field-map__canvas-stack"><output data-planar-render-layers=',
    );
    // Since PR 350 the probe reading is retained per pinned point; with no
    // point pinned (static render) no stale reading is shown. Axis rows are
    // covered by PlanarPinnedProbe, placement by PlanarSurface.
    expect(html).not.toContain('class="fm-field-map__pinned-probe"');
  });

  it("resolves Airbox and object wireframes without changing the field query or sample identity", () => {
    const globalWireframe = { color: "#94a3b8", opacity: 1 };
    const airboxWireframe = { color: "#00ff00", opacity: 0.6 };
    const objectWireframe = { color: "#ff0000", opacity: 0.4 };
    const planar = {
      colormap: "viridis",
      component: "magnitude",
      default_slice: {
        operator: { kind: "plane_sample" },
        plane: "xy",
        position_fraction: 0.5,
      },
      display_unit: "A/m",
      interaction: { pan_u_m: 0, pan_v_m: 0, zoom: 1 },
      layers: { mesh: true, raster: true, vectors: false },
      quantity_id: "m",
      quality: "interactive",
      range: { mode: "auto" },
      resolution: { height: 128, vector_budget: 512, width: 256 },
      source: { kind: "default" },
      target_overrides: [
        { scope: "airbox", scope_id: "airbox", wireframe_style: airboxWireframe },
        { scope: "object", scope_id: "free-layer", wireframe_style: objectWireframe },
      ],
      vector_style: { color_mode: "orientation", length_mode: "uniform", scale: 1 },
      view_scope: { kind: "monitor_target" },
      wireframe_style: globalWireframe,
    };
    const registry = {
      airbox: { label: "Airbox", scope: "airbox", scope_id: "airbox" },
      objects: [{ label: "Free layer", scope: "object", scope_id: "free-layer" }],
      parts: [],
    };
    mocks.visualization.data = { planar, targets: registry };
    mocks.visualization.status = "ready";
    mocks.renderReady = true;

    mocks.selection = airboxSelection();
    renderToStaticMarkup(<FieldMapModule />);
    const airboxQueryCall = mocks.meta.mock.calls.at(-1);
    const airboxRenderInput = mocks.renderModel.mock.calls.at(-1)?.[0] as {
      sampleIdentity: string;
      wireframeStyle: unknown;
    };

    mocks.meta.mockClear();
    mocks.renderModel.mockClear();
    mocks.selection = objectSelection("free-layer");
    renderToStaticMarkup(<FieldMapModule />);
    const objectQueryCall = mocks.meta.mock.calls.at(-1);
    const objectRenderInput = mocks.renderModel.mock.calls.at(-1)?.[0] as {
      sampleIdentity: string;
      wireframeStyle: unknown;
    };

    expect(airboxRenderInput.wireframeStyle).toEqual(airboxWireframe);
    expect(objectRenderInput.wireframeStyle).toEqual(objectWireframe);
    expect(objectQueryCall).toEqual(airboxQueryCall);
    expect(objectRenderInput.sampleIdentity).toBe(airboxRenderInput.sampleIdentity);
    expect(objectRenderInput.sampleIdentity).toBe("scalar-authoritative");

    const fallbackCases = [
      { selection: emptySelection(), targets: registry },
      { selection: regionSelection("free-layer", "region-1"), targets: registry },
      { selection: airboxSelection(), targets: undefined },
      {
        selection: objectSelection("dormant-layer"),
        targets: registry,
      },
    ];
    for (const fallbackCase of fallbackCases) {
      mocks.meta.mockClear();
      mocks.renderModel.mockClear();
      mocks.selection = fallbackCase.selection;
      mocks.visualization.data = fallbackCase.targets
        ? { planar, targets: fallbackCase.targets }
        : { planar };
      renderToStaticMarkup(<FieldMapModule />);

      const fallbackRenderInput = mocks.renderModel.mock.calls.at(-1)?.[0] as {
        sampleIdentity: string;
        wireframeStyle: unknown;
      };
      expect(fallbackRenderInput.wireframeStyle).toEqual(globalWireframe);
      expect(mocks.meta.mock.calls.at(-1)).toEqual(airboxQueryCall);
      expect(fallbackRenderInput.sampleIdentity).toBe(
        airboxRenderInput.sampleIdentity,
      );
    }
  });

  it("keeps the canonical plan and sample identity stable while optimistic layers alter rendered flags", () => {
    const planar = {
      colormap: "viridis",
      component: "magnitude",
      interaction: { pan_u_m: 0, pan_v_m: 0, zoom: 1 },
      layers: { boundaries: false, contours: false, mesh: true, probes: false, raster: true, vectors: true },
      quality: "interactive",
      quantity_id: "h_eff",
      resolution: { height: 128, vector_budget: 512, width: 256 },
      source: { kind: "monitor", monitor_id: "plane-authoritative" },
      vector_style: { color_mode: "orientation", length_mode: "uniform", scale: 1 },
      view_scope: { kind: "monitor_target" },
    };
    mocks.visualization.data = { planar };
    mocks.visualization.optimisticData = {
      planar: {
        ...planar,
        component: "normal",
        layers: { ...planar.layers, mesh: false, vectors: false },
        quality: "export",
        resolution: { height: 1024, vector_budget: 1000, width: 1024 },
        quantity_id: "m",
        source: { kind: "monitor", monitor_id: "plane-pending" },
      },
    };
    mocks.visualization.status = "ready";
    mocks.renderReady = true;

    renderToStaticMarkup(<FieldMapModule />);

    expect(mocks.meta).toHaveBeenCalledWith(
      "h_eff",
      { kind: "monitor", monitorId: "plane-authoritative" },
      expect.objectContaining({ include_mesh: true, quality: "interactive", resolution_x: 256, resolution_y: 128, vector_budget: 512 }),
      { enabled: true },
    );
    expect(mocks.renderModel).toHaveBeenLastCalledWith(expect.objectContaining({
      layers: expect.objectContaining({ mesh: false, vectors: false }),
      vectorBudget: 512,
    }));

    mocks.meta.mockClear();
    mocks.renderModel.mockClear();
    mocks.visualization.data = mocks.visualization.optimisticData;
    mocks.visualization.optimisticData = null;
    renderToStaticMarkup(<FieldMapModule />);

    expect(mocks.meta).toHaveBeenCalledWith(
      "m",
      { kind: "monitor", monitorId: "plane-pending" },
      expect.objectContaining({ include_mesh: false, quality: "export", resolution_x: 1024, resolution_y: 1024, vector_budget: 0 }),
      { enabled: true },
    );
  });
});
function emptySelection(): Selection {
  return {
    kind: null,
    label: null,
    moduleSource: null,
    nodeId: null,
    objectId: null,
    ref: null,
  };
}

function airboxSelection(): Selection {
  return {
    kind: "airbox.visualization",
    label: "Airbox",
    moduleSource: "inspector",
    nodeId: "model:airbox:visualization",
    objectId: null,
    ref: {
      kind: "airbox.visualization",
      nodeId: "model:airbox:visualization",
      type: "airbox",
      visualizationTargetId: "airbox",
    },
  };
}

function regionSelection(objectId: string, regionId: string): Selection {
  return {
    kind: "object.region.visualization",
    label: "Region",
    moduleSource: "inspector",
    nodeId: `model:object:${objectId}:region:${regionId}`,
    objectId,
    ref: {
      kind: "object.region.visualization",
      nodeId: `model:object:${objectId}:region:${regionId}`,
      objectId,
      regionId,
      type: "scene-object",
      visualizationTargetId: `region:${objectId}:${regionId}`,
    },
  };
}

function objectSelection(objectId: string): Selection {
  return {
    kind: "object.visualization",
    label: "Free layer",
    moduleSource: "inspector",
    nodeId: `model:object:${objectId}:visualization`,
    objectId,
    ref: {
      kind: "object.visualization",
      nodeId: `model:object:${objectId}:visualization`,
      objectId,
      type: "scene-object",
      visualizationTargetId: `object:${objectId}`,
    },
  };
}

"use client";

import { isFlowMajorTensorDescriptor, isTensorFrobeniusSurfaceField, retainTensorSurfaceField } from "@/kernel/api/tensorFieldProjection";

import type { components } from "@/kernel/api/generated/openapi-v2-types";
import { DATA_FIELDS_PATH } from "@/kernel/api/apiPaths";
import { publishViewport3DLiveRefreshRevisions } from "@/kernel/performance/visualizationDebugPerformanceProbe";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
  type ComponentProps,
} from "react";

import type {
  FieldVectorQuery,
  FieldCatalogResource,
  FieldMetaResource,
  LiveStatusResource,
  MeshHistogramBinElementsResource,
  MeshRegionMembershipResource,
  MeshSharedDomainManifestResource,
  RegionListResource,
  ResourceRevision,
  QuantityCatalogResource,
  VisualizationStateResource,
} from "@/kernel/api/apiTypes";
import {
  asDecodedComplexFieldVector,
  FMRM_INACTIVE_REGION_ID,
  type DecodedFieldVector,
} from "@/kernel/api/codecs";
import { ControlRoomApiError } from "@/kernel/api/ControlRoomApi";
import type { MeshSizeHistogramHighlight } from "@/kernel/events/eventTypes";
import {
  isAnalysisFieldQuantityId,
  fieldCatalogQuantitySupportsAirbox,
  isScalarSpatialQuantityId,
  quantityCatalogSupportsQuantity,
  quantityCatalogEntrySupportsSpatialVisualization,
  quantityCatalogEntrySupportsAnySpatialVisualization,
  resolveCanonicalQuantityId,
  sameRenderableFieldQuantityId,
} from "@/kernel/api/quantityIds";
import { useCrossSectionResource } from "@/kernel/resources/crossSectionResources";
import { useModeCompositionFieldLayerResources } from "@/kernel/resources/modeCompositionFieldLayerResources";
import { useModeCompositionControllerResource } from "@/kernel/resources/modeCompositionResources";
import { useModeFieldOverlayIntentResource } from "@/kernel/resources/modeFieldOverlayResources";
import {
  resolveSessionDiscretization,
  resolveSessionTopologyDiscretization,
} from "@/kernel/resources/sessionDiscretization";
import {
  useFdmRegionMembershipBinaryResource,
  useFdmMultilayerLayerActiveMasksResource,
  useFdmMultilayerLayoutResource,
  useFdmRegionMembershipResource,
  useMeshRegionMembershipsResource,
  useModelRegionsResource,
} from "@/kernel/resources/geometryLifecycleResources";
import { deriveAuthoredFdmUniverseOutsideMagneticSupport } from "@/shared/domain/mesh/domainPresentation";
import { hasEmptyObjectMagneticModel } from "@/shared/domain/physics/objectMagneticModel";
import {
  resolveFieldMetaResourceKey,
  useMeshPeriodicPairsResource,
  useFieldCatalogResource,
  useFieldMetaResource,
  useQuantityCatalogResource,
} from "@/kernel/resources/studyRuntimeResources";
import { useResource } from "@/kernel/resources/useResource";
import type { SessionResourceIdentity } from "@/kernel/resources/sessionResourceIdentity";
import {
  useSessionResourceIdentity,
  useSessionStatusSelector,
} from "@/kernel/resources/useSessionStatus";
import { useKernel } from "@/kernel/KernelContext";
import type {
  ResourceResult,
  ResourceStatus,
} from "@/kernel/resources/resourceTypes";
import type {
  PinnedMaterializedDatasetSelectionRef,
  Selection,
} from "@/kernel/selection/selectionTypes";
import {
  canonicalVisualizationSceneObjectId,
  visualizationTargetIdForSceneObject,
  visualizationObjectIdForMeshPartLike,
} from "@/kernel/selection/selectionTypes";
import {
  buildSemanticRenderTargetCatalog,
  type SemanticRenderTargetCatalog,
} from "@/kernel/selection/semanticRenderTargetCatalog";
import {
  resolveVisualizationTargetForMeshPart,
  visualizationSceneObjectIds,
} from "@/kernel/selection/visualizationTargetResolver";
import {
  activeCrossSectionFramePreview,
  crossSectionFramePreviewEquals,
  crossSectionFramePreviewToClip,
} from "@/kernel/workspace/crossSectionWorkspace";
import { useCrossSectionWorkspaceSelector } from "@/kernel/workspace/useCrossSectionWorkspace";
import { useObservationSourceWorkspaceSelector } from "@/kernel/workspace/useObservationSourceWorkspace";
import { observationFrameMagnetizationResourceKey } from "@/kernel/resources/observationFrameResources";
import {
  planarMonitorFramePreviewFromDraft,
  usePlanarMonitorFramePreview,
  usePlanarMonitorFramePreviewDraft,
} from "@/kernel/workspace/planarMonitorFramePreview";
import {
  AIRBOX_VISUALIZATION_TARGET,
  resolveDefaultVisualizationSettings,
  resolveEffectiveVisualizationSettings,
  resolveGlobalObjectVisualizationSettings,
  resolveVisualizationTargetFromSelection,
  resolveFdmViewportVisualizationSettings,
  resolveTargetVisualization,
  surfaceColorSourceToColorMode,
  visualizationTargetKey,
  type ObjectVisualizationSnapshot,
  type VisualizationObjectContext,
  type SurfaceFieldProjectionMode,
  type SurfaceColorSource,
  type VisualizationStoredTargetPatch,
  type VisualizationTargetKind,
  type VisualizationTargetRef,
  type VisualizationTargetSettings,
} from "@/kernel/visualization/ObjectVisualizationController";
import { useObjectVisualizationSelector, useSavedFieldPresentation } from "@/kernel/visualization/useObjectVisualization";
import { useCameraRegistryCamera } from "@/kernel/visualization/useCameraRegistry";
import {
  viewport3DFieldColorLayersEnabledFromBrowserConfig,
  viewport3DVectorLayersEnabledFromBrowserConfig,
} from "@/kernel/browserFullmagConfig";
import {
  useAnalysisFieldOverlayContext,
  useRenderableAnalysisFieldOverlay,
  type AnalysisFieldOverlayAppearanceState,
} from "@/kernel/visualization/AnalysisFieldOverlayController";
import { isAnalysisResultFieldOverlayIntent } from "@/kernel/visualization/AnalysisResultFieldOverlayIntent";
import { startAnalysisFieldOverlayPhaseAnimation } from "@/kernel/visualization/AnalysisFieldOverlayPhaseAnimation";
import { useModeCompositionPhaseClock } from "@/kernel/visualization/ModeCompositionPhaseClock";
import { useVisualizationStateResource } from "@/kernel/visualization/useVisualizationStateResource";
import { resolveVisualizationEffectiveRenderMode } from "@/kernel/visualization/useVisualizationClientAck";
import { resolveCrossSectionQueryFromVisualizationState } from "@/shared/domain/mesh/crossSectionQuery";
import {
  FDM_DISPLAY_CELL_BUDGET,
  FDM_NATIVE_LAYER_DISPLAY_CELL_BUDGET,
  formatFdmDisplaySamplingSummary,
} from "@/shared/domain/mesh/fdmDisplaySampling";
import { buildPeriodicOverlayModel } from "@/shared/domain/mesh/periodicOverlayModel";

import {
  mergeViewport3DFieldScalarColors,
  resolveViewport3DChunkedFieldColorTarget,
  useViewport3DChunkedScalarColors,
} from "./useViewport3DChunkedScalarColors";
import { useViewport3DTopologyIndexBundle } from "./useViewport3DTopologyIndexBundle";
import {
  useViewport3DFieldRenderOptions,
  clampViewport3DInteractiveVectorBudget,
  limitViewport3DFieldRenderVectorBudgets,
  resolveViewport3DAirboxVectorLengthScale,
  viewport3DAirboxVectorsVisible,
} from "./useViewport3DFieldRenderOptions";
import {
  buildHysteresisReplayGlyphModel,
  resolveHysteresisReplayMeshCompatibility,
  resolveHysteresisStepViewportTarget,
  resolveViewport3DSelectionBounds,
  targetForFdmDomain,
  targetForFdmNativeLayer,
  targetForFdmUniverseOutsideSupport,
  type FdmSelectionGrid,
  type HysteresisReplayGlyphModel,
  type HysteresisReplayMeshCompatibility,
} from "../model/viewport3DTargets";
import { resolveFdmUniverseOutsideSupportOverlayFromPresentation } from "../model/fdmUniverseOverlay";
import {
  buildViewport3DTargetRenderPlan,
  buildViewport3DFieldResourceRequestId,
  DEFAULT_VIEWPORT3D_SHADER_MONO_COLOR,
  mergeViewport3DFieldVectorQueries,
  resolveViewport3DAirboxFieldVectorDemandPlan,
  resolveViewport3DPrimaryFieldDemandPlan,
  resolveViewport3DFdmNativeLayerFieldRequests,
  resolveViewport3DScalarComponentRequest,
  resolveViewport3DScopedFieldQuery,
  resolveViewport3DVectorCarrierSampleLimit,
  resolveViewport3DScopedPartVectorFieldDemandPlan,
  resolveViewport3DTargetQuantityFieldDemandPlan,
  resolveViewport3DTargetFieldQuery as resolveViewport3DTargetFieldQueryFromPlan,
  summarizeViewport3DFieldDemandDiagnostics,
  validateViewport3DFieldResourceRequestEquivalence,
  validateViewport3DFieldResourceRequestIdentities,
  type Viewport3DFieldDemandDiagnosticSummary,
  type Viewport3DFieldResourceRequest,
  type Viewport3DTargetRenderPlan,
} from "../model/viewport3DFieldDataPlan";
export {
  resolveViewport3DAirboxFieldVectorDemandPlan,
  resolveViewport3DPrimaryFieldDemandPlan,
  resolveViewport3DPrimaryFieldQuery,
  resolveViewport3DScopedPartVectorFieldDemandPlan,
  resolveViewport3DTargetQuantityFieldDemandPlan,
} from "../model/viewport3DFieldDataPlan";
import {
  buildViewport3DTargetFieldBuffer,
  resolveViewport3DTargetFieldInput,
  type Viewport3DTargetFieldBuffer,
} from "../model/viewport3DTargetFieldBuffer";
import {
  resolveTrustedViewport3DResponseDomainGenerationId,
  describeViewport3DFieldDomainMismatch,
  resolveViewport3DFieldDomainCompatibility,
  resolveViewport3DFieldVectorForDomain,
  safeViewport3DDomainGenerationId,
} from "../model/viewport3DFieldDomainCompatibility";
import {
  buildFdmVectorSegments,
  buildFdmVectorSampledCellIndices,
  createFdmVectorOnlyBuildInput,
  resolveFdmVectorGlyphScaleForCellSize,
  resolveFdmVectorGlyphSamplingSpacingScale,
  useFdmCuboidBuildResult,
  useFdmCuboidBuildResults,
  type FdmCuboidAsyncBuildEntry,
  type FdmCuboidInstanceModel,
} from "../layers/FdmCuboidLayer";
import { resolveFdmAirboxPassPlan } from "../layers/fdmAirboxPassPlan";
import {
  buildViewport3DFdmTargetSurfaceCellIndices,
  buildViewport3DFdmTargetDefinitions,
  buildViewport3DFdmTargetViews,
  memoizeViewport3DFdmTargetRenderView,
  memoizeViewport3DFdmTargetSurfaceColors,
  memoizeViewport3DFdmSurfaceColors,
  type Viewport3DFdmTargetRenderView,
} from "../model/viewport3DFdmTargetViews";
import {
  applyViewport3DGlobalVectorAllocationsToFieldRenderOptions,
  resolveViewport3DGlobalVectorAllocation,
  type Viewport3DVectorBudgetTarget,
} from "../model/viewport3DVectorBudgetAllocator";
import {
  buildFdmMultilayerAirboxFieldRequest,
  buildFdmMultilayerAirboxRegionIds,
  resolveFdmMultilayerAirboxFieldVector,
  shouldRequestFdmMultilayerAirboxField,
} from "../model/viewport3DFdmMultilayerAirbox";
import { resolveFdmVectorOnlyRenderBuffers } from "../model/fdmVectorOnlyRenderBuffers";
import { buildViewport3DFdmCuboidJobKey } from "../build-engine/viewport3dBuildJobKeys";
import { modeCompositionTargetIdForMeshPart } from "../model/modeCompositionViewportProjection";
import { Viewport3DScene } from "../layers/Viewport3DScene";
import { buildClipPlaneIntersectionMarkerBuffers } from "../layers/clipPlaneModel";
import {
  buildRegionOverlayModels,
  type RegionOverlayInput,
  type RegionOverlayModel,
  type RegionMeshOverlayOwnerPart,
} from "../layers/regionOverlayModel";
import {
  adaptDomainPresentation,
  adaptFdmDomainPresentation,
  adaptFdmMultilayerAirboxDomain,
  adaptFdmMultilayerNativeLayerDomains,
  adaptFemSharedDomainManifest,
  resolveFdmNativeLayerActiveMaskForRendering,
  resolveViewport3DFdmRealizedRegionIds,
  type FdmNativeLayerRenderView,
  type FdmMultilayerAirboxRenderView,
  type FemManifestRenderDomain,
  type Viewport3DMeshPart,
} from "../viewport3dDomainAdapter";
import {
  buildViewport3DDiagnostics,
  type Viewport3DResourceCounts,
  type Viewport3DResourceTracker,
} from "../viewport3dDiagnostics";
import {
  getViewport3DBuildDiagnosticsSnapshotVersion,
  getViewport3DBuildFallbackDiagnosticsSnapshot,
  getViewport3DBuildPipelineDiagnosticsSnapshot,
  subscribeViewport3DBuildDiagnostics,
} from "../build-engine/viewport3dBuildDiagnostics";
import {
  buildFdmSampledScalarColors,
  fieldTransformNeedsChunking,
  resolveScalarRange,
  type ScalarRange,
  type Viewport3DFieldVector,
} from "../viewport3dFieldMapping";
import { buildViewport3DResourceFrameKey } from "../viewport3dInvalidation";
import type { Viewport3DResourceFrameState } from "../viewport3dInvalidation";
import {
  buildViewport3DMagnetizationTexturePreviewMap,
  buildViewport3DPrimitiveRenderModel,
  resolvePrimitiveSelectionBounds,
  type Viewport3DPrimitiveObject,
} from "../viewport3dPrimitiveModel";
import { usePrimitiveDraftOverlay } from "./usePrimitiveDraftOverlay";
import {
  buildMeshQualityVertexColors,
  topologySupportsTet4FmmqQuality,
  type MeshQualityColorMetric,
} from "../viewport3dQualityMapping";
import { buildViewport3DMeshSizeHighlightModel } from "../viewport3dMeshSizeHighlight";
import {
  buildViewport3DFieldRenderModel,
  buildViewport3DTopologyRenderModel,
  combineViewport3DBounds,
  resolveNodeSelectionCount,
  resolveDomainBounds,
  resolveTopologyBounds,
  resolveUniverseBounds,
  resolveViewport3DMaxVectorGlyphs,
  type Viewport3DFieldRenderOptions,
  type Viewport3DRenderablePart,
  type Viewport3DTargetFieldBufferSource,
  type Viewport3DTargetRenderPassModel,
  type Viewport3DTopologyRenderModel,
  type Viewport3DVectorBuildReference,
  type Viewport3DBounds,
  viewport3DFieldRenderOptionsNeedFieldData,
} from "../viewport3dRenderModel";
import { resolveViewport3DCameraFovDegrees } from "../viewport3dCameraFov";
import { useMaterializedDatasetResource } from "@/kernel/resources/solutionSetResources";
import { useSavedFieldViewportResources } from "@/kernel/resources/savedFieldViewportResources";
import { buildSavedFieldViewportSceneModel, finalizeSavedFieldColors } from "../savedFieldViewportAdapter";
import { useSavedAntennaSourceContextResources } from "@/kernel/resources/savedAntennaSourceContextResources";
import { buildSavedAntennaSourceModel } from "../model/savedAntennaSourceModel";

export function resolveViewport3DAirboxVectorSampleBudget(
  requestedBudget: number,
  availableAirOnlyNodeCount: number,
): number {
  return Math.max(
    0,
    Math.min(
      Math.floor(requestedBudget),
      Math.floor(availableAirOnlyNodeCount),
    ),
  );
}

function analysisResultOverlayMatchesSelection(
  overlay: ReturnType<typeof useRenderableAnalysisFieldOverlay>,
  selection: Selection,
): boolean {
  const intent = overlay?.analysisResultFieldIntent;
  const ref = selection.ref;
  if (!intent) return true;
  if (!isAnalysisResultFieldOverlayIntent(intent) || ref?.type !== "analysis-result") {
    return false;
  }
  return (
    ref.runId === intent.analysisRunId &&
    ref.stageId === intent.analysisStageId &&
    ref.datasetId === intent.datasetId &&
    ref.datasetRevision === intent.datasetRevision &&
    ref.sampleId === intent.sampleId &&
    ref.itemId === intent.itemId &&
    ref.itemKind === intent.itemKind &&
    ref.fieldId === intent.fieldId &&
    ref.fieldRevision === intent.fieldRevision &&
    ref.fieldRef?.resource_key === intent.fieldRef.resource_key &&
    ref.fieldRef?.mesh_ref?.mesh_id === intent.fieldRef.mesh_ref?.mesh_id &&
    ref.fieldRef?.mesh_ref?.mesh_revision ===
      intent.fieldRef.mesh_ref?.mesh_revision &&
    ref.fieldRef?.mesh_ref?.topology_fingerprint ===
      intent.fieldRef.mesh_ref?.topology_fingerprint
  );
}

function resolvePinnedMaterializedDatasetSelection(
  selection: Selection,
): PinnedMaterializedDatasetSelectionRef | null {
  return selection.kind === "results.materialized_dataset" &&
      selection.ref?.type === "materialized-dataset"
    ? selection.ref
    : null;
}

function savedDatasetMatchesSelection(
  selection: PinnedMaterializedDatasetSelectionRef | null,
  dataset: components["schemas"]["MaterializedDatasetResource"] | null,
): boolean {
  return Boolean(
    selection &&
      dataset &&
      dataset.project_id === selection.projectId &&
      dataset.run_id === selection.runId &&
      dataset.solution_set_id === selection.solutionSetId &&
      dataset.containing_solution_revision === selection.containingRevision &&
      dataset.member_id === selection.memberId &&
      dataset.artifact_id === selection.artifactId &&
      dataset.manifest_object_ref === selection.manifestObjectRef &&
      dataset.sample_id === selection.sampleId &&
      dataset.item_id === selection.itemId &&
      dataset.field_id === selection.fieldId &&
      dataset.dataset.dataset_id === selection.datasetId &&
      dataset.dataset.revision === selection.datasetRevision,
  );
}

function savedViewportResourceHasFreshData(resource: {
  data: unknown;
  error: Error | null;
  refreshError?: Error | null;
  status: ResourceStatus;
}): boolean {
  return (
    resource.status === "ready" &&
    resource.data !== null &&
    resource.error === null &&
    resource.refreshError == null
  );
}
import {
  getViewport3DCacheStats as getCacheStats,
  resolveViewport3DFieldVectorResourceKey,
  resolveViewport3DFieldVectorRequestResourceKey,
  resolveViewport3DFieldVectorIdentityMatch,
  useViewport3DAirboxFieldVectors,
  useViewport3DDomainMeta,
  useViewport3DDomainTopology,
  useViewport3DAnalysisFieldVector,
  useViewport3DFieldVectorRequest,
  useViewport3DObservationFrameMagnetization,
  useViewport3DMeshQualityData,
  useViewport3DPartFieldVectors,
  useViewport3DQuantityFieldVectors,
  useViewport3DScene,
  useViewport3DSharedDomainManifest,
  type Viewport3DAirboxFieldVectorPartState,
  useViewport3DUniverse,
  type Viewport3DFieldVectorEnvelope,
  type Viewport3DFieldVectorRequestOptions,
} from "../viewport3dResources";
import type { Viewport3DFieldRefreshState } from "../viewport3dRefreshCountdown";
import {
  isViewport3DTopologyCurrent,
  isViewport3DTopologyRenderable,
  resolveViewport3DTopologyFreshnessLabel,
  resolveUnknownTopologyProvenanceRefreshKey,
  resolveViewport3DTopologyFreshness,
  type Viewport3DTopologyFreshness,
} from "../viewport3dTopologyStaleness";
import {
  resolveHslReferenceVisible,
  resolveViewport3DCameraOrthographicScale,
  resolveViewport3DCameraProjection,
  resolveViewport3DCameraState,
  type Viewport3DCommandState,
  type Viewport3DCameraProjection,
  type Viewport3DCameraState,
  type useViewport3DCommandState,
} from "../viewport3dStore";
import { getViewport3DVisualProfile } from "../viewport3dVisualProfile";
import { resolveViewport3DAdaptiveVectorGlyphLength } from "../model/viewport3DVectorGlyphScale";
import { useSavedViewportCamera } from "./useSavedViewportCamera";

type Viewport3DSceneProps = ComponentProps<typeof Viewport3DScene>;
type JsonRecord = Record<string, unknown>;
type SceneRegionShape = components["schemas"]["SceneRegionShape"];

const EMPTY_AIRBOX_FIELD_VECTOR_PARTS: readonly { id: string }[] = [];
const EMPTY_VIEWPORT_3D_FIELD_QUANTITY_IDS: ReadonlySet<string> = new Set();
export function resolveViewport3DVectorScale(
  boundsSize: readonly number[],
  vectorLengthScale: number,
  glyphCount = 1200,
  scope: "full" | "surface" = "full",
): number {
  return resolveViewport3DAdaptiveVectorGlyphLength({
    boundsSize,
    glyphCount,
    lengthScale: vectorLengthScale,
    scope,
  });
}

export function resolveViewport3DFdmGridVectorScale(
  shape: readonly [number, number, number],
  spacing: readonly [number, number, number],
  vectorLengthScale: number,
  glyphCount = 1200,
  scope: "full" | "surface" = "full",
): number {
  return resolveViewport3DVectorScale(
    shape.map((cells, axis) => cells * (spacing[axis] ?? 0)),
    vectorLengthScale,
    glyphCount,
    scope,
  );
}

/**
 * Primary field-vector failures are owned by the viewport issue banner
 * (`fieldDataIssue`), so they do not also raise a global toast.
 */
export const VIEWPORT3D_PRIMARY_FIELD_VECTOR_REQUEST_OPTIONS: Viewport3DFieldVectorRequestOptions =
  Object.freeze({ notifyOnError: false });

const EMPTY_FDM_MULTILAYER_AIRBOX_FIELD_REQUEST: Viewport3DFieldResourceRequest = {
  consumers: [],
  quantityId: "H_demag",
  query: { component: "full", scope_id: "airbox", scope_kind: "airbox" },
  requestId: "fdm-multilayer-airbox:idle",
};
const FDM_AIRBOX_VOXEL_TOPOGRAPHY = {
  amplitudeCells: 0,
  component: "z" as const,
  enabled: false,
};

function resolveViewport3DAvailableFieldQuantityIds(
  catalog: FieldCatalogResource | null,
): ReadonlySet<string> | null {
  if (!catalog) return null;
  return new Set(
    catalog.quantities
      .filter((quantity) => quantity.available)
      .map((quantity) => resolveCanonicalQuantityId(quantity.quantity_id)),
  );
}

export function mergeViewport3DQuantityCapabilityIds(
  fieldQuantityIds: ReadonlySet<string> | null,
  quantityCatalog: QuantityCatalogResource | null,
): ReadonlySet<string> | null {
  if (!fieldQuantityIds && !quantityCatalog) return null;
  const catalogByQuantityId = new Map(
    (quantityCatalog?.quantities ?? []).map((quantity) => [
      resolveCanonicalQuantityId(quantity.id),
      quantity,
    ]),
  );
  const merged = new Set(
    [...(fieldQuantityIds ?? [])].filter(
      (quantityId) =>
        catalogByQuantityId.get(resolveCanonicalQuantityId(quantityId))
          ?.capability_state !== "unsupported",
    ),
  );
  for (const quantity of quantityCatalog?.quantities ?? []) {
    if (quantityCatalogEntrySupportsAnySpatialVisualization(quantity)) {
      merged.add(resolveCanonicalQuantityId(quantity.id));
    }
  }
  if (merged.has("H_drive")) {
    merged.add("B_drive");
  }
  return merged;
}

function viewport3DFieldQuantityAvailable(
  quantityId: string,
  availableQuantityIds: ReadonlySet<string> | null,
): boolean {
  return (
    availableQuantityIds == null ||
    availableQuantityIds.has(resolveCanonicalQuantityId(quantityId))
  );
}

export function resolveFdmNativeLayerFieldVector(
  domain: import("../viewport3dDomainAdapter").FdmNativeLayerRenderDomain,
  layoutGenerationId: string,
  fieldVector: DecodedFieldVector | null | undefined,
): DecodedFieldVector | null {
  if (!fieldVector) return null;
  const indexing = fieldVector.indexing ?? "legacy_count_only";
  const isDensePayload =
    indexing === "full_domain" || indexing === "legacy_count_only";
  const isIndexedPayload =
    indexing === "explicit_node_indices" ||
    indexing === "sampled_node_indices";
  if (
    fieldVector.scopeKind !== "layer" ||
    fieldVector.scopeId !== domain.layerId ||
    (!isDensePayload && !isIndexedPayload)
  ) {
    return null;
  }
  if (isDensePayload) {
    if (
      fieldVector.pointCount !== domain.totalCells ||
      fieldVector.grid.some((value, axis) => value !== domain.shape[axis])
    ) {
      return null;
    }
  } else {
    // Indexed payload grids describe their compact samples; nodeIndices map them to the native carrier.
    let payloadCellCount = 1;
    for (const axisCount of fieldVector.grid) {
      if (!Number.isSafeInteger(axisCount) || axisCount <= 0) return null;
      payloadCellCount *= axisCount;
      if (!Number.isSafeInteger(payloadCellCount)) return null;
    }
    if (
      !Number.isSafeInteger(fieldVector.pointCount) ||
      fieldVector.pointCount <= 0 ||
      payloadCellCount !== fieldVector.pointCount
    ) {
      return null;
    }
  }
  const compatible = resolveViewport3DFieldDomainCompatibility({
    domain: {
      discretization: "fdm",
      domainGenerationId: layoutGenerationId,
      meshTopologyHash: domain.gridFingerprint,
      meshTopologyRevision: null,
      pointCount: domain.totalCells,
    },
    field: fieldVector,
  });
  return compatible.status === "mismatch" ? null : fieldVector;
}

const EMPTY_FEM_RENDER_DOMAIN: FemManifestRenderDomain = {
  airboxParts: [],
  fieldCapableAirboxParts: [],
  fieldCapableMagneticParts: [],
  magneticParts: [],
  magneticSurfacePartsByPartId: new Map(),
  objectPartIds: new Map(),
  partsById: new Map(),
};

const EMPTY_SEMANTIC_RENDER_TARGET_CATALOG: SemanticRenderTargetCatalog = {
  byCarrierId: new Map(),
  byTargetId: new Map(),
  entries: [],
};
const EMPTY_VIEWPORT_FDM_PART_STATES = new Map<
  string,
  Viewport3DAirboxFieldVectorPartState
>();

export interface Viewport3DDomainRenderLane {
  femDomain: FemManifestRenderDomain;
  topologyCurrent: boolean;
  topologyRenderable: boolean;
}

export function resolveViewport3DDomainRenderLane({
  discretization,
  femDomain,
  topologyFreshness,
}: {
  discretization: "fdm" | "fem" | null;
  femDomain: FemManifestRenderDomain;
  topologyFreshness: Viewport3DTopologyFreshness;
}): Viewport3DDomainRenderLane {
  return {
    femDomain: discretization === "fem" ? femDomain : EMPTY_FEM_RENDER_DOMAIN,
    topologyCurrent:
      discretization === "fem" && isViewport3DTopologyCurrent(topologyFreshness),
    topologyRenderable:
      discretization === "fem" && isViewport3DTopologyRenderable(topologyFreshness),
  };
}

export function hasActiveViewport3DTargetQuantityDemand(
  discretization: "fdm" | "fem" | null,
  requestCount: number,
): boolean {
  return (
    (discretization === "fdm" || discretization === "fem") &&
    Number.isSafeInteger(requestCount) &&
    requestCount > 0
  );
}

export function resolveViewport3DFdmFieldIdentityCompatible({
  fdmFieldCompatibilityStatus,
  fdmLaneActive,
}: {
  fdmFieldCompatibilityStatus:
    | "compatible"
    | "degraded"
    | "mismatch"
    | null;
  fdmLaneActive: boolean;
}): boolean {
  return !fdmLaneActive || fdmFieldCompatibilityStatus !== "mismatch";
}

interface Viewport3DScalarRangeModeFlags {
  magnitude: boolean;
  x: boolean;
  y: boolean;
  z: boolean;
}

function resolveViewport3DScalarRangeModeFlags(
  scalarColorModes: ReadonlySet<string> | null | undefined,
  vectorColorMode: string,
): Viewport3DScalarRangeModeFlags {
  const modes = new Set(scalarColorModes ?? []);
  modes.add(vectorColorMode);
  return {
    magnitude: modes.has("magnitude"),
    x: modes.has("x"),
    y: modes.has("y"),
    z: modes.has("z"),
  };
}

function enabledScalarRangeModes(
  flags: Viewport3DScalarRangeModeFlags,
): Array<"magnitude" | "x" | "y" | "z"> {
  return (["magnitude", "x", "y", "z"] as const).filter(
    (mode) => flags[mode],
  );
}

function resolveViewport3DFieldMetaScalarRange(
  fieldMeta: FieldMetaResource | null | undefined,
): ScalarRange | null {
  const stats = fieldMeta?.stats;
  if (
    !stats ||
    !Number.isFinite(stats.min) ||
    !Number.isFinite(stats.max)
  ) {
    return null;
  }
  return {
    max: stats.max,
    min: stats.min,
  };
}

export function resolveAirboxManualColorRange(
  quantity: VisualizationStateResource["quantity"] | null | undefined,
  quantityId: string,
  component: string,
): ScalarRange | null {
  if (
    !quantity ||
    quantity.auto_contrast !== false ||
    quantity.field_component !== component ||
    !sameViewport3DQuantityId(quantity.active_quantity_id, quantityId)
  ) return null;

  const { contrast_min: min, contrast_max: max } = quantity;
  return typeof min === "number" && typeof max === "number" &&
    Number.isFinite(min) && Number.isFinite(max) && min < max
    ? { min, max }
    : null;
}

interface Viewport3DPartScalarRangeRequest {
  component: string;
  mode: string;
  partId: string;
  quantityId: string;
  scopeId: string;
  scopeKind: "object" | "part";
  snapshot_id?: string | null;
  stage_id?: string | null;
}

export function resolveViewport3DPartScalarRangeRequests({
  fieldRenderOptions,
  getPartSettings,
  magneticParts,
  selectedSnapshotQuery,
}: {
  fieldRenderOptions: Pick<
    Viewport3DFieldRenderOptions,
    "partScalarColorModes"
  >;
  getPartSettings: (part: Viewport3DMeshPart) => VisualizationTargetSettings;
  magneticParts: readonly { part: Viewport3DMeshPart }[];
  selectedSnapshotQuery?: FieldVectorQuery | null;
}): ReadonlyMap<string, Viewport3DPartScalarRangeRequest> {
  const requests = new Map<string, Viewport3DPartScalarRangeRequest>();
  for (const partModel of magneticParts) {
    const partId = partModel.part.id;
    const mode = fieldRenderOptions.partScalarColorModes?.get(partId);
    const component = mode ? fieldColorModeScalarComponent(mode) : null;
    if (!mode || !component) continue;
    const settings = getPartSettings(partModel.part);
    if (!settings.visible || !settings.shaderVisible) continue;
    const quantityId = resolveCanonicalQuantityId(settings.activeQuantityId);
    if (isAnalysisFieldQuantityId(quantityId)) continue;
    const objectScopeId = partModel.part.object_id ?? partModel.part.geometry_id;
    requests.set(partId, {
      component: resolveViewport3DFieldMetaScalarComponent(quantityId, component),
      mode,
      partId,
      quantityId,
      scopeId: objectScopeId ?? partId,
      scopeKind: objectScopeId ? "object" : "part",
      snapshot_id: selectedSnapshotQuery?.snapshot_id ?? null,
      stage_id: selectedSnapshotQuery?.stage_id ?? null,
    });
  }
  return new Map(
    Array.from(requests).toSorted(([left], [right]) =>
      left.localeCompare(right),
    ),
  );
}

export function mergeViewport3DPartScalarRanges({
  baseRanges,
  partFieldVectors,
  partScalarColorModes,
  partTargetFieldBuffers,
}: {
  baseRanges?: ReadonlyMap<string, ReadonlyMap<string, ScalarRange>> | null;
  partFieldVectors: ReadonlyMap<string, DecodedFieldVector>;
  partScalarColorModes?: ReadonlyMap<string, string> | null;
  partTargetFieldBuffers?: ReadonlyMap<string, Viewport3DTargetFieldBuffer> | null;
}): ReadonlyMap<string, ReadonlyMap<string, ScalarRange>> {
  const mergedRanges = new Map<string, Map<string, ScalarRange>>();
  if (baseRanges) {
    for (const [partId, rangesByMode] of baseRanges) {
      mergedRanges.set(partId, new Map(rangesByMode));
    }
  }

  const partIds = new Set([
    ...partFieldVectors.keys(),
    ...(partTargetFieldBuffers?.keys() ?? []),
  ]);
  for (const partId of partIds) {
    const scalarColorMode = partScalarColorModes?.get(partId);
    if (
      !scalarColorMode ||
      scalarColorMode === "orientation" ||
      scalarColorMode === "hsl_sphere" ||
      scalarColorMode === "monochrome"
    ) {
      continue;
    }
    const fieldVector = resolveViewport3DTargetFieldInput({
      fallbackFieldVector: null,
      legacyPartFieldVectors: partFieldVectors,
      partId,
      targetFieldBuffers: partTargetFieldBuffers ?? undefined,
    }).fieldVector;
    if (!fieldVector) continue;
    const rangesByMode = mergedRanges.get(partId) ?? new Map<string, ScalarRange>();
    if (isTensorFrobeniusSurfaceField(fieldVector)) {
      rangesByMode.set(scalarColorMode, resolveScalarRange(fieldVector, scalarColorMode));
      mergedRanges.set(partId, rangesByMode);
      continue;
    }
    if (rangesByMode.has(scalarColorMode)) {
      mergedRanges.set(partId, rangesByMode);
      continue;
    }
    rangesByMode.set(scalarColorMode, resolveScalarRange(fieldVector, scalarColorMode));
    mergedRanges.set(partId, rangesByMode);
  }

  return new Map(
    Array.from(mergedRanges, ([partId, rangesByMode]) => [
      partId,
      new Map(rangesByMode),
    ]),
  );
}

export function mergeViewport3DPrimaryTargetFieldBuffers({
  fieldRenderOptions,
  fieldRevision = null,
  fieldVector,
  getPartSettings,
  primaryFieldQuantityId,
  primaryFieldRequest,
  primaryFieldResourceKey,
  sessionIdentity = null,
  topology,
  topologyRevision = null,
}: {
  fieldRenderOptions: Viewport3DFieldRenderOptions;
  fieldRevision?: string | null;
  fieldVector: DecodedFieldVector | null;
  getPartSettings: (part: Viewport3DMeshPart) => VisualizationTargetSettings;
  primaryFieldQuantityId: string;
  primaryFieldRequest: Viewport3DFieldResourceRequest;
  primaryFieldResourceKey: string;
  sessionIdentity?: SessionResourceIdentity | null;
  topology:
    | Pick<
        Viewport3DTopologyRenderModel<Viewport3DMeshPart>,
        | "magneticParts"
        | "meshGenerationId"
        | "meshRevision"
        | "meshTopologyHash"
        | "nodeCount"
      >
    | null;
  topologyRevision?: string | null;
}): Viewport3DFieldRenderOptions {
  if (!fieldVector || !topology) {
    return fieldRenderOptions;
  }

  let changed = false;
  const partFieldVectors = new Map(fieldRenderOptions.partFieldVectors);
  const partTargetFieldBuffers = new Map(
    fieldRenderOptions.partTargetFieldBuffers,
  );

  for (const partModel of topology.magneticParts) {
    const partId = partModel.part.id;
    if (partFieldVectors.has(partId) || partTargetFieldBuffers.has(partId)) {
      continue;
    }

    const settings = getPartSettings(partModel.part);
    const primaryFieldAppliesToPart =
      isAnalysisFieldQuantityId(primaryFieldQuantityId) ||
      sameViewport3DQuantityId(settings.activeQuantityId, primaryFieldQuantityId);
    if (
      !settings.visible ||
      (!settings.shaderVisible && !settings.vectorsVisible) ||
      !primaryFieldAppliesToPart
    ) {
      continue;
    }

    partTargetFieldBuffers.set(
      partId,
      buildViewport3DTargetFieldBuffer({
        consumers: resolveViewport3DPrimaryTargetBufferConsumers({
          partId,
          primaryFieldRequest,
          settings,
        }),
        fieldRevision,
        fieldVector,
        domain: {
          domainGenerationId: topology.meshGenerationId,
          meshTopologyHash: topology.meshTopologyHash,
          meshTopologyRevision: topology.meshRevision == null ? null : String(topology.meshRevision),
          pointCount: topology.nodeCount,
        },
        query: primaryFieldRequest.query,
        resourceKey: primaryFieldResourceKey,
        sessionIdentity,
        targetIds: [partId],
        topologyRevision,
      }),
    );
    changed = true;
  }

  const normalizedPartFieldVectors =
    partTargetFieldBuffers.size > 0
      ? new Map<string, DecodedFieldVector>()
      : partFieldVectors;
  const normalized = normalizedPartFieldVectors.size !== partFieldVectors.size;

  return changed || normalized
    ? {
        ...fieldRenderOptions,
        ...(normalizedPartFieldVectors.size > 0
          ? { partFieldVectors: normalizedPartFieldVectors }
          : { partFieldVectors: undefined }),
        partTargetFieldBuffers,
      }
    : fieldRenderOptions;
}

function resolveViewport3DPrimaryTargetBufferConsumers({
  partId,
  primaryFieldRequest,
  settings,
}: {
  partId: string;
  primaryFieldRequest: Viewport3DFieldResourceRequest;
  settings: VisualizationTargetSettings;
}): readonly string[] {
  const consumers = new Set(primaryFieldRequest.consumers);
  if (settings.visible && settings.shaderVisible) {
    consumers.add(`${partId}:surface`);
  }
  if (
    settings.visible &&
    settings.vectorsVisible &&
    settings.vectorBudget > 0
  ) {
    consumers.add(`${partId}:vector-glyph`);
  }
  return [...consumers].toSorted();
}

type Viewport3DResolvedFieldResourceRequest =
  Pick<Viewport3DFieldResourceRequest, "query"> & {
    consumers?: readonly string[];
    quantityId?: string;
    resourceKey?: string;
  };

export function resolveViewport3DResolvedPartFieldBuffers({
  airboxFieldRevision = null,
  airboxFieldVectorRequests,
  airboxFieldVectors,
  airboxQuantityCompatible = false,
  airboxQuantityId = "m",
  airboxSyntheticVectorsEnabled = false,
  getPartSettings,
  quantityCatalog = null,
  magneticPartFieldQueries,
  magneticPartFieldRevision = null,
  magneticPartFieldVectors,
  sessionIdentity = null,
  targetQuantityFieldRequests,
  targetQuantityFieldRevision = null,
  targetQuantityFieldVectors,
  topology,
  topologyRevision = null,
}: {
  airboxFieldRevision?: ResourceRevision | null;
  airboxFieldVectorRequests?: ReadonlyMap<
    string,
    Viewport3DResolvedFieldResourceRequest
  >;
  airboxFieldVectors?: ReadonlyMap<string, DecodedFieldVector> | null;
  airboxQuantityCompatible?: boolean;
  airboxQuantityId?: string | null;
  airboxSyntheticVectorsEnabled?: boolean;
  quantityCatalog?: QuantityCatalogResource | null;
  getPartSettings: (part: Viewport3DMeshPart) => VisualizationTargetSettings;
  magneticPartFieldQueries?: ReadonlyMap<
    string,
    Viewport3DResolvedFieldResourceRequest
  >;
  magneticPartFieldRevision?: ResourceRevision | null;
  magneticPartFieldVectors?: ReadonlyMap<string, DecodedFieldVector> | null;
  sessionIdentity?: SessionResourceIdentity | null;
  targetQuantityFieldRequests?: ReadonlyMap<
    string,
    Viewport3DResolvedFieldResourceRequest
  >;
  targetQuantityFieldRevision?: ResourceRevision | null;
  targetQuantityFieldVectors?: ReadonlyMap<string, DecodedFieldVector> | null;
  topology:
    | Pick<
        Viewport3DTopologyRenderModel<Viewport3DMeshPart>,
        | "airboxParts"
        | "magneticParts"
        | "meshGenerationId"
        | "meshRevision"
        | "meshTopologyHash"
        | "nodeCount"
      >
    | null
    | undefined;
  topologyRevision?: string | null;
}): {
  partFieldVectors: Map<string, DecodedFieldVector>;
  partTargetFieldBuffers: Map<string, Viewport3DTargetFieldBuffer>;
} {
  const partFieldVectors = new Map<string, DecodedFieldVector>();
  const partTargetFieldBuffers = new Map<string, Viewport3DTargetFieldBuffer>();
  const resolvedTopologyRevision = topologyRevision ?? null;

  const setResolvedPartFieldVector = ({
    fieldRevision,
    fieldVector,
    partId,
    request,
  }: {
    fieldRevision: ResourceRevision | null;
    fieldVector: DecodedFieldVector;
    partId: string;
    request?: Viewport3DResolvedFieldResourceRequest | null;
  }): void => {
    const part = topology?.magneticParts.find(model => model.part.id === partId)?.part;
    if (part && getPartSettings(part).tensorProjection === "frobenius") {
      const descriptor = quantityCatalog?.quantities.find(entry => sameViewport3DQuantityId(entry.id, fieldVector.quantityId))?.tensor;
      if (isFlowMajorTensorDescriptor(descriptor) && fieldVector.nComp === 9 && fieldVector.values.length === fieldVector.pointCount * 9) {
        fieldVector = retainTensorSurfaceField(fieldVector, descriptor);
      }
    }
    if (!request) {
      partFieldVectors.set(partId, fieldVector);
      return;
    }
    partTargetFieldBuffers.set(
      partId,
      buildViewport3DTargetFieldBuffer({
        consumers: request.consumers ?? [],
        fieldRevision: fieldRevision == null ? null : String(fieldRevision),
        fieldVector,
        domain: topology
          ? {
              domainGenerationId: topology.meshGenerationId,
              meshTopologyHash: topology.meshTopologyHash,
              meshTopologyRevision:
                topology.meshRevision == null ? null : String(topology.meshRevision),
              pointCount: topology.nodeCount,
            }
          : undefined,
        query: request.query,
        resourceKey:
          request.resourceKey ??
          (request.quantityId
            ? resolveViewport3DFieldVectorResourceKey(
                request.quantityId,
                request.query,
              )
            : null),
        sessionIdentity,
        targetIds: [partId],
        topologyRevision: resolvedTopologyRevision,
      }),
    );
  };

  if (targetQuantityFieldVectors && topology) {
    for (const partModel of topology.magneticParts) {
      const partId = partModel.part.id;
      const targetQuantityId = resolveCanonicalQuantityId(
        getPartSettings(partModel.part).activeQuantityId,
      );
      const resolved = resolveViewport3DTargetQuantityFieldVectorForTarget({
        fieldVectors: targetQuantityFieldVectors,
        quantityId: targetQuantityId,
        requests: targetQuantityFieldRequests,
        targetId: partId,
      });
      if (!resolved) continue;
      setResolvedPartFieldVector({
        fieldRevision: targetQuantityFieldRevision,
        fieldVector: resolved.fieldVector,
        partId,
        request: resolved.request,
      });
    }
    if (airboxQuantityCompatible) {
      const targetQuantityId = resolveCanonicalQuantityId(airboxQuantityId ?? "m");
      for (const partModel of topology.airboxParts) {
        const partId = partModel.part.id;
        const resolved = resolveViewport3DTargetQuantityFieldVectorForTarget({
          fieldVectors: targetQuantityFieldVectors,
          quantityId: targetQuantityId,
          requests: targetQuantityFieldRequests,
          targetId: partId,
        });
        if (!resolved) continue;
        setResolvedPartFieldVector({
          fieldRevision: targetQuantityFieldRevision,
          fieldVector: resolved.fieldVector,
          partId,
          request: resolved.request,
        });
      }
    }
  }

  for (const [partId, fieldVector] of magneticPartFieldVectors ?? []) {
    setResolvedPartFieldVector({
      fieldRevision: magneticPartFieldRevision,
      fieldVector,
      partId,
      request: magneticPartFieldQueries?.get(partId),
    });
  }

  for (const [partId, fieldVector] of airboxFieldVectors ?? []) {
    const request = airboxFieldVectorRequests?.get(partId);
    if (!request) continue;
    setResolvedPartFieldVector({
      fieldRevision: airboxFieldRevision,
      fieldVector,
      partId,
      request,
    });
  }

  if (airboxSyntheticVectorsEnabled && topology) {
    const syntheticTopologyIdentity =
      resolvedTopologyRevision ??
      (topology.meshRevision == null ? null : String(topology.meshRevision)) ??
      topology.meshTopologyHash ??
      topology.meshGenerationId;
    const syntheticFieldRevision = syntheticTopologyIdentity
      ? `synthetic:airbox:+z:topology=${encodeURIComponent(syntheticTopologyIdentity)}`
      : null;
    for (const partModel of topology.airboxParts) {
      const partId = partModel.part.id;
      if (partFieldVectors.has(partId) || partTargetFieldBuffers.has(partId)) {
        continue;
      }
      const fieldVector = buildViewport3DAirboxSyntheticVectorField(
        partModel.part,
        topology.nodeCount,
      );
      if (!fieldVector) continue;
      partTargetFieldBuffers.set(
        partId,
        buildViewport3DTargetFieldBuffer({
          fieldRevision: syntheticFieldRevision,
          fieldVector,
          domain: {
            domainGenerationId: topology.meshGenerationId,
            meshTopologyHash: topology.meshTopologyHash,
            meshTopologyRevision:
              topology.meshRevision == null ? null : String(topology.meshRevision),
            pointCount: topology.nodeCount,
          },
          query: {
            component: "full",
            scope_id: partId,
            scope_kind: "airbox",
          },
          resourceKey: null,
          sessionIdentity,
          synthetic: true,
          targetIds: [partId],
          topologyRevision: resolvedTopologyRevision,
        }),
      );
    }
  }

  return {
    partFieldVectors:
      partTargetFieldBuffers.size > 0
        ? new Map<string, DecodedFieldVector>()
        : partFieldVectors,
    partTargetFieldBuffers,
  };
}

function resolveViewport3DTargetQuantityFieldVectorForTarget({
  fieldVectors,
  quantityId,
  requests,
  targetId,
}: {
  fieldVectors: ReadonlyMap<string, DecodedFieldVector>;
  quantityId: string;
  requests?: ReadonlyMap<string, Viewport3DResolvedFieldResourceRequest>;
  targetId: string;
}): {
  fieldVector: DecodedFieldVector;
  request: Viewport3DResolvedFieldResourceRequest | null;
  requestId: string;
} | null {
  const canonicalQuantityId = resolveCanonicalQuantityId(quantityId);
  for (const [requestId, request] of requests ?? []) {
    if (!fieldVectors.has(requestId)) continue;
    if (request.quantityId && !sameViewport3DQuantityId(
      request.quantityId,
      canonicalQuantityId,
    )) {
      continue;
    }
    const consumers = request.consumers ?? [];
    if (!consumers.some((consumer) => consumer.startsWith(`${targetId}:`))) {
      continue;
    }
    return {
      fieldVector: fieldVectors.get(requestId)!,
      request,
      requestId,
    };
  }

  return null;
}

export function resolveViewport3DFdmTargetFieldVectorForTarget({
  primaryFieldQuantityId,
  primaryFieldVector,
  quantityId,
  targetFieldRequests,
  targetFieldVectors,
  targetId,
}: {
  primaryFieldQuantityId: string;
  primaryFieldVector: DecodedFieldVector | null;
  quantityId: string;
  targetFieldRequests?: ReadonlyMap<string, Viewport3DFieldResourceRequest>;
  targetFieldVectors?: ReadonlyMap<string, DecodedFieldVector> | null;
  targetId: string;
}): {
  fieldVector: DecodedFieldVector;
  request: Viewport3DFieldResourceRequest | null;
  requestId: string;
} | null {
  const canonicalQuantityId = resolveCanonicalQuantityId(quantityId);
  if (targetFieldVectors) {
    const resolved = resolveViewport3DTargetQuantityFieldVectorForTarget({
      fieldVectors: targetFieldVectors,
      quantityId: canonicalQuantityId,
      requests: targetFieldRequests,
      targetId,
    });
    if (
      resolved &&
      sameViewport3DQuantityId(resolved.fieldVector.quantityId, canonicalQuantityId)
    ) {
      return {
        fieldVector: resolved.fieldVector,
        request: targetFieldRequests?.get(resolved.requestId) ?? null,
        requestId: resolved.requestId,
      };
    }
  }
  if (sameViewport3DQuantityId(primaryFieldQuantityId, canonicalQuantityId)) {
    if (
      !primaryFieldVector ||
      !sameViewport3DQuantityId(primaryFieldVector.quantityId, canonicalQuantityId)
    ) {
      return null;
    }
    return {
      fieldVector: primaryFieldVector,
      request: null,
      requestId: "primary-field-vector",
    };
  }

  return null;
}

function resolveViewport3DPartScalarRangeResourceKey(
  requests: ReadonlyMap<string, Viewport3DPartScalarRangeRequest>,
): string {
  const suffix = Array.from(requests.values(), (request) =>
    resolveFieldMetaResourceKey(request.quantityId, {
      component: request.component,
      scope_id: request.scopeId,
      scope_kind: request.scopeKind,
      snapshot_id: request.snapshot_id,
      stage_id: request.stage_id,
    }),
  ).join("|");
  return suffix
    ? `${DATA_FIELDS_PATH}#viewport-3d:part-scalar-ranges:${suffix}`
    : `${DATA_FIELDS_PATH}#viewport-3d:part-scalar-ranges:none`;
}

function resolveViewport3DPartScalarRangesRevision(
  data: ReadonlyMap<string, ReadonlyMap<string, ScalarRange>>,
): string | null {
  return (
    Array.from(data)
      .map(([partId, ranges]) => {
        const range = ranges.values().next().value as ScalarRange | undefined;
        return range ? `${partId}:${range.min}:${range.max}` : `${partId}:none`;
      })
      .join("|") || null
  );
}

function partScalarRangeMetaUnavailable(error: unknown): boolean {
  return error instanceof ControlRoomApiError && error.status === 404;
}

function useViewport3DPartScalarRanges(
  requests: ReadonlyMap<string, Viewport3DPartScalarRangeRequest>,
  enabled: boolean,
  options: { pauseLoad?: boolean } = {},
): ResourceResult<ReadonlyMap<string, ReadonlyMap<string, ScalarRange>>> {
  const { api } = useKernel();
  const resourceKey = useMemo(
    () => resolveViewport3DPartScalarRangeResourceKey(requests),
    [requests],
  );
  const load = useCallback(
    async ({ signal }: { signal: AbortSignal }) => {
      const entries = await Promise.all(
        Array.from(requests, async ([partId, request]) => {
          const meta = await api.data.fields
            .meta(
              request.quantityId,
              {
                component: request.component,
                scope_id: request.scopeId,
                scope_kind: request.scopeKind,
                snapshot_id: request.snapshot_id,
                stage_id: request.stage_id,
              },
              { signal },
            )
            .catch((error: unknown) => {
              if (partScalarRangeMetaUnavailable(error)) return null;
              throw error;
            });
          const range = resolveViewport3DFieldMetaScalarRange(meta);
          return range
            ? [partId, new Map([[request.mode, range]])] as const
            : null;
        }),
      );
      const ranges = new Map<string, ReadonlyMap<string, ScalarRange>>();
      for (const entry of entries) {
        if (entry) {
          ranges.set(entry[0], entry[1]);
        }
      }
      return ranges;
    },
    [api, requests],
  );
  return useResource({
    abortStaleInflight: true,
    enabled: enabled && requests.size > 0,
    load,
    pauseLoad: options.pauseLoad,
    resolveRevision: resolveViewport3DPartScalarRangesRevision,
    resourceKey,
  });
}

function asJsonRecord(value: unknown): JsonRecord | null {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value)
    ? (value as JsonRecord)
    : null;
}

function asNonEmptyString(value: unknown): string | null {
  return typeof value === "string" && value.length > 0 ? value : null;
}

function sceneRegionShape(value: unknown): SceneRegionShape | null {
  const shape = asJsonRecord(value);
  if (!shape) return null;
  const kind = asNonEmptyString(shape.kind);
  if (kind === "box") {
    return isFiniteNumberVector(shape.center, 3) && isFiniteNumberVector(shape.size, 3)
      ? { center: shape.center, kind, size: shape.size }
      : null;
  }
  if (kind === "cylinder") {
    return isFiniteNumberVector(shape.axis, 3) &&
      isFiniteNumberVector(shape.center, 3) &&
      isPositiveFiniteNumber(shape.height) &&
      isPositiveFiniteNumber(shape.radius)
      ? {
          axis: shape.axis,
          center: shape.center,
          height: shape.height,
          kind,
          radius: shape.radius,
        }
      : null;
  }
  if (kind === "sphere") {
    return isFiniteNumberVector(shape.center, 3) && isPositiveFiniteNumber(shape.radius)
      ? { center: shape.center, kind, radius: shape.radius }
      : null;
  }
  return null;
}

function isFiniteNumberVector(value: unknown, length: number): value is number[] {
  return (
    Array.isArray(value) &&
    value.length === length &&
    value.every((entry) => typeof entry === "number" && Number.isFinite(entry))
  );
}

function isPositiveFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value) && value > 0;
}

export function resolveViewport3DRegionOverlays({
  objectTransformsById,
  realizedRegionKeys,
  regionResource,
  scene,
}: {
  objectTransformsById: ReadonlyMap<string, unknown>;
  realizedRegionKeys?: ReadonlySet<string>;
  regionResource?: RegionListResource | null;
  scene: unknown;
}): RegionOverlayInput[] {
  const overlays: RegionOverlayInput[] = [];
  const seen = new Set<string>();

  for (const region of regionResource?.regions ?? []) {
    if (region.source !== "authored_object_region") continue;
    const regionId = asNonEmptyString(region.region_id);
    const objectId = asNonEmptyString(region.owner_object_id);
    if (!regionId || !objectId) continue;
    if (realizedRegionKeys?.has(regionOverlayKey(objectId, regionId))) continue;
    seen.add(regionOverlayKey(objectId, regionId));
    overlays.push({
      enabled: region.enabled,
      frame: region.frame,
      name: region.name,
      owner_object_id: objectId,
      owner_transform: objectTransformsById.get(objectId) ?? null,
      priority: region.priority,
      region_id: regionId,
      shape: region.shape,
    });
  }

  const sceneRecord = asJsonRecord(scene);
  if (!Array.isArray(sceneRecord?.objects)) return overlays;

  for (const objectValue of sceneRecord.objects) {
    const object = asJsonRecord(objectValue);
    const objectId = asNonEmptyString(object?.id);
    if (!objectId || !Array.isArray(object?.regions)) continue;
    for (const regionValue of object.regions) {
      const region = asJsonRecord(regionValue);
      const regionId = asNonEmptyString(region?.region_id) ?? asNonEmptyString(region?.id);
      if (!regionId || seen.has(regionOverlayKey(objectId, regionId))) continue;
      if (realizedRegionKeys?.has(regionOverlayKey(objectId, regionId))) continue;
      const shape = sceneRegionShape(region?.shape);
      if (!shape) continue;
      seen.add(regionOverlayKey(objectId, regionId));
      overlays.push({
        enabled: region?.enabled !== false && object.visible !== false,
        frame: asNonEmptyString(region?.frame),
        name: asNonEmptyString(region?.name),
        owner_object_id: objectId,
        owner_transform: objectTransformsById.get(objectId) ?? asJsonRecord(object?.transform),
        priority: typeof region?.priority === "number" ? region.priority : null,
        region_id: regionId,
        shape,
      });
    }
  }

  return overlays;
}

function regionOverlayKey(objectId: string, regionId: string): string {
  return `${objectId}\u0000${regionId}`;
}

export function resolveViewport3DMeshBackedRegionKeys(
  regions: MeshSharedDomainManifestResource["regions"] | null | undefined,
): Set<string> {
  const keys = new Set<string>();
  for (const region of regions ?? []) {
    const regionId = asNonEmptyString(region.source_region_candidate_id);
    if (!regionId || !region.mesh_part_ids || region.mesh_part_ids.length === 0) {
      continue;
    }
    for (const objectId of region.source_object_ids ?? []) {
      const owner = asNonEmptyString(objectId);
      if (owner) {
        keys.add(regionOverlayKey(canonicalVisualizationSceneObjectId(owner), regionId));
      }
    }
  }
  return keys;
}

export function filterViewport3DMeshBackedRegionOverlays(
  regions: readonly RegionOverlayInput[],
  meshBackedRegionKeys: ReadonlySet<string>,
): RegionOverlayInput[] {
  return regions.filter((region) => {
    const objectId = asNonEmptyString(region.owner_object_id);
    const regionId = asNonEmptyString(region.region_id);
    return Boolean(
      objectId &&
        regionId &&
        meshBackedRegionKeys.has(regionOverlayKey(objectId, regionId)),
    );
  });
}

export function resolveViewport3DRegionMembershipIds({
  meshBackedRegionKeys,
  regions,
}: {
  meshBackedRegionKeys: ReadonlySet<string>;
  regions: readonly RegionOverlayInput[];
}): string[] {
  const regionIds: string[] = [];
  const seen = new Set<string>();
  for (const region of regions) {
    const objectId = asNonEmptyString(region.owner_object_id);
    const regionId = asNonEmptyString(region.region_id);
    if (!objectId || !regionId || seen.has(regionId)) continue;
    if (meshBackedRegionKeys.has(regionOverlayKey(objectId, regionId))) continue;
    seen.add(regionId);
    regionIds.push(regionId);
  }
  return regionIds;
}

export function resolveViewport3DMeshBackedRegionOverlays({
  manifestRegions,
  regions,
}: {
  manifestRegions: MeshSharedDomainManifestResource["regions"] | null | undefined;
  regions: readonly RegionOverlayInput[];
}): RegionOverlayInput[] {
  const authoredByKey = new Map<string, RegionOverlayInput>();
  for (const region of regions) {
    const objectId = asNonEmptyString(region.owner_object_id);
    const regionId = asNonEmptyString(region.region_id);
    if (objectId && regionId) {
      authoredByKey.set(regionOverlayKey(objectId, regionId), region);
    }
  }

  const overlays: RegionOverlayInput[] = [];
  const seen = new Set<string>();
  for (const manifestRegion of manifestRegions ?? []) {
    const regionId = asNonEmptyString(manifestRegion.source_region_candidate_id);
    const meshPartIds = (manifestRegion.mesh_part_ids ?? []).flatMap((entry) => {
      const meshPartId = asNonEmptyString(entry);
      return meshPartId ? [meshPartId] : [];
    });
    if (!regionId || meshPartIds.length === 0) continue;

    for (const sourceObjectId of manifestRegion.source_object_ids ?? []) {
      const objectId = asNonEmptyString(sourceObjectId);
      if (!objectId) continue;
      const key = regionOverlayKey(objectId, regionId);
      if (seen.has(key)) continue;
      seen.add(key);

      const authored = authoredByKey.get(key);
      overlays.push({
        enabled: authored?.enabled ?? true,
        frame: authored?.frame ?? null,
        mesh_part_ids: meshPartIds,
        name: manifestRegion.name ?? authored?.name ?? regionId,
        owner_object_id: objectId,
        owner_transform: authored?.owner_transform ?? null,
        priority: authored?.priority ?? null,
        region_id: regionId,
        shape: authored?.shape ?? null,
      });
    }
  }

  return overlays;
}

export function resolveViewport3DMembershipRegionOverlays({
  memberships,
  regions,
}: {
  memberships: readonly MeshRegionMembershipResource[];
  regions: readonly RegionOverlayInput[];
}): {
  ownerParts: RegionMeshOverlayOwnerPart[];
  regions: RegionOverlayInput[];
} {
  const authoredByKey = new Map<string, RegionOverlayInput>();
  for (const region of regions) {
    const objectId = asNonEmptyString(region.owner_object_id);
    const regionId = asNonEmptyString(region.region_id);
    if (objectId && regionId) {
      authoredByKey.set(regionOverlayKey(objectId, regionId), region);
    }
  }

  const overlayRegions: RegionOverlayInput[] = [];
  const ownerParts: RegionMeshOverlayOwnerPart[] = [];
  const seen = new Set<string>();
  for (const membership of memberships) {
    const objectId = asNonEmptyString(membership.owner_object_id);
    const regionId = asNonEmptyString(membership.region_id);
    if ((membership.mesh_part_ids ?? []).some((partId) => asNonEmptyString(partId))) {
      continue;
    }
    if (!objectId || !regionId) continue;
    const key = regionOverlayKey(objectId, regionId);
    const authored = authoredByKey.get(key);
    if (!authored || seen.has(key)) {
      continue;
    }

    const syntheticPartId = `membership:${encodeURIComponent(objectId)}:${encodeURIComponent(regionId)}`;
    seen.add(key);
    overlayRegions.push({
      ...authored,
      mesh_part_ids: [syntheticPartId],
    });
    ownerParts.push({
      boundary_face_indices: membership.boundary_face_indices,
      element_indices: membership.element_indices,
      id: syntheticPartId,
      node_indices: membership.node_indices,
      object_id: objectId,
      region_id: regionId,
    });
  }

  return {
    ownerParts,
    regions: overlayRegions,
  };
}

export function resolveViewport3DRegionTargetByPartId(
  regions: MeshSharedDomainManifestResource["regions"] | null | undefined,
): Map<string, VisualizationTargetRef> {
  const targets = new Map<string, VisualizationTargetRef>();
  for (const region of regions ?? []) {
    const regionId = asNonEmptyString(region.source_region_candidate_id);
    if (!regionId || !region.mesh_part_ids || region.mesh_part_ids.length === 0) {
      continue;
    }
    const sourceObjectIds = (region.source_object_ids ?? [])
      .map((sourceObjectId) => asNonEmptyString(sourceObjectId))
      .filter((sourceObjectId): sourceObjectId is string => sourceObjectId !== null);
    if (sourceObjectIds.length !== 1) continue;
    const objectId = sourceObjectIds[0];
    if (!objectId) continue;
    if (
      canonicalVisualizationSceneObjectId(regionId) ===
        canonicalVisualizationSceneObjectId(objectId)
    ) {
      continue;
    }
    const target: VisualizationTargetRef = {
      id: visualizationTargetIdForSceneObject(objectId, regionId),
      kind: "region",
      label: region.name ?? regionId,
    };
    for (const partId of region.mesh_part_ids) {
      const id = asNonEmptyString(partId);
      if (id) targets.set(id, target);
    }
  }
  return targets;
}

export function resolveViewport3DRegionTargetsForMembershipOwnerParts({
  manifestRegions,
  ownerParts,
  regions,
}: {
  manifestRegions: MeshSharedDomainManifestResource["regions"] | null | undefined;
  ownerParts: readonly RegionMeshOverlayOwnerPart[];
  regions: readonly RegionOverlayInput[];
}): Map<string, VisualizationTargetRef> {
  const targets = resolveViewport3DRegionTargetByPartId(manifestRegions);
  const regionsByKey = new Map<string, RegionOverlayInput>();
  for (const region of regions) {
    const objectId = asNonEmptyString(region.owner_object_id);
    const regionId = asNonEmptyString(region.region_id);
    if (objectId && regionId) {
      regionsByKey.set(regionOverlayKey(objectId, regionId), region);
    }
  }

  for (const part of ownerParts) {
    const partId = asNonEmptyString(part.id);
    const objectId = asNonEmptyString(part.object_id);
    const regionId = asNonEmptyString(part.region_id);
    if (!partId || !objectId || !regionId) continue;
    const label = regionsByKey.get(regionOverlayKey(objectId, regionId))?.name ?? regionId;
    targets.set(partId, {
      id: visualizationTargetIdForSceneObject(objectId, regionId),
      kind: "region",
      label,
    });
  }
  return targets;
}

export function resolveViewport3DPrimitiveVisualizationSettings(
  input: Parameters<typeof resolveTargetVisualization>[0],
): VisualizationTargetSettings {
  const { settings, effectiveSettings } = resolveTargetVisualization(input);
  // A rejected field cannot remove the requested field-free geometry preview.
  if (settings.visible && settings.shaderVisible && !effectiveSettings.shaderVisible) {
    return { ...effectiveSettings, primitiveVisible: true };
  }
  return effectiveSettings;
}

export function resolveViewport3DPartVisualizationSettings({
  objectVisualizationSnapshot,
  part,
  regionTarget,
  renderingState,
  sceneObjectIds,
  sceneObjectsById,
  quantityCatalog,
}: {
  objectVisualizationSnapshot: ObjectVisualizationSnapshot;
  part: Viewport3DMeshPart;
  regionTarget?: VisualizationTargetRef | null;
  renderingState?: VisualizationStateResource | null;
  sceneObjectIds?: ReadonlySet<string>;
  sceneObjectsById?: ReadonlyMap<string, NonNullable<VisualizationObjectContext["object"]>>;
  quantityCatalog?: QuantityCatalogResource | null;
}): VisualizationTargetSettings & { target: VisualizationTargetRef } {
  const target = resolveVisualizationTargetForMeshPart({
    part,
    sceneObjectIds: sceneObjectIds ?? new Set(),
    targetRegistry: renderingState?.targets,
  });
  const ownerId = target.kind === "object"
    ? target.id.slice("object:".length) : visualizationObjectIdForMeshPartLike(part);
  const objectContext = sceneObjectsById && ownerId && target.kind !== "airbox" ? {
    object: ownerId ? sceneObjectsById.get(ownerId) ?? null : null,
    quantityCatalog: quantityCatalog ?? null,
  } : undefined;
  const objectVisualization = resolveTargetVisualization({
    objectContext,
    snapshot: objectVisualizationSnapshot,
    target,
    visualizationState: renderingState,
  });
  if (!regionTarget) {
    return { ...objectVisualization.effectiveSettings, target };
  }
  const regionVisualization = resolveTargetVisualization({
    objectContext,
    inheritedSettings: objectVisualization.settings,
    snapshot: objectVisualizationSnapshot,
    target: regionTarget,
    visualizationState: renderingState,
  });
  return { ...regionVisualization.effectiveSettings, target };
}

export function resolveViewport3DRegionSelectionBounds(
  selection: Selection,
  regions: readonly RegionOverlayInput[],
): Viewport3DBounds | null {
  const regionId =
    selection.ref?.type === "scene-object" ? selection.ref.regionId : null;
  if (!regionId) return null;
  const objectId =
    selection.ref?.type === "scene-object"
      ? selection.ref.objectId
      : selection.objectId;
  const models = buildRegionOverlayModels(regions, {
    selectedObjectId: objectId,
    selectedRegionId: regionId,
  });
  const region = models.find((entry) => entry.regionId === regionId);
  return region ? regionOverlayBounds(region) : null;
}

export function resolveViewport3DRegionSelectionScope(selection: Selection): {
  selectedObjectId: string | null;
  selectedRegionId: string | null;
} {
  if (selection.ref?.type === "scene-object") {
    return {
      selectedObjectId: selection.ref.objectId,
      selectedRegionId: selection.ref.regionId ?? null,
    };
  }

  if (selection.kind?.startsWith("object.")) {
    return {
      selectedObjectId: selection.objectId,
      selectedRegionId: null,
    };
  }

  return {
    selectedObjectId: null,
    selectedRegionId: null,
  };
}

function regionOverlayBounds(region: RegionOverlayModel): Viewport3DBounds {
  const center = transformedRegionCenter(region);
  const size = regionOverlaySize(region);
  return {
    center,
    radius: Math.max(Math.hypot(size[0], size[1], size[2]) / 2, 1e-12),
    size,
  };
}

function transformedRegionCenter(
  region: RegionOverlayModel,
): [number, number, number] {
  return [
    region.transform.position[0] + region.center[0],
    region.transform.position[1] + region.center[1],
    region.transform.position[2] + region.center[2],
  ];
}

function regionOverlaySize(region: RegionOverlayModel): [number, number, number] {
  if (region.kind === "box") {
    return [region.size[0], region.size[1], region.size[2]];
  }
  if (region.kind === "sphere") {
    const diameter = region.radius * 2;
    return [diameter, diameter, diameter];
  }
  const diameter = region.radius * 2;
  return [diameter, diameter, region.height];
}

export interface Viewport3DResourceFrameInput {
  dataAvailable: boolean;
  error?: string | null;
  id: string;
  materializationState?:
    | components["schemas"]["FieldMaterializationState"]
    | null;
  payloadRevision: ResourceRevision | null;
  revision: ResourceRevision | null;
  status: ResourceStatus;
}

export interface Viewport3DFieldDataIssue {
  key: string;
  message: string;
  quantityId: string;
  resourceKey: string;
  retry: () => void;
}

export interface Viewport3DFieldDataIssueInput {
  fieldVectorEnabled: boolean;
  fieldVectorErrorMessage: string | null;
  fieldVectorRefetch: () => void;
  fieldVectorResourceKey: string;
  fieldVectorRevision: ResourceRevision | null;
  fieldVectorStatus?: ResourceStatus;
  fieldVectorDataAvailable?: boolean;
  hysteresisReplayMeshCompatibility: HysteresisReplayMeshCompatibility;
  primaryFieldQuantityId: string;
}

export function resolveViewport3DVisualizationQuantityId(
  state: VisualizationStateResource | null | undefined,
): string {
  return resolveCanonicalQuantityId(
    state?.quantity?.active_quantity_id ?? state?.active_quantity_id ?? "m",
  );
}

export function resolveViewport3DFieldDataIssue({
  fieldVectorEnabled,
  fieldVectorErrorMessage,
  fieldVectorRefetch,
  fieldVectorResourceKey,
  fieldVectorRevision,
  fieldVectorStatus = "ready",
  fieldVectorDataAvailable = true,
  hysteresisReplayMeshCompatibility,
  primaryFieldQuantityId,
}: Viewport3DFieldDataIssueInput): Viewport3DFieldDataIssue | null {
  if (hysteresisReplayMeshCompatibility.status === "mismatch") {
    const message =
      hysteresisReplayMeshCompatibility.reason ??
      "Selected hysteresis snapshot was computed on a different mesh.";
    return {
      key: `${fieldVectorResourceKey}:mesh-mismatch:${hysteresisReplayMeshCompatibility.requiredMeshIdentity ?? "unknown"}:${hysteresisReplayMeshCompatibility.actualMeshIdentity ?? "unknown"}`,
      message,
      quantityId: primaryFieldQuantityId,
      resourceKey: fieldVectorResourceKey,
      retry: fieldVectorRefetch,
    };
  }

  if (!(fieldVectorEnabled && fieldVectorErrorMessage)) {
    if (
      !fieldVectorEnabled ||
      fieldVectorStatus !== "ready" ||
      fieldVectorDataAvailable
    ) {
      return null;
    }
    return {
      key: `${fieldVectorResourceKey}:${fieldVectorRevision ?? "none"}:not-materialized`,
      message:
        "Field vector is not materialized for the selected quantity. Retry to request it again.",
      quantityId: primaryFieldQuantityId,
      resourceKey: fieldVectorResourceKey,
      retry: fieldVectorRefetch,
    };
  }
  const message =
    fieldVectorErrorMessage.trim() || "Field vector resource failed to load.";
  return {
    key: `${fieldVectorResourceKey}:${fieldVectorRevision ?? "none"}:${message}`,
    message,
    quantityId: primaryFieldQuantityId,
    resourceKey: fieldVectorResourceKey,
    retry: fieldVectorRefetch,
  };
}

/**
 * HUD status text with field-data failures removed when the viewport issue
 * banner already reports them (R24: one foreground failure surface). Only the
 * exact messages the banner owns are dropped; any other status, including
 * higher-priority topology/build errors, is kept.
 */
export function resolveViewport3DHudStatus({
  bannerOwnedMessages,
  fieldDataIssue,
  status,
}: {
  bannerOwnedMessages: ReadonlyArray<string | null | undefined>;
  fieldDataIssue: Pick<Viewport3DFieldDataIssue, "message"> | null;
  status: string;
}): string {
  if (!fieldDataIssue) return status;
  const normalizedStatus = status.trim();
  if (normalizedStatus === fieldDataIssue.message.trim()) return "";
  for (const message of bannerOwnedMessages) {
    if (message && normalizedStatus === message.trim()) return "";
  }
  return status;
}

export function resolveViewport3DSelectedSnapshotId(
  selection: Selection,
): string | null {
  const hysteresisTarget = resolveHysteresisStepViewportTarget(selection);
  if (hysteresisTarget) return hysteresisTarget.snapshotId;
  if (selection.ref?.type !== "analysis-chart-point") return null;
  return selection.ref.snapshotId ?? null;
}

export function resolveViewport3DSelectedSnapshotQuery(
  selection: Selection,
): FieldVectorQuery | null {
  const hysteresisTarget = resolveHysteresisStepViewportTarget(selection);
  if (!hysteresisTarget) {
    const snapshotId =
      selection.ref?.type === "analysis-chart-point"
        ? selection.ref.snapshotId ?? null
        : null;
    return snapshotId ? { snapshot_id: snapshotId } : null;
  }

  const params = resourceRefSearchParams(hysteresisTarget.resourceRef);
  return {
    snapshot_id: params?.get("snapshot_id") ?? hysteresisTarget.snapshotId,
    stage_id: params?.get("stage_id") ?? hysteresisTarget.stageId,
  };
}

function resourceRefSearchParams(resourceRef: string | null): URLSearchParams | null {
  const query = resourceRef?.split("?", 2)[1];
  return query ? new URLSearchParams(query) : null;
}

/** The live model has no implicit magnetic field when its authored support is empty. */
export function resolveViewport3DModelQuantityId(
  requested: string,
  quantityCatalog: QuantityCatalogResource | null,
  objects: readonly NonNullable<VisualizationObjectContext["object"]>[] | null,
): string {
  if (!quantityCatalog || !objects) return "";
  const id = resolveCanonicalQuantityId(requested);
  const entry = quantityCatalog.quantities.find((quantity) => resolveCanonicalQuantityId(quantity.id) === id);
  if (!entry || !quantityCatalogEntrySupportsSpatialVisualization(entry)) return "";
  if (entry.domain === "magnetic_only" && objects.every(hasEmptyObjectMagneticModel)) return "";
  return id;
}

/** Runtime overlays consume published fields; a run identity alone is not field support. */
export function resolveViewport3DPublishedModelQuantityIds(
  fieldQuantityIds: ReadonlySet<string> | null,
  quantityCatalog: QuantityCatalogResource | null,
  objects: readonly NonNullable<VisualizationObjectContext["object"]>[] | null,
): ReadonlySet<string> {
  return new Set(
    [...(fieldQuantityIds ?? [])]
      .map((id) => resolveViewport3DModelQuantityId(id, quantityCatalog, objects))
      .filter(Boolean),
  );
}

export function resolveViewport3DActiveQuantityId({
  selectedSnapshotId,
  selection,
  visualizationState,
}: {
  selectedSnapshotId: string | null;
  selection: Selection;
  visualizationState: VisualizationStateResource | null | undefined;
}): string {
  if (selectedSnapshotId) {
    const hysteresisTarget = resolveHysteresisStepViewportTarget(selection);
    if (hysteresisTarget?.quantityId) {
      return resolveCanonicalQuantityId(hysteresisTarget.quantityId);
    }
    if (selection.ref?.type === "analysis-chart-point" && selection.ref.quantity) {
      return resolveCanonicalQuantityId(selection.ref.quantity);
    }
  }
  return resolveViewport3DVisualizationQuantityId(visualizationState);
}

export function resolveViewport3DPrimaryFieldVectorEnabled({
  fdmInstanceModelNeedsFieldVector,
  fdmSurfaceColorMode,
  fdmVectorsVisible,
  fieldRenderOptions,
  selectedSnapshotId,
}: {
  fdmInstanceModelNeedsFieldVector: boolean;
  fdmSurfaceColorMode: string | null;
  fdmVectorsVisible: boolean;
  fieldRenderOptions: Viewport3DFieldRenderOptions;
  selectedSnapshotId: string | null;
}): boolean {
  return (
    Boolean(selectedSnapshotId) ||
    viewport3DFieldRenderOptionsNeedFieldData(fieldRenderOptions) ||
    Boolean(fdmSurfaceColorMode) ||
    fdmVectorsVisible ||
    fdmInstanceModelNeedsFieldVector
  );
}

export function resolveViewport3DDisplayedLiveValue<TValue>(
  incoming: TValue | null,
  previousDisplayed: TValue | null,
  holdActive: boolean,
): TValue | null {
  return holdActive ? previousDisplayed : incoming;
}

export interface Viewport3DPrimaryFieldRetainedState {
  envelope: Viewport3DFieldVectorEnvelope;
  revision: string | null;
}

export interface ResolvePrimaryFieldDisplayedEnvelopeResult {
  displayedEnvelope: Viewport3DFieldVectorEnvelope | null;
  displayedRevision: string | null;
  nextRetained: Viewport3DPrimaryFieldRetainedState | null;
}

export function resolvePrimaryFieldDisplayedEnvelope({
  incomingEnvelope,
  status,
  preparedRevision,
  retained,
  request,
  sourceResourceKey,
  tracker,
}: {
  incomingEnvelope: Viewport3DFieldVectorEnvelope | null;
  status: string;
  preparedRevision: string | null;
  retained: Viewport3DPrimaryFieldRetainedState | null;
  request: Pick<Viewport3DFieldResourceRequest, "quantityId" | "query">;
  sourceResourceKey?: string;
  tracker?: Viewport3DResourceTracker;
}): ResolvePrimaryFieldDisplayedEnvelopeResult {
  if (status === "ready" && incomingEnvelope) {
    const incomingMatch = resolveViewport3DFieldVectorIdentityMatch(
      incomingEnvelope,
      request,
    );
    if (incomingMatch.matches) {
      if (
        retained &&
        retained.envelope.data === incomingEnvelope.data &&
        retained.envelope.retained === false &&
        retained.revision === preparedRevision
      ) {
        return {
          displayedEnvelope: retained.envelope,
          displayedRevision: preparedRevision,
          nextRetained: retained,
        };
      }
      const freshEnvelope: Viewport3DFieldVectorEnvelope =
        incomingEnvelope.retained === false
          ? incomingEnvelope
          : {
              ...incomingEnvelope,
              retained: false,
            };
      return {
        displayedEnvelope: freshEnvelope,
        displayedRevision: preparedRevision,
        nextRetained: {
          envelope: freshEnvelope,
          revision: preparedRevision,
        },
      };
    }
  }

  if (
    retained &&
    sourceResourceKey !== undefined &&
    retained.envelope.resourceKey !== sourceResourceKey
  ) {
    return {
      displayedEnvelope: null,
      displayedRevision: null,
      nextRetained: null,
    };
  }

  if (retained) {
    const retainedMatch = resolveViewport3DFieldVectorIdentityMatch(
      retained.envelope,
      request,
    );
    if (retainedMatch.matches) {
      if (retained.envelope.retained === true) {
        return {
          displayedEnvelope: retained.envelope,
          displayedRevision: retained.revision,
          nextRetained: retained,
        };
      }
      const retainedEnvelope: Viewport3DFieldVectorEnvelope = {
        ...retained.envelope,
        retained: true,
      };
      return {
        displayedEnvelope: retainedEnvelope,
        displayedRevision: retained.revision,
        nextRetained: {
          envelope: retainedEnvelope,
          revision: retained.revision,
        },
      };
    }
    tracker?.recordRetentionRejection(retainedMatch.reason);
    return {
      displayedEnvelope: null,
      displayedRevision: null,
      nextRetained: null,
    };
  }

  if (status !== "ready" && incomingEnvelope) {
    const incomingMatch = resolveViewport3DFieldVectorIdentityMatch(
      incomingEnvelope,
      request,
    );
    if (incomingMatch.matches) {
      const retainedEnvelope: Viewport3DFieldVectorEnvelope =
        incomingEnvelope.retained === true
          ? incomingEnvelope
          : {
              ...incomingEnvelope,
              retained: true,
            };
      return {
        displayedEnvelope: retainedEnvelope,
        displayedRevision: preparedRevision,
        nextRetained: {
          envelope: retainedEnvelope,
          revision: preparedRevision,
        },
      };
    }
  }

  return {
    displayedEnvelope: null,
    displayedRevision: null,
    nextRetained: null,
  };
}

export function sameViewport3DQuantityId(left: string, right: string): boolean {
  return sameRenderableFieldQuantityId(left, right);
}

export function applyViewport3DFieldLayerDiagnosticOverrides(
  options: Viewport3DFieldRenderOptions,
  {
    fieldColorLayersEnabled,
    vectorLayersEnabled,
  }: {
    fieldColorLayersEnabled: boolean;
    vectorLayersEnabled: boolean;
  },
): Viewport3DFieldRenderOptions {
  if (fieldColorLayersEnabled && vectorLayersEnabled) return options;

  return {
    ...options,
    ...(vectorLayersEnabled
      ? {}
      : {
          fullVectorBudget: 0,
          partVectorBudgets: new Map<string, number>(),
        }),
    ...(fieldColorLayersEnabled
      ? {}
      : {
          scalarColorModes: new Set<string>(),
          scalarColorsVisible: false,
        }),
  };
}

export type Viewport3DFieldPresentationFreshness =
  | "current"
  | "stale"
  | "materializing"
  | "loading"
  | "unsupported";

/**
 * Presentation freshness of the primary field. It is deliberately separate
 * from the frame state: a retained last-good payload keeps its frame key,
 * while the user still sees that it is previous data or being materialized.
 */
export function resolveViewport3DFieldPresentationFreshness({
  dataAvailable,
  error,
  materializationState,
  status,
}: Pick<
  Viewport3DResourceFrameInput,
  "dataAvailable" | "error" | "materializationState" | "status"
>): Viewport3DFieldPresentationFreshness | null {
  // Errors are presented by the field-data issue banner.
  if (error || status === "error") return null;
  if (materializationState === "unsupported") return "unsupported";
  if (materializationState === "pending") return "materializing";
  if (status === "stale" || status === "loading" || materializationState === "stale_complete") {
    return dataAvailable ? "stale" : "loading";
  }
  return dataAvailable ? "current" : null;
}

export function resolveViewport3DResourceFrameState({
  dataAvailable,
  error,
  id,
  materializationState,
  payloadRevision,
  revision,
  status,
}: Viewport3DResourceFrameInput): Viewport3DResourceFrameState {
  const visiblePayloadAvailable = dataAvailable && !error;
  return {
    error,
    id,
    revision: visiblePayloadAvailable ? payloadRevision ?? revision : revision,
    status:
      visiblePayloadAvailable &&
      (status === "stale" ||
        materializationState === "stale_complete" ||
        materializationState === "pending")
        ? "ready"
        : status,
  };
}

export function resolveViewport3DTargetFieldQuery({
  surfaceColorMode,
  vectorsVisible,
}: {
  surfaceColorMode: string | null;
  vectorsVisible: boolean;
}): FieldVectorQuery | null {
  return resolveViewport3DTargetFieldQueryFromPlan({
    surfaceColorMode,
    vectorsVisible,
  });
}

export function resolveViewport3DReplayFieldQuery(
  query: FieldVectorQuery,
  snapshotQuery: FieldVectorQuery | null | undefined,
): FieldVectorQuery {
  return snapshotQuery ? { ...query, ...snapshotQuery } : query;
}

export function resolveViewport3DScopedVectorFieldQuery({
  geometryScope,
  maxSamples,
  surfaceColorMode,
  vectorsVisible,
}: {
  geometryScope: "full" | "surface";
  maxSamples: number;
  surfaceColorMode: string | null;
  vectorsVisible: boolean;
}): FieldVectorQuery {
  const query = resolveViewport3DScopedFieldQuery({
    maxSamples,
    surfaceColorMode,
    vectorsVisible,
  });
  return geometryScope === "surface"
    ? { ...query, geometry_scope: "surface" }
    : query;
}

export function resolveViewport3DPrimaryFieldRenderOptions({
  analysisOverlayAppearance,
  analysisOverlayActive = false,
  fieldRenderOptions,
  getPartSettings,
  magneticParts,
  quantityId,
  vectorDomain,
}: {
  analysisOverlayAppearance?: AnalysisFieldOverlayAppearanceState | null;
  analysisOverlayActive?: boolean;
  fieldRenderOptions: Viewport3DFieldRenderOptions;
  getPartSettings: (part: Viewport3DMeshPart) => {
    activeQuantityId: string;
    tensorProjection?: VisualizationTargetSettings["tensorProjection"];
    geometryScope?: "surface" | "full";
    scalarColorPalette?: string;
    shaderMonoColor?: string;
    shaderVisible: boolean;
    surfaceColorSource: SurfaceColorSource;
    surfaceProjectionMode?: SurfaceFieldProjectionMode;
    vectorBudget: number;
    vectorCenteringEnabled?: boolean;
    vectorColorMode?: "orientation" | "x" | "y" | "z" | "magnitude" | "monochrome";
    vectorLengthScale?: number;
    vectorSurfaceOffsetEnabled?: boolean;
    vectorSurfaceOffsetScale?: number;
    vectorsVisible: boolean;
    viewportColorbarVisible?: boolean;
    visible: boolean;
  };
  magneticParts: readonly { part: Viewport3DMeshPart }[];
  quantityId: string;
  vectorDomain: string;
}): Viewport3DFieldRenderOptions {
  if (magneticParts.length === 0) {
    return fieldRenderOptions;
  }

  const magneticVectorsAllowed = vectorDomain !== "airbox_only";
  const partVectorBudgets = new Map(fieldRenderOptions.partVectorBudgets ?? []);
  const partScalarColorModes = analysisOverlayActive
    ? new Map<string, string>()
    : new Map(fieldRenderOptions.partScalarColorModes ?? []);
  const partScalarColorPalettes = analysisOverlayActive
    ? new Map<string, string>()
    : new Map(fieldRenderOptions.partScalarColorPalettes ?? []);
  const scalarColorModes = new Set<string>();
  const targetRenderPlans = new Map<string, Viewport3DTargetRenderPlan>(
    fieldRenderOptions.targetRenderPlans ?? [],
  );

  for (const partModel of magneticParts) {
    const partId = partModel.part.id;
    const settings = getPartSettings(partModel.part);
    const effectiveSurfaceColorSource =
      analysisOverlayAppearance?.surfaceColorSource ?? settings.surfaceColorSource;
    const effectiveVectorBudget =
      analysisOverlayAppearance?.vectorBudget ?? settings.vectorBudget;
    targetRenderPlans.set(
      partId,
      buildViewport3DTargetRenderPlan({
        label: partModel.part.label ?? partId,
        quantityId: analysisOverlayActive ? quantityId : settings.activeQuantityId,
        settings: {
          geometryScope: settings.geometryScope ?? "full",
          scalarColorPalette:
            analysisOverlayAppearance?.scalarColorPalette ??
            settings.scalarColorPalette ??
            fieldRenderOptions.partScalarColorPalettes?.get(partId) ??
            fieldRenderOptions.scalarColorPalette ??
            "viridis",
          shaderMonoColor:
            settings.shaderMonoColor ?? DEFAULT_VIEWPORT3D_SHADER_MONO_COLOR,
          shaderVisible:
            analysisOverlayAppearance?.shaderVisible ?? settings.shaderVisible,
          tensorProjection: analysisOverlayActive ? null : settings.tensorProjection,
          surfaceColorSource: effectiveSurfaceColorSource,
          surfaceProjectionMode: settings.surfaceProjectionMode ?? "raw_nodal",
          vectorBudget: effectiveVectorBudget,
          vectorCenteringEnabled: settings.vectorCenteringEnabled ?? true,
          vectorColorMode: settings.vectorColorMode ?? "magnitude",
          vectorLengthScale: settings.vectorLengthScale ?? 1,
          vectorSurfaceOffsetEnabled:
            settings.vectorSurfaceOffsetEnabled ?? false,
          vectorSurfaceOffsetScale: settings.vectorSurfaceOffsetScale ?? 0,
          vectorsVisible:
            magneticVectorsAllowed &&
            (analysisOverlayAppearance?.vectorsVisible ?? settings.vectorsVisible),
          viewportColorbarVisible: settings.viewportColorbarVisible ?? false,
          visible: settings.visible,
        },
        targetId: partId,
        targetKind: "part",
      }),
    );
    if (!settings.visible) {
      partVectorBudgets.delete(partId);
      partScalarColorModes.delete(partId);
      partScalarColorPalettes.delete(partId);
      continue;
    }
    const partUsesPrimaryQuantity = sameViewport3DQuantityId(
      settings.activeQuantityId,
      quantityId,
    );
    if (analysisOverlayAppearance?.shaderVisible ?? settings.shaderVisible) {
      const scalarColorMode = !analysisOverlayActive && settings.tensorProjection && !settings.tensorProjection.startsWith("spin_flow_")
        ? "magnitude"
        : surfaceColorSourceToColorMode(effectiveSurfaceColorSource);
      if (scalarColorMode) {
        if (analysisOverlayActive || partUsesPrimaryQuantity) {
          scalarColorModes.add(scalarColorMode);
        }
        if (!analysisOverlayActive) {
          partScalarColorModes.set(partId, scalarColorMode);
          partScalarColorPalettes.set(
            partId,
            settings.scalarColorPalette ??
              fieldRenderOptions.partScalarColorPalettes?.get(partId) ??
              fieldRenderOptions.scalarColorPalette ??
              "viridis",
          );
        }
      }
    }
    if (
      magneticVectorsAllowed &&
      (!settings.tensorProjection || settings.tensorProjection.startsWith("spin_flow_")) &&
      (analysisOverlayAppearance?.vectorsVisible ?? settings.vectorsVisible) &&
      effectiveVectorBudget > 0
    ) {
      partVectorBudgets.set(partId, effectiveVectorBudget);
    } else {
      partVectorBudgets.delete(partId);
    }
  }

  return {
    ...fieldRenderOptions,
    fullVectorBudget: 0,
    partVectorBudgets,
    partScalarColorModes:
      partScalarColorModes.size > 0 ? partScalarColorModes : undefined,
    partScalarColorPalettes:
      partScalarColorPalettes.size > 0 ? partScalarColorPalettes : undefined,
    targetRenderPlans:
      targetRenderPlans.size > 0 ? targetRenderPlans : undefined,
    scalarColorPalette:
      analysisOverlayAppearance?.scalarColorPalette ??
      fieldRenderOptions.scalarColorPalette,
    scalarColorModes,
    scalarColorsVisible:
      scalarColorModes.size > 0 || partScalarColorModes.size > 0,
  };
}

export function resolveViewport3DPrimaryFieldDataOptions(
  options: Viewport3DFieldRenderOptions,
  excludedPartIds: ReadonlySet<string>,
): Viewport3DFieldRenderOptions {
  let nextOptions = options;
  if (options.partVectorBudgets && excludedPartIds.size > 0) {
    const partVectorBudgets = new Map<string, number>();
    for (const [partId, budget] of options.partVectorBudgets) {
      if (!excludedPartIds.has(partId)) {
        partVectorBudgets.set(partId, budget);
      }
    }

    if (partVectorBudgets.size !== options.partVectorBudgets.size) {
      nextOptions = {
        ...nextOptions,
        partVectorBudgets,
      };
    }
  }
  if (options.targetRenderPlans && excludedPartIds.size > 0) {
    const targetRenderPlans = new Map<string, Viewport3DTargetRenderPlan>();
    for (const [targetId, plan] of options.targetRenderPlans) {
      if (!excludedPartIds.has(targetId)) {
        targetRenderPlans.set(targetId, plan);
      }
    }

    if (targetRenderPlans.size !== options.targetRenderPlans.size) {
      nextOptions = {
        ...nextOptions,
        targetRenderPlans:
          targetRenderPlans.size > 0 ? targetRenderPlans : undefined,
      };
    }
  }

  if (
    nextOptions.scalarColorsVisible !== false &&
    (nextOptions.scalarColorModes?.size ?? 0) === 0
  ) {
    nextOptions = {
      ...nextOptions,
      scalarColorsVisible: false,
    };
  }

  return nextOptions;
}

export function resolveViewport3DFieldRenderModelBuildOptions({
  complexFieldVector,
  fieldRenderOptions,
  fieldVector,
  topology,
}: {
  complexFieldVector: object | null | undefined;
  fieldRenderOptions: Viewport3DFieldRenderOptions;
  fieldVector: Viewport3DFieldVector | null | undefined;
  topology:
    | Viewport3DTopologyRenderModel<Viewport3DRenderablePart>
    | null
    | undefined;
}): Viewport3DFieldRenderOptions {
  const scalarModes = fieldRenderOptions.scalarColorModes ?? new Set<string>();
  const fieldColorTarget = resolveViewport3DChunkedFieldColorTarget(
    topology,
    fieldVector,
  );
  const globalOffMainThreadScalarColors =
    !complexFieldVector &&
    fieldRenderOptions.scalarColorsVisible !== false &&
    scalarModes.size > 0 &&
    Boolean(fieldVector) &&
    Boolean(fieldColorTarget) &&
    Boolean(topology) &&
    fieldTransformNeedsChunking(
      Math.max(fieldVector?.pointCount ?? 0, topology?.nodeCount ?? 0),
    );
  const partOffMainThreadScalarColors =
    !complexFieldVector &&
    fieldRenderOptions.scalarColorsVisible !== false &&
    Boolean(topology) &&
    Boolean(fieldRenderOptions.partScalarColorModes) &&
    [...(topology?.magneticParts ?? []), ...(topology?.airboxParts ?? [])].some(
      (partModel) => {
        const colorMode = fieldRenderOptions.partScalarColorModes?.get(
          partModel.part.id,
        );
        if (!colorMode || colorMode === "monochrome") return false;
        const partFieldVector = resolveViewport3DTargetFieldInput({
          fallbackFieldVector: fieldVector,
          legacyPartFieldVectors: fieldRenderOptions.partFieldVectors,
          partId: partModel.part.id,
          targetFieldBuffers: fieldRenderOptions.partTargetFieldBuffers,
        }).fieldVector;
        return (
          Boolean(partFieldVector) &&
          fieldTransformNeedsChunking(
            Math.max(
              partFieldVector?.pointCount ?? 0,
              topology?.nodeCount ?? 0,
            ),
          )
        );
      },
    );
  const offMainThreadScalarColors =
    globalOffMainThreadScalarColors || partOffMainThreadScalarColors;

  if (!offMainThreadScalarColors) return fieldRenderOptions;

  return {
    ...fieldRenderOptions,
    scalarColorModes: new Set<string>(),
    scalarColorsVisible: false,
  };
}

function applyAnalysisOverlayAppearance(
  settings: VisualizationTargetSettings,
  appearance: AnalysisFieldOverlayAppearanceState | null | undefined,
): VisualizationTargetSettings {
  if (!appearance) return settings;
  const surfaceColorSource =
    appearance.surfaceColorSource ?? settings.surfaceColorSource;
  const shaderColorMode =
    surfaceColorSource === "solid"
      ? "monochrome"
      : surfaceColorSourceToColorMode(surfaceColorSource) ??
        settings.shaderColorMode;
  return {
    ...settings,
    ...(appearance.scalarColorPalette
      ? { scalarColorPalette: appearance.scalarColorPalette }
      : {}),
    ...(appearance.shaderMonoColor
      ? { shaderMonoColor: appearance.shaderMonoColor }
      : {}),
    ...(appearance.shaderVisible === undefined
      ? {}
      : { shaderVisible: appearance.shaderVisible }),
    shaderColorMode,
    surfaceColorSource,
    ...(appearance.geometryScope ? { geometryScope: appearance.geometryScope } : {}),
    ...(appearance.vectorBudget === undefined
      ? {}
      : { vectorBudget: appearance.vectorBudget }),
    ...(appearance.vectorScale === undefined && appearance.displayGain === undefined
      ? {}
      : {
          vectorLengthScale:
            (appearance.vectorScale ?? 1) * (appearance.displayGain ?? 1),
        }),
    ...(appearance.vectorsVisible === undefined
      ? {}
      : { vectorsVisible: appearance.vectorsVisible }),
  };
}

export function buildViewport3DAirboxSyntheticVectorField(
  part: Viewport3DMeshPart,
  nodeCount: number,
): DecodedFieldVector | null {
  const pointCount = resolveNodeSelectionCount(part, { nodeCount });
  if (pointCount <= 0) return null;

  const values = new Float64Array(pointCount * 3);
  for (let point = 0; point < pointCount; point += 1) {
    values[point * 3 + 2] = 1;
  }

  return {
    dtype: "float64",
    grid: [pointCount, 1, 1],
    nComp: 3,
    pointCount,
    quantityId: "debug:airbox:synthetic:+z",
    valueCount: values.length,
    values,
  };
}

export function resolveViewport3DScopedPartVectorFieldRequests({
  getPartSettings,
  maxVectorGlyphs,
  magneticParts,
  selectedSnapshotQuery,
  vectorDomain,
}: {
  getPartSettings: (part: Viewport3DMeshPart) => {
    activeQuantityId: string;
    shaderVisible: boolean;
    surfaceColorSource: SurfaceColorSource;
    surfaceProjectionMode?: SurfaceFieldProjectionMode;
    vectorBudget: number;
    vectorsVisible: boolean;
    visible: boolean;
  };
  maxVectorGlyphs: number;
  magneticParts: readonly { part: Viewport3DMeshPart }[];
  selectedSnapshotQuery?: FieldVectorQuery | null;
  vectorDomain: string;
}): Map<string, Viewport3DFieldResourceRequest> {
  return new Map(
    resolveViewport3DScopedPartVectorFieldDemandPlan({
      getPartSettings: (part) => {
        const settings = getPartSettings(part as Viewport3DMeshPart);
        return {
          ...settings,
          surfaceProjectionMode: settings.surfaceProjectionMode ?? "raw_nodal",
        };
      },
      maxVectorGlyphs,
      magneticParts,
      selectedSnapshotQuery,
      vectorDomain,
    }).requests,
  );
}

export function resolveViewport3DTargetQuantityFieldRequests({
  fdmAirboxSettings,
  fdmSettings,
  getPartSettings,
  magneticPartScopedFieldIds,
  magneticParts,
  maxVectorGlyphs,
  primaryFieldQuantityId,
  selectedSnapshotQuery,
}: {
  fdmAirboxSettings?: VisualizationTargetSettings | null;
  fdmSettings: VisualizationTargetSettings | null;
  getPartSettings: (part: Viewport3DMeshPart) => VisualizationTargetSettings;
  magneticPartScopedFieldIds: ReadonlySet<string>;
  magneticParts: readonly { part: Viewport3DMeshPart }[];
  maxVectorGlyphs: number;
  primaryFieldQuantityId: string;
  selectedSnapshotQuery?: FieldVectorQuery | null;
}): Map<string, Viewport3DFieldResourceRequest> {
  return new Map(
    resolveViewport3DTargetQuantityFieldDemandPlan({
      fdmAirboxSettings,
      fdmSettings,
      getPartSettings: (part) => getPartSettings(part as Viewport3DMeshPart),
      magneticPartScopedFieldIds,
      magneticParts,
      maxVectorGlyphs,
      primaryFieldQuantityId,
      selectedSnapshotQuery,
    }).requests,
  );
}

export function resolveViewport3DFieldMetaScalarComponent(
  quantityId: string,
  component: string,
): string {
  return isScalarSpatialQuantityId(quantityId) ? "full" : component;
}

function fieldColorModeScalarComponent(mode: string | null | undefined): string | null {
  return resolveViewport3DScalarComponentRequest(null, mode).component;
}

export function mergeViewport3DFieldQuery(
  current: FieldVectorQuery | undefined,
  next: FieldVectorQuery,
): FieldVectorQuery {
  return mergeViewport3DFieldVectorQueries(current, next);
}

export function resolveViewport3DAnalysisComplexFieldQuery(
  query: FieldVectorQuery,
): FieldVectorQuery {
  const next = { ...query };
  delete next.phase_rad;
  return {
    ...next,
    component: "full",
    view: "complex",
  };
}

export function resolveViewport3DAnalysisComplexProjectionEnabled(
  query: FieldVectorQuery | null | undefined,
): boolean {
  return query?.view === "phase_rotated_real";
}

export function resolveViewport3DModeFieldOverlaySourceIdentity({
  metadata,
}: {
  metadata: {
    binaryQuery: FieldVectorQuery;
    fieldId: string;
    intent: {
      analysisRunId: string;
      analysisStageId: string;
      artifactRevision: string;
      modeId: string;
      sampleId: string;
    };
    resourceRevision: string;
  } | null;
}): { fieldBufferId: string; resourceKey: string } | null {
  if (
    !metadata ||
    !metadata.fieldId.trim() ||
    !metadata.resourceRevision.trim()
  ) {
    return null;
  }
  const resourceKey = resolveViewport3DFieldVectorResourceKey(
    metadata.fieldId,
    metadata.binaryQuery,
  );
  if (!resourceKey.trim()) return null;
  const ownerIdentity = [
    metadata.intent.analysisRunId,
    metadata.intent.analysisStageId,
    metadata.intent.artifactRevision,
    metadata.intent.sampleId,
    metadata.intent.modeId,
    metadata.fieldId,
    metadata.resourceRevision,
  ].map((part) => encodeURIComponent(part)).join(":");
  return {
    fieldBufferId: `analysis-mode-field:${ownerIdentity}`,
    resourceKey,
  };
}

function selectViewport3DComputeRunning(
  status: ResourceResult<LiveStatusResource>,
): boolean {
  return status.data?.solver.state === "running";
}

function resolveSelectionMeshQualityMetric(
  selection: Selection,
): MeshQualityColorMetric {
  const ref = selection.ref;
  const metric =
    ref?.type === "mesh-quality-element" || ref?.type === "mesh-quality-metric"
      ? ref.metric
      : null;
  if (metric === "gamma" || metric === "sicn" || metric === "volume") {
    return metric;
  }
  return "gamma";
}

const VIEWPORT_3D_VISUALIZATION_TARGET_KINDS: readonly VisualizationTargetKind[] = [
  "airbox",
  "fdm-domain",
  "object",
  "part",
  "region",
];

function selectViewport3DObjectVisualizationSnapshot(
  snapshot: ObjectVisualizationSnapshot,
  targets: readonly VisualizationTargetRef[],
): ObjectVisualizationSnapshot {
  const defaults: ObjectVisualizationSnapshot["defaults"] = {};
  const viewportPreferenceDefaults: NonNullable<
    ObjectVisualizationSnapshot["viewportPreferenceDefaults"]
  > = {};
  const viewportPreferences: NonNullable<
    ObjectVisualizationSnapshot["viewportPreferences"]
  > = {};
  const overrides: ObjectVisualizationSnapshot["overrides"] = {};
  const pendingOverrides: NonNullable<
    ObjectVisualizationSnapshot["pendingOverrides"]
  > = {};

  for (const kind of VIEWPORT_3D_VISUALIZATION_TARGET_KINDS) {
    const defaultPatch = snapshot.defaults[kind];
    if (defaultPatch) {
      defaults[kind] = defaultPatch;
    }
    const viewportPreferenceDefault =
      snapshot.viewportPreferenceDefaults?.[kind];
    if (viewportPreferenceDefault) {
      viewportPreferenceDefaults[kind] = viewportPreferenceDefault;
    }
  }

  for (const target of targets) {
    const key = visualizationTargetKey(target);
    const override = snapshot.overrides[key];
    if (override) {
      overrides[key] = override;
    }
    const viewportPreference = snapshot.viewportPreferences?.[key];
    if (viewportPreference) {
      viewportPreferences[key] = viewportPreference;
    }
    const pendingOverride = snapshot.pendingOverrides?.[key];
    if (pendingOverride) {
      pendingOverrides[key] = pendingOverride;
    }
  }

  return {
    defaults,
    viewportPreferenceDefaults,
    viewportPreferences,
    overrides,
    pendingOverrides,
    version: snapshot.version,
  };
}

/**
 * Structured-grid targets use the same canonical visualization resource as
 * the Inspector. Local snapshots only supply pending edits and preferences.
 */
export function resolveViewport3DFdmTargetVisualization({
  inheritedSettings,
  objectContext,
  snapshot,
  target,
  visualizationState,
}: {
  inheritedSettings?: VisualizationTargetSettings;
  objectContext?: VisualizationObjectContext;
  snapshot: ObjectVisualizationSnapshot;
  target: VisualizationTargetRef;
  visualizationState?: VisualizationStateResource | null;
}) {
  return resolveTargetVisualization({
    objectContext,
    inheritedSettings,
    snapshot,
    target,
    visualizationState,
  });
}

export function resolveViewport3DFdmNativeLayerSettings({
  activeMaskReady,
  domain,
  globalObjectBaseSettings,
  objectContext,
  snapshot,
  target,
  visualizationState,
}: {
  activeMaskReady: boolean;
  domain: import("../viewport3dDomainAdapter").FdmNativeLayerRenderDomain;
  globalObjectBaseSettings: ReturnType<typeof resolveGlobalObjectVisualizationSettings>;
  objectContext?: VisualizationObjectContext;
  snapshot: ObjectVisualizationSnapshot;
  target: VisualizationTargetRef;
  visualizationState?: VisualizationStateResource | null;
}) {
  const canonicalObjectId = canonicalVisualizationSceneObjectId(domain.objectId);
  const owner = resolveViewport3DFdmTargetVisualization({
    objectContext,
    inheritedSettings: globalObjectBaseSettings,
    snapshot,
    target: { id: `object:${canonicalObjectId}`, kind: "object" },
    visualizationState,
  });
  const resolved = resolveViewport3DFdmTargetVisualization({
    objectContext,
    inheritedSettings: owner.effectiveSettings,
    snapshot,
    target,
    visualizationState,
  }).effectiveSettings;

  return resolveFdmViewportVisualizationSettings(resolved, activeMaskReady);
}

function viewport3DObjectVisualizationSnapshotEquals(
  previous: ObjectVisualizationSnapshot,
  next: ObjectVisualizationSnapshot,
): boolean {
  for (const kind of VIEWPORT_3D_VISUALIZATION_TARGET_KINDS) {
    if (!visualizationTargetPatchEquals(previous.defaults[kind], next.defaults[kind])) {
      return false;
    }
    if (
      !visualizationTargetPatchEquals(
        previous.viewportPreferenceDefaults?.[kind],
        next.viewportPreferenceDefaults?.[kind],
      )
    ) {
      return false;
    }
  }

  const overrideKeys = new Set([
    ...Object.keys(previous.overrides),
    ...Object.keys(next.overrides),
  ]);
  for (const key of overrideKeys) {
    if (!visualizationTargetPatchEquals(previous.overrides[key], next.overrides[key])) {
      return false;
    }
  }

  const viewportPreferenceKeys = new Set([
    ...Object.keys(previous.viewportPreferences ?? {}),
    ...Object.keys(next.viewportPreferences ?? {}),
  ]);
  for (const key of viewportPreferenceKeys) {
    if (
      !visualizationTargetPatchEquals(
        previous.viewportPreferences?.[key],
        next.viewportPreferences?.[key],
      )
    ) {
      return false;
    }
  }

  const pendingOverrideKeys = new Set([
    ...Object.keys(previous.pendingOverrides ?? {}),
    ...Object.keys(next.pendingOverrides ?? {}),
  ]);
  for (const key of pendingOverrideKeys) {
    const previousPending = previous.pendingOverrides?.[key];
    const nextPending = next.pendingOverrides?.[key];
    if (
      previousPending?.baseRevision !== nextPending?.baseRevision ||
      !visualizationTargetPatchEquals(previousPending?.patch, nextPending?.patch)
    ) {
      return false;
    }
  }

  return true;
}

function visualizationTargetPatchEquals(
  previous: VisualizationStoredTargetPatch | undefined,
  next: VisualizationStoredTargetPatch | undefined,
): boolean {
  if (previous === next) return true;
  if (!previous || !next) return previous === next;

  const keys = new Set([
    ...Object.keys(previous),
    ...Object.keys(next),
  ] as Array<keyof VisualizationStoredTargetPatch>);
  for (const key of keys) {
    if (!Object.is(previous[key], next[key])) {
      return false;
    }
  }

  return true;
}

function pushViewportVisualizationTarget(
  targets: VisualizationTargetRef[],
  seen: Set<string>,
  target: VisualizationTargetRef,
): void {
  const key = visualizationTargetKey(target);
  if (seen.has(key)) return;
  seen.add(key);
  targets.push(target);
}

export function resolveViewport3DSceneCameraView({
  cameraRegistryCamera,
}: {
  cameraRegistryCamera: VisualizationStateResource["camera"];
  commandState: Pick<Viewport3DCommandState, "camera" | "widgets">;
}): {
  cameraOrthographicScale: number | null;
  cameraProjection: Viewport3DCameraProjection;
  cameraFov: number;
  cameraResource: VisualizationStateResource["camera"];
  cameraState: Viewport3DCameraState;
} {
  return {
    cameraOrthographicScale: resolveViewport3DCameraOrthographicScale({
      camera: cameraRegistryCamera,
    }),
    cameraProjection: resolveViewport3DCameraProjection({
      camera: cameraRegistryCamera,
    }),
    cameraFov: resolveViewport3DCameraFovDegrees(
      cameraRegistryCamera?.fov_degrees,
    ),
    cameraResource: cameraRegistryCamera,
    cameraState: resolveViewport3DCameraState({ camera: cameraRegistryCamera }),
  };
}

export function useViewport3DSceneModel({
  commandState,
  colors,
  meshSizeHighlight,
  meshSizeHighlightSelection,
  resourceCounts,
  selection,
  tracker,
}: {
  commandState: ReturnType<typeof useViewport3DCommandState>;
  colors: Viewport3DSceneProps["colors"] | null;
  meshSizeHighlight: MeshSizeHistogramHighlight | null;
  meshSizeHighlightSelection: MeshHistogramBinElementsResource | null;
  resourceCounts: Viewport3DResourceCounts;
  selection: Selection;
  tracker?: Viewport3DResourceTracker;
}) {
  const { presentation: savedPresentation, projectId: savedProjectId, runId: savedRunId } = useSavedFieldPresentation();
  const savedDatasetSelection = savedPresentation?.selection ?? resolvePinnedMaterializedDatasetSelection(selection);
  const savedProjectMatches = savedDatasetSelection !== null && savedDatasetSelection.projectId === savedProjectId
    && (!savedRunId || savedDatasetSelection.runId === savedRunId);
  const savedSelectionActive = savedDatasetSelection !== null;
  const liveViewportResourcesEnabled = !savedSelectionActive;
  const savedDatasetResource = useMaterializedDatasetResource(
    savedDatasetSelection?.projectId,
    savedDatasetSelection?.runId,
    savedDatasetSelection?.solutionSetId,
    savedDatasetSelection?.containingRevision,
    savedDatasetSelection?.memberId,
    savedDatasetSelection?.artifactId,
    { enabled: savedSelectionActive && savedProjectMatches },
  );
  const savedDatasetForViewport = savedDatasetMatchesSelection(
    savedDatasetSelection,
    savedProjectMatches && savedViewportResourceHasFreshData(savedDatasetResource)
      ? savedDatasetResource.data
      : null,
  )
    ? savedDatasetResource.data
    : null;
  const savedDatasetIdentityMismatch =
    savedDatasetResource.status === "ready" &&
    savedDatasetResource.error === null &&
    savedDatasetResource.refreshError == null &&
    savedDatasetResource.data !== null &&
    savedDatasetForViewport === null;
  const savedViewportResources = useSavedFieldViewportResources(
    savedDatasetForViewport,
    savedSelectionActive,
  );
  const savedAntennaSourceContext = useSavedAntennaSourceContextResources(
    savedDatasetForViewport,
    savedSelectionActive,
  );
  const sourceGeometry = savedAntennaSourceContext.status === "ready" ? savedAntennaSourceContext.geometry : null;
  const sourceTopology = savedAntennaSourceContext.status === "ready" ? savedAntennaSourceContext.topology : null;
  const savedAntennaSourceModel = useMemo(
    () => sourceGeometry && sourceTopology ? buildSavedAntennaSourceModel(sourceGeometry, sourceTopology) : null,
    [sourceGeometry, sourceTopology],
  );
  const savedViewportResourcesFresh =
    savedDatasetForViewport !== null &&
    savedViewportResourceHasFreshData(savedViewportResources.geometry) &&
    savedViewportResourceHasFreshData(savedViewportResources.support) &&
    savedViewportResourceHasFreshData(savedViewportResources.topology) &&
    savedViewportResourceHasFreshData(savedViewportResources.field);
  const primitiveDraftOverlay = usePrimitiveDraftOverlay();
  const { analysisFieldOverlay, diagnosticRecorder } = useKernel();
  const analysisOverlayContext = useAnalysisFieldOverlayContext(analysisFieldOverlay);
  const analysisOverlaySnapshot =
    useRenderableAnalysisFieldOverlay(analysisFieldOverlay);
  const analysisOverlay = useMemo(
    () =>
      analysisResultOverlayMatchesSelection(
        analysisOverlaySnapshot,
        selection,
      )
        ? analysisOverlaySnapshot
        : null,
    [analysisOverlaySnapshot, selection],
  );
  useEffect(() => {
    if (
      analysisOverlaySnapshot?.analysisResultFieldIntent &&
      !analysisResultOverlayMatchesSelection(
        analysisOverlaySnapshot,
        selection,
      )
    ) {
      analysisFieldOverlay.clear();
    }
  }, [analysisFieldOverlay, analysisOverlaySnapshot, selection]);
  const modeCompositionController = useModeCompositionControllerResource();
  const modeCompositionPhaseClock = useModeCompositionPhaseClock(
    modeCompositionController.controller.resource,
  );
  useEffect(() => {
    const handle = startAnalysisFieldOverlayPhaseAnimation(analysisFieldOverlay);
    return () => {
      handle.stop();
    };
  }, [analysisFieldOverlay]);
  const visualizationState = useVisualizationStateResource();
  const crossSectionFramePreview = useCrossSectionWorkspaceSelector(
    activeCrossSectionFramePreview,
    { isEqual: crossSectionFramePreviewEquals },
  );
  const planarMonitorDraft = useCrossSectionWorkspaceSelector(
    (state) => state.planarMonitorDraft,
  );
  const crossSectionFrameClip = useMemo(
    () => crossSectionFramePreviewToClip(crossSectionFramePreview),
    [crossSectionFramePreview],
  );
  const resolvedPlanarMonitorFramePreview = usePlanarMonitorFramePreview();
  const committedPlanarMonitorPreviewDraft = usePlanarMonitorFramePreviewDraft();
  const cameraRegistryCamera = useCameraRegistryCamera();
  const visualProfile = getViewport3DVisualProfile(commandState.visualProfileId);
  const computeRunning = useSessionStatusSelector(selectViewport3DComputeRunning);
  const sessionDiscretization = useSessionStatusSelector((status) =>
    resolveSessionDiscretization(status.data),
  );
  // Published topology may select a binary preview adapter while runtime lane
  // resolution is pending. Solver-facing state continues to use the strict
  // sessionDiscretization value above.
  const viewportDataDiscretization = useSessionStatusSelector((status) =>
    resolveSessionTopologyDiscretization(status.data),
  );
  const fdmLaneActive = viewportDataDiscretization === "fdm";
  const femLaneActive = viewportDataDiscretization === "fem";
  const sessionIdentity = useSessionResourceIdentity();
  const pinnedObservationSource = useObservationSourceWorkspaceSelector(
    (state) => state.pinned,
  );
  const pinnedObservationActive =
    pinnedObservationSource !== null && analysisOverlay === null;
  const renderingState = visualizationState.data;
  const maxInteractiveVectorGlyphs = useMemo(
    () => resolveViewport3DMaxVectorGlyphs(renderingState),
    [renderingState],
  );
  const regionSelectionScope = useMemo(
    () => resolveViewport3DRegionSelectionScope(selection),
    [selection],
  );
  const { selectedObjectId, selectedRegionId } = regionSelectionScope;
  const selectedVisualizationTargetId = useMemo(
    () => resolveVisualizationTargetFromSelection(selection)?.id ?? null,
    [selection],
  );
  const visualizationRevision = renderingState?.revision ?? null;
  const visualizationError = visualizationState.error?.message ?? null;
  const visualizationEffectiveRenderMode = resolveVisualizationEffectiveRenderMode({
    layers: renderingState?.layers,
  });
  const selectedSnapshotId = useMemo(
    () => resolveViewport3DSelectedSnapshotId(selection),
    [selection],
  );
  const selectedSnapshotQuery = useMemo(
    () => resolveViewport3DSelectedSnapshotQuery(selection),
    [selection],
  );
  const hysteresisReplayTarget = useMemo(
    () => resolveHysteresisStepViewportTarget(selection),
    [selection],
  );
  const hysteresisReplayGlyphModel = useMemo<HysteresisReplayGlyphModel | null>(
    () => buildHysteresisReplayGlyphModel(hysteresisReplayTarget),
    [hysteresisReplayTarget],
  );
  const quantityId = resolveViewport3DActiveQuantityId({
    selectedSnapshotId,
    selection,
    visualizationState: renderingState,
  });
  const scalarColorPalette = savedPresentation?.settings.scalarColorPalette ??
    renderingState?.quantity?.colormap ?? renderingState?.colormap ?? "viridis";
  const vectorStyleState = renderingState?.vector_style;
  const vectorColorMode = savedPresentation?.settings.vectorColorMode ??
    vectorStyleState?.color_mode ?? "orientation";
  const vectorDomain = renderingState?.layers?.vectors?.domain ?? "auto";
  const vectorStyle = useMemo(
    () => ({
      alpha: vectorStyleState?.alpha ?? 1,
      monoColor:
        vectorStyleState?.mono_color ??
        String(colors?.field ?? "white"),
      thickness: vectorStyleState?.thickness ?? 1,
    }),
    [
      colors?.field,
      vectorStyleState?.alpha,
      vectorStyleState?.mono_color,
      vectorStyleState?.thickness,
    ],
  );
  const domainMeta = useViewport3DDomainMeta(liveViewportResourcesEnabled);
  const scene = useViewport3DScene(liveViewportResourcesEnabled);
  const sceneObjectIds = useMemo(
    () => visualizationSceneObjectIds(scene.data),
    [scene.data],
  );
  const sceneObjectsById = useMemo(() => new Map(
    (scene.data?.objects ?? []).map((object) => [canonicalVisualizationSceneObjectId(object.id), object]),
  ), [scene.data]);
  const modelRegions = useModelRegionsResource({
    enabled: liveViewportResourcesEnabled && Boolean(scene.data),
  });
  const universe = useViewport3DUniverse(liveViewportResourcesEnabled);
  const authoredUniverseBounds = useMemo(() => {
    const resourceAuthoredBounds = universe.data
      ? resolveUniverseBounds({
          ...universe.data,
          object_bounds_max: null,
          object_bounds_min: null,
        })
      : null;
    const sceneUniverse = scene.data?.universe;
    const sceneAuthoredBounds = sceneUniverse
      ? resolveUniverseBounds({
          mesh_dirty: false,
          object_bounds_max: null,
          object_bounds_min: null,
          scene_revision: scene.data?.scene_revision ?? 0,
          study_universe_mesh: null,
          universe: sceneUniverse,
        })
      : null;
    const sceneRevision = scene.data?.scene_revision;
    const resourceRevision = universe.data?.scene_revision;
    const sceneIsNewer = Boolean(
      sceneAuthoredBounds &&
        sceneRevision != null &&
        resourceRevision != null &&
        sceneRevision > resourceRevision,
    );
    return sceneIsNewer
      ? sceneAuthoredBounds
      : resourceAuthoredBounds ?? sceneAuthoredBounds;
  }, [scene.data?.scene_revision, scene.data?.universe, universe.data]);
  const sharedDomainManifest = useViewport3DSharedDomainManifest(
    liveViewportResourcesEnabled && femLaneActive,
  );
  const sharedDomainTopologyFingerprint =
    sharedDomainManifest.data?.topology_fingerprint ?? null;
  const unknownTopologyProvenanceRefreshRef = useRef<string | null>(null);
  const topology = useViewport3DDomainTopology(
    liveViewportResourcesEnabled && femLaneActive,
  );
  const fdmMultilayerLayout = useFdmMultilayerLayoutResource({
    enabled: liveViewportResourcesEnabled && Boolean(fdmLaneActive),
  });
  const fdmMultilayerLayerActiveMasks =
    useFdmMultilayerLayerActiveMasksResource(fdmMultilayerLayout.data, {
      enabled:
        liveViewportResourcesEnabled &&
        Boolean(fdmLaneActive && fdmMultilayerLayout.data?.available),
    });
  const fdmNativeLayerDomains = useMemo(
    () =>
      adaptFdmMultilayerNativeLayerDomains(
        fdmMultilayerLayout.data,
        FDM_NATIVE_LAYER_DISPLAY_CELL_BUDGET,
      ),
    [fdmMultilayerLayout.data],
  );
  const fdmMultilayerAirboxDomain = useMemo(
    () =>
      adaptFdmMultilayerAirboxDomain(
        fdmMultilayerLayout.data,
        FDM_DISPLAY_CELL_BUDGET,
        authoredUniverseBounds,
      ),
    [authoredUniverseBounds, fdmMultilayerLayout.data],
  );
  const fieldCatalog = useFieldCatalogResource({
    enabled: Boolean(
      liveViewportResourcesEnabled &&
        (fdmLaneActive || femLaneActive),
    ),
  });
  const quantityCatalog = useQuantityCatalogResource({
    enabled: Boolean(
      liveViewportResourcesEnabled &&
        (fdmLaneActive || femLaneActive || (scene.data?.antenna_field_solve_stages?.length ?? 0) > 0),
    ),
  });
  const modelQuantityId = useMemo(() => resolveViewport3DModelQuantityId(
    quantityId, quantityCatalog.data, scene.data?.objects ?? null,
  ), [quantityId, quantityCatalog.data, scene.data]);
  const primaryFieldQuantityId = analysisOverlay?.fieldId ??
    (pinnedObservationActive ? "m" : selectedSnapshotId ? quantityId : modelQuantityId);
  const getObjectContext = useCallback((objectId: string | null): VisualizationObjectContext => ({
    object: objectId ? sceneObjectsById.get(canonicalVisualizationSceneObjectId(objectId)) ?? null : null,
    quantityCatalog: quantityCatalog.data,
  }), [sceneObjectsById, quantityCatalog.data]);
  const availableFieldQuantityIds = useMemo(
    () => resolveViewport3DAvailableFieldQuantityIds(fieldCatalog.data),
    [fieldCatalog.data],
  );
  const publishedModelQuantityIds = useMemo(
    () => liveViewportResourcesEnabled
      ? resolveViewport3DPublishedModelQuantityIds(
        availableFieldQuantityIds, quantityCatalog.data, scene.data?.objects ?? null,
      )
      : EMPTY_VIEWPORT_3D_FIELD_QUANTITY_IDS,
    [liveViewportResourcesEnabled, availableFieldQuantityIds, quantityCatalog.data, scene.data],
  );
  const availableQuantityIdsForPlanning = useMemo(
    () =>
      mergeViewport3DQuantityCapabilityIds(
        availableFieldQuantityIds,
        quantityCatalog.data,
      ) ?? EMPTY_VIEWPORT_3D_FIELD_QUANTITY_IDS,
    [availableFieldQuantityIds, quantityCatalog.data],
  );
  const fdmRegionMembership = useFdmRegionMembershipResource({
    enabled: liveViewportResourcesEnabled && fdmLaneActive,
  });
  const fdmRegionMembershipBinary = useFdmRegionMembershipBinaryResource(null, {
    enabled:
      liveViewportResourcesEnabled &&
      Boolean(fdmLaneActive && fdmRegionMembership.data),
    revision: fdmRegionMembership.revision,
  });
  const fdmDomainPresentation = useMemo(
    () =>
      fdmLaneActive && domainMeta.data?.discretization === "fdm" && domainMeta.data.grid
        ? adaptDomainPresentation({
            domainMeta: domainMeta.data,
            expectedFdmGridFingerprint:
              fdmRegionMembershipBinary.data?.gridFingerprint ?? null,
            fdmMembership: fdmRegionMembership.data,
            fdmMembershipStatus: fdmRegionMembership.error
              ? "error"
              : fdmRegionMembership.status,
            universeOutsideMagneticSupport:
              deriveAuthoredFdmUniverseOutsideMagneticSupport({
                domainBounds: domainMeta.data.bounds,
                objects: scene.data?.objects,
              }),
          })
        : null,
    [
      fdmLaneActive,
      domainMeta.data,
      fdmRegionMembership.data,
      fdmRegionMembership.error,
      fdmRegionMembership.status,
      fdmRegionMembershipBinary.data?.gridFingerprint,
      scene.data,
    ],
  );
  const fdmDomain = useMemo(
    () => adaptFdmDomainPresentation(fdmDomainPresentation, FDM_DISPLAY_CELL_BUDGET),
    [fdmDomainPresentation],
  );
  const fdmSelectionGrid = useMemo<FdmSelectionGrid | null>(() => {
    if (!fdmDomain) return null;
    return {
      ...fdmDomain,
      // A cell can be focused only while the current membership resource
      // proves the same grid identity. Grid-level nodes remain focusable from
      // the descriptor even when membership is loading or stale.
      gridFingerprint:
        fdmDomainPresentation?.resourceStatus === "realized"
          ? fdmDomainPresentation.fingerprint
          : null,
    };
  }, [fdmDomain, fdmDomainPresentation]);
  const fdmRealizedRegionIds = useMemo<Uint32Array | null>(() => {
    if (fdmRegionMembership.error || fdmRegionMembershipBinary.error) {
      return null;
    }
    return (
      resolveViewport3DFdmRealizedRegionIds(
        fdmDomainPresentation,
        fdmRegionMembershipBinary.data,
      ) ?? null
    );
  }, [
    fdmDomainPresentation,
    fdmRegionMembership.error,
    fdmRegionMembershipBinary.data,
    fdmRegionMembershipBinary.error,
  ]);
  const fdmMembershipCurrent = Boolean(
    fdmDomain &&
      fdmRealizedRegionIds instanceof Uint32Array &&
      fdmRealizedRegionIds.length === fdmDomain.totalCells,
  );
  const fdmTargetDefinitionsResult = useMemo(
    () =>
      buildViewport3DFdmTargetDefinitions(
        fdmRegionMembership.data,
        sceneObjectIds,
      ),
    [fdmRegionMembership.data, sceneObjectIds],
  );
  const femDomain = useMemo(
    () =>
      femLaneActive
        ? adaptFemSharedDomainManifest(sharedDomainManifest.data)
        : EMPTY_FEM_RENDER_DOMAIN,
    [femLaneActive, sharedDomainManifest.data],
  );
  const semanticTargetCatalog = useMemo(
    () =>
      buildSemanticRenderTargetCatalog({
        parts: [...femDomain.partsById.values()],
        sceneObjectIds,
      }),
    [femDomain.partsById, sceneObjectIds],
  );
  const topologyIndexBundle = useViewport3DTopologyIndexBundle({
    airboxParts: femDomain.airboxParts,
    enabled:
      liveViewportResourcesEnabled && Boolean(topology.data && femLaneActive),
    magneticParts: femDomain.magneticParts,
    magneticSurfacePartsByPartId: femDomain.magneticSurfacePartsByPartId,
    topology: topology.data,
    topologyRevision: topology.revision == null ? null : String(topology.revision),
  });
  const topologyIndexState =
    topologyIndexBundle.status === "building"
      ? "pending"
      : topologyIndexBundle.status === "ready"
        ? "ready"
        : "unavailable";
  const topologyRenderModel = useMemo(
    () =>
      measureViewport3DModelBuild(
        "fullmag.viewport3d.buildViewport3DTopologyRenderModel",
        () =>
          buildViewport3DTopologyRenderModel(
            topology.data,
            femDomain.magneticParts,
            femDomain.airboxParts,
            femDomain.magneticSurfacePartsByPartId,
            {
              meshGenerationId: sharedDomainManifest.data?.generation_id ?? null,
              meshRevision: sharedDomainManifest.data?.revision ?? null,
              meshTopologyHash: sharedDomainTopologyFingerprint,
            },
            {
              topologyIndexBundle: topologyIndexBundle.bundle,
              topologyIndexState,
            },
          ),
      ),
    [
      femDomain.airboxParts,
      femDomain.magneticParts,
      femDomain.magneticSurfacePartsByPartId,
      sharedDomainManifest.data?.generation_id,
      sharedDomainManifest.data?.revision,
      sharedDomainTopologyFingerprint,
      topology.data,
      topologyIndexBundle.bundle,
      topologyIndexState,
    ],
  );
  const fieldTopologyRenderModel = useMemo(
    () =>
      measureViewport3DModelBuild(
        "fullmag.viewport3d.buildViewport3DFieldTopologyRenderModel",
        () =>
          buildViewport3DTopologyRenderModel(
            topology.data,
            femDomain.fieldCapableMagneticParts ?? femDomain.magneticParts,
            femDomain.fieldCapableAirboxParts ?? femDomain.airboxParts,
            femDomain.magneticSurfacePartsByPartId,
            {
              meshGenerationId: sharedDomainManifest.data?.generation_id ?? null,
              meshRevision: sharedDomainManifest.data?.revision ?? null,
              meshTopologyHash: sharedDomainTopologyFingerprint,
            },
            {
              topologyIndexBundle: topologyIndexBundle.bundle,
              topologyIndexState,
            },
          ),
      ),
    [
      femDomain.fieldCapableAirboxParts,
      femDomain.fieldCapableMagneticParts,
      femDomain.airboxParts,
      femDomain.magneticParts,
      femDomain.magneticSurfacePartsByPartId,
      sharedDomainManifest.data?.generation_id,
      sharedDomainManifest.data?.revision,
      sharedDomainTopologyFingerprint,
      topology.data,
      topologyIndexBundle.bundle,
      topologyIndexState,
    ],
  );
  const primitiveModel = useMemo(() => {
    const committed = buildViewport3DPrimitiveRenderModel(
      scene.data,
      sharedDomainManifest.data,
    );
    return {
      ...committed,
      draftOverlay: primitiveDraftOverlay,
    };
  }, [primitiveDraftOverlay, scene.data, sharedDomainManifest.data]);
  const objectTransformsById = useMemo(() => {
    const sceneRecord = asJsonRecord(scene.data);
    const transforms = new Map<string, unknown>();
    if (!sceneRecord || !Array.isArray(sceneRecord.objects)) {
      return transforms;
    }

    for (const value of sceneRecord.objects) {
      const object = asJsonRecord(value);
      const objectId = asNonEmptyString(object?.id);
      const transform = asJsonRecord(object?.transform);
      if (objectId && transform) {
        transforms.set(objectId, transform);
      }
    }

    return transforms;
  }, [scene.data]);
  const meshBackedRegionKeys = useMemo(
    () =>
      femLaneActive
        ? resolveViewport3DMeshBackedRegionKeys(
            sharedDomainManifest.data?.regions,
          )
        : new Set<string>(),
    [femLaneActive, sharedDomainManifest.data?.regions],
  );
  const allRegionOverlays = useMemo<RegionOverlayInput[]>(
    () =>
      resolveViewport3DRegionOverlays({
        objectTransformsById,
        regionResource: modelRegions.data,
        scene: scene.data,
      }),
    [modelRegions.data, objectTransformsById, scene.data],
  );
  const regionOverlays = useMemo<RegionOverlayInput[]>(
    () =>
      resolveViewport3DRegionOverlays({
        objectTransformsById,
        realizedRegionKeys: meshBackedRegionKeys,
        regionResource: modelRegions.data,
        scene: scene.data,
      }),
    [meshBackedRegionKeys, modelRegions.data, objectTransformsById, scene.data],
  );
  const topologyFreshness = useMemo(
    () =>
      resolveViewport3DTopologyFreshness(
        scene.data,
        sharedDomainManifest.data,
        {
          domainMeta: domainMeta.data,
          topology: topology.data,
        },
      ),
    [domainMeta.data, scene.data, sharedDomainManifest.data, topology.data],
  );
  useEffect(() => {
    if (!femLaneActive) return;
    const refreshKey = resolveUnknownTopologyProvenanceRefreshKey(
      scene.data,
      sharedDomainManifest.data,
    );
    if (
      !refreshKey ||
      unknownTopologyProvenanceRefreshRef.current === refreshKey
    ) {
      return;
    }

    unknownTopologyProvenanceRefreshRef.current = refreshKey;
    sharedDomainManifest.refetch();
  }, [femLaneActive, scene.data, sharedDomainManifest]);
  const domainRenderLane = resolveViewport3DDomainRenderLane({
    discretization: viewportDataDiscretization,
    femDomain,
    topologyFreshness,
  });
  const topologyCurrent = domainRenderLane.topologyCurrent;
  const topologyRenderable = domainRenderLane.topologyRenderable;
  const periodicPairs = useMeshPeriodicPairsResource({
    enabled: liveViewportResourcesEnabled && topologyCurrent,
  });
  const periodicOverlayModel = useMemo(
    () =>
      femLaneActive
        ? buildPeriodicOverlayModel({
            currentMeshRevision: sharedDomainManifest.data?.revision ?? null,
            currentTopologyFingerprint: sharedDomainTopologyFingerprint,
            resource: periodicPairs.data,
            topology: topology.data,
          })
        : null,
    [
      periodicPairs.data,
      sharedDomainManifest.data?.revision,
      sharedDomainTopologyFingerprint,
      topology.data,
      femLaneActive,
    ],
  );
  const regionMembershipIds = useMemo(
    () =>
      topologyCurrent
        ? resolveViewport3DRegionMembershipIds({
            meshBackedRegionKeys,
            regions: allRegionOverlays,
          })
        : [],
    [allRegionOverlays, meshBackedRegionKeys, topologyCurrent],
  );
  const regionMemberships = useMeshRegionMembershipsResource(regionMembershipIds, {
    enabled:
      liveViewportResourcesEnabled &&
      Boolean(topologyCurrent && regionMembershipIds.length > 0),
  });
  const membershipRegionOverlays = useMemo(
    () =>
      topologyCurrent && regionMemberships.data
        ? resolveViewport3DMembershipRegionOverlays({
            memberships: regionMemberships.data,
            regions: allRegionOverlays,
          })
        : { ownerParts: [], regions: [] },
    [allRegionOverlays, regionMemberships.data, topologyCurrent],
  );
  const regionTargetByPartId = useMemo(
    () =>
      resolveViewport3DRegionTargetsForMembershipOwnerParts({
        manifestRegions: sharedDomainManifest.data?.regions,
        ownerParts: membershipRegionOverlays.ownerParts,
        regions: allRegionOverlays,
      }),
    [sharedDomainManifest.data?.regions, membershipRegionOverlays.ownerParts, allRegionOverlays],
  );
  const meshRegionOverlays = useMemo(
    () => {
      if (!topologyCurrent) return [];
      return [
        ...resolveViewport3DMeshBackedRegionOverlays({
          manifestRegions: sharedDomainManifest.data?.regions,
          regions: allRegionOverlays,
        }),
        ...membershipRegionOverlays.regions,
      ];
    },
    [
      allRegionOverlays,
      membershipRegionOverlays.regions,
      sharedDomainManifest.data?.regions,
      topologyCurrent,
    ],
  );
  const meshRegionOverlayParts = useMemo(
    () => [...femDomain.magneticParts, ...membershipRegionOverlays.ownerParts],
    [femDomain.magneticParts, membershipRegionOverlays.ownerParts],
  );
  const topologyRenderModelForGeometry = topologyRenderable ? topologyRenderModel : null;
  const fieldCompatibleTopologyRenderModel = topologyCurrent
    ? fieldTopologyRenderModel
    : null;
  const modeCompositionTopologyByTarget = useMemo(() => {
    if (
      !fieldCompatibleTopologyRenderModel?.meshGenerationId ||
      !fieldCompatibleTopologyRenderModel.meshTopologyHash ||
      fieldCompatibleTopologyRenderModel.meshRevision == null
    ) {
      return {};
    }
    const topologyIdentity = {
      domainGenerationId: fieldCompatibleTopologyRenderModel.meshGenerationId,
      meshTopologyHash: fieldCompatibleTopologyRenderModel.meshTopologyHash,
      meshTopologyRevision: String(fieldCompatibleTopologyRenderModel.meshRevision),
    };
    return Object.fromEntries(
      fieldCompatibleTopologyRenderModel.magneticParts.flatMap(({ part }) => {
        const targetId = modeCompositionTargetIdForMeshPart(part);
        return targetId ? [[targetId, topologyIdentity]] : [];
      }),
    );
  }, [fieldCompatibleTopologyRenderModel]);
  const modeCompositionFieldLayers = useModeCompositionFieldLayerResources({
    composition: modeCompositionController.controller.resource,
    enabled: Boolean(fieldCompatibleTopologyRenderModel),
    topologyByTarget: modeCompositionTopologyByTarget,
  });
  const modeFieldOverlayTopology = useMemo(() => {
    if (
      !fieldCompatibleTopologyRenderModel?.meshGenerationId ||
      !fieldCompatibleTopologyRenderModel.meshTopologyHash ||
      fieldCompatibleTopologyRenderModel.meshRevision == null
    ) {
      return null;
    }
    return {
      domainGenerationId: fieldCompatibleTopologyRenderModel.meshGenerationId,
      meshId: sharedDomainManifest.data?.mesh_id ?? null,
      meshTopologyHash: fieldCompatibleTopologyRenderModel.meshTopologyHash,
      meshTopologyRevision: String(fieldCompatibleTopologyRenderModel.meshRevision),
      pointCount: fieldCompatibleTopologyRenderModel.nodeCount,
    };
  }, [
    fieldCompatibleTopologyRenderModel,
    sharedDomainManifest.data?.mesh_id,
  ]);
  const analysisFieldIntent =
    analysisOverlay?.analysisResultFieldIntent ?? analysisOverlay?.modeIntent;
  const modeFieldOverlayHasIntent = Boolean(analysisFieldIntent);
  const modeFieldOverlayEnabled = Boolean(
    liveViewportResourcesEnabled && modeFieldOverlayHasIntent,
  );
  const modeFieldOverlay = useModeFieldOverlayIntentResource({
    enabled: modeFieldOverlayEnabled,
    intent: analysisFieldIntent,
    topology: modeFieldOverlayTopology,
  });
  const modeFieldOverlayTopologyIdentityComplete = Boolean(
    modeFieldOverlayTopology?.domainGenerationId &&
      modeFieldOverlayTopology.meshTopologyHash &&
      modeFieldOverlayTopology.meshTopologyRevision !== null &&
      Number.isInteger(modeFieldOverlayTopology.pointCount) &&
      modeFieldOverlayTopology.pointCount > 0,
  );
  const modeFieldOwnerReason = analysisOverlayContext.reason?.slice(0, 160) ?? null;
  const modeFieldOwnerResultRunId =
    analysisOverlayContext.resultRunId?.slice(0, 120) ?? null;
  const modeFieldOwnerStatus = analysisOverlayContext.status;
  const hasModeFieldTopology = modeFieldOverlayTopology !== null;
  const hasModeFieldSession = sessionIdentity !== null;
  const modeFieldOwnerDiagnostic = useMemo(
    () => ({
      enabled: modeFieldOverlayEnabled,
      hasIntent: modeFieldOverlayHasIntent,
      hasSession: hasModeFieldSession,
      hasTopology: hasModeFieldTopology,
      ownerReason: modeFieldOwnerReason,
      ownerResultRunId: modeFieldOwnerResultRunId,
      ownerStatus: modeFieldOwnerStatus,
      topologyCurrent,
      topologyIdentityComplete: modeFieldOverlayTopologyIdentityComplete,
    }),
    [
      hasModeFieldSession,
      hasModeFieldTopology,
      modeFieldOverlayEnabled,
      modeFieldOverlayHasIntent,
      modeFieldOverlayTopologyIdentityComplete,
      modeFieldOwnerReason,
      modeFieldOwnerResultRunId,
      modeFieldOwnerStatus,
      topologyCurrent,
    ],
  );
  const modeFieldOwnerDiagnosticRef = useRef<string | null>(null);
  useEffect(() => {
    const diagnosticKey = JSON.stringify(modeFieldOwnerDiagnostic);
    if (modeFieldOwnerDiagnosticRef.current === diagnosticKey) return;
    modeFieldOwnerDiagnosticRef.current = diagnosticKey;
    diagnosticRecorder.mark(
      "viewport-3d.mode-field-overlay.owner-gate",
      modeFieldOwnerDiagnostic,
      "viewport-3d",
    );
  }, [diagnosticRecorder, modeFieldOwnerDiagnostic]);
  const clipCrossSectionQuery = useMemo(() => {
    const query = resolveCrossSectionQueryFromVisualizationState(renderingState);
    return {
      ...query,
      includePolygons: true,
      includeWireframe: false,
    };
  }, [renderingState]);
  const clipCrossSection = useCrossSectionResource(clipCrossSectionQuery, {
    enabled:
      liveViewportResourcesEnabled &&
      Boolean(renderingState?.clip?.enabled && topologyCurrent),
  });
  const clipIntersectionMarkers = useMemo(
    () => buildClipPlaneIntersectionMarkerBuffers(clipCrossSection.data),
    [clipCrossSection.data],
  );
  const meshQualityOverlayVisible =
    selection.kind === "mesh.quality" ||
    selection.ref?.type === "mesh-quality-element";
  const meshQualityMetric = resolveSelectionMeshQualityMetric(selection);
  const tet4FmmqQualitySupported = topologySupportsTet4FmmqQuality(topology.data);
  const meshQualityData = useViewport3DMeshQualityData(
    Boolean(
      liveViewportResourcesEnabled &&
        fieldCompatibleTopologyRenderModel &&
        meshQualityOverlayVisible &&
        tet4FmmqQualitySupported,
    ),
  );
  const meshQualityColors = useMemo(
    () =>
      meshQualityOverlayVisible && topologyCurrent
        ? measureViewport3DModelBuild(
            "fullmag.viewport3d.buildMeshQualityVertexColors",
            () =>
              buildMeshQualityVertexColors(
                topology.data,
                meshQualityData.data,
                meshQualityMetric,
                scalarColorPalette,
              ),
          )
        : null,
    [
      meshQualityData.data,
      meshQualityMetric,
      meshQualityOverlayVisible,
      scalarColorPalette,
      topology.data,
      topologyCurrent,
    ],
  );
  const meshSizeHighlightModel = useMemo(
    () =>
      topologyCurrent
        ? measureViewport3DModelBuild(
            "fullmag.viewport3d.buildMeshSizeHistogramHighlight",
            () =>
              buildViewport3DMeshSizeHighlightModel(
                topology.data,
                topologyRenderModelForGeometry,
                femDomain,
                meshSizeHighlight,
                meshSizeHighlightSelection
                  ? { elementIndices: meshSizeHighlightSelection.element_indices }
                  : null,
              ),
          )
        : null,
    [
      topologyRenderModelForGeometry,
      femDomain,
      meshSizeHighlight,
      meshSizeHighlightSelection,
      topology.data,
      topologyCurrent,
    ],
  );
  const magnetizationTexturePreviews = useMemo(
    () => buildViewport3DMagnetizationTexturePreviewMap(scene.data),
    [scene.data],
  );
  const primitiveBounds = useMemo(
    () =>
      combineViewport3DBounds(
        primitiveModel.objects.map((object) => object.bounds),
      ),
    [primitiveModel],
  );
  const universeBounds = useMemo(
    () => resolveUniverseBounds(universe.data),
    [universe.data],
  );
  const fdmUniverseOutsideSupport = useMemo(
    () =>
      resolveFdmUniverseOutsideSupportOverlayFromPresentation(
        fdmDomainPresentation,
      ),
    [fdmDomainPresentation],
  );
  const topologyBounds = useMemo(
    () => (topologyCurrent ? resolveTopologyBounds(topology.data) : null),
    [topology.data, topologyCurrent],
  );
  const universeRootSelectionBounds = useMemo(() => {
    return (
      authoredUniverseBounds ??
      fdmUniverseOutsideSupport?.universeBounds ??
      (topologyCurrent ? resolveDomainBounds(domainMeta.data) : null)
    );
  }, [
    authoredUniverseBounds,
    domainMeta.data,
    fdmUniverseOutsideSupport?.universeBounds,
    topologyCurrent,
  ]);
  // Unmaterialized domains publish placeholder bounds. Frame the authored
  // Universe until current mesh data is available, not just the magnetic objects.
  const primaryResourceBounds =
    fdmUniverseOutsideSupport?.universeBounds ??
    (topologyCurrent ? resolveDomainBounds(domainMeta.data) : null) ??
    universeRootSelectionBounds ??
    topologyBounds ??
    universeBounds;
  const resourceBounds =
    combineViewport3DBounds(
      [primaryResourceBounds, fdmMultilayerAirboxDomain?.bounds].filter(
        (entry): entry is NonNullable<typeof entry> => Boolean(entry),
      ),
    ) ?? primaryResourceBounds;
  const liveBounds =
    combineViewport3DBounds(
      [resourceBounds, primitiveBounds].filter(
        (entry): entry is NonNullable<typeof entry> => Boolean(entry),
      ),
    ) ??
    resourceBounds ??
    primitiveBounds;
  const savedSamplingBounds = useMemo(
    () => savedViewportResourcesFresh && savedViewportResources.topology.data
      ? resolveTopologyBounds(savedViewportResources.topology.data)
      : null,
    [savedViewportResources.topology.data, savedViewportResourcesFresh],
  );
  const savedViewportBounds = useMemo(
    () =>
      savedViewportResourcesFresh && savedViewportResources.topology.data
        ? combineViewport3DBounds([
            resolveTopologyBounds(savedViewportResources.topology.data),
            savedAntennaSourceModel?.bounds ?? null,
          ].filter((entry): entry is Viewport3DBounds => entry !== null))
        : null,
    [savedAntennaSourceModel?.bounds, savedViewportResources.topology.data, savedViewportResourcesFresh],
  );
  const savedViewportCamera = useSavedViewportCamera({
    bounds: savedViewportBounds,
    enabled: savedSelectionActive,
    identityKey: savedDatasetSelection?.nodeId,
  });
  const cameraView = resolveViewport3DSceneCameraView({
    cameraRegistryCamera,
    commandState,
  });
  const cameraResource = savedSelectionActive
    ? savedViewportCamera.cameraResource
    : cameraView.cameraResource;
  const effectiveCameraOrthographicScale = savedSelectionActive
    ? savedViewportCamera.cameraOrthographicScale
    : cameraView.cameraOrthographicScale;
  const effectiveCameraProjection = savedSelectionActive
    ? savedViewportCamera.cameraProjection
    : cameraView.cameraProjection;
  const effectiveCameraState = savedSelectionActive
    ? savedViewportCamera.cameraState
    : cameraView.cameraState;
  const bounds = savedSelectionActive
    ? savedViewportBounds
    : liveBounds;
  const planarMonitorFramePreview = useMemo(
    () => planarMonitorDraft
      ? planarMonitorFramePreviewFromDraft(planarMonitorDraft, bounds, "draft")
      : committedPlanarMonitorPreviewDraft
        ? planarMonitorFramePreviewFromDraft(committedPlanarMonitorPreviewDraft, bounds, "committed")
      : resolvedPlanarMonitorFramePreview,
    [bounds, committedPlanarMonitorPreviewDraft, planarMonitorDraft, resolvedPlanarMonitorFramePreview],
  );
  const vectorScale = resolveViewport3DVectorScale(
    bounds?.size ?? [1e-6, 1e-6, 1e-6],
    savedPresentation?.settings.vectorLengthScale ?? 1,
    savedPresentation ? Math.min(savedPresentation.settings.vectorBudget, maxInteractiveVectorGlyphs,
      Number(savedViewportResources.geometry.data?.active_node_count ?? 0)) : maxInteractiveVectorGlyphs,
  );
  const savedShaderColorMode = savedPresentation?.settings.shaderColorMode;
  const savedVectorBudget = savedPresentation?.settings.vectorBudget;
  const savedVectorLengthScale = savedPresentation?.settings.vectorLengthScale;
  const savedFieldBuildSettings = useMemo(() => savedShaderColorMode !== undefined && savedVectorBudget !== undefined ? {
    shaderColorMode: savedShaderColorMode,
    vectorBudget: savedVectorBudget,
    vectorLengthScale: savedVectorLengthScale,
  } : undefined, [savedShaderColorMode, savedVectorBudget, savedVectorLengthScale]);
  const savedViewportSceneModel = useMemo(
    () => {
      if (
        !savedSelectionActive ||
        !savedViewportResourcesFresh ||
        savedViewportResources.eligibility.status !== "ready" ||
        !savedViewportResources.field.data ||
        !savedViewportResources.geometry.data ||
        !savedViewportResources.support.data ||
        !savedViewportResources.topology.data
      ) {
        return null;
      }
      return buildSavedFieldViewportSceneModel({
        field: savedViewportResources.field.data,
        geometry: savedViewportResources.geometry.data,
        palette: scalarColorPalette,
        support: savedViewportResources.support.data,
        topology: savedViewportResources.topology.data,
        vectorColorMode,
        vectorScale,
        settings: savedFieldBuildSettings,
        colorRanges: savedPresentation?.colorRanges,
        sceneVectorCap: maxInteractiveVectorGlyphs,
      });
    },
    [
      savedSelectionActive,
      savedViewportResourcesFresh,
      savedViewportResources.eligibility,
      savedViewportResources.field.data,
      savedViewportResources.geometry.data,
      savedViewportResources.support.data,
      savedViewportResources.topology.data,
      savedFieldBuildSettings,
      savedPresentation?.colorRanges,
      maxInteractiveVectorGlyphs,
      scalarColorPalette,
      vectorColorMode,
      vectorScale,
    ],
  );
  const savedColorModes = useMemo(() => new Set(
    [savedShaderColorMode ?? "magnitude", vectorColorMode]
      .filter(mode => ["magnitude", "x", "y", "z", "orientation"].includes(mode)),
  ), [savedShaderColorMode, vectorColorMode]);
  const savedColorRanges = useMemo(() => new Map(
    Object.entries(savedPresentation?.colorRanges ?? {}).map(([mode, range]) =>
      [mode, { min: range.minimum, max: range.maximum }]),
  ), [savedPresentation?.colorRanges]);
  const savedChunkedColors = useViewport3DChunkedScalarColors({
    buildDomainId: savedViewportResources.field.data?.savedScopeKey,
    buildSessionId: savedViewportResources.field.data?.savedScopeKey,
    colorModes: savedColorModes,
    colorPalette: scalarColorPalette,
    enabled: Boolean(savedSelectionActive && savedViewportSceneModel && savedPresentation?.settings.visible),
    fieldRevision: savedViewportResources.field.data?.savedScopeKey,
    fieldScalarRangesByMode: savedColorRanges,
    fieldVector: savedViewportSceneModel?.fieldVector,
    topology: savedViewportSceneModel?.topologyModel,
    topologyRevision: savedViewportSceneModel?.topologyModel?.meshRevision,
  });
  const savedFieldRenderModel = useMemo(() => {
    if (!savedViewportSceneModel) return null;
    const model = savedViewportSceneModel.fieldModel;
    const partColors = new Map(
      [...(model?.targetPasses.keys() ?? [])].map(id => [id, savedChunkedColors.colors]),
    );
    return finalizeSavedFieldColors(
      mergeViewport3DFieldScalarColors(model, savedChunkedColors.colors, vectorColorMode, partColors),
      savedViewportSceneModel.activeNodeMask,
      vectorColorMode,
    );
  }, [savedChunkedColors.colors, savedViewportSceneModel, vectorColorMode]);
  const selectionBounds = useMemo(
    () =>
      resolveViewport3DRegionSelectionBounds(selection, allRegionOverlays) ??
      resolvePrimitiveSelectionBounds(selection, primitiveModel) ??
      resolveViewport3DSelectionBounds(
        selection,
        femDomain,
        bounds,
        fdmSelectionGrid,
        fdmUniverseOutsideSupport,
        sharedDomainManifest.data?.generation_id,
        universeRootSelectionBounds,
      ),
    [
      selection,
      allRegionOverlays,
      primitiveModel,
      femDomain,
      bounds,
      fdmSelectionGrid,
      fdmUniverseOutsideSupport,
      sharedDomainManifest.data?.generation_id,
      universeRootSelectionBounds,
    ],
  );
  const globalLayers = renderingState?.layers;
  const globalObjectBaseSettings = useMemo(
    () => resolveGlobalObjectVisualizationSettings(renderingState),
    // Explicit deps on global layer fields only; airbox sub-fields excluded.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      globalLayers?.surface?.visible,
      globalLayers?.surface?.opacity,
      globalLayers?.wireframe?.visible,
      globalLayers?.points?.visible,
      globalLayers?.vectors?.visible,
      vectorStyleState?.alpha,
      vectorStyleState?.color_mode,
      vectorStyleState?.mono_color,
      vectorStyleState?.thickness,
      renderingState?.vector_glyphs,
      renderingState?.quantity?.active_quantity_id,
      renderingState?.active_quantity_id,
    ],
  );
  const viewportVisualizationTargets = useMemo(() => {
    const targets: VisualizationTargetRef[] = [];
    const seen = new Set<string>();
    pushViewportVisualizationTarget(
      targets,
      seen,
      AIRBOX_VISUALIZATION_TARGET,
    );

    const fdmDomainId = domainMeta.data?.domain_id ?? null;
    const fdmTarget = fdmDomain ? targetForFdmDomain(fdmDomainId) : null;
    if (fdmTarget) {
      pushViewportVisualizationTarget(targets, seen, fdmTarget);
    }
    for (const domain of fdmNativeLayerDomains) {
      pushViewportVisualizationTarget(
        targets,
        seen,
        targetForFdmNativeLayer(domain.layerId, domain.magnetName),
      );
    }
    if (fdmMembershipCurrent && fdmTargetDefinitionsResult.status === "ready") {
      for (const definition of fdmTargetDefinitionsResult.definitions) {
        pushViewportVisualizationTarget(targets, seen, definition.ownerTarget);
        pushViewportVisualizationTarget(targets, seen, definition.target);
      }
    }
    if (fdmUniverseOutsideSupport) {
      pushViewportVisualizationTarget(
        targets,
        seen,
        targetForFdmUniverseOutsideSupport(),
      );
    }

    for (const object of primitiveModel.objects) {
      pushViewportVisualizationTarget(targets, seen, {
        id: visualizationTargetIdForSceneObject(object.objectId),
        kind: "object",
        label: object.label,
      });
    }

    for (const part of femDomain.magneticParts) {
      pushViewportVisualizationTarget(
        targets,
        seen,
        resolveVisualizationTargetForMeshPart({
          part,
          sceneObjectIds,
          targetRegistry: renderingState?.targets,
        }),
      );
    }
    for (const part of femDomain.airboxParts) {
      pushViewportVisualizationTarget(
        targets,
        seen,
        resolveVisualizationTargetForMeshPart({
          part,
          sceneObjectIds,
          targetRegistry: renderingState?.targets,
        }),
      );
    }
    for (const region of allRegionOverlays) {
      const objectId = asNonEmptyString(region.owner_object_id);
      const regionId = asNonEmptyString(region.region_id);
      if (!objectId || !regionId) continue;
      pushViewportVisualizationTarget(targets, seen, {
        id: visualizationTargetIdForSceneObject(objectId, regionId),
        kind: "region",
        label: region.name ?? regionId,
      });
    }
    for (const target of regionTargetByPartId.values()) {
      pushViewportVisualizationTarget(targets, seen, target);
    }

    return targets;
  }, [
    domainMeta.data?.domain_id,
    fdmDomain,
    fdmNativeLayerDomains,
    fdmMembershipCurrent,
    fdmTargetDefinitionsResult,
    fdmUniverseOutsideSupport,
    femDomain.airboxParts,
    femDomain.magneticParts,
    primitiveModel.objects,
    regionTargetByPartId,
    allRegionOverlays,
    renderingState?.targets,
    sceneObjectIds,
  ]);
  const selectObjectVisualizationSnapshot = useCallback(
    (snapshot: ObjectVisualizationSnapshot) =>
      selectViewport3DObjectVisualizationSnapshot(
        snapshot,
        viewportVisualizationTargets,
      ),
    [viewportVisualizationTargets],
  );
  const objectVisualizationSnapshot = useObjectVisualizationSelector(
    selectObjectVisualizationSnapshot,
    { isEqual: viewport3DObjectVisualizationSnapshotEquals },
  );
  const fallbackSettings = useMemo(
    () =>
      resolveDefaultVisualizationSettings(
        objectVisualizationSnapshot,
        "object",
        globalObjectBaseSettings,
      ),
    [globalObjectBaseSettings, objectVisualizationSnapshot],
  );
  const fdmSettings = useMemo(() => {
    const fdmDomainId = domainMeta.data?.domain_id ?? null;
    const fdmTarget = fdmDomain ? targetForFdmDomain(fdmDomainId) : null;
    if (!fdmTarget) return fallbackSettings;
    const resolved = resolveTargetVisualization({
      snapshot: objectVisualizationSnapshot,
      target: fdmTarget,
      visualizationState: renderingState,
    }).effectiveSettings;
    return resolveFdmViewportVisualizationSettings(
      resolved,
      fdmMembershipCurrent,
    );
  }, [
    domainMeta.data?.domain_id,
    fallbackSettings,
    fdmMembershipCurrent,
    fdmDomain,
    objectVisualizationSnapshot,
    renderingState,
  ]);
  const fdmNativeLayerSettingsById = useMemo(() => {
    const settingsById = new Map<string, VisualizationTargetSettings>();
    for (const domain of fdmNativeLayerDomains) {
      const target = targetForFdmNativeLayer(domain.layerId, domain.magnetName);
      settingsById.set(
        domain.layerId,
        resolveViewport3DFdmNativeLayerSettings({
          activeMaskReady:
            !domain.activeMaskPresent ||
            domain.activeCellCount === domain.totalCells ||
            Boolean(
              fdmMultilayerLayerActiveMasks.data?.masks.get(domain.layerId),
            ),
          domain,
          globalObjectBaseSettings,
          objectContext: getObjectContext(domain.objectId),
          snapshot: objectVisualizationSnapshot,
          target,
          visualizationState: renderingState,
        }),
      );
    }
    return settingsById;
  }, [
    fdmNativeLayerDomains,
    fdmMultilayerLayerActiveMasks.data,
    getObjectContext,
    globalObjectBaseSettings,
    objectVisualizationSnapshot,
    renderingState,
  ]);
  const nativeLayerFieldRequests = useMemo<
    ReadonlyMap<string, Viewport3DFieldResourceRequest>
  >(() => resolveViewport3DFdmNativeLayerFieldRequests({
    available: Boolean(fdmLaneActive && fdmMultilayerLayout.data?.available),
    layers: fdmNativeLayerDomains.map((domain) => ({
      layerId: domain.layerId,
      settings: fdmNativeLayerSettingsById.get(domain.layerId) ?? null,
    })),
    maxSamples: FDM_NATIVE_LAYER_DISPLAY_CELL_BUDGET,
  }), [
    fdmLaneActive,
    fdmMultilayerLayout.data,
    fdmNativeLayerDomains,
    fdmNativeLayerSettingsById,
  ]);
  const nativeLayerFieldVectors = useViewport3DQuantityFieldVectors(
    nativeLayerFieldRequests,
    liveViewportResourcesEnabled &&
      fdmLaneActive && nativeLayerFieldRequests.size > 0,
    { selectedTargetId: selectedVisualizationTargetId },
  );
  const fdmTargetSettingsById = useMemo(() => {
    const settingsById = new Map<string, VisualizationTargetSettings>();
    if (!fdmMembershipCurrent || fdmTargetDefinitionsResult.status !== "ready") {
      return settingsById;
    }
    for (const definition of fdmTargetDefinitionsResult.definitions) {
      if (definition.target.kind !== "object") continue;
      const resolved = resolveViewport3DFdmTargetVisualization({
        objectContext: getObjectContext(definition.ownerTarget.id.slice("object:".length)),
        inheritedSettings: globalObjectBaseSettings,
        snapshot: objectVisualizationSnapshot,
        target: definition.target,
        visualizationState: renderingState,
      }).effectiveSettings;
      settingsById.set(
        definition.target.id,
        resolveFdmViewportVisualizationSettings(resolved, true),
      );
    }
    for (const definition of fdmTargetDefinitionsResult.definitions) {
      if (definition.target.kind !== "region") continue;
      const inheritedSettings = settingsById.get(definition.ownerTarget.id);
      if (!inheritedSettings) continue;
      const resolved = resolveViewport3DFdmTargetVisualization({
        objectContext: getObjectContext(definition.ownerTarget.id.slice("object:".length)),
        inheritedSettings,
        snapshot: objectVisualizationSnapshot,
        target: definition.target,
        visualizationState: renderingState,
      }).effectiveSettings;
      settingsById.set(
        definition.target.id,
        resolveFdmViewportVisualizationSettings(resolved, true),
      );
    }
    return settingsById;
  }, [
    fdmMembershipCurrent,
    fdmTargetDefinitionsResult,
    globalObjectBaseSettings,
    getObjectContext,
    objectVisualizationSnapshot,
    renderingState,
  ]);
  const fdmTargetSettings = useMemo(
    () => [...fdmTargetSettingsById.values()],
    [fdmTargetSettingsById],
  );
  const fdmTargetSettingsForPlanning = useMemo(
    () =>
      fdmTargetDefinitionsResult.status === "ready"
        ? fdmTargetDefinitionsResult.definitions.flatMap((definition) => {
            const settings = fdmTargetSettingsById.get(definition.target.id);
            return settings
              ? [{
                  label: definition.target.label ?? definition.target.id,
                  settings,
                  targetId: definition.target.id,
                }]
              : [];
          })
        : [],
    [fdmTargetDefinitionsResult, fdmTargetSettingsById],
  );
  const airboxSettings = useMemo(
    () =>
      resolveTargetVisualization({
        snapshot: objectVisualizationSnapshot,
        target: AIRBOX_VISUALIZATION_TARGET,
        visualizationState: renderingState,
      }).effectiveSettings,
    [objectVisualizationSnapshot, renderingState],
  );
  // Airbox is the public display target for both FDM paths.  The structured
  // outside-support id remains a carrier/query scope only; it must not own a
  // second set of display toggles.  A published multilayer Airbox uses its
  // target-only carrier, while legacy single-grid rendering uses these same
  // canonical settings for its inactive-cell model.
  const fdmSingleGridAirboxSettings = fdmMultilayerLayout.data?.available
    ? null
    : airboxSettings;
  const fdmVectorScale = fdmDomain
    ? resolveViewport3DFdmGridVectorScale(
        fdmDomain.shape,
        fdmDomain.spacing,
        fdmSettings.vectorLengthScale,
        clampViewport3DInteractiveVectorBudget(
          fdmSettings.vectorBudget,
          maxInteractiveVectorGlyphs,
        ),
        fdmSettings.geometryScope,
      )
    : vectorScale * fdmSettings.vectorLengthScale;
  const airboxQuantityCompatible =
    (quantityCatalogSupportsQuantity(
      quantityCatalog.data,
      airboxSettings.activeQuantityId,
      "airbox",
      airboxSettings.tensorProjection,
    ) ??
      fieldCatalogQuantitySupportsAirbox(
        fieldCatalog.data,
        airboxSettings.activeQuantityId,
      )) &&
    viewport3DFieldQuantityAvailable(
      airboxSettings.activeQuantityId,
      availableQuantityIdsForPlanning,
    );
  const getPartSettings = useCallback(
    (part: Viewport3DMeshPart) =>
      applyAnalysisOverlayAppearance(
        resolveViewport3DPartVisualizationSettings({
          objectVisualizationSnapshot,
          part,
          regionTarget: regionTargetByPartId.get(part.id),
          renderingState,
          sceneObjectIds,
          sceneObjectsById,
          quantityCatalog: quantityCatalog.data,
        }),
        analysisOverlay?.appearance,
      ),
    [
      analysisOverlay?.appearance,
      objectVisualizationSnapshot,
      regionTargetByPartId,
      renderingState,
      sceneObjectIds,
      sceneObjectsById,
      quantityCatalog.data,
    ],
  );
  const getObjectSettings = useCallback(
    (object: Viewport3DPrimitiveObject) =>
      resolveViewport3DPrimitiveVisualizationSettings({
        objectContext: getObjectContext(object.objectId),
        snapshot: objectVisualizationSnapshot,
        target: {
          id: visualizationTargetIdForSceneObject(object.objectId),
          kind: "object",
          label: object.label,
        },
        visualizationState: femLaneActive ? renderingState : null,
      }),
    [femLaneActive, getObjectContext, objectVisualizationSnapshot, renderingState],
  );
  const getRegionSettings = useCallback(
    (region: RegionOverlayInput) => {
      const objectId = asNonEmptyString(region.owner_object_id);
      const regionId = asNonEmptyString(region.region_id);
      if (!objectId || !regionId) return resolveEffectiveVisualizationSettings({ ...fallbackSettings, activeQuantityId: "" });
      const objectSettings = resolveTargetVisualization({
        objectContext: getObjectContext(objectId),
        snapshot: objectVisualizationSnapshot,
        target: {
          id: visualizationTargetIdForSceneObject(objectId),
          kind: "object",
          label: objectId,
        },
        visualizationState: femLaneActive ? renderingState : null,
      }).settings;
      return resolveTargetVisualization({
        objectContext: getObjectContext(objectId),
        inheritedSettings: objectSettings,
        snapshot: objectVisualizationSnapshot,
        target: {
          id: visualizationTargetIdForSceneObject(objectId, regionId),
          kind: "region",
          label: region.name ?? regionId,
        },
        visualizationState: femLaneActive ? renderingState : null,
      }).effectiveSettings;
    },
    [
      fallbackSettings,
      femLaneActive,
      getObjectContext,
      objectVisualizationSnapshot,
      renderingState,
    ],
  );
  const airboxVectorsVisible = viewport3DAirboxVectorsVisible(
    airboxSettings.visible,
    airboxSettings.vectorsVisible,
    airboxQuantityCompatible,
    vectorDomain,
  );
  const airboxFieldVectorEnabled =
    airboxVectorsVisible && !airboxSettings.airboxSyntheticVectorsEnabled;
  const airboxFieldVectorParts = useMemo(
    () =>
      fieldCompatibleTopologyRenderModel?.airboxParts.map((partModel) => partModel.part) ??
      EMPTY_AIRBOX_FIELD_VECTOR_PARTS,
    [fieldCompatibleTopologyRenderModel],
  );
  const airboxAvailableNodeCount = useMemo(() => {
    if (!fieldCompatibleTopologyRenderModel) return 0;
    return fieldCompatibleTopologyRenderModel.airboxParts.reduce(
      (total, partModel) =>
        total +
        resolveNodeSelectionCount(
          airboxSettings.geometryScope === "surface"
            ? partModel.surfaceNodeSelection ?? { nodeIndices: [] }
            : partModel.fullNodeSelection,
          fieldCompatibleTopologyRenderModel,
        ),
      0,
    );
  }, [airboxSettings.geometryScope, fieldCompatibleTopologyRenderModel]);
  const airboxFieldQuery = useMemo(
    () =>
      resolveViewport3DScopedVectorFieldQuery({
        geometryScope: airboxSettings.geometryScope,
        maxSamples: resolveViewport3DAirboxVectorSampleBudget(
          airboxSettings.vectorBudget,
          airboxAvailableNodeCount,
        ),
        surfaceColorMode: null,
        vectorsVisible: airboxVectorsVisible,
      }),
    [
      airboxSettings.geometryScope,
      airboxSettings.vectorBudget,
      airboxAvailableNodeCount,
      airboxVectorsVisible,
    ],
  );
  const airboxFieldDemandPlan = useMemo(
    () =>
      resolveViewport3DAirboxFieldVectorDemandPlan({
        airboxParts: airboxFieldVectorParts,
        availableQuantityIds: availableQuantityIdsForPlanning,
        fieldCatalog: fieldCatalog.data,
        quantityCatalog: quantityCatalog.data,
        fieldQuery: airboxFieldQuery,
        tensorProjection: airboxSettings.tensorProjection,
        quantityId: airboxSettings.activeQuantityId,
        replayQuery: selectedSnapshotQuery,
        vectorBudget: resolveViewport3DAirboxVectorSampleBudget(
          airboxSettings.vectorBudget,
          airboxAvailableNodeCount,
        ),
        vectorsVisible: airboxVectorsVisible,
      }),
    [
      airboxFieldQuery,
      airboxFieldVectorParts,
      airboxSettings.activeQuantityId,
      airboxSettings.tensorProjection,
      airboxAvailableNodeCount,
      airboxSettings.vectorBudget,
      airboxVectorsVisible,
      availableQuantityIdsForPlanning,
      fieldCatalog.data,
      quantityCatalog.data,
      selectedSnapshotQuery,
    ],
  );
  const airboxFieldVectorRequests = airboxFieldDemandPlan.requests;
  const fdmSurfaceColorMode = useMemo(() => {
    if (!fdmDomain) return null;
    const settings =
      fdmTargetSettings.find(
        (targetSettings) =>
          targetSettings.visible && targetSettings.shaderVisible,
      ) ??
      (fdmSettings.visible && fdmSettings.shaderVisible ? fdmSettings : null);
    return settings
      ? surfaceColorSourceToColorMode(settings.surfaceColorSource)
      : null;
  }, [fdmDomain, fdmSettings, fdmTargetSettings]);
  const magneticPartFieldDemandPlan = useMemo(
    () =>
      resolveViewport3DScopedPartVectorFieldDemandPlan({
        getPartSettings: (part) => getPartSettings(part as Viewport3DMeshPart),
        maxVectorGlyphs: maxInteractiveVectorGlyphs,
        magneticParts: fieldCompatibleTopologyRenderModel?.magneticParts ?? [],
        selectedSnapshotQuery,
        vectorDomain,
      }),
    [
      fieldCompatibleTopologyRenderModel?.magneticParts,
      getPartSettings,
      maxInteractiveVectorGlyphs,
      selectedSnapshotQuery,
      vectorDomain,
    ],
  );
  const magneticPartFieldQueries = magneticPartFieldDemandPlan.requests;
  const magneticPartScopedFieldIds = useMemo(
    () => new Set(magneticPartFieldQueries.keys()),
    [magneticPartFieldQueries],
  );
  const targetQuantityFieldDemandPlan = useMemo(() => {
    return resolveViewport3DTargetQuantityFieldDemandPlan({
      fdmAirboxSettings: fdmSingleGridAirboxSettings,
      fdmSettings: fdmDomain ? fdmSettings : null,
      fdmTargetSettings: fdmTargetSettingsForPlanning,
      getPartSettings: (part) => getPartSettings(part as Viewport3DMeshPart),
      magneticPartScopedFieldIds,
      magneticParts: fieldCompatibleTopologyRenderModel?.magneticParts ?? [],
      maxVectorGlyphs: maxInteractiveVectorGlyphs,
      primaryFieldQuantityId,
      selectedSnapshotQuery,
      availableQuantityIds: availableQuantityIdsForPlanning,
      fieldCatalog: fieldCatalog.data,
      quantityCatalog: quantityCatalog.data,
    });
  }, [
    fdmDomain,
    fdmSettings,
    fdmTargetSettingsForPlanning,
    fdmSingleGridAirboxSettings,
    fieldCompatibleTopologyRenderModel?.magneticParts,
    getPartSettings,
    magneticPartScopedFieldIds,
    maxInteractiveVectorGlyphs,
    primaryFieldQuantityId,
    selectedSnapshotQuery,
    availableQuantityIdsForPlanning,
    fieldCatalog.data,
    quantityCatalog.data,
  ]);
  const targetQuantityFieldRequests = targetQuantityFieldDemandPlan.requests;
  // Field payloads are viewport data: a published domain and its prepared
  // initial state are readable while the runtime lane is still unresolved.
  const targetQuantityFieldDemandActive = hasActiveViewport3DTargetQuantityDemand(
    viewportDataDiscretization,
    targetQuantityFieldRequests.size,
  );
  const airboxCellGeometryRequested =
    airboxSettings.visible && (
      airboxSettings.shaderVisible ||
      airboxSettings.pointsVisible ||
      airboxSettings.wireframeVisible
    );
  const fdmMultilayerAirboxGeometryScope =
    airboxCellGeometryRequested ? "full" : airboxSettings.geometryScope;
  const fdmMultilayerAirboxMaxSamples = useMemo(() => {
    if (
      !fdmMultilayerAirboxDomain ||
      !airboxSettings.vectorsVisible ||
      airboxSettings.shaderVisible
    ) {
      return null;
    }
    return resolveViewport3DAirboxVectorSampleBudget(
      airboxSettings.vectorBudget,
      fdmMultilayerAirboxDomain.totalCells,
    );
  }, [
    airboxSettings.shaderVisible,
    airboxSettings.vectorBudget,
    airboxSettings.vectorsVisible,
    fdmMultilayerAirboxDomain,
  ]);
  const fdmMultilayerAirboxFieldRequest = useMemo(
    () => {
      const request = fdmMultilayerAirboxDomain
        ? buildFdmMultilayerAirboxFieldRequest(
            fdmMultilayerAirboxDomain,
            fdmMultilayerAirboxMaxSamples,
            airboxSettings.activeQuantityId === "H_eff" ? "H_eff" : "H_demag",
            fdmMultilayerAirboxGeometryScope,
          )
        : null;
      return request ?? EMPTY_FDM_MULTILAYER_AIRBOX_FIELD_REQUEST;
    },
    [
      fdmMultilayerAirboxDomain,
      fdmMultilayerAirboxGeometryScope,
      fdmMultilayerAirboxMaxSamples,
      airboxSettings.activeQuantityId,
    ],
  );
  const fdmMultilayerAirboxField = useViewport3DFieldVectorRequest(
    fdmMultilayerAirboxFieldRequest,
    liveViewportResourcesEnabled &&
      Boolean(
        fdmLaneActive &&
        fdmMultilayerAirboxDomain &&
        shouldRequestFdmMultilayerAirboxField(
          airboxSettings,
          airboxSettings.activeQuantityId,
          fdmMultilayerAirboxDomain,
        ),
      ),
  );
  const magneticPartFieldVectors = useViewport3DPartFieldVectors(
    magneticPartFieldQueries,
    liveViewportResourcesEnabled &&
      femLaneActive && magneticPartFieldQueries.size > 0,
    { selectedTargetId: selectedVisualizationTargetId, tracker },
  );
  const targetQuantityFieldVectors = useViewport3DQuantityFieldVectors(
    targetQuantityFieldRequests,
    liveViewportResourcesEnabled && targetQuantityFieldDemandActive,
    { selectedTargetId: selectedVisualizationTargetId, tracker },
  );
  const airboxFieldVectors = useViewport3DAirboxFieldVectors(
    airboxSettings.activeQuantityId,
    airboxFieldVectorParts,
    liveViewportResourcesEnabled &&
      femLaneActive &&
      airboxFieldVectorEnabled &&
      airboxFieldVectorParts.length > 0,
    airboxFieldVectorRequests,
    { selectedTargetId: selectedVisualizationTargetId, tracker },
    fieldCatalog.data,
  );
  const rawFieldRenderOptions = useViewport3DFieldRenderOptions({
    airboxSettings,
    airboxQuantityCompatible,
    fallbackSettings: fdmLaneActive ? fdmSettings : fallbackSettings,
    getPartSettings,
    maxVectorGlyphs: maxInteractiveVectorGlyphs,
    scalarColorPalette,
    topologyRenderModel: fieldCompatibleTopologyRenderModel,
    vectorColorMode,
    vectorDomain,
  });
  const fieldColorLayersEnabled =
    viewport3DFieldColorLayersEnabledFromBrowserConfig();
  const vectorLayersEnabled = viewport3DVectorLayersEnabledFromBrowserConfig();
  const fieldRenderOptions = useMemo(
    () =>
      applyViewport3DFieldLayerDiagnosticOverrides(rawFieldRenderOptions, {
        fieldColorLayersEnabled,
        vectorLayersEnabled,
      }),
    [fieldColorLayersEnabled, rawFieldRenderOptions, vectorLayersEnabled],
  );
  const primaryFieldRenderOptions = useMemo(
    () =>
      fieldCompatibleTopologyRenderModel
        ? limitViewport3DFieldRenderVectorBudgets(
            {
              ...resolveViewport3DPrimaryFieldRenderOptions({
                analysisOverlayAppearance: analysisOverlay?.appearance,
                analysisOverlayActive: Boolean(analysisOverlay),
                fieldRenderOptions,
                getPartSettings,
                magneticParts: fieldCompatibleTopologyRenderModel.magneticParts,
                quantityId: primaryFieldQuantityId,
                vectorDomain,
              }),
              visualizationPhaseRad:
                analysisOverlay?.visualizationPhaseRad ??
                analysisOverlay?.query.phase_rad ??
                null,
            },
            fieldCompatibleTopologyRenderModel,
            maxInteractiveVectorGlyphs,
          )
        : {
            ...fieldRenderOptions,
            visualizationPhaseRad:
              analysisOverlay?.visualizationPhaseRad ??
              analysisOverlay?.query.phase_rad ??
              null,
          },
    [
      analysisOverlay,
      fieldCompatibleTopologyRenderModel,
      fieldRenderOptions,
      getPartSettings,
      maxInteractiveVectorGlyphs,
      primaryFieldQuantityId,
      vectorDomain,
    ],
  );
  const primaryFieldVectorBudgetExclusions = useMemo(() => {
    const excludedPartIds = new Set<string>();
    for (const partModel of fieldCompatibleTopologyRenderModel?.airboxParts ?? []) {
      excludedPartIds.add(partModel.part.id);
    }
    for (const partId of magneticPartScopedFieldIds) {
      excludedPartIds.add(partId);
    }
    if (!analysisOverlay) {
      for (const partModel of fieldCompatibleTopologyRenderModel?.magneticParts ?? []) {
        const settings = getPartSettings(partModel.part);
        if (!sameViewport3DQuantityId(settings.activeQuantityId, primaryFieldQuantityId)) {
          excludedPartIds.add(partModel.part.id);
        }
      }
    }
    return excludedPartIds;
  }, [
    analysisOverlay,
    fieldCompatibleTopologyRenderModel?.airboxParts,
    fieldCompatibleTopologyRenderModel?.magneticParts,
    getPartSettings,
    magneticPartScopedFieldIds,
    primaryFieldQuantityId,
  ]);
  const primaryFieldDataOptions = useMemo(
    () =>
      resolveViewport3DPrimaryFieldDataOptions(
        primaryFieldRenderOptions,
        primaryFieldVectorBudgetExclusions,
      ),
    [primaryFieldRenderOptions, primaryFieldVectorBudgetExclusions],
  );
  const partScalarRangeRequests = useMemo(
    () =>
      resolveViewport3DPartScalarRangeRequests({
        fieldRenderOptions: primaryFieldRenderOptions,
        getPartSettings,
        magneticParts: fieldCompatibleTopologyRenderModel?.magneticParts ?? [],
        selectedSnapshotQuery,
      }),
    [
      fieldCompatibleTopologyRenderModel?.magneticParts,
      getPartSettings,
      primaryFieldRenderOptions,
      selectedSnapshotQuery,
    ],
  );
  const partScalarRanges = useViewport3DPartScalarRanges(
    partScalarRangeRequests,
    liveViewportResourcesEnabled && partScalarRangeRequests.size > 0,
  );
  const resolvedFieldRenderOptions = useMemo(
    () => {
      const { partFieldVectors, partTargetFieldBuffers } =
        resolveViewport3DResolvedPartFieldBuffers({
          quantityCatalog: quantityCatalog.data,
          airboxFieldRevision: airboxFieldVectors.payloadRevision ?? null,
          airboxFieldVectorRequests,
          airboxFieldVectors: airboxFieldVectors.data,
          airboxQuantityCompatible,
          airboxQuantityId: airboxSettings.activeQuantityId,
          airboxSyntheticVectorsEnabled:
            airboxSettings.airboxSyntheticVectorsEnabled,
          getPartSettings,
          magneticPartFieldQueries,
          magneticPartFieldRevision:
            magneticPartFieldVectors.payloadRevision ?? null,
          magneticPartFieldVectors: magneticPartFieldVectors.data,
          sessionIdentity,
          targetQuantityFieldRequests,
          targetQuantityFieldRevision:
            targetQuantityFieldVectors.payloadRevision ?? null,
          targetQuantityFieldVectors: targetQuantityFieldVectors.data,
          topology: fieldCompatibleTopologyRenderModel,
          topologyRevision:
            topology.revision == null ? null : String(topology.revision),
        });
      const partScalarRangesByMode = mergeViewport3DPartScalarRanges({
        baseRanges: partScalarRanges.data,
        partFieldVectors,
        partScalarColorModes: primaryFieldRenderOptions.partScalarColorModes,
        partTargetFieldBuffers,
      });
      return partFieldVectors.size > 0 || partTargetFieldBuffers.size > 0
        ? {
            ...primaryFieldRenderOptions,
            ...(partFieldVectors.size > 0 ? { partFieldVectors } : {}),
            ...(partTargetFieldBuffers.size > 0
              ? { partTargetFieldBuffers }
              : {}),
            ...(partScalarRangesByMode.size > 0
              ? { partScalarRangesByMode }
              : {}),
          }
        : primaryFieldRenderOptions;
    },
    [
      quantityCatalog.data,      airboxFieldVectorRequests,
      airboxFieldVectors.data,
      airboxFieldVectors.payloadRevision,
      airboxSettings.airboxSyntheticVectorsEnabled,
      airboxSettings.activeQuantityId,
      airboxQuantityCompatible,
      fieldCompatibleTopologyRenderModel,
      getPartSettings,
      magneticPartFieldVectors.data,
      magneticPartFieldVectors.payloadRevision,
      magneticPartFieldQueries,
      partScalarRanges.data,
      primaryFieldRenderOptions,
      sessionIdentity,
      targetQuantityFieldVectors.data,
      targetQuantityFieldVectors.payloadRevision,
      targetQuantityFieldRequests,
      topology.revision,
    ],
  );
  const fdmVoxelMagnitudeThreshold =
    fdmDomain
      ? visualProfile.voxelMagnitudeThreshold
      : 0;
  const fdmTopographyEnabled = Boolean(
    fdmDomain &&
      commandState.widgets.fdmTopographyEnabled,
  );
  const fdmVoxelTopography = useMemo(
    () => ({
      amplitudeCells: commandState.widgets.fdmTopographyAmplitudeCells,
      component: commandState.widgets.fdmTopographyComponent,
      enabled: fdmTopographyEnabled,
    }),
    [
      commandState.widgets.fdmTopographyAmplitudeCells,
      commandState.widgets.fdmTopographyComponent,
      fdmTopographyEnabled,
    ],
  );
  const fdmVectorsVisible = Boolean(
    fdmMembershipCurrent &&
      fdmTargetSettings.some(
        (settings) =>
          settings.visible &&
          settings.vectorsVisible &&
          viewport3DFieldQuantityAvailable(
            settings.activeQuantityId,
            availableQuantityIdsForPlanning,
          ),
      ),
  );
  const fdmAirboxVectorsVisible = Boolean(
    !fdmMultilayerAirboxDomain &&
      fdmUniverseOutsideSupport &&
      fdmSingleGridAirboxSettings?.visible &&
      fdmSingleGridAirboxSettings.vectorsVisible &&
      viewport3DFieldQuantityAvailable(
        fdmSingleGridAirboxSettings.activeQuantityId,
        availableQuantityIdsForPlanning,
      ),
  );
  const fdmInstanceModelEnabled = Boolean(
    fdmMembershipCurrent &&
      fdmDomain &&
      fdmTargetDefinitionsResult.status === "ready",
  );
  const fdmInstanceModelNeedsFieldVector =
    fdmVoxelMagnitudeThreshold > 0 || fdmTopographyEnabled;
  const primaryFieldVectorEnabled =
    Boolean(primaryFieldQuantityId) &&
    !analysisFieldIntent &&
    Boolean(fdmDomain || fieldCompatibleTopologyRenderModel) &&
    (Boolean(analysisOverlay) ||
      (viewport3DFieldQuantityAvailable(
        primaryFieldQuantityId,
        availableQuantityIdsForPlanning,
      ) &&
        resolveViewport3DPrimaryFieldVectorEnabled({
          fdmInstanceModelNeedsFieldVector,
          fdmSurfaceColorMode,
          fdmVectorsVisible: fdmVectorsVisible || fdmAirboxVectorsVisible,
          fieldRenderOptions: primaryFieldDataOptions,
          selectedSnapshotId,
        })));
  const analysisPrimaryFieldDemandPlan = useMemo(() => {
    if (!analysisOverlay) return null;
    const request: Viewport3DFieldResourceRequest = {
      consumers: ["primary-field-vector"],
      quantityId: primaryFieldQuantityId,
      query: analysisOverlay.query,
      requestId: buildViewport3DFieldResourceRequestId(
        primaryFieldQuantityId,
        analysisOverlay.query,
      ),
    };
    return {
      demands: [],
      request,
    };
  }, [analysisOverlay, primaryFieldQuantityId]);
  const livePrimaryFieldDemandPlan = useMemo(
    () =>
      resolveViewport3DPrimaryFieldDemandPlan({
        fdmInstanceModelNeedsFieldVector,
        fdmSurfaceColorMode,
        fdmTopographyEnabled,
        fdmVectorsVisible: fdmVectorsVisible || fdmAirboxVectorsVisible,
        fieldRenderOptions: primaryFieldDataOptions,
        primaryFieldQuantityId,
        snapshotId: selectedSnapshotId,
        snapshotQuery: selectedSnapshotQuery,
      }),
    [
      fdmInstanceModelNeedsFieldVector,
      // The React Compiler cannot prove these derived lane values are immutable;
      // the explicit dependency list is intentional for the viewport model.
      fdmSurfaceColorMode,
      fdmTopographyEnabled,
      fdmVectorsVisible,
      fdmAirboxVectorsVisible,
      primaryFieldDataOptions,
      primaryFieldQuantityId,
      selectedSnapshotId,
      selectedSnapshotQuery,
    ],
  );
  const primaryFieldDemandPlan =
    analysisPrimaryFieldDemandPlan ?? livePrimaryFieldDemandPlan;
  const primaryFieldRequest = primaryFieldDemandPlan.request;
  const fieldDemandDiagnostics = useMemo<Viewport3DFieldDemandDiagnosticSummary[]>(
    () =>
      summarizeViewport3DFieldDemandDiagnostics({
        demands: [
          ...primaryFieldDemandPlan.demands,
          ...magneticPartFieldDemandPlan.demands,
          ...targetQuantityFieldDemandPlan.demands,
          ...airboxFieldDemandPlan.demands,
        ],
        requests: [
          primaryFieldDemandPlan.request,
          ...magneticPartFieldDemandPlan.requests.values(),
          ...targetQuantityFieldDemandPlan.requests.values(),
          ...Array.from(airboxFieldDemandPlan.requests.values(), (request) => ({
            consumers: request.consumers ?? [],
            query: request.query,
            quantityId: request.quantityId,
            requestId:
              request.requestId ??
              buildViewport3DFieldResourceRequestId(
                request.quantityId,
                request.query,
              ),
          })),
        ],
      }),
    [
      airboxFieldDemandPlan,
      magneticPartFieldDemandPlan,
      primaryFieldDemandPlan,
      targetQuantityFieldDemandPlan,
    ],
  );
  const dataPlaneIssues = useMemo(() => {
    const requests: Array<readonly [string, Viewport3DFieldResourceRequest]> = [
      ["primary-field", primaryFieldDemandPlan.request],
      ...Array.from(magneticPartFieldDemandPlan.requests),
      ...Array.from(targetQuantityFieldDemandPlan.requests),
      ...Array.from(airboxFieldDemandPlan.requests, ([targetId, request]) => [
        targetId,
        {
          consumers: request.consumers ?? [],
          query: request.query,
          quantityId: request.quantityId,
          requestId:
            request.requestId ??
            buildViewport3DFieldResourceRequestId(
              request.quantityId,
              request.query,
            ),
        },
      ] as const),
    ];
    return [
      ...validateViewport3DFieldResourceRequestIdentities(requests),
      ...validateViewport3DFieldResourceRequestEquivalence(requests),
    ];
  }, [
    airboxFieldDemandPlan,
    magneticPartFieldDemandPlan,
    primaryFieldDemandPlan,
    targetQuantityFieldDemandPlan,
  ]);
  const liveFieldVectorResourceKey = useMemo(
    () =>
      resolveViewport3DFieldVectorRequestResourceKey(primaryFieldRequest),
    [primaryFieldRequest],
  );
  const fieldVectorResourceKey = pinnedObservationActive
    ? observationFrameMagnetizationResourceKey(pinnedObservationSource.frameId)
    : liveFieldVectorResourceKey;
  const hysteresisReplayMeshCompatibility = useMemo(
    () =>
      resolveHysteresisReplayMeshCompatibility(
        hysteresisReplayTarget,
        fieldCompatibleTopologyRenderModel,
      ),
    [
      fieldCompatibleTopologyRenderModel,
      hysteresisReplayTarget,
    ],
  );
  const fieldVectorEnabled =
    liveViewportResourcesEnabled &&
    // Published fields belong to the published domain, including the initial
    // magnetization before Compute resolves a runtime lane. This opens the
    // published-field data path; execution, availability and topology stay fenced.
    (viewportDataDiscretization !== null || Boolean(analysisOverlay) || pinnedObservationActive) &&
    primaryFieldVectorEnabled &&
    hysteresisReplayMeshCompatibility.status !== "mismatch";
  const scalarRangeModeFlags = useMemo(
    () =>
      resolveViewport3DScalarRangeModeFlags(
        primaryFieldRenderOptions.scalarColorModes,
        vectorColorMode,
      ),
    [primaryFieldRenderOptions.scalarColorModes, vectorColorMode],
  );
  const scalarRangeStatsEnabled =
    fieldVectorEnabled && primaryFieldRenderOptions.scalarColorsVisible !== false;
  const primaryFieldMetaEnabled =
    scalarRangeStatsEnabled &&
    !pinnedObservationActive &&
    !isAnalysisFieldQuantityId(primaryFieldQuantityId) &&
    viewport3DFieldQuantityAvailable(
      primaryFieldQuantityId,
      availableQuantityIdsForPlanning,
    );
  const primaryMagnitudeFieldMeta = useFieldMetaResource({
    component: resolveViewport3DFieldMetaScalarComponent(
      primaryFieldQuantityId,
      "magnitude",
    ),
    enabled:
      liveViewportResourcesEnabled &&
      primaryFieldMetaEnabled &&
      scalarRangeModeFlags.magnitude,
    quantityId: primaryFieldQuantityId,
    snapshot_id: selectedSnapshotQuery?.snapshot_id ?? null,
    stage_id: selectedSnapshotQuery?.stage_id ?? null,
  });
  const primaryXFieldMeta = useFieldMetaResource({
    component: resolveViewport3DFieldMetaScalarComponent(
      primaryFieldQuantityId,
      "x",
    ),
    enabled:
      liveViewportResourcesEnabled &&
      primaryFieldMetaEnabled &&
      scalarRangeModeFlags.x,
    quantityId: primaryFieldQuantityId,
    snapshot_id: selectedSnapshotQuery?.snapshot_id ?? null,
    stage_id: selectedSnapshotQuery?.stage_id ?? null,
  });
  const primaryYFieldMeta = useFieldMetaResource({
    component: resolveViewport3DFieldMetaScalarComponent(
      primaryFieldQuantityId,
      "y",
    ),
    enabled:
      liveViewportResourcesEnabled &&
      primaryFieldMetaEnabled &&
      scalarRangeModeFlags.y,
    quantityId: primaryFieldQuantityId,
    snapshot_id: selectedSnapshotQuery?.snapshot_id ?? null,
    stage_id: selectedSnapshotQuery?.stage_id ?? null,
  });
  const primaryZFieldMeta = useFieldMetaResource({
    component: resolveViewport3DFieldMetaScalarComponent(
      primaryFieldQuantityId,
      "z",
    ),
    enabled:
      liveViewportResourcesEnabled &&
      primaryFieldMetaEnabled &&
      scalarRangeModeFlags.z,
    quantityId: primaryFieldQuantityId,
    snapshot_id: selectedSnapshotQuery?.snapshot_id ?? null,
    stage_id: selectedSnapshotQuery?.stage_id ?? null,
  });
  const fieldScalarRangesByMode = useMemo<
    ReadonlyMap<string, ScalarRange> | undefined
  >(() => {
    const entries: [string, ScalarRange][] = [];
    const magnitudeRange = resolveViewport3DFieldMetaScalarRange(
      primaryMagnitudeFieldMeta.data,
    );
    const xRange = resolveViewport3DFieldMetaScalarRange(primaryXFieldMeta.data);
    const yRange = resolveViewport3DFieldMetaScalarRange(primaryYFieldMeta.data);
    const zRange = resolveViewport3DFieldMetaScalarRange(primaryZFieldMeta.data);
    if (magnitudeRange) entries.push(["magnitude", magnitudeRange]);
    if (xRange) entries.push(["x", xRange]);
    if (yRange) entries.push(["y", yRange]);
    if (zRange) entries.push(["z", zRange]);
    const mode = analysisOverlay?.appearance?.colorRangeMode;
    const gain = Math.max(0, analysisOverlay?.appearance?.displayGain ?? 1);
    const configuredMax = analysisOverlay?.appearance?.colorRangeMax;
    const configuredMin = analysisOverlay?.appearance?.colorRangeMin;
    if (mode === "manual" && configuredMin != null && configuredMax != null) {
      const denominator = Math.max(gain, Number.EPSILON);
      const range = {
        max: configuredMax / denominator,
        min: configuredMin / denominator,
      };
      for (const scalarMode of enabledScalarRangeModes(scalarRangeModeFlags)) {
        entries.push([scalarMode, range]);
      }
    } else if (mode === "symmetric" && configuredMax != null) {
      const extent = Math.abs(configuredMax) / Math.max(gain, Number.EPSILON);
      for (const scalarMode of enabledScalarRangeModes(scalarRangeModeFlags)) {
        entries.push([scalarMode, { max: extent, min: -extent }]);
      }
    }
    return entries.length > 0 ? new Map(entries) : undefined;
  }, [
    analysisOverlay?.appearance?.colorRangeMax,
    analysisOverlay?.appearance?.colorRangeMin,
    analysisOverlay?.appearance?.colorRangeMode,
    analysisOverlay?.appearance?.displayGain,
    primaryMagnitudeFieldMeta.data,
    primaryXFieldMeta.data,
    primaryYFieldMeta.data,
    primaryZFieldMeta.data,
    scalarRangeModeFlags,
  ]);
  // The primary field vector is enabled exactly when `fieldDataIssue` can
  // report its failure, so the viewport issue banner is its single foreground
  // surface (R24). Suppress the duplicate global toast; resource-hook
  // diagnostics still record the failure as history.
  const liveFieldVector = useViewport3DFieldVectorRequest(
    primaryFieldRequest,
    liveViewportResourcesEnabled &&
      fieldVectorEnabled &&
      !pinnedObservationActive,
    VIEWPORT3D_PRIMARY_FIELD_VECTOR_REQUEST_OPTIONS,
  );
  const observationFieldVector = useViewport3DObservationFrameMagnetization(
    pinnedObservationSource?.frameId,
    liveViewportResourcesEnabled &&
      fieldVectorEnabled &&
      pinnedObservationActive,
    VIEWPORT3D_PRIMARY_FIELD_VECTOR_REQUEST_OPTIONS,
  );
  const fieldVector = pinnedObservationActive
    ? observationFieldVector
    : liveFieldVector;
  const incomingFieldVectorEnvelope = useMemo<Viewport3DFieldVectorEnvelope | null>(
    () =>
      fieldVector.data
        ? {
            data: fieldVector.data,
            etag:
              fieldVector.payloadRevision == null
                ? fieldVector.revision == null
                  ? null
                  : String(fieldVector.revision)
                : String(fieldVector.payloadRevision),
            responseMetadata: fieldVector.responseMetadata,
            resourceKey: fieldVectorResourceKey,
          }
        : null,
    [
      fieldVector.data,
      fieldVector.payloadRevision,
      fieldVector.responseMetadata,
      fieldVector.revision,
      fieldVectorResourceKey,
    ],
  );
  const [primaryFieldRetained, setPrimaryFieldRetained] =
    useState<Viewport3DPrimaryFieldRetainedState | null>(null);
  const fieldVectorRevisionString =
    fieldVector.revision == null ? null : String(fieldVector.revision);
  const fieldVectorPayloadRevisionString =
    fieldVector.payloadRevision == null
      ? null
      : String(fieldVector.payloadRevision);
  const fieldVectorPreparedRevision =
    fieldVectorPayloadRevisionString ?? fieldVectorRevisionString;
  const {
    displayedEnvelope: displayedFieldVectorEnvelope,
    displayedRevision: fieldVectorDisplayedRevision,
    nextRetained: nextPrimaryFieldRetained,
  } = useMemo(() => {
    if (!fieldVectorEnabled) {
      return {
        displayedEnvelope: null,
        displayedRevision: null,
        nextRetained: null,
      };
    }
    return resolvePrimaryFieldDisplayedEnvelope({
      incomingEnvelope: incomingFieldVectorEnvelope,
      status: fieldVector.status,
      preparedRevision: fieldVectorPreparedRevision,
      retained: primaryFieldRetained,
      request: primaryFieldRequest,
      sourceResourceKey: fieldVectorResourceKey,
      tracker,
    });
  }, [
    fieldVector.status,
    fieldVectorEnabled,
    fieldVectorPreparedRevision,
    incomingFieldVectorEnvelope,
    primaryFieldRequest,
    primaryFieldRetained,
    fieldVectorResourceKey,
    tracker,
  ]);
  if (nextPrimaryFieldRetained !== primaryFieldRetained) {
    setPrimaryFieldRetained(nextPrimaryFieldRetained);
  }
  const displayedFieldVector = displayedFieldVectorEnvelope?.data ?? null;
  const analysisComplexFieldQuery = useMemo(
    () =>
      analysisOverlay
        ? resolveViewport3DAnalysisComplexFieldQuery(analysisOverlay.query)
        : {},
    [analysisOverlay],
  );
  const analysisComplexProjectionEnabled = useMemo(
    () => resolveViewport3DAnalysisComplexProjectionEnabled(analysisOverlay?.query),
    [analysisOverlay?.query],
  );
  const analysisComplexFieldVector = useViewport3DAnalysisFieldVector(
    primaryFieldQuantityId,
    analysisComplexFieldQuery,
    liveViewportResourcesEnabled &&
      Boolean(analysisOverlay) &&
      !analysisFieldIntent &&
      analysisComplexProjectionEnabled &&
      fieldVectorEnabled,
  );
  const fieldDataIssue = useMemo<Viewport3DFieldDataIssue | null>(() => {
    const fieldVectorErrorMessage =
      fieldVectorEnabled && fieldVector.error ? fieldVector.error.message : null;
    return resolveViewport3DFieldDataIssue({
      fieldVectorEnabled,
      fieldVectorErrorMessage,
      fieldVectorRefetch: fieldVector.refetch,
      fieldVectorResourceKey,
      fieldVectorRevision: fieldVector.revision,
      fieldVectorStatus: fieldVector.status,
      fieldVectorDataAvailable: fieldVector.data !== null,
      hysteresisReplayMeshCompatibility,
      primaryFieldQuantityId,
    });
  }, [
    fieldVector.error,
    fieldVector.data,
    fieldVector.refetch,
    fieldVector.revision,
    fieldVector.status,
    fieldVectorEnabled,
    fieldVectorResourceKey,
    hysteresisReplayMeshCompatibility,
    primaryFieldQuantityId,
  ]);
  const fieldRefresh = useMemo<Viewport3DFieldRefreshState>(
    () => ({
      enabled: !pinnedObservationActive && computeRunning && fieldVectorEnabled,
      payloadRevision: fieldVector.payloadRevision ?? null,
      quantityId: primaryFieldQuantityId,
      resourceKey: fieldVectorResourceKey,
      revision: fieldVector.revision,
      requestedRevision: fieldVector.revision,
      status: fieldVector.status,
    }),
    [
      computeRunning,
      fieldVector.revision,
      fieldVector.payloadRevision,
      fieldVector.status,
      fieldVectorEnabled,
      fieldVectorResourceKey,
      pinnedObservationActive,
      primaryFieldQuantityId,
    ],
  );
  const committedFieldVector = modeFieldOverlay.binary ?? displayedFieldVector;
  const primaryFieldRevision =
    modeFieldOverlay.metadata?.resourceRevision ??
    displayedFieldVectorEnvelope?.etag ??
    null;
  const fieldRenderOptionsWithPrimaryTargetBuffers = useMemo(
    () =>
      mergeViewport3DPrimaryTargetFieldBuffers({
        fieldRenderOptions: resolvedFieldRenderOptions,
        fieldRevision:
          primaryFieldRevision == null ? null : String(primaryFieldRevision),
        fieldVector: committedFieldVector,
        getPartSettings,
        primaryFieldQuantityId,
        primaryFieldRequest,
        primaryFieldResourceKey: fieldVectorResourceKey,
        sessionIdentity,
        topology: fieldCompatibleTopologyRenderModel,
        topologyRevision:
          topology.revision == null ? null : String(topology.revision),
      }),
    [
      committedFieldVector,
      fieldCompatibleTopologyRenderModel,
      getPartSettings,
      primaryFieldQuantityId,
      primaryFieldRequest,
      fieldVectorResourceKey,
      primaryFieldRevision,
      resolvedFieldRenderOptions,
      sessionIdentity,
      topology.revision,
    ],
  );
  const analysisComplexField = useMemo(() => {
    if (analysisFieldIntent) return modeFieldOverlay.field;
    return analysisComplexProjectionEnabled
      ? asDecodedComplexFieldVector(analysisComplexFieldVector.data)
      : null;
  }, [
    analysisComplexFieldVector.data,
    analysisComplexProjectionEnabled,
    analysisFieldIntent,
    modeFieldOverlay.field,
  ]);
  const analysisOverlaySourceIdentity = useMemo(
    () =>
      analysisFieldIntent
        ? resolveViewport3DModeFieldOverlaySourceIdentity({
            metadata: modeFieldOverlay.metadata,
          })
        : null,
    [analysisFieldIntent, modeFieldOverlay.metadata],
  );
  const fdmUsesPrimaryField = sameViewport3DQuantityId(
    fdmSettings.activeQuantityId,
    primaryFieldQuantityId,
  );
  const fdmTargetQuantityField =
    !fdmUsesPrimaryField && targetQuantityFieldVectors.data
      ? resolveViewport3DTargetQuantityFieldVectorForTarget({
          fieldVectors: targetQuantityFieldVectors.data,
          quantityId: fdmSettings.activeQuantityId,
          requests: targetQuantityFieldRequests,
          targetId: "fdm-domain",
      })
      : null;
  const fdmAirboxActiveQuantityId =
    fdmSingleGridAirboxSettings?.activeQuantityId ?? "m";
  const fdmAirboxResolvedField = resolveViewport3DFdmTargetFieldVectorForTarget({
    primaryFieldQuantityId,
    primaryFieldVector: committedFieldVector,
    quantityId: fdmAirboxActiveQuantityId,
    targetFieldRequests: targetQuantityFieldRequests,
    targetFieldVectors: targetQuantityFieldVectors.data,
    targetId: "airbox",
  });
  const fdmAirboxUsesPrimaryField =
    fdmAirboxResolvedField?.requestId === "primary-field-vector";
  const fdmAirboxTargetQuantityField =
    fdmAirboxResolvedField && !fdmAirboxUsesPrimaryField
      ? fdmAirboxResolvedField
      : null;
  const fdmCandidateFieldVector = fdmUsesPrimaryField
    ? committedFieldVector
    : fdmTargetQuantityField?.fieldVector ?? null;
  const fdmFieldResponseMetadata = fdmUsesPrimaryField
    ? fieldVector.responseMetadata
    : fdmTargetQuantityField
      ? targetQuantityFieldVectors.responseMetadataByRequestId.get(
          fdmTargetQuantityField.requestId,
        ) ?? null
      : null;
  const fdmResponseDomainGenerationId = fdmCandidateFieldVector
    ? resolveTrustedViewport3DResponseDomainGenerationId(
        fdmCandidateFieldVector,
        fdmFieldResponseMetadata,
      )
    : null;
  const fdmDomainGenerationId = safeViewport3DDomainGenerationId(
    domainMeta.data?.generation_id,
  );
  const fdmGridShape = fdmDomain?.shape;
  const fdmGridShapeX = fdmGridShape?.[0] ?? null;
  const fdmGridShapeY = fdmGridShape?.[1] ?? null;
  const fdmGridShapeZ = fdmGridShape?.[2] ?? null;
  const fdmMeshTopologyHash =
    fdmRegionMembershipBinary.data?.gridFingerprint ?? null;
  const fdmPointCount = fdmDomain?.totalCells ?? 0;
  const fdmFieldDomainIdentity = useMemo(
    () => ({
      discretization: "fdm" as const,
      domainGenerationId: fdmDomainGenerationId,
      gridShape:
        fdmGridShapeX == null || fdmGridShapeY == null || fdmGridShapeZ == null
          ? null
          : ([fdmGridShapeX, fdmGridShapeY, fdmGridShapeZ] as const),
      meshTopologyHash: fdmMeshTopologyHash,
      meshTopologyRevision: null,
      pointCount: fdmPointCount,
    }),
    [
      fdmDomainGenerationId,
      fdmGridShapeX,
      fdmGridShapeY,
      fdmGridShapeZ,
      fdmMeshTopologyHash,
      fdmPointCount,
    ],
  );
  const fdmFieldCompatibility = fdmCandidateFieldVector
    ? resolveViewport3DFieldDomainCompatibility({
        domain: fdmFieldDomainIdentity,
        field: fdmCandidateFieldVector,
        responseDomainGenerationId: fdmResponseDomainGenerationId,
      })
    : null;
  const fdmFieldVector = resolveViewport3DFieldVectorForDomain({
    domain: fdmFieldDomainIdentity,
    fieldVector: fdmCandidateFieldVector,
    responseDomainGenerationId: fdmResponseDomainGenerationId,
  });
  const fdmPrimaryResponseDomainGenerationId = committedFieldVector
    ? resolveTrustedViewport3DResponseDomainGenerationId(
        committedFieldVector,
        fieldVector.responseMetadata,
      )
    : null;
  const fdmPrimaryFieldVector = resolveViewport3DFieldVectorForDomain({
    domain: fdmFieldDomainIdentity,
    fieldVector: committedFieldVector,
    responseDomainGenerationId: fdmPrimaryResponseDomainGenerationId,
  });
  const fdmAirboxCandidateFieldVector = fdmAirboxResolvedField?.fieldVector ?? null;
  const fdmAirboxFieldResponseMetadata = fdmAirboxUsesPrimaryField
    ? fieldVector.responseMetadata
    : fdmAirboxTargetQuantityField
      ? targetQuantityFieldVectors.responseMetadataByRequestId.get(
          fdmAirboxTargetQuantityField.requestId,
        ) ?? null
      : null;
  const fdmAirboxResponseDomainGenerationId = fdmAirboxCandidateFieldVector
    ? resolveTrustedViewport3DResponseDomainGenerationId(
        fdmAirboxCandidateFieldVector,
        fdmAirboxFieldResponseMetadata,
      )
    : null;
  const fdmAirboxDomainCompatibleFieldVector = resolveViewport3DFieldVectorForDomain({
    domain: fdmFieldDomainIdentity,
    fieldVector: fdmAirboxCandidateFieldVector,
    responseDomainGenerationId: fdmAirboxResponseDomainGenerationId,
  });
  const fdmAirboxFieldRequest = fdmAirboxUsesPrimaryField
    ? primaryFieldRequest
    : fdmAirboxTargetQuantityField?.request ?? null;
  const fdmAirboxIdentityBuffer =
    fdmAirboxDomainCompatibleFieldVector && fdmAirboxFieldRequest
      ? buildViewport3DTargetFieldBuffer({
          consumers: fdmAirboxFieldRequest.consumers,
          domain: fdmFieldDomainIdentity,
          fieldVector: fdmAirboxDomainCompatibleFieldVector,
          query: fdmAirboxFieldRequest.query,
          responseDomainGenerationId: fdmAirboxResponseDomainGenerationId,
          responseMetadata: fdmAirboxFieldResponseMetadata,
          resourceKey: null,
          sessionIdentity,
          targetIds: ["airbox"],
        })
      : null;
  const fdmAirboxFieldVector = fdmAirboxIdentityBuffer?.requestIdentityCompatible
    ? fdmAirboxDomainCompatibleFieldVector
    : null;
  const fdmFieldRevision =
    sameViewport3DQuantityId(fdmSettings.activeQuantityId, primaryFieldQuantityId)
      ? fieldVector.payloadRevision ?? fieldVector.revision
      : targetQuantityFieldVectors.payloadRevision ??
        targetQuantityFieldVectors.revision;
  const fdmAirboxFieldRevision = fdmAirboxUsesPrimaryField
    ? fieldVector.payloadRevision ?? fieldVector.revision
    : targetQuantityFieldVectors.payloadRevision ??
      targetQuantityFieldVectors.revision;
  const fdmInstanceModelFieldVector = fdmInstanceModelNeedsFieldVector
    ? fdmFieldVector
    : null;
  const fdmBuildTopologyRevision =
    domainMeta.revision == null ? null : String(domainMeta.revision);
  const fdmBuildFieldRevision =
    fdmInstanceModelNeedsFieldVector
      ? fdmFieldRevision == null
        ? null
        : String(fdmFieldRevision)
      : null;
  const fdmBuildSamplingRevision = fdmDomain
    ? `shape=${fdmDomain.shape.join("x")}|display=${fdmDomain.displayCellCount}|total=${fdmDomain.totalCells}|stride=${fdmDomain.stride}|membership=${fdmRegionMembership.revision ?? "none"}`
    : "none";
  const fdmBuildStyleRevision = [
    `fill=${visualProfile.voxelFillRatio}`,
    `threshold=${fdmVoxelMagnitudeThreshold}`,
    `topography=${fdmVoxelTopography.enabled}:${fdmVoxelTopography.component}:${fdmVoxelTopography.amplitudeCells}`,
  ].join("|");
  const fdmBuildKey = fdmInstanceModelEnabled
    ? buildViewport3DFdmCuboidJobKey({
        algorithmVersion: 1,
        component: fdmInstanceModelNeedsFieldVector
          ? fdmVoxelTopography.component
          : null,
        domainId: domainMeta.data?.domain_id ?? "shared-domain",
        domainGenerationId: fdmDomainGenerationId,
        fieldRevision: fdmBuildFieldRevision,
        quantityId: fdmInstanceModelNeedsFieldVector
          ? resolveCanonicalQuantityId(fdmFieldVector?.quantityId ?? "m")
          : "geometry",
        samplingRevision: fdmBuildSamplingRevision,
        scopeId: "full",
        scopeKind: "full",
        sessionId: "current",
        styleRevision: fdmBuildStyleRevision,
        targetVisualizationRevision: "shared-model",
        topologyRevision: fdmBuildTopologyRevision,
      })
    : null;
  const fdmBuildGroupKey = fdmInstanceModelEnabled
    ? `fdm-cuboid:session=current:domain=${domainMeta.data?.domain_id ?? "shared-domain"}`
    : null;
  const fdmBuildState = useFdmCuboidBuildResult({
    buildKey: fdmBuildKey,
    cellSelection: "active",
    domain: fdmDomain,
    enabled: fdmInstanceModelEnabled,
    groupKey: fdmBuildGroupKey,
    maxVectorGlyphs: 0,
    modelFieldVector: fdmInstanceModelFieldVector,
    topologyKey: `fdm-grid:${domainMeta.data?.domain_id ?? "shared-domain"}|generation=${fdmDomainGenerationId}|${fdmBuildSamplingRevision}|topology=${fdmBuildTopologyRevision ?? "none"}`,
    realizedRegionIds: fdmRealizedRegionIds,
    revisionSummary: `domain=${fdmBuildTopologyRevision ?? "none"} field=${fdmBuildFieldRevision ?? "none"} membership=${fdmRegionMembership.revision ?? "none"}`,
    vectorAnchorMode: "center",
    vectorField: null,
    vectorScale: 0,
    voxelFillRatio: visualProfile.voxelFillRatio,
    voxelMagnitudeThreshold: fdmVoxelMagnitudeThreshold,
    voxelTopography: fdmVoxelTopography,
  });
  const fdmBuildResult = fdmBuildState?.result ?? undefined;
  const fdmInstanceModel: FdmCuboidInstanceModel | null | undefined =
    fdmBuildResult?.model;
  const fdmTargetViewsResult = useMemo(
    () =>
      buildViewport3DFdmTargetViews({
        membership: fdmRegionMembership.data,
        model: fdmInstanceModel,
        realizedRegionIds: fdmRealizedRegionIds,
        sceneObjectIds,
      }),
    [
      fdmInstanceModel,
      fdmRealizedRegionIds,
      fdmRegionMembership.data,
      sceneObjectIds,
    ],
  );
  const fdmTargetVectorAllocations = useMemo(() => {
    const targets: Viewport3DVectorBudgetTarget[] = [];
    if (fdmTargetViewsResult.status === "ready") {
      for (const view of fdmTargetViewsResult.views) {
        const settings = fdmTargetSettingsById.get(view.target.id);
        targets.push({
          available:
            settings?.geometryScope === "surface"
              ? view.surfaceInstanceOrdinals.length
              : view.instanceOrdinals.length,
          requested: settings?.vectorsVisible ? settings.vectorBudget : 0,
          targetId: `fdm-target:${view.target.id}`,
        });
      }
    }

    if (
      fdmSingleGridAirboxSettings?.visible &&
      fdmSingleGridAirboxSettings.vectorsVisible
    ) {
      const available = fdmRealizedRegionIds
        ? fdmRealizedRegionIds.reduce(
            (count, regionId) =>
              count + (regionId === FMRM_INACTIVE_REGION_ID ? 1 : 0),
            0,
          )
        : fdmDomain?.displayCellCount ?? 0;
      targets.push({
        available,
        requested: fdmSingleGridAirboxSettings.vectorBudget,
        targetId: "fdm-airbox",
      });
    }

    for (const domain of fdmNativeLayerDomains) {
      const settings = fdmNativeLayerSettingsById.get(domain.layerId) ?? fdmSettings;
      targets.push({
        available: domain.activeCellCount,
        requested: settings.visible && settings.vectorsVisible
          ? settings.vectorBudget
          : 0,
        targetId: `fdm-native:${domain.layerId}`,
      });
    }

    if (fdmMultilayerAirboxDomain) {
      targets.push({
        available: fdmMultilayerAirboxDomain.totalCells,
        requested:
          airboxSettings.visible && airboxSettings.vectorsVisible
            ? airboxSettings.vectorBudget
            : 0,
        targetId: "fdm-multilayer-airbox",
      });
    }

    if (fieldCompatibleTopologyRenderModel) {
      for (const partModel of [
        ...fieldCompatibleTopologyRenderModel.magneticParts,
        ...fieldCompatibleTopologyRenderModel.airboxParts,
      ]) {
        const isAirbox = fieldCompatibleTopologyRenderModel.airboxParts.some(
          (candidate) => candidate.part.id === partModel.part.id,
        );
        const settings = isAirbox
          ? airboxSettings
          : getPartSettings(partModel.part);
        const selection =
          settings.geometryScope === "surface"
            ? partModel.surfaceNodeSelection ?? { nodeIndices: [] }
            : partModel.fullNodeSelection;
        targets.push({
          available: resolveNodeSelectionCount(
            selection,
            fieldCompatibleTopologyRenderModel,
          ),
          requested:
            settings.visible && settings.vectorsVisible
              ? settings.vectorBudget
              : 0,
          targetId: `fem-part:${partModel.part.id}`,
        });
      }
    }

    return resolveViewport3DGlobalVectorAllocation(
      targets,
      maxInteractiveVectorGlyphs,
    );
  }, [
    airboxSettings,
    fdmDomain,
    fdmMultilayerAirboxDomain,
    fdmNativeLayerDomains,
    fdmNativeLayerSettingsById,
    fdmRealizedRegionIds,
    fdmSettings,
    fdmSingleGridAirboxSettings,
    fdmTargetSettingsById,
    fdmTargetViewsResult,
    fieldCompatibleTopologyRenderModel,
    getPartSettings,
    maxInteractiveVectorGlyphs,
  ]);
  const globalFieldRenderOptionsWithPrimaryTargetBuffers = useMemo(
    () =>
      applyViewport3DGlobalVectorAllocationsToFieldRenderOptions(
        fieldRenderOptionsWithPrimaryTargetBuffers,
        fdmTargetVectorAllocations,
      ),
    [
      fdmTargetVectorAllocations,
      fieldRenderOptionsWithPrimaryTargetBuffers,
    ],
  );
  const fdmAirboxPassPlan = resolveFdmAirboxPassPlan(
    fdmSingleGridAirboxSettings ?? { ...fdmSettings, visible: false },
  );
  const fdmAirboxBuildTargetRevision = fdmLaneActive
    ? String(objectVisualizationSnapshot.version)
    : femLaneActive && renderingState?.revision != null
      ? String(renderingState.revision)
      : null;
  const fdmAirboxMaxVectorGlyphs = fdmSingleGridAirboxSettings
    ? fdmTargetVectorAllocations.get("fdm-airbox")?.effective ??
      clampViewport3DInteractiveVectorBudget(
        fdmSingleGridAirboxSettings.vectorBudget,
        maxInteractiveVectorGlyphs,
      )
    : 0;
  const fdmAirboxVectorCarrierSampleLimit = fdmSingleGridAirboxSettings
    ? resolveViewport3DVectorCarrierSampleLimit(
        fdmAirboxMaxVectorGlyphs,
        "fdm-universe-outside-support",
      )
    : 0;
  const fdmAirboxVectorScale = fdmSingleGridAirboxSettings && fdmDomain
    ? resolveFdmVectorGlyphScaleForCellSize(
        fdmDomain.spacing,
        resolveViewport3DFdmGridVectorScale(
          fdmDomain.shape,
          fdmDomain.spacing,
          resolveViewport3DAirboxVectorLengthScale(
            fdmSingleGridAirboxSettings.vectorLengthScale,
          ),
          fdmAirboxMaxVectorGlyphs,
          fdmSingleGridAirboxSettings.geometryScope,
        ),
        resolveFdmVectorGlyphSamplingSpacingScale(
          fdmDomain.totalCells,
          fdmAirboxMaxVectorGlyphs,
        ),
      )
    : 0;
  const fdmAirboxVectorAnchorMode =
    fdmSingleGridAirboxSettings?.vectorCenteringEnabled ? "center" : "tail";
  const fdmAirboxInstanceModelEnabled = Boolean(
      !fdmMultilayerAirboxDomain &&
      fdmUniverseOutsideSupport &&
      fdmSingleGridAirboxSettings?.visible &&
      fdmAirboxPassPlan.needsInactiveCellGeometry,
  );
  const fdmAirboxVectorOnlyBuildInput = useMemo(
    () =>
      fdmAirboxPassPlan.needsVectorAnchors &&
      !fdmAirboxPassPlan.needsPointGeometry &&
      !fdmAirboxPassPlan.needsSurfaceInstances
        ? createFdmVectorOnlyBuildInput({
            cellSelection: "inactive",
            domain: fdmDomain,
            fieldVector: fdmAirboxFieldVector,
            maxSamples: fdmAirboxVectorCarrierSampleLimit,
            realizedRegionIds: fdmRealizedRegionIds,
          })
        : null,
    [
      fdmAirboxPassPlan.needsPointGeometry,
      fdmAirboxPassPlan.needsSurfaceInstances,
      fdmAirboxPassPlan.needsVectorAnchors,
      fdmDomain,
      // eslint-disable-next-line react-hooks/preserve-manual-memoization
      fdmAirboxFieldVector,
      // eslint-disable-next-line react-hooks/preserve-manual-memoization
      fdmAirboxVectorCarrierSampleLimit,
      fdmRealizedRegionIds,
    ],
  );
  const fdmAirboxVectorOnlyBuildEnabled = Boolean(
    fdmAirboxVectorOnlyBuildInput,
  );
  const fdmAirboxBuildEnabled = Boolean(
    fdmAirboxInstanceModelEnabled ||
    fdmAirboxVectorOnlyBuildEnabled,
  );
  const fdmAirboxBuildKey = fdmAirboxBuildEnabled
    ? buildViewport3DFdmCuboidJobKey({
        algorithmVersion: 2,
        domainId: domainMeta.data?.domain_id ?? "shared-domain",
        domainGenerationId: fdmDomainGenerationId,
        fieldRevision: fdmAirboxVectorOnlyBuildEnabled
          ? fdmAirboxFieldRevision == null
            ? null
            : String(fdmAirboxFieldRevision)
          : null,
        quantityId: fdmAirboxVectorOnlyBuildEnabled
          ? fdmAirboxActiveQuantityId
          : null,
        samplingRevision: fdmBuildSamplingRevision,
        scopeId: "airbox",
        scopeKind: "airbox",
        sessionId: "current",
        styleRevision: fdmAirboxVectorOnlyBuildEnabled
          ? [
              "vector-only",
              "carrier=" + fdmAirboxVectorCarrierSampleLimit,
              `max=${fdmAirboxMaxVectorGlyphs}`,
              `geometry=${fdmSingleGridAirboxSettings?.geometryScope ?? "full"}`,
              `lengthScale=${fdmSingleGridAirboxSettings?.vectorLengthScale ?? 1}`,
              `scale=${fdmAirboxVectorScale}`,
              `anchor=${fdmAirboxVectorAnchorMode}`,
              `offset=${fdmSingleGridAirboxSettings?.vectorSurfaceOffsetEnabled ?? false}:${fdmSingleGridAirboxSettings?.vectorSurfaceOffsetScale ?? 0}`,
            ].join("|")
          : `fill=${visualProfile.voxelFillRatio}|airbox=true|lengthScale=${fdmSingleGridAirboxSettings?.vectorLengthScale ?? 1}|scale=${fdmAirboxVectorScale}`,
        topologyRevision: fdmBuildTopologyRevision,
      })
    : null;
  const fdmAirboxBuildState = useFdmCuboidBuildResult({
    buildKey: fdmAirboxBuildKey,
    cellSelection: "inactive",
    domain: fdmDomain,
    enabled: fdmAirboxBuildEnabled,
    groupKey: fdmAirboxBuildEnabled
      ? `fdm-cuboid:session=current:domain=${domainMeta.data?.domain_id ?? "shared-domain"}:airbox`
      : null,
    maxVectorGlyphs: fdmAirboxMaxVectorGlyphs,
    modelFieldVector: null,
    topologyKey: `fdm-airbox:${domainMeta.data?.domain_id ?? "shared-domain"}|generation=${fdmDomainGenerationId}|${fdmBuildSamplingRevision}|topology=${fdmBuildTopologyRevision ?? "none"}`,
    realizedRegionIds: fdmRealizedRegionIds,
    revisionSummary: `domain=${fdmBuildTopologyRevision ?? "none"} membership=${fdmRegionMembership.revision ?? "none"} target=${fdmAirboxBuildTargetRevision ?? "none"}`,
    vectorAnchorMode: fdmAirboxVectorAnchorMode,
    vectorField: fdmAirboxVectorsVisible ? fdmAirboxFieldVector : null,
    vectorGeometryScope: fdmSingleGridAirboxSettings?.geometryScope ?? "full",
    vectorLengthScale: fdmSingleGridAirboxSettings
      ? resolveViewport3DAirboxVectorLengthScale(
          fdmSingleGridAirboxSettings.vectorLengthScale,
        )
      : 0,
    vectorOnly: fdmAirboxVectorOnlyBuildInput,
    vectorScale: fdmAirboxVectorScale,
    vectorSurfaceOffsetEnabled:
      fdmSingleGridAirboxSettings?.vectorSurfaceOffsetEnabled ?? false,
    vectorSurfaceOffsetScale:
      fdmSingleGridAirboxSettings?.vectorSurfaceOffsetScale ?? 0,
    voxelFillRatio: visualProfile.voxelFillRatio,
    voxelMagnitudeThreshold: 0,
    voxelTopography: FDM_AIRBOX_VOXEL_TOPOGRAPHY,
  });
  const fdmAirboxInstanceModel: FdmCuboidInstanceModel | null | undefined =
    fdmAirboxBuildState?.result?.model;
  const fdmAirboxVectorSegments =
    fdmAirboxBuildState?.result?.vectorSegments ?? null;
  const fdmAirboxVectorCellIndices =
    fdmAirboxBuildState?.result?.vectorCellIndices ?? null;
  const fdmTargetViews: readonly Viewport3DFdmTargetRenderView[] = useMemo(
    () =>
      fdmTargetViewsResult.status === "ready"
        ? fdmTargetViewsResult.views.flatMap((view) => {
          const settings = fdmTargetSettingsById.get(view.target.id);
          if (!settings) return [];
          const targetField = resolveViewport3DFdmTargetFieldVectorForTarget({
            primaryFieldQuantityId,
            primaryFieldVector: fdmPrimaryFieldVector,
            quantityId: settings.activeQuantityId,
            targetFieldRequests: targetQuantityFieldRequests,
            targetFieldVectors: targetQuantityFieldVectors.data,
            targetId: view.target.id,
          });
          const targetFieldResponseMetadata =
            targetField?.requestId === "primary-field-vector"
              ? fieldVector.responseMetadata
              : targetField
                ? targetQuantityFieldVectors.responseMetadataByRequestId.get(
                    targetField.requestId,
                  ) ?? null
                : null;
          const targetFieldResponseDomainGenerationId = targetField
            ? resolveTrustedViewport3DResponseDomainGenerationId(
                targetField.fieldVector,
                targetFieldResponseMetadata,
              )
            : null;
          const targetFieldVector = targetField
            ? resolveViewport3DFieldVectorForDomain({
                domain: fdmFieldDomainIdentity,
                fieldVector: targetField.fieldVector,
                responseDomainGenerationId: targetFieldResponseDomainGenerationId,
              })
            : null;
          const targetFieldRevision =
            targetField?.requestId === "primary-field-vector"
              ? fieldVector.payloadRevision ?? fieldVector.revision
              : targetField
                ? targetQuantityFieldVectors.payloadRevision ??
                  targetQuantityFieldVectors.revision
                : null;
          const targetFieldResourceKey =
            targetField?.requestId === "primary-field-vector"
              ? fieldVectorResourceKey
              : targetField?.request
                ? resolveViewport3DFieldVectorResourceKey(
                    targetField.request.quantityId,
                    targetField.request.query,
                  )
                : null;
          const targetFieldRequest =
            targetField?.request ??
            (targetField?.requestId === "primary-field-vector"
              ? primaryFieldRequest
              : null);
          const targetFieldBuffer =
            targetFieldVector && targetFieldRequest
              ? buildViewport3DTargetFieldBuffer({
                  consumers: targetFieldRequest.consumers,
                  domain: fdmFieldDomainIdentity,
                  fieldRevision:
                    targetFieldRevision == null
                      ? null
                      : String(targetFieldRevision),
                  fieldVector: targetFieldVector,
                  query: targetFieldRequest.query,
                  responseDomainGenerationId:
                    targetFieldResponseDomainGenerationId,
                  responseMetadata: targetFieldResponseMetadata,
                  resourceKey: targetFieldResourceKey,
                  sessionIdentity,
                  targetIds: [view.target.id],
                  topologyRevision: fdmBuildTopologyRevision ?? null,
                })
              : null;
          const targetFieldBufferSource: Viewport3DTargetFieldBufferSource | null =
            targetFieldBuffer
              ? {
                  ...targetFieldBuffer,
                  decodedFieldVector: targetFieldBuffer.fieldVector,
                }
              : null;
          const targetSourceFieldBufferId =
            targetFieldBufferSource?.bufferId ?? "none";
          const fieldCompatible = Boolean(
            targetFieldBuffer?.requestIdentityCompatible &&
              targetFieldVector &&
              sameViewport3DQuantityId(
                settings.activeQuantityId,
                targetFieldVector.quantityId,
              ),
          );
          const surfaceMode = fieldCompatible
            ? surfaceColorSourceToColorMode(settings.surfaceColorSource)
            : null;
          const surfaceColorKey = [
            targetSourceFieldBufferId,
            targetFieldRevision ?? "none",
            targetFieldResourceKey ?? "none",
            settings.geometryScope,
            settings.surfaceColorSource,
            surfaceMode ?? "none",
            settings.scalarColorPalette,
            view.target.id,
            view.instanceOrdinals.length,
            view.surfaceInstanceOrdinals.length,
          ].join("|");
          const surfaceColors = memoizeViewport3DFdmTargetSurfaceColors({
            build: () => {
              if (!targetFieldVector || !fdmDomain || !surfaceMode) return null;
              const colors = buildFdmSampledScalarColors(
                targetFieldVector,
                settings.geometryScope === "surface"
                  ? buildViewport3DFdmTargetSurfaceCellIndices(view)
                  : view.cellIndices,
                fdmDomain.totalCells,
                surfaceMode,
                settings.scalarColorPalette,
                undefined,
                fdmDomain.shape,
              );
              return colors
                ? {
                    ...colors,
                    buildKey: surfaceColorKey,
                    sourceFieldBufferId: targetSourceFieldBufferId,
                    sourceResourceKey: targetFieldResourceKey,
                  }
                : null;
            },
            colorKey: surfaceColorKey,
            view,
          });
          const requestedMaxVectors = clampViewport3DInteractiveVectorBudget(
            settings.vectorBudget,
            maxInteractiveVectorGlyphs,
          );
          const maxVectors =
            fdmTargetVectorAllocations.get(`fdm-target:${view.target.id}`)?.effective ??
            requestedMaxVectors;
          const vectorInstanceOrdinals =
            settings.geometryScope === "surface"
              ? view.surfaceInstanceOrdinals
              : view.instanceOrdinals;
          const renderKey = [
            targetSourceFieldBufferId,
            targetFieldRevision ?? "none",
            targetFieldResourceKey ?? "none",
            maxInteractiveVectorGlyphs,
            maxVectors,
            vectorScale,
            JSON.stringify(settings),
          ].join("|");
          return [
            memoizeViewport3DFdmTargetRenderView({
              build: () => {
                if (!targetFieldVector || !fdmDomain) {
                  return {
                    ...view,
                    fieldBuffer: null,
                    fieldVector: null,
                    settings,
                    surfaceColors: null,
                    vectorColors: null,
                    vectorGlyphColors: null,
                    vectorBuildReference: null,
                    vectorSegments: null,
                  };
                }
                const vectorsVisible =
                  settings.visible && settings.vectorsVisible && fieldCompatible;
                const vectorColors = vectorsVisible
                  ? buildFdmSampledScalarColors(
                      targetFieldVector,
                      view.cellIndices,
                      fdmDomain.totalCells,
                      settings.vectorColorMode,
                      settings.scalarColorPalette,
                      undefined,
                      fdmDomain.shape,
                    )
                  : null;
                const vectorCellIndices = vectorsVisible
                  ? buildFdmVectorSampledCellIndices(
                      view.sourceModel,
                      targetFieldVector,
                      maxVectors,
                      vectorInstanceOrdinals,
                      settings.geometryScope,
                    )
                  : null;
                const vectorGlyphColors =
                  vectorColors && vectorCellIndices
                    ? buildFdmSampledScalarColors(
                        targetFieldVector,
                        vectorCellIndices,
                        fdmDomain.totalCells,
                        vectorColors.colorMode,
                        vectorColors.colorPalette,
                        vectorColors.range,
                        fdmDomain.shape,
                      )
                    : null;
                const withSource = (colors: typeof surfaceColors) =>
                  colors
                    ? {
                        ...colors,
                        sourceFieldBufferId: targetSourceFieldBufferId,
                        sourceResourceKey: targetFieldResourceKey,
                      }
                    : null;
                const vectorSegments = vectorsVisible
                  ? buildFdmVectorSegments(
                      view.sourceModel,
                      targetFieldVector,
                      vectorScale,
                      maxVectors,
                      {
                        anchorMode: settings.vectorCenteringEnabled
                          ? "center"
                          : "tail",
                        geometryScope: settings.geometryScope,
                        instanceOrdinals: vectorInstanceOrdinals,
                        vectorLengthScale: settings.vectorLengthScale,
                        surfaceOffsetEnabled:
                          settings.vectorSurfaceOffsetEnabled,
                        surfaceOffsetScale:
                          settings.vectorSurfaceOffsetScale,
                      },
                    )
                  : null;
                const vectorBuildReference = vectorSegments
                  ? {
                      buildKey: `fdm-target-vector:${renderKey}`,
                      fieldBufferId: targetSourceFieldBufferId,
                      fieldRevision: String(targetFieldRevision ?? "none"),
                      groupKey: `fdm-target-vector:${view.target.id}`,
                      resourceKey: targetFieldResourceKey,
                      revisionSummary: renderKey,
                      targetRevision: JSON.stringify(settings),
                      topologyRevision: fdmBuildTopologyRevision ?? "none",
                    }
                  : null;
                return {
                  ...view,
                  fieldBuffer: targetFieldBufferSource,
                  fieldVector: targetFieldVector,
                  settings,
                  surfaceColors,
                  vectorColors: withSource(vectorColors),
                  vectorGlyphColors: withSource(vectorGlyphColors),
                  vectorBuildReference,
                  vectorSegments,
                };
              },
              fieldConsumersCompatible: fieldCompatible,
              renderKey,
              view,
            }),
          ];
        })
        : [],
    [
      fdmBuildTopologyRevision,
      fdmDomain,
      fdmFieldDomainIdentity,
      fdmPrimaryFieldVector,
      fdmTargetSettingsById,
      fdmTargetViewsResult,
      fdmTargetVectorAllocations,
      fieldVector,
      fieldVectorResourceKey,
      maxInteractiveVectorGlyphs,
      primaryFieldQuantityId,
      primaryFieldRequest,
      sessionIdentity,
      targetQuantityFieldRequests,
      targetQuantityFieldVectors,
      vectorScale,
    ],
  );
  const fdmMultilayerVoxelFillRatio = useMemo(
    () => getViewport3DVisualProfile(commandState.visualProfileId).voxelFillRatio,
    [commandState.visualProfileId],
  );
  const fdmMultilayerAirboxRegionIds = useMemo(() => {
    const layout = fdmMultilayerLayout.data;
    if (!airboxCellGeometryRequested || !fdmMultilayerAirboxDomain || !layout?.available) {
      return null;
    }
    if (fdmNativeLayerDomains.length !== layout.layers.length) return null;
    return buildFdmMultilayerAirboxRegionIds(
      fdmMultilayerAirboxDomain,
      fdmNativeLayerDomains.map((domain) => ({
        domain,
        activeMask: resolveFdmNativeLayerActiveMaskForRendering(
          domain,
          layout.layout_revision,
          layout.layers.find((layer) => layer.layer_id === domain.layerId),
          fdmMultilayerLayerActiveMasks.data?.masks.get(domain.layerId) ?? null,
        ),
      })),
    );
  }, [
    airboxCellGeometryRequested,
    fdmMultilayerAirboxDomain,
    fdmMultilayerLayerActiveMasks.data,
    fdmMultilayerLayout.data,
    fdmNativeLayerDomains,
  ]);
  const fdmMultilayerCuboidBuildEntries = useMemo<
    readonly FdmCuboidAsyncBuildEntry[]
  >(() => {
    const layoutGenerationId = safeViewport3DDomainGenerationId(
      fdmMultilayerLayout.data?.domain_generation_id,
    );
    if (!fdmMultilayerLayout.data?.available || !layoutGenerationId) return [];
    const entries: FdmCuboidAsyncBuildEntry[] = fdmNativeLayerDomains.map(
      (domain) => {
        const layerLayout = fdmMultilayerLayout.data?.layers.find(
          (layer) => layer.layer_id === domain.layerId,
        );
        const decodedActiveMask = domain.activeMaskPresent
          ? fdmMultilayerLayerActiveMasks.data?.masks.get(domain.layerId) ?? null
          : null;
        const activeMask = resolveFdmNativeLayerActiveMaskForRendering(
          domain,
          fdmMultilayerLayout.data!.layout_revision,
          layerLayout,
          decodedActiveMask,
        );
        const activeMaskRequired = domain.activeMaskPresent;
        const maskRevision = domain.activeMaskPresent
          ? layerLayout?.active_mask_hash ?? "missing"
          : "dense";
        const settings =
          fdmNativeLayerSettingsById.get(domain.layerId) ?? fdmSettings;
        const request = nativeLayerFieldRequests.get(domain.layerId);
        const requestedField = request
          ? nativeLayerFieldVectors.data?.get(request.requestId) ?? null
          : null;
        const compatibleField = resolveFdmNativeLayerFieldVector(
          domain,
          layoutGenerationId,
          requestedField,
        );
        const fieldVector =
          compatibleField &&
          sameViewport3DQuantityId(
            settings.activeQuantityId,
            compatibleField.quantityId,
          )
            ? compatibleField
            : null;
        const vectorsVisible = Boolean(
          settings.visible && settings.vectorsVisible && fieldVector,
        );
        const requestedMaxVectors = clampViewport3DInteractiveVectorBudget(
          settings.vectorBudget,
          maxInteractiveVectorGlyphs,
        );
        const maxVectors =
          fdmTargetVectorAllocations.get(`fdm-native:${domain.layerId}`)?.effective ??
          requestedMaxVectors;
        const fieldRevision = request
          ? String(
              nativeLayerFieldVectors.payloadRevisionByRequestId.get(
                request.requestId,
              ) ?? "missing",
            )
          : "none";
        const nativeCellGeometryRequired =
          settings.shaderVisible ||
          settings.pointsVisible ||
          settings.wireframeVisible;
        const nativeVectorsOnlyEnabled =
          vectorsVisible && !nativeCellGeometryRequired;
        const targetStyleRevision =
          `visible=${settings.visible}|cells=${nativeCellGeometryRequired}|vectors=${vectorsVisible}|budget=${maxVectors}` +
          `|scale=${settings.vectorLengthScale}|center=${settings.vectorCenteringEnabled}|scope=${settings.geometryScope}`;
        const buildKey = buildViewport3DFdmCuboidJobKey({
          algorithmVersion: 2,
          component: vectorsVisible ? "full" : null,
          domainId: domain.layerId,
          domainGenerationId: layoutGenerationId,
          fieldRevision: vectorsVisible ? fieldRevision : null,
          quantityId: vectorsVisible
            ? resolveCanonicalQuantityId(settings.activeQuantityId)
            : "geometry",
          samplingRevision: `shape=${domain.shape.join("x")}|display=${domain.displayCellCount}|total=${domain.totalCells}|mask=${maskRevision}`,
          scopeId: domain.layerId,
          scopeKind: "fdm_native_layer",
          sessionId: "current",
          styleRevision: `fill=${fdmMultilayerVoxelFillRatio}|vectors=${vectorsVisible}:${maxVectors}:${vectorScale * settings.vectorLengthScale}:${settings.vectorCenteringEnabled}:${settings.geometryScope}`,
          targetVisualizationRevision: targetStyleRevision,
          topologyRevision: `${domain.gridFingerprint ?? "missing"}|layout=${fdmMultilayerLayout.data?.layout_revision ?? "missing"}|mask=${maskRevision}`,
        });
        return {
          buildKey,
          // Vector-only membership filters use active/inactive semantics, not dense geometry.
          cellSelection:
            nativeVectorsOnlyEnabled && activeMask ? "active" : "dense",
          domain: { ...domain, kind: "fdm-grid" as const },
          enabled:
            settings.visible &&
            (nativeCellGeometryRequired || (vectorsVisible && maxVectors > 0)) &&
            (!activeMaskRequired || activeMask !== null),
          groupKey: `fdm-cuboid:session=current:native-layer:${domain.layerId}`,
          id: `native:${domain.layerId}`,
          maxVectorGlyphs: maxVectors,
          modelFieldVector: null,
          nativeActiveMask: activeMask,
          realizedRegionIds: null,
          topologyKey: `fdm-native:${domain.layerId}|generation=${layoutGenerationId}|grid=${domain.gridFingerprint ?? "none"}|layout=${fdmMultilayerLayout.data?.layout_revision ?? "none"}|mask=${maskRevision}`,
          revisionSummary: `carrier=${domain.gridFingerprint ?? "none"} target=${targetStyleRevision} field=${fieldRevision}`,
          vectorAnchorMode: settings.vectorCenteringEnabled ? "center" : "tail",
          vectorField: vectorsVisible ? fieldVector : null,
          vectorGeometryScope: settings.geometryScope,
          vectorLengthScale: settings.vectorLengthScale,
          vectorOnly: nativeVectorsOnlyEnabled
            ? createFdmVectorOnlyBuildInput({
                cellSelection: "active",
                domain: { ...domain, kind: "fdm-grid" as const },
                fieldVector,
                maxSamples: maxVectors,
                nativeActiveMask: activeMask,
                realizedRegionIds: null,
              })
            : null,
          vectorScale: resolveViewport3DFdmGridVectorScale(
            domain.shape,
            domain.spacing,
            settings.vectorLengthScale,
            maxVectors,
            settings.geometryScope,
          ),
          vectorSurfaceOffsetEnabled:
            settings.vectorSurfaceOffsetEnabled ?? false,
          vectorSurfaceOffsetScale: settings.vectorSurfaceOffsetScale ?? 0,
          voxelFillRatio: fdmMultilayerVoxelFillRatio,
          voxelMagnitudeThreshold: 0,
          voxelTopography: FDM_AIRBOX_VOXEL_TOPOGRAPHY,
        };
      },
    );
    if (fdmMultilayerAirboxDomain && airboxSettings.visible) {
      const fieldVector = resolveFdmMultilayerAirboxFieldVector(
        fdmMultilayerAirboxDomain,
        fdmMultilayerAirboxField.data,
        airboxSettings.activeQuantityId,
      );
      const vectorsVisible = Boolean(
        airboxSettings.vectorsVisible && fieldVector,
      );
      const requestedMaxVectors = clampViewport3DInteractiveVectorBudget(
        airboxSettings.vectorBudget,
        maxInteractiveVectorGlyphs,
      );
      const maxVectors =
        fdmTargetVectorAllocations.get("fdm-multilayer-airbox")?.effective ??
        requestedMaxVectors;
      const airboxFieldEnabled = !fdmMultilayerAirboxDomain.geometryOnly;
      const airboxFieldRevision = airboxFieldEnabled
        ? String(fdmMultilayerAirboxField.payloadRevision ?? "missing")
        : "not-requested";
      const airboxVectorScale = resolveViewport3DFdmGridVectorScale(
        fdmMultilayerAirboxDomain.shape,
        fdmMultilayerAirboxDomain.spacing,
        airboxSettings.vectorLengthScale,
        maxVectors,
        airboxSettings.geometryScope,
      );
      const airboxCellGeometryReady = fdmMultilayerAirboxRegionIds !== null;
      const airboxMembershipRevision = airboxCellGeometryReady
        ? fdmMultilayerLayout.data.layers
            .map((layer) => layer.active_mask_hash ?? layer.native_grid_fingerprint)
            .join("|")
        : "none";
      const airboxStyleRevision =
        `visible=${airboxSettings.visible}|cells=${airboxCellGeometryReady}|vectors=${vectorsVisible}|budget=${maxVectors}` +
        `|scale=${airboxSettings.vectorLengthScale}|center=${airboxSettings.vectorCenteringEnabled}` +
        `|scope=${airboxSettings.geometryScope}`;
      const airboxVectorsOnlyEnabled =
        vectorsVisible && !airboxCellGeometryReady;
      entries.push({
        buildKey: buildViewport3DFdmCuboidJobKey({
          algorithmVersion: 2,
          component: vectorsVisible && airboxFieldEnabled ? "full" : null,
          domainId: "fdm-multilayer-airbox",
          domainGenerationId: layoutGenerationId,
          fieldRevision:
            vectorsVisible && airboxFieldEnabled ? airboxFieldRevision : null,
          quantityId: vectorsVisible && airboxFieldEnabled
            ? resolveCanonicalQuantityId(airboxSettings.activeQuantityId)
            : "geometry",
          samplingRevision: `${fdmMultilayerAirboxDomain.geometryRevision}|display=${fdmMultilayerAirboxDomain.displayCellCount}|total=${fdmMultilayerAirboxDomain.totalCells}|membership=${airboxMembershipRevision}`,
          scopeId: "airbox",
          scopeKind: "airbox",
          sessionId: "current",
          styleRevision: `fill=${fdmMultilayerVoxelFillRatio}|vectors=${vectorsVisible}:${maxVectors}:${airboxVectorScale}:${airboxSettings.vectorCenteringEnabled}`,
          targetVisualizationRevision: airboxStyleRevision,
          topologyRevision: airboxFieldEnabled
            ? fdmMultilayerAirboxDomain.carrierFingerprint
            : null,
        }),
        cellSelection: airboxCellGeometryReady ? "inactive" : "all",
        domain: {
          ...fdmMultilayerAirboxDomain,
          kind: "fdm-grid" as const,
          geometryOnly: fdmMultilayerAirboxDomain.geometryOnly && !airboxCellGeometryReady,
        },
        enabled: airboxCellGeometryReady || (vectorsVisible && maxVectors > 0),
        groupKey: "fdm-cuboid:session=current:multilayer-airbox",
        id: "airbox",
        maxVectorGlyphs: maxVectors,
        topologyKey: `fdm-multilayer-airbox:${fdmMultilayerAirboxDomain.geometryRevision}|generation=${layoutGenerationId}|membership=${airboxMembershipRevision}`,
        realizedRegionIds: fdmMultilayerAirboxRegionIds,
        revisionSummary: `${fdmMultilayerAirboxDomain.geometryOnly ? "geometry-preview" : `carrier=${fdmMultilayerAirboxDomain.carrierFingerprint}`} target=${airboxStyleRevision} field=${airboxFieldRevision}`,
        vectorAnchorMode: airboxSettings.vectorCenteringEnabled ? "center" : "tail",
        vectorField: vectorsVisible ? fieldVector : null,
        vectorGeometryScope: airboxSettings.geometryScope,
        vectorLengthScale: airboxSettings.vectorLengthScale,
        vectorOnly: airboxVectorsOnlyEnabled
          ? createFdmVectorOnlyBuildInput({
              cellSelection: "all",
              domain: { ...fdmMultilayerAirboxDomain, kind: "fdm-grid" as const },
              fieldVector,
              maxSamples: maxVectors,
              membershipAdmission: "full-domain",
              realizedRegionIds: null,
            })
          : null,
        vectorScale: airboxVectorScale,
        vectorSurfaceOffsetEnabled:
          airboxSettings.vectorSurfaceOffsetEnabled ?? false,
        vectorSurfaceOffsetScale: airboxSettings.vectorSurfaceOffsetScale ?? 0,
        voxelFillRatio: fdmMultilayerVoxelFillRatio,
        voxelMagnitudeThreshold: 0,
        voxelTopography: FDM_AIRBOX_VOXEL_TOPOGRAPHY,
      });
    }
    return entries;
  }, [
    airboxSettings,
    fdmMultilayerAirboxDomain,
    fdmMultilayerAirboxRegionIds,
    fdmMultilayerAirboxField.data,
    fdmMultilayerAirboxField.payloadRevision,
    fdmMultilayerLayout.data,
    fdmMultilayerLayerActiveMasks.data,
    fdmNativeLayerDomains,
    fdmNativeLayerSettingsById,
    fdmSettings,
    fdmTargetVectorAllocations,
    maxInteractiveVectorGlyphs,
    nativeLayerFieldRequests,
    nativeLayerFieldVectors.data,
    nativeLayerFieldVectors.payloadRevisionByRequestId,
    vectorScale,
    fdmMultilayerVoxelFillRatio,
  ]);
  const fdmMultilayerCuboidBuildResults = useFdmCuboidBuildResults(
    fdmMultilayerCuboidBuildEntries,
  );
  const fdmMultilayerAirboxBuildState =
    fdmMultilayerCuboidBuildResults.get("airbox") ?? null;
  const fdmMultilayerAirboxFieldResourceKey = fdmMultilayerAirboxDomain
    && !fdmMultilayerAirboxDomain.geometryOnly
    ? resolveViewport3DFieldVectorResourceKey(
        fdmMultilayerAirboxFieldRequest.quantityId,
        fdmMultilayerAirboxFieldRequest.query,
      )
    : null;
  const fdmNativeLayerViews = useMemo<readonly FdmNativeLayerRenderView[]>(
    () => {
      const layout = fdmMultilayerLayout.data;
      const layoutGenerationId = safeViewport3DDomainGenerationId(
        layout?.domain_generation_id,
      );
      if (!layout?.available || !layoutGenerationId) return [];

      return fdmNativeLayerDomains.map((domain) => {
        const target = targetForFdmNativeLayer(
          domain.layerId,
          domain.magnetName,
        );
        const settings =
          fdmNativeLayerSettingsById.get(domain.layerId) ?? fdmSettings;
        const request = nativeLayerFieldRequests.get(domain.layerId);
        const requestedField = request
          ? nativeLayerFieldVectors.data?.get(request.requestId) ?? null
          : null;
        const compatibleField = resolveFdmNativeLayerFieldVector(
          domain,
          layoutGenerationId,
          requestedField,
        );
        const fieldVector =
          compatibleField &&
          sameViewport3DQuantityId(
            settings.activeQuantityId,
            compatibleField.quantityId,
          )
            ? compatibleField
            : null;
        const buildResult = fdmMultilayerCuboidBuildResults.get(
          `native:${domain.layerId}`,
        )?.result;
        const model = buildResult?.model ?? null;
        const surfaceMode =
          model && fieldVector
            ? surfaceColorSourceToColorMode(settings.surfaceColorSource)
            : null;
        const surfaceColorKey = [
          "native-layer",
          domain.layerId,
          request?.requestId ?? "none",
          request
            ? String(
                nativeLayerFieldVectors.payloadRevisionByRequestId.get(
                  request.requestId,
                ) ?? "missing",
              )
            : "none",
          model?.membershipRevision ?? "none",
          settings.activeQuantityId,
          settings.surfaceColorSource,
          surfaceMode ?? "none",
          settings.scalarColorPalette,
        ].join("|");
        const surfaceColors = memoizeViewport3DFdmSurfaceColors({
          build: () => {
            if (!model || !fieldVector || !surfaceMode) return null;
            const colors = buildFdmSampledScalarColors(
              fieldVector,
              model.cellIndices,
              domain.totalCells,
              surfaceMode,
              settings.scalarColorPalette,
            );
            return colors ? { ...colors, buildKey: surfaceColorKey } : null;
          },
          colorKey: surfaceColorKey,
          owner: domain,
        });
        const vectorBuffers = resolveFdmVectorOnlyRenderBuffers({
          buildResult,
          fieldAvailable: Boolean(fieldVector),
          layerVisible: settings.visible,
          vectorsEnabled: settings.vectorsVisible,
        });
        const vectorsVisible = vectorBuffers.vectorsVisible;
        const vectorCellIndices = vectorBuffers.vectorCellIndices;
        const vectorGlyphColors =
          vectorsVisible && vectorCellIndices
            ? buildFdmSampledScalarColors(
                fieldVector,
                vectorCellIndices,
                domain.totalCells,
                settings.vectorColorMode,
                settings.scalarColorPalette,
              )
            : null;
        const vectorSegments = vectorBuffers.vectorSegments;

        return {
          domain,
          fieldVector,
          model,
          settings,
          surfaceColors,
          target,
          vectorGlyphColors,
          vectorSegments,
        };
      });
    },
    [
      fdmMultilayerLayout.data,
      fdmNativeLayerDomains,
      fdmNativeLayerSettingsById,
      fdmSettings,
      fdmMultilayerCuboidBuildResults,
      nativeLayerFieldRequests,
      nativeLayerFieldVectors.data,
      nativeLayerFieldVectors.payloadRevisionByRequestId,
    ],
  );
  const fdmMultilayerAirboxView = useMemo<FdmMultilayerAirboxRenderView | null>(() => {
    if (!fdmMultilayerAirboxDomain || !airboxSettings.visible) return null;
    const buildResult = fdmMultilayerAirboxBuildState?.result ?? null;
    const model = buildResult?.model ?? null;
    const compatibleField = resolveFdmMultilayerAirboxFieldVector(
      fdmMultilayerAirboxDomain,
      fdmMultilayerAirboxField.data,
      airboxSettings.activeQuantityId,
    );
    const requestedField =
      compatibleField &&
      sameViewport3DQuantityId(
        airboxSettings.activeQuantityId,
        compatibleField.quantityId,
      )
        ? compatibleField
        : null;
    const responseDomainGenerationId = requestedField
      ? resolveTrustedViewport3DResponseDomainGenerationId(
          requestedField,
          fdmMultilayerAirboxField.responseMetadata,
        )
      : null;
    const fieldBufferCandidate =
      requestedField && fdmMultilayerAirboxDomain.carrierFingerprint
      ? buildViewport3DTargetFieldBuffer({
          consumers: fdmMultilayerAirboxFieldRequest.consumers,
          domain: {
            discretization: "fdm",
            domainGenerationId: fdmMultilayerAirboxDomain.domainGenerationId,
            gridShape: fdmMultilayerAirboxDomain.shape,
            meshTopologyHash: fdmMultilayerAirboxDomain.carrierFingerprint,
            meshTopologyRevision: null,
            pointCount: fdmMultilayerAirboxDomain.totalCells,
          },
          fieldRevision:
            fdmMultilayerAirboxField.payloadRevision == null
              ? null
              : String(fdmMultilayerAirboxField.payloadRevision),
          fieldVector: requestedField,
          query: fdmMultilayerAirboxFieldRequest.query,
          responseDomainGenerationId,
          responseMetadata: fdmMultilayerAirboxField.responseMetadata,
          resourceKey: fdmMultilayerAirboxFieldResourceKey,
          sessionIdentity,
          targetIds: [AIRBOX_VISUALIZATION_TARGET.id],
          topologyRevision: fdmMultilayerAirboxDomain.carrierFingerprint,
        })
      : null;
    const fieldBuffer: Viewport3DTargetFieldBufferSource | null =
      fieldBufferCandidate?.requestIdentityCompatible &&
      fieldBufferCandidate.domainCompatibility.status !== "mismatch"
        ? {
            ...fieldBufferCandidate,
            decodedFieldVector: fieldBufferCandidate.fieldVector,
          }
        : null;
    const fieldVector = fieldBuffer ? requestedField : null;
    const surfaceMode =
      model && fieldVector
        ? surfaceColorSourceToColorMode(airboxSettings.surfaceColorSource)
        : null;
    const surfaceRange = surfaceMode
      ? resolveAirboxManualColorRange(
          renderingState?.quantity, airboxSettings.activeQuantityId, surfaceMode,
        )
      : null;
    const surfaceColorKey = [
      "multilayer-airbox",
      fieldBuffer?.bufferId ?? "none",
      fdmMultilayerAirboxFieldResourceKey ?? "none",
      String(fdmMultilayerAirboxField.payloadRevision ?? "missing"),
      model?.membershipRevision ?? "none",
      airboxSettings.activeQuantityId,
      airboxSettings.surfaceColorSource,
      surfaceMode ?? "none",
      airboxSettings.scalarColorPalette,
      surfaceRange?.min ?? "auto",
      surfaceRange?.max ?? "auto",
    ].join("|");
    const surfaceColors = memoizeViewport3DFdmSurfaceColors({
      build: () => {
        if (!model || !fieldVector || !fieldBuffer || !surfaceMode) return null;
        const colors = buildFdmSampledScalarColors(
          fieldVector,
          model.cellIndices,
          fdmMultilayerAirboxDomain.totalCells,
          surfaceMode,
          airboxSettings.scalarColorPalette,
          surfaceRange,
        );
        return colors
          ? {
              ...colors,
              buildKey: surfaceColorKey,
              sourceFieldBufferId: fieldBuffer.bufferId,
              sourceResourceKey: fdmMultilayerAirboxFieldResourceKey,
            }
          : null;
      },
      colorKey: surfaceColorKey,
      owner: fdmMultilayerAirboxDomain,
    });
    const vectorBuffers = resolveFdmVectorOnlyRenderBuffers({
      buildResult,
      fieldAvailable: Boolean(fieldBuffer && fieldVector),
      layerVisible: airboxSettings.visible,
      vectorsEnabled: airboxSettings.vectorsVisible,
    });
    const vectorsVisible = vectorBuffers.vectorsVisible;
    const vectorCellIndices = vectorBuffers.vectorCellIndices;
    const vectorGlyphColors =
      vectorsVisible && vectorCellIndices && fieldVector
        ? buildFdmSampledScalarColors(
            fieldVector,
            vectorCellIndices,
            fdmMultilayerAirboxDomain.totalCells,
            airboxSettings.vectorColorMode,
            airboxSettings.scalarColorPalette,
            resolveAirboxManualColorRange(
              renderingState?.quantity,
              airboxSettings.activeQuantityId,
              airboxSettings.vectorColorMode,
            ),
          )
        : null;
    const vectorSegments = vectorBuffers.vectorSegments;
    const vectorBuildReference: Viewport3DVectorBuildReference | null =
      fieldBuffer &&
      fdmMultilayerAirboxDomain.carrierFingerprint &&
      vectorSegments &&
      vectorSegments.length > 0 &&
      fdmMultilayerAirboxBuildState?.buildKey
        ? {
            buildKey: `fdm-multilayer-airbox-vector:${fdmMultilayerAirboxBuildState.buildKey}`,
            fieldBufferId: fieldBuffer.bufferId,
            fieldRevision: String(
              fdmMultilayerAirboxField.payloadRevision ?? "none",
            ),
            groupKey: "fdm-multilayer-airbox-vector:airbox",
            resourceKey: fdmMultilayerAirboxFieldResourceKey,
            revisionSummary: fdmMultilayerAirboxBuildState.buildKey,
            targetRevision:
              `layout=${fdmMultilayerAirboxDomain.layoutRevision}` +
              `|observation=${fdmMultilayerAirboxDomain.observationRevision}`,
            topologyRevision: fdmMultilayerAirboxDomain.carrierFingerprint,
          }
        : null;
    return {
      domain: fdmMultilayerAirboxDomain,
      fieldBuffer,
      fieldVector,
      model,
      settings: airboxSettings,
      surfaceColors,
      target: AIRBOX_VISUALIZATION_TARGET,
      vectorBuildReference,
      vectorGlyphColors,
      vectorSegments,
    };
  }, [
    airboxSettings,
    fdmMultilayerAirboxBuildState,
    fdmMultilayerAirboxDomain,
    fdmMultilayerAirboxField.data,
    fdmMultilayerAirboxField.payloadRevision,
    fdmMultilayerAirboxField.responseMetadata,
    fdmMultilayerAirboxFieldRequest,
    renderingState?.quantity,
    sessionIdentity,
    fdmMultilayerAirboxFieldResourceKey,
  ]);
  const fdmSurfaceColors =
    fdmTargetViews.find((view) => view.surfaceColors)?.surfaceColors ?? null;
  const fdmVectorColors =
    fdmTargetViews.find((view) => view.vectorColors)?.vectorColors ?? null;
  const fdmVectorGlyphColors =
    fdmTargetViews.find((view) => view.vectorGlyphColors)?.vectorGlyphColors ?? null;
  const fdmVectorSegments =
    fdmTargetViews.find((view) => view.vectorSegments)?.vectorSegments ?? null;
  const fdmAirboxVectorColors = useMemo(() => {
    if (!fdmAirboxVectorsVisible || !fdmAirboxFieldVector || !fdmAirboxInstanceModel) {
      return null;
    }
    return buildFdmSampledScalarColors(
      fdmAirboxFieldVector,
      fdmAirboxInstanceModel.cellIndices,
      fdmDomain?.totalCells ?? 0,
      fdmSingleGridAirboxSettings?.vectorColorMode ?? "orientation",
      fdmSingleGridAirboxSettings?.scalarColorPalette ?? "viridis",
    );
  }, [
    // eslint-disable-next-line react-hooks/preserve-manual-memoization
    fdmAirboxFieldVector,
    fdmAirboxInstanceModel,
    fdmAirboxVectorsVisible,
    fdmDomain?.totalCells,
    fdmSingleGridAirboxSettings?.scalarColorPalette,
    fdmSingleGridAirboxSettings?.vectorColorMode,
  ]);
  // eslint-disable-next-line react-hooks/preserve-manual-memoization
  const fdmAirboxVectorGlyphColors = useMemo(() => {
    if (!fdmAirboxVectorColors || !fdmAirboxVectorCellIndices) return null;
    return buildFdmSampledScalarColors(
      fdmAirboxFieldVector,
      fdmAirboxVectorCellIndices,
      fdmDomain?.totalCells ?? 0,
      fdmAirboxVectorColors.colorMode,
      fdmAirboxVectorColors.colorPalette,
      fdmAirboxVectorColors.range,
    );
  }, [
    // eslint-disable-next-line react-hooks/preserve-manual-memoization
    fdmAirboxFieldVector,
    fdmAirboxVectorCellIndices,
    fdmAirboxVectorColors,
    fdmDomain?.totalCells,
  ]);
  const fdmAirboxFieldResourceKey = fdmAirboxUsesPrimaryField
    ? fieldVectorResourceKey
    : fdmAirboxFieldRequest
      ? resolveViewport3DFieldVectorResourceKey(
          fdmAirboxActiveQuantityId,
          fdmAirboxFieldRequest.query,
        )
      : null;
  const fdmAirboxFieldBuffer: Viewport3DTargetFieldBufferSource | null =
    fdmAirboxFieldVector && fdmAirboxFieldRequest
      ? (() => {
          const buffer = buildViewport3DTargetFieldBuffer({
            consumers: fdmAirboxFieldRequest.consumers,
            domain: fdmFieldDomainIdentity,
            fieldRevision:
              fdmAirboxFieldRevision == null
                ? null
                : String(fdmAirboxFieldRevision),
            fieldVector: fdmAirboxFieldVector,
            query: fdmAirboxFieldRequest.query,
            responseDomainGenerationId: fdmAirboxResponseDomainGenerationId,
            responseMetadata: fdmAirboxFieldResponseMetadata,
            resourceKey: fdmAirboxFieldResourceKey,
            sessionIdentity,
            targetIds: ["airbox"],
            topologyRevision: fdmBuildTopologyRevision,
          });
          return { ...buffer, decodedFieldVector: buffer.fieldVector };
        })()
      : null;
  const fdmAirboxVectorBuildReference: Viewport3DVectorBuildReference | null =
    fdmAirboxFieldBuffer && fdmAirboxBuildKey
      ? {
          buildKey: `fdm-airbox-vector:${fdmAirboxBuildKey}`,
          fieldBufferId: fdmAirboxFieldBuffer.bufferId,
          fieldRevision: String(fdmAirboxFieldRevision ?? "none"),
          groupKey: "fdm-airbox-vector:fdm-universe-outside-support",
          resourceKey: fdmAirboxFieldResourceKey,
          revisionSummary: fdmAirboxBuildKey ?? "none",
          targetRevision: fdmAirboxBuildTargetRevision ?? "none",
          topologyRevision: fdmBuildTopologyRevision ?? "none",
        }
      : null;
  const fdmAirboxDebugRenderPass: Viewport3DTargetRenderPassModel = {
    fieldBuffer: fdmAirboxFieldBuffer,
    fieldBufferState: fdmAirboxFieldBuffer ? "target-buffer" : "missing",
    surface: {
      degradation: null,
      passId: "airbox:surface",
      scalarColorMode: null,
      scalarColors: null,
    },
    vectors: {
      buildReference: fdmAirboxVectorBuildReference,
      degradation: null,
      passId: "airbox:vector-glyph",
      segments: fdmAirboxVectorSegments,
    },
  };
  const fdmMultilayerAirboxDebugRenderPass: Viewport3DTargetRenderPassModel =
    useMemo(
      () => ({
        fieldBuffer: fdmMultilayerAirboxView?.fieldBuffer ?? null,
        fieldBufferState: fdmMultilayerAirboxView?.fieldBuffer
          ? "target-buffer"
          : "missing",
        surface: {
          degradation: null,
          passId: "airbox:surface",
          scalarColorMode:
            fdmMultilayerAirboxView?.surfaceColors?.colorMode ?? null,
          scalarColors: fdmMultilayerAirboxView?.surfaceColors ?? null,
        },
        vectors: {
          buildReference:
            fdmMultilayerAirboxView?.vectorBuildReference ?? null,
          degradation: null,
          passId: "airbox:vector-glyph",
          segments: fdmMultilayerAirboxView?.vectorSegments ?? null,
        },
      }),
      [fdmMultilayerAirboxView],
    );
  const chunkedScalarColors = useViewport3DChunkedScalarColors({
    buildDomainId: "shared-domain",
    buildSessionId: "current",
    colorModes: primaryFieldRenderOptions.scalarColorModes,
    colorPalette:
      primaryFieldRenderOptions.scalarColorPalette ?? scalarColorPalette,
    enabled:
      primaryFieldRenderOptions.scalarColorsVisible !== false &&
      !analysisFieldIntent,
    fieldRevision: primaryFieldRevision,
    fieldScalarRangesByMode,
    fieldVector: committedFieldVector,
    partFieldVectors: globalFieldRenderOptionsWithPrimaryTargetBuffers.partFieldVectors,
    partTargetFieldBuffers:
      globalFieldRenderOptionsWithPrimaryTargetBuffers.partTargetFieldBuffers,
    partScalarColorModes:
      globalFieldRenderOptionsWithPrimaryTargetBuffers.partScalarColorModes,
    partScalarColorPalettes:
      globalFieldRenderOptionsWithPrimaryTargetBuffers.partScalarColorPalettes,
    partScalarRangesByMode:
      globalFieldRenderOptionsWithPrimaryTargetBuffers.partScalarRangesByMode,
    targetRenderPlans:
      globalFieldRenderOptionsWithPrimaryTargetBuffers.targetRenderPlans,
    targetVisualizationRevision: renderingState?.revision ?? null,
    topology: fieldCompatibleTopologyRenderModel,
    topologyRevision: topology.revision,
  });
  const fieldRenderModelBuildOptions = useMemo(
    () =>
      resolveViewport3DFieldRenderModelBuildOptions({
        complexFieldVector: analysisComplexField,
        fieldRenderOptions: globalFieldRenderOptionsWithPrimaryTargetBuffers,
        fieldVector: committedFieldVector,
        topology: fieldCompatibleTopologyRenderModel,
      }),
    [
      analysisComplexField,
      committedFieldVector,
      fieldCompatibleTopologyRenderModel,
      globalFieldRenderOptionsWithPrimaryTargetBuffers,
    ],
  );
  const analysisOverlayActive = Boolean(analysisOverlay);
  const fieldRenderModel = useMemo(() => {
    const model = measureViewport3DModelBuild(
      "fullmag.viewport3d.buildViewport3DFieldRenderModel",
      () =>
        buildViewport3DFieldRenderModel(
          fieldCompatibleTopologyRenderModel,
          committedFieldVector,
          vectorScale,
          {
            ...fieldRenderModelBuildOptions,
            analysisOverlayActive,
            analysisFieldIntentActive: Boolean(analysisFieldIntent),
            analysisOverlaySourceIdentity,
            buildDomainId: "shared-domain",
            buildSessionId: "current",
            complexFieldVector: analysisComplexField,
            fieldRevision: primaryFieldRevision,
            legacyResponseOverlayActive:
              analysisOverlay?.source === "frequency-response",
            modeOverlay:
              analysisFieldIntent &&
              modeFieldOverlay.phasorAmplitudeMax !== null
                ? {
                    phasorAmplitudeMax: modeFieldOverlay.phasorAmplitudeMax,
                    representation:
                      modeFieldOverlay.metadata?.availableViews[0] ?? "complex",
                  }
                : null,
            scalarRangesByMode: fieldScalarRangesByMode,
            targetVisualizationRevision: renderingState?.revision ?? null,
            topologyRevision: topology.revision,
            wavevectorKf: analysisOverlay?.wavevectorKf,
            cellOrigin: analysisOverlay?.cellOrigin,
            floquetSpatialConvention: analysisOverlay?.floquetSpatialConvention,
            phasorConvention: analysisOverlay?.phasorConvention,
          },
        ),
    );
    return mergeViewport3DFieldScalarColors(
      model,
      chunkedScalarColors.colors,
      vectorColorMode,
      chunkedScalarColors.colorsByPartAndMode,
    );
  }, [
    chunkedScalarColors.colors,
    chunkedScalarColors.colorsByPartAndMode,
    committedFieldVector,
    fieldCompatibleTopologyRenderModel,
    analysisComplexField,
    analysisOverlayActive,
    analysisFieldIntent,
    analysisOverlaySourceIdentity,
    fieldRenderModelBuildOptions,
    fieldScalarRangesByMode,
    primaryFieldRevision,
    renderingState?.revision,
    topology.revision,
    vectorColorMode,
    vectorScale,
    analysisOverlay?.cellOrigin,
    analysisOverlay?.floquetSpatialConvention,
    analysisOverlay?.phasorConvention,
    analysisOverlay?.wavevectorKf,
    analysisOverlay?.source,
    modeFieldOverlay.metadata?.availableViews,
    modeFieldOverlay.phasorAmplitudeMax,
  ]);
  const visualizationDebugTargets = viewportVisualizationTargets.map((target) => {
        const carrierIds = new Set(
          semanticTargetCatalog.byTargetId.get(target.id)?.carrierIds ?? [],
        );
        const fdmTargetView = fdmTargetViews.find(
          (view) => view.target.id === target.id,
        );
        if (fdmTargetView) carrierIds.add(target.id);
        if (
          target.id === AIRBOX_VISUALIZATION_TARGET.id &&
          fdmMultilayerAirboxView
        ) {
          carrierIds.add(fdmMultilayerAirboxView.target.id);
        }
        if (
          target.id === AIRBOX_VISUALIZATION_TARGET.id &&
          fdmUniverseOutsideSupport &&
          !fdmMultilayerAirboxView
        ) {
          carrierIds.add("fdm-universe-outside-support");
        }
        for (const [carrierId, regionTarget] of regionTargetByPartId) {
          if (regionTarget.id === target.id) carrierIds.add(carrierId);
        }
        return {
          carrierIds: Object.freeze([...carrierIds]),
          renderPass:
            target.id === AIRBOX_VISUALIZATION_TARGET.id &&
            fdmMultilayerAirboxView
              ? fdmMultilayerAirboxDebugRenderPass
              : target.id === AIRBOX_VISUALIZATION_TARGET.id &&
                  fdmUniverseOutsideSupport
                ? fdmAirboxDebugRenderPass
              : fdmTargetView
              ? {
                fieldBuffer: fdmTargetView.fieldBuffer,
                fieldBufferState: fdmTargetView.fieldBuffer
                  ? ("target-buffer" as const)
                  : ("missing" as const),
                surface: {
                  degradation: null,
                  passId: `${target.id}:surface`,
                  scalarColorMode: fdmTargetView.surfaceColors?.colorMode ?? null,
                  scalarColors: fdmTargetView.surfaceColors,
                },
                vectors: {
                  buildReference: fdmTargetView.vectorBuildReference ?? null,
                  degradation: null,
                  passId: `${target.id}:vector-glyph`,
                  segments: fdmTargetView.vectorSegments,
                },
                }
              : undefined,
          target,
        };
  });
  const visualizationDebugTopologyByteLength = useMemo(() => {
    const decoded = topology.data;
    if (!decoded) return null;
    return (
      decoded.boundaryFaces.byteLength +
      decoded.boundaryMarkers.byteLength +
      decoded.elementMarkers.byteLength +
      decoded.indices.byteLength +
      (decoded.cellNodes?.byteLength ?? 0) +
      (decoded.cellOffsets?.byteLength ?? 0) +
      (decoded.cellTypes?.byteLength ?? 0) +
      (decoded.facetNodes?.byteLength ?? 0) +
      (decoded.facetOffsets?.byteLength ?? 0) +
      (decoded.facetTypes?.byteLength ?? 0) +
      decoded.positions.byteLength
    );
  }, [topology.data]);
  const selectedLabel = selection.label ?? "No selection";
  const topologyFreshnessStatus = femLaneActive
    ? resolveViewport3DTopologyFreshnessLabel(topologyFreshness)
    : null;
  const status =
    (femLaneActive ? topology.error?.message : null) ??
    (fdmLaneActive ? fdmBuildState?.error?.message : null) ??
    (renderingState?.clip?.enabled ? clipCrossSection.error?.message : null) ??
    (meshQualityOverlayVisible ? meshQualityData.error?.message : null) ??
    fieldVector.error?.message ??
    (fdmLaneActive && fdmFieldCompatibility?.status === "mismatch"
      ? `FDM field degraded: ${fdmFieldCompatibility.reason}`
      : null) ??
    (femLaneActive ? magneticPartFieldVectors.error?.message : null) ??
    (targetQuantityFieldDemandActive
      ? targetQuantityFieldVectors.error?.message
      : null) ??
    (femLaneActive ? airboxFieldVectors.error?.message : null) ??
    scene.error?.message ??
    universe.error?.message ??
    domainMeta.error?.message ??
    (femLaneActive ? sharedDomainManifest.error?.message : null) ??
    visualizationState.error?.message ??
    (femLaneActive ? topologyFreshnessStatus ?? topology.status : null) ??
    "idle";
  const savedViewportStatus = savedSelectionActive
    ? (!savedProjectMatches ? "Open the project that owns this pinned saved field." : null) ??
      savedDatasetResource.error?.message ??
      savedDatasetResource.refreshError?.message ??
      (savedDatasetIdentityMismatch
        ? "Returned dataset does not match the selected immutable identity."
        : null) ??
      savedViewportResources.field.error?.message ??
      savedViewportResources.field.refreshError?.message ??
      savedViewportResources.support.error?.message ??
      savedViewportResources.support.refreshError?.message ??
      savedViewportResources.topology.error?.message ??
      savedViewportResources.topology.refreshError?.message ??
      savedViewportResources.geometry.error?.message ??
      savedViewportResources.geometry.refreshError?.message ??
      (savedViewportResources.eligibility.status === "unavailable"
        ? savedViewportResources.eligibility.reason
        : savedViewportSceneModel && savedViewportResourcesFresh
          ? null
          : "Loading pinned saved viewport data.")
    : null;
  const effectiveViewportFemDomain = savedSelectionActive
    ? savedViewportSceneModel?.femDomain ?? EMPTY_FEM_RENDER_DOMAIN
    : femDomain;
  const effectiveViewportFieldModel = savedSelectionActive
    ? savedFieldRenderModel
    : fieldRenderModel;
  const effectiveViewportTopologyModel = savedSelectionActive
    ? savedViewportSceneModel?.topologyModel ?? null
    : topologyRenderModelForGeometry;
  const effectiveViewportTopology = savedSelectionActive
    ? savedViewportResources.topology.data
    : topology.data;
  const effectiveViewportTopologyRevision = savedSelectionActive
    ? savedViewportSceneModel?.topologyModel?.meshRevision ?? null
    : topology.revision;
  const effectiveViewportTopologyFreshness = savedSelectionActive
    ? savedViewportSceneModel
      ? ("current" as const)
      : ("unknown" as const)
    : topologyFreshness;
  const effectiveViewportQuantityId = savedSelectionActive
    ? savedViewportResources.field.data?.quantityId ?? ""
    : primaryFieldQuantityId;
  const effectiveViewportAvailableQuantityIds = useMemo(
    () => savedSelectionActive
      ? new Set(effectiveViewportQuantityId ? [effectiveViewportQuantityId] : [])
      : availableQuantityIdsForPlanning,
    [availableQuantityIdsForPlanning, effectiveViewportQuantityId, savedSelectionActive],
  );
  const effectiveViewportVectorColorMode = savedSelectionActive &&
      savedViewportResources.field.data?.componentCount === 1
    ? "magnitude"
    : vectorColorMode;
  const effectiveViewportFallbackSettings = useMemo(
    () =>
      savedSelectionActive
        ? {
            ...fallbackSettings,
            renderMode: "surface" as const,
            shaderColorMode: "magnitude" as const,
            shaderVisible: true,
            surfaceColorSource: "magnitude" as const,
            surfaceOpacityPercent: 100,
            viewportColorbarVisible: true,
            visible: true,
            ...savedPresentation?.settings,
            activeQuantityId: effectiveViewportQuantityId,
            surfaceProjectionMode: "raw_nodal" as const,
          }
        : fallbackSettings,
    [effectiveViewportQuantityId, fallbackSettings, savedSelectionActive, savedPresentation?.settings],
  );
  const effectiveViewportPartSettings = useCallback(
    (part: Viewport3DMeshPart) => savedSelectionActive
      ? effectiveViewportFallbackSettings
      : getPartSettings(part),
    [effectiveViewportFallbackSettings, getPartSettings, savedSelectionActive],
  );
  const domainSummary = fdmDomain
    ? formatFdmDisplaySamplingSummary({
        budget: fdmDomain.displayCellBudget,
        displaySamples: fdmDomain.displayCellCount,
        stride: fdmDomain.stride,
        total: fdmDomain.totalCells,
      })
    : `${femDomain.magneticParts.length}+${femDomain.airboxParts.length}`;
  const buildDiagnosticsSnapshotVersion = useSyncExternalStore(
    (onStoreChange) =>
      subscribeViewport3DBuildDiagnostics(() => {
        onStoreChange();
      }),
    getViewport3DBuildDiagnosticsSnapshotVersion,
    getViewport3DBuildDiagnosticsSnapshotVersion,
  );
  const buildFallbackDiagnostics = useMemo(
    () => {
      void buildDiagnosticsSnapshotVersion;
      return getViewport3DBuildFallbackDiagnosticsSnapshot();
    },
    [buildDiagnosticsSnapshotVersion],
  );
  const buildPipelineDiagnostics = useMemo(
    () => {
      void buildDiagnosticsSnapshotVersion;
      return getViewport3DBuildPipelineDiagnosticsSnapshot();
    },
    [buildDiagnosticsSnapshotVersion],
  );
  const diagnostics = buildViewport3DDiagnostics(savedSelectionActive ? {
    airboxPartCount: 0,
    buildFallbacks: buildFallbackDiagnostics,
    cache: getCacheStats(),
    fieldRevision: savedDatasetResource.data?.manifest_object_ref ?? null,
    fieldStatus: savedViewportResourcesFresh ? "ready" : "loading",
    objectCount: 0,
    pipelineDiagnostics: buildPipelineDiagnostics,
    quantityId: effectiveViewportQuantityId,
    targetDiagnostics: effectiveViewportFieldModel?.targetDiagnostics,
    topologyRevision: effectiveViewportTopologyRevision,
    tracker: resourceCounts,
  } : {
    airboxPartCount: femDomain.airboxParts.length,
    airboxFieldVectorPartStates: airboxFieldVectors.partStates,
    buildFallbacks: buildFallbackDiagnostics,
    cache: getCacheStats(),
    dataPlaneIssues,
    displayedRevision: fieldVectorDisplayedRevision,
    fieldDemandDiagnostics,
    fieldPayloadRevision: fieldVector.payloadRevision ?? null,
    fieldRevision: fieldVector.payloadRevision ?? fieldVector.revision,
    fieldRequestedRevision: fieldVector.revision,
    fieldStatus: fieldVector.status,
    manifestCarrierDegradedCount:
      femDomain.renderCarrierDiagnostics?.degradedCarrierCount,
    manifestCarrierKind: femDomain.renderCarrierDiagnostics?.kind,
    manifestCarrierRejectedCount:
      femDomain.renderCarrierDiagnostics?.rejectedCarrierCount,
    objectCount: fdmLaneActive
      ? fdmTargetViews.length
      : femDomain.objectPartIds.size,
    pipelineDiagnostics: buildPipelineDiagnostics,
    preparedRevision: fieldVectorPreparedRevision,
    quantityId: primaryFieldQuantityId,
    receivedRevision: fieldVectorPayloadRevisionString,
    requestedRevision: fieldVectorRevisionString,
    surfaceColorStatus: chunkedScalarColors.status,
    targetDiagnostics: fieldRenderModel?.targetDiagnostics,
    topologyRevision: topology.revision,
    topologyIndexStatus:
      savedSelectionActive || !femLaneActive
        ? "idle"
        : topologyIndexBundle.status === "unavailable"
          ? "error"
          : topologyIndexBundle.status,
    tracker: resourceCounts,
  });
  useEffect(() => {
    publishViewport3DLiveRefreshRevisions({
      displayed: fieldVectorDisplayedRevision,
      prepared: fieldVectorPreparedRevision,
      received: fieldVectorPayloadRevisionString,
      requested: fieldVectorRevisionString,
    });
  }, [
    fieldVectorDisplayedRevision,
    fieldVectorPayloadRevisionString,
    fieldVectorPreparedRevision,
    fieldVectorRevisionString,
  ]);
  const hslReferenceVisible = resolveHslReferenceVisible(
    commandState.widgets.hslReferenceMode,
    vectorColorMode,
  );
  const resourceFrameKey = buildViewport3DResourceFrameKey([
    {
      error: femLaneActive ? topology.error?.message : null,
      id: "topology",
      revision: topology.revision,
      status: femLaneActive ? topology.status : "idle",
    },
    resolveViewport3DResourceFrameState({
      dataAvailable: Boolean(fieldVector.data),
      error: fieldVector.error?.message,
      id: "field-vector",
      materializationState: primaryMagnitudeFieldMeta.data?.state ?? null,
      payloadRevision: fieldVector.payloadRevision ?? null,
      revision: fieldVector.revision,
      status: fieldVector.status,
    }),
    {
      error: fdmLaneActive ? fdmBuildState?.error?.message ?? null : null,
      id: "fdm-cuboid-build",
      revision: fdmLaneActive ? fdmBuildState?.buildKey ?? null : null,
      status: !fdmLaneActive
        ? "idle"
        : fdmBuildState?.status === "pending"
          ? "loading"
          : fdmBuildState?.status ?? "idle",
    },
    resolveViewport3DResourceFrameState({
      dataAvailable:
        !fdmMultilayerAirboxDomain?.geometryOnly &&
        Boolean(fdmMultilayerAirboxField.data),
      error:
        fdmLaneActive && !fdmMultilayerAirboxDomain?.geometryOnly
          ? fdmMultilayerAirboxField.error?.message
          : null,
      id: "fdm-multilayer-airbox-field",
      payloadRevision: fdmLaneActive && !fdmMultilayerAirboxDomain?.geometryOnly
        ? fdmMultilayerAirboxField.payloadRevision ?? null
        : null,
      revision:
        fdmLaneActive && !fdmMultilayerAirboxDomain?.geometryOnly
          ? fdmMultilayerAirboxField.revision
          : null,
      status:
        fdmLaneActive && !fdmMultilayerAirboxDomain?.geometryOnly
          ? fdmMultilayerAirboxField.status
          : "idle",
    }),
    {
      error: fdmLaneActive
        ? fdmMultilayerAirboxBuildState?.error?.message ?? null
        : null,
      id: "fdm-multilayer-airbox-build",
      revision: fdmLaneActive ? fdmMultilayerAirboxBuildState?.buildKey ?? null : null,
      status: !fdmLaneActive
        ? "idle"
        : fdmMultilayerAirboxBuildState?.status === "pending"
          ? "loading"
          : fdmMultilayerAirboxBuildState?.status ?? "idle",
    },
    resolveViewport3DResourceFrameState({
      dataAvailable: Boolean(magneticPartFieldVectors.data?.size),
      error: femLaneActive ? magneticPartFieldVectors.error?.message : null,
      id: "magnetic-part-field-vectors",
      payloadRevision: femLaneActive
        ? magneticPartFieldVectors.payloadRevision ?? null
        : null,
      revision: femLaneActive ? magneticPartFieldVectors.revision : null,
      status: femLaneActive ? magneticPartFieldVectors.status : "idle",
    }),
    resolveViewport3DResourceFrameState({
      dataAvailable:
        targetQuantityFieldDemandActive &&
        Boolean(targetQuantityFieldVectors.data?.size),
      error: targetQuantityFieldDemandActive
        ? targetQuantityFieldVectors.error?.message
        : null,
      id: "target-quantity-field-vectors",
      payloadRevision: targetQuantityFieldDemandActive
        ? targetQuantityFieldVectors.payloadRevision ?? null
        : null,
      revision: targetQuantityFieldDemandActive
        ? targetQuantityFieldVectors.revision
        : null,
      status: targetQuantityFieldDemandActive
        ? targetQuantityFieldVectors.status
        : "idle",
    }),
    resolveViewport3DResourceFrameState({
      dataAvailable: Boolean(airboxFieldVectors.data?.size),
      error: femLaneActive ? airboxFieldVectors.error?.message : null,
      id: "airbox-field-vectors",
      payloadRevision: femLaneActive
        ? airboxFieldVectors.payloadRevision ?? null
        : null,
      revision: femLaneActive ? airboxFieldVectors.revision : null,
      status: femLaneActive ? airboxFieldVectors.status : "idle",
    }),
    {
      error: meshQualityOverlayVisible
        ? meshQualityData.error?.message
        : undefined,
      id: "mesh-quality-data",
      revision: meshQualityOverlayVisible ? meshQualityData.revision : null,
      status: meshQualityOverlayVisible ? meshQualityData.status : "idle",
    },
    {
      error: renderingState?.clip?.enabled
        ? clipCrossSection.error?.message
        : undefined,
      id: "clip-cross-section",
      revision: renderingState?.clip?.enabled ? clipCrossSection.revision : null,
      status: renderingState?.clip?.enabled ? clipCrossSection.status : "idle",
    },
    {
      error: modelRegions.error?.message,
      id: "model-regions",
      revision: modelRegions.revision,
      status: modelRegions.status,
    },
    {
      error: regionMemberships.error?.message,
      id: "region-memberships",
      revision: regionMemberships.revision,
      status: regionMemberships.status,
    },
    {
      error:
        fdmLaneActive
          ? fdmRegionMembership.error?.message ??
            fdmRegionMembershipBinary.error?.message
          : null,
      id: "fdm-region-membership",
      revision: fdmLaneActive
        ? fdmRegionMembershipBinary.revision ?? fdmRegionMembership.revision
        : null,
      status:
        !fdmLaneActive
          ? "idle"
          : fdmRegionMembershipBinary.status === "idle" &&
              fdmRegionMembership.status !== "idle"
            ? fdmRegionMembership.status
            : fdmRegionMembershipBinary.status,
    },
    {
      error: scene.error?.message,
      id: "scene",
      revision: scene.revision,
      status: scene.status,
    },
    {
      error: domainMeta.error?.message,
      id: "domain-meta",
      revision: domainMeta.revision,
      status: domainMeta.status,
    },
    {
      error: femLaneActive ? sharedDomainManifest.error?.message : null,
      id: "shared-domain-manifest",
      revision: femLaneActive ? sharedDomainManifest.revision : null,
      status: femLaneActive ? sharedDomainManifest.status : "idle",
    },
    {
      error: universe.error?.message,
      id: "universe",
      revision: universe.revision,
      status: universe.status,
    },
    {
      error: visualizationState.error?.message,
      id: "visualization-state",
      revision: visualizationState.revision,
      status: visualizationState.status,
    },
    {
      id: "object-visualization",
      revision: objectVisualizationSnapshot.version,
      status: "ready",
    },
  ]);
  const adoptedFdmFieldBuffer =
    fdmTargetViews.find(
      (view) =>
        view.settings.visible &&
        view.fieldBuffer !== null &&
        (view.surfaceColors !== null || view.vectorSegments !== null),
    )?.fieldBuffer ?? fdmAirboxFieldBuffer;
  const visualizationDebugSource = {
    airboxFieldVectorPartStates: savedSelectionActive
      ? EMPTY_VIEWPORT_FDM_PART_STATES
      : airboxFieldVectors.partStates,
    carrierRoles: new Map(
      [...effectiveViewportFemDomain.partsById].map(([carrierId, part]) => [carrierId, part.role]),
    ),
    fieldModel: effectiveViewportFieldModel,
    // Debug/adoption evidence must use the same session-scoped target buffer as
    // the FDM renderer.  A decoded payload fingerprint is not a session identity.
    fullFieldBufferIdentity: !savedSelectionActive && adoptedFdmFieldBuffer
      ? {
          bufferId: adoptedFdmFieldBuffer.bufferId,
          currentDomainGenerationId:
            adoptedFdmFieldBuffer.currentDomainGenerationId ?? null,
          fieldRevision: adoptedFdmFieldBuffer.fieldRevision,
          resourceKey: adoptedFdmFieldBuffer.resourceKey,
          sessionEpoch: sessionIdentity?.sessionEpoch ?? null,
          sessionId: sessionIdentity?.sessionId ?? null,
        }
      : null,
    fullFieldVector: !savedSelectionActive && fdmDomain
      ? fdmFieldVector ?? null
      : null,
    targets: savedSelectionActive ? [] : visualizationDebugTargets,
    topologyByteLength: savedSelectionActive
      ? null
      : visualizationDebugTopologyByteLength,
    visualizationRevision:
      savedSelectionActive
        ? effectiveViewportTopologyRevision == null
          ? null
          : String(effectiveViewportTopologyRevision)
        : renderingState?.revision == null
          ? null
          : String(renderingState.revision),
    webglSharedByteLength: null,
  };
  // A buffer blocked by the domain gate is never drawn; surface why instead
  // of leaving geometry without a field. FDM and FEM keep separate gates.
  const femPartTargetFieldBuffers =
    globalFieldRenderOptionsWithPrimaryTargetBuffers.partTargetFieldBuffers;
  const fieldPresentationFreshness = resolveViewport3DFieldPresentationFreshness({
    dataAvailable: Boolean(fieldVector.data),
    error: fieldVector.error?.message,
    materializationState: primaryMagnitudeFieldMeta.data?.state ?? null,
    status: fieldVector.status,
  });
  const fieldDomainIssue = useMemo<Viewport3DFieldDataIssue | null>(() => {
    let reason: Parameters<typeof describeViewport3DFieldDomainMismatch>[0] | null = null;
    if (fdmLaneActive && fdmFieldCompatibility?.status === "mismatch") {
      reason = fdmFieldCompatibility.reason;
    } else if (femLaneActive && femPartTargetFieldBuffers) {
      for (const buffer of femPartTargetFieldBuffers.values()) {
        if (buffer.domainCompatibility.status === "mismatch") {
          reason = buffer.domainCompatibility.reason;
          break;
        }
      }
    }
    if (!reason) return null;
    return {
      key: `${fieldVectorResourceKey}:domain-mismatch:${reason}`,
      message: describeViewport3DFieldDomainMismatch(reason),
      quantityId: primaryFieldQuantityId,
      resourceKey: fieldVectorResourceKey,
      retry: fieldVector.refetch,
    };
  }, [
    fdmFieldCompatibility,
    fdmLaneActive,
    femLaneActive,
    femPartTargetFieldBuffers,
    fieldVector.refetch,
    fieldVectorResourceKey,
    primaryFieldQuantityId,
  ]);
  // The issue banner is the foreground surface for these failures; the HUD
  // status pill must not repeat them. The FDM mismatch wording differs from the
  // banner text, so it is matched only while the domain issue owns the banner.
  const hudStatus = resolveViewport3DHudStatus({
    bannerOwnedMessages:
      !fieldDataIssue &&
      fieldDomainIssue &&
      fdmLaneActive &&
      fdmFieldCompatibility?.status === "mismatch"
        ? [`FDM field degraded: ${fdmFieldCompatibility.reason}`]
        : [],
    fieldDataIssue: fieldDataIssue ?? fieldDomainIssue,
    status,
  });

  return {
    artifactInspectionDefinitions: !savedSelectionActive && scene.status === "ready" ? scene.data?.antenna_field_solve_stages ?? [] : [],
    airboxSettings,
    availableQuantityIds: effectiveViewportAvailableQuantityIds,
    publishedModelQuantityIds,
    bounds,
    cameraOrthographicScale: effectiveCameraOrthographicScale,
    cameraProjection: effectiveCameraProjection,
    cameraFov: resolveViewport3DCameraFovDegrees(
      cameraResource?.fov_degrees,
    ),
    cameraResource,
    cameraState: effectiveCameraState,
    clip: renderingState?.clip ?? null,
    clipFrameRotationDegrees: 0,
    clipIntersectionMarkers,
    crossSectionFrameClip,
    crossSectionFrameRotationDegrees:
      crossSectionFramePreview?.rotationDegrees ?? 0,
    planarMonitorFramePreview,
    diagnostics,
    domainId: savedSelectionActive ? null : domainMeta.data?.domain_id,
    sessionDiscretization: savedSelectionActive ? null : sessionDiscretization,
    domainSummary: savedSelectionActive
      ? savedViewportSceneModel
        ? savedAntennaSourceModel
          ? savedPresentation?.sourceGeometryVisible === false
            ? "saved sampling domain · antenna geometry hidden"
            : "saved sampling domain · archived antenna source"
          : savedDatasetForViewport?.field.descriptor.quantity_id === "H_ant"
            ? "saved sampling domain · antenna context: " + (savedAntennaSourceContext.status === "ready" ? "surface unavailable" : savedAntennaSourceContext.reason)
            : "saved sampling domain"
        : "saved domain unavailable"
      : domainSummary,
    fallbackSettings: effectiveViewportFallbackSettings,
    fdmLaneActive: savedSelectionActive ? false : fdmLaneActive,
    fdmFieldIdentityCompatible:
      resolveViewport3DFdmFieldIdentityCompatible({
        fdmFieldCompatibilityStatus: fdmFieldCompatibility?.status ?? null,
        fdmLaneActive: savedSelectionActive ? false : fdmLaneActive,
      }),
    fdmDomain: savedSelectionActive ? null : fdmDomain,
    fdmRegionMembership: savedSelectionActive ? null : fdmRegionMembership.data,
    fdmRegionMembershipBinary: savedSelectionActive
      ? null
      : fdmRegionMembershipBinary.data,
    fdmAirboxInstanceModel: savedSelectionActive ? null : fdmAirboxInstanceModel,
    fdmAirboxPassPlan,
    fdmAirboxFieldVector: savedSelectionActive ? null : fdmAirboxFieldVector,
    airboxFieldVectorPartStates: savedSelectionActive
      ? EMPTY_VIEWPORT_FDM_PART_STATES
      : airboxFieldVectors.partStates,
    fdmAirboxVectorBuildReference: savedSelectionActive
      ? null
      : fdmAirboxVectorBuildReference,
    fdmAirboxVectorSegments: savedSelectionActive ? null : fdmAirboxVectorSegments,
    fdmAirboxVectorGlyphColors: savedSelectionActive
      ? null
      : fdmAirboxVectorGlyphColors,
    fdmInstanceModel: savedSelectionActive ? null : fdmInstanceModel,
    fdmUniverseOutsideSupport: savedSelectionActive ? null : fdmUniverseOutsideSupport,
    fdmSettings,
    fdmMultilayerAirboxView: savedSelectionActive ? null : fdmMultilayerAirboxView,
    fdmMultilayerAirboxAuthoredBounds:
      savedSelectionActive || !fdmLaneActive || !fdmMultilayerLayout.data?.available
        ? null
        : universeRootSelectionBounds,
    fdmMultilayerAirboxBuildError:
      savedSelectionActive || !fdmLaneActive
        ? null
        : fdmMultilayerAirboxBuildState?.error?.message ?? null,
    fdmMultilayerAirboxBuildKey:
      savedSelectionActive || !fdmLaneActive
        ? null
        : fdmMultilayerAirboxBuildState?.buildKey ?? null,
    fdmMultilayerAirboxBuildStatus:
      savedSelectionActive || !fdmLaneActive
        ? "idle"
        : fdmMultilayerAirboxBuildState?.status ?? "idle",
    fdmNativeLayerViews: savedSelectionActive ? [] : fdmNativeLayerViews,
    fdmTargetViews: savedSelectionActive ? [] : fdmTargetViews,
    fdmSurfaceColors: savedSelectionActive ? null : fdmSurfaceColors,
    fdmVectorColors: savedSelectionActive ? null : fdmVectorColors,
    fdmVectorGlyphColors: savedSelectionActive ? null : fdmVectorGlyphColors,
    fdmAirboxVectorColors: savedSelectionActive ? null : fdmAirboxVectorColors,
    fdmVectorSegments: savedSelectionActive ? null : fdmVectorSegments,
    femDomain: effectiveViewportFemDomain,
    fieldDataIssue: savedSelectionActive ? null : (fieldDataIssue ?? fieldDomainIssue),
    fieldPresentationFreshness:
      savedSelectionActive || !fieldVectorEnabled ? null : fieldPresentationFreshness,
    fieldRefresh: savedSelectionActive
      ? {
          enabled: false,
          payloadRevision: null,
          quantityId: effectiveViewportQuantityId,
          resourceKey:
            savedViewportResources.field.data?.savedScopeKey ??
            "saved-field-viewport:pending",
          revision: null,
          requestedRevision: null,
          status: "idle" as const,
        }
      : fieldRefresh,
    fieldModel: effectiveViewportFieldModel,
    fieldVector: savedSelectionActive ? null : fdmFieldVector,
    getObjectSettings,
    getPartSettings: effectiveViewportPartSettings,
    getRegionSettings,
    hysteresisReplayGlyphModel: savedSelectionActive
      ? null
      : hysteresisReplayGlyphModel,
    hslReferenceVisible,
    hysteresisReplayTarget: savedSelectionActive ? null : hysteresisReplayTarget,
    magnetizationTexturePreviews: savedSelectionActive
      ? new Map()
      : magnetizationTexturePreviews,
    maxVectorGlyphs: clampViewport3DInteractiveVectorBudget(
      fdmSettings.vectorBudget,
      maxInteractiveVectorGlyphs,
    ),
    meshQualityColors: savedSelectionActive ? null : meshQualityColors,
    meshQualityMetric,
    meshQualityOverlayVisible: savedSelectionActive
      ? false
      : meshQualityOverlayVisible,
    meshRegionOverlayParts: savedSelectionActive ? [] : meshRegionOverlayParts,
    periodicOverlayModel: savedSelectionActive ? null : periodicOverlayModel,
    meshSizeHighlightModel: savedSelectionActive ? null : meshSizeHighlightModel,
    meshQualityRange: savedSelectionActive ? null : meshQualityColors?.range ?? null,
    meshRegionOverlays: savedSelectionActive ? [] : meshRegionOverlays,
    modeCompositionFieldLayers: savedSelectionActive
      ? new Map()
      : modeCompositionFieldLayers,
    modeCompositionId:
      savedSelectionActive
        ? null
        : modeCompositionController.controller.resource?.composition_id ?? null,
    modeCompositionPhaseByLayerId: savedSelectionActive
      ? new Map()
      : modeCompositionPhaseClock.phaseByLayerId,
    primitiveModel: savedSelectionActive ? null : primitiveModel,
    sceneRefetch: savedSelectionActive ? () => undefined : scene.refetch,
    sceneRevision: savedSelectionActive ? null : primitiveModel.sceneRevision,
    sceneStatus: savedSelectionActive ? "idle" : scene.status,
    quantityId: effectiveViewportQuantityId,
    quantityLabel: !savedSelectionActive && analysisOverlay
      ? `Mode · ${analysisOverlay.label}`
      : !savedSelectionActive && !effectiveViewportQuantityId ? "No quantity selected" : effectiveViewportQuantityId,
    regionOverlays: savedSelectionActive ? [] : regionOverlays,
    resourceFrameKey,
    retrySavedAntennaSourceContext: savedSelectionActive &&
      (savedAntennaSourceContext.status === "unavailable" || savedAntennaSourceContext.status === "error")
      ? savedAntennaSourceContext.refetch : null,
    savedViewportActive: savedSelectionActive,
    savedAntennaSourceModel: savedSelectionActive && savedViewportResourcesFresh && savedPresentation?.sourceGeometryVisible !== false ? savedAntennaSourceModel : null,
    savedFieldIdentity: savedSelectionActive ? savedPresentation?.selection.nodeId ?? savedDatasetSelection?.nodeId ?? null : null,
    savedFieldUnit: savedSelectionActive ? savedDatasetResource.data?.field.descriptor.unit ?? null : null,
    selectedLabel,
    artifactPresentationTarget: savedSelectionActive ? null : resolveVisualizationTargetFromSelection(selection),
    selectedObjectId: savedSelectionActive ? null : selectedObjectId,
    selectedRegionId: savedSelectionActive ? null : selectedRegionId,
    selectionBounds: savedSelectionActive ? null : selectionBounds,
    scalarColorPalette,
    savedViewportCamera,
    savedSamplingBounds,
    semanticTargetCatalog: savedSelectionActive
      ? EMPTY_SEMANTIC_RENDER_TARGET_CATALOG
      : semanticTargetCatalog,
    status: savedSelectionActive
      ? savedViewportStatus ?? "Saved field ready · representation not verified"
      : hudStatus,
    renderedMeshRevision: effectiveViewportTopologyModel?.meshRevision ?? null,
    topology: effectiveViewportTopology,
    topologyRevision: effectiveViewportTopologyRevision,
    visualizationDebugSource,
    topologyFreshness: effectiveViewportTopologyFreshness,
    topologyIndexStatus: savedSelectionActive
      ? "idle"
      : topologyIndexBundle.status,
    topologyModel: effectiveViewportTopologyModel,
    vectorColorMode: effectiveViewportVectorColorMode,
    vectorScale: savedSelectionActive ? vectorScale : fdmVectorScale,
    vectorStyle: savedPresentation ? {
      alpha: savedPresentation.settings.vectorAlphaPercent / 100,
      monoColor: savedPresentation.settings.vectorMonoColor,
      thickness: savedPresentation.settings.vectorThickness,
    } : vectorStyle,
    visualizationEffectiveRenderMode,
    visualizationError: savedSelectionActive ? null : visualizationError,
    visualProfileId: commandState.visualProfileId,
    visualizationRevision,
  };
}


function measureViewport3DModelBuild<T>(name: string, build: () => T): T {
  const performanceTarget =
    typeof performance !== "undefined" ? performance : null;
  if (
    !performanceTarget ||
    typeof performanceTarget.mark !== "function" ||
    typeof performanceTarget.measure !== "function"
  ) {
    return build();
  }

  const startMark = `${name}:start`;
  const endMark = `${name}:end`;
  performanceTarget.mark(startMark);
  try {
    return build();
  } finally {
    performanceTarget.mark(endMark);
    try {
      performanceTarget.measure(name, startMark, endMark);
    } catch {
      // Gracefully ignore measurement errors to prevent crashing the UI
    }
    performanceTarget.clearMarks?.(startMark);
    performanceTarget.clearMarks?.(endMark);
  }
}

import { describe, expect, it, vi } from "vitest";

import { MODEL_READINESS_PATH, SIMULATION_PREPARATION_PATH } from "../api/apiPaths";
import { SESSION_STATUS_RESOURCE_KEY } from "../resources/useSessionStatus";

import {
  materializeCurrentLivePreparation,
  requiresSharedDomainMeshForLivePreparation,
} from "./livePreparationMaterialization";

function materializationApi({
  sourceSceneRevision = 17,
  status = "ready" as "ready" | "running",
} = {}) {
  const preparation = vi.fn(async () => ({
    preparation_id: "prep-current",
    status,
  }));
  const scene = vi.fn(async () => ({ revision: 17 }));
  const sharedDomainManifest = vi.fn(async () => ({
    source_scene_revision: sourceSceneRevision,
  }));
  const materializePreparation = vi.fn(async () => ({
    disposition: "accepted" as const,
    preparation_id: "prep-current",
    scene_revision: 17,
    run_id: "run-current",
    plan_fingerprint: `sha256:${"a".repeat(64)}`,
    receipt_sha256: `sha256:${"b".repeat(64)}`,
  }));
  const invalidate = vi.fn();

  return {
    context: {
      api: {
        meshing: { sharedDomainManifest },
        model: { scene },
        simulation: { materializePreparation, preparation },
      },
      resourceData: {
        [SESSION_STATUS_RESOURCE_KEY]: {
          capabilities: { explicit_topology: true },
          domain: { discretization: "fem" },
        },
      },
      resources: { invalidate },
      sessionScopeKey: "session=current&epoch=1&request_scope_epoch=api%3A1",
      source: "test" as const,
    } as never,
    invalidate,
    materializePreparation,
    preparation,
    scene,
    sharedDomainManifest,
  };
}

describe("Live preparation materialization", () => {
  it("uses the declared lane ahead of stale topology flags when deciding mesh requirements", () => {
    const contextFor = (status: Record<string, unknown>) =>
      ({
        resourceData: { [SESSION_STATUS_RESOURCE_KEY]: status },
      }) as never;
    const fdm = {
      capabilities: {
        explicit_topology: true,
        active_lane: { resolved: { discretization: "fdm" } },
      },
      domain: { discretization: "fem" },
    };
    const unresolved = {
      capabilities: { explicit_topology: true, active_lane: null },
      domain: { discretization: "fem" },
    };
    const legacy = {
      capabilities: { explicit_topology: true },
      domain: { discretization: "fdm" },
    };

    expect(requiresSharedDomainMeshForLivePreparation(contextFor(fdm))).toBe(false);
    expect(requiresSharedDomainMeshForLivePreparation(contextFor(unresolved))).toBe(false);
    expect(requiresSharedDomainMeshForLivePreparation(contextFor(legacy))).toBe(true);
  });

  it("accepts a receipt only after matching the current FEM mesh and scene revisions", async () => {
    const fixture = materializationApi();

    const outcome = await materializeCurrentLivePreparation(fixture.context, {
      expectedSceneRevision: 17,
      requireCurrentSharedDomainMesh: true,
    });

    expect(outcome.kind).toBe("materialized");
    expect(fixture.materializePreparation).toHaveBeenCalledWith(
      { preparation_id: "prep-current", scene_revision: 17 },
      { sessionScopeKey: "session=current&epoch=1&request_scope_epoch=api%3A1" },
    );
    expect(fixture.invalidate).toHaveBeenCalledWith(
      SIMULATION_PREPARATION_PATH,
      `sha256:${"b".repeat(64)}`,
    );
  });

  it("fails closed when the shared-domain mesh belongs to another scene revision", async () => {
    const fixture = materializationApi({ sourceSceneRevision: 16 });

    const outcome = await materializeCurrentLivePreparation(fixture.context, {
      expectedSceneRevision: 17,
      requireCurrentSharedDomainMesh: true,
    });

    expect(outcome).toMatchObject({ kind: "rejected" });
    expect(fixture.materializePreparation).not.toHaveBeenCalled();
    expect(fixture.invalidate).not.toHaveBeenCalled();
  });

  it("keeps an already receipted preparation instead of re-planning it", async () => {
    const fixture = materializationApi();
    const receipt = {
      payload_sha256: "c".repeat(64),
      plan_fingerprint: `sha256:${"d".repeat(64)}`,
      preparation_id: "prep-current",
      run_id: "run-current",
      schema_version: "preparation_receipt.v1",
    };
    fixture.preparation.mockResolvedValueOnce({
      preparation_id: "prep-current",
      receipt,
      status: "ready",
    } as never);

    const outcome = await materializeCurrentLivePreparation(fixture.context, {
      expectedSceneRevision: 17,
      requireCurrentSharedDomainMesh: true,
    });

    expect(outcome).toEqual({ kind: "already-prepared", receipt });
    expect(fixture.sharedDomainManifest).toHaveBeenCalled();
    expect(fixture.materializePreparation).not.toHaveBeenCalled();
  });

  it("does not materialize while the Live preparation is still running", async () => {
    const fixture = materializationApi({ status: "running" });

    const outcome = await materializeCurrentLivePreparation(fixture.context);

    expect(outcome).toMatchObject({ kind: "rejected" });
    expect(fixture.scene).not.toHaveBeenCalled();
    expect(fixture.materializePreparation).not.toHaveBeenCalled();
  });
});


describe("Backend-owned source mesh preparation", () => {
  function context(readiness: Record<string, unknown>, sceneRevision: unknown = 17) {
    return {
      resourceData: {
        [SESSION_STATUS_RESOURCE_KEY]: {
          capabilities: { explicit_topology: true },
          domain: { discretization: "fem" },
          resources: { scene_revision: sceneRevision },
        },
        [MODEL_READINESS_PATH]: readiness,
      },
    } as never;
  }
  const ready = {scene_revision: 17, ready_to_run: true, preparation_owns_mesh: true};

  it("uses explicit fresh backend ownership instead of requiring a magnetic mesh", () => {
    expect(requiresSharedDomainMeshForLivePreparation(context(ready))).toBe(false);
  });

  it("accepts the existing retained resource envelope", () => {
    expect(requiresSharedDomainMeshForLivePreparation(context({data: ready}))).toBe(false);
  });

  it.each([
    ["legacy response", {scene_revision: 17, ready_to_run: true}],
    ["blocked model", {...ready, ready_to_run: false}],
    ["stale scene", {...ready, scene_revision: 16}],
    ["explicit mesh requirement", {...ready, preparation_owns_mesh: false}],
    ["invalid ownership", {...ready, preparation_owns_mesh: "true"}],
  ])("preserves the FEM mesh guard for %s", (_name, value) => {
    expect(requiresSharedDomainMeshForLivePreparation(context(value))).toBe(true);
  });

  it("refuses missing scene revision even with ownership", () => {
    expect(requiresSharedDomainMeshForLivePreparation(context(ready, null))).toBe(true);
  });
});

import { MODEL_READINESS_PATH, SIMULATION_PREPARATION_PATH } from "../api/apiPaths";
import { ControlRoomApiError } from "../api/ControlRoomApi";
import type {
  LivePreparationMaterializationResource,
  SimulationPreparationResource,
} from "../api/apiTypes";
import type { CommandContext, CommandResult } from "../commands/commandTypes";
import {
  assertCurrentSessionScope,
  obsoleteSessionResult,
} from "../commands/commandSessionScope";
import { SESSION_STATUS_RESOURCE_KEY } from "../resources/useSessionStatus";
import {
  hasSessionActiveLaneDeclaration,
  resolveSessionAuthoringDiscretization,
} from "../resources/sessionDiscretization";

type JsonRecord = Record<string, unknown>;

type PreparationReceipt = NonNullable<SimulationPreparationResource["receipt"]>;

export type LivePreparationMaterializationOutcome =
  | { kind: "materialized"; resource: LivePreparationMaterializationResource }
  | { kind: "already-prepared"; receipt: PreparationReceipt }
  | { kind: "server-prepares" }
  | { kind: "rejected"; result: CommandResult };

export interface LivePreparationMaterializationOptions {
  expectedSceneRevision?: number | null;
  requireCurrentSharedDomainMesh?: boolean;
}

function asRecord(value: unknown): JsonRecord | null {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value)
    ? (value as JsonRecord)
    : null;
}

function finiteRevision(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function reject(message: string): LivePreparationMaterializationOutcome {
  return { kind: "rejected", result: { message, status: "failed" } };
}

function rejectedSessionResult(
  result: CommandResult,
): LivePreparationMaterializationOutcome {
  return { kind: "rejected", result };
}

function isSha256Fingerprint(value: string): boolean {
  return /^sha256:[0-9a-f]{64}$/.test(value);
}

/** Materialize a receipt only for the current session, scene, and optional mesh revision. */
export async function materializeCurrentLivePreparation(
  context: CommandContext,
  options: LivePreparationMaterializationOptions = {},
): Promise<LivePreparationMaterializationOutcome> {
  const api = context.api;
  if (!api) return reject("Control-room API is unavailable.");

  try {
    assertCurrentSessionScope(context);
    const requestOptions = context.sessionScopeKey
      ? { sessionScopeKey: context.sessionScopeKey }
      : undefined;
    // A geometry-only mesh build (ADR 0074) publishes no live preparation;
    // Compute then prepares its accepted run on the server.
    const preparation: SimulationPreparationResource | null = await api.simulation
      .preparation(requestOptions)
      .catch((error: unknown) => {
        if (error instanceof ControlRoomApiError && error.status === 404) return null;
        throw error;
      });
    const obsoleteAfterPreparation = obsoleteSessionResult(context);
    if (obsoleteAfterPreparation) {
      return rejectedSessionResult(obsoleteAfterPreparation);
    }
    if (
      preparation !== null &&
      (!preparation.preparation_id || preparation.status !== "ready")
    ) {
      return reject(
        `Live preparation is not ready (status: ${preparation.status}).`,
      );
    }

    const scene = await api.model.scene(requestOptions);
    const obsoleteAfterScene = obsoleteSessionResult(context);
    if (obsoleteAfterScene) return rejectedSessionResult(obsoleteAfterScene);
    const sceneRevision = finiteRevision(scene.revision);
    if (sceneRevision === null) {
      return reject("Scene revision is unavailable; refresh the scene and retry.");
    }
    if (
      typeof options.expectedSceneRevision === "number" &&
      options.expectedSceneRevision !== sceneRevision
    ) {
      return reject(
        `Scene changed during preparation: expected revision ${options.expectedSceneRevision}, received ${sceneRevision}. Retry with the current scene.`,
      );
    }

    if (options.requireCurrentSharedDomainMesh) {
      const manifest = await api.meshing.sharedDomainManifest(requestOptions);
      const obsoleteAfterManifest = obsoleteSessionResult(context);
      if (obsoleteAfterManifest) {
        return rejectedSessionResult(obsoleteAfterManifest);
      }
      if (finiteRevision(manifest?.source_scene_revision) !== sceneRevision) {
        return reject(
          "A shared-domain mesh for the current scene revision is required before preparation.",
        );
      }
    }

    if (preparation === null) return { kind: "server-prepares" };

    // A ready preparation that already carries its receipt was published by
    // the accepted preparation lane (for FEM, with native mesh evidence).
    // Materializing it again would re-plan from the scene without that
    // evidence, so Compute proceeds with the accepted plan.
    if (preparation.receipt?.preparation_id === preparation.preparation_id) {
      return { kind: "already-prepared", receipt: preparation.receipt };
    }

    const resource = await api.simulation.materializePreparation(
      {
        preparation_id: preparation.preparation_id,
        scene_revision: sceneRevision,
      },
      requestOptions,
    );
    const obsoleteAfterMaterialization = obsoleteSessionResult(context);
    if (obsoleteAfterMaterialization) {
      return rejectedSessionResult(obsoleteAfterMaterialization);
    }
    if (
      resource.preparation_id !== preparation.preparation_id ||
      resource.scene_revision !== sceneRevision ||
      !isSha256Fingerprint(resource.plan_fingerprint) ||
      !isSha256Fingerprint(resource.receipt_sha256)
    ) {
      return reject(
        "Live preparation returned receipt provenance that does not match the current request.",
      );
    }

    context.resources?.invalidate(
      SIMULATION_PREPARATION_PATH,
      resource.receipt_sha256,
    );
    return { kind: "materialized", resource };
  } catch (error) {
    const obsolete = obsoleteSessionResult(context);
    if (obsolete) return rejectedSessionResult(obsolete);
    return reject(
      error instanceof Error
        ? error.message
        : "Live preparation materialization failed.",
    );
  }
}

export function requiresSharedDomainMeshForLivePreparation(
  context: CommandContext,
): boolean {
  const status = asRecord(context.resourceData?.[SESSION_STATUS_RESOURCE_KEY]);
  const laneStatus = asRecord(status?.data ?? status);
  const capabilities = asRecord(laneStatus?.capabilities);
  const typedStatus =
    laneStatus as Parameters<typeof hasSessionActiveLaneDeclaration>[0];
  const laneDeclared = hasSessionActiveLaneDeclaration(typedStatus);
  const lane = resolveSessionAuthoringDiscretization(typedStatus);
  const requiresMesh = laneDeclared
    ? lane === "fem"
    : capabilities?.explicit_topology === true || lane === "fem";
  if (!requiresMesh) return false;

  const readinessResource = asRecord(context.resourceData?.[MODEL_READINESS_PATH]);
  const readiness = asRecord(readinessResource?.data ?? readinessResource);
  const sceneRevision = finiteRevision(asRecord(laneStatus?.resources)?.scene_revision);
  const preparationOwnsMesh =
    sceneRevision !== null &&
    readiness?.scene_revision === sceneRevision &&
    readiness.ready_to_run === true &&
    readiness.preparation_owns_mesh === true;
  return !preparationOwnsMesh;
}

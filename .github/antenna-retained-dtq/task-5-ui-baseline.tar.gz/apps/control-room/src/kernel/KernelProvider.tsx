"use client";

import { useSavedRunSelection } from "./saved-results/useSavedRun";
import { SavedRunController } from "./saved-results/SavedRunController";
import { openSavedRun } from "./saved-results/openSavedRun";
import { SavedResultsPlaybackController } from "./saved-results/SavedResultsPlaybackController";
import { homeView } from "./layout/homeView";

import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";

import { SESSION_EVENTS_WS_PATH, VISUALIZATION_STATE_PATH } from "./api/apiPaths";
import { planarMonitorFramePreviewStore } from "./workspace/planarMonitorFramePreview";
import type {
  ResourceRevision,
  VisualizationStatePatch,
  VisualizationStateResource,
} from "./api/apiTypes";
import {
  createBinaryDecodeScheduler,
  type BinaryDecodeDiagnosticEvent,
} from "./api/binaryDecodeScheduler";
import { ControlRoomApi, ControlRoomApiError } from "./api/ControlRoomApi";
import {
  resolveControlRoomApiBase,
  resolveControlRoomWebSocketUrl,
} from "./api/apiRuntimeTarget";
import { normalizeQuantityIdOrDefault } from "./api/quantityIds";
import { RequestDiagnosticsController } from "./api/RequestDiagnosticsController";
import { GEOMETRY_LIFECYCLE_COMMANDS } from "./authoring/geometryLifecycleCommandContributions";
import { MAGNETIZATION_TEXTURE_COMMANDS } from "./authoring/magnetization-texture/commands";
import { REGION_COMMANDS } from "./authoring/regionCommandContributions";
import { createCommandContext } from "./commands/commandContext";
import { CommandRegistry } from "./commands/CommandRegistry";
import { createCommandSessionScopeSource } from "./commands/commandSessionScopeSource";
import {
  dispatchShortcutCommand,
} from "./commands/commandShortcuts";
import { CommandDiagnosticsController } from "./commands/CommandDiagnosticsController";
import { CommandFeedbackController } from "./commands/CommandFeedbackController";
import { isMeshBuildConfirmCommandId } from "./authoring/meshBuildConfirmation";
import { EventBus } from "./events/EventBus";
import type { KernelEventMap } from "./events/eventTypes";
import {
  performanceDiagnosticsEnabledFromBrowserConfig,
  type BrowserFullmagConfig,
} from "./browserFullmagConfig";
import {
  DIAGNOSTIC_EVENT_NAMES,
  DiagnosticRecorderController,
} from "./performance/diagnostic-recorder/DiagnosticRecorderController";
import { recordDiagnosticBrowserSnapshot } from "./performance/diagnostic-recorder/diagnosticBrowserSnapshot";
import { installDiagnosticConsoleCapture } from "./performance/diagnostic-recorder/diagnosticConsoleCapture";
import { resolveDiagnosticRecorderConfig } from "./performance/diagnostic-recorder/diagnosticRecorderConfig";
import { KernelContext } from "./KernelContext";
import { LayoutController } from "./layout/LayoutController";
import { SHELL_COMMANDS } from "./layout/shellCommands";
import { useDomainSetupNavigation } from "./layout/domainSetupNavigation";
import { ModuleRegistry } from "./module/ModuleRegistry";
import { startBrowserActivityDiagnostics } from "./performance/browserActivityDiagnostics";
import { startPerformanceMeasureDiagnostics } from "./performance/performanceMeasureDiagnostics";
import { installPerformanceMeasureGuard } from "./performance/performanceMeasureGuard";
import { RealtimeClient } from "./realtime/RealtimeClient";
import { RealtimeConnectionController } from "./realtime/RealtimeConnectionController";
import { RealtimeInvalidationBridge } from "./realtime/RealtimeInvalidationBridge";
import { useSimulationStartupOverlayVisibility } from "./layout/SimulationStartupOverlay";
import { ResourceInvalidationController } from "./resources/ResourceInvalidationController";
import { sharedResourceRuntimeStore } from "./resources/ResourceRuntimeStore";
import { resourceRuntimeKeyForClientScope } from "./resources/resourceClientScope";
import {
  acquireViewport3DWorkerRuntime,
  getViewport3DWorkerRuntimeSnapshot,
  viewport3DFieldUpdateHoldActive,
} from "@/modules/viewport-3d/public";
import {
  createViewport3DInactiveResourcePauseController,
} from "./resources/inactiveViewportResourcePolicy";
import {
  createHiddenDocumentResourcePauseController,
  createHiddenInstanceTabResourcePauseController,
} from "./resources/hiddenInstanceTabResourcePolicy";
import { listenForInstanceTabVisibility } from "./layout/instanceTabVisibility";
import { useRuntimeCommandControlResourceData } from "./resources/studyRuntimeResources";
import { confirmedSessionResourceIdentity, sessionRequestScopeKey, sessionScopedResourceKey, type SessionResourceIdentity } from "./resources/sessionResourceIdentity";
import { useSessionResourceIdentity } from "./resources/useSessionStatus";
import { useSessionCollection } from "./resources/useSessionCollection";
import { isProjectWorkspaceCommand } from "./commands/projectWorkspaceCommandPolicy";
import { STUDY_RUNTIME_COMMANDS } from "./runtime/studyRuntimeCommandContributions";
import { SelectionController } from "./selection/SelectionController";
import type { KernelApi } from "./types";
import { ChartViewportHandoffController } from "./visualization/ChartViewportHandoffController";
import { CameraRegistryController } from "./visualization/CameraRegistryController";
import { AnalysisFieldOverlayController } from "./visualization/AnalysisFieldOverlayController";
import { ModeCompositionController } from "./visualization/ModeCompositionController";
import { ANALYSIS_FIELD_OVERLAY_COMMANDS } from "./visualization/analysisFieldOverlayCommandContributions";
import { POSTPROCESSING_DEFINITION_COMMANDS } from "./analysis-modules/postprocessingCommandContributions";
import {
  ObjectVisualizationController,
  type VisualizationTargetPatch,
  type VisualizationTargetRef,
} from "./visualization/ObjectVisualizationController";
import { VisualizationDebugController } from "./visualization/VisualizationDebugController";
import { VisualizationRegistrySyncController } from "./visualization/VisualizationRegistrySyncController";
import { VISUALIZATION_TARGET_COMMANDS } from "./visualization/visualizationCommandContributions";
import { ObjectMoveToolController } from "./authoring/ObjectMoveToolController";
import { AuthoringHistoryController } from "./authoring/AuthoringHistoryController";
import { ObjectEditSessionController } from "./authoring/object-edit/ObjectEditSessionController";
import type { GeometryObjectDraft } from "./authoring/object-edit/objectEditTypes";
import { PendingFormRegistry } from "./authoring/PendingFormRegistry";
import { ProjectDocumentController } from "./persistence/ProjectDocumentController";
import { RunOutcomeConnector } from "./persistence/RunOutcomeConnector";
import { resolveControlRoomModules } from "@/modules";

installPerformanceMeasureGuard();

interface KernelProviderProps {
  children: ReactNode;
}

function createKernel(): KernelApi {
  const bus = new EventBus<KernelEventMap>();
  const diagnostics = new RequestDiagnosticsController();
  const browserConfig =
    typeof window === "undefined"
      ? undefined
      : (window as Window & { __FULLMAG_CONFIG__?: BrowserFullmagConfig })
          .__FULLMAG_CONFIG__;
  const diagnosticRecorder = new DiagnosticRecorderController({
    config: resolveDiagnosticRecorderConfig(browserConfig),
    diagnostics,
  });
  diagnosticRecorder.mark(DIAGNOSTIC_EVENT_NAMES.kernelCreated);
  const commandDiagnostics = new CommandDiagnosticsController();
  const binaryDecodeScheduler = createBinaryDecodeScheduler({
    onEvent: (event) => {
      recordBinaryDecodeDiagnostic(diagnosticRecorder, event);
    },
  });
  const api = new ControlRoomApi({
    baseUrl: resolveControlRoomApiBase(),
    binaryDecodeScheduler,
    diagnostics,
  });
  const savedResultsPlayback = new SavedResultsPlaybackController();
  const savedRun = new SavedRunController();
  const projectDocument = new ProjectDocumentController(api);
  const commands = new CommandRegistry();
  commands.attachSessionScopeSource(
    createCommandSessionScopeSource(
      sharedResourceRuntimeStore,
      api.resourceCacheScope,
    ),
  );
  commands.attach(bus);
  commands.attachDiagnostics(commandDiagnostics);
  const commandFeedback = new CommandFeedbackController(bus, {
    getSessionScopeKey: () => commands.getSessionScopeKey(),
    // The mesh build dialog observes and presents mesh run outcomes itself.
    isRunOutcomeSelfPresented: isMeshBuildConfirmCommandId,
    subscribeSessionScope: (listener) => commands.subscribeSessionScope(listener),
  });

  const modules = new ModuleRegistry();
  const resources = new ResourceInvalidationController(bus);
  const authoringHistory = new AuthoringHistoryController(api, resources);
  const objectEditSession = new ObjectEditSessionController<GeometryObjectDraft>();
  const pendingForms = new PendingFormRegistry();
  authoringHistory.subscribe(() => commands.refresh());
  pendingForms.subscribe(() => commands.refresh());
  objectEditSession.subscribe(() => commands.refresh());
  const selection = new SelectionController(bus);
  const layout = new LayoutController(bus);
  const objectMoveTool = new ObjectMoveToolController();
  const chartViewportHandoff = new ChartViewportHandoffController();
  bus.on("session:status-changed", ({ status }) => {
    if (status === "idle") {
      chartViewportHandoff.cancel("Session closed.");
      objectMoveTool.clear();
      authoringHistory.clear();
      objectEditSession.clear();
      pendingForms.clear();
    } else if (status !== "connected") {
      chartViewportHandoff.cancel("Session connection interrupted.");
      objectMoveTool.clear();
    }
  });
  const cameraRegistry = new CameraRegistryController({
    api: api.visualization,
    getSessionScopeKey: () => commands.getSessionScopeKey() ?? null,
  });
  cameraRegistry.setSessionScopeKey(null);
  const analysisFieldOverlay = new AnalysisFieldOverlayController();
  const modeComposition = new ModeCompositionController({
    getActiveModeComposition: (options) =>
      api.visualization.modeComposition.active(options),
    patchActiveModeComposition: (patch, options) =>
      api.visualization.modeComposition.patch(patch, options),
  });
  const visualization = new ObjectVisualizationController();
  const visualizationDebug = new VisualizationDebugController();
  const visualizationSync = new VisualizationRegistrySyncController({
    api: api.visualization,
    resourceCacheScope: api.resourceCacheScope,
    resources,
    onAcknowledgedTargetPatches: (state, _targetIds, transactionIds) =>
      visualization.acknowledgePendingTargetPatches(state, transactionIds),
    onRejectedTargetPatches: (targetIds, transactionIds) =>
      visualization.rejectPendingTargetPatches(targetIds, transactionIds),
  });
  const realtime = new RealtimeInvalidationBridge(resources, {
    bus,
    shouldSuppressInvalidation: (resourceKey, revision) =>
      visualizationSync.shouldSuppressInvalidation(resourceKey, revision) ||
      cameraRegistry.shouldSuppressInvalidation(resourceKey, revision),
  });
  const realtimeConnection = new RealtimeConnectionController();

  for (const cmd of SHELL_COMMANDS) {
    commands.register(cmd);
  }
  for (const cmd of GEOMETRY_LIFECYCLE_COMMANDS) {
    commands.register(cmd);
  }
  for (const cmd of STUDY_RUNTIME_COMMANDS) {
    commands.register(cmd);
  }
  for (const cmd of MAGNETIZATION_TEXTURE_COMMANDS) {
    commands.register(cmd);
  }
  for (const cmd of REGION_COMMANDS) {
    commands.register(cmd);
  }
  for (const cmd of VISUALIZATION_TARGET_COMMANDS) {
    commands.register(cmd);
  }
  for (const cmd of ANALYSIS_FIELD_OVERLAY_COMMANDS) {
    commands.register(cmd);
  }
  for (const cmd of POSTPROCESSING_DEFINITION_COMMANDS) {
    commands.register(cmd);
  }

  commands.register({
    id: "workspace.open-results-folder", title: "Open Saved Results",
    group: "workspace-document", category: "File", scope: "global",
    isEnabled: () => true,
    run: async (context) => {
      const input = context.input as {itemId?: string; name?: string} | undefined;
      if (!input?.itemId || !input.name) return {status: "failed", message: "Select a result folder first."};
      if (objectEditSession.getSnapshot().dirty) {
        return {status: "failed", message: "Apply or cancel the current object edit before opening saved results."};
      }
      const transition = await pendingForms.prepareTransition({applyPendingChanges: false});
      try {
        await api.workspace.playback(input.itemId);
        transition.assertCurrent();
        if (objectEditSession.getSnapshot().dirty) {
          return {status: "failed", message: "Object edits changed while opening saved results."};
        }
        savedResultsPlayback.open({itemId: input.itemId, name: input.name});
        homeView.close();
        return {status: "completed", message: "Saved results opened read only."};
      } finally {
        transition.release();
      }
    },
  });

  commands.register({
    id: "workspace.open-saved-run", title: "Open Saved Run", group: "workspace-document",
    category: "File", scope: "global", requiresInput: true, isEnabled: () => true,
    run: async (context) => {
      const input = context.input as { projectId?: string; runId?: string } | undefined;
      if (!input?.projectId || !input.runId) return { status: "failed", message: "Project ID and run ID are required." };
      await openSavedRun({ savedRun, api, pendingForms, objectEditSession, savedResultsPlayback, visualization, selection, layout }, { projectId: input.projectId, runId: input.runId });
      return { status: "completed", message: "Saved run opened read only." };
    },
  });

  // Register modules and auto-register their contributed commands.
  for (const manifest of resolveControlRoomModules()) {
    modules.register(manifest);
    if (manifest.contributes?.commands) {
      for (const cmd of manifest.contributes.commands) {
        commands.register(cmd);
      }
    }
  }

  return {
    savedRun,
    savedResultsPlayback,
    api,
    analysisFieldOverlay,
    authoringHistory,
    objectEditSession,
    bus,
    chartViewportHandoff,
    cameraRegistry,
    commandDiagnostics,
    commandFeedback,
    commands,
    diagnostics,
    diagnosticRecorder,
    layout,
    modeComposition,
    modules,
    objectMoveTool,
    pendingForms,
    projectDocument,
    realtime,
    realtimeConnection,
    resources,
    selection,
    visualization,
    visualizationDebug,
    visualizationSync,
  };
}

function recordBinaryDecodeDiagnostic(
  diagnosticRecorder: DiagnosticRecorderController,
  event: BinaryDecodeDiagnosticEvent,
): void {
  diagnosticRecorder.record({
    byteLength: event.payloadBytes,
    detail: {
      decoderKind: event.kind,
      errorName: event.errorName,
      outcome: event.outcome,
      path: event.path,
      queueWaitMs: event.queueWaitMs,
      worker: event.worker,
    },
    droppedCount: 0,
    durationMs: event.durationMs,
    id: "",
    kind: "binary-decode",
    lane: event.worker ? "worker" : "main-thread",
    name:
      event.outcome === "ok"
        ? "binary-decode.finished"
        : "binary-decode.error",
    severity:
      event.outcome === "error" || event.durationMs >= 100
        ? "warning"
        : "info",
    startTimeMs: Math.max(0, event.timestampMs - event.durationMs),
    timestampMs: event.timestampMs,
  });
}

function DiagnosticRecorderConnector({ kernel }: { kernel: KernelApi }) {
  useEffect(() => {
    const diagnosticWindow = window as Window & {
      __FULLMAG_DIAGNOSTIC_RECORDER_EXPORT__?: () => ReturnType<
        KernelApi["diagnosticRecorder"]["exportArtifact"]
      >;
    };
    const exportDiagnosticArtifact = () =>
      kernel.diagnosticRecorder.exportArtifact();
    diagnosticWindow.__FULLMAG_DIAGNOSTIC_RECORDER_EXPORT__ =
      exportDiagnosticArtifact;
    kernel.diagnosticRecorder.drainEarlyRecorder();
    recordDiagnosticBrowserSnapshot((record) => {
      kernel.diagnosticRecorder.record(record);
    });
    const cleanupConsoleCapture = installDiagnosticConsoleCapture({
      record: (record) => {
        kernel.diagnosticRecorder.record(record);
      },
    });
    kernel.diagnosticRecorder.mark(DIAGNOSTIC_EVENT_NAMES.kernelProviderMounted);
    return () => {
      if (
        diagnosticWindow.__FULLMAG_DIAGNOSTIC_RECORDER_EXPORT__ ===
        exportDiagnosticArtifact
      ) {
        delete diagnosticWindow.__FULLMAG_DIAGNOSTIC_RECORDER_EXPORT__;
      }
      cleanupConsoleCapture();
    };
  }, [kernel]);

  return null;
}

function RealtimeConnector({ kernel, sessionIdentity }: { kernel: KernelApi; sessionIdentity: SessionResourceIdentity }) {
  const sessionScopeKey = sessionRequestScopeKey(sessionIdentity);
  const expectedRequestScopeEpoch = sessionIdentity?.requestScopeEpoch ?? null;
  const expectedSessionId = sessionIdentity?.sessionId ?? null;
  useEffect(() => {
    if (!expectedSessionId || !expectedRequestScopeEpoch || controlRoomRealtimeDisabledFromBrowser()) {
      return;
    }

    if (typeof WebSocket === "undefined") {
      return;
    }

    const url = resolveControlRoomWebSocketUrl(
      kernel.api.getBaseUrl(),
      SESSION_EVENTS_WS_PATH,
      window.location.origin,
    );
    if (!url) {
      return;
    }

    const client = new RealtimeClient({
      beforeConnect: kernel.api.getExpectedApiInstance() ? async () => {
        try {
          await kernel.api.platform.health({ signal: AbortSignal.timeout(3000) });
          return true;
        } catch (error) {
          if (error instanceof ControlRoomApiError && error.code === "API_INSTANCE_MISMATCH") return false;
          throw error;
        }
      } : undefined,
      bridge: kernel.realtime,
      diagnostics: kernel.diagnostics,
      expectedRequestScopeEpoch,
      expectedSessionId,
      expectedApiInstance: kernel.api.getExpectedApiInstance(),
      onReconnected: () => {
        kernel.realtime.handleReconnect();
      },
      onScopeMismatch: () => {
        kernel.realtime.handleReconnect();
      },
      onStatusChange: (status) => {
        kernel.realtimeConnection.update(status);
        kernel.bus.emit("session:status-changed", { status });
      },
      url,
    });
    client.connect();
    return () => client.close();
  }, [kernel, sessionScopeKey, expectedRequestScopeEpoch, expectedSessionId]);

  return null;
}

function controlRoomRealtimeDisabledFromBrowser(): boolean {
  const auditWindow = window as Window & {
    __FULLMAG_CONFIG__?: { disableRealtime?: boolean };
  };
  return auditWindow.__FULLMAG_CONFIG__?.disableRealtime === true;
}

function CommandShortcutConnector({ kernel }: { kernel: KernelApi }) {
  const startupVisible = useSimulationStartupOverlayVisibility();
  const sessionIdentity = useSessionResourceIdentity();
  const sessionScopeKey = sessionRequestScopeKey(sessionIdentity);
  const runtimeResourceData = useRuntimeCommandControlResourceData({
    enabled: !startupVisible,
  });
  const runtimeResourceDataRef = useRef(runtimeResourceData);

  useEffect(() => {
    runtimeResourceDataRef.current = runtimeResourceData;
  }, [runtimeResourceData]);

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent): void {
      const context = createCommandContext("shortcut", kernel, {
        resourceData: runtimeResourceDataRef.current,
        sessionScopeKey,
        sourceDetail: "global",
      });
      dispatchShortcutCommand(kernel.commands, event, context);
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [kernel, sessionScopeKey]);

  return null;
}

function ProjectWorkspaceShortcutConnector({
  kernel,
  canCreateSession,
}: {
  kernel: KernelApi;
  canCreateSession: boolean;
}) {
  useEffect(() => {
    const commands = {
      all: () => kernel.commands.all().filter((command) =>
        isProjectWorkspaceCommand(command.id) &&
        (canCreateSession || command.id !== "workspace.new-problem")),
      isEnabled: (id: string, context: Parameters<typeof kernel.commands.isEnabled>[1]) => kernel.commands.isEnabled(id, context),
      execute: (id: string, context: Parameters<typeof kernel.commands.execute>[1]) => kernel.commands.execute(id, context),
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      dispatchShortcutCommand(commands, event, createCommandContext("shortcut", kernel, {
        sessionScopeKey: null,
        sourceDetail: "project-workspace",
      }));
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [kernel, canCreateSession]);
  return null;
}

function SessionRuntimeConnectors({ kernel }: { kernel: KernelApi }) {
  const sessions = useSessionCollection();
  const savedRun = useSavedRunSelection();
  if (savedRun) return <ProjectWorkspaceShortcutConnector kernel={kernel} canCreateSession={false} />;
  if (sessions.state !== "ready") {
    return <ProjectWorkspaceShortcutConnector kernel={kernel} canCreateSession={sessions.state === "no-session"} />;
  }
  return <AvailableSessionRuntimeConnectors kernel={kernel} collection={sessions.resource.data} />;
}

function AvailableSessionRuntimeConnectors({ kernel, collection }: {
  kernel: KernelApi;
  collection: ReturnType<typeof useSessionCollection>["resource"]["data"];
}) {
  const identity = useSessionResourceIdentity();
  const confirmedIdentity = confirmedSessionResourceIdentity(identity, collection);
  const scopeKey = sessionRequestScopeKey(confirmedIdentity);
  useLayoutEffect(() => {
    const clearRuntimeSelection = () => {
      if (kernel.selection.get().ref?.type !== "materialized-dataset") kernel.selection.clearForSessionTransition("workspace");
    };
    clearRuntimeSelection();
    return clearRuntimeSelection;
  }, [kernel, scopeKey]);
  // Declared after the clearing effect so a requested Universe selection is
  // applied after the session-transition clear, not wiped by it.
  useDomainSetupNavigation(kernel, confirmedIdentity?.sessionId ?? null, scopeKey);
  if (!confirmedIdentity) return null;
  return (
    <>
      <RealtimeConnector kernel={kernel} sessionIdentity={confirmedIdentity} />
      <CommandShortcutConnector kernel={kernel} />
      <VisualizationRegistrySyncConnector kernel={kernel} />
      <CameraRegistrySyncConnector kernel={kernel} sessionScopeKey={scopeKey!} />
      <RunOutcomeConnector kernel={kernel} sessionIdentity={confirmedIdentity} />
    </>
  );
}

function VisualizationRegistrySyncConnector({ kernel }: { kernel: KernelApi }) {
  useEffect(() => {
    kernel.visualizationSync.start();
    return () => kernel.visualizationSync.stop();
  }, [kernel]);

  return null;
}

function CameraRegistrySyncConnector({ kernel, sessionScopeKey }: { kernel: KernelApi; sessionScopeKey: string }) {
  useEffect(() => {
    kernel.cameraRegistry.setSessionScopeKey(sessionScopeKey);
    return () => { kernel.cameraRegistry.stop(); kernel.cameraRegistry.setSessionScopeKey(null); };
  }, [kernel, sessionScopeKey]);
  useEffect(() => {
    kernel.cameraRegistry.start();
    return () => kernel.cameraRegistry.stop();
  }, [kernel, sessionScopeKey]);

  return null;
}

function BrowserAuditConnector({ kernel }: { kernel: KernelApi }) {
  const sessionIdentity = useSessionResourceIdentity();
  const sessionIdentityRef = useRef(sessionIdentity);
  useEffect(() => {
    sessionIdentityRef.current = sessionIdentity;
  }, [sessionIdentity]);
  useEffect(() => {
    // The browser driver is compiled only into the explicitly named audit
    // artifact. Ordinary production bundles never install this mutable hook.
    const auditBuild = process.env.NEXT_PUBLIC_AUDIT_BUILD === "1";
    if (process.env.NODE_ENV === "production" && !auditBuild) return;
    // Audit drivers address resources by their canonical path; the store keys
    // them by the confirmed session scope.
    const auditScopedResourceKey = (resourceKey: string) => {
      const identity = sessionIdentityRef.current;
      return identity && !resourceKey.includes("|")
        ? sessionScopedResourceKey(identity, resourceKey)
        : resourceKey;
    };
    const auditWindow = window as Window & {
      __FULLMAG_CONFIG__?: {
        allowMissingSessionSmoke?: boolean;
        disableRealtime?: boolean;
        enableAuditHooks?: boolean;
      };
      __FULLMAG_CONTROL_ROOM_AUDIT__?: {
        loadHysteresisReplaySnapshot: (input: {
          fieldVal?: number | null;
          fieldRevision?: string | number | null;
          mVal?: number | null;
          measurementAxis?: string | null;
          meshIdentity?: string | null;
          pointId: number;
          snapshotId: string;
          stageId: string;
        }) => void;
        returnHysteresisReplayToLive: (input?: {
          stageId?: string | null;
        }) => Promise<void>;
        setGlobalQuantity: (quantityId: string) => Promise<void>;
        queueGlobalQuantity: (quantityId: string) => void;
        flushVisualization: () => Promise<void>;
        setActiveViewportModule: (moduleId: "field-map" | "viewport-3d") => void;
        patchVisualization: (patch: VisualizationStatePatch) => Promise<void>;
        patchFdmVisualization: (patch: VisualizationTargetPatch) => void;
        readFdmVisualizationSettings: () => ReturnType<
          ObjectVisualizationController["getSettings"]
        >;
        readVisualizationTargetSettings: (
          target: VisualizationTargetRef,
        ) => ReturnType<ObjectVisualizationController["getSettings"]>;
        readVisualizationSyncSnapshot: () => ReturnType<
          VisualizationRegistrySyncController["getSnapshot"]
        >;
        readVisualizationControllerSnapshot: () => ReturnType<
          ObjectVisualizationController["getSnapshot"]
        >;
        readViewport3DFieldUpdateHoldActive: () => boolean;
        readActiveViewportModule: () => string;
        publishVisualizationState: (state: VisualizationStateResource) => void;
        readViewportAuditRuntime: () => {
          listenerCounts: ReturnType<typeof sharedResourceRuntimeStore.listenerCounts>;
          resources: ReturnType<typeof sharedResourceRuntimeStore.stats>;
          visualizationRevision: ResourceRevision | null;
          workers: ReturnType<typeof getViewport3DWorkerRuntimeSnapshot>;
        };
        setPlanarMonitorFrameVisible: (visible: boolean) => void;
        seedPlanarMonitorFramePreview: () => void;
        readViewportAuditResource: (resourceKey: string) => {
          data: unknown;
          error: string | null;
          revision: ResourceRevision | null;
          status: string;
        };
        invalidateResource: (
          resourceKey: string,
          revision: ResourceRevision,
        ) => void;
        injectViewportAuditListenerLeak: () => void;
        injectViewportAuditWorkerLeak: () => void;
      };
    };
    const browserConfig = auditWindow.__FULLMAG_CONFIG__;
    if (
      !browserConfig?.allowMissingSessionSmoke &&
      !browserConfig?.enableAuditHooks
    ) {
      return;
    }

    const auditApi = {
      loadHysteresisReplaySnapshot: (input: {
        fieldVal?: number | null;
        fieldRevision?: string | number | null;
        mVal?: number | null;
        measurementAxis?: string | null;
        meshIdentity?: string | null;
        pointId: number;
        snapshotId: string;
        stageId: string;
      }) => {
        const fieldVal = input.fieldVal ?? input.pointId;
        const mVal = input.mVal ?? 0;
        kernel.selection.set(
          {
            kind: "analysis.chart-point",
            label: `Point ${input.pointId} (${fieldVal} mT)`,
            nodeId: `analysis:hysteresis:${input.stageId}:point:${input.pointId}`,
            objectId: null,
            ref: {
              chartId: `hysteresis:${input.stageId}`,
              fieldRevision: input.fieldRevision ?? null,
              kind: "analysis.chart-point",
              measurementAxis: input.measurementAxis ?? null,
              meshIdentity: input.meshIdentity ?? null,
              nodeId: `analysis:hysteresis:${input.stageId}:point:${input.pointId}`,
              pointId: input.pointId,
              quantity: "m",
              quantityId: "m",
              rowIndex: input.pointId,
              seriesId: `hysteresis:${input.stageId}:m`,
              snapshotId: input.snapshotId,
              stageId: input.stageId,
              tableId: `hysteresis:${input.stageId}`,
              targetId: `hysteresis-step:${input.stageId}:${input.pointId}`,
              targetKind: "hysteresis-step",
              type: "analysis-chart-point",
              x: fieldVal,
              y: mVal,
            },
          },
          "analysis-plots",
        );
        kernel.layout.setActiveViewportMainModule("viewport-3d");
        kernel.layout.setFocusedSlot("viewport-main");
      },
      returnHysteresisReplayToLive: async (input?: {
        stageId?: string | null;
      }) => {
        await kernel.commands.execute(
          "hysteresis.return-to-live",
          createCommandContext("analysis-plots", kernel),
          { stageId: input?.stageId ?? null },
        );
      },
      setGlobalQuantity: async (quantityId: string) => {
        auditApi.queueGlobalQuantity(quantityId);
        await kernel.visualizationSync.flushNow();
      },
      queueGlobalQuantity: (quantityId: string) => {
        const activeQuantityId = normalizeQuantityIdOrDefault(quantityId);
        kernel.visualizationSync.queuePatch({
          active_quantity_id: activeQuantityId,
          quantity: { active_quantity_id: activeQuantityId },
        });
      },
      flushVisualization: () => kernel.visualizationSync.flushNow(),
      setActiveViewportModule: (moduleId: "field-map" | "viewport-3d") => {
        kernel.layout.setActiveViewportMainModule(moduleId);
        kernel.layout.setFocusedSlot("viewport-main");
      },
      patchVisualization: async (patch: VisualizationStatePatch) => {
        kernel.visualizationSync.queuePatch(patch);
        await kernel.visualizationSync.flushNow();
      },
      patchFdmVisualization: (patch: VisualizationTargetPatch) => {
        kernel.visualization.patchDefaults("fdm-domain", patch);
      },
       readFdmVisualizationSettings: () =>
         kernel.visualization.getSettings({
           id: "fdm-domain",
           kind: "fdm-domain",
           label: "FDM domain",
         }),
       readVisualizationTargetSettings: (target: VisualizationTargetRef) =>
         kernel.visualization.getSettings(target),
       readVisualizationSyncSnapshot: () => kernel.visualizationSync.getSnapshot(),
       readVisualizationControllerSnapshot: () => kernel.visualization.getSnapshot(),
      readViewport3DFieldUpdateHoldActive: () =>
        viewport3DFieldUpdateHoldActive(),
      readActiveViewportModule: () =>
        kernel.layout.get().activeViewportMainModuleId,
      publishVisualizationState: (state: VisualizationStateResource) => {
        // Runtime resources are keyed by the confirmed session scope; an
        // unscoped publication would never reach the mounted viewport.
        const identity = sessionIdentityRef.current;
        if (!identity) {
          throw new Error("Browser audit publication requires a confirmed session identity.");
        }
        sharedResourceRuntimeStore.updateData(
          resourceRuntimeKeyForClientScope(
            sessionScopedResourceKey(identity, VISUALIZATION_STATE_PATH),
            kernel.api.resourceCacheScope,
          ),
          state,
          state.revision,
        );
      },
      readViewportAuditRuntime: () => {
        const identity = sessionIdentityRef.current;
        return {
          listenerCounts: sharedResourceRuntimeStore.listenerCounts(),
          resources: sharedResourceRuntimeStore.stats(),
          visualizationRevision: identity
            ? sharedResourceRuntimeStore.getSnapshot(
                resourceRuntimeKeyForClientScope(
                  sessionScopedResourceKey(identity, VISUALIZATION_STATE_PATH),
                  kernel.api.resourceCacheScope,
                ),
              ).revision
            : null,
          workers: getViewport3DWorkerRuntimeSnapshot(),
        };
      },
      setPlanarMonitorFrameVisible: (visible: boolean) => {
        planarMonitorFramePreviewStore.setVisible(visible);
      },
      seedPlanarMonitorFramePreview: () => {
        planarMonitorFramePreviewStore.set({
          boundsUvM: [-1e-9, 1e-9, -1e-9, 1e-9],
          monitorId: "audit-planar-monitor",
          normal: [0, 0, 1],
          operator: { kind: "plane_sample" },
          originM: [0, 0, 0],
          selectable: true,
          uAxis: [1, 0, 0],
          vAxis: [0, 1, 0],
          visible: true,
        });
      },
      readViewportAuditResource: (resourceKey: string) => {
        const snapshot = sharedResourceRuntimeStore.getSnapshot(
          resourceRuntimeKeyForClientScope(
            auditScopedResourceKey(resourceKey),
            kernel.api.resourceCacheScope,
          ),
        );
        return {
          data: snapshot.data,
          error: snapshot.error?.message ?? null,
          revision: snapshot.revision,
          status: snapshot.status,
        };
      },
      invalidateResource: (resourceKey: string, revision: ResourceRevision) => {
        kernel.resources.invalidate(auditScopedResourceKey(resourceKey), revision);
      },
      injectViewportAuditListenerLeak: () => {
        // Deliberately retained only when an audit asks for a negative control.
        sharedResourceRuntimeStore.subscribe(
          resourceRuntimeKeyForClientScope(
            VISUALIZATION_STATE_PATH,
            kernel.api.resourceCacheScope,
          ),
          () => {},
        );
      },
      injectViewportAuditWorkerLeak: () => {
        // Deliberately retained only when an audit asks for a negative control.
        acquireViewport3DWorkerRuntime();
      },
    };
    auditWindow.__FULLMAG_CONTROL_ROOM_AUDIT__ = auditApi;
    return () => {
      if (auditWindow.__FULLMAG_CONTROL_ROOM_AUDIT__ === auditApi) {
        delete auditWindow.__FULLMAG_CONTROL_ROOM_AUDIT__;
      }
    };
  }, [kernel]);

  return null;
}

function PerformanceDiagnosticsConnector({ kernel }: { kernel: KernelApi }) {
  useEffect(
    () => {
      if (!performanceDiagnosticsEnabledFromBrowserConfig()) {
        return;
      }
      const stopMeasures = startPerformanceMeasureDiagnostics({
        diagnostics: kernel.diagnostics,
      });
      const stopBrowserActivity = startBrowserActivityDiagnostics({
        diagnostics: kernel.diagnostics,
      });
      return () => {
        stopMeasures();
        stopBrowserActivity();
      };
    },
    [kernel.diagnostics],
  );

  return null;
}

function Viewport3DResourceLifecycleConnector({
  kernel,
}: {
  kernel: KernelApi;
}) {
  useEffect(
    () =>
      createViewport3DInactiveResourcePauseController({
        layout: kernel.layout,
      }),
    [kernel.layout],
  );

  return null;
}

/**
 * Pauses this page's background work while its instance tab is hidden
 * (ADR 0069), and its live data plane while the browser tab is hidden.
 */
function InstanceTabVisibilityConnector() {
  useEffect(() => listenForInstanceTabVisibility(window), []);
  useEffect(() => createHiddenInstanceTabResourcePauseController(), []);
  useEffect(
    () => createHiddenDocumentResourcePauseController({ visibility: document }),
    [],
  );

  return null;
}

export function KernelProvider({ children }: KernelProviderProps) {
  const [kernel] = useState(() => createKernel());

  return (
    <KernelContext.Provider value={kernel}>
      <SessionRuntimeConnectors kernel={kernel} />
      <BrowserAuditConnector kernel={kernel} />
      <DiagnosticRecorderConnector kernel={kernel} />
      <PerformanceDiagnosticsConnector kernel={kernel} />
      <Viewport3DResourceLifecycleConnector kernel={kernel} />
      <InstanceTabVisibilityConnector />
      {children}
    </KernelContext.Provider>
  );
}

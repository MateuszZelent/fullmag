import type { SavedRunController } from "./saved-results/SavedRunController";
import type { SavedResultsPlaybackController } from "./saved-results/SavedResultsPlaybackController";
import type { ComponentType } from "react";

import type { ControlRoomApi } from "./api/ControlRoomApi";
import type { RequestDiagnosticsController } from "./api/RequestDiagnosticsController";
import type { CommandDiagnosticsController } from "./commands/CommandDiagnosticsController";
import type { CommandFeedbackController } from "./commands/CommandFeedbackController";
import type { CommandContribution } from "./commands/commandTypes";
import type { CommandRegistry } from "./commands/CommandRegistry";
import type { EventBus } from "./events/EventBus";
import type { KernelEventMap } from "./events/eventTypes";
import type { LayoutController } from "./layout/LayoutController";
import type { RibbonTabId } from "./layout/layoutTypes";
import type { ModuleRegistry } from "./module/ModuleRegistry";
import type { RealtimeInvalidationBridge } from "./realtime/RealtimeInvalidationBridge";
import type { RealtimeConnectionController } from "./realtime/RealtimeConnectionController";
import type { ResourceInvalidationController } from "./resources/ResourceInvalidationController";
import type { SelectionController } from "./selection/SelectionController";
import type { DiagnosticRecorderController } from "./performance/diagnostic-recorder/DiagnosticRecorderController";
import type { ObjectMoveToolController } from "./authoring/ObjectMoveToolController";
import type { AuthoringHistoryController } from "./authoring/AuthoringHistoryController";
import type { ObjectEditSessionController } from "./authoring/object-edit/ObjectEditSessionController";
import type { GeometryObjectDraft } from "./authoring/object-edit/objectEditTypes";
import type { PendingFormRegistry } from "./authoring/PendingFormRegistry";
import type { AnalysisFieldOverlayController } from "./visualization/AnalysisFieldOverlayController";
import type { ChartViewportHandoffController } from "./visualization/ChartViewportHandoffController";
import type { CameraRegistryController } from "./visualization/CameraRegistryController";
import type { ObjectVisualizationController } from "./visualization/ObjectVisualizationController";
import type { ModeCompositionController } from "./visualization/ModeCompositionController";
import type { VisualizationDebugController } from "./visualization/VisualizationDebugController";
import type { VisualizationRegistrySyncController } from "./visualization/VisualizationRegistrySyncController";
import type { ProjectDocumentController } from "./persistence/ProjectDocumentController";

export type SlotId =
  | "app-menu"
  | "ribbon"
  | "panel-left"
  | "viewport-main"
  | "viewport-aux"
  | "panel-right"
  | "panel-bottom"
  | "status-bar"
  | "start-screen"
  | "overlay";

export type ModuleId = string;
type CapabilityKey = string;
export type ModuleConfig = Record<string, unknown>;

export interface ModuleProps {
  kernel: KernelApi;
  moduleId: ModuleId;
  slotId: SlotId;
  config: ModuleConfig;
  setConfig: (patch: Partial<ModuleConfig>) => void;
}

export interface ModuleManifest {
  /** Optional ribbon tab that selects this module when its slot is shared. */
  activationTab?: RibbonTabId;
  id: ModuleId;
  title: string;
  version: string;
  slots: SlotId[];
  capabilityGate?: CapabilityKey[];
  component: () => Promise<{ default: ComponentType<ModuleProps> }>;
  /** Declarative contributions — auto-registered by the kernel on module load. */
  contributes?: {
    commands?: CommandContribution[];
  };
  emits?: Array<keyof KernelEventMap>;
  listens?: Array<keyof KernelEventMap>;
}

export interface KernelApi {
  readonly savedRun?: SavedRunController;
  readonly savedResultsPlayback?: SavedResultsPlaybackController;
  readonly api: ControlRoomApi;
  readonly analysisFieldOverlay: AnalysisFieldOverlayController;
  readonly authoringHistory?: AuthoringHistoryController;
  readonly objectEditSession: ObjectEditSessionController<GeometryObjectDraft>;
  readonly pendingForms?: PendingFormRegistry;
  readonly bus: EventBus<KernelEventMap>;
  readonly chartViewportHandoff: ChartViewportHandoffController;
  readonly cameraRegistry: CameraRegistryController;
  readonly commandDiagnostics: CommandDiagnosticsController;
  /** Foreground command feedback owner; optional for partial test kernels. */
  readonly commandFeedback?: CommandFeedbackController;
  readonly commands: CommandRegistry;
  readonly diagnostics: RequestDiagnosticsController;
  readonly diagnosticRecorder: DiagnosticRecorderController;
  readonly modules: ModuleRegistry;
  readonly objectMoveTool: ObjectMoveToolController;
  readonly projectDocument?: ProjectDocumentController;
  readonly realtime: RealtimeInvalidationBridge;
  readonly realtimeConnection: RealtimeConnectionController;
  readonly resources: ResourceInvalidationController;
  readonly selection: SelectionController;
  readonly visualization: ObjectVisualizationController;
  readonly visualizationDebug: VisualizationDebugController;
  readonly visualizationSync: VisualizationRegistrySyncController;
  readonly layout: LayoutController;
  readonly modeComposition: ModeCompositionController;
}

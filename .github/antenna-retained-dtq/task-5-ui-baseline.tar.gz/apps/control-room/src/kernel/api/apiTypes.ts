import type { components, paths } from "./generated/openapi-v2-types";

export type ResourceRevision = string | number;
type JsonPrimitive = boolean | null | number | string;
export type JsonValue = JsonPrimitive | JsonObject | JsonValue[];
export type JsonObject = { [key: string]: JsonValue };

export type SessionListResource = components["schemas"]["SessionListResource"];
export type InstanceDiscoveryResource = components["schemas"]["InstanceDiscoveryResource"];
export type DiscoveredInstance = components["schemas"]["DiscoveredInstance"];
export type ModelReadinessResource =
  components["schemas"]["ModelReadinessResource"];
export type ModelReadinessCheck = components["schemas"]["ModelReadinessCheck"];

export type ObjectInteractionKind =
  | "exchange"
  | "demag"
  | "interfacial_dmi"
  | "uniaxial_anisotropy";

interface BaseAuthoringTransaction {
  base_revision?: number | null;
}

export type CommandDetailResource = components["schemas"]["CommandDetailResource"];
export type CommandQueueStatusResource =
  components["schemas"]["CommandQueueStatusResource"];
export type CommandResponse = components["schemas"]["CommandResponse"];
export type CommandFailureRequest = components["schemas"]["CommandFailureRequest"];
export type CheckpointCreateRequest =
  components["schemas"]["CheckpointCreateRequest"];
export type CheckpointCreateResponse =
  components["schemas"]["CheckpointCreateResponse"];
export type CheckpointEntry = components["schemas"]["CheckpointEntry"];
export type CheckpointListResource =
  components["schemas"]["CheckpointListResponse"];
export type CheckpointRestoreRequest =
  components["schemas"]["CheckpointRestoreRequest"];
export type CheckpointRestoreResponse =
  components["schemas"]["CheckpointRestoreResponse"];
export type CurrentRunResource = components["schemas"]["CurrentRunResource"];
export type DomainMetaResource = components["schemas"]["DomainMeta"];
export type FdmMultilayerLayoutResource =
  components["schemas"]["FdmMultilayerLayoutResource"];
export type FdmNativeLayerRegionMembershipResource =
  components["schemas"]["FdmNativeLayerRegionMembershipResource"];
export type EngineLogResource = components["schemas"]["EngineLogResource"];
export type FieldCatalogResource = components["schemas"]["FieldCatalog"];
export type ArtifactFieldCatalogQuery = NonNullable<paths["/v2/sessions/current/data/fields"]["get"]["parameters"]["query"]>;
export type FieldAvailabilityResource =
  components["schemas"]["FieldAvailabilityResource"];
export type FieldMetaResource = components["schemas"]["FieldMeta"];
/** Pending managed export: schemas/quantities.rs::QuantityTensorDescriptor/QuantityCatalogEntry. */
export interface QuantityTensorDescriptor {
  rank: number;
  shape: number[];
  layout: string;
  axes: string[];
  component_labels: string[];
}
export type QuantityCatalogResource = Omit<components["schemas"]["QuantityCatalogResponse"], "quantities"> & {
  quantities: (components["schemas"]["QuantityCatalogEntry"] & { tensor?: QuantityTensorDescriptor | null })[];
};
export interface FieldAvailabilityQuery {
  stage_id?: string | null;
  carrier_id?: string | null;
  expected_carrier_revision?: string | null;
  view?: string | null;
  target_id?: string | null;
  scope_kind?: string | null;
  scope_id?: string | null;
  owner_object_id?: string | null;
}
export interface FieldMetaQuery {
  carrier_id?: string | null;
  expected_carrier_revision?: string | null;
  view?: string | null;
  component?: string | null;
  owner_object_id?: string | null;
  scope_id?: string | null;
  scope_kind?: string | null;
  snapshot_id?: string | null;
  stage_id?: string | null;
}
export type FieldStateExportRequest =
  components["schemas"]["FieldStateExportRequest"];
export type FieldStateExportResponse =
  components["schemas"]["FieldStateExportResponse"];
export type FieldStateImportRequest =
  components["schemas"]["FieldStateImportRequest"];
export type FieldStateImportResponse =
  components["schemas"]["FieldStateImportResponse"];
export type FieldStateInspectRequest =
  components["schemas"]["FieldStateInspectRequest"];
export type FieldStateInspectResponse =
  components["schemas"]["FieldStateInspectResponse"];
export type FieldStateTargetRef =
  components["schemas"]["FieldStateTargetRef"];
export type FieldVectorQuery = components["schemas"]["FieldVectorQuery"] & {
  carrier_id?: string | null;
};
/** Existing provider-owned geometry selector; generated schema follows runtime export. */
export interface ArtifactCarrierGeometryQuery {
  carrier_id: string;
  stage_id?: string;
  expected_carrier_revision: string;
}
export type FieldVectorPendingResponse =
  components["schemas"]["FieldVectorPendingResponse"];
type FdmFieldVectorQueryBase = Omit<
  FieldVectorQuery,
  "geometry_scope" | "scope_id" | "scope_kind"
> & {
  geometry_scope?: never;
};
type FdmIdentifiedFieldVectorQueryBase = FdmFieldVectorQueryBase & {
  scope_id: string;
};
export type FdmSingleGridFieldVectorQuery =
  | (FdmIdentifiedFieldVectorQueryBase & {
      scope_kind: "object" | "region";
    })
  | (FdmFieldVectorQueryBase & {
      scope_id?: string | null;
      scope_kind: "airbox";
    });
export type FdmMultilayerFieldVectorQuery =
  | (FdmIdentifiedFieldVectorQueryBase & {
      scope_kind: "layer" | "object";
    })
  | (Omit<FdmIdentifiedFieldVectorQueryBase, "geometry_scope"> & {
      geometry_scope?: "full" | "surface";
      scope_kind: "airbox";
    });
export type FdmScopedFieldVectorQuery =
  | FdmSingleGridFieldVectorQuery
  | FdmMultilayerFieldVectorQuery;
export type PlanarFieldMetaResource =
  components["schemas"]["PlanarFieldMetaResource"];
export type PlanarSampleSourceResource =
  components["schemas"]["PlanarSampleSourceResource"];
export type PlanarFieldProbeResource =
  components["schemas"]["PlanarFieldProbeResource"];
export type PlanarFieldProfileResource =
  components["schemas"]["PlanarFieldProfileResource"];
export type PostprocessingDataRef = components["schemas"]["PostprocessingDataRef"];
export type PostprocessingDefinition = components["schemas"]["PostprocessingDefinition"];
export type AnalyticReferenceModelCollectionResource =
  components["schemas"]["AnalyticReferenceModelCollectionResource"];
export type AnalyticReferenceModelResource = components["schemas"]["AnalyticReferenceModelResource"];
export type PostprocessingDefinitionCollectionResource =
  components["schemas"]["PostprocessingDefinitionCollectionResource"];
export type PostprocessingDefinitionCreateRequest =
  components["schemas"]["PostprocessingDefinitionCreateRequest"];
export type PostprocessingDefinitionDeleteRequest =
  components["schemas"]["PostprocessingDefinitionDeleteRequest"];
export type PostprocessingDefinitionPatchRequest =
  components["schemas"]["PostprocessingDefinitionPatchRequest"];
export type PostprocessingDefinitionResource =
  components["schemas"]["PostprocessingDefinitionResource"];
export type PlanarMonitorCollectionResource =
  components["schemas"]["PlanarMonitorCollectionResource"];
export type PlanarMonitorCreateRequest =
  components["schemas"]["PlanarMonitorCreateRequest"];
export type PlanarMonitorDeleteRequest =
  components["schemas"]["PlanarMonitorDeleteRequest"];
export type PlanarMonitorDuplicateRequest =
  components["schemas"]["PlanarMonitorDuplicateRequest"];
export type PlanarMonitorPatchRequest =
  components["schemas"]["PlanarMonitorPatchRequest"];
export type PlanarMonitorResource =
  components["schemas"]["PlanarMonitorResource"];
export type PlanarViewScopeState =
  components["schemas"]["PlanarViewScopeState"];

export type PlanarFieldSource =
  /**
   * `sliceKey` is client-only resource identity for the session default slice:
   * the server resolves the slice from visualization state, so a slice change
   * must produce a new resource key even though the HTTP query is unchanged.
   */
  | { kind: "default"; sliceKey?: string }
  | { kind: "monitor"; monitorId: string };

export interface PlanarFieldQuery {
  [key: string]: boolean | number | string | undefined;
  sample_token?: string;
  component?: string;
  expected_carrier_revision?: string;
  expected_field_revision?: string;
  expected_mesh_revision?: string;
  expected_monitor_revision?: string;
  expected_source_revision?: string;
  expected_scene_revision?: string;
  include_mesh?: boolean;
  /** Default source only: multislice panel position along the plane normal (note 0970). */
  position_fraction?: number;
  /** Exact physical default-plane coordinate in metres; mutually exclusive with fraction. */
  position_m?: number;
  quality?: string;
  resolution_x?: number;
  resolution_y?: number;
  scope_id?: string;
  scope_kind?: string;
  /** Region within the `scope_id` object when `scope_kind` is `region`. */
  scope_region_id?: string;
  snapshot_id?: string;
  stage_id?: string;
  vector_budget?: number;
}
export interface PlanarFieldProbeQuery
  extends Pick<
    PlanarFieldQuery,
    | "component"
    | "sample_token"
    | "expected_carrier_revision"
    | "expected_field_revision"
    | "expected_mesh_revision"
    | "expected_monitor_revision"
    | "expected_source_revision"
    | "expected_scene_revision"
    | "position_fraction"
    | "position_m"
    | "quality"
    | "resolution_x"
    | "resolution_y"
    | "scope_id"
    | "scope_kind"
    | "scope_region_id"
    | "snapshot_id"
    | "stage_id"
  > {
  u_m: number;
  v_m: number;
}
/** Line profile of one planar sample (note 0970, `eq-planar-line-profile`). */
export interface PlanarFieldProfileQuery extends Omit<PlanarFieldProbeQuery, "u_m" | "v_m"> {
  samples?: number;
  u0_m: number;
  u1_m: number;
  v0_m: number;
  v1_m: number;
}
export type CrossSectionPlane = "xy" | "xz" | "yz";
export type CrossSectionQualityMetric =
  components["schemas"]["CrossSectionQualityMetric"];
type CrossSectionImageColorScale =
  components["schemas"]["CrossSectionImageColorScale"];
export type SliceMeshColorScale = components["schemas"]["SliceMeshColorScale"];
export interface CrossSectionQuery {
  includePolygons?: boolean;
  includeWireframe?: boolean;
  plane: CrossSectionPlane;
  positionPercent: number;
}
export interface CrossSectionImageQuery {
  colorScale?: CrossSectionImageColorScale;
  dpr?: number;
  edgeWidth?: number;
  filterExpression?: string | null;
  legend?: boolean;
  metric: CrossSectionQualityMetric;
  plane: CrossSectionPlane;
  positionPercent: number;
  resolution?: number;
  rotationDegrees?: number;
  shrinkFactor?: number;
  wireframe?: boolean;
}
export interface CrossSectionQualityQuery {
  metric: CrossSectionQualityMetric;
  plane: CrossSectionPlane;
  positionPercent: number;
}
export type GeometryCapabilitiesResource =
  components["schemas"]["GeometryCapabilitiesResource"];
export type GeometryDiagnosticsResource =
  components["schemas"]["GeometryDiagnosticsResource"];
export type GeometryRealizationRequest =
  components["schemas"]["GeometryRealizationRequest"];
export type GeometryRealizationResource =
  components["schemas"]["GeometryRealizationSnapshot"];
export type GeometryValidationResource =
  components["schemas"]["GeometryValidationResource"];
export type HealthResource = components["schemas"]["HealthResponse"];
export type RuntimeServiceStatusResource =
  components["schemas"]["RuntimeServiceStatusResource"];
export type ImportSessionAssetRequest =
  components["schemas"]["ImportSessionAssetRequest"];
export type SessionAssetImportResponse =
  components["schemas"]["SessionAssetImportResponse"];
export type CpuTelemetryResource =
  components["schemas"]["CpuTelemetryResponse"];
export type GpuTelemetryResource =
  components["schemas"]["GpuTelemetryResponse"];
export type LiveStatusResource = components["schemas"]["LiveStatus"];
export type PlatformCapabilitiesResource =
  components["schemas"]["RuntimeCapabilityMatrix"];
export type MagneticResponseSweepResource = JsonObject & {
  schema_version: string;
};
export type TopologicalChargeResource =
  components["schemas"]["TopologicalChargeResourceV2"];
export interface TopologicalChargeQuery {
  plane?: "auto" | "xy" | "xz" | "yz";
  support?: "midplane" | "layer_profile";
  profile_samples?: "auto" | number;
  snapshot_id?: string | null;
  stage_id?: string | null;
}
export type FrequencyDomainManifestResource =
  components["schemas"]["FrequencyDomainManifestResource"];
export type FrequencyDomainJsonArtifactResource =
  components["schemas"]["FrequencyDomainJsonArtifactResource"];
export type FrequencyDomainJsonArtifactPayload =
  components["schemas"]["FrequencyDomainJsonArtifactPayload"];
export type FrequencyDomainSpectrumArtifactPayload =
  components["schemas"]["FrequencyDomainSpectrumArtifactPayload"];
export type FrequencyDomainBranchesArtifactPayload =
  components["schemas"]["FrequencyDomainBranchesArtifactPayload"];
export type FrequencyDomainFieldSweepArtifactPayload =
  components["schemas"]["FrequencyDomainFieldSweepArtifactPayload"];
export type FrequencyDomainResponseSweepArtifactPayload =
  components["schemas"]["FrequencyDomainResponseSweepArtifactPayload"];
export type FrequencyDomainFmrPeaksArtifactPayload =
  components["schemas"]["FrequencyDomainFmrPeaksArtifactPayload"];
export type FrequencyDomainTextArtifactResource =
  components["schemas"]["FrequencyDomainTextArtifactResource"];
export type ArtifactResource = components["schemas"]["ArtifactResource"];
export type AntennaFieldSolutionResource =
  components["schemas"]["AntennaFieldSolutionResource"];
export type AntennaFieldPayloadKind =
  | "conductor_positions"
  | "sample_positions"
  | "sample_topology"
  | "electric_potential_per_ampere"
  | "current_density_per_ampere"
  | "magnetic_field_per_ampere";
export type AntennaStageOutputCatalogResource =
  components["schemas"]["AntennaStageOutputCatalogResource"];
export type AntennaExternalLeadInspectionResource =
  components["schemas"]["AntennaExternalLeadInspectionResource"];
export type AntennaInspectionDisplayResource =
  components["schemas"]["AntennaInspectionDisplayResource"];
export type AntennaInspectionCurrentPayloadKind =
  | "current_center_positions"
  | "current_center_density"
  | "current_trace_positions"
  | "current_trace_density"
  | "current_snapshot";
export type AntennaInspectionPayloadKind =
  | AntennaInspectionCurrentPayloadKind
  | "bundle"
  | "sample_positions"
  | "magnetic_field"
  | "device_vertex_ids"
  | "device_potential"
  | "device_positions"
  | "device_topology";
export type AntennaInspectionManifestPayloadKind = Exclude<
  AntennaInspectionPayloadKind, "device_positions" | "device_topology" | AntennaInspectionCurrentPayloadKind
>;
export type AntennaSourceSpectrumResource =
  components["schemas"]["AntennaSourceSpectrumResource"];
export type AntennaSpectrumPayloadKind =
  | "k_u_rad_per_m"
  | "k_v_rad_per_m"
  | "amplitudes_re_im"
  | "power";
export type FrequencyDomainKPathMetadataResource =
  components["schemas"]["FrequencyDomainKPathMetadataResource"];
export type FrequencyDomainKPathSamplingResource =
  components["schemas"]["FrequencyDomainKPathSamplingResource"];
export type FrequencyDomainKPathControlPointResource =
  components["schemas"]["FrequencyDomainKPathControlPointResource"];
export type FrequencyDomainFieldResource =
  components["schemas"]["FrequencyDomainFieldResource"];
export type FrequencyDomainSweepProgressResource =
  components["schemas"]["FrequencyDomainSweepProgressResource"];
export type RealtimeCommunicationPolicy =
  components["schemas"]["RealtimeCommunicationPolicy"];
export type RealtimeCommunicationPolicyPatch =
  components["schemas"]["RealtimeCommunicationPolicyPatch"];
export type RealtimeCommunicationPolicyResource =
  components["schemas"]["RealtimeCommunicationPolicyResource"];
export type RunPerformanceResource =
  components["schemas"]["RunPerformanceResource"];
export type SolverProfileResource =
  components["schemas"]["SolverProfileResource"];
export type MaterialPatchRequest =
  components["schemas"]["MaterialPatchRequest"];
export type MaterialPropertiesResource =
  components["schemas"]["MaterialPropertiesResource"];
export type MaterialReferenceResource =
  components["schemas"]["MaterialReferenceResource"];
export type MaterialResource = components["schemas"]["MaterialResource"];
export type MagnetizationAssetPatchRequest =
  components["schemas"]["MagnetizationAssetPatchRequest"];
export type MagnetizationAssetResource =
  components["schemas"]["MagnetizationAssetResource"];
export type MeshActiveBuildResource =
  components["schemas"]["MeshActiveBuildResource"];
export type MeshBuildHistoryResource =
  components["schemas"]["MeshBuildHistoryResource"];
export type MeshCapabilitiesResource =
  components["schemas"]["MeshCapabilitiesResource"];
export type MeshCapabilityMatrixResource =
  components["schemas"]["MeshCapabilityMatrixResource"];
export type MeshFeatureCapabilityResource =
  components["schemas"]["MeshFeatureCapabilityResource"];
export type MeshHistogramBinElementsResource =
  components["schemas"]["MeshHistogramBinElementsResource"];
export type MeshHistogramBinMetric =
  | "characteristic_size"
  | "edge_length"
  | "gamma"
  | "sicn"
  | "volume";
export type MeshLastSuccessfulBuildResource =
  components["schemas"]["MeshLastSuccessfulBuildResource"];
export type MeshObjectQualityResource =
  components["schemas"]["MeshObjectQualityResource"];
export type MeshObjectReportResource =
  components["schemas"]["MeshObjectReportResource"];
export type MeshObjectSizeFieldResource =
  components["schemas"]["MeshObjectSizeFieldResource"];
export type MeshPeriodicPairsResource =
  components["schemas"]["MeshPeriodicPairsResource"];
export type PeriodicValidationStatus =
  components["schemas"]["PeriodicValidationStatus"];
export type MeshQualityGatesResource =
  components["schemas"]["MeshQualityGatesResource"];
export type MeshRealizedSizeFieldsResource =
  components["schemas"]["MeshRealizedSizeFieldsResource"];
export type MeshRegionMembershipListResource =
  components["schemas"]["MeshRegionMembershipListResource"];
export type MeshRegionMembershipResource =
  components["schemas"]["MeshRegionMembershipResource"];
export type FdmRegionMembershipResource =
  components["schemas"]["FdmRegionMembershipResource"];
export type PendingJsonResourceResult<TData> =
  | { data: TData; status: "ready" }
  | { data: null; status: "pending" };
export type MeshRegionQualityResource =
  components["schemas"]["MeshRegionQualityResource"];
export type MeshSemanticsResource =
  components["schemas"]["MeshSemanticsResource"];
export type MeshSharedDomainConfigResource =
  components["schemas"]["MeshSharedDomainConfigResource"];
export type MeshSharedDomainQualityResource =
  components["schemas"]["MeshSharedDomainQualityResource"];
export type MeshSharedDomainReportResource =
  components["schemas"]["MeshSharedDomainReportResource"];
export type MeshSummaryResource =
  components["schemas"]["MeshSummaryResource"];
export type MeshUniverseQualityResource =
  components["schemas"]["MeshUniverseQualityResource"];
export type MeshUniverseReportResource =
  components["schemas"]["MeshUniverseReportResource"];
export interface MeshObjectConfigReplaceRequest {
  config?: JsonObject | null;
}
export interface MeshObjectConfigResource {
  config?: JsonObject | null;
  effective_config?: JsonObject | null;
  object_id: string;
  revision: number;
}
export interface MeshUniverseConfigReplaceRequest {
  config: JsonObject;
  /** Resource revision the draft was based on; stale values return 409. */
  expected_revision?: number;
}
export interface MeshUniverseConfigResource {
  config?: JsonObject | null;
  effective_config?: JsonObject | null;
  revision: number;
}
export interface MeshSharedDomainConfigReplaceRequest {
  config: JsonObject;
}
export type MeshSharedDomainManifestResource =
  components["schemas"]["MeshSharedDomainManifestResource"];
export type CouplingListResource =
  components["schemas"]["CouplingListResource"];
export type SpinWaveGammaResource =
  components["schemas"]["SpinWaveGammaResource"];
export type DynamicStructureFactorResource =
  components["schemas"]["DynamicStructureFactorResource"];
export type AnalysisResultProductKind =
  components["schemas"]["AnalysisResultProductKind"];
export type AnalysisResultItemKind =
  components["schemas"]["AnalysisResultItemKind"];
export type AnalysisResultAxisProjection =
  components["schemas"]["AnalysisResultAxisProjection"];
export type AnalysisResultAxisValueResource =
  components["schemas"]["AnalysisResultAxisValueResource"];
export type AnalysisResultAxisResource =
  components["schemas"]["AnalysisResultAxisResource"];
export type AnalysisResultCoordinateResource =
  components["schemas"]["AnalysisResultCoordinateResource"];
export type AnalysisResultMeshRef =
  components["schemas"]["AnalysisResultMeshRef"];
export type AnalysisResultStatusFacets =
  components["schemas"]["AnalysisResultStatusFacets"];
export type AnalysisResultDatasetCapabilities =
  components["schemas"]["AnalysisResultDatasetCapabilities"];
export type AnalysisResultProjectionDescriptor =
  components["schemas"]["AnalysisResultProjectionDescriptor"];
export type AnalysisResultDefaultCursor =
  components["schemas"]["AnalysisResultDefaultCursor"];
export type AnalysisResultDatasetSummaryResource =
  components["schemas"]["AnalysisResultDatasetSummaryResource"];
export type AnalysisResultDatasetCatalogResource =
  components["schemas"]["AnalysisResultDatasetCatalogResource"];
export type AnalysisResultDatasetManifestResource =
  components["schemas"]["AnalysisResultDatasetManifestResource"];
export type AnalysisResultSampleIndexEntry =
  components["schemas"]["AnalysisResultSampleIndexEntry"];
export type AnalysisResultFieldRef =
  components["schemas"]["AnalysisResultFieldRef"];
export type AnalysisResultQualitySummary =
  components["schemas"]["AnalysisResultQualitySummary"];
export type AnalysisResultItemRelation =
  components["schemas"]["AnalysisResultItemRelation"];
export type AnalysisResultSpectralItemSummary =
  components["schemas"]["AnalysisResultSpectralItemSummary"];
export type AnalysisResultSamplePageResource =
  components["schemas"]["AnalysisResultSamplePageResource"];
export type AnalysisResultItemPageResource =
  components["schemas"]["AnalysisResultItemPageResource"];
export type AnalysisResultBranchPointResource =
  components["schemas"]["AnalysisResultBranchPointResource"];
export type AnalysisResultBranchSummaryResource =
  components["schemas"]["AnalysisResultBranchSummaryResource"];
export type AnalysisResultBranchPageResource =
  components["schemas"]["AnalysisResultBranchPageResource"];
export type AnalysisResultBranchResource =
  components["schemas"]["AnalysisResultBranchResource"];
export type AnalysisResultBranchPointPageResource =
  components["schemas"]["AnalysisResultBranchPointPageResource"];
export type AnalysisResultRelationResource =
  components["schemas"]["AnalysisResultRelationResource"];
export type AnalysisResultRelationPageResource =
  components["schemas"]["AnalysisResultRelationPageResource"];
export type AnalysisResultProjectionSelectionEntry =
  components["schemas"]["AnalysisResultProjectionSelectionEntry"];
export type AnalysisResultProjectionPoint =
  components["schemas"]["AnalysisResultProjectionPoint"];
export type AnalysisResultProjectionSeries =
  components["schemas"]["AnalysisResultProjectionSeries"];
export type AnalysisResultProjectionResource =
  components["schemas"]["AnalysisResultProjectionResource"];
export type AnalysisResultAxisValuesResource =
  components["schemas"]["AnalysisResultAxisValuesResource"];
export interface AnalysisResultPageQuery {
  cursor?: string;
  limit?: number;
  stage_id?: string;
  product_kind?: AnalysisResultProductKind;
  search?: string;
  from_si?: number;
  to_si?: number;
  sample_id?: string;
  item_kind?: AnalysisResultItemKind;
  branch_id?: string;
  status?: string;
  has_field?: boolean;
  has_fields?: boolean;
  frequency_min_hz?: number;
  frequency_max_hz?: number;
  residual_max?: number;
  sort?: string;
  [coordinate: `coordinate.${string}`]: string | undefined;
}
export type FieldDriveListResource =
  components["schemas"]["FieldDriveListResource"];
export type PhysicsGraphResource =
  components["schemas"]["PhysicsGraphResource"];
export type PhysicsGraphActivationResource =
  components["schemas"]["PhysicsGraphActivationResource"];
export type PhysicsGraphEdgeResource =
  components["schemas"]["PhysicsGraphEdgeResource"];
export type PhysicsGraphModuleResource =
  components["schemas"]["PhysicsGraphModuleResource"];
export type PhysicsGraphProvenanceResource =
  components["schemas"]["PhysicsGraphProvenanceResource"];
export type PhysicsGraphScopeResource =
  components["schemas"]["PhysicsGraphScopeResource"];
export type RegionalFieldDriveResource =
  components["schemas"]["RegionalFieldDriveResource"];
export type FieldDriveCreateRequest =
  components["schemas"]["FieldDriveCreateRequest"];
export type FieldDriveReplaceRequest =
  components["schemas"]["FieldDriveReplaceRequest"];
export type FieldDriveDeleteRequest =
  components["schemas"]["FieldDriveDeleteRequest"];
export type RegionListResource = components["schemas"]["RegionListResource"];
export type RegionDiagnosticsResource =
  components["schemas"]["RegionDiagnosticsResource"];
export type MaterialParameterFieldListResource =
  components["schemas"]["MaterialParameterFieldListResource"];
export type RegionPatchRequest = components["schemas"]["RegionPatchRequest"];
export type SolverEnergyCurrentResource =
  components["schemas"]["SolverEnergyCurrentResource"];
export type SolverEnergyHistoryResource =
  components["schemas"]["SolverEnergyHistoryResource"];
export type SimulationPreparationResource =
  components["schemas"]["SimulationPreparationResource"];
export type LivePreparationMaterializationRequest =
  components["schemas"]["LivePreparationMaterializationRequest"];
export type LivePreparationMaterializationResource =
  components["schemas"]["LivePreparationMaterializationResource"];
export type SolverStatusResource = components["schemas"]["SolverStatusResource"];
export type StageExecutionResource =
  components["schemas"]["StageExecutionResource"];
export type HysteresisStagePlanSchema =
  components["schemas"]["HysteresisStagePlanSchema"];
export type HysteresisStageSaturationSchema =
  components["schemas"]["HysteresisStageSaturationSchema"];
export type HysteresisProtocolSchema =
  components["schemas"]["HysteresisProtocolSchema"];
export type HysteresisOrientationSchema =
  components["schemas"]["HysteresisOrientationSchema"];
export type HysteresisSettlePipelineSchema =
  components["schemas"]["HysteresisSettlePipelineSchema"];
export type HysteresisExecutionTreeResource =
  components["schemas"]["HysteresisExecutionTreeResource"];
export type HysteresisExecutionTreeNode =
  components["schemas"]["HysteresisExecutionTreeNode"];
export type HysteresisBookmarkPointRequest =
  components["schemas"]["HysteresisBookmarkPointRequest"];
export type HysteresisBookmarkSchema =
  components["schemas"]["HysteresisBookmarkSchema"];
export type HysteresisBookmarksResource =
  components["schemas"]["HysteresisBookmarksResource"];
export type HysteresisAngularFamilyResource =
  components["schemas"]["HysteresisAngularFamilyResource"];
export type HysteresisAdaptiveRefinementResource =
  components["schemas"]["HysteresisAdaptiveRefinementResource"];
export type HysteresisBranchesResource =
  components["schemas"]["HysteresisBranchesResource"];
export type HysteresisMinorLoopsResource =
  components["schemas"]["HysteresisMinorLoopsResource"];
export type HysteresisPointsResource =
  components["schemas"]["HysteresisPointsResource"];
export type HysteresisMetricsResource =
  components["schemas"]["HysteresisMetricsResource"];
export type HysteresisReversalFieldsResource =
  components["schemas"]["HysteresisReversalFieldsResource"];
export type HysteresisSettleTraceResource =
  components["schemas"]["HysteresisSettleTraceResource"];
export type HysteresisProgressSchema =
  components["schemas"]["HysteresisProgressSchema"];
export type StudyRuntimePatchRequest =
  components["schemas"]["StudyRuntimePatchRequest"];
export type StudyRuntimeResource =
  components["schemas"]["StudyRuntimeResource"];
export type AuthoringTransactionRequest =
  | { base_revision: number; kind: "assign_study_execution"; execution_profile: ExecutionProfile; execution_layers: ExecutionRequestLayer[] }
  | { base_revision?: number | null; kind: "replace_scene"; scene: JsonObject }
  | (BaseAuthoringTransaction & {
      kind: "merge_patch";
      merge_patch: JsonObject;
    })
  | (BaseAuthoringTransaction & {
      asset?: JsonObject | null;
      kind: "patch_magnetization";
      magnetization_ref?: string | null;
      object_id: string;
      region_id?: string | null;
    })
  | (BaseAuthoringTransaction & ObjectGeometryPatchRequest & {
      kind: "patch_object_geometry";
      object_id: string;
    })
  | (BaseAuthoringTransaction & ObjectCreateRequest & {
      kind: "create_object";
    })
  | (BaseAuthoringTransaction & {
      kind: "create_material";
      material_id: string;
      name: string;
      properties: MaterialPropertiesResource;
      references?: MaterialReferenceResource[];
    })
  | (BaseAuthoringTransaction & {
      kind: "patch_material";
      material_id: string;
      patch: MaterialPatchRequest;
    })
  | (BaseAuthoringTransaction & {
      kind: "delete_material";
      material_id: string;
    })
  | (BaseAuthoringTransaction & {
      kind: "delete_object";
      object_id: string;
    })
  | (BaseAuthoringTransaction & {
      kind: "rename_object";
      name: string;
      object_id: string;
    })
  | (BaseAuthoringTransaction & {
      kind: "commit_object_transform";
      object_id: string;
      transform: JsonObject;
    })
  | (BaseAuthoringTransaction & {
      kind: "patch_universe";
      sync_study_universe_mesh?: boolean;
      universe: JsonObject;
    })
  | (BaseAuthoringTransaction & {
      kind: "create_object_region";
      object_id: string;
      region: components["schemas"]["SceneObjectRegion"];
    })
  | (BaseAuthoringTransaction & {
      kind: "patch_object_region";
      object_id: string;
      patch: components["schemas"]["SceneObjectRegionPatch"];
      region_id: string;
    })
  | (BaseAuthoringTransaction & {
      fields: components["schemas"]["SceneMaterialParameterAssignment"][];
      kind: "patch_object_material_fields";
      object_id: string;
    })
  | (BaseAuthoringTransaction & {
      kind: "delete_object_region";
      object_id: string;
      region_id: string;
    })
  | (BaseAuthoringTransaction & {
      kind: "reorder_object_regions";
      object_id: string;
      region_ids: string[];
    })
  | (BaseAuthoringTransaction & {
      coupling: components["schemas"]["SceneCoupling"];
      kind: "create_coupling";
    })
  | (BaseAuthoringTransaction & {
      coupling_id: string;
      kind: "patch_coupling";
      patch: components["schemas"]["SceneCouplingPatch"];
    })
  | (BaseAuthoringTransaction & {
      coupling_id: string;
      kind: "delete_coupling";
    });
export interface AuthoringTransactionResponse {
  committed_scene: SceneResource;
  scene_revision: number;
  transaction_kind: string;
}
export interface ObjectCreateRequest extends BaseAuthoringTransaction {
  geometry: JsonObject;
  magnetization_asset?: JsonObject | null;
  magnetization_ref?: string | null;
  material_asset?: JsonObject | null;
  material_ref?: string | null;
  name: string;
  object_id: string;
  region_name?: string | null;
  study_universe_mesh?: JsonObject | null;
  transform?: JsonObject | null;
  universe?: JsonObject | null;
}
export interface ObjectGeometryPatchRequest extends BaseAuthoringTransaction {
  geometry: JsonObject;
  transform?: JsonObject | null;
}
export interface ObjectRegionCreateRequest extends BaseAuthoringTransaction {
  region: components["schemas"]["SceneObjectRegion"];
}
export type ObjectRegionDuplicateRequest =
  components["schemas"]["ObjectRegionDuplicateRequest"];
export interface ObjectRegionPatchRequest extends BaseAuthoringTransaction {
  patch: components["schemas"]["SceneObjectRegionPatch"];
}
export type ObjectRegionReorderRequest =
  components["schemas"]["ObjectRegionReorderRequest"];
export interface ObjectInteractionPatchRequest {
  base_revision?: number | null;
  enabled?: boolean | null;
  params?: JsonObject;
  present?: boolean | null;
}
export interface ObjectInteractionResource {
  enabled: boolean;
  interaction_kind: ObjectInteractionKind | string;
  object_id: string;
  params: JsonObject;
  present: boolean;
  scene_revision: number;
}
export interface ObjectPatchRequest extends BaseAuthoringTransaction {
  absorbing_boundary?: JsonObject | null;
  geometry?: JsonObject | null;
  magnetization_ref?: string | null;
  material_ref?: string | null;
  name?: string | null;
  notes?: string | null;
  region_name?: string | null;
  transform?: JsonObject | null;
  visible?: boolean | null;
}
export type ObjectMetricsResource = components["schemas"]["ObjectMetricsResource"];

export type SceneResource = components["schemas"]["SceneResource"];
export type FrozenSpinsCollectionResource =
  components["schemas"]["FrozenSpinsCollectionResource"];
export type FrozenSpinsDefinitionResource =
  components["schemas"]["FrozenSpinsDefinitionResource"];
export type FrozenSpinsMutationRequest =
  components["schemas"]["FrozenSpinsMutationRequest"];
export type FrozenSpinsDeleteRequest =
  components["schemas"]["FrozenSpinsDeleteRequest"];
export type FrozenSpinsPreviewRequest =
  components["schemas"]["FrozenSpinsPreviewRequest"];
export type FrozenSpinsPreviewResponse =
  components["schemas"]["FrozenSpinsPreviewResponse"];
export type FrozenSpinsPreviewActivationRequest =
  components["schemas"]["FrozenSpinsPreviewActivationRequest"];
export type FrozenSpinsPreviewActivationResponse =
  components["schemas"]["FrozenSpinsPreviewActivationResponse"];
export type FrozenSpinsRuntimeApplication =
  components["schemas"]["FrozenSpinsRuntimeApplication"];
export type FrozenSpinsSolverRuntimeStatus =
  components["schemas"]["FrozenSpinsSolverRuntimeStatus"];
export type FrozenSpinsDefinition = components["schemas"]["FrozenSpinsSchema"];
export type FrozenSpinsSelectionExpression =
  components["schemas"]["SelectionExprSchema"];
export type FrozenSpinsReferencePolicy =
  components["schemas"]["FrozenReferencePolicySchema"];
export type FrozenSpinsMembershipPolicy =
  components["schemas"]["SelectionMembershipPolicySchema"];
export type FrozenSpinsActivation =
  components["schemas"]["ConstraintActivationSchema"];
export type SelectionScalarExpression =
  components["schemas"]["SelectionScalarExprSchema"];
export type SelectionGeometryPredicate =
  components["schemas"]["SelectionGeometryPredicateSchema"];
export type SceneCurrentTransport = components["schemas"]["SceneCurrentTransport"];
export type SceneSpinTransport = components["schemas"]["SceneSpinTransport"];
export type KnownSceneCurrentTransport = components["schemas"]["KnownSceneCurrentTransport"];
export type KnownSceneSpinTransport = components["schemas"]["KnownSceneSpinTransport"];
export type SceneImpressedPotentialJump = components["schemas"]["SceneImpressedPotentialJump"];
export type SceneStructuredCurrentClosure = components["schemas"]["SceneStructuredCurrentClosure"];
export type SceneStructuredCurrentDrive = components["schemas"]["SceneStructuredCurrentDrive"];
export type SceneStructuredCurrentSourceCut = components["schemas"]["SceneStructuredCurrentSourceCut"];
export type SceneStructuredCutPlane = components["schemas"]["SceneStructuredCutPlane"];
export type SceneSpinTorque = components["schemas"]["SceneSpinTorque"];
export type SceneOerstedField = components["schemas"]["SceneOerstedField"];
export type CurrentTransportListResource = components["schemas"]["CurrentTransportListResource"];
export type CurrentTransportMutationRequest = components["schemas"]["CurrentTransportMutationRequest"];
export type CurrentTransportCommitResource = components["schemas"]["CurrentTransportCommitResource"];
export type SpinTransportListResource = components["schemas"]["SpinTransportListResource"];
export type SpinTransportMutationRequest = components["schemas"]["SpinTransportMutationRequest"];
export type SpinTransportCommitResource = components["schemas"]["SpinTransportCommitResource"];
export type SpinInterfaceListResource = components["schemas"]["SpinInterfaceListResource"];
export type TransportValidationRequest = components["schemas"]["TransportValidationRequest"];
export type TransportValidationResponse = components["schemas"]["TransportValidationResponse"];
export type TransportAuthoringCapabilityMap = components["schemas"]["TransportAuthoringCapabilityMap"];
export type SpinTorqueListResource = components["schemas"]["SpinTorqueListResource"];
export type SpinTorqueMutationRequest = components["schemas"]["SpinTorqueMutationRequest"];
export type SpinTorqueCommitResource = components["schemas"]["SpinTorqueCommitResource"];
export type OerstedFieldListResource = components["schemas"]["OerstedFieldListResource"];
export type OerstedFieldMutationRequest = components["schemas"]["OerstedFieldMutationRequest"];
export type OerstedFieldCommitResource = components["schemas"]["OerstedFieldCommitResource"];
export type SpinAuthoringDeleteRequest = components["schemas"]["SpinAuthoringDeleteRequest"];
export type RuntimeCommandPrecondition =
  components["schemas"]["RuntimeCommandPrecondition"];
export type RuntimeCommandTarget =
  components["schemas"]["RuntimeCommandTarget"];
export type ScalarWindowResource = components["schemas"]["ScalarWindow"];
export interface ScalarWindowQuery {
  columns?: readonly string[];
  limit?: number;
  sinceRevision?: number;
  tail?: boolean;
}
export type TableRowsResource = components["schemas"]["TableRowsResource"];
export type TableColumnMeta = components["schemas"]["TableColumnMeta"];
export type TableListResource = components["schemas"]["TableListResource"];
export type TableResource = components["schemas"]["TableResource"];
export interface TableRowsQuery {
  columns?: readonly string[];
  cursor?: number;
  decimation?: "minmax_lttb" | "none";
  fromRow?: number;
  fromT?: number;
  includeTail?: boolean;
  limit?: number;
  targetPoints?: number;
  toRow?: number;
  toT?: number;
}
export type SessionExportRequest =
  components["schemas"]["SessionExportRequest"];
// The intersections cover fields added in `crates/fullmag-api/src/types.rs`
// (revision-bound canonical export) until the OpenAPI artifacts are
// regenerated with `pnpm run generate:api`; they are no-ops afterwards.
export type ScriptSyncRequest = components["schemas"]["ScriptSyncRequest"] & {
  expected_scene_revision?: number | null;
};
/** `not_checked` unless the exported script was actually lowered and compared. */
export type ScriptExportFidelity = "not_checked" | (string & {});
export type ScriptSyncResponse = components["schemas"]["ScriptSyncResponse"] & {
  source?: string | null;
  scene_revision?: number | null;
  fidelity?: ScriptExportFidelity;
};
export type ScriptSourceResponse = components["schemas"]["ScriptSourceResponse"] & {
  canonical?: boolean;
};
export type SessionExportResponse =
  components["schemas"]["SessionExportResponse"];
export type SessionImportCommitRequest =
  components["schemas"]["SessionImportCommitRequest"];
export type SessionImportCommitResponse =
  components["schemas"]["SessionImportCommitResponse"];
export type SessionImportInspectRequest =
  components["schemas"]["SessionImportInspectRequest"];
export type SessionImportInspectResponse =
  components["schemas"]["SessionImportInspectResponse"];
export type ProjectCreateRequest =
  components["schemas"]["ProjectCreateRequest"];
export type ProjectArchiveRequest =
  components["schemas"]["ProjectArchiveRequest"];
export type ProjectAuthoringUpdateRequest =
  components["schemas"]["ProjectAuthoringUpdateRequest"];
export type ProjectDocumentResource =
  components["schemas"]["ProjectDocumentResource"];
export type ProjectFromScriptRequest =
  components["schemas"]["ProjectFromScriptRequest"];
export type ProjectFromScriptResource =
  components["schemas"]["ProjectFromScriptResource"];
export type ProjectScriptImportResource =
  components["schemas"]["ProjectScriptImportResource"];
export type ScriptFidelityResource =
  components["schemas"]["ScriptFidelityResource"];
export type ProjectRunSubmitRequest =
  components["schemas"]["ProjectRunSubmitRequest"];
export type ProjectRunSubmitResource =
  components["schemas"]["ProjectRunSubmitResource"];
export type ProjectRunMaterializationResource =
  components["schemas"]["ProjectRunMaterializationResource"];
export type ProjectRunResource = components["schemas"]["ProjectRunResource"];
export type ProjectRunListQuery = components["schemas"]["ProjectRunListQuery"];
export type ProjectRunListResource = components["schemas"]["ProjectRunListResource"];
export type ProjectBatchSubmitRequest = components["schemas"]["ProjectBatchSubmitRequest"];
export type ProjectBatchSubmitResource = components["schemas"]["ProjectBatchSubmitResource"];
export type ProjectBatchListQuery = components["schemas"]["ProjectBatchListQuery"];
export type ProjectBatchListResource = components["schemas"]["ProjectBatchListResource"];
export type ProjectBatchSummaryResource = components["schemas"]["ProjectBatchSummaryResource"];
export type ProjectBatchCommandAction = components["schemas"]["ProjectBatchCommandAction"];
export type ProjectBatchCommandRequest = components["schemas"]["ProjectBatchCommandRequest"];
export type ProjectBatchCommandResource = components["schemas"]["ProjectBatchCommandResource"];
export type ProjectBatchAxisSummaryResource = components["schemas"]["ProjectBatchAxisSummaryResource"];
export type ProjectBatchCasesQuery = components["schemas"]["ProjectBatchCasesQuery"];
export type ProjectBatchCasesResource = components["schemas"]["ProjectBatchCasesResource"];
export type ProjectBatchCaseSummaryResource = components["schemas"]["ProjectBatchCaseSummaryResource"];
export type ProjectRunTaskCancellationRequest =
  components["schemas"]["ProjectRunTaskCancellationRequest"];
export type ProjectRunTaskCancellationResource =
  components["schemas"]["ProjectRunTaskCancellationResource"];
export type ProjectRunTaskRetryRequest =
  components["schemas"]["ProjectRunTaskRetryRequest"];
export type ProjectRunTaskRetryResource =
  components["schemas"]["ProjectRunTaskRetryResource"];
export type SolutionSetDiscoveryPageResource =
  components["schemas"]["SolutionSetDiscoveryPageResource"];
export type SolutionSetDiscoveryPageQuery =
  components["schemas"]["SolutionSetDiscoveryPageQuery"];
export type SolutionSetResource =
  components["schemas"]["SolutionSetResource"];
export type SolutionSetMemberResource =
  components["schemas"]["SolutionSetMemberResource"];
export type SolutionSetArtifactResource =
  components["schemas"]["SolutionSetArtifactResource"];
export type SolutionSetMemberPageResource =
  components["schemas"]["SolutionSetMemberPageResource"];
export type SolutionSetArtifactPageResource =
  components["schemas"]["SolutionSetArtifactPageResource"];
export type SolutionSetMemberPageQuery =
  components["schemas"]["SolutionSetMemberPageQuery"];
export type SolutionSetArtifactPageQuery =
  components["schemas"]["SolutionSetArtifactPageQuery"];
export type SolutionScalarResource =
  components["schemas"]["SolutionScalarResource"];
export type SolutionSetRevision = Extract<SolutionSetResource["revision"], string>;
export type MaterializedDatasetResource =
  components["schemas"]["MaterializedDatasetResource"];
export type MaterializedDatasetSliceEnvelopeResource =
  components["schemas"]["MaterializedDatasetSliceEnvelopeResource"];
export type SavedFieldGeometryResource =
  components["schemas"]["SavedFieldGeometryResource"];
export type SavedFieldGeometryQuery =
  components["schemas"]["SavedFieldGeometryQuery"];
export type SavedAntennaGeometrySourceContextResource =
  components["schemas"]["SavedAntennaGeometrySourceContextResource"];
export type ObservationFrameListQuery =
  components["schemas"]["ObservationFrameListQuery"];
export type ObservationFrameListResource =
  components["schemas"]["ObservationFrameListResource"];
export type ObservationFrameResource =
  components["schemas"]["ObservationFrameResource"];
type GeneratedStructuredCommandRequest =
  components["schemas"]["StructuredCommandRequest"];
type RuntimeCommandIntent = components["schemas"]["RuntimeCommandIntent"];
type MeshBuildCommandRequest = RuntimeCommandIntent & {
  kind: "mesh_build";
  mesh_options?: JsonObject | null;
  mesh_reason?: string | null;
  mesh_target?: components["schemas"]["MeshCommandTarget"] | null;
};
type FdmGridRefreshCommandRequest = RuntimeCommandIntent & {
  kind: "fdm_grid_refresh";
  mesh_options?: JsonObject | null;
};
export type StructuredCommandRequest =
  | Exclude<
      GeneratedStructuredCommandRequest,
      { kind: "mesh_build" } | { kind: "fdm_grid_refresh" }
    >
  | MeshBuildCommandRequest
  | FdmGridRefreshCommandRequest;
export type UniversePatchRequest = components["schemas"]["UniversePatchRequest"];
export type UniverseResource = components["schemas"]["UniverseResource"];
/** Pending managed export: schemas/visualization_state.rs tensor and planar serde fields. */
type VisualizationStyleOverride = components["schemas"]["VisualizationTargetStyleOverride"] & {
  tensor_projection?: string | null;
};
type VisualizationOverride = Omit<components["schemas"]["VisualizationOverrideState"], "style"> & {
  style?: VisualizationStyleOverride | null;
};
type VisualizationTargetEntry = Omit<components["schemas"]["VisualizationTargetRegistryEntry"], "settings" | "override"> & {
  settings: components["schemas"]["VisualizationResolvedTargetSettings"] & { tensor_projection?: string | null };
  override?: VisualizationOverride | null;
};
type VisualizationTargets = Omit<components["schemas"]["VisualizationTargetRegistryState"], "airbox" | "objects" | "parts"> & {
  airbox: VisualizationTargetEntry;
  objects: VisualizationTargetEntry[];
  parts: VisualizationTargetEntry[];
};
type PlanarFieldComponent = components["schemas"]["PlanarFieldComponent"] | import("./tensorFieldProjection").TensorProjectionToken;
export type PlanarFieldOverlayState = Omit<components["schemas"]["PlanarFieldOverlayState"], "component"> & {
  component: PlanarFieldComponent;
};
type PlanarVisualizationPatch = Omit<components["schemas"]["PlanarVisualizationPatch"], "component" | "field_overlays"> & {
  field_overlays?: PlanarFieldOverlayState[] | null;
  component?: PlanarFieldComponent | null;
};
export type VisualizationStatePatch = Omit<components["schemas"]["VisualizationStatePatch"], "overrides" | "planar"> & {
  overrides?: VisualizationOverride[] | null;
  planar?: PlanarVisualizationPatch | null;
};
export type DisplaySelection = components["schemas"]["DisplaySelection"];
export type VisualizationStateResource = Omit<components["schemas"]["VisualizationStateResource"], "overrides" | "targets" | "planar"> & {
  overrides: VisualizationOverride[];
  targets?: VisualizationTargets;
  planar?: Omit<components["schemas"]["PlanarVisualizationState"], "component" | "field_overlays"> & {
    component: PlanarFieldComponent;
    field_overlays?: PlanarFieldOverlayState[];
  };
};
export type ModeCompositionDatasetPatch =
  components["schemas"]["ModeCompositionDatasetPatch"];
export type EigenModeResourceRef =
  components["schemas"]["EigenModeResourceRef"];
export type ModeCompositionLayer =
  components["schemas"]["ModeCompositionLayer"];
export type ModeCompositionLifecycle =
  components["schemas"]["ModeCompositionLifecycle"];
export type ModeCompositionOperation =
  components["schemas"]["ModeCompositionOperation"];
export type ModeCompositionPatch =
  components["schemas"]["ModeCompositionPatch"];
export type ModeCompositionPhaseClock =
  components["schemas"]["ModeCompositionPhaseClock"];
export type ModeCompositionResource =
  components["schemas"]["ModeCompositionResource"];
export type ModeFieldComponent = components["schemas"]["ModeFieldComponent"];
export type ModeFieldNormalization =
  components["schemas"]["ModeFieldNormalization"];
export type ModeFieldRepresentation =
  components["schemas"]["ModeFieldRepresentation"];
export type ModeLayerAnimation = components["schemas"]["ModeLayerAnimation"];
export type ModeLayerAppearance = components["schemas"]["ModeLayerAppearance"];
export type VisualizationClientAckEntry =
  components["schemas"]["VisualizationClientAckEntry"];
export type VisualizationClientAckRequest =
  components["schemas"]["VisualizationClientAckRequest"];
export type VisualizationClientAckResource =
  components["schemas"]["VisualizationClientAckResource"];

export type HysteresisPointSchema = components["schemas"]["HysteresisPointSchema"];
export type HysteresisAdaptiveRefinementCandidateSchema =
  components["schemas"]["HysteresisAdaptiveRefinementCandidateSchema"];
export type HysteresisAdaptiveRefinementSchema =
  components["schemas"]["HysteresisAdaptiveRefinementSchema"];
export type HysteresisBranchSchema = components["schemas"]["HysteresisBranchSchema"];
export type HysteresisMinorLoopSchema =
  components["schemas"]["HysteresisMinorLoopSchema"];
export type HysteresisMetricsSchema = components["schemas"]["HysteresisMetricsSchema"];
export type HysteresisSaturationResultSchema =
  components["schemas"]["HysteresisSaturationResultSchema"];
export type HysteresisSaturationResource =
  components["schemas"]["HysteresisSaturationResource"];
export type HysteresisSettleTraceEntrySchema =
  components["schemas"]["HysteresisSettleTraceEntrySchema"];

export interface FieldVectorIdentityIssue {
  field: string;
  headerValue: number | string | null;
  payloadValue: number | string | null;
}

export interface FieldVectorResponseMetadata {
  carrierId?: string | null;
  carrierRevision?: string | null;
  carrierDigest?: string | null;
  component: string | null;
  domainGenerationId: string | null;
  artifactGenerationId?: string | null;
  encoding: string | null;
  fieldIndexing: string | null;
  fieldGenerationId?: string | null;
  fieldRevision: string | null;
  identityIssues: FieldVectorIdentityIssue[];
  meshTopologyHash: string | null;
  nComp: number | null;
  nodeIndexCount: number | null;
  pointCount: number | null;
  quantityId: string | null;
  scopeId: string | null;
  scopeKind: string | null;
  sourceId?: string | null;
  sourceKind?: string | null;
  sourceRevision?: string | null;
  snapshotId: string | null;
  stageId?: string | null;
  phaseRad?: number | null;
  view?: string | null;
  valueCount: number | null;
}

export type PendingBinaryResourceResult = FieldVectorPendingResponse & {
  etag: string | null;
  status: "pending";
};

type PendingBinaryResourceFor<TMetadata> =
  Extract<TMetadata, FieldVectorResponseMetadata> extends never
    ? never
    : PendingBinaryResourceResult;

type ReadyBinaryResourceResult<TData, TMetadata> = {
      byteLength: number;
      contentRange?: string | null;
      data: TData;
      etag: string | null;
      status: "ready";
    } & (unknown extends TMetadata
      ? { responseMetadata?: TMetadata }
      : { responseMetadata: TMetadata });

export type BinaryResourceResult<TData, TMetadata = unknown> =
  | ReadyBinaryResourceResult<TData, TMetadata>
  | PendingBinaryResourceFor<TMetadata>
  | {
      etag: string | null;
      status: "not-applicable";
    }
  | {
      etag: string | null;
      status: "not-modified";
    };

export interface RequestOptions {
  /**
   * Canonical session, scientific epoch and request_scope_epoch identity used for
   * coalescing and the x-fullmag-session-scope HTTP precondition header.
   * It is never serialized into URLs.
   */
  sessionScopeKey?: string;
  signal?: AbortSignal;
}

export interface BinaryRequestOptions extends RequestOptions {
  /** Optional hard body cap enforced while reading, before binary decoding. */
  maxResponseBytes?: number;
  etag?: string | null;
  range?: string | null;
}

export function isOptionalObjectInteractionKind(
  kind: ObjectInteractionKind,
): boolean {
  return (
    kind === "interfacial_dmi" || kind === "uniaxial_anisotropy"
  );
}

export type OutputStorageDefaultsResource = components["schemas"]["OutputStorageDefaultsResource"];
export type ExecutionProfileCatalogResource = components["schemas"]["ExecutionProfileCatalogResource"];
export type ComputePreviewRequest = components["schemas"]["ComputePreviewRequest"];
export type ExecutionRequestLayer = components["schemas"]["ExecutionLayerSchema"];
export type ComputePreviewResource = components["schemas"]["ComputePreviewResource"];
export type ComputeNodesResource = components["schemas"]["ComputeNodesResource"];
export type ComputeNodesState = components["schemas"]["ComputeNodesState"];
export type ComputeNodePolicyResource = components["schemas"]["ComputeNodePolicyResource"];
export type ComputeNodePolicyUpdateRequest = components["schemas"]["ComputeNodePolicyUpdateRequest"];
export type ExecutionProfileVersionResource = components["schemas"]["ExecutionProfileVersionResource"];
export type ExecutionProfile = ExecutionProfileVersionResource["profile"];
export type PublishExecutionProfileRequest = components["schemas"]["PublishExecutionProfileRequest"];
export type PublishExecutionProfileResource = components["schemas"]["PublishExecutionProfileResource"];
export type ExecutionProfileCatalogQuery = NonNullable<paths["/v2/platform/compute/profiles"]["get"]["parameters"]["query"]>;
export type OutputStorageDefaultsRequest = components["schemas"]["OutputStorageDefaultsRequest"];
export type OutputStorageSettings = components["schemas"]["OutputStorageSettingsSchema"];

/**
 * Request shapes of the workspace database routes. The answers are returned
 * as `unknown` and validated by the start screen's parsers
 * (modules/start/model/workspaceApiTypes.ts) until generated types replace both.
 */
export interface WorkspaceItemsQuery {
  readonly kind?: "all" | "project" | "script" | "result";
  readonly sort?: "last_used" | "name" | "modified" | "use_count";
  readonly search?: string;
  readonly limit?: number;
  readonly includeMissing?: boolean;
}

export interface WorkspaceRootWire {
  readonly path: string;
  readonly kinds: readonly string[];
  readonly recursive: boolean;
  readonly enabled: boolean;
}

export type SavedPlanarQuery = components["schemas"]["SavedPlanarQuery"];
export type SavedPlanarResource = components["schemas"]["SavedPlanarResource"];

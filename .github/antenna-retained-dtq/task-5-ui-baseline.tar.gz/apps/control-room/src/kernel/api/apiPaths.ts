import { openApiV2Path } from "./generated/openapi-v2-paths";

export const API_CONTRACT_VERSION_HEADER = "x-api-contract-version";
export const EXPECTED_API_CONTRACT_VERSION = "1.0.0";

export const PLATFORM_INDEX_PATH = openApiV2Path(
  "/v2/",
);

export const PLATFORM_ASYNCAPI_PATH = openApiV2Path(
  "/v2/platform/asyncapi.json",
);

export const PLATFORM_ASYNCAPI_DOCS_PATH = openApiV2Path(
  "/v2/platform/docs/asyncapi",
);

export const PLATFORM_CAPABILITIES_PATH = openApiV2Path(
  "/v2/platform/capabilities",
);

export const PLATFORM_HEALTH_PATH = openApiV2Path(
  "/v2/platform/health",
);

export const PLATFORM_RUNTIME_SERVICE_PATH = openApiV2Path(
  "/v2/platform/runtime-service",
);

export const PLATFORM_OPENAPI_PATH = openApiV2Path(
  "/v2/platform/openapi.json",
);

export const SESSIONS_PATH = openApiV2Path(
  "/v2/sessions",
);

export const SESSION_EVENTS_WS_PATH = openApiV2Path(
  "/v2/sessions/current/events/ws",
);

export const SESSION_EVENTS_COMMUNICATION_POLICY_PATH = openApiV2Path(
  "/v2/sessions/current/events/communication-policy",
);

export const SESSION_CURRENT_PATH = openApiV2Path(
  "/v2/sessions/current",
);

export const SESSION_STATUS_PATH = openApiV2Path(
  "/v2/sessions/current/status",
);

/** External clients (e.g. Python live scripts) present in the current session. */
export const SESSION_CLIENTS_PATH = openApiV2Path(
  "/v2/sessions/current/clients",
);

export const SESSION_CLIENT_PATH = openApiV2Path(
  "/v2/sessions/current/clients/{client_id}",
);

/** Fullmag instances on this host, one per Control Room origin (ADR 0069). */
export const PLATFORM_INSTANCES_PATH = openApiV2Path("/v2/platform/instances");

export const ANALYSIS_FREQUENCY_RESPONSE_MAGNETIC_SWEEP_V1_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-response/magnetic-sweep.v1",
);

export const ANALYSIS_SPIN_WAVE_GAMMA_V1_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/spin-wave/gamma.v1",
);

export const ANALYSIS_DYNAMIC_STRUCTURE_FACTOR_V1_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/spin-wave/dynamic-structure-factor.v1",
);

export const ANALYSIS_RESULT_DATASETS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets",
);

export const ANALYSIS_RESULT_DATASET_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}",
);

export const ANALYSIS_RESULT_AXIS_VALUES_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/axes/{axis_id}/values",
);

export const ANALYSIS_RESULT_SAMPLES_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/samples",
);

export const ANALYSIS_RESULT_ITEMS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/items",
);

export const ANALYSIS_RESULT_ITEM_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/items/{item_id}",
);

export const ANALYSIS_RESULT_BRANCHES_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/branches",
);

export const ANALYSIS_RESULT_BRANCH_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/branches/{branch_id}",
);

export const ANALYSIS_RESULT_BRANCH_POINTS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/branches/{branch_id}/points",
);

export const ANALYSIS_RESULT_RELATIONS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/relations",
);

export const ANALYSIS_RESULT_RELATION_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/relations/{relation_id}",
);

export const ANALYSIS_RESULT_PROJECTION_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/results/runs/{run_id}/datasets/{dataset_id}/projections/{projection_id}",
);

export const ANALYSIS_OBJECT_TOPOLOGICAL_CHARGE_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/extensions/objects/{object_id}/topological-charge",
);

export const ANALYSIS_FREQUENCY_DOMAIN_MANIFEST_V1_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/manifest.v1",
);

export const ANALYSIS_FREQUENCY_DOMAIN_EIGEN_SPECTRUM_V2_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/eigen/spectrum.v2",
);

export const ANALYSIS_FREQUENCY_DOMAIN_EIGEN_SPECTRUM_V3_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/eigen/spectrum.v3",
);

export const ANALYSIS_FREQUENCY_DOMAIN_EIGEN_FIELD_SWEEP_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/eigen/field-sweep",
);

export const ANALYSIS_FREQUENCY_DOMAIN_EIGEN_BRANCHES_V2_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/eigen/branches.v2",
);

export const ANALYSIS_FREQUENCY_DOMAIN_EIGEN_DISPERSION_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/eigen/dispersion",
);

export const ANALYSIS_FREQUENCY_DOMAIN_EIGEN_DIAGNOSTICS_V2_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/eigen/diagnostics.v2",
);

export const ANALYSIS_FREQUENCY_DOMAIN_EIGEN_MODE_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/eigen/modes/{sample_index}/{mode_index}",
);

export const ANALYSIS_FREQUENCY_DOMAIN_EIGEN_MODE_FIELD_META_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/eigen/mode-field/{sample_index}/{mode_index}/meta",
);

export const ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_MAGNETIC_SWEEP_PATH =
  openApiV2Path(
    "/v2/sessions/current/analysis/frequency-domain/response/magnetic-sweep",
  );

export const ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_PROGRESS_V1_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/response/progress.v1",
);

export const ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_CANCEL_REQUESTED_V1_PATH =
  openApiV2Path(
    "/v2/sessions/current/analysis/frequency-domain/response/cancel-requested.v1",
  );

export const ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_DIAGNOSTICS_V1_PATH =
  openApiV2Path(
    "/v2/sessions/current/analysis/frequency-domain/response/diagnostics/solver.v1",
  );

export const ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_DIAGNOSTICS_COMPAT_V1_PATH =
  openApiV2Path(
    "/v2/sessions/current/analysis/frequency-domain/response/diagnostics.v1",
  );

export const ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_FREQUENCY_POINT_PATH =
  openApiV2Path(
    "/v2/sessions/current/analysis/frequency-domain/response/frequency-points/{frequency_index}",
  );

export const ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_FIELD_META_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/response/field/{frequency_index}/meta",
);

export const ANALYSIS_FREQUENCY_DOMAIN_FMR_PEAKS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/fmr/peaks",
);

export const ANALYSIS_FREQUENCY_DOMAIN_FMR_RESONANCE_FITS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/fmr/resonance-fits",
);

export const ANALYSIS_FREQUENCY_DOMAIN_FMR_KITTEL_FIT_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/frequency-domain/fmr/kittel-fit",
);

export const ANALYSIS_HYSTERESIS_POINTS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/points",
);

export const ANALYSIS_HYSTERESIS_METRICS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/metrics",
);

export const ANALYSIS_HYSTERESIS_SATURATION_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/saturation",
);

export const ANALYSIS_HYSTERESIS_ADAPTIVE_REFINEMENT_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/adaptive-refinement",
);

export const ANALYSIS_HYSTERESIS_BRANCHES_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/branches",
);

export const ANALYSIS_HYSTERESIS_BOOKMARKS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/bookmarks",
);

export const ANALYSIS_HYSTERESIS_FAMILY_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis-family/{stage_id}",
);

export const ANALYSIS_HYSTERESIS_FAMILY_VARIANT_POINTS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis-family/{stage_id}/variants/{variant_id}/points",
);

export const ANALYSIS_HYSTERESIS_MINOR_LOOPS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/minor-loops",
);

export const ANALYSIS_HYSTERESIS_REVERSAL_FIELDS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/reversal-fields",
);

export const ANALYSIS_HYSTERESIS_POINT_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/steps/{point_id}",
);

export const ANALYSIS_HYSTERESIS_STAGE_SETTLE_TRACE_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/settle-trace",
);

export const ANALYSIS_HYSTERESIS_SETTLE_TRACE_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/hysteresis/{stage_id}/steps/{point_id}/settle-trace",
);

export const ANALYSIS_EIGEN_BRANCHES_V2_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/eigen/branches.v2",
);

export const ANALYSIS_EIGEN_DISPERSION_CSV_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/eigen/dispersion.csv",
);

export const ANALYSIS_EIGEN_MODE_V2_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/eigen/modes/{sample_index}/{mode_index}",
);

export const ANALYSIS_EIGEN_SPECTRUM_V2_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/eigen/spectrum.v2",
);

export const ANALYSIS_EIGENMODES_BRANCHES_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/eigenmodes/branches",
);

export const ANALYSIS_EIGENMODES_DISPERSION_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/eigenmodes/dispersion",
);

export const ANALYSIS_EIGENMODE_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/eigenmodes/modes/{mode_id}",
);

export const ANALYSIS_EIGENMODES_SPECTRUM_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/eigenmodes/spectrum",
);

export const DATA_FIELDS_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields",
);

export const DATA_FROZEN_SPINS_RESOLVED_MASK_PATH = openApiV2Path(
  "/v2/sessions/current/data/frozen-spins/resolved-masks/{mask_id}",
);

export const DATA_FIELD_AVAILABILITY_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/availability",
);

export const DATA_PLANAR_FIELD_META_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-monitors/{monitor_id}/meta",
);

export const DATA_PLANAR_FIELD_SCALAR_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-monitors/{monitor_id}/scalar",
);

export const DATA_PLANAR_FIELD_VECTORS_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-monitors/{monitor_id}/vectors",
);

export const DATA_PLANAR_FIELD_EMPTY_MASK_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-monitors/{monitor_id}/empty-mask",
);

export const DATA_PLANAR_FIELD_MESH_OVERLAY_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-monitors/{monitor_id}/mesh-overlay",
);

export const DATA_PLANAR_FIELD_PROBE_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-monitors/{monitor_id}/probe",
);

export const DATA_PLANAR_FIELD_PROFILE_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-monitors/{monitor_id}/profile",
);

export const DATA_PLANAR_FIELD_RENDER_PNG_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-monitors/{monitor_id}/render.png",
);

export const DATA_PLANAR_DEFAULT_FIELD_META_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-default/meta",
);

export const DATA_PLANAR_DEFAULT_FIELD_SCALAR_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-default/scalar",
);

export const DATA_PLANAR_DEFAULT_FIELD_VECTORS_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-default/vectors",
);

export const DATA_PLANAR_DEFAULT_FIELD_EMPTY_MASK_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-default/empty-mask",
);

export const DATA_PLANAR_DEFAULT_FIELD_MESH_OVERLAY_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-default/mesh-overlay",
);

export const DATA_PLANAR_DEFAULT_FIELD_PROBE_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-default/probe",
);

export const DATA_PLANAR_DEFAULT_FIELD_PROFILE_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-default/profile",
);

export const DATA_PLANAR_DEFAULT_FIELD_RENDER_PNG_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/planar-default/render.png",
);

export const DATA_QUANTITIES_PATH = openApiV2Path(
  "/v2/sessions/current/data/quantities",
);

export const DATA_ARTIFACTS_PATH = openApiV2Path(
  "/v2/sessions/current/data/artifacts",
);

export const DATA_ANTENNA_FIELD_SOLUTION_PATH = openApiV2Path(
  "/v2/sessions/current/data/antenna/field-solutions/{solution_id}",
);

export const DATA_ANTENNA_FIELD_SOLUTION_PAYLOAD_PATH = openApiV2Path(
  "/v2/sessions/current/data/antenna/field-solutions/{solution_id}/payloads/{payload_kind}",
);

export const DATA_ANTENNA_STAGE_OUTPUT_CATALOG_PATH = openApiV2Path(
  "/v2/sessions/current/data/antenna/stages/{stage_id}/output-catalog",
);

export const DATA_ANTENNA_EXTERNAL_LEAD_INSPECTION_PATH = openApiV2Path(
  "/v2/sessions/current/data/antenna/stages/{stage_id}/external-lead-inspection",
);

export const DATA_ANTENNA_EXTERNAL_LEAD_INSPECTION_DISPLAY_PATH = openApiV2Path(
  "/v2/sessions/current/data/antenna/stages/{stage_id}/external-lead-inspection/display",
);

export const DATA_ANTENNA_EXTERNAL_LEAD_INSPECTION_PAYLOAD_PATH = openApiV2Path(
  "/v2/sessions/current/data/antenna/stages/{stage_id}/external-lead-inspection/payloads/{payload_kind}",
);

export const DATA_ANTENNA_SOURCE_SPECTRUM_PATH = openApiV2Path(
  "/v2/sessions/current/data/antenna/source-spectra/{output_id}",
);

export const DATA_ANTENNA_SOURCE_SPECTRUM_PAYLOAD_PATH = openApiV2Path(
  "/v2/sessions/current/data/antenna/source-spectra/{output_id}/payloads/{payload_kind}",
);

export const DATA_ARTIFACT_PATH = openApiV2Path(
  "/v2/sessions/current/data/artifacts/{artifact_id}",
);

export const DATA_SCALARS_PATH = openApiV2Path(
  "/v2/sessions/current/data/scalars",
);

export const DATA_TABLE_ROWS_PATH = openApiV2Path(
  "/v2/sessions/current/data/tables/{table_id}/rows",
);

export const DATA_TABLES_PATH = openApiV2Path(
  "/v2/sessions/current/data/tables",
);

export const DATA_TABLE_PATH = openApiV2Path(
  "/v2/sessions/current/data/tables/{table_id}",
);

export const DATA_TABLE_COLUMNS_PATH = openApiV2Path(
  "/v2/sessions/current/data/tables/{table_id}/columns",
);

export const DATA_TABLE_ROWS_BINARY_PATH = openApiV2Path(
  "/v2/sessions/current/data/tables/{table_id}/rows.bin",
);

export const DATA_DOMAIN_META_PATH = openApiV2Path(
  "/v2/sessions/current/data/domain/meta",
);

export const DATA_DOMAIN_FDM_MULTILAYER_LAYOUT_PATH = openApiV2Path(
  "/v2/sessions/current/data/domain/fdm-multilayer-layout",
);

export const DATA_DOMAIN_FDM_MULTILAYER_LAYER_ACTIVE_MASK_PATH = openApiV2Path(
  "/v2/sessions/current/data/domain/fdm-multilayer-layers/{layer_id}/active-mask",
);

export const DATA_DOMAIN_FDM_MULTILAYER_LAYER_REGION_MEMBERSHIP_PATH =
  openApiV2Path(
    "/v2/sessions/current/data/domain/fdm-multilayer-layers/{layer_id}/region-membership",
  );

export const DATA_DOMAIN_FDM_MULTILAYER_LAYER_REGION_MEMBERSHIPS_PATH =
  openApiV2Path(
    "/v2/sessions/current/data/domain/fdm-multilayer-layers/{layer_id}/region-memberships",
  );

export const DATA_DOMAIN_TOPOLOGY_PATH = openApiV2Path(
  "/v2/sessions/current/data/domain/topology",
);

export const DATA_DOMAIN_SLICE_MESH_OVERLAY_PATH = openApiV2Path(
  "/v2/sessions/current/data/domain/slice/mesh-overlay",
);

export const DATA_MATERIAL_FIELDS_PATH = openApiV2Path(
  "/v2/sessions/current/data/material-fields",
);

export const DATA_MATERIAL_FIELD_PATH = openApiV2Path(
  "/v2/sessions/current/data/material-fields/{field_id}",
);

export const DATA_MESH_REGION_MEMBERSHIP_PATH = openApiV2Path(
  "/v2/sessions/current/data/mesh-region-membership/{region_id}",
);

export const DATA_MESH_REGION_MEMBERSHIPS_PATH = openApiV2Path(
  "/v2/sessions/current/data/mesh-region-memberships",
);

export const DATA_FDM_REGION_MEMBERSHIPS_PATH = openApiV2Path(
  "/v2/sessions/current/data/fdm-region-memberships",
);

export const DATA_FDM_REGION_MEMBERSHIP_BINARY_PATH = openApiV2Path(
  "/v2/sessions/current/data/fdm-region-membership",
);

export const DATA_FDM_REGION_MEMBERSHIP_SCOPED_PATH = openApiV2Path(
  "/v2/sessions/current/data/fdm-region-membership/{region_id}",
);

export const DATA_FIELD_META_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/meta",
);

export const DATA_FIELD_PROJECTION_META_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/projection/meta",
);

export const DATA_FIELD_PROJECTION_SCALAR_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/projection/scalar",
);

export const DATA_FIELD_PROJECTION_MATRIX_JSON_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/projection/matrix.json",
);

export const DATA_FIELD_PROJECTION_RENDER_PNG_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/projection/render.png",
);

export const DATA_FIELD_PROJECTION_EMPTY_MASK_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/projection/empty-mask",
);

export const DATA_FIELD_PROJECTION_PROFILE_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/projection/profile",
);

export const DATA_FIELD_SLICE_META_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/samples/slice/meta",
);

export const DATA_FIELD_SLICE_SCALAR_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/samples/slice/scalar",
);

export const DATA_FIELD_SLICE_MATRIX_JSON_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/samples/slice/matrix.json",
);

export const DATA_FIELD_SLICE_RENDER_PNG_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/samples/slice/render.png",
);

export const DATA_FIELD_SLICE_ARROWS_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/samples/slice/arrows",
);

export const DATA_FIELD_VECTOR_PATH = openApiV2Path(
  "/v2/sessions/current/data/fields/{quantity_id}/samples/vector",
);

export const DATA_OBSERVATION_FRAMES_PATH = openApiV2Path(
  "/v2/sessions/current/data/observation-frames",
);

export const DATA_OBSERVATION_FRAME_PATH = openApiV2Path(
  "/v2/sessions/current/data/observation-frames/{frame_id}",
);

export const DATA_OBSERVATION_FRAME_MAGNETIZATION_PATH = openApiV2Path(
  "/v2/sessions/current/data/observation-frames/{frame_id}/magnetization",
);

export const DIAGNOSTICS_ENGINE_LOG_PATH = openApiV2Path(
  "/v2/sessions/current/diagnostics/engine-log",
);

export const DIAGNOSTICS_CPU_PATH = openApiV2Path(
  "/v2/sessions/current/diagnostics/cpu",
);

export const DIAGNOSTICS_GPU_PATH = openApiV2Path(
  "/v2/sessions/current/diagnostics/gpu",
);

export const DIAGNOSTICS_SOLVER_PROFILE_PATH = openApiV2Path(
  "/v2/sessions/current/diagnostics/solver-profile",
);

export const DIAGNOSTICS_RUN_PERFORMANCE_PATH = openApiV2Path(
  "/v2/sessions/current/diagnostics/performance",
);

export const MESHING_SHARED_DOMAIN_MANIFEST_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/manifest",
);

export const MESHING_SHARED_DOMAIN_TOPOLOGY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/topology",
);

export const MESHING_SHARED_DOMAIN_CROSS_SECTION_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/cross-section",
);

export const MESHING_SHARED_DOMAIN_CROSS_SECTION_IMAGE_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/cross-section/image",
);

export const MESHING_SHARED_DOMAIN_CROSS_SECTION_QUALITY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/cross-section/quality",
);

export const MESHING_SUMMARY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/summary",
);

export const MESHING_CAPABILITIES_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/capabilities",
);

export const MESHING_PERIODIC_PAIRS_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/mesh/periodic_pairs.v1",
);

export const MESHING_PERIODIC_PAIRS_BINARY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/mesh/periodic_pairs.v1.bin",
);

export const MESHING_SEMANTICS_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/semantics",
);

export const MESHING_BUILDS_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/builds",
);

export const MESHING_BUILDS_CURRENT_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/builds/current",
);

export const MESHING_BUILDS_LATEST_SUCCESSFUL_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/builds/latest-successful",
);

export const MESHING_OBJECT_TOPOLOGY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/objects/{object_id}/topology",
);

export const MESHING_OBJECT_REPORT_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/objects/{object_id}/report",
);

export const MESHING_OBJECT_QUALITY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/objects/{object_id}/quality",
);

export const MESHING_REGION_QUALITY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/regions/{region_id}/quality",
);

export const MESHING_OBJECT_SIZE_FIELD_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/objects/{object_id}/size-field",
);

export const MESHING_INTERFACE_REPORT_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/interfaces/{interface_id}/report",
);

export const MESHING_INTERFACE_QUALITY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/interfaces/{interface_id}/quality",
);

export const MESHING_UNIVERSE_REPORT_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/universe/report",
);

export const MESHING_UNIVERSE_QUALITY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/universe/quality",
);

export const MESHING_SHARED_DOMAIN_REPORT_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/report",
);

export const MESHING_SHARED_DOMAIN_QUALITY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/quality",
);

export const MESHING_SHARED_DOMAIN_QUALITY_DATA_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/quality/per-element",
);

export const MESHING_SHARED_DOMAIN_QUALITY_GATES_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/quality-gates",
);

export const MESHING_SHARED_DOMAIN_REALIZED_SIZE_FIELDS_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/shared-domain/realized-size-fields",
);

export const MESHING_OBJECT_POLICY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/policies/objects/{object_id}",
);

export const MESHING_INTERFACE_POLICY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/policies/interfaces/{interface_id}",
);

export const MESHING_UNIVERSE_POLICY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/policies/universe",
);

export const MESHING_SHARED_DOMAIN_POLICY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/policies/shared-domain",
);

export const MESHING_PART_TOPOLOGY_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/parts/{part_id}/topology",
);

export const MESHING_HISTOGRAM_BIN_ELEMENTS_PATH = openApiV2Path(
  "/v2/sessions/current/meshing/meshes/{mesh_id}/parts/{part_id}/histogram-bins/{metric}/{bin_index}/elements",
);

export const MODEL_UNIVERSE_PATH = openApiV2Path(
  "/v2/sessions/current/model/universe",
);

export const MODEL_UNIVERSE_FIT_PATH = openApiV2Path(
  "/v2/sessions/current/model/universe/fit",
);

export const MODEL_SCENE_PATH = openApiV2Path(
  "/v2/sessions/current/model/scene",
);

export const MODEL_READINESS_PATH = openApiV2Path(
  "/v2/sessions/current/model/readiness",
);

export const MODEL_FROZEN_SPINS_PATH = openApiV2Path(
  "/v2/sessions/current/model/frozen-spins",
);

export const MODEL_FROZEN_SPIN_PATH = openApiV2Path(
  "/v2/sessions/current/model/frozen-spins/{constraint_id}",
);

export const MODEL_FROZEN_SPINS_PREVIEWS_PATH = openApiV2Path(
  "/v2/sessions/current/model/frozen-spins/previews",
);

export const MODEL_FROZEN_SPINS_PREVIEW_PATH = openApiV2Path(
  "/v2/sessions/current/model/frozen-spins/previews/{preview_id}",
);

export const MODEL_FROZEN_SPINS_PREVIEW_ACTIVATE_PATH = openApiV2Path(
  "/v2/sessions/current/model/frozen-spins/previews/{preview_id}/activate",
);

export const MODEL_PHYSICS_GRAPH_PATH = openApiV2Path(
  "/v2/sessions/current/model/physics-graph",
);

export const MODEL_CURRENT_TRANSPORTS_PATH = openApiV2Path(
  "/v2/sessions/current/model/current-transports",
);

export const MODEL_CURRENT_TRANSPORT_PATH = openApiV2Path(
  "/v2/sessions/current/model/current-transports/{id}",
);

export const MODEL_SPIN_TRANSPORTS_PATH = openApiV2Path(
  "/v2/sessions/current/model/spin-transports",
);

export const MODEL_SPIN_TRANSPORT_PATH = openApiV2Path(
  "/v2/sessions/current/model/spin-transports/{id}",
);

export const MODEL_SPIN_INTERFACES_PATH = openApiV2Path(
  "/v2/sessions/current/model/spin-interfaces",
);

export const MODEL_TRANSPORT_VALIDATION_PATH = openApiV2Path(
  "/v2/sessions/current/model/transport-validation",
);

export const MODEL_SPIN_TORQUES_PATH = openApiV2Path(
  "/v2/sessions/current/model/spin-torques",
);

export const MODEL_SPIN_TORQUE_PATH = openApiV2Path(
  "/v2/sessions/current/model/spin-torques/{id}",
);

export const MODEL_OERSTED_FIELDS_PATH = openApiV2Path(
  "/v2/sessions/current/model/oersted-fields",
);

export const MODEL_OERSTED_FIELD_PATH = openApiV2Path(
  "/v2/sessions/current/model/oersted-fields/{id}",
);

export const MODEL_STUDY_PATH = openApiV2Path(
  "/v2/sessions/current/model/study",
);

export const MODEL_SCRIPT_PATH = openApiV2Path(
  "/v2/sessions/current/model/script",
);

export const MODEL_PLANAR_MONITORS_PATH = openApiV2Path(
  "/v2/sessions/current/model/planar-monitors",
);

export const MODEL_PLANAR_MONITOR_PATH = openApiV2Path(
  "/v2/sessions/current/model/planar-monitors/{monitor_id}",
);

export const ANALYSIS_ANALYTIC_REFERENCE_MODELS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/references/analytic-models",
);

export const ANALYSIS_POSTPROCESSING_DEFINITIONS_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/postprocessing/definitions",
);

export const ANALYSIS_POSTPROCESSING_DEFINITION_PATH = openApiV2Path(
  "/v2/sessions/current/analysis/postprocessing/definitions/{definition_id}",
);

export const MODEL_PLANAR_MONITOR_DUPLICATE_PATH = openApiV2Path(
  "/v2/sessions/current/model/planar-monitors/{monitor_id}/duplicate",
);

export const MODEL_TRANSACTIONS_PATH = openApiV2Path(
  "/v2/sessions/current/model/transactions",
);

export const MODEL_SYNCS_PATH = openApiV2Path(
  "/v2/sessions/current/model/syncs",
);

export const MODEL_OBJECTS_PATH = openApiV2Path(
  "/v2/sessions/current/model/objects",
);

export const MODEL_OBJECT_PATH = openApiV2Path(
  "/v2/sessions/current/model/objects/{object_id}",
);

export const MODEL_OBJECT_REGIONS_PATH = openApiV2Path(
  "/v2/sessions/current/model/objects/{object_id}/regions",
);

export const MODEL_OBJECT_REGIONS_REORDER_PATH = openApiV2Path(
  "/v2/sessions/current/model/objects/{object_id}/regions/reorder",
);

export const MODEL_OBJECT_REGION_PATH = openApiV2Path(
  "/v2/sessions/current/model/objects/{object_id}/regions/{region_id}",
);

export const MODEL_OBJECT_REGION_DUPLICATE_PATH = openApiV2Path(
  "/v2/sessions/current/model/objects/{object_id}/regions/{region_id}/duplicate",
);

export const MODEL_OBJECT_GEOMETRY_PATH = openApiV2Path(
  "/v2/sessions/current/model/objects/{object_id}/geometry",
);

export const MODEL_OBJECT_INTERACTION_PATH = openApiV2Path(
  "/v2/sessions/current/model/objects/{object_id}/interactions/{interaction_kind}",
);

export const MODEL_MATERIAL_PATH = openApiV2Path(
  "/v2/sessions/current/model/materials/{material_id}",
);

export const MODEL_MAGNETIZATION_ASSET_PATH = openApiV2Path(
  "/v2/sessions/current/model/magnetization-assets/{asset_id}",
);

export const MODEL_REGIONS_PATH = openApiV2Path(
  "/v2/sessions/current/model/regions",
);

export const MODEL_REALIZED_REGIONS_PATH = openApiV2Path(
  "/v2/sessions/current/model/realized-regions",
);

export const MODEL_REGION_DIAGNOSTICS_PATH = openApiV2Path(
  "/v2/sessions/current/model/region-diagnostics",
);

export const MODEL_MATERIAL_FIELDS_PATH = openApiV2Path(
  "/v2/sessions/current/model/material-fields",
);

export const MODEL_COUPLINGS_PATH = openApiV2Path(
  "/v2/sessions/current/model/couplings",
);

export const MODEL_COUPLING_PATH = openApiV2Path(
  "/v2/sessions/current/model/couplings/{coupling_id}",
);

export const MODEL_FIELD_DRIVES_PATH = openApiV2Path(
  "/v2/sessions/current/model/field-drives",
);

export const MODEL_FIELD_DRIVE_PATH = openApiV2Path(
  "/v2/sessions/current/model/field-drives/{drive_id}",
);

export const MODEL_REGION_PATH = openApiV2Path(
  "/v2/sessions/current/model/regions/{region_id}",
);

export const MODEL_GEOMETRY_CAPABILITIES_PATH = openApiV2Path(
  "/v2/sessions/current/model/geometry/capabilities",
);

export const MODEL_GEOMETRY_VALIDATION_PATH = openApiV2Path(
  "/v2/sessions/current/model/geometry/validation",
);

export const MODEL_GEOMETRY_DIAGNOSTICS_PATH = openApiV2Path(
  "/v2/sessions/current/model/geometry/diagnostics",
);

export const MODEL_GEOMETRY_DIAGNOSTIC_PATH = openApiV2Path(
  "/v2/sessions/current/model/geometry/diagnostics/{diagnostic_id}",
);

export const MODEL_GEOMETRY_REALIZATIONS_PATH = openApiV2Path(
  "/v2/sessions/current/model/geometry/realizations",
);

export const MODEL_GEOMETRY_REALIZATION_CURRENT_PATH = openApiV2Path(
  "/v2/sessions/current/model/geometry/realizations/current",
);

export const VISUALIZATION_STATE_PATH = openApiV2Path(
  "/v2/sessions/current/visualization/state",
);

export const VISUALIZATION_DISPLAY_PATH = openApiV2Path(
  "/v2/sessions/current/visualization/display",
);

export const VISUALIZATION_CLIENT_ACKS_PATH = openApiV2Path(
  "/v2/sessions/current/visualization/client-acks",
);

export const VISUALIZATION_MODE_COMPOSITION_ACTIVE_PATH = openApiV2Path(
  "/v2/sessions/current/visualization/mode-compositions/active",
);

export const WORKSPACE_LAYOUT_PATH = openApiV2Path(
  "/v2/sessions/current/workspace/layout",
);

export const WORKSPACE_RIBBON_PATH = openApiV2Path(
  "/v2/sessions/current/workspace/ribbon",
);

export const WORKSPACE_SELECTION_PATH = openApiV2Path(
  "/v2/sessions/current/workspace/selection",
);

export const WORKSPACE_TREE_ACTIVE_NODE_PATH = openApiV2Path(
  "/v2/sessions/current/workspace/tree/active-node",
);

export const SIMULATION_PREPARATION_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/preparation",
);

export const SIMULATION_PREPARATION_MATERIALIZATION_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/preparation/materialization",
);

export const SIMULATION_COMMANDS_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/commands",
);

export const SIMULATION_COMMAND_DETAIL_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/commands/{command_id}",
);

export const SIMULATION_COMMAND_FAILURE_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/commands/{command_id}/failure",
);

export const SIMULATION_OBJECT_METRICS_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/objects/{object_id}/metrics",
);

export const SIMULATION_RUN_CURRENT_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/runs/current",
);

export const SIMULATION_RUN_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/runs/{run_id}",
);

export const SIMULATION_STAGES_EXECUTION_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/stages/execution",
);

export const SIMULATION_STAGE_HYSTERESIS_PLAN_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/stages/{stage_id}/hysteresis/plan",
);

export const SIMULATION_STAGE_HYSTERESIS_PROTOCOL_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/stages/{stage_id}/hysteresis/protocol",
);

export const SIMULATION_STAGE_HYSTERESIS_SATURATION_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/stages/{stage_id}/hysteresis/saturation",
);

export const SIMULATION_STAGE_HYSTERESIS_ORIENTATION_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/stages/{stage_id}/hysteresis/orientation",
);

export const SIMULATION_STAGE_HYSTERESIS_SETTLE_PIPELINE_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/stages/{stage_id}/hysteresis/settle-pipeline",
);

export const SIMULATION_STAGE_HYSTERESIS_EXECUTION_TREE_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/stages/{stage_id}/hysteresis/execution-tree",
);

export const SIMULATION_STAGE_HYSTERESIS_PROGRESS_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/stages/{stage_id}/hysteresis/progress",
);

export const SIMULATION_SOLVER_STATUS_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/solver/status",
);

export const SIMULATION_SOLVER_ENERGIES_CURRENT_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/solver/energies/current",
);

export const SIMULATION_SOLVER_ENERGIES_HISTORY_PATH = openApiV2Path(
  "/v2/sessions/current/simulation/solver/energies/history",
);

export const PERSISTENCE_CHECKPOINTS_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/checkpoints",
);

export const PERSISTENCE_CHECKPOINT_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/checkpoints/{checkpoint_id}",
);

export const PERSISTENCE_CHECKPOINT_RESTORE_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/checkpoints/{checkpoint_id}/restore",
);

export const PERSISTENCE_EXPORTS_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/exports",
);

export const PERSISTENCE_FIELD_STATE_EXPORTS_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/field-states/exports",
);

export const PERSISTENCE_FIELD_STATE_IMPORTS_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/field-states/imports",
);

export const PERSISTENCE_FIELD_STATE_IMPORT_INSPECTIONS_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/field-states/imports/inspections",
);

export const PERSISTENCE_IMPORTS_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/imports",
);

export const PERSISTENCE_IMPORT_INSPECTIONS_PATH = openApiV2Path(
  "/v2/persistence/imports/inspections",
);

export const PERSISTENCE_ASSET_IMPORT_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/assets/import",
);

export const PERSISTENCE_PROJECTS_PATH = openApiV2Path(
  "/v2/persistence/projects",
);

export const PERSISTENCE_PROJECT_OPEN_PATH = openApiV2Path(
  "/v2/persistence/projects/open",
);
export const PERSISTENCE_PROJECT_AUTHORING_PATH = openApiV2Path(
  "/v2/persistence/projects/authoring",
);
export const PERSISTENCE_PROJECT_FROM_SCRIPT_PATH = openApiV2Path(
  "/v2/persistence/projects/from-script",
);

export const PROJECT_RUN_INTENT_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/run-intent",
);

export const PROJECT_RUN_ANTENNA_INSPECTIONS_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/antenna-inspections",
);

export const PROJECT_RUN_ANTENNA_INSPECTION_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/antenna-inspections/{step_id}",
);

export const PROJECT_RUN_ANTENNA_INSPECTION_PAYLOAD_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/antenna-inspections/{step_id}/payloads/{payload_kind}",
);

export const PROJECT_RUN_SUBMIT_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs",
);

export const PROJECT_BATCHES_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/batches",
);

export const PROJECT_BATCH_CASES_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/batches/{batch_id}/cases",
);

export const PROJECT_BATCH_COMMANDS_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/batches/{batch_id}/commands",
);

export const PROJECT_RUN_MATERIALIZATION_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/materialization",
);

export const PROJECT_RUN_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}",
);

export const PROJECT_SOLUTION_SET_DISCOVERY_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets",
);

export const PROJECT_SOLUTION_SET_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}",
);

export const PROJECT_SOLUTION_SET_MEMBERS_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members",
);

export const PROJECT_SOLUTION_SET_ARTIFACTS_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts",
);

export const PROJECT_MATERIALIZED_DATASET_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/materialized-dataset",
);

export const PROJECT_SOLUTION_SCALAR_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/scalar",
);

export const PROJECT_MATERIALIZED_DATASET_SLICE_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/materialized-dataset/slice",
);

export const PROJECT_SAVED_FIELD_GEOMETRY_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/saved-field-geometry",
);
export const PROJECT_SAVED_FIELD_TOPOLOGY_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/saved-field-geometry/topology",
);
export const PROJECT_SAVED_FIELD_SUPPORT_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/saved-field-geometry/support",
);

export const PROJECT_RUN_TASK_CANCELLATION_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/tasks/{task_id}/cancellation",
);
export const PROJECT_RUN_TASK_RETRY_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/tasks/{task_id}/retry",
);

export const PERSISTENCE_RECOVERY_PATH = openApiV2Path(
  "/v2/sessions/current/persistence/recovery",
);

export const PLATFORM_OUTPUT_STORAGE_PATH = openApiV2Path("/v2/platform/output-storage");

// Workspace database routes (start screen).
export const WORKSPACE_ITEM_PLAYBACK_PATH = openApiV2Path("/v2/workspace/items/{id}/playback");
export const WORKSPACE_ITEM_PLAYBACK_GEOMETRY_PATH = openApiV2Path("/v2/workspace/items/{id}/playback/geometry");
export const WORKSPACE_ITEM_PLAYBACK_FRAME_PATH = openApiV2Path("/v2/workspace/items/{id}/playback/frames/{frame_index}");


export const WORKSPACE_ITEMS_PATH = openApiV2Path("/v2/workspace/items");
export const WORKSPACE_ITEM_PATH = openApiV2Path("/v2/workspace/items/{id}");
export const WORKSPACE_ITEM_THUMBNAIL_PATH = openApiV2Path(
  "/v2/workspace/items/{id}/thumbnail",
);
export const WORKSPACE_ITEM_ARCHIVE_PATH = openApiV2Path(
  "/v2/workspace/items/{id}/archive",
);
export const WORKSPACE_ITEM_PIN_PATH = openApiV2Path("/v2/workspace/items/{id}/pin");
export const WORKSPACE_ITEM_FORGET_PATH = openApiV2Path("/v2/workspace/items/{id}/forget");
export const WORKSPACE_ITEM_HISTORY_PATH = openApiV2Path(
  "/v2/workspace/items/{id}/history",
);
export const WORKSPACE_ITEM_FRAMES_PATH = openApiV2Path(
  "/v2/workspace/items/{id}/frames",
);
export const WORKSPACE_SETTING_PATH = openApiV2Path("/v2/workspace/settings/{key}");
export const WORKSPACE_ROOTS_PATH = openApiV2Path("/v2/workspace/roots");
export const WORKSPACE_SCAN_PATH = openApiV2Path("/v2/workspace/scan");

/** Absolute URL that downloads a result folder as a zip (a navigation, not a fetch). */
export function workspaceItemArchiveUrl(baseUrl: string, id: string): string {
  return `${baseUrl}${WORKSPACE_ITEM_ARCHIVE_PATH.replace("{id}", encodeURIComponent(id))}`;
}

/** Absolute URL of an item's thumbnail, for an <img>; the id is path-encoded. */
export function workspaceItemThumbnailUrl(baseUrl: string, id: string): string {
  return `${baseUrl}${WORKSPACE_ITEM_THUMBNAIL_PATH.replace("{id}", encodeURIComponent(id))}`;
}
export const PLATFORM_COMPUTE_ALLOCATION_PATH = openApiV2Path("/v2/platform/compute/allocations/{allocation_id}");
export const PLATFORM_COMPUTE_QUEUE_PATH = openApiV2Path("/v2/platform/compute/queue");
export const PLATFORM_COMPUTE_PROFILES_PATH = openApiV2Path("/v2/platform/compute/profiles");
export const PLATFORM_COMPUTE_PREVIEW_PATH = openApiV2Path("/v2/platform/compute/preview");
export const PLATFORM_COMPUTE_NODES_PATH = openApiV2Path("/v2/platform/compute/nodes");
export const PLATFORM_COMPUTE_NODE_PATH = openApiV2Path("/v2/platform/compute/nodes/{node_id}");
export const PLATFORM_COMPUTE_NODE_POLICY_PATH = openApiV2Path("/v2/platform/compute/nodes/{node_id}/policy");

export const PROJECT_SAVED_PLANAR_META_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/saved-planar/meta",
);

export const PROJECT_SAVED_PLANAR_SCALAR_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/saved-planar/scalar",
);

export const PROJECT_SAVED_PLANAR_VECTORS_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/saved-planar/vectors",
);

export const PROJECT_SAVED_PLANAR_OCCUPANCY_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/saved-planar/occupancy",
);

export const PROJECT_SAVED_PLANAR_PROBE_PATH = openApiV2Path(
  "/v2/persistence/projects/{project_id}/runs/{run_id}/solution-sets/{solution_set_id}/revisions/{revision}/members/{member_id}/artifacts/{artifact_id}/saved-planar/probe",
);

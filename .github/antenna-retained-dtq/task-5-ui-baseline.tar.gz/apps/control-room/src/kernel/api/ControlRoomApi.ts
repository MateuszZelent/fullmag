import { savedPlanarFrameMatches } from "./savedPlanarIdentity";
import type { SavedPlanarQuery, SavedPlanarResource } from "./apiTypes";
import { PROJECT_SAVED_PLANAR_META_PATH, PROJECT_SAVED_PLANAR_SCALAR_PATH, PROJECT_SAVED_PLANAR_VECTORS_PATH, PROJECT_SAVED_PLANAR_OCCUPANCY_PATH } from "./apiPaths";
import { WORKSPACE_ITEM_PLAYBACK_PATH, WORKSPACE_ITEM_PLAYBACK_FRAME_PATH, WORKSPACE_ITEM_PLAYBACK_GEOMETRY_PATH } from "./apiPaths";
import type { SavedPlaybackResource } from "./savedResultsPlayback";
import { artifactFieldResponseIdentityError } from "./artifactFieldResponseIdentity";
import { objectMeshPolicyWireRequest } from "./objectMeshPolicyWire";
import { API_INSTANCE_HEADER, isApiInstanceId, resolveApiInstancePin } from "./apiInstancePin";
import {
  ANALYSIS_FREQUENCY_DOMAIN_MANIFEST_V1_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_EIGEN_BRANCHES_V2_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_EIGEN_DIAGNOSTICS_V2_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_EIGEN_DISPERSION_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_EIGEN_FIELD_SWEEP_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_EIGEN_MODE_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_EIGEN_MODE_FIELD_META_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_EIGEN_SPECTRUM_V2_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_EIGEN_SPECTRUM_V3_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_FMR_KITTEL_FIT_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_FMR_PEAKS_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_FMR_RESONANCE_FITS_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_DIAGNOSTICS_V1_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_FIELD_META_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_FREQUENCY_POINT_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_MAGNETIC_SWEEP_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_CANCEL_REQUESTED_V1_PATH,
  ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_PROGRESS_V1_PATH,
  ANALYSIS_FREQUENCY_RESPONSE_MAGNETIC_SWEEP_V1_PATH,
  ANALYSIS_DYNAMIC_STRUCTURE_FACTOR_V1_PATH,
  ANALYSIS_RESULT_AXIS_VALUES_PATH,
  ANALYSIS_RESULT_BRANCH_PATH,
  ANALYSIS_RESULT_BRANCH_POINTS_PATH,
  ANALYSIS_RESULT_BRANCHES_PATH,
  ANALYSIS_RESULT_DATASET_PATH,
  ANALYSIS_RESULT_DATASETS_PATH,
  ANALYSIS_RESULT_ITEM_PATH,
  ANALYSIS_RESULT_ITEMS_PATH,
  ANALYSIS_RESULT_PROJECTION_PATH,
  ANALYSIS_RESULT_RELATION_PATH,
  ANALYSIS_RESULT_RELATIONS_PATH,
  ANALYSIS_RESULT_SAMPLES_PATH,
  ANALYSIS_SPIN_WAVE_GAMMA_V1_PATH,
  ANALYSIS_OBJECT_TOPOLOGICAL_CHARGE_PATH,
  ANALYSIS_HYSTERESIS_POINTS_PATH,
  ANALYSIS_HYSTERESIS_METRICS_PATH,
  ANALYSIS_HYSTERESIS_SATURATION_PATH,
  ANALYSIS_HYSTERESIS_ADAPTIVE_REFINEMENT_PATH,
  ANALYSIS_HYSTERESIS_BRANCHES_PATH,
  ANALYSIS_HYSTERESIS_BOOKMARKS_PATH,
  ANALYSIS_HYSTERESIS_FAMILY_PATH,
  ANALYSIS_HYSTERESIS_FAMILY_VARIANT_POINTS_PATH,
  ANALYSIS_HYSTERESIS_MINOR_LOOPS_PATH,
  ANALYSIS_HYSTERESIS_REVERSAL_FIELDS_PATH,
  ANALYSIS_HYSTERESIS_POINT_PATH,
  ANALYSIS_HYSTERESIS_STAGE_SETTLE_TRACE_PATH,
  ANALYSIS_HYSTERESIS_SETTLE_TRACE_PATH,
  API_CONTRACT_VERSION_HEADER,
  DATA_FIELD_AVAILABILITY_PATH,
  DATA_FIELDS_PATH,
  DATA_FROZEN_SPINS_RESOLVED_MASK_PATH,
  DATA_QUANTITIES_PATH,
  DATA_ARTIFACT_PATH,
  DATA_ARTIFACTS_PATH,
  DATA_ANTENNA_FIELD_SOLUTION_PATH,
  DATA_ANTENNA_FIELD_SOLUTION_PAYLOAD_PATH,
  DATA_ANTENNA_EXTERNAL_LEAD_INSPECTION_PATH,
  DATA_ANTENNA_EXTERNAL_LEAD_INSPECTION_DISPLAY_PATH,
  DATA_ANTENNA_EXTERNAL_LEAD_INSPECTION_PAYLOAD_PATH,
  DATA_ANTENNA_STAGE_OUTPUT_CATALOG_PATH,
  DATA_ANTENNA_SOURCE_SPECTRUM_PATH,
  DATA_ANTENNA_SOURCE_SPECTRUM_PAYLOAD_PATH,
  DATA_DOMAIN_META_PATH,
  DATA_DOMAIN_FDM_MULTILAYER_LAYOUT_PATH,
  DATA_DOMAIN_FDM_MULTILAYER_LAYER_ACTIVE_MASK_PATH,
  DATA_DOMAIN_FDM_MULTILAYER_LAYER_REGION_MEMBERSHIP_PATH,
  DATA_DOMAIN_FDM_MULTILAYER_LAYER_REGION_MEMBERSHIPS_PATH,
  DATA_DOMAIN_TOPOLOGY_PATH,
  DATA_FDM_REGION_MEMBERSHIP_BINARY_PATH,
  DATA_FDM_REGION_MEMBERSHIP_SCOPED_PATH,
  DATA_FDM_REGION_MEMBERSHIPS_PATH,
  DATA_FIELD_META_PATH,
  DATA_PLANAR_FIELD_EMPTY_MASK_PATH,
  DATA_PLANAR_FIELD_MESH_OVERLAY_PATH,
  DATA_PLANAR_FIELD_META_PATH,
  DATA_PLANAR_FIELD_PROBE_PATH,
  DATA_PLANAR_FIELD_PROFILE_PATH,
  DATA_PLANAR_FIELD_RENDER_PNG_PATH,
  DATA_PLANAR_FIELD_SCALAR_PATH,
  DATA_PLANAR_FIELD_VECTORS_PATH,
  DATA_PLANAR_DEFAULT_FIELD_EMPTY_MASK_PATH,
  DATA_PLANAR_DEFAULT_FIELD_MESH_OVERLAY_PATH,
  DATA_PLANAR_DEFAULT_FIELD_META_PATH,
  DATA_PLANAR_DEFAULT_FIELD_PROBE_PATH,
  DATA_PLANAR_DEFAULT_FIELD_PROFILE_PATH,
  DATA_PLANAR_DEFAULT_FIELD_RENDER_PNG_PATH,
  DATA_PLANAR_DEFAULT_FIELD_SCALAR_PATH,
  DATA_PLANAR_DEFAULT_FIELD_VECTORS_PATH,
  DATA_FIELD_VECTOR_PATH,
  DATA_OBSERVATION_FRAME_MAGNETIZATION_PATH,
  DATA_OBSERVATION_FRAME_PATH,
  DATA_OBSERVATION_FRAMES_PATH,
  DATA_MESH_REGION_MEMBERSHIP_PATH,
  DATA_MESH_REGION_MEMBERSHIPS_PATH,
  EXPECTED_API_CONTRACT_VERSION,
  DATA_SCALARS_PATH,
  DATA_TABLE_COLUMNS_PATH,
  DATA_TABLE_PATH,
  DATA_TABLE_ROWS_PATH,
  DATA_TABLE_ROWS_BINARY_PATH,
  DATA_TABLES_PATH,
  DIAGNOSTICS_CPU_PATH,
  DIAGNOSTICS_ENGINE_LOG_PATH,
  DIAGNOSTICS_GPU_PATH,
  DIAGNOSTICS_RUN_PERFORMANCE_PATH,
  DIAGNOSTICS_SOLVER_PROFILE_PATH,
  MESHING_CAPABILITIES_PATH,
  MESHING_BUILDS_PATH,
  MESHING_BUILDS_CURRENT_PATH,
  MESHING_BUILDS_LATEST_SUCCESSFUL_PATH,
  MESHING_HISTOGRAM_BIN_ELEMENTS_PATH,
  MESHING_PERIODIC_PAIRS_PATH,
  MESHING_PERIODIC_PAIRS_BINARY_PATH,
  MESHING_SHARED_DOMAIN_CROSS_SECTION_IMAGE_PATH,
  MESHING_SHARED_DOMAIN_CROSS_SECTION_PATH,
  MESHING_SHARED_DOMAIN_CROSS_SECTION_QUALITY_PATH,
  MESHING_SEMANTICS_PATH,
  MESHING_SHARED_DOMAIN_POLICY_PATH,
  MESHING_SHARED_DOMAIN_QUALITY_DATA_PATH,
  MESHING_SHARED_DOMAIN_QUALITY_GATES_PATH,
  MESHING_SHARED_DOMAIN_QUALITY_PATH,
  MESHING_SHARED_DOMAIN_REALIZED_SIZE_FIELDS_PATH,
  MESHING_SHARED_DOMAIN_REPORT_PATH,
  MESHING_OBJECT_POLICY_PATH,
  MESHING_OBJECT_TOPOLOGY_PATH,
  MESHING_OBJECT_QUALITY_PATH,
  MESHING_OBJECT_REPORT_PATH,
  MESHING_OBJECT_SIZE_FIELD_PATH,
  MESHING_PART_TOPOLOGY_PATH,
  MESHING_REGION_QUALITY_PATH,
  MESHING_SHARED_DOMAIN_MANIFEST_PATH,
  MESHING_SHARED_DOMAIN_TOPOLOGY_PATH,
  MESHING_SUMMARY_PATH,
  MESHING_UNIVERSE_POLICY_PATH,
  MESHING_UNIVERSE_QUALITY_PATH,
  MESHING_UNIVERSE_REPORT_PATH,
  MODEL_GEOMETRY_CAPABILITIES_PATH,
  MODEL_GEOMETRY_DIAGNOSTIC_PATH,
  MODEL_GEOMETRY_DIAGNOSTICS_PATH,
  MODEL_GEOMETRY_REALIZATION_CURRENT_PATH,
  MODEL_GEOMETRY_REALIZATIONS_PATH,
  MODEL_GEOMETRY_VALIDATION_PATH,
  MODEL_READINESS_PATH,
  MODEL_FROZEN_SPIN_PATH,
  MODEL_FROZEN_SPINS_PATH,
  MODEL_FROZEN_SPINS_PREVIEW_ACTIVATE_PATH,
  MODEL_FROZEN_SPINS_PREVIEW_PATH,
  MODEL_FROZEN_SPINS_PREVIEWS_PATH,
  MODEL_COUPLINGS_PATH,
  MODEL_CURRENT_TRANSPORT_PATH,
  MODEL_CURRENT_TRANSPORTS_PATH,
  MODEL_FIELD_DRIVE_PATH,
  MODEL_FIELD_DRIVES_PATH,
  MODEL_SPIN_TRANSPORT_PATH,
  MODEL_SPIN_TRANSPORTS_PATH,
  MODEL_SPIN_INTERFACES_PATH,
  MODEL_TRANSPORT_VALIDATION_PATH,
  MODEL_MAGNETIZATION_ASSET_PATH,
  MODEL_MATERIAL_FIELDS_PATH,
  MODEL_MATERIAL_PATH,
  MODEL_OBJECT_GEOMETRY_PATH,
  MODEL_OBJECT_INTERACTION_PATH,
  MODEL_OBJECT_PATH,
  MODEL_OBJECT_REGION_DUPLICATE_PATH,
  MODEL_OBJECT_REGION_PATH,
  MODEL_OBJECT_REGIONS_REORDER_PATH,
  MODEL_OBJECT_REGIONS_PATH,
  MODEL_OBJECTS_PATH,
  MODEL_PHYSICS_GRAPH_PATH,
  ANALYSIS_POSTPROCESSING_DEFINITION_PATH,
  ANALYSIS_ANALYTIC_REFERENCE_MODELS_PATH,
  ANALYSIS_POSTPROCESSING_DEFINITIONS_PATH,
  MODEL_PLANAR_MONITOR_DUPLICATE_PATH,
  MODEL_PLANAR_MONITOR_PATH,
  MODEL_PLANAR_MONITORS_PATH,
  MODEL_REGION_PATH,
  MODEL_REGION_DIAGNOSTICS_PATH,
  MODEL_REALIZED_REGIONS_PATH,
  MODEL_REGIONS_PATH,
  MODEL_SCENE_PATH,
  MODEL_SPIN_TORQUE_PATH,
  MODEL_SPIN_TORQUES_PATH,
  MODEL_OERSTED_FIELD_PATH,
  MODEL_OERSTED_FIELDS_PATH,
  MODEL_SCRIPT_PATH,
  MODEL_STUDY_PATH,
  MODEL_TRANSACTIONS_PATH,
  MODEL_SYNCS_PATH,
  MODEL_UNIVERSE_PATH,
  PERSISTENCE_ASSET_IMPORT_PATH,
  PERSISTENCE_CHECKPOINT_PATH,
  PERSISTENCE_CHECKPOINT_RESTORE_PATH,
  PERSISTENCE_CHECKPOINTS_PATH,
  PERSISTENCE_EXPORTS_PATH,
  PERSISTENCE_FIELD_STATE_EXPORTS_PATH,
  PERSISTENCE_FIELD_STATE_IMPORT_INSPECTIONS_PATH,
  PERSISTENCE_FIELD_STATE_IMPORTS_PATH,
  PERSISTENCE_IMPORT_INSPECTIONS_PATH,
  PERSISTENCE_IMPORTS_PATH,
  PERSISTENCE_PROJECT_OPEN_PATH,
  PERSISTENCE_PROJECT_AUTHORING_PATH,
  PERSISTENCE_PROJECT_FROM_SCRIPT_PATH,
  PERSISTENCE_PROJECTS_PATH,
  PROJECT_MATERIALIZED_DATASET_PATH,
  PROJECT_MATERIALIZED_DATASET_SLICE_PATH,
  PROJECT_SOLUTION_SCALAR_PATH,
  PROJECT_SAVED_FIELD_GEOMETRY_PATH,
  PROJECT_SAVED_FIELD_TOPOLOGY_PATH,
  PROJECT_SAVED_FIELD_SUPPORT_PATH,
  PROJECT_SOLUTION_SET_ARTIFACTS_PATH,
  PROJECT_SOLUTION_SET_MEMBERS_PATH,
  PROJECT_SOLUTION_SET_PATH,
  PROJECT_SOLUTION_SET_DISCOVERY_PATH,
  PROJECT_RUN_SUBMIT_PATH,
  PROJECT_RUN_MATERIALIZATION_PATH,
  PROJECT_RUN_PATH,
  PROJECT_RUN_TASK_CANCELLATION_PATH,
  PROJECT_RUN_TASK_RETRY_PATH,
  PROJECT_BATCHES_PATH,
  PROJECT_BATCH_CASES_PATH,
  PROJECT_BATCH_COMMANDS_PATH,
  PLATFORM_CAPABILITIES_PATH,
  PLATFORM_OUTPUT_STORAGE_PATH,
  PLATFORM_COMPUTE_PROFILES_PATH,
  PLATFORM_COMPUTE_PREVIEW_PATH,
  PLATFORM_COMPUTE_NODES_PATH,
  PLATFORM_COMPUTE_NODE_POLICY_PATH,
  PLATFORM_HEALTH_PATH,
  PLATFORM_INSTANCES_PATH,
  PLATFORM_RUNTIME_SERVICE_PATH,
  WORKSPACE_ITEMS_PATH,
  WORKSPACE_ITEM_FORGET_PATH,
  WORKSPACE_ITEM_FRAMES_PATH,
  WORKSPACE_ITEM_HISTORY_PATH,
  WORKSPACE_ITEM_PATH,
  WORKSPACE_ITEM_PIN_PATH,
  WORKSPACE_ROOTS_PATH,
  WORKSPACE_SETTING_PATH,
  WORKSPACE_SCAN_PATH,
  workspaceItemArchiveUrl,
  workspaceItemThumbnailUrl,
  SESSIONS_PATH,
  SESSION_EVENTS_COMMUNICATION_POLICY_PATH,
  SESSION_STATUS_PATH,
  SIMULATION_COMMAND_DETAIL_PATH,
  SIMULATION_COMMAND_FAILURE_PATH,
  SIMULATION_COMMANDS_PATH,
  SIMULATION_OBJECT_METRICS_PATH,
  SIMULATION_PREPARATION_MATERIALIZATION_PATH,
  SIMULATION_PREPARATION_PATH,
  SIMULATION_RUN_CURRENT_PATH,
  SIMULATION_RUN_PATH,
  SIMULATION_SOLVER_ENERGIES_CURRENT_PATH,
  SIMULATION_SOLVER_ENERGIES_HISTORY_PATH,
  SIMULATION_SOLVER_STATUS_PATH,
  SIMULATION_STAGE_HYSTERESIS_EXECUTION_TREE_PATH,
  SIMULATION_STAGE_HYSTERESIS_ORIENTATION_PATH,
  SIMULATION_STAGE_HYSTERESIS_PLAN_PATH,
  SIMULATION_STAGE_HYSTERESIS_PROGRESS_PATH,
  SIMULATION_STAGE_HYSTERESIS_PROTOCOL_PATH,
  SIMULATION_STAGE_HYSTERESIS_SATURATION_PATH,
  SIMULATION_STAGE_HYSTERESIS_SETTLE_PIPELINE_PATH,
  SIMULATION_STAGES_EXECUTION_PATH,
  VISUALIZATION_CLIENT_ACKS_PATH,
  VISUALIZATION_DISPLAY_PATH,
  VISUALIZATION_MODE_COMPOSITION_ACTIVE_PATH,
  VISUALIZATION_STATE_PATH,
} from "./apiPaths";
import {
  canonicalFieldVectorQuery,
  canonicalFieldVectorQueryParams,
  fieldVectorComponentEvidenceIdentity,
  isCanonicalU64Decimal,
} from "./fieldQueryIdentity";
import {
  fieldDisplayScale,
  resolveCanonicalQuantityId,
  storedFieldQuantityId,
} from "./quantityIds";
import type { OutputStorageDefaultsResource, OutputStorageDefaultsRequest } from "./apiTypes";
import type {
  ExecutionProfileCatalogQuery, ExecutionProfileCatalogResource,
  ComputePreviewRequest, ComputePreviewResource,
  ComputeNodesResource,
  ComputeNodePolicyResource,
  ComputeNodePolicyUpdateRequest,
  PublishExecutionProfileRequest, PublishExecutionProfileResource,
} from "./apiTypes";
import type {
  BinaryRequestOptions,
  BinaryResourceResult,
  AuthoringTransactionRequest,
  AuthoringTransactionResponse,
  CheckpointCreateRequest,
  CheckpointCreateResponse,
  CheckpointEntry,
  CheckpointListResource,
  CheckpointRestoreRequest,
  CheckpointRestoreResponse,
  CommandDetailResource,
  CommandFailureRequest,
  CommandQueueStatusResource,
  CommandResponse,
  CouplingListResource,
  DynamicStructureFactorResource,
  AnalysisResultAxisValuesResource,
  AnalysisResultBranchPageResource,
  AnalysisResultBranchPointPageResource,
  AnalysisResultBranchResource,
  AnalysisResultDatasetCatalogResource,
  AnalysisResultDatasetManifestResource,
  AnalysisResultItemPageResource,
  AnalysisResultPageQuery,
  AnalysisResultProjectionResource,
  AnalysisResultRelationPageResource,
  AnalysisResultRelationResource,
  AnalysisResultSamplePageResource,
  AnalysisResultSpectralItemSummary,
  FieldDriveCreateRequest,
  FieldDriveDeleteRequest,
  FieldDriveListResource,
  FieldDriveReplaceRequest,
  SpinWaveGammaResource,
  CpuTelemetryResource,
  CrossSectionImageQuery,
  CrossSectionQuery,
  CrossSectionQualityQuery,
  CurrentRunResource,
  DomainMetaResource,
  FdmMultilayerLayoutResource,
  FdmNativeLayerRegionMembershipResource,
  EngineLogResource,
  FieldAvailabilityQuery,
  FieldAvailabilityResource,
  ArtifactFieldCatalogQuery,
  FieldCatalogResource,
  QuantityCatalogResource,
  FieldVectorIdentityIssue,
  FieldVectorPendingResponse,
  FieldVectorResponseMetadata,
  FieldMetaResource,
  ArtifactCarrierGeometryQuery,
  FieldMetaQuery,
  FieldStateExportRequest,
  FieldStateExportResponse,
  FieldStateImportRequest,
  FieldStateImportResponse,
  FieldStateInspectRequest,
  FieldStateInspectResponse,
  FdmScopedFieldVectorQuery,
  FieldVectorQuery,
  PlanarFieldMetaResource,
  PlanarFieldProbeQuery,
  PlanarFieldProbeResource,
  PlanarFieldProfileQuery,
  PlanarFieldProfileResource,
  PlanarFieldQuery,
  PlanarFieldSource,
  AnalyticReferenceModelCollectionResource,
  PostprocessingDefinitionCollectionResource,
  PostprocessingDefinitionCreateRequest,
  PostprocessingDefinitionDeleteRequest,
  PostprocessingDefinitionPatchRequest,
  PostprocessingDefinitionResource,
  PlanarMonitorCollectionResource,
  PlanarMonitorCreateRequest,
  PlanarMonitorDeleteRequest,
  PlanarMonitorDuplicateRequest,
  PlanarMonitorPatchRequest,
  PlanarMonitorResource,
  GeometryCapabilitiesResource,
  GeometryDiagnosticsResource,
  GeometryRealizationRequest,
  GeometryRealizationResource,
  GeometryValidationResource,
  GpuTelemetryResource,
  RunPerformanceResource,
  HealthResource,
  RuntimeServiceStatusResource,
  WorkspaceItemsQuery,
  WorkspaceRootWire,
  ImportSessionAssetRequest,
  JsonObject,
  LiveStatusResource,
  PlatformCapabilitiesResource,
  InstanceDiscoveryResource,
  MagnetizationAssetPatchRequest,
  MagnetizationAssetResource,
  ModeCompositionPatch,
  ModeCompositionResource,
  MagneticResponseSweepResource,
  FrequencyDomainManifestResource,
  FrequencyDomainJsonArtifactResource,
  FrequencyDomainTextArtifactResource,
  ArtifactResource,
  AntennaFieldSolutionResource,
  AntennaFieldPayloadKind,
  AntennaExternalLeadInspectionResource,
  AntennaInspectionDisplayResource,
  AntennaInspectionPayloadKind,
  AntennaStageOutputCatalogResource,
  AntennaSpectrumPayloadKind,
  AntennaSourceSpectrumResource,
  FrequencyDomainFieldResource,
  FrequencyDomainSweepProgressResource,
  HysteresisAdaptiveRefinementResource,
  HysteresisAngularFamilyResource,
  HysteresisBookmarkPointRequest,
  HysteresisBookmarksResource,
  HysteresisBranchesResource,
  HysteresisExecutionTreeResource,
  HysteresisMinorLoopsResource,
  HysteresisMetricsResource,
  HysteresisPointSchema,
  HysteresisPointsResource,
  HysteresisOrientationSchema,
  HysteresisProgressSchema,
  HysteresisProtocolSchema,
  HysteresisReversalFieldsResource,
  HysteresisSaturationResource,
  HysteresisSettlePipelineSchema,
  HysteresisSettleTraceEntrySchema,
  HysteresisSettleTraceResource,
  HysteresisStagePlanSchema,
  HysteresisStageSaturationSchema,
  MaterialParameterFieldListResource,
  MaterialPatchRequest,
  MaterialPropertiesResource,
  MaterialReferenceResource,
  MaterialResource,
  MeshActiveBuildResource,
  MeshBuildHistoryResource,
  MeshCapabilitiesResource,
  MeshHistogramBinElementsResource,
  MeshHistogramBinMetric,
  MeshLastSuccessfulBuildResource,
  MeshObjectConfigReplaceRequest,
  MeshObjectConfigResource,
  MeshObjectQualityResource,
  MeshObjectReportResource,
  MeshObjectSizeFieldResource,
  MeshPeriodicPairsResource,
  MeshQualityGatesResource,
  MeshRealizedSizeFieldsResource,
  MeshRegionMembershipListResource,
  MeshRegionMembershipResource,
  FdmRegionMembershipResource,
  PendingJsonResourceResult,
  MeshRegionQualityResource,
  MeshSemanticsResource,
  MeshSharedDomainConfigReplaceRequest,
  MeshSharedDomainConfigResource,
  MeshSharedDomainQualityResource,
  MeshSharedDomainReportResource,
  MeshSharedDomainManifestResource,
  ModelReadinessResource,
  MeshSummaryResource,
  MeshUniverseConfigReplaceRequest,
  MeshUniverseConfigResource,
  MeshUniverseQualityResource,
  MeshUniverseReportResource,
  ObjectCreateRequest,
  ObjectGeometryPatchRequest,
  ObjectMetricsResource,
  ObjectInteractionKind,
  ObjectInteractionPatchRequest,
  ObjectInteractionResource,
  ObjectPatchRequest,
  ObjectRegionCreateRequest,
  ObjectRegionDuplicateRequest,
  ObjectRegionPatchRequest,
  ObjectRegionReorderRequest,
  RealtimeCommunicationPolicyPatch,
  RealtimeCommunicationPolicyResource,
  RegionDiagnosticsResource,
  RegionListResource,
  RegionPatchRequest,
  RequestOptions,
  ScalarWindowQuery,
  ScalarWindowResource,
  TableColumnMeta,
  TableListResource,
  TableResource,
  TableRowsQuery,
  TableRowsResource,
  SceneResource,
  FrozenSpinsCollectionResource,
  FrozenSpinsDefinitionResource,
  FrozenSpinsMutationRequest,
  FrozenSpinsDeleteRequest,
  FrozenSpinsPreviewActivationRequest,
  FrozenSpinsPreviewActivationResponse,
  FrozenSpinsPreviewRequest,
  FrozenSpinsPreviewResponse,
  SceneCurrentTransport,
  SceneSpinTransport,
  SceneSpinTorque,
  SceneOerstedField,
  CurrentTransportListResource,
  CurrentTransportMutationRequest,
  CurrentTransportCommitResource,
  SpinTransportListResource,
  SpinTransportMutationRequest,
  SpinTransportCommitResource,
  SpinInterfaceListResource,
  TransportValidationRequest,
  TransportValidationResponse,
  SpinTorqueListResource,
  SpinTorqueMutationRequest,
  SpinTorqueCommitResource,
  OerstedFieldListResource,
  OerstedFieldMutationRequest,
  OerstedFieldCommitResource,
  SpinAuthoringDeleteRequest,
  PhysicsGraphResource,
  ScriptSyncRequest,
  ScriptSyncResponse,
  ScriptSourceResponse,
  TopologicalChargeQuery,
  TopologicalChargeResource,
  SessionAssetImportResponse,
  SessionExportRequest,
  SessionExportResponse,
  SessionListResource,
  SessionImportCommitRequest,
  SessionImportCommitResponse,
  SessionImportInspectRequest,
  SessionImportInspectResponse,
  ProjectArchiveRequest,
  ProjectAuthoringUpdateRequest,
  ProjectFromScriptRequest,
  ProjectFromScriptResource,
  ProjectCreateRequest,
  ProjectDocumentResource,
  ProjectRunSubmitRequest,
  ProjectRunSubmitResource,
  ProjectRunMaterializationResource,
  ProjectRunResource,
  ProjectRunListQuery,
  ProjectRunListResource,
  ProjectRunTaskCancellationRequest,
  ProjectRunTaskCancellationResource,
  ProjectRunTaskRetryRequest,
  ProjectRunTaskRetryResource,
  ProjectBatchSubmitRequest,
  ProjectBatchSubmitResource,
  ProjectBatchCommandRequest,
  ProjectBatchCommandResource,
  ProjectBatchListQuery,
  ProjectBatchListResource,
  ProjectBatchCasesQuery,
  ProjectBatchCasesResource,
  SolutionSetArtifactPageQuery,
  SolutionSetArtifactPageResource,
  SolutionScalarResource,
  SolutionSetMemberPageQuery,
  SolutionSetMemberPageResource,
  SolutionSetResource,
  SolutionSetDiscoveryPageQuery,
  SolutionSetDiscoveryPageResource,
  MaterializedDatasetResource,
  SavedFieldGeometryResource,
  SavedFieldGeometryQuery,
  SolutionSetRevision,
  ObservationFrameListQuery,
  ObservationFrameListResource,
  ObservationFrameResource,
  LivePreparationMaterializationRequest,
  LivePreparationMaterializationResource,
  SolverEnergyCurrentResource,
  SolverEnergyHistoryResource,
  SolverProfileResource,
  SimulationPreparationResource,
  SolverStatusResource,
  StageExecutionResource,
  StructuredCommandRequest,
  StudyRuntimePatchRequest,
  StudyRuntimeResource,
  UniversePatchRequest,
  UniverseResource,
  VisualizationClientAckEntry,
  VisualizationClientAckRequest,
  VisualizationClientAckResource,
  DisplaySelection,
  VisualizationStatePatch,
  VisualizationStateResource,
} from "./apiTypes";

type CreateSessionRequest = components["schemas"]["CreateSessionRequest"];
type CreateSessionResponse = components["schemas"]["CreateSessionResponse"];

function optionalIntegerHeader(headers: Headers, name: string): number | null {
  const raw = headers.get(name);
  if (raw === null || raw.trim() === "") return null;
  const value = Number(raw);
  return Number.isSafeInteger(value) && value >= 0 ? value : null;
}

export function parseFieldVectorResponseMetadata(
  headers: Headers,
): FieldVectorResponseMetadata {
  return {
    carrierId: headers.get("x-fullmag-carrier-id"),
    carrierRevision: headers.get("x-fullmag-carrier-revision"),
    carrierDigest: headers.get("x-fullmag-carrier-digest"),
    component: headers.get("x-fullmag-component"),
    domainGenerationId: headers.get("x-fullmag-domain-generation-id"),
    artifactGenerationId: headers.get("x-fullmag-artifact-generation-id"),
    encoding: headers.get("x-fullmag-encoding"),
    fieldIndexing: headers.get("x-fullmag-field-indexing"),
    fieldGenerationId: headers.get("x-fullmag-field-generation-id"),
    fieldRevision: headers.get("x-fullmag-field-revision"),
    identityIssues: [],
    meshTopologyHash: headers.get("x-fullmag-mesh-topology-hash"),
    nComp: optionalIntegerHeader(headers, "x-fullmag-n-comp"),
    nodeIndexCount: optionalIntegerHeader(headers, "x-fullmag-node-index-count"),
    pointCount: optionalIntegerHeader(headers, "x-fullmag-point-count"),
    quantityId: headers.get("x-fullmag-quantity-id"),
    scopeId: headers.get("x-fullmag-scope-id"),
    scopeKind: headers.get("x-fullmag-scope-kind"),
    sourceId: headers.get("x-fullmag-source-id"),
    sourceKind: headers.get("x-fullmag-source-kind"),
    sourceRevision: headers.get("x-fullmag-source-revision"),
    snapshotId: headers.get("x-fullmag-snapshot-id"),
    valueCount: optionalIntegerHeader(headers, "x-fullmag-value-count"),
  };
}

export function collectFieldVectorIdentityIssues(
  payload: DecodedFieldVector,
  metadata: FieldVectorResponseMetadata,
): FieldVectorIdentityIssue[] {
  const issues: FieldVectorIdentityIssue[] = [];
  const compare = (
    field: string,
    headerValue: number | string | null,
    payloadValue: number | string | null,
  ) => {
    if (headerValue !== null && String(headerValue) !== String(payloadValue)) {
      issues.push({ field, headerValue, payloadValue });
    }
  };
  compare("quantityId", metadata.quantityId, payload.quantityId);
  compare("pointCount", metadata.pointCount, payload.pointCount);
  compare("valueCount", metadata.valueCount, payload.valueCount);
  compare("nComp", metadata.nComp, payload.nComp);
  if (
    payload.formatVersion === 3 ||
    payload.formatVersion === 4 ||
    payload.formatVersion === 5 ||
    payload.formatVersion === 6
  ) {
    compare("scopeKind", metadata.scopeKind, payload.scopeKind ?? null);
    compare("scopeId", metadata.scopeId, payload.scopeId ?? null);
    const payloadMeshTopologyHash = payload.meshTopologyHash ?? null;
    if (
      metadata.meshTopologyHash !== null &&
      canonicalFieldVectorTopologyHash(metadata.meshTopologyHash) !==
        canonicalFieldVectorTopologyHash(payloadMeshTopologyHash)
    ) {
      issues.push({
        field: "meshTopologyHash",
        headerValue: metadata.meshTopologyHash,
        payloadValue: payloadMeshTopologyHash,
      });
    }
    compare("fieldIndexing", metadata.fieldIndexing, payload.indexing ?? null);
    compare(
      "nodeIndexCount",
      metadata.nodeIndexCount,
      payload.nodeIndices?.length ?? 0,
    );
    compare(
      "domainGenerationId",
      metadata.domainGenerationId,
      payload.domainGenerationId ?? null,
    );
  }
  if (payload.formatVersion === 4 || payload.formatVersion === 5 || payload.formatVersion === 6) {
    compare("sourceKind", metadata.sourceKind ?? null, payload.sourceKind ?? null);
    compare("sourceId", metadata.sourceId ?? null, payload.sourceId ?? null);
    compare(
      "sourceRevision",
      metadata.sourceRevision ?? null,
      payload.sourceRevision ?? null,
    );
    compare(
      "fieldGenerationId",
      metadata.fieldGenerationId ?? null,
      payload.fieldGenerationId ?? null,
    );
  }
  if (payload.formatVersion === 6) {
    compare("carrierRevision", metadata.carrierRevision ?? null, payload.meshTopologyRevision ?? null);
    compare("carrierDigest", metadata.carrierDigest ?? null, payload.meshTopologyHash ?? null);
  }
  return issues;
}

function canonicalFieldVectorTopologyHash(value: string | null): string | null {
  const match = /^(?:sha256:)?([0-9a-f]{64})$/i.exec(value ?? "");
  return match?.[1]?.toLowerCase() ?? value;
}

export function withDerivedDriveFluxDensity(
  catalog: FieldCatalogResource,
): FieldCatalogResource {
  if (catalog.quantities.some((quantity) => quantity.quantity_id === "B_drive")) {
    return catalog;
  }
  const source = catalog.quantities.find(
    (quantity) => quantity.quantity_id === "H_drive",
  );
  if (!source) return catalog;
  return {
    ...catalog,
    quantities: [
      ...catalog.quantities,
      {
        ...source,
        label: "Drive flux density",
        quantity_id: "B_drive",
        unit: "T",
      },
    ],
  };
}

export function transformFieldMetaForDisplay(
  requestedQuantityId: string,
  meta: FieldMetaResource,
): FieldMetaResource {
  const scale = fieldDisplayScale(requestedQuantityId);
  if (scale === 1) return meta;
  return {
    ...meta,
    label: "Drive flux density",
    quantity_id: requestedQuantityId,
    stats: meta.stats
      ? {
          max: meta.stats.max * scale,
          mean: meta.stats.mean * scale,
          min: meta.stats.min * scale,
        }
      : meta.stats,
    unit: "T",
  };
}

export function transformFieldVectorForDisplay(
  requestedQuantityId: string,
  result: BinaryResourceResult<DecodedFieldVector, FieldVectorResponseMetadata>,
): BinaryResourceResult<DecodedFieldVector, FieldVectorResponseMetadata> {
  const scale = fieldDisplayScale(requestedQuantityId);
  if (scale === 1 || result.status !== "ready") return result;
  // The backend projects H before this display conversion. A squared norm
  // therefore needs the squared unit conversion as well.
  const projectionScale =
    fieldVectorComponentEvidenceIdentity(result.responseMetadata.component ?? "full") ===
    "magnitude_squared"
      ? scale * scale
      : scale;
  let data: DecodedFieldVector;
  if (result.data.dtype === "float32") {
    const values = Float32Array.from(
      result.data.values,
      (value) => value * projectionScale,
    );
    if (values.some((value) => !Number.isFinite(value))) {
      throw new Error("Display conversion produced non-finite float32 values");
    }
    data = { ...result.data, quantityId: requestedQuantityId, values };
  } else {
    data = {
      ...result.data,
      quantityId: requestedQuantityId,
      values: Float64Array.from(
        result.data.values,
        (value) => value * projectionScale,
      ),
    };
  }
  return {
    ...result,
    data,
    responseMetadata: {
      ...result.responseMetadata,
      quantityId: requestedQuantityId,
    },
  };
}
import { decodeCrossSection } from "./codecs/crossSectionCodec";
import { decodeCrossSectionQuality } from "./codecs/crossSectionQualityCodec";
import { decodeFieldVector } from "./codecs/fieldVectorCodec";
import { decodeMeshQualityData } from "./codecs/meshQualityDataCodec";
import { decodeSavedSupport, savedSupportByteLimit } from "./codecs/savedSupportCodec";
import { savedTopologyByteLimit, validateSavedGeometry, verifySavedTopologyBody } from "./savedGeometryIdentity";
import { boundedBinaryResponse } from "./boundedBinaryResponse";
import {
  decodeMaterializedDatasetSlice,
  materializedDatasetSliceByteLimit,
  type MaterializedDatasetSliceRange,
} from "./codecs/materializedDatasetSliceCodec";
import { decodePeriodicPairs } from "./codecs/periodicPairsCodec";
import { decodeTableRows } from "./codecs/tableRowsCodec";
import {
  decodeTopology,
  decodeTopologyHeader,
  decodeTopologySections,
  expectedTopologyByteLength,
  FMMT_HEADER_LEN,
  topologyByteLayout,
  type TopologyHeader,
  type TopologySections,
} from "./codecs/topologyCodec";
import type {
  DecodedCrossSection,
  DecodedCrossSectionQuality,
  DecodedFieldVector,
  DecodedMeshQualityData,
  DecodedTableRows,
  DecodedTopology,
} from "./codecs/types";
import {
  createBinaryDecodeScheduler,
  type BinaryDecoderKind,
  type BinaryDecodeScheduler,
} from "./binaryDecodeScheduler";
import {
  createOpenApiV2Transport,
  type OpenApiV2Transport,
} from "./generated/openapi-v2-client";
import type { OpenApiV2Path } from "./generated/openapi-v2-paths";
import type { RequestDiagnosticsController } from "./RequestDiagnosticsController";
import type { components } from "./generated/openapi-v2-types";
import { recordVisualizationDebugPerformanceMetric } from "@/kernel/performance/visualizationDebugPerformanceProbe";

type FetchLike = typeof fetch;
type PathParams = Record<string, string | number>;
type QueryParams = Record<string, unknown>;
type BinaryOpenApiTransportResult = {
  data?: unknown;
  error?: unknown;
  response: Response;
};

export interface JsonResponseIdentity<T> {
  data: T;
  requestId: string | null;
}

function planarRequestSpec(
  source: PlanarFieldSource,
  quantityId: string,
  monitorPath: OpenApiV2Path,
  defaultPath: OpenApiV2Path,
): { path: OpenApiV2Path; pathParams: PathParams } {
  return source.kind === "default"
    ? { path: defaultPath, pathParams: { quantity_id: quantityId } }
    : {
        path: monitorPath,
        pathParams: { monitor_id: source.monitorId, quantity_id: quantityId },
      };
}

export interface AuthoringWriteOptions extends RequestOptions {
  baseRevision?: number;
}

export interface MeshHistogramBinElementsParams {
  binIndex: number;
  meshId: string;
  metric: MeshHistogramBinMetric;
  partId: string;
}

export interface HysteresisExecutionTreeQuery {
  window?: "active" | string;
  before?: number;
  after?: number;
  include_bookmarks?: boolean;
  include_warnings?: boolean;
  include_snapshots?: boolean;
}

const CHUNKED_TOPOLOGY_THRESHOLD_BYTES = 16 * 1024 * 1024;

function savedGeometryPath(dataset: MaterializedDatasetResource) {
  return {
    project_id: assertSolutionSetProjectId(dataset.project_id),
    run_id: assertSolutionSetRunId(dataset.run_id),
    solution_set_id: assertSolutionSetLogicalId(dataset.solution_set_id),
    revision: assertSolutionSetRevision(dataset.containing_solution_revision),
    member_id: assertMaterializedDatasetPathId("member id", dataset.member_id),
    artifact_id: assertMaterializedDatasetPathId("artifact id", dataset.artifact_id),
  };
}

function savedGeometryBinaryQuery(geometry: SavedFieldGeometryResource, limit: number) {
  return {
    expected_dataset_manifest_object_ref: geometry.dataset_manifest.object_ref,
    expected_geometry_manifest_object_ref: geometry.geometry_manifest.object_ref,
    expected_geometry_object_ref: geometry.geometry_payload.object_ref,
    max_response_bytes: String(limit),
  };
}
const TOPOLOGY_RANGE_CHUNK_BYTES = 8 * 1024 * 1024;
export const MAX_TOPOLOGY_BYTES = 512 * 1024 * 1024;
export const MAX_ANTENNA_INSPECTION_BYTES = 128 * 1024 * 1024;
const FIELD_MATERIALIZATION_TIMEOUT_MS = 5_000;
const FIELD_MATERIALIZATION_RETRY_MS = 250;
const FIELD_MATERIALIZATION_REQUEST_KEY = "current-field-cache";

const CONTROL_CHARACTERS = /[\u0000-\u001f\u007f-\u009f]/;
const PROJECT_ID_PATTERN = /^[A-Za-z0-9._-]+$/;
const PROJECT_ID_MAX_BYTES = 200;
const RUN_ID_MAX_BYTES = 256;
const SOLUTION_SET_ID_MAX_BYTES = 1024;

function utf8ByteLength(value: string): number {
  return new TextEncoder().encode(value).byteLength;
}

function assertNonEmptyId(label: string, value: string): string {
  if (
    typeof value !== "string" ||
    value.trim().length === 0 ||
    CONTROL_CHARACTERS.test(value)
  ) {
    throw new Error(`Invalid ${label}.`);
  }
  return value;
}

export function assertSolutionSetProjectId(value: string): string {
  assertNonEmptyId("project id", value);
  if (
    utf8ByteLength(value) > PROJECT_ID_MAX_BYTES ||
    value !== value.trim() ||
    value === "." ||
    value === ".." ||
    value.endsWith(".") ||
    !PROJECT_ID_PATTERN.test(value)
  ) {
    throw new Error("Invalid project id.");
  }
  const stem = (value.split(".")[0] ?? "").toUpperCase();
  if (
    new Set(["CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$"]).has(stem) ||
    ((stem.startsWith("COM") || stem.startsWith("LPT")) &&
      stem.length === 4 &&
      /^[1-9]$/.test(stem.slice(3)))
  ) {
    throw new Error("Invalid project id.");
  }
  return value;
}

export function assertSolutionSetRunId(value: string): string {
  assertNonEmptyId("run id", value);
  if (
    utf8ByteLength(value) > RUN_ID_MAX_BYTES ||
    /[\\/]/.test(value)
  ) {
    throw new Error("Invalid run id.");
  }
  return value;
}

export function assertSolutionSetLogicalId(value: string): string {
  assertNonEmptyId("solution set id", value);
  if (utf8ByteLength(value) > SOLUTION_SET_ID_MAX_BYTES) {
    throw new Error("Invalid solution set id.");
  }
  return value;
}

export function assertSolutionSetMemberId(
  label: string,
  value: string,
): string {
  return assertNonEmptyId(label, value);
}

export function assertSolutionSetRevision(
  revision: SolutionSetRevision,
): SolutionSetRevision {
  if (revision === "0" || !isCanonicalU64Decimal(revision)) {
    throw new Error("SolutionSet revision must be a positive canonical u64 string.");
  }
  return revision;
}

export function assertMaterializedDatasetPathId(label: string, value: string): string {
  assertSolutionSetMemberId(label, value);
  if (utf8ByteLength(value) > 1024) {
    throw new Error(`Invalid ${label}.`);
  }
  return value;
}

function normalizeSolutionSetPageQuery<
  T extends {
    after_artifact_id?: string | null;
    after_member_id?: string | null;
    limit?: number | null;
  },
>(
  query: T,
): T {
  const limit = query.limit ?? 50;
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) {
    throw new Error("SolutionSet page limit must be an integer between 1 and 100.");
  }
  if (query.after_member_id != null) {
    assertSolutionSetMemberId("member cursor", query.after_member_id);
  }
  if (query.after_artifact_id != null) {
    assertSolutionSetMemberId("artifact cursor", query.after_artifact_id);
  }
  return {
    ...query,
    after_artifact_id: query.after_artifact_id ?? undefined,
    after_member_id: query.after_member_id ?? undefined,
    limit,
  };
}

function workspaceQueryParams(query: WorkspaceItemsQuery): Record<string, unknown> {
  const wire: Record<string, unknown> = {};
  if (query.kind) wire.kind = query.kind;
  if (query.sort) wire.sort = query.sort;
  if (query.search) wire.search = query.search;
  if (query.limit !== undefined) wire.limit = query.limit;
  if (query.includeMissing !== undefined) wire.include_missing = query.includeMissing;
  return wire;
}

function sessionScopeHeaders(options: RequestOptions): Record<string, string> {
  return options.sessionScopeKey
    ? { "x-fullmag-session-scope": options.sessionScopeKey }
    : {};
}

interface ComputeNodePolicyWriteOptions extends RequestOptions {
  readonly operatorCapability: string;
  readonly expectedRevision: number;
}

interface ComputeProfileWriteOptions extends RequestOptions {
  readonly operatorCapability: string;
}

function baseRevisionPayload(options?: AuthoringWriteOptions): { base_revision?: number } {
  return options?.baseRevision === undefined
    ? {}
    : { base_revision: options.baseRevision };
}

function shouldMaterializeFieldAfterJsonError(error: unknown): boolean {
  return (
    error instanceof ControlRoomApiError &&
    error.status === 404 &&
    error.message.toLowerCase().includes("not available")
  );
}

function throwIfAborted(signal?: AbortSignal | null): void {
  if (signal?.aborted) {
    throw new DOMException("Aborted", "AbortError");
  }
}

function delay(ms: number, signal?: AbortSignal | null): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new DOMException("Aborted", "AbortError"));
      return;
    }

    const timeout = globalThis.setTimeout(resolve, ms);
    signal?.addEventListener(
      "abort",
      () => {
        globalThis.clearTimeout(timeout);
        reject(new DOMException("Aborted", "AbortError"));
      },
      { once: true },
    );
  });
}

interface ControlRoomApiOptions {
  expectedApiInstance?: string | null;
  baseUrl?: string;
  binaryDecodeScheduler?: BinaryDecodeScheduler;
  diagnostics?: RequestDiagnosticsController;
  fetchImpl?: FetchLike;
  maxGetRetries?: number;
  retryDelayMs?: number;
  requestIdFactory?: () => string;
}

export class ControlRoomApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly requestId: string | null = null,
    readonly code: string | null = null,
  ) {
    super(message);
    this.name = "ControlRoomApiError";
  }
}

export class ControlRoomApi {
  /** Unique cache namespace for this API client instance. */
  readonly resourceCacheScope = createRequestId();

  private readonly expectedApiInstance: string | null;
  private apiInstanceMismatch = false;
  private readonly baseUrl: string;
  private readonly binaryDecodeScheduler: BinaryDecodeScheduler;
  private readonly requestDiagnostics: RequestDiagnosticsController | null;
  private readonly fetchImpl: FetchLike;
  private readonly maxGetRetries: number;
  private readonly retryDelayMs: number;
  private readonly requestIdFactory: () => string;
  private readonly transport: OpenApiV2Transport;
  private readonly fieldMaterializationRequests = new Map<string, Promise<void>>();
  private readonly meshFreshnessRequests = new Map<string, Promise<boolean>>();

  readonly sessions = {
    list: (options?: RequestOptions) =>
      this.requestJson<SessionListResource>(SESSIONS_PATH, options),
    create: (input: CreateSessionRequest, options?: RequestOptions) =>
      this.postJson<CreateSessionResponse, CreateSessionRequest>(
        SESSIONS_PATH,
        input,
        options,
      ),
    current: {
      status: (options?: RequestOptions) =>
        this.requestJson<LiveStatusResource>(SESSION_STATUS_PATH, options),
    },
  };

  /**
   * The workspace database (projects, scripts, result folders) as the start
   * screen reads it. Answers are `unknown` on purpose: the caller validates
   * them (modules/start/model/workspaceApiTypes.ts) until generated types exist.
   */
  readonly workspace = {
    playback: (id: string, options?: RequestOptions) =>
      this.requestJson<SavedPlaybackResource>(WORKSPACE_ITEM_PLAYBACK_PATH, options, {path: {id}}),
    playbackGeometry: (id: string, revision: string, part: "topology"|"support", options?: BinaryRequestOptions) =>
      this.requestBinaryBytes(WORKSPACE_ITEM_PLAYBACK_GEOMETRY_PATH, {...options, maxResponseBytes: part === "support" ? 1024*1024 : 64*1024*1024},
        {id}, {revision, part}),
    playbackFrame: (id: string, stageId: string, frameIndex: number, revision: string, options?: BinaryRequestOptions) =>
      this.requestBinaryBytes(WORKSPACE_ITEM_PLAYBACK_FRAME_PATH, {...options, maxResponseBytes: 64 * 1024 * 1024},
        {id, frame_index: String(frameIndex)}, {stage_id: stageId, revision}),

    items: (query: WorkspaceItemsQuery = {}, options?: RequestOptions) =>
      this.requestJson<unknown>(WORKSPACE_ITEMS_PATH, options, {
        query: workspaceQueryParams(query),
      }),
    item: (id: string, options?: RequestOptions) =>
      this.requestJson<unknown>(WORKSPACE_ITEM_PATH, options, { path: { id } }),
    history: (id: string, limit?: number, options?: RequestOptions) =>
      this.requestJson<unknown>(WORKSPACE_ITEM_HISTORY_PATH, options, {
        path: { id },
        query: limit === undefined ? {} : { limit },
      }),
    /** One page of the saved-frame index (`frames.json`) of a result folder. */
    frames: (id: string, from: number, limit: number, options?: RequestOptions) =>
      this.requestJson<unknown>(WORKSPACE_ITEM_FRAMES_PATH, options, {
        path: { id },
        query: { from, limit },
      }),
    /** An allow-listed per-user setting (`telemetry.enabled`, `update.available`). */
    setting: (key: string, options?: RequestOptions) =>
      this.requestJson<unknown>(WORKSPACE_SETTING_PATH, options, { path: { key } }),
    saveSetting: (key: string, value: boolean, options?: RequestOptions) =>
      this.putJson<unknown, { value: boolean }>(
        WORKSPACE_SETTING_PATH,
        { value },
        options,
        { path: { key } },
      ),
    thumbnailUrl: (id: string) => workspaceItemThumbnailUrl(this.baseUrl, id),
    archiveUrl: (id: string) => workspaceItemArchiveUrl(this.baseUrl, id),
    setPinned: (id: string, pinned: boolean, options?: RequestOptions) =>
      this.postJson<unknown, { pinned: boolean }>(
        WORKSPACE_ITEM_PIN_PATH,
        { pinned },
        options,
        { path: { id } },
      ),
    forget: (id: string, options?: RequestOptions) =>
      this.postJson<unknown, Record<string, never>>(WORKSPACE_ITEM_FORGET_PATH, {}, options, {
        path: { id },
      }),
    roots: (options?: RequestOptions) =>
      this.requestJson<unknown>(WORKSPACE_ROOTS_PATH, options),
    saveRoots: (roots: readonly WorkspaceRootWire[], options?: RequestOptions) =>
      this.putJson<unknown, { roots: readonly WorkspaceRootWire[] }>(
        WORKSPACE_ROOTS_PATH,
        { roots },
        options,
      ),
    scan: (roots?: readonly string[], options?: RequestOptions) =>
      this.postJson<unknown, { roots?: readonly string[] }>(
        WORKSPACE_SCAN_PATH,
        roots ? { roots } : {},
        options,
      ),
    addItem: (path: string, kind?: "project" | "script" | "result", options?: RequestOptions) =>
      this.postJson<unknown, { path: string; kind?: string }>(
        WORKSPACE_ITEMS_PATH,
        kind ? { path, kind } : { path },
        options,
      ),
  };

  readonly platform = {
    computeNodes: (options?: RequestOptions) =>
      this.requestJson<ComputeNodesResource>(PLATFORM_COMPUTE_NODES_PATH, options),
    computeNodePolicy: (nodeId: string, options?: RequestOptions) =>
      this.requestJson<ComputeNodePolicyResource>(
        PLATFORM_COMPUTE_NODE_POLICY_PATH,
        options,
        { path: { node_id: nodeId } },
      ),
    updateComputeNodePolicy: (
      nodeId: string,
      input: ComputeNodePolicyUpdateRequest,
      options: ComputeNodePolicyWriteOptions,
    ) =>
      this.putJson<ComputeNodePolicyResource, ComputeNodePolicyUpdateRequest>(
        PLATFORM_COMPUTE_NODE_POLICY_PATH,
        input,
        { sessionScopeKey: options.sessionScopeKey, signal: options.signal },
        { path: { node_id: nodeId } },
        {
          Authorization: `Bearer ${options.operatorCapability}`,
          "If-Match": `"compute-node-policy:${nodeId}:${options.expectedRevision}"`,
        },
      ),
    computeExecutionPreview: (input: ComputePreviewRequest, options?: RequestOptions) =>
      this.postJson<ComputePreviewResource, ComputePreviewRequest>(PLATFORM_COMPUTE_PREVIEW_PATH, input, options),
    computeProfiles: (query: ExecutionProfileCatalogQuery = {}, options?: RequestOptions) =>
      this.requestJson<ExecutionProfileCatalogResource>(PLATFORM_COMPUTE_PROFILES_PATH, options, { query }),
    publishComputeProfile: (input: PublishExecutionProfileRequest, options: ComputeProfileWriteOptions) =>
      this.postJson<PublishExecutionProfileResource, PublishExecutionProfileRequest>(
        PLATFORM_COMPUTE_PROFILES_PATH,
        input,
        { sessionScopeKey: options.sessionScopeKey, signal: options.signal },
        undefined,
        { Authorization: `Bearer ${options.operatorCapability}` },
      ),
    outputStorageDefaults: (options?: RequestOptions) =>
      this.requestJson<OutputStorageDefaultsResource>(PLATFORM_OUTPUT_STORAGE_PATH, options),
    saveOutputStorageDefaults: (input: OutputStorageDefaultsRequest, options?: RequestOptions) =>
      this.putJson<OutputStorageDefaultsResource, OutputStorageDefaultsRequest>(PLATFORM_OUTPUT_STORAGE_PATH, input, options),
    capabilities: (options?: RequestOptions) =>
      this.requestJson<PlatformCapabilitiesResource>(
        PLATFORM_CAPABILITIES_PATH,
        options,
      ),
    health: (options?: RequestOptions) =>
      this.requestJson<HealthResource>(PLATFORM_HEALTH_PATH, options),
    instances: (options?: RequestOptions) =>
      this.requestJson<InstanceDiscoveryResource>(PLATFORM_INSTANCES_PATH, options),
    runtimeService: (options?: RequestOptions) =>
      this.requestJson<RuntimeServiceStatusResource>(PLATFORM_RUNTIME_SERVICE_PATH, options),
  };

  readonly events = {
    communicationPolicy: (options?: RequestOptions) =>
      this.requestJson<RealtimeCommunicationPolicyResource>(
        SESSION_EVENTS_COMMUNICATION_POLICY_PATH,
        options,
      ),
    patchCommunicationPolicy: (
      patch: RealtimeCommunicationPolicyPatch,
      options?: RequestOptions,
    ) =>
      this.patchJson<
        RealtimeCommunicationPolicyResource,
        RealtimeCommunicationPolicyPatch
      >(SESSION_EVENTS_COMMUNICATION_POLICY_PATH, patch, options),
  };

  readonly commands = {
    detail: (commandId: string, options?: RequestOptions) =>
      this.requestJson<CommandDetailResource>(
        SIMULATION_COMMAND_DETAIL_PATH,
        options,
        { path: { command_id: commandId } },
      ),
    failure: (
      commandId: string,
      request: CommandFailureRequest,
      options?: RequestOptions,
    ) =>
      this.postJson<CommandDetailResource, CommandFailureRequest>(
        SIMULATION_COMMAND_FAILURE_PATH,
        request,
        options,
        { path: { command_id: commandId } },
      ),
    list: (options?: RequestOptions) =>
      this.requestJson<CommandQueueStatusResource>(
        SIMULATION_COMMANDS_PATH,
        options,
      ),
    submit: (command: StructuredCommandRequest, options?: RequestOptions) =>
      this.postJson<CommandResponse, StructuredCommandRequest>(
        SIMULATION_COMMANDS_PATH,
        command,
        options,
      ),
  };

  readonly analysis = {
    /** Analytic reference models with their declared assumptions (spec 32 §9). */
    references: {
      analyticModels: (options?: RequestOptions) =>
        this.requestJson<AnalyticReferenceModelCollectionResource>(
          ANALYSIS_ANALYTIC_REFERENCE_MODELS_PATH,
          options,
        ),
    },
    /** User-created Results nodes saved with the project (ADR 0054, spec 32 §8). */
    postprocessing: {
      definitions: {
        list: (options?: RequestOptions) =>
          this.requestJson<PostprocessingDefinitionCollectionResource>(
            ANALYSIS_POSTPROCESSING_DEFINITIONS_PATH,
            options,
          ),
        get: (definitionId: string, options?: RequestOptions) =>
          this.requestJson<PostprocessingDefinitionResource>(
            ANALYSIS_POSTPROCESSING_DEFINITION_PATH,
            options,
            { path: { definition_id: definitionId } },
          ),
        create: (request: PostprocessingDefinitionCreateRequest, options?: RequestOptions) =>
          this.postJson<PostprocessingDefinitionResource, PostprocessingDefinitionCreateRequest>(
            ANALYSIS_POSTPROCESSING_DEFINITIONS_PATH,
            request,
            options,
          ),
        patch: (
          definitionId: string,
          request: PostprocessingDefinitionPatchRequest,
          options?: RequestOptions,
        ) =>
          this.patchJson<PostprocessingDefinitionResource, PostprocessingDefinitionPatchRequest>(
            ANALYSIS_POSTPROCESSING_DEFINITION_PATH,
            request,
            options,
            { path: { definition_id: definitionId } },
          ),
        remove: (
          definitionId: string,
          request: PostprocessingDefinitionDeleteRequest,
          options?: RequestOptions,
        ) =>
          this.deleteJsonWithBody<
            PostprocessingDefinitionCollectionResource,
            PostprocessingDefinitionDeleteRequest
          >(ANALYSIS_POSTPROCESSING_DEFINITION_PATH, request, options, {
            path: { definition_id: definitionId },
          }),
      },
    },
    spinWave: {
      gamma: (options?: RequestOptions) =>
        this.requestJson<SpinWaveGammaResource>(
          ANALYSIS_SPIN_WAVE_GAMMA_V1_PATH,
          options,
        ),
      dynamicStructureFactor: (options?: RequestOptions) =>
        this.requestJson<DynamicStructureFactorResource>(
          ANALYSIS_DYNAMIC_STRUCTURE_FACTOR_V1_PATH,
          options,
        ),
    },
    results: {
      datasets: (
        runId: string,
        query: AnalysisResultPageQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultDatasetCatalogResource>(
          ANALYSIS_RESULT_DATASETS_PATH,
          options,
          { path: { run_id: runId }, query },
        ),
      dataset: (
        runId: string,
        datasetId: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultDatasetManifestResource>(
          ANALYSIS_RESULT_DATASET_PATH,
          options,
          { path: { run_id: runId, dataset_id: datasetId } },
        ),
      axisValues: (
        runId: string,
        datasetId: string,
        axisId: string,
        query: AnalysisResultPageQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultAxisValuesResource>(
          ANALYSIS_RESULT_AXIS_VALUES_PATH,
          options,
          {
            path: { run_id: runId, dataset_id: datasetId, axis_id: axisId },
            query,
          },
        ),
      samples: (
        runId: string,
        datasetId: string,
        query: AnalysisResultPageQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultSamplePageResource>(
          ANALYSIS_RESULT_SAMPLES_PATH,
          options,
          { path: { run_id: runId, dataset_id: datasetId }, query },
        ),
      items: (
        runId: string,
        datasetId: string,
        query: AnalysisResultPageQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultItemPageResource>(
          ANALYSIS_RESULT_ITEMS_PATH,
          options,
          { path: { run_id: runId, dataset_id: datasetId }, query },
        ),
      item: (
        runId: string,
        datasetId: string,
        itemId: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultSpectralItemSummary>(
          ANALYSIS_RESULT_ITEM_PATH,
          options,
          { path: { run_id: runId, dataset_id: datasetId, item_id: itemId } },
        ),
      branches: (
        runId: string,
        datasetId: string,
        query: AnalysisResultPageQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultBranchPageResource>(
          ANALYSIS_RESULT_BRANCHES_PATH,
          options,
          { path: { run_id: runId, dataset_id: datasetId }, query },
        ),
      branch: (
        runId: string,
        datasetId: string,
        branchId: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultBranchResource>(
          ANALYSIS_RESULT_BRANCH_PATH,
          options,
          {
            path: {
              branch_id: branchId,
              dataset_id: datasetId,
              run_id: runId,
            },
          },
        ),
      branchPoints: (
        runId: string,
        datasetId: string,
        branchId: string,
        query: AnalysisResultPageQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultBranchPointPageResource>(
          ANALYSIS_RESULT_BRANCH_POINTS_PATH,
          options,
          {
            path: {
              branch_id: branchId,
              dataset_id: datasetId,
              run_id: runId,
            },
            query,
          },
        ),
      relations: (
        runId: string,
        datasetId: string,
        query: AnalysisResultPageQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultRelationPageResource>(
          ANALYSIS_RESULT_RELATIONS_PATH,
          options,
          { path: { run_id: runId, dataset_id: datasetId }, query },
        ),
      relation: (
        runId: string,
        datasetId: string,
        relationId: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultRelationResource>(
          ANALYSIS_RESULT_RELATION_PATH,
          options,
          {
            path: {
              dataset_id: datasetId,
              relation_id: relationId,
              run_id: runId,
            },
          },
        ),
      projection: (
        runId: string,
        datasetId: string,
        projectionId: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<AnalysisResultProjectionResource>(
          ANALYSIS_RESULT_PROJECTION_PATH,
          options,
          {
            path: {
              run_id: runId,
              dataset_id: datasetId,
              projection_id: projectionId,
            },
          },
        ),
    },
    eigen: {
      eigenBranchesV2: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_EIGEN_BRANCHES_V2_PATH,
          options,
        ),
      eigenDiagnosticsV2: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_EIGEN_DIAGNOSTICS_V2_PATH,
          options,
        ),
      eigenDispersion: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainTextArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_EIGEN_DISPERSION_PATH,
          options,
        ),
      eigenModeFieldMeta: (
        sampleIndex: number,
        modeIndex: number,
        options?: RequestOptions,
      ) =>
        this.requestJson<FrequencyDomainFieldResource>(
          ANALYSIS_FREQUENCY_DOMAIN_EIGEN_MODE_FIELD_META_PATH,
          options,
          {
            path: {
              sample_index: sampleIndex,
              mode_index: modeIndex,
            },
          },
        ),
      eigenSpectrumV2: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_EIGEN_SPECTRUM_V2_PATH,
          options,
        ),
      eigenSpectrumV3: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_EIGEN_SPECTRUM_V3_PATH,
          options,
        ),
    },
    frequencyDomain: {
      eigenBranchesV2: (options?: RequestOptions) =>
        this.analysis.eigen.eigenBranchesV2(options),
      eigenDiagnosticsV2: (options?: RequestOptions) =>
        this.analysis.eigen.eigenDiagnosticsV2(options),
      eigenDispersion: (options?: RequestOptions) =>
        this.analysis.eigen.eigenDispersion(options),
      eigenMode: (
        sampleIndex: number,
        modeIndex: number,
        options?: RequestOptions,
      ) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_EIGEN_MODE_PATH,
          options,
          {
            path: {
              sample_index: sampleIndex,
              mode_index: modeIndex,
            },
          },
        ),
      eigenModeFieldMeta: (
        sampleIndex: number,
        modeIndex: number,
        options?: RequestOptions,
      ) => this.analysis.eigen.eigenModeFieldMeta(sampleIndex, modeIndex, options),
      eigenSpectrumV2: (options?: RequestOptions) =>
        this.analysis.eigen.eigenSpectrumV2(options),
      eigenSpectrumV3: (options?: RequestOptions) =>
        this.analysis.eigen.eigenSpectrumV3(options),
      eigenFieldSweep: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_EIGEN_FIELD_SWEEP_PATH,
          options,
        ),
      fmrKittelFit: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_FMR_KITTEL_FIT_PATH,
          options,
        ),
      fmrPeaks: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_FMR_PEAKS_PATH,
          options,
        ),
      fmrResonanceFits: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_FMR_RESONANCE_FITS_PATH,
          options,
        ),
      manifestV1: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainManifestResource>(
          ANALYSIS_FREQUENCY_DOMAIN_MANIFEST_V1_PATH,
          options,
        ),
      responseDiagnosticsV1: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_DIAGNOSTICS_V1_PATH,
          options,
        ),
      responseFieldMeta: (frequencyIndex: number, options?: RequestOptions) =>
        this.requestJson<FrequencyDomainFieldResource>(
          ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_FIELD_META_PATH,
          options,
          { path: { frequency_index: frequencyIndex } },
        ),
      responseFrequencyPoint: (
        frequencyIndex: number,
        options?: RequestOptions,
      ) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_FREQUENCY_POINT_PATH,
          options,
          { path: { frequency_index: frequencyIndex } },
        ),
      responseMagneticSweep: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainJsonArtifactResource>(
          ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_MAGNETIC_SWEEP_PATH,
          options,
        ),
      responseCancelRequestedV1: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainSweepProgressResource>(
          ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_CANCEL_REQUESTED_V1_PATH,
          options,
        ),
      responseProgressV1: (options?: RequestOptions) =>
        this.requestJson<FrequencyDomainSweepProgressResource>(
          ANALYSIS_FREQUENCY_DOMAIN_RESPONSE_PROGRESS_V1_PATH,
          options,
        ),
    },
    frequencyResponse: {
      fieldMeta: (frequencyIndex: number, options?: RequestOptions) =>
        this.analysis.frequencyDomain.responseFieldMeta(frequencyIndex, options),
      frequencyPoint: (frequencyIndex: number, options?: RequestOptions) =>
        this.analysis.frequencyDomain.responseFrequencyPoint(
          frequencyIndex,
          options,
        ),
      magneticSweepV1: (options?: RequestOptions) =>
        this.requestJson<MagneticResponseSweepResource>(
          ANALYSIS_FREQUENCY_RESPONSE_MAGNETIC_SWEEP_V1_PATH,
          options,
        ),
      magneticSweepV2: (options?: RequestOptions) =>
        this.analysis.frequencyDomain.responseMagneticSweep(options),
    },
    extensions: {
      objects: {
        topologicalCharge: (
          objectId: string,
          query: TopologicalChargeQuery = {},
          options?: RequestOptions,
        ) =>
          this.requestJson<TopologicalChargeResource>(
            ANALYSIS_OBJECT_TOPOLOGICAL_CHARGE_PATH,
            options,
            {
              path: { object_id: objectId },
              query: topologicalChargeQueryParams(query),
            },
          ),
      },
    },
    hysteresis: {
      points: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisPointsResource>(
          ANALYSIS_HYSTERESIS_POINTS_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      metrics: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisMetricsResource>(
          ANALYSIS_HYSTERESIS_METRICS_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      saturation: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisSaturationResource>(
          ANALYSIS_HYSTERESIS_SATURATION_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      adaptiveRefinement: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisAdaptiveRefinementResource>(
          ANALYSIS_HYSTERESIS_ADAPTIVE_REFINEMENT_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      branches: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisBranchesResource>(
          ANALYSIS_HYSTERESIS_BRANCHES_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      bookmarks: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisBookmarksResource>(
          ANALYSIS_HYSTERESIS_BOOKMARKS_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      bookmarkPoint: (
        stageId: string,
        bookmark: HysteresisBookmarkPointRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<HysteresisBookmarksResource, HysteresisBookmarkPointRequest>(
          ANALYSIS_HYSTERESIS_BOOKMARKS_PATH,
          bookmark,
          options,
          { path: { stage_id: stageId } },
        ),
      family: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisAngularFamilyResource>(
          ANALYSIS_HYSTERESIS_FAMILY_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      familyVariantPoints: (
        stageId: string,
        variantId: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<HysteresisPointSchema[]>(
          ANALYSIS_HYSTERESIS_FAMILY_VARIANT_POINTS_PATH,
          options,
          { path: { stage_id: stageId, variant_id: variantId } },
        ),
      minorLoops: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisMinorLoopsResource>(
          ANALYSIS_HYSTERESIS_MINOR_LOOPS_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      reversalFields: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisReversalFieldsResource>(
          ANALYSIS_HYSTERESIS_REVERSAL_FIELDS_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      point: (stageId: string, pointId: number, options?: RequestOptions) =>
        this.requestJson<HysteresisPointSchema>(
          ANALYSIS_HYSTERESIS_POINT_PATH,
          options,
          { path: { stage_id: stageId, point_id: pointId } },
        ),
      stageSettleTrace: (stageId: string, options?: RequestOptions) =>
        this.requestJson<HysteresisSettleTraceResource>(
          ANALYSIS_HYSTERESIS_STAGE_SETTLE_TRACE_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      settleTrace: (stageId: string, pointId: number, options?: RequestOptions) =>
        this.requestJson<HysteresisSettleTraceEntrySchema[]>(
          ANALYSIS_HYSTERESIS_SETTLE_TRACE_PATH,
          options,
          { path: { stage_id: stageId, point_id: pointId } },
        ),
    },
  };

  readonly data = {
    antenna: {
      fieldSolution: (solutionId: string, options?: RequestOptions) =>
        this.requestJson<AntennaFieldSolutionResource>(
          DATA_ANTENNA_FIELD_SOLUTION_PATH,
          options,
          { path: { solution_id: solutionId } },
        ),
      fieldSolutionPayload: (
        solutionId: string,
        payloadKind: AntennaFieldPayloadKind,
        portModeId?: string,
        options?: BinaryRequestOptions,
      ) =>
        this.requestBinaryBytes(
          DATA_ANTENNA_FIELD_SOLUTION_PAYLOAD_PATH,
          options,
          { solution_id: solutionId, payload_kind: payloadKind },
          portModeId ? { port_mode_id: portModeId } : undefined,
        ),
      stageOutputCatalog: (stageId: string, options?: RequestOptions) =>
        this.requestJson<AntennaStageOutputCatalogResource>(
          DATA_ANTENNA_STAGE_OUTPUT_CATALOG_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      externalLeadInspection: (stageId: string, options?: RequestOptions) =>
        this.requestJson<AntennaExternalLeadInspectionResource>(
          DATA_ANTENNA_EXTERNAL_LEAD_INSPECTION_PATH,
          options,
          { path: { stage_id: stageId } },
        ),
      externalLeadInspectionDisplay: (
        stageId: string,
        contentDigest: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<AntennaInspectionDisplayResource>(
          DATA_ANTENNA_EXTERNAL_LEAD_INSPECTION_DISPLAY_PATH,
          options,
          { path: { stage_id: stageId }, query: { content_digest: contentDigest } },
        ),
      externalLeadInspectionPayload: (
        stageId: string,
        payloadKind: AntennaInspectionPayloadKind,
        contentDigest: string,
        options?: BinaryRequestOptions,
      ) =>
        this.requestBinaryBytes(
          DATA_ANTENNA_EXTERNAL_LEAD_INSPECTION_PAYLOAD_PATH,
          {
            ...options,
            maxResponseBytes: Math.min(
              options?.maxResponseBytes ?? MAX_ANTENNA_INSPECTION_BYTES,
              MAX_ANTENNA_INSPECTION_BYTES,
            ),
          },
          { stage_id: stageId, payload_kind: payloadKind },
          { content_digest: contentDigest },
        ),
      sourceSpectrum: (outputId: string, options?: RequestOptions) =>
        this.requestJson<AntennaSourceSpectrumResource>(
          DATA_ANTENNA_SOURCE_SPECTRUM_PATH,
          options,
          { path: { output_id: outputId } },
        ),
      sourceSpectrumPayload: (
        outputId: string,
        payloadKind: AntennaSpectrumPayloadKind,
        options?: BinaryRequestOptions,
      ) =>
        this.requestBinaryBytes(
          DATA_ANTENNA_SOURCE_SPECTRUM_PAYLOAD_PATH,
          options,
          { output_id: outputId, payload_kind: payloadKind },
        ),
    },
    artifacts: {
      list: (options?: RequestOptions) =>
        this.requestJson<ArtifactResource[]>(DATA_ARTIFACTS_PATH, options),
      bytes: (artifactRef: string, options?: BinaryRequestOptions) =>
        this.requestBinaryBytes(
          DATA_ARTIFACT_PATH,
          options,
          { artifact_id: artifactRef },
        ),
    },
    domain: {
      meta: (options?: RequestOptions) =>
        this.requestJson<DomainMetaResource>(DATA_DOMAIN_META_PATH, options),
      fdmMultilayerLayout: (options?: RequestOptions) =>
        this.requestJson<FdmMultilayerLayoutResource>(
          DATA_DOMAIN_FDM_MULTILAYER_LAYOUT_PATH,
          options,
        ),
      fdmMultilayerLayerActiveMaskBytes: (
        layerId: string,
        options?: BinaryRequestOptions,
      ) =>
        this.requestBinaryBytes(
          DATA_DOMAIN_FDM_MULTILAYER_LAYER_ACTIVE_MASK_PATH,
          options,
          { layer_id: layerId },
        ),
      fdmMultilayerLayerRegionMemberships: (
        layerId: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<FdmNativeLayerRegionMembershipResource>(
          DATA_DOMAIN_FDM_MULTILAYER_LAYER_REGION_MEMBERSHIPS_PATH,
          options,
          { path: { layer_id: layerId } },
        ),
      fdmMultilayerLayerRegionMembershipBytes: (
        layerId: string,
        options?: BinaryRequestOptions,
      ) =>
        this.requestBinaryBytes(
          DATA_DOMAIN_FDM_MULTILAYER_LAYER_REGION_MEMBERSHIP_PATH,
          options,
          { layer_id: layerId },
        ),
      topology: (options?: BinaryRequestOptions, query?: ArtifactCarrierGeometryQuery) =>
        this.requestTopology(DATA_DOMAIN_TOPOLOGY_PATH, options, undefined, query ? {
          carrier_id: query.carrier_id, stage_id: query.stage_id, expected_carrier_revision: query.expected_carrier_revision,
        } : undefined),
      topologyBytes: (options?: BinaryRequestOptions) =>
        this.requestBinaryBytes(DATA_DOMAIN_TOPOLOGY_PATH, options),
      topologyChunked: (options?: BinaryRequestOptions) =>
        this.requestTopologyChunked(DATA_DOMAIN_TOPOLOGY_PATH, options),
    },
    observationFrames: {
      list: (
        query: ObservationFrameListQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<ObservationFrameListResource>(
          DATA_OBSERVATION_FRAMES_PATH,
          options,
          { query },
        ),
      get: (frameId: string, options?: RequestOptions) =>
        this.requestJson<ObservationFrameResource>(
          DATA_OBSERVATION_FRAME_PATH,
          options,
          { path: { frame_id: frameId } },
        ),
      magnetization: (frameId: string, options?: BinaryRequestOptions) =>
        this.requestFieldVector(
          DATA_OBSERVATION_FRAME_MAGNETIZATION_PATH,
          { frame_id: frameId },
          {},
          options,
        ),
    },
    fields: {
      catalog: (options?: RequestOptions, query: ArtifactFieldCatalogQuery = {}) =>
        this.requestJson<FieldCatalogResource>(DATA_FIELDS_PATH, options, { query }).then(
          withDerivedDriveFluxDensity,
        ),
      availability: (
        quantityId: string,
        query: FieldAvailabilityQuery = {},
        options?: RequestOptions,
      ) => {
        const requestedQuantityId = resolveCanonicalQuantityId(quantityId);
        const storedQuantityId = storedFieldQuantityId(requestedQuantityId);
        return this.requestJson<FieldAvailabilityResource>(
          DATA_FIELD_AVAILABILITY_PATH,
          options,
          {
            path: { quantity_id: storedQuantityId },
            query: fieldAvailabilityQueryParams(query),
          },
        ).then((availability) =>
          requestedQuantityId === storedQuantityId
            ? availability
            : { ...availability, quantity_id: requestedQuantityId },
        );
      },
      meta: (
        quantityId: string,
        query: FieldMetaQuery = {},
        options?: RequestOptions,
      ) => {
        const requestedQuantityId = resolveCanonicalQuantityId(quantityId);
        const storedQuantityId = storedFieldQuantityId(requestedQuantityId);
        return this.requestFieldMeta(
          storedQuantityId,
          DATA_FIELD_META_PATH,
          {
            path: { quantity_id: storedQuantityId },
            query: fieldMetaQueryParams(query),
          },
          options,
        ).then((meta) => transformFieldMetaForDisplay(requestedQuantityId, meta));
      },
      vector: (
        quantityId: string,
        query: FieldVectorQuery = {},
        options?: BinaryRequestOptions,
      ) => {
        const requestedQuantityId = resolveCanonicalQuantityId(quantityId);
        const storedQuantityId = storedFieldQuantityId(requestedQuantityId);
        return this.requestFieldVectorOnDemand(
          storedQuantityId,
          DATA_FIELD_VECTOR_PATH,
          { quantity_id: storedQuantityId },
          fieldVectorQueryParams(query),
          fieldMetaQueryParams(query),
          options,
        ).then((result) => transformFieldVectorForDisplay(requestedQuantityId, result));
      },
      fdmVector: (
        quantityId: string,
        query: FdmScopedFieldVectorQuery,
        options?: BinaryRequestOptions,
      ) => this.data.fields.vector(quantityId, query, options),
      planar: {
        meta: (
          quantityId: string,
          source: PlanarFieldSource,
          query: PlanarFieldQuery = {},
          options?: RequestOptions,
        ) => {
          const request = planarRequestSpec(
            source,
            quantityId,
            DATA_PLANAR_FIELD_META_PATH,
            DATA_PLANAR_DEFAULT_FIELD_META_PATH,
          );
          return this.requestJson<PlanarFieldMetaResource>(request.path, options, {
            path: request.pathParams,
            query,
          });
        },
        scalar: (
          quantityId: string,
          source: PlanarFieldSource,
          query: PlanarFieldQuery = {},
          options?: BinaryRequestOptions,
        ) => {
          const request = planarRequestSpec(
            source,
            quantityId,
            DATA_PLANAR_FIELD_SCALAR_PATH,
            DATA_PLANAR_DEFAULT_FIELD_SCALAR_PATH,
          );
          return this.requestBinaryBytes(
            request.path,
            options,
            request.pathParams,
            query,
          );
        },
        vectors: (
          quantityId: string,
          source: PlanarFieldSource,
          query: PlanarFieldQuery = {},
          options?: BinaryRequestOptions,
        ) => {
          const request = planarRequestSpec(
            source,
            quantityId,
            DATA_PLANAR_FIELD_VECTORS_PATH,
            DATA_PLANAR_DEFAULT_FIELD_VECTORS_PATH,
          );
          return this.requestBinaryBytes(
            request.path,
            options,
            request.pathParams,
            query,
          );
        },
        emptyMask: (
          quantityId: string,
          source: PlanarFieldSource,
          query: PlanarFieldQuery = {},
          options?: BinaryRequestOptions,
        ) => {
          const request = planarRequestSpec(
            source,
            quantityId,
            DATA_PLANAR_FIELD_EMPTY_MASK_PATH,
            DATA_PLANAR_DEFAULT_FIELD_EMPTY_MASK_PATH,
          );
          return this.requestBinaryBytes(
            request.path,
            options,
            request.pathParams,
            query,
          );
        },
        meshOverlay: (
          quantityId: string,
          source: PlanarFieldSource,
          query: PlanarFieldQuery = {},
          options?: BinaryRequestOptions,
        ) => {
          const request = planarRequestSpec(
            source,
            quantityId,
            DATA_PLANAR_FIELD_MESH_OVERLAY_PATH,
            DATA_PLANAR_DEFAULT_FIELD_MESH_OVERLAY_PATH,
          );
          return this.requestBinaryBytes(
            request.path,
            options,
            request.pathParams,
            query,
          );
        },
        probe: (
          quantityId: string,
          source: PlanarFieldSource,
          query: PlanarFieldProbeQuery,
          options?: RequestOptions,
        ) => {
          const request = planarRequestSpec(
            source,
            quantityId,
            DATA_PLANAR_FIELD_PROBE_PATH,
            DATA_PLANAR_DEFAULT_FIELD_PROBE_PATH,
          );
          return this.requestJson<PlanarFieldProbeResource>(request.path, options, {
            path: request.pathParams,
            query,
          });
        },
        profile: (
          quantityId: string,
          source: PlanarFieldSource,
          query: PlanarFieldProfileQuery,
          options?: RequestOptions,
        ) => {
          const request = planarRequestSpec(
            source,
            quantityId,
            DATA_PLANAR_FIELD_PROFILE_PATH,
            DATA_PLANAR_DEFAULT_FIELD_PROFILE_PATH,
          );
          return this.requestJson<PlanarFieldProfileResource>(request.path, options, {
            path: request.pathParams,
            query,
          });
        },
        renderPng: (
          quantityId: string,
          source: PlanarFieldSource,
          query: PlanarFieldQuery = {},
          options?: BinaryRequestOptions,
        ) => {
          const request = planarRequestSpec(
            source,
            quantityId,
            DATA_PLANAR_FIELD_RENDER_PNG_PATH,
            DATA_PLANAR_DEFAULT_FIELD_RENDER_PNG_PATH,
          );
          return this.requestBinaryBytes(
            request.path,
            options,
            request.pathParams,
            query,
          );
        },
      },
    },
    quantities: {
      catalog: (options?: RequestOptions, query: ArtifactFieldCatalogQuery = {}) =>
        this.requestJson<QuantityCatalogResource>(DATA_QUANTITIES_PATH, options, { query }),
    },
    meshRegionMembership: (
      ownerObjectId: string,
      regionId: string,
      options?: RequestOptions,
    ) =>
      this.requestJson<MeshRegionMembershipResource>(
        DATA_MESH_REGION_MEMBERSHIP_PATH,
        options,
        {
          path: { region_id: regionId },
          query: { owner_object_id: ownerObjectId },
        },
      ),
    meshRegionMemberships: (options?: RequestOptions) =>
      this.requestJson<MeshRegionMembershipListResource>(
        DATA_MESH_REGION_MEMBERSHIPS_PATH,
        options,
      ),
    fdmRegionMemberships: (options?: RequestOptions) =>
      this.requestPendingJson<FdmRegionMembershipResource>(
        DATA_FDM_REGION_MEMBERSHIPS_PATH,
        options,
      ),
    fdmRegionMembershipBytes: (options?: BinaryRequestOptions) =>
      this.requestBinaryBytes(DATA_FDM_REGION_MEMBERSHIP_BINARY_PATH, options),
    fdmRegionMembershipRegionBytes: (
      ownerObjectId: string | null,
      regionId: string,
      options?: BinaryRequestOptions,
    ) =>
      this.requestBinaryBytes(
        DATA_FDM_REGION_MEMBERSHIP_SCOPED_PATH,
        options,
        { region_id: regionId },
        ownerObjectId ? { owner_object_id: ownerObjectId } : undefined,
      ),
    scalars: {
      window: (
        query: ScalarWindowQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<ScalarWindowResource>(
          DATA_SCALARS_PATH,
          options,
          { query: scalarWindowQueryParams(query) },
        ),
    },
    tables: {
      list: (options?: RequestOptions) =>
        this.requestJson<TableListResource>(DATA_TABLES_PATH, options),
      detail: (tableId: string, options?: RequestOptions) =>
        this.requestJson<TableResource>(
          DATA_TABLE_PATH,
          options,
          { path: { table_id: tableId } },
        ),
      columns: (tableId: string, options?: RequestOptions) =>
        this.requestJson<TableColumnMeta[]>(
          DATA_TABLE_COLUMNS_PATH,
          options,
          { path: { table_id: tableId } },
        ),
      rows: (
        tableId: string,
        query: TableRowsQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<TableRowsResource>(
          DATA_TABLE_ROWS_PATH,
          options,
          {
            path: { table_id: tableId },
            query: tableRowsQueryParams(query),
          },
        ),
      rowsBinary: (
        tableId: string,
        query: TableRowsQuery = {},
        options?: BinaryRequestOptions,
      ) =>
        this.requestTableRowsBinary(
          DATA_TABLE_ROWS_BINARY_PATH,
          { table_id: tableId },
          query,
          options,
        ),
    },
  };

  readonly diagnostics = {
    engineLog: (options?: RequestOptions) =>
      this.requestJson<EngineLogResource>(
        DIAGNOSTICS_ENGINE_LOG_PATH,
        options,
      ),
    cpuTelemetry: (options?: RequestOptions) =>
      this.requestJson<CpuTelemetryResource>(DIAGNOSTICS_CPU_PATH, options),
    gpuTelemetry: (options?: RequestOptions) =>
      this.requestJson<GpuTelemetryResource>(DIAGNOSTICS_GPU_PATH, options),
    solverProfile: (options?: RequestOptions) =>
      this.requestJson<SolverProfileResource>(
        DIAGNOSTICS_SOLVER_PROFILE_PATH,
        options,
      ),
    runPerformance: (options?: RequestOptions) =>
      this.requestJson<RunPerformanceResource>(
        DIAGNOSTICS_RUN_PERFORMANCE_PATH,
        options,
      ),
  };

  readonly meshing = {
    capabilities: (options?: RequestOptions) =>
      this.requestJson<MeshCapabilitiesResource>(
        MESHING_CAPABILITIES_PATH,
        options,
      ),
    semantics: (options?: RequestOptions) =>
      this.requestJson<MeshSemanticsResource>(MESHING_SEMANTICS_PATH, options),
    summary: (options?: RequestOptions) =>
      this.requestJson<MeshSummaryResource>(MESHING_SUMMARY_PATH, options),
    periodicPairs: (options?: RequestOptions) =>
      this.requestJson<MeshPeriodicPairsResource>(
        MESHING_PERIODIC_PAIRS_PATH,
        options,
      ),
    periodicPairsBinary: (options?: BinaryRequestOptions) =>
      this.requestBinaryResource(
        MESHING_PERIODIC_PAIRS_BINARY_PATH,
        "periodic-pairs",
        decodePeriodicPairs,
        options,
      ),
    builds: {
      history: (options?: RequestOptions) =>
        this.requestJson<MeshBuildHistoryResource>(MESHING_BUILDS_PATH, options),
      current: (options?: RequestOptions) =>
        this.requestJson<MeshActiveBuildResource>(
          MESHING_BUILDS_CURRENT_PATH,
          options,
        ),
      latestSuccessful: (options?: RequestOptions) =>
        this.requestJson<MeshLastSuccessfulBuildResource>(
          MESHING_BUILDS_LATEST_SUCCESSFUL_PATH,
          options,
        ),
    },
    objectPolicy: (objectId: string, options?: RequestOptions) =>
      this.requestJson<MeshObjectConfigResource>(
        MESHING_OBJECT_POLICY_PATH,
        options,
        {
          path: { object_id: objectId },
        },
      ),
    objectQuality: (objectId: string, options?: RequestOptions) =>
      this.requestJson<MeshObjectQualityResource>(
        MESHING_OBJECT_QUALITY_PATH,
        options,
        {
          path: { object_id: objectId },
        },
      ),
    regionQuality: (regionId: string, options?: RequestOptions) =>
      this.requestJson<MeshRegionQualityResource>(
        MESHING_REGION_QUALITY_PATH,
        options,
        {
          path: { region_id: regionId },
        },
      ),
    objectReport: (objectId: string, options?: RequestOptions) =>
      this.requestJson<MeshObjectReportResource>(
        MESHING_OBJECT_REPORT_PATH,
        options,
        {
          path: { object_id: objectId },
        },
      ),
    objectSizeField: (objectId: string, options?: RequestOptions) =>
      this.requestJson<MeshObjectSizeFieldResource>(
        MESHING_OBJECT_SIZE_FIELD_PATH,
        options,
        {
          path: { object_id: objectId },
        },
      ),
    objectTopology: (objectId: string, options?: BinaryRequestOptions) =>
      this.requestTopology(
        MESHING_OBJECT_TOPOLOGY_PATH,
        options,
        { object_id: objectId },
      ),
    partTopology: (partId: string, options?: BinaryRequestOptions) =>
      this.requestTopology(
        MESHING_PART_TOPOLOGY_PATH,
        options,
        { part_id: partId },
      ),
    histogramBinElements: (
      params: MeshHistogramBinElementsParams,
      options?: RequestOptions,
    ) =>
      this.requestJson<MeshHistogramBinElementsResource>(
        MESHING_HISTOGRAM_BIN_ELEMENTS_PATH,
        options,
        {
          path: {
            bin_index: params.binIndex,
            mesh_id: params.meshId,
            metric: params.metric,
            part_id: params.partId,
          },
        },
      ),
    replaceObjectPolicy: (
      objectId: string,
      request: MeshObjectConfigReplaceRequest,
      options?: RequestOptions,
    ) =>
      this.putJson<MeshObjectConfigResource, MeshObjectConfigReplaceRequest>(
        MESHING_OBJECT_POLICY_PATH,
        objectMeshPolicyWireRequest(request),
        options,
        {
          path: { object_id: objectId },
        },
      ),
    sharedDomain: {
      manifest: (options?: RequestOptions) =>
        this.requestOptionalJson<MeshSharedDomainManifestResource>(
          MESHING_SHARED_DOMAIN_MANIFEST_PATH,
          options,
        ),
      policy: (options?: RequestOptions) =>
        this.requestJson<MeshSharedDomainConfigResource>(
          MESHING_SHARED_DOMAIN_POLICY_PATH,
          options,
        ),
      quality: (options?: RequestOptions) =>
        this.requestJson<MeshSharedDomainQualityResource>(
          MESHING_SHARED_DOMAIN_QUALITY_PATH,
          options,
        ),
      crossSection: (
        query: CrossSectionQuery,
        options?: BinaryRequestOptions,
      ) =>
        this.requestCrossSection(
          MESHING_SHARED_DOMAIN_CROSS_SECTION_PATH,
          query,
          options,
        ),
      crossSectionImage: (
        query: CrossSectionImageQuery,
        options?: BinaryRequestOptions,
      ) =>
        this.requestCrossSectionImage(
          MESHING_SHARED_DOMAIN_CROSS_SECTION_IMAGE_PATH,
          query,
          options,
        ),
      crossSectionQuality: (
        query: CrossSectionQualityQuery,
        options?: BinaryRequestOptions,
      ) =>
        this.requestCrossSectionQuality(
          MESHING_SHARED_DOMAIN_CROSS_SECTION_QUALITY_PATH,
          query,
          options,
        ),
      qualityData: (options?: BinaryRequestOptions) =>
        this.requestMeshQualityData(
          MESHING_SHARED_DOMAIN_QUALITY_DATA_PATH,
          options,
        ),
      qualityGates: (options?: RequestOptions) =>
        this.requestJson<MeshQualityGatesResource>(
          MESHING_SHARED_DOMAIN_QUALITY_GATES_PATH,
          options,
        ),
      realizedSizeFields: (options?: RequestOptions) =>
        this.requestJson<MeshRealizedSizeFieldsResource>(
          MESHING_SHARED_DOMAIN_REALIZED_SIZE_FIELDS_PATH,
          options,
        ),
      report: (options?: RequestOptions) =>
        this.requestJson<MeshSharedDomainReportResource>(
          MESHING_SHARED_DOMAIN_REPORT_PATH,
          options,
        ),
      replacePolicy: (
        request: MeshSharedDomainConfigReplaceRequest,
        options?: RequestOptions,
      ) =>
        this.putJson<
          MeshSharedDomainConfigResource,
          MeshSharedDomainConfigReplaceRequest
        >(MESHING_SHARED_DOMAIN_POLICY_PATH, request, options),
      topology: (options?: BinaryRequestOptions) =>
        this.requestTopology(MESHING_SHARED_DOMAIN_TOPOLOGY_PATH, options),
    },
    sharedDomainManifest: (options?: RequestOptions) =>
      this.requestOptionalJson<MeshSharedDomainManifestResource>(
        MESHING_SHARED_DOMAIN_MANIFEST_PATH,
        options,
      ),
    sharedDomainTopology: (options?: BinaryRequestOptions) =>
      this.requestTopology(MESHING_SHARED_DOMAIN_TOPOLOGY_PATH, options),
    universePolicy: (options?: RequestOptions) =>
      this.requestJson<MeshUniverseConfigResource>(
        MESHING_UNIVERSE_POLICY_PATH,
        options,
      ),
    universeQuality: (options?: RequestOptions) =>
      this.requestJson<MeshUniverseQualityResource>(
        MESHING_UNIVERSE_QUALITY_PATH,
        options,
      ),
    universeReport: (options?: RequestOptions) =>
      this.requestJson<MeshUniverseReportResource>(
        MESHING_UNIVERSE_REPORT_PATH,
        options,
      ),
    replaceUniversePolicy: (
      request: MeshUniverseConfigReplaceRequest,
      options?: RequestOptions,
    ) =>
      this.putJson<MeshUniverseConfigResource, MeshUniverseConfigReplaceRequest>(
        MESHING_UNIVERSE_POLICY_PATH,
        request,
        options,
      ),
  };

  readonly model = {
    frozenSpins: {
      list: (options?: RequestOptions) =>
        this.requestJson<FrozenSpinsCollectionResource>(
          MODEL_FROZEN_SPINS_PATH,
          options,
        ),
      get: (constraintId: string, options?: RequestOptions) =>
        this.requestJson<FrozenSpinsDefinitionResource>(
          MODEL_FROZEN_SPIN_PATH,
          options,
          { path: { constraint_id: constraintId } },
        ),
      create: (
        request: FrozenSpinsMutationRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<FrozenSpinsDefinitionResource, FrozenSpinsMutationRequest>(
          MODEL_FROZEN_SPINS_PATH,
          request,
          options,
        ),
      patch: (
        constraintId: string,
        request: FrozenSpinsMutationRequest,
        options?: RequestOptions,
      ) =>
        this.patchJson<FrozenSpinsDefinitionResource, FrozenSpinsMutationRequest>(
          MODEL_FROZEN_SPIN_PATH,
          request,
          options,
          { path: { constraint_id: constraintId } },
        ),
      delete: (
        constraintId: string,
        request: FrozenSpinsDeleteRequest,
        options?: RequestOptions,
      ) =>
        this.deleteJsonWithBody<
          FrozenSpinsCollectionResource,
          FrozenSpinsDeleteRequest
        >(MODEL_FROZEN_SPIN_PATH, request, options, {
          path: { constraint_id: constraintId },
        }),
      createPreview: (
        request: FrozenSpinsPreviewRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<FrozenSpinsPreviewResponse, FrozenSpinsPreviewRequest>(
          MODEL_FROZEN_SPINS_PREVIEWS_PATH,
          request,
          options,
        ),
      getPreview: (previewId: string, options?: RequestOptions) =>
        this.requestJson<FrozenSpinsPreviewResponse>(
          MODEL_FROZEN_SPINS_PREVIEW_PATH,
          options,
          { path: { preview_id: previewId } },
        ),
      activatePreview: (
        previewId: string,
        request: FrozenSpinsPreviewActivationRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<
          FrozenSpinsPreviewActivationResponse,
          FrozenSpinsPreviewActivationRequest
        >(
          MODEL_FROZEN_SPINS_PREVIEW_ACTIVATE_PATH,
          request,
          options,
          { path: { preview_id: previewId } },
        ),
      resolvedMask: (
        maskId: string,
        options?: BinaryRequestOptions,
      ): Promise<BinaryResourceResult<ArrayBuffer>> =>
        this.requestBinaryBytes(
          DATA_FROZEN_SPINS_RESOLVED_MASK_PATH,
          options,
          { mask_id: maskId },
        ),
    },
    currentTransports: (options?: RequestOptions) =>
      this.requestJson<CurrentTransportListResource>(MODEL_CURRENT_TRANSPORTS_PATH, options),
    currentTransport: (id: string, options?: RequestOptions) =>
      this.requestJson<SceneCurrentTransport>(MODEL_CURRENT_TRANSPORT_PATH, options, { path: { id } }),
    createCurrentTransport: (request: CurrentTransportMutationRequest, options?: RequestOptions) =>
      this.postJson<CurrentTransportCommitResource, CurrentTransportMutationRequest>(MODEL_CURRENT_TRANSPORTS_PATH, request, options),
    replaceCurrentTransport: (id: string, request: CurrentTransportMutationRequest, options?: RequestOptions) =>
      this.patchJson<CurrentTransportCommitResource, CurrentTransportMutationRequest>(MODEL_CURRENT_TRANSPORT_PATH, request, options, { path: { id } }),
    deleteCurrentTransport: (id: string, request: SpinAuthoringDeleteRequest, options?: RequestOptions) =>
      this.deleteJsonWithBody<CurrentTransportCommitResource, SpinAuthoringDeleteRequest>(MODEL_CURRENT_TRANSPORT_PATH, request, options, { path: { id } }),
    spinTransports: (options?: RequestOptions) =>
      this.requestJson<SpinTransportListResource>(MODEL_SPIN_TRANSPORTS_PATH, options),
    spinTransport: (id: string, options?: RequestOptions) =>
      this.requestJson<SceneSpinTransport>(MODEL_SPIN_TRANSPORT_PATH, options, { path: { id } }),
    createSpinTransport: (request: SpinTransportMutationRequest, options?: RequestOptions) =>
      this.postJson<SpinTransportCommitResource, SpinTransportMutationRequest>(MODEL_SPIN_TRANSPORTS_PATH, request, options),
    replaceSpinTransport: (id: string, request: SpinTransportMutationRequest, options?: RequestOptions) =>
      this.patchJson<SpinTransportCommitResource, SpinTransportMutationRequest>(MODEL_SPIN_TRANSPORT_PATH, request, options, { path: { id } }),
    deleteSpinTransport: (id: string, request: SpinAuthoringDeleteRequest, options?: RequestOptions) =>
      this.deleteJsonWithBody<SpinTransportCommitResource, SpinAuthoringDeleteRequest>(MODEL_SPIN_TRANSPORT_PATH, request, options, { path: { id } }),
    spinInterfaces: (options?: RequestOptions) =>
      this.requestJson<SpinInterfaceListResource>(MODEL_SPIN_INTERFACES_PATH, options),
    validateTransport: (request: TransportValidationRequest, options?: RequestOptions) =>
      this.postJson<TransportValidationResponse, TransportValidationRequest>(MODEL_TRANSPORT_VALIDATION_PATH, request, options),
    spinTorques: (options?: RequestOptions) =>
      this.requestJson<SpinTorqueListResource>(MODEL_SPIN_TORQUES_PATH, options),
    spinTorque: (id: string, options?: RequestOptions) =>
      this.requestJson<SceneSpinTorque>(MODEL_SPIN_TORQUE_PATH, options, { path: { id } }),
    createSpinTorque: (request: SpinTorqueMutationRequest, options?: RequestOptions) =>
      this.postJson<SpinTorqueCommitResource, SpinTorqueMutationRequest>(MODEL_SPIN_TORQUES_PATH, request, options),
    replaceSpinTorque: (id: string, request: SpinTorqueMutationRequest, options?: RequestOptions) =>
      this.patchJson<SpinTorqueCommitResource, SpinTorqueMutationRequest>(MODEL_SPIN_TORQUE_PATH, request, options, { path: { id } }),
    deleteSpinTorque: (id: string, request: SpinAuthoringDeleteRequest, options?: RequestOptions) =>
      this.deleteJsonWithBody<SpinTorqueCommitResource, SpinAuthoringDeleteRequest>(MODEL_SPIN_TORQUE_PATH, request, options, { path: { id } }),
    oerstedFields: (options?: RequestOptions) =>
      this.requestJson<OerstedFieldListResource>(MODEL_OERSTED_FIELDS_PATH, options),
    oerstedField: (id: string, options?: RequestOptions) =>
      this.requestJson<SceneOerstedField>(MODEL_OERSTED_FIELD_PATH, options, { path: { id } }),
    createOerstedField: (request: OerstedFieldMutationRequest, options?: RequestOptions) =>
      this.postJson<OerstedFieldCommitResource, OerstedFieldMutationRequest>(MODEL_OERSTED_FIELDS_PATH, request, options),
    replaceOerstedField: (id: string, request: OerstedFieldMutationRequest, options?: RequestOptions) =>
      this.patchJson<OerstedFieldCommitResource, OerstedFieldMutationRequest>(MODEL_OERSTED_FIELD_PATH, request, options, { path: { id } }),
    deleteOerstedField: (id: string, request: SpinAuthoringDeleteRequest, options?: RequestOptions) =>
      this.deleteJsonWithBody<OerstedFieldCommitResource, SpinAuthoringDeleteRequest>(MODEL_OERSTED_FIELD_PATH, request, options, { path: { id } }),
    planarMonitors: {
      list: (options?: RequestOptions) =>
        this.requestJson<PlanarMonitorCollectionResource>(
          MODEL_PLANAR_MONITORS_PATH,
          options,
        ),
      get: (monitorId: string, options?: RequestOptions) =>
        this.requestJson<PlanarMonitorResource>(
          MODEL_PLANAR_MONITOR_PATH,
          options,
          { path: { monitor_id: monitorId } },
        ),
      create: (
        request: PlanarMonitorCreateRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<PlanarMonitorResource, PlanarMonitorCreateRequest>(
          MODEL_PLANAR_MONITORS_PATH,
          request,
          options,
        ),
      patch: (
        monitorId: string,
        request: PlanarMonitorPatchRequest,
        options?: RequestOptions,
      ) =>
        this.patchJson<PlanarMonitorResource, PlanarMonitorPatchRequest>(
          MODEL_PLANAR_MONITOR_PATH,
          request,
          options,
          { path: { monitor_id: monitorId } },
        ),
      remove: (
        monitorId: string,
        request: PlanarMonitorDeleteRequest,
        options?: RequestOptions,
      ) =>
        this.deleteJsonWithBody<
          PlanarMonitorCollectionResource,
          PlanarMonitorDeleteRequest
        >(MODEL_PLANAR_MONITOR_PATH, request, options, {
          path: { monitor_id: monitorId },
        }),
      duplicate: (
        monitorId: string,
        request: PlanarMonitorDuplicateRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<PlanarMonitorResource, PlanarMonitorDuplicateRequest>(
          MODEL_PLANAR_MONITOR_DUPLICATE_PATH,
          request,
          options,
          { path: { monitor_id: monitorId } },
        ),
    },
    commitTransaction: (
      transaction: AuthoringTransactionRequest,
      options?: RequestOptions,
    ) =>
      this.postJson<AuthoringTransactionResponse, AuthoringTransactionRequest>(
        MODEL_TRANSACTIONS_PATH,
        transaction,
        options,
      ),
    patchMagnetization: (
      objectId: string,
      regionId: string | null,
      asset: JsonObject | null,
      magnetizationRef: string | null,
      options?: AuthoringWriteOptions,
    ) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          ...(asset ? { asset } : {}),
          kind: "patch_magnetization",
          magnetization_ref: magnetizationRef,
          object_id: objectId,
          ...(regionId ? { region_id: regionId } : {}),
        },
        options,
      ),
    createObject: (request: ObjectCreateRequest, options?: RequestOptions) =>
      this.postJson<SceneResource, ObjectCreateRequest>(
        MODEL_OBJECTS_PATH,
        request,
        options,
      ),
    deleteObject: (objectId: string, options?: RequestOptions) =>
      this.deleteJson<SceneResource>(MODEL_OBJECT_PATH, options, {
        path: { object_id: objectId },
      }),
    createRegion: (
      objectId: string,
      region: components["schemas"]["SceneObjectRegion"],
      options?: AuthoringWriteOptions,
    ) =>
      this.postJson<SceneResource, ObjectRegionCreateRequest>(
        MODEL_OBJECT_REGIONS_PATH,
        {
          ...baseRevisionPayload(options),
          region,
        },
        options,
        { path: { object_id: objectId } },
      ),
    patchObjectRegionResource: (
      objectId: string,
      regionId: string,
      patch: components["schemas"]["SceneObjectRegionPatch"],
      options?: AuthoringWriteOptions,
    ) =>
      this.patchJson<SceneResource, ObjectRegionPatchRequest>(
        MODEL_OBJECT_REGION_PATH,
        {
          ...baseRevisionPayload(options),
          patch,
        },
        options,
        { path: { object_id: objectId, region_id: regionId } },
      ),
    deleteRegion: (objectId: string, regionId: string, options?: RequestOptions) =>
      this.deleteJson<SceneResource>(MODEL_OBJECT_REGION_PATH, options, {
        path: { object_id: objectId, region_id: regionId },
      }),
    duplicateObjectRegion: (
      objectId: string,
      regionId: string,
      request: Omit<ObjectRegionDuplicateRequest, "base_revision"> = {},
      options?: AuthoringWriteOptions,
    ) =>
      this.postJson<SceneResource, ObjectRegionDuplicateRequest>(
        MODEL_OBJECT_REGION_DUPLICATE_PATH,
        {
          ...baseRevisionPayload(options),
          ...request,
        },
        options,
        { path: { object_id: objectId, region_id: regionId } },
      ),
    reorderObjectRegions: (
      objectId: string,
      regionIds: string[],
      options?: AuthoringWriteOptions,
    ) =>
      this.postJson<SceneResource, ObjectRegionReorderRequest>(
        MODEL_OBJECT_REGIONS_REORDER_PATH,
        {
          ...baseRevisionPayload(options),
          region_ids: regionIds,
        },
        options,
        { path: { object_id: objectId } },
      ),
    geometry: {
      capabilities: (options?: RequestOptions) =>
        this.requestJson<GeometryCapabilitiesResource>(
          MODEL_GEOMETRY_CAPABILITIES_PATH,
          options,
        ),
      diagnostic: (diagnosticId: string, options?: RequestOptions) =>
        this.requestJson<GeometryDiagnosticsResource>(
          MODEL_GEOMETRY_DIAGNOSTIC_PATH,
          options,
          { path: { diagnostic_id: diagnosticId } },
        ),
      diagnostics: (options?: RequestOptions) =>
        this.requestJson<GeometryDiagnosticsResource>(
          MODEL_GEOMETRY_DIAGNOSTICS_PATH,
          options,
        ),
      realization: (options?: RequestOptions) =>
        this.requestJson<GeometryRealizationResource>(
          MODEL_GEOMETRY_REALIZATION_CURRENT_PATH,
          options,
        ),
      realize: (request: GeometryRealizationRequest, options?: RequestOptions) =>
        this.postJson<GeometryRealizationResource, GeometryRealizationRequest>(
          MODEL_GEOMETRY_REALIZATIONS_PATH,
          request,
          options,
        ),
      validation: (options?: RequestOptions) =>
        this.requestJson<GeometryValidationResource>(
          MODEL_GEOMETRY_VALIDATION_PATH,
          options,
        ),
    },
    patchObject: (
      objectId: string,
      patch: ObjectPatchRequest,
      options?: RequestOptions,
    ) =>
      this.patchJson<SceneResource, ObjectPatchRequest>(
        MODEL_OBJECT_PATH,
        patch,
        options,
        { path: { object_id: objectId } },
      ),
    patchObjectGeometry: (
      objectId: string,
      patch: ObjectGeometryPatchRequest,
      options?: RequestOptions,
    ) =>
      this.patchJson<SceneResource, ObjectGeometryPatchRequest>(
        MODEL_OBJECT_GEOMETRY_PATH,
        patch,
        options,
        { path: { object_id: objectId } },
      ),
    objectInteraction: (
      objectId: string,
      interactionKind: ObjectInteractionKind,
      options?: RequestOptions,
    ) =>
      this.requestJson<ObjectInteractionResource>(
        MODEL_OBJECT_INTERACTION_PATH,
        options,
        { path: { object_id: objectId, interaction_kind: interactionKind } },
      ),
    patchObjectInteraction: (
      objectId: string,
      interactionKind: ObjectInteractionKind,
      patch: ObjectInteractionPatchRequest,
      options?: RequestOptions,
    ) =>
      this.patchJson<ObjectInteractionResource, ObjectInteractionPatchRequest>(
        MODEL_OBJECT_INTERACTION_PATH,
        patch,
        options,
        { path: { object_id: objectId, interaction_kind: interactionKind } },
      ),
    material: (materialId: string, options?: RequestOptions) =>
      this.requestJson<MaterialResource>(MODEL_MATERIAL_PATH, options, {
        path: { material_id: materialId },
      }),
    createMaterial: (
      materialId: string,
      name: string,
      properties: MaterialPropertiesResource,
      references: MaterialReferenceResource[] = [],
      options?: AuthoringWriteOptions,
    ) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          kind: "create_material",
          material_id: materialId,
          name,
          properties,
          references,
        },
        options,
      ),
    magnetizationAsset: (assetId: string, options?: RequestOptions) =>
      this.requestJson<MagnetizationAssetResource>(
        MODEL_MAGNETIZATION_ASSET_PATH,
        options,
        { path: { asset_id: assetId } },
      ),
    patchMaterial: (
      materialId: string,
      patch: MaterialPatchRequest,
      options?: RequestOptions,
    ) =>
      this.patchJson<MaterialResource, MaterialPatchRequest>(
        MODEL_MATERIAL_PATH,
        patch,
        options,
        { path: { material_id: materialId } },
      ),
    patchMaterialAsset: (
      materialId: string,
      patch: MaterialPatchRequest,
      options?: AuthoringWriteOptions,
    ) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          kind: "patch_material",
          material_id: materialId,
          patch,
        },
        options,
      ),
    deleteMaterial: (materialId: string, options?: AuthoringWriteOptions) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          kind: "delete_material",
          material_id: materialId,
        },
        options,
      ),
    patchMagnetizationAsset: (
      assetId: string,
      patch: MagnetizationAssetPatchRequest,
      options?: RequestOptions,
    ) =>
      this.patchJson<MagnetizationAssetResource, MagnetizationAssetPatchRequest>(
        MODEL_MAGNETIZATION_ASSET_PATH,
        patch,
        options,
        { path: { asset_id: assetId } },
      ),
    regions: (options?: RequestOptions) =>
      this.requestJson<RegionListResource>(MODEL_REGIONS_PATH, options),
    realizedRegions: (options?: RequestOptions) =>
      this.requestJson<RegionListResource>(
        MODEL_REALIZED_REGIONS_PATH,
        options,
      ),
    regionDiagnostics: (options?: RequestOptions) =>
      this.requestJson<RegionDiagnosticsResource>(
        MODEL_REGION_DIAGNOSTICS_PATH,
        options,
      ),
    materialFields: (options?: RequestOptions) =>
      this.requestJson<MaterialParameterFieldListResource>(
        MODEL_MATERIAL_FIELDS_PATH,
        options,
      ),
    couplings: (options?: RequestOptions) =>
      this.requestJson<CouplingListResource>(MODEL_COUPLINGS_PATH, options),
    fieldDrives: (options?: RequestOptions) =>
      this.requestJson<FieldDriveListResource>(MODEL_FIELD_DRIVES_PATH, options),
    createFieldDrive: (
      request: FieldDriveCreateRequest,
      options?: RequestOptions,
    ) =>
      this.postJson<AuthoringTransactionResponse, FieldDriveCreateRequest>(
        MODEL_FIELD_DRIVES_PATH,
        request,
        options,
      ),
    replaceFieldDrive: (
      driveId: string,
      request: FieldDriveReplaceRequest,
      options?: RequestOptions,
    ) =>
      this.putJson<AuthoringTransactionResponse, FieldDriveReplaceRequest>(
        MODEL_FIELD_DRIVE_PATH,
        request,
        options,
        { path: { drive_id: driveId } },
      ),
    deleteFieldDrive: (
      driveId: string,
      request: FieldDriveDeleteRequest,
      options?: RequestOptions,
    ) =>
      this.deleteJsonWithBody<AuthoringTransactionResponse, FieldDriveDeleteRequest>(
        MODEL_FIELD_DRIVE_PATH,
        request,
        options,
        { path: { drive_id: driveId } },
      ),
    createObjectRegion: (
      objectId: string,
      region: components["schemas"]["SceneObjectRegion"],
      options?: AuthoringWriteOptions,
    ) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          kind: "create_object_region",
          object_id: objectId,
          region,
        },
        options,
      ),
    patchObjectRegion: (
      objectId: string,
      regionId: string,
      patch: components["schemas"]["SceneObjectRegionPatch"],
      options?: AuthoringWriteOptions,
    ) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          kind: "patch_object_region",
          object_id: objectId,
          patch,
          region_id: regionId,
        },
        options,
      ),
    patchObjectMaterialFields: (
      objectId: string,
      fields: components["schemas"]["SceneMaterialParameterAssignment"][],
      options?: AuthoringWriteOptions,
    ) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          fields,
          kind: "patch_object_material_fields",
          object_id: objectId,
        },
        options,
      ),
    deleteObjectRegion: (
      objectId: string,
      regionId: string,
      options?: AuthoringWriteOptions,
    ) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          kind: "delete_object_region",
          object_id: objectId,
          region_id: regionId,
        },
        options,
      ),
    createCoupling: (
      coupling: components["schemas"]["SceneCoupling"],
      options?: AuthoringWriteOptions,
    ) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          coupling,
          kind: "create_coupling",
        },
        options,
      ),
    patchCoupling: (
      couplingId: string,
      patch: components["schemas"]["SceneCouplingPatch"],
      options?: AuthoringWriteOptions,
    ) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          coupling_id: couplingId,
          kind: "patch_coupling",
          patch,
        },
        options,
      ),
    deleteCoupling: (couplingId: string, options?: AuthoringWriteOptions) =>
      this.model.commitTransaction(
        {
          ...baseRevisionPayload(options),
          coupling_id: couplingId,
          kind: "delete_coupling",
        },
        options,
      ),
    patchRegion: (
      regionId: string,
      patch: RegionPatchRequest,
      options?: AuthoringWriteOptions,
    ) =>
      this.patchJson<SceneResource, RegionPatchRequest>(
        MODEL_REGION_PATH,
        { ...baseRevisionPayload(options), ...patch },
        options,
        { path: { region_id: regionId } },
      ),
    scene: (options?: RequestOptions) =>
      this.requestJson<SceneResource>(MODEL_SCENE_PATH, options),
    readiness: (options?: RequestOptions) =>
      this.requestJson<ModelReadinessResource>(MODEL_READINESS_PATH, options),
    physicsGraph: (options?: RequestOptions) =>
      this.requestJson<PhysicsGraphResource>(MODEL_PHYSICS_GRAPH_PATH, options),
    authoringScript: (options?: RequestOptions) =>
      this.requestJson<ScriptSourceResponse>(MODEL_SCRIPT_PATH, options),
    syncAuthoringScript: (
      request: ScriptSyncRequest,
      options?: RequestOptions,
    ) =>
      this.postJson<ScriptSyncResponse, ScriptSyncRequest>(
        MODEL_SYNCS_PATH,
        request,
        options,
      ),
    study: (options?: RequestOptions) =>
      this.requestJson<StudyRuntimeResource>(MODEL_STUDY_PATH, options),
    patchStudy: (
      patch: StudyRuntimePatchRequest,
      options?: RequestOptions,
    ) =>
      this.patchJson<StudyRuntimeResource, StudyRuntimePatchRequest>(
        MODEL_STUDY_PATH,
        patch,
        options,
      ),
    universe: (options?: RequestOptions) =>
      this.requestJson<UniverseResource>(MODEL_UNIVERSE_PATH, options),
    updateUniverse: (patch: UniversePatchRequest, options?: RequestOptions) =>
      this.patchJson<UniverseResource, UniversePatchRequest>(
        MODEL_UNIVERSE_PATH,
        patch,
        options,
      ),
  };

  readonly persistence = {
    assets: {
      import: (
        request: ImportSessionAssetRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<SessionAssetImportResponse, ImportSessionAssetRequest>(
          PERSISTENCE_ASSET_IMPORT_PATH,
          request,
          options,
        ),
    },
    checkpoints: {
      create: (request: CheckpointCreateRequest, options?: RequestOptions) =>
        this.postJson<CheckpointCreateResponse, CheckpointCreateRequest>(
          PERSISTENCE_CHECKPOINTS_PATH,
          request,
          options,
        ),
      /** 204 on success; 404 for an unknown id; 409 while still referenced. */
      delete: (checkpointId: string, options?: RequestOptions) =>
        this.deleteJson<void>(PERSISTENCE_CHECKPOINT_PATH, options, {
          path: { checkpoint_id: checkpointId },
        }),
      detail: (checkpointId: string, options?: RequestOptions) =>
        this.requestJson<CheckpointEntry>(
          PERSISTENCE_CHECKPOINT_PATH,
          options,
          { path: { checkpoint_id: checkpointId } },
        ),
      list: (options?: RequestOptions) =>
        this.requestJson<CheckpointListResource>(
          PERSISTENCE_CHECKPOINTS_PATH,
          options,
        ),
      restore: (
        checkpointId: string,
        request: CheckpointRestoreRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<CheckpointRestoreResponse, CheckpointRestoreRequest>(
          PERSISTENCE_CHECKPOINT_RESTORE_PATH,
          request,
          options,
          { path: { checkpoint_id: checkpointId } },
        ),
    },
    exports: {
      create: (request: SessionExportRequest, options?: RequestOptions) =>
        this.postJson<SessionExportResponse, SessionExportRequest>(
          PERSISTENCE_EXPORTS_PATH,
          request,
          options,
        ),
    },
    fieldStates: {
      export: (
        request: FieldStateExportRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<FieldStateExportResponse, FieldStateExportRequest>(
          PERSISTENCE_FIELD_STATE_EXPORTS_PATH,
          request,
          options,
        ),
      inspectImport: (
        request: FieldStateInspectRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<FieldStateInspectResponse, FieldStateInspectRequest>(
          PERSISTENCE_FIELD_STATE_IMPORT_INSPECTIONS_PATH,
          request,
          options,
        ),
      import: (
        request: FieldStateImportRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<FieldStateImportResponse, FieldStateImportRequest>(
          PERSISTENCE_FIELD_STATE_IMPORTS_PATH,
          request,
          options,
        ),
    },
    imports: {
      commit: (request: SessionImportCommitRequest, options?: RequestOptions) =>
        this.postJson<SessionImportCommitResponse, SessionImportCommitRequest>(
          PERSISTENCE_IMPORTS_PATH,
          request,
          options,
        ),
      inspect: (
        request: SessionImportInspectRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<
          SessionImportInspectResponse,
          SessionImportInspectRequest
        >(PERSISTENCE_IMPORT_INSPECTIONS_PATH, request, options),
    },
    projects: {
      listRuns: (
        projectId: string,
        query: ProjectRunListQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<ProjectRunListResource>(
          PROJECT_RUN_SUBMIT_PATH,
          options,
          { path: { project_id: projectId }, query },
        ),
      listBatches: (
        projectId: string,
        query: ProjectBatchListQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<ProjectBatchListResource>(
          PROJECT_BATCHES_PATH,
          options,
          { path: { project_id: projectId }, query },
        ),
      listBatchCases: (
        projectId: string,
        batchId: string,
        query: ProjectBatchCasesQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<ProjectBatchCasesResource>(
          PROJECT_BATCH_CASES_PATH,
          options,
          { path: { project_id: projectId, batch_id: batchId }, query },
        ),
      commandBatch: (
        projectId: string,
        batchId: string,
        request: ProjectBatchCommandRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<ProjectBatchCommandResource, ProjectBatchCommandRequest>(
          PROJECT_BATCH_COMMANDS_PATH,
          request,
          options,
          { path: { project_id: projectId, batch_id: batchId } },
        ),
      getRun: (projectId: string, runId: string, options?: RequestOptions) =>
        this.requestJson<ProjectRunResource>(
          PROJECT_RUN_PATH,
          options,
          { path: { project_id: projectId, run_id: runId } },
        ),
      solutionSets: (
        projectId: string,
        runId: string,
        query: SolutionSetDiscoveryPageQuery = {},
        options?: RequestOptions,
      ) => {
        const limit = query.limit ?? 25;
        if (!Number.isInteger(limit) || limit < 1 || limit > 50) {
          throw new Error("Solution discovery limit must be between 1 and 50.");
        }
        const cursor = query.cursor ?? undefined;
        if (cursor !== undefined &&
          (cursor.length > 4096 || !/^[A-Za-z0-9_-]+$/.test(cursor))) {
          throw new Error("Invalid solution discovery cursor.");
        }
        return this.requestJson<SolutionSetDiscoveryPageResource>(
          PROJECT_SOLUTION_SET_DISCOVERY_PATH,
          options,
          {
            path: {
              project_id: assertSolutionSetProjectId(projectId),
              run_id: assertSolutionSetRunId(runId),
            },
            query: { cursor, limit },
          },
        );
      },
      solutionSet: (
        projectId: string,
        runId: string,
        solutionSetId: string,
        revision: SolutionSetRevision,
        options?: RequestOptions,
      ) =>
        this.requestJson<SolutionSetResource>(
          PROJECT_SOLUTION_SET_PATH,
          options,
          {
            path: {
              project_id: assertSolutionSetProjectId(projectId),
              revision: assertSolutionSetRevision(revision),
              run_id: assertSolutionSetRunId(runId),
              solution_set_id: assertSolutionSetLogicalId(solutionSetId),
            },
          },
        ),
      solutionSetMembers: (
        projectId: string,
        runId: string,
        solutionSetId: string,
        revision: SolutionSetRevision,
        query: SolutionSetMemberPageQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<SolutionSetMemberPageResource>(
          PROJECT_SOLUTION_SET_MEMBERS_PATH,
          options,
          {
            path: {
              project_id: assertSolutionSetProjectId(projectId),
              revision: assertSolutionSetRevision(revision),
              run_id: assertSolutionSetRunId(runId),
              solution_set_id: assertSolutionSetLogicalId(solutionSetId),
            },
            query: normalizeSolutionSetPageQuery(query),
          },
        ),
      solutionSetArtifacts: (
        projectId: string,
        runId: string,
        solutionSetId: string,
        revision: SolutionSetRevision,
        memberId: string,
        query: SolutionSetArtifactPageQuery = {},
        options?: RequestOptions,
      ) =>
        this.requestJson<SolutionSetArtifactPageResource>(
          PROJECT_SOLUTION_SET_ARTIFACTS_PATH,
          options,
          {
            path: {
              member_id: assertSolutionSetMemberId("member id", memberId),
              project_id: assertSolutionSetProjectId(projectId),
              revision: assertSolutionSetRevision(revision),
              run_id: assertSolutionSetRunId(runId),
              solution_set_id: assertSolutionSetLogicalId(solutionSetId),
            },
            query: normalizeSolutionSetPageQuery(query),
          },
        ),
      materializedDataset: (
        projectId: string,
        runId: string,
        solutionSetId: string,
        revision: SolutionSetRevision,
        memberId: string,
        artifactId: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<MaterializedDatasetResource>(
          PROJECT_MATERIALIZED_DATASET_PATH,
          options,
          {
            path: {
              project_id: assertSolutionSetProjectId(projectId),
              run_id: assertSolutionSetRunId(runId),
              solution_set_id: assertSolutionSetLogicalId(solutionSetId),
              revision: assertSolutionSetRevision(revision),
              member_id: assertMaterializedDatasetPathId("member id", memberId),
              artifact_id: assertMaterializedDatasetPathId("artifact id", artifactId),
            },
          },
        ),
      solutionScalar: (
        projectId: string,
        runId: string,
        solutionSetId: string,
        revision: SolutionSetRevision,
        memberId: string,
        artifactId: string,
        options?: RequestOptions,
      ) =>
        this.requestJson<SolutionScalarResource>(
          PROJECT_SOLUTION_SCALAR_PATH,
          options,
          {
            path: {
              project_id: assertSolutionSetProjectId(projectId),
              run_id: assertSolutionSetRunId(runId),
              solution_set_id: assertSolutionSetLogicalId(solutionSetId),
              revision: assertSolutionSetRevision(revision),
              member_id: assertMaterializedDatasetPathId("member id", memberId),
              artifact_id: assertMaterializedDatasetPathId("artifact id", artifactId),
            },
          },
        ),
      materializedDatasetSlice: async (
        dataset: MaterializedDatasetResource,
        range: MaterializedDatasetSliceRange,
        options?: RequestOptions,
      ) => {
        const result = await this.requestBinaryBytes(
          PROJECT_MATERIALIZED_DATASET_SLICE_PATH,
          { signal: options?.signal, maxResponseBytes: materializedDatasetSliceByteLimit(range) },
          {
            project_id: assertSolutionSetProjectId(dataset.project_id),
            run_id: assertSolutionSetRunId(dataset.run_id),
            solution_set_id: assertSolutionSetLogicalId(dataset.solution_set_id),
            revision: assertSolutionSetRevision(dataset.containing_solution_revision),
            member_id: assertMaterializedDatasetPathId("member id", dataset.member_id),
            artifact_id: assertMaterializedDatasetPathId("artifact id", dataset.artifact_id),
          },
          {
            schema_version: "1.0.0",
            dataset_id: dataset.dataset.dataset_id,
            dataset_revision: assertSolutionSetRevision(dataset.dataset.revision),
            sample_id: dataset.sample_id,
            item_id: dataset.item_id,
            field_id: dataset.field_id,
            expected_manifest_object_ref: dataset.manifest_object_ref,
            element_offset: range.elementOffset,
            element_count: range.elementCount,
            max_response_bytes: range.maxResponseBytes,
          },
        );
        if (result.status !== "ready") {
          throw new ControlRoomApiError("Expected a complete pinned dataset slice response", 0);
        }
        return decodeMaterializedDatasetSlice(result.data, dataset, range, options?.signal);
      },
      savedPlanar: async (
        dataset: MaterializedDatasetResource,
        geometry: SavedFieldGeometryResource,
        query: SavedPlanarQuery,
        options?: RequestOptions,
      ) => {
        validateSavedGeometry(geometry, dataset);
        const path = savedGeometryPath(dataset);
        const meta = await this.requestJson<SavedPlanarResource>(
          PROJECT_SAVED_PLANAR_META_PATH, options, { path, query },
        );
        validateSavedGeometry(meta.source, dataset);
        if (meta.source.geometry_payload.object_ref !== geometry.geometry_payload.object_ref ||
            meta.source.geometry_manifest.object_ref !== geometry.geometry_manifest.object_ref ||
            meta.reconstruction !== "tet4_linear_inspection_v1" || meta.qualification !== "not_verified" ||
            meta.resolution[0] !== query.width || meta.resolution[1] !== query.height ||
            meta.component !== query.component || !meta.request_identity ||
            !savedPlanarFrameMatches(meta, query) ||
            JSON.stringify(meta.bounds_uv_m) !== JSON.stringify([query.u_min_m, query.u_max_m, query.v_min_m, query.v_max_m]) ||
            meta.occupancy_encoding !== "uint8.planar_occupancy.v1") {
          throw new ControlRoomApiError("Saved planar source or request identity mismatch", 0);
        }
        const read = async (route: OpenApiV2Path) => {
          const result = await this.requestBinaryResource(route, "raw-bytes", buffer => buffer,
            { signal: options?.signal, maxResponseBytes: Number(query.max_response_bytes) }, path, query,
            response => {
              if (response.headers.get("x-fullmag-planar-identity") !== meta.request_identity) {
                throw new ControlRoomApiError("Saved planar binary identity mismatch", 0);
              }
            });
          if (result.status !== "ready") throw new ControlRoomApiError("Saved planar body is incomplete", 0);
          return result.data;
        };
        const [scalarBody, vectorBody, maskBody] = await Promise.all([
          read(PROJECT_SAVED_PLANAR_SCALAR_PATH), read(PROJECT_SAVED_PLANAR_VECTORS_PATH),
          read(PROJECT_SAVED_PLANAR_OCCUPANCY_PATH),
        ]);
        const scalar = decodeFieldVector(scalarBody);
        const vectors = decodeFieldVector(vectorBody);
        const mask = new Uint8Array(maskBody);
        const count = query.width * query.height;
        if (scalar.nComp !== 1 || vectors.nComp !== 3 || scalar.pointCount !== count ||
            vectors.pointCount !== count || mask.length !== count ||
            scalar.grid[0] !== query.width || scalar.grid[1] !== query.height ||
            vectors.grid[0] !== query.width || vectors.grid[1] !== query.height ||
            mask.some(value => value > 4)) {
          throw new ControlRoomApiError("Saved planar raster layout mismatch", 0);
        }
        for (let index = 0; index < count; index += 1) {
          if (mask[index] === 0 && (!Number.isFinite(scalar.values[index]) ||
              ![0, 1, 2].every(axis => Number.isFinite(vectors.values[index * 3 + axis])))) {
            throw new ControlRoomApiError("Saved planar occupied sample is nonfinite", 0);
          }
        }
        this.requireApiInstanceCurrent();
        return { meta, scalar: scalar.values, vectors: vectors.values, mask };
      },
      savedFieldGeometry: async (
        dataset: MaterializedDatasetResource,
        options?: RequestOptions,
        query: SavedFieldGeometryQuery = {},
      ) => {
        const geometry = await this.requestJson<SavedFieldGeometryResource>(
          PROJECT_SAVED_FIELD_GEOMETRY_PATH, options, { path: savedGeometryPath(dataset), query },
        );
        return validateSavedGeometry(geometry, dataset);
      },
      savedFieldTopology: async (
        dataset: MaterializedDatasetResource,
        geometry: SavedFieldGeometryResource,
        options?: RequestOptions,
      ) => {
        validateSavedGeometry(geometry, dataset);
        if (geometry.topology_binary_byte_length == null || geometry.topology_binary_sha256 == null) {
          return null;
        }
        const limit = savedTopologyByteLimit(geometry);
        const result = await this.requestBinaryBytes(
          PROJECT_SAVED_FIELD_TOPOLOGY_PATH,
          { signal: options?.signal, maxResponseBytes: limit },
          savedGeometryPath(dataset), savedGeometryBinaryQuery(geometry, limit),
        );
        if (result.status === "not-applicable") return null;
        if (result.status !== "ready") throw new ControlRoomApiError("Expected a complete pinned topology body", 0);
        await verifySavedTopologyBody(result.data, geometry, options?.signal);
        this.requireApiInstanceCurrent();
        const topology = await this.binaryDecodeScheduler({
          buffer: result.data,
          decodeInline: decodeTopology,
          kind: "topology",
          path: PROJECT_SAVED_FIELD_TOPOLOGY_PATH,
          signal: options?.signal,
        });
        this.requireApiInstanceCurrent();
        if (topology.formatVersion !== 2 || String(topology.nodeCount) !== geometry.node_count ||
            String(topology.cellCount) !== geometry.cell_count || String(topology.facetCount) !== geometry.facet_count) {
          throw new ControlRoomApiError("Pinned topology extents differ from saved geometry", 0);
        }
        return topology;
      },
      savedFieldSupport: async (
        dataset: MaterializedDatasetResource,
        geometry: SavedFieldGeometryResource,
        options?: RequestOptions,
      ) => {
        validateSavedGeometry(geometry, dataset);
        if (geometry.support_binary_byte_length == null || geometry.support_binary_sha256 == null) {
          return null;
        }
        const identity = { nodeCount: geometry.node_count, byteLength: geometry.support_binary_byte_length, sha256: geometry.support_binary_sha256 };
        const limit = savedSupportByteLimit(identity);
        const result = await this.requestBinaryBytes(
          PROJECT_SAVED_FIELD_SUPPORT_PATH,
          { signal: options?.signal, maxResponseBytes: limit },
          savedGeometryPath(dataset), savedGeometryBinaryQuery(geometry, limit),
        );
        if (result.status === "not-applicable") return null;
        if (result.status !== "ready") throw new ControlRoomApiError("Expected a complete pinned support body", 0);
        const support = await decodeSavedSupport(result.data, identity, options?.signal);
        this.requireApiInstanceCurrent();
        let active = 0;
        for (const byte of support.bits) {
          let remaining = byte;
          while (remaining !== 0) { remaining &= remaining - 1; active += 1; }
        }
        if (String(active) !== geometry.active_node_count) throw new ControlRoomApiError("Pinned support active count mismatch", 0);
        return support;
      },
      create: (request: ProjectCreateRequest, options?: RequestOptions) =>
        this.postJson<ProjectDocumentResource, ProjectCreateRequest>(
          PERSISTENCE_PROJECTS_PATH,
          request,
          options,
        ),
      open: (request: ProjectArchiveRequest, options?: RequestOptions) =>
        this.postJson<ProjectDocumentResource, ProjectArchiveRequest>(
          PERSISTENCE_PROJECT_OPEN_PATH,
          request,
          options,
        ),
      /**
       * Executes the supplied script in the Python helper (the request must
       * carry `consent.executed_by_user: true`) and returns a project with the
       * script embedded plus a fidelity verdict.
       */
      fromScript: (request: ProjectFromScriptRequest, options?: RequestOptions) =>
        this.postJson<ProjectFromScriptResource, ProjectFromScriptRequest>(
          PERSISTENCE_PROJECT_FROM_SCRIPT_PATH,
          request,
          options,
        ),
      authoringUpdate: (request: ProjectAuthoringUpdateRequest, options?: RequestOptions) =>
        this.postJson<ProjectDocumentResource, ProjectAuthoringUpdateRequest>(
          PERSISTENCE_PROJECT_AUTHORING_PATH,
          request,
          options,
        ),
      submitBatch: (
        projectId: string,
        request: ProjectBatchSubmitRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<ProjectBatchSubmitResource, ProjectBatchSubmitRequest>(
          PROJECT_BATCHES_PATH,
          request,
          options,
          { path: { project_id: projectId } },
        ),
      submitRun: (
        projectId: string,
        request: ProjectRunSubmitRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<ProjectRunSubmitResource, ProjectRunSubmitRequest>(
          PROJECT_RUN_SUBMIT_PATH,
          request,
          options,
          { path: { project_id: projectId } },
        ),
      materializeRun: (
        projectId: string,
        runId: string,
        options?: RequestOptions,
      ) =>
        this.postJson<ProjectRunMaterializationResource, undefined>(
          PROJECT_RUN_MATERIALIZATION_PATH,
          undefined,
          options,
          { path: { project_id: projectId, run_id: runId } },
        ),
      cancelRunTask: (
        projectId: string,
        runId: string,
        taskId: string,
        request: ProjectRunTaskCancellationRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<
          ProjectRunTaskCancellationResource,
          ProjectRunTaskCancellationRequest
        >(
          PROJECT_RUN_TASK_CANCELLATION_PATH,
          request,
          options,
          {
            path: {
              project_id: projectId,
              run_id: runId,
              task_id: taskId,
            },
          },
        ),
      retryRunTask: (
        projectId: string,
        runId: string,
        taskId: string,
        request: ProjectRunTaskRetryRequest,
        options?: RequestOptions,
      ) =>
        this.postJson<ProjectRunTaskRetryResource, ProjectRunTaskRetryRequest>(
          PROJECT_RUN_TASK_RETRY_PATH,
          request,
          options,
          {
            path: {
              project_id: projectId,
              run_id: runId,
              task_id: taskId,
            },
          },
        ),
    },
  };

  readonly simulation = {
    currentRun: (options?: RequestOptions) =>
      this.requestJson<CurrentRunResource>(
        SIMULATION_RUN_CURRENT_PATH,
        options,
      ),
    preparation: (options?: RequestOptions) =>
      this.requestJson<SimulationPreparationResource>(
        SIMULATION_PREPARATION_PATH,
        options,
      ),
    materializePreparation: (
      request: LivePreparationMaterializationRequest,
      options?: RequestOptions,
    ) =>
      this.postJson<
        LivePreparationMaterializationResource,
        LivePreparationMaterializationRequest
      >(
        SIMULATION_PREPARATION_MATERIALIZATION_PATH,
        request,
        options,
      ),
    objects: {
      metrics: (objectId: string, options?: RequestOptions) =>
        this.requestJson<ObjectMetricsResource>(
          SIMULATION_OBJECT_METRICS_PATH,
          options,
          { path: { object_id: objectId } },
        ),
    },
    run: (runId: string, options?: RequestOptions) =>
      this.requestJson<CurrentRunResource>(
        SIMULATION_RUN_PATH,
        options,
        { path: { run_id: runId } },
      ),
    stages: {
      execution: (options?: RequestOptions) =>
        this.requestOptionalJson<StageExecutionResource>(
          SIMULATION_STAGES_EXECUTION_PATH,
          options,
        ),
      hysteresis: {
        plan: (stageId: string, options?: RequestOptions) =>
          this.requestJson<HysteresisStagePlanSchema>(
            SIMULATION_STAGE_HYSTERESIS_PLAN_PATH,
            options,
            { path: { stage_id: stageId } },
          ),
        protocol: (stageId: string, options?: RequestOptions) =>
          this.requestJson<HysteresisProtocolSchema>(
            SIMULATION_STAGE_HYSTERESIS_PROTOCOL_PATH,
            options,
            { path: { stage_id: stageId } },
          ),
        saturation: (stageId: string, options?: RequestOptions) =>
          this.requestJson<HysteresisStageSaturationSchema>(
            SIMULATION_STAGE_HYSTERESIS_SATURATION_PATH,
            options,
            { path: { stage_id: stageId } },
          ),
        orientation: (stageId: string, options?: RequestOptions) =>
          this.requestJson<HysteresisOrientationSchema>(
            SIMULATION_STAGE_HYSTERESIS_ORIENTATION_PATH,
            options,
            { path: { stage_id: stageId } },
          ),
        settlePipeline: (stageId: string, options?: RequestOptions) =>
          this.requestJson<HysteresisSettlePipelineSchema>(
            SIMULATION_STAGE_HYSTERESIS_SETTLE_PIPELINE_PATH,
            options,
            { path: { stage_id: stageId } },
          ),
        executionTree: (
          stageId: string,
          query?: HysteresisExecutionTreeQuery,
          options?: RequestOptions,
        ) =>
          this.requestJson<HysteresisExecutionTreeResource>(
            SIMULATION_STAGE_HYSTERESIS_EXECUTION_TREE_PATH,
            options,
            { path: { stage_id: stageId }, query },
          ),
        progress: (stageId: string, options?: RequestOptions) =>
          this.requestJson<HysteresisProgressSchema>(
            SIMULATION_STAGE_HYSTERESIS_PROGRESS_PATH,
            options,
            { path: { stage_id: stageId } },
          ),
      },
    },
    solver: {
      energies: {
        current: (options?: RequestOptions) =>
          this.requestJson<SolverEnergyCurrentResource>(
            SIMULATION_SOLVER_ENERGIES_CURRENT_PATH,
            options,
          ),
        history: (limit?: number, options?: RequestOptions) =>
          this.requestJson<SolverEnergyHistoryResource>(
            SIMULATION_SOLVER_ENERGIES_HISTORY_PATH,
            options,
            limit === undefined ? undefined : { query: { limit } },
          ),
      },
      status: (options?: RequestOptions) =>
        this.requestJson<SolverStatusResource>(
          SIMULATION_SOLVER_STATUS_PATH,
          options,
        ),
    },
  };

  readonly visualization = {
    display: (options?: RequestOptions) =>
      this.requestJson<DisplaySelection>(VISUALIZATION_DISPLAY_PATH, options),
    replaceDisplay: (display: DisplaySelection, options?: RequestOptions) =>
      this.putJson<DisplaySelection, DisplaySelection>(
        VISUALIZATION_DISPLAY_PATH,
        display,
        options,
      ),
    ack: (ack: VisualizationClientAckRequest, options?: RequestOptions) =>
      this.postJson<VisualizationClientAckEntry, VisualizationClientAckRequest>(
        VISUALIZATION_CLIENT_ACKS_PATH,
        ack,
        options,
      ),
    acks: (options?: RequestOptions) =>
      this.requestJson<VisualizationClientAckResource>(
        VISUALIZATION_CLIENT_ACKS_PATH,
        options,
      ),
    modeComposition: {
      active: (options?: RequestOptions) =>
        this.requestJson<ModeCompositionResource>(
          VISUALIZATION_MODE_COMPOSITION_ACTIVE_PATH,
          options,
        ),
      patch: (patch: ModeCompositionPatch, options?: RequestOptions) =>
        this.patchJson<ModeCompositionResource, ModeCompositionPatch>(
          VISUALIZATION_MODE_COMPOSITION_ACTIVE_PATH,
          patch,
          options,
        ),
    },
    patch: (patch: VisualizationStatePatch, options?: RequestOptions) =>
      this.patchJson<VisualizationStateResource, VisualizationStatePatch>(
        VISUALIZATION_STATE_PATH,
        patch,
        options,
      ),
    patchWithResponseIdentity: (
      patch: VisualizationStatePatch,
      options?: RequestOptions,
    ) =>
      this.patchJsonWithResponseIdentity<
        VisualizationStateResource,
        VisualizationStatePatch
      >(VISUALIZATION_STATE_PATH, patch, options),
    state: (options?: RequestOptions) =>
      this.requestJson<VisualizationStateResource>(
        VISUALIZATION_STATE_PATH,
        options,
      ),
    replaceState: (
      replacement: VisualizationStateResource,
      options?: RequestOptions,
    ) =>
      this.putJson<VisualizationStateResource, VisualizationStateResource>(
        VISUALIZATION_STATE_PATH,
        replacement,
        options,
      ),
  };

  constructor({
    baseUrl,
    expectedApiInstance = resolveApiInstancePin(),
    binaryDecodeScheduler = createBinaryDecodeScheduler(),
    diagnostics,
    fetchImpl,
    maxGetRetries = 2,
    retryDelayMs = 100,
    requestIdFactory = createRequestId,
  }: ControlRoomApiOptions = {}) {
    this.baseUrl = resolveBaseUrl(baseUrl);
    if (expectedApiInstance !== null && !isApiInstanceId(expectedApiInstance)) {
      throw new ControlRoomApiError("Invalid API instance pin", 0, null, "API_INSTANCE_MISMATCH");
    }
    this.expectedApiInstance = expectedApiInstance;
    this.binaryDecodeScheduler = binaryDecodeScheduler;
    this.requestDiagnostics = diagnostics ?? null;
    this.fetchImpl = fetchImpl ?? resolveDefaultFetch();
    this.maxGetRetries = maxGetRetries;
    this.retryDelayMs = retryDelayMs;
    this.requestIdFactory = requestIdFactory;
    this.transport = createOpenApiV2Transport({
      baseUrl: this.baseUrl,
      fetch: (input: Request, init?: RequestInit) =>
        this.executeOpenApiFetch(input, init),
    });
  }

  getBaseUrl(): string {
    return this.baseUrl;
  }

  getExpectedApiInstance(): string | null {
    return this.expectedApiInstance;
  }

  private requireApiInstanceCurrent(): void {
    if (this.apiInstanceMismatch) {
      throw new ControlRoomApiError("API instance changed; reopen Fullmag", 409, null, "API_INSTANCE_MISMATCH");
    }
  }

  private async requestJson<T>(
    path: OpenApiV2Path,
    options: RequestOptions = {},
    params?: Record<string, unknown>,
  ): Promise<T> {
    const result = await this.transport.GET(path as never, {
      cache: "no-store",
      headers: sessionScopeHeaders(options),
      params,
      signal: options.signal,
    } as never);
    this.requireApiInstanceCurrent();
    return readOpenApiResult<T>(result);
  }

  private async requestOptionalJson<T>(
    path: OpenApiV2Path,
    options: RequestOptions = {},
    params?: Record<string, unknown>,
  ): Promise<T | null> {
    const result = await this.transport.GET(path as never, {
      cache: "no-store",
      headers: sessionScopeHeaders(options),
      params,
      signal: options.signal,
    } as never);
    this.requireApiInstanceCurrent();

    if (result.response?.status === 204 || result.response?.status === 304) {
      return null;
    }

    return readOpenApiResult<T>(result);
  }

  private async requestPendingJson<T>(
    path: OpenApiV2Path,
    options: RequestOptions = {},
    params?: Record<string, unknown>,
  ): Promise<PendingJsonResourceResult<T>> {
    const result = await this.transport.GET(path as never, {
      cache: "no-store",
      headers: sessionScopeHeaders(options),
      params,
      signal: options.signal,
    } as never);
    this.requireApiInstanceCurrent();

    if (result.response?.status === 204) {
      return { data: null, status: "pending" };
    }

    return { data: readOpenApiResult<T>(result), status: "ready" };
  }

  private async requestFieldMeta(
    quantityId: string,
    path: OpenApiV2Path,
    params: Record<string, unknown>,
    options: RequestOptions = {},
  ): Promise<FieldMetaResource> {
    try {
      return await this.requestJson<FieldMetaResource>(path, options, params);
    } catch (error) {
      if (!shouldMaterializeFieldAfterJsonError(error)) {
        throw error;
      }
      if (await this.meshIsStale(options)) {
        throw error;
      }
      await this.materializeFieldsForQuantity(quantityId, options);
      return this.retryFieldMetaUntilReady(quantityId, path, params, options);
    }
  }

  private async postJson<TResponse, TBody>(
    path: OpenApiV2Path,
    body: TBody,
    options: RequestOptions = {},
    params?: Record<string, unknown>,
    additionalHeaders?: Record<string, string>,
  ): Promise<TResponse> {
    const result = await this.transport.POST(path as never, {
      body,
      cache: "no-store",
      headers: { ...sessionScopeHeaders(options), ...additionalHeaders },
      params,
      signal: options.signal,
    } as never);
    this.requireApiInstanceCurrent();
    return readOpenApiResult<TResponse>(result);
  }

  private async patchJson<TResponse, TBody>(
    path: OpenApiV2Path,
    body: TBody,
    options: RequestOptions = {},
    params?: Record<string, unknown>,
  ): Promise<TResponse> {
    const result = await this.transport.PATCH(path as never, {
      body,
      cache: "no-store",
      headers: sessionScopeHeaders(options),
      params,
      signal: options.signal,
    } as never);
    this.requireApiInstanceCurrent();
    return readOpenApiResult<TResponse>(result);
  }

  private async patchJsonWithResponseIdentity<TResponse, TBody>(
    path: OpenApiV2Path,
    body: TBody,
    options: RequestOptions = {},
    params?: Record<string, unknown>,
  ): Promise<JsonResponseIdentity<TResponse>> {
    const result = await this.transport.PATCH(path as never, {
      body,
      cache: "no-store",
      headers: sessionScopeHeaders(options),
      params,
      signal: options.signal,
    } as never);
    this.requireApiInstanceCurrent();
    return {
      data: readOpenApiResult<TResponse>(result),
      requestId: result.response.headers.get("x-request-id"),
    };
  }

  private async putJson<TResponse, TBody>(
    path: OpenApiV2Path,
    body: TBody,
    options: RequestOptions = {},
    params?: Record<string, unknown>,
    additionalHeaders: Readonly<Record<string, string>> = {},
  ): Promise<TResponse> {
    const result = await this.transport.PUT(path as never, {
      body,
      cache: "no-store",
      headers: { ...sessionScopeHeaders(options), ...additionalHeaders },
      params,
      signal: options.signal,
    } as never);
    this.requireApiInstanceCurrent();
    return readOpenApiResult<TResponse>(result);
  }

  private async deleteJson<TResponse>(
    path: OpenApiV2Path,
    options: RequestOptions = {},
    params?: Record<string, unknown>,
  ): Promise<TResponse> {
    const result = await this.transport.DELETE(path as never, {
      cache: "no-store",
      headers: sessionScopeHeaders(options),
      params,
      signal: options.signal,
    } as never);
    this.requireApiInstanceCurrent();
    return readOpenApiResult<TResponse>(result);
  }

  private async deleteJsonWithBody<TResponse, TBody>(
    path: OpenApiV2Path,
    body: TBody,
    options: RequestOptions = {},
    params?: Record<string, unknown>,
  ): Promise<TResponse> {
    const result = await this.transport.DELETE(path as never, {
      body,
      cache: "no-store",
      headers: sessionScopeHeaders(options),
      params,
      signal: options.signal,
    } as never);
    this.requireApiInstanceCurrent();
    return readOpenApiResult<TResponse>(result);
  }

  private requestTopology(
    path: OpenApiV2Path,
    options: BinaryRequestOptions = {},
    pathParams?: PathParams,
    query?: QueryParams,
  ): Promise<BinaryResourceResult<DecodedTopology>> {
    return this.requestBinaryResource(
      path,
      "topology",
      decodeTopology,
      options,
      pathParams,
      query,
      query?.carrier_id ? (response) => {
        const carrierId = response.headers.get("x-fullmag-carrier-id");
        const carrierRevision = response.headers.get("x-fullmag-carrier-revision");
        const carrierDigest = response.headers.get("x-fullmag-carrier-digest");
        if (carrierId !== query.carrier_id || carrierRevision !== query.expected_carrier_revision
          || !carrierRevision || !/^[1-9][0-9]*$/.test(carrierRevision) || BigInt(carrierRevision) > BigInt("18446744073709551615")
          || !carrierDigest || !/^[0-9a-f]{64}$/.test(carrierDigest)
          || response.headers.get("x-fullmag-mesh-topology-hash")?.replace(/^sha256:/, "") !== carrierDigest
          || response.headers.get("x-fullmag-coordinate-frame") !== "world"
          || response.headers.get("x-fullmag-coordinate-unit") !== "m") {
          throw new ControlRoomApiError("Artifact topology owner headers differ", 409);
        }
        return { carrierId, carrierRevision, carrierDigest, coordinateFrame: "world", coordinateUnit: "m" };
      } : undefined,
    );
  }

  private async requestTopologyChunked(
    path: OpenApiV2Path,
    options: BinaryRequestOptions = {},
    pathParams?: PathParams,
  ): Promise<BinaryResourceResult<DecodedTopology>> {
    const headerResult = await this.requestBinaryBytes(
      path,
      {
        ...options,
        range: `bytes=0-${FMMT_HEADER_LEN - 1}`,
      },
      pathParams,
    );
    if (headerResult.status !== "ready") {
      return headerResult;
    }

    const headerContentRange = requireExactContentRange(
      headerResult.contentRange,
      0,
      FMMT_HEADER_LEN - 1,
    );
    if (headerResult.byteLength !== headerContentRange.end + 1) {
      throw new ControlRoomApiError(
        `Expected topology header byte range 0-${headerContentRange.end} to contain ${headerContentRange.end + 1} bytes, got ${headerResult.byteLength}`,
        0,
      );
    }
    if (!isStrongEtag(headerResult.etag)) {
      throw new ControlRoomApiError(
        "Chunked FMMT topology requires a strong ETag",
        0,
      );
    }
    const header = decodeTopologyHeader(headerResult.data);
    const expectedByteLength = expectedTopologyByteLength(header);
    if (expectedByteLength > MAX_TOPOLOGY_BYTES) {
      throw new ControlRoomApiError(
        `FMMT topology exceeds ${MAX_TOPOLOGY_BYTES} byte limit: ${expectedByteLength}`,
        0,
      );
    }
    if (headerContentRange.total !== expectedByteLength) {
      throw new ControlRoomApiError(
        `FMMT content length mismatch: expected ${expectedByteLength}, got ${headerContentRange.total}`,
        0,
      );
    }
    if (expectedByteLength <= CHUNKED_TOPOLOGY_THRESHOLD_BYTES) {
      return this.requestBinaryResource(
        path,
        "topology",
        decodeTopology,
        options,
        pathParams,
      );
    }

    const data = await this.loadTopologySectionsByRange(
      path,
      header,
      headerResult.etag,
      expectedByteLength,
      options,
      pathParams,
    );
    this.requireApiInstanceCurrent();
    return {
      byteLength: expectedByteLength,
      data,
      etag: headerResult.etag,
      status: "ready",
    };
  }

  private async loadTopologySectionsByRange(
    path: OpenApiV2Path,
    header: TopologyHeader,
    expectedEtag: string | null,
    expectedTotal: number,
    options: BinaryRequestOptions,
    pathParams?: PathParams,
  ): Promise<DecodedTopology> {
    const layout = topologyByteLayout(header);
    const sections: TopologySections = {
      cellGlobalOrdinals: new BigUint64Array(header.cellGlobalOrdinalCount),
      cellMarkers: new Uint32Array(header.cellMarkerCount),
      cellNodes: new Uint32Array(header.cellConnectivityCount),
      cellOffsets:
        header.version === 1
          ? sequentialTopologyOffsets(header.cellCount, 4)
          : new Uint32Array(header.cellCount + 1),
      cellTypes: new Uint32Array(header.cellCount).fill(1),
      facetGlobalOrdinals: new BigUint64Array(header.facetGlobalOrdinalCount),
      facetMarkers: new Uint32Array(header.facetMarkerCount),
      facetNodes: new Uint32Array(header.facetConnectivityCount),
      facetOffsets:
        header.version === 1
          ? sequentialTopologyOffsets(header.facetCount, 3)
          : new Uint32Array(header.facetCount + 1),
      facetRoles: new Uint32Array(header.facetCount).fill(1),
      facetTypes: new Uint32Array(header.facetCount).fill(1),
      positions: new Float64Array(header.nodeCount * 3),
    };

    for (const [range, target] of [
      [layout.positions, sections.positions],
      [layout.cellNodes, sections.cellNodes],
      [layout.facetNodes, sections.facetNodes],
      [layout.cellMarkers, sections.cellMarkers],
      [layout.facetMarkers, sections.facetMarkers],
      [layout.cellGlobalOrdinals, sections.cellGlobalOrdinals],
      [layout.facetGlobalOrdinals, sections.facetGlobalOrdinals],
      [layout.cellTypes, sections.cellTypes],
      [layout.cellOffsets, sections.cellOffsets],
      [layout.facetTypes, sections.facetTypes],
      [layout.facetRoles, sections.facetRoles],
      [layout.facetOffsets, sections.facetOffsets],
    ] as const) {
      if (range) {
        await this.loadTopologySectionByRange(
          path,
          options,
          pathParams,
          range,
          new Uint8Array(target.buffer),
          expectedEtag,
          expectedTotal,
        );
      }
    }

    return decodeTopologySections(header, sections);
  }

  private async loadTopologySectionByRange(
    path: OpenApiV2Path,
    options: BinaryRequestOptions,
    pathParams: PathParams | undefined,
    range: { end: number; start: number },
    target: Uint8Array,
    expectedEtag: string | null,
    expectedTotal: number,
  ): Promise<void> {
    if (target.byteLength === 0 || range.end < range.start) return;

    let written = 0;
    for (
      let start = range.start;
      start <= range.end;
      start += TOPOLOGY_RANGE_CHUNK_BYTES
    ) {
      const end = Math.min(start + TOPOLOGY_RANGE_CHUNK_BYTES - 1, range.end);
      const result = await this.requestBinaryBytes(
        path,
        {
          ...options,
          etag: null,
          range: `bytes=${start}-${end}`,
        },
        pathParams,
      );
      if (result.status !== "ready") {
        throw new ControlRoomApiError(
          `Expected topology byte range ${start}-${end}, got ${result.status}`,
          0,
        );
      }

      if (expectedEtag !== null && result.etag !== expectedEtag) {
        throw new ControlRoomApiError(
          `FMMT topology ETag mismatch for byte range ${start}-${end}: expected ${expectedEtag}, got ${result.etag ?? "missing"}`,
          0,
        );
      }
      requireExactContentRange(result.contentRange, start, end, expectedTotal);

      const bytes = new Uint8Array(result.data);
      const expectedChunkLength = end - start + 1;
      if (bytes.byteLength !== expectedChunkLength) {
        throw new ControlRoomApiError(
          `Expected topology byte range ${start}-${end} to contain ${expectedChunkLength} bytes, got ${bytes.byteLength}`,
          0,
        );
      }
      target.set(bytes, written);
      written += bytes.byteLength;
    }
  }

  private requestBinaryBytes(
    path: OpenApiV2Path,
    options: BinaryRequestOptions = {},
    pathParams?: PathParams,
    query?: QueryParams,
  ): Promise<BinaryResourceResult<ArrayBuffer>> {
    return this.requestBinaryResource(
      path,
      "raw-bytes",
      (buffer) => buffer,
      options,
      pathParams,
      query,
    );
  }

  private requestMeshQualityData(
    path: OpenApiV2Path,
    options: BinaryRequestOptions = {},
  ): Promise<BinaryResourceResult<DecodedMeshQualityData>> {
    return this.requestBinaryResource(
      path,
      "mesh-quality-data",
      decodeMeshQualityData,
      options,
    );
  }

  private requestTableRowsBinary(
    path: OpenApiV2Path,
    pathParams: PathParams,
    query: TableRowsQuery = {},
    options: BinaryRequestOptions = {},
  ): Promise<BinaryResourceResult<DecodedTableRows>> {
    return this.requestBinaryResource(
      path,
      "table-rows",
      decodeTableRows,
      options,
      pathParams,
      tableRowsQueryParams(query),
    );
  }

  private requestCrossSection(
    path: OpenApiV2Path,
    query: CrossSectionQuery,
    options: BinaryRequestOptions = {},
  ): Promise<BinaryResourceResult<DecodedCrossSection>> {
    return this.requestBinaryResource(
      path,
      "cross-section",
      decodeCrossSection,
      options,
      undefined,
      {
        include_polygons: query.includePolygons,
        include_wireframe: query.includeWireframe,
        plane: query.plane,
        position_percent: query.positionPercent,
      },
    );
  }

  private requestCrossSectionImage(
    path: OpenApiV2Path,
    query: CrossSectionImageQuery,
    options: BinaryRequestOptions = {},
  ): Promise<BinaryResourceResult<ArrayBuffer>> {
    return this.requestBinaryBytes(path, options, undefined, {
      color_scale: query.colorScale,
      dpr: query.dpr,
      edge_width: query.edgeWidth,
      filter_expression: query.filterExpression,
      legend: query.legend,
      metric: query.metric,
      plane: query.plane,
      position_percent: query.positionPercent,
      resolution: query.resolution,
      rotation_degrees: query.rotationDegrees,
      shrink_factor: query.shrinkFactor,
      wireframe: query.wireframe,
    });
  }

  private requestCrossSectionQuality(
    path: OpenApiV2Path,
    query: CrossSectionQualityQuery,
    options: BinaryRequestOptions = {},
  ): Promise<BinaryResourceResult<DecodedCrossSectionQuality>> {
    return this.requestBinaryResource(
      path,
      "cross-section-quality",
      decodeCrossSectionQuality,
      options,
      undefined,
      {
        metric: query.metric,
        plane: query.plane,
        position_percent: query.positionPercent,
      },
    );
  }

  private requestFieldVector(
    path: OpenApiV2Path,
    pathParams: PathParams,
    query: QueryParams,
    options: BinaryRequestOptions = {},
  ): Promise<BinaryResourceResult<DecodedFieldVector, FieldVectorResponseMetadata>> {
    return this.requestBinaryResource(
      path,
      "field-vector",
      decodeFieldVector,
      options,
      pathParams,
      query,
      (response, data) => {
        const metadata = parseFieldVectorResponseMetadata(response.headers);
        const expectedArtifactGenerationId = query[
          "expected_artifact_generation_id"
        ];
        if (
          typeof expectedArtifactGenerationId === "string" &&
          expectedArtifactGenerationId.trim().length > 0 &&
          metadata.artifactGenerationId !== expectedArtifactGenerationId
        ) {
          throw new ControlRoomApiError(
            "Field vector artifact generation did not match the requested generation.",
            409,
          );
        }
        const identityIssues = collectFieldVectorIdentityIssues(data, metadata);
        const artifactIdentityError = artifactFieldResponseIdentityError(String(pathParams.quantity_id), query, data, { ...metadata, identityIssues });
        if (artifactIdentityError) throw new ControlRoomApiError(artifactIdentityError, 409);
        return { ...metadata, identityIssues };
      },
    );
  }

  private async requestFieldVectorOnDemand(
    quantityId: string,
    path: OpenApiV2Path,
    pathParams: PathParams,
    query: QueryParams,
    metaQuery: QueryParams,
    options: BinaryRequestOptions = {},
  ): Promise<BinaryResourceResult<DecodedFieldVector, FieldVectorResponseMetadata>> {
    const result = await this.requestFieldVector(path, pathParams, query, options);
    if (result.status === "pending") {
      return this.retryFieldVectorUntilReady(
        path,
        pathParams,
        query,
        options,
        result,
      );
    }
    if (result.status !== "not-applicable") {
      return result;
    }
    if (await this.livePublisherOwnsFieldMaterialization(quantityId, metaQuery, options)) {
      return result;
    }
    if (await this.meshIsStale(options)) {
      return result;
    }
    await this.materializeFieldsForQuantity(quantityId, options);
    return this.retryFieldVectorUntilReady(
      path,
      pathParams,
      query,
      options,
      result,
    );
  }

  private async livePublisherOwnsFieldMaterialization(
    quantityId: string,
    query: QueryParams,
    options: RequestOptions,
  ): Promise<boolean> {
    try {
      const meta = await this.requestJson<FieldMetaResource>(
        DATA_FIELD_META_PATH,
        options,
        {
          path: { quantity_id: quantityId },
          query,
        },
      );
      return ["complete", "pending", "stale_complete", "error"].includes(
        meta.state,
      );
    } catch (error) {
      if (shouldMaterializeFieldAfterJsonError(error)) {
        const solver = await this.requestOptionalJson<SolverStatusResource>(
          SIMULATION_SOLVER_STATUS_PATH,
          options,
        );
        return solver?.is_busy === true || solver?.runtime_state === "running";
      }
      throw error;
    }
  }

  private async materializeFieldsForQuantity(
    quantityId: string,
    options: RequestOptions = {},
  ): Promise<void> {
    if (quantityId.startsWith("analysis:")) {
      return;
    }
    throwIfAborted(options.signal);
    const key = options.sessionScopeKey ?? FIELD_MATERIALIZATION_REQUEST_KEY;
    const existing = this.fieldMaterializationRequests.get(key);
    if (existing) {
      return existing;
    }
    const requestedQuantityId = resolveCanonicalQuantityId(quantityId);
    const request = this.commands
      .submit(
        {
          client_intent_id: `field-on-demand:${requestedQuantityId}:${Date.now()}`,
          kind: "compute_fields",
          reason: "field_on_demand",
          requested_at_unix_ms: Date.now(),
          target: { kind: "study" },
        },
        options,
      )
      .then(() => undefined)
      .finally(() => {
        this.fieldMaterializationRequests.delete(key);
      });
    this.fieldMaterializationRequests.set(key, request);
    return request;
  }

  private async meshIsStale(options: RequestOptions = {}): Promise<boolean> {
    throwIfAborted(options.signal);
    const key = options.sessionScopeKey ?? FIELD_MATERIALIZATION_REQUEST_KEY;
    const existing = this.meshFreshnessRequests.get(key);
    if (existing) {
      const stale = await existing;
      throwIfAborted(options.signal);
      return stale;
    }

    const request = (async () => {
      try {
        // Do not bind the shared request to one component's abort signal.
        return (await this.model.geometry.validation({
          sessionScopeKey: options.sessionScopeKey,
        })).dirty;
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          throw error;
        }
        // Field materialization is unsafe without authoritative freshness.
        return true;
      }
    })();
    this.meshFreshnessRequests.set(key, request);
    void request
      .finally(() => {
        if (this.meshFreshnessRequests.get(key) === request) {
          this.meshFreshnessRequests.delete(key);
        }
      })
      .catch(() => undefined);
    const stale = await request;
    throwIfAborted(options.signal);
    return stale;
  }

  private async retryFieldMetaUntilReady(
    quantityId: string,
    path: OpenApiV2Path,
    params: Record<string, unknown>,
    options: RequestOptions,
  ): Promise<FieldMetaResource> {
    const deadline = Date.now() + FIELD_MATERIALIZATION_TIMEOUT_MS;
    let lastError: unknown = null;
    while (Date.now() <= deadline) {
      throwIfAborted(options.signal);
      await delay(FIELD_MATERIALIZATION_RETRY_MS, options.signal);
      try {
        return await this.requestJson<FieldMetaResource>(path, options, params);
      } catch (error) {
        if (!shouldMaterializeFieldAfterJsonError(error)) {
          throw error;
        }
        lastError = error;
      }
    }
    throw lastError ?? new ControlRoomApiError(
      `Timed out waiting for field metadata materialization for quantity '${quantityId}'`,
      0,
    );
  }

  private async retryFieldVectorUntilReady(
    path: OpenApiV2Path,
    pathParams: PathParams,
    query: QueryParams,
    options: BinaryRequestOptions,
    initialResult: BinaryResourceResult<DecodedFieldVector, FieldVectorResponseMetadata>,
  ): Promise<BinaryResourceResult<DecodedFieldVector, FieldVectorResponseMetadata>> {
    const deadline = Date.now() + FIELD_MATERIALIZATION_TIMEOUT_MS;
    let lastResult = initialResult;
    while (Date.now() < deadline) {
      throwIfAborted(options.signal);
      const retryDelay =
        lastResult.status === "pending"
          ? lastResult.retry_after_ms
          : FIELD_MATERIALIZATION_RETRY_MS;
      await delay(
        Math.min(Math.max(1, retryDelay), deadline - Date.now()),
        options.signal,
      );
      if (Date.now() >= deadline) {
        return lastResult;
      }
      const result = await this.requestFieldVector(path, pathParams, query, options);
      if (result.status === "ready" || result.status === "not-modified") {
        return result;
      }
      lastResult = result;
    }
    return lastResult;
  }

  private async requestBinaryResource<TData, TMetadata = undefined>(
    path: OpenApiV2Path,
    decoderKind: BinaryDecoderKind,
    decode: (buffer: ArrayBuffer) => TData,
    options: BinaryRequestOptions = {},
    pathParams?: PathParams,
    query?: QueryParams,
    responseMetadata?: (response: Response, data: TData) => TMetadata,
  ): Promise<BinaryResourceResult<TData, TMetadata>> {
    const measureBase = `fullmag.api.requestBinaryResource.${decoderKind}`;
    return measureControlRoomApiPerformance(
      measureBase,
      async () => {
        const headers: Record<string, string> = sessionScopeHeaders(options);
        if (options.etag) {
          headers["if-none-match"] = options.etag;
        }
        if (options.range) {
          headers.range = options.range;
        }

        const requestState: {
          lastRequestPath: string;
          lastResponse: Response | null;
        } = {
          lastRequestPath: path as string,
          lastResponse: null,
        };
        let result: BinaryOpenApiTransportResult | null = null;
        try {
          result = await measureControlRoomApiPerformance(
            `${measureBase}.transport`,
            async () =>
              this.transport.GET(path as never, {
                cache: "no-store",
                fetch: async (input: RequestInfo | URL, init?: RequestInit) => {
                  requestState.lastRequestPath = pathFromUrl(
                    typeof input === "string"
                      ? input
                      : input instanceof Request
                        ? input.url
                        : String(input),
                  );
                  const resp = await this.executeBinaryOpenApiFetch(input, init);
                  requestState.lastResponse = resp;
                  return boundedBinaryResponse(resp, options.maxResponseBytes);
                },
                headers,
                params: { path: pathParams, query },
                parseAs: "arrayBuffer",
                signal: options.signal,
              } as never) as unknown as BinaryOpenApiTransportResult,
          );
        } catch (error) {
          this.requireApiInstanceCurrent();
          const lastResponse = requestState.lastResponse;
          if (lastResponse && !lastResponse.ok) {
            throw new ControlRoomApiError(
              `Request failed with status ${lastResponse.status}`,
              lastResponse.status,
            );
          }
          throw error;
        }
        this.requireApiInstanceCurrent();
        if (!result) {
          throw new ControlRoomApiError("Binary resource request did not return a response", 0);
        }
        const response = result.response;
        const etag = response.headers.get("etag");

        if (response.status === 304) {
          return { etag, status: "not-modified" };
        }

        if (response.status === 204) {
          return { etag, status: "not-applicable" };
        }

        if (response.status === 202 && decoderKind === "field-vector") {
          const pending = parseFieldVectorPendingResponse(result.data);
          return {
            ...pending,
            etag,
            status: "pending",
          } as unknown as BinaryResourceResult<TData, TMetadata>;
        }

        if (!response.ok || result.error) {
          const apiError = parseOpenApiError(result.error, response.status);
          throw new ControlRoomApiError(
            apiError.message === "Request failed"
              ? await formatResponseError(response)
              : apiError.message,
            response.status,
            response.headers.get("x-request-id"),
            apiError.code,
          );
        }

        const buffer = result.data as unknown;
        if (!(buffer instanceof ArrayBuffer)) {
          throw new ControlRoomApiError("Expected binary response body", 0);
        }
        const byteLength = buffer.byteLength;

        const decodeStartedAt = nowMs();
        let data: TData;
        try {
          data = await measureControlRoomApiPerformance(
            `${measureBase}.decode`,
            async () =>
              decoderKind === "raw-bytes"
                ? decode(buffer)
                : await this.binaryDecodeScheduler({
                    buffer,
                    decodeInline: decode,
                    kind: decoderKind,
                    path: requestState.lastRequestPath,
                    signal: options.signal,
                  }),
          );
          this.requireApiInstanceCurrent();
        } catch (error) {
          this.requestDiagnostics?.record({
            byteLength,
            channel: "http",
            contentType: response.headers.get("content-type"),
            detail: "binary decode failed",
            direction: "rx",
            durationMs: Math.max(0, nowMs() - decodeStartedAt),
            etag,
            method: "GET",
            outcome: "error",
            path: requestState.lastRequestPath,
            requestId:
              response.headers.get("x-request-id") ?? "binary-payload",
            resourceKey: requestState.lastRequestPath,
            status: response.status,
          });
          throw error;
        }
        const decodeDurationMs = Math.max(0, nowMs() - decodeStartedAt);
        if (decoderKind === "field-vector") {
          recordVisualizationDebugPerformanceMetric("fieldDecodes");
        }

        this.requestDiagnostics?.record({
          byteLength,
          channel: "http",
          contentType: response.headers.get("content-type"),
          detail: "decoded binary payload",
          direction: "rx",
          durationMs: decodeDurationMs,
          etag,
          method: "GET",
          outcome: "ok",
          path: requestState.lastRequestPath,
          requestId: response.headers.get("x-request-id") ?? "binary-payload",
          resourceKey: requestState.lastRequestPath,
          status: response.status,
        });

        return {
          byteLength,
          contentRange: response.headers.get("content-range"),
          data,
          etag,
          ...(responseMetadata
            ? { responseMetadata: responseMetadata(response, data) }
            : {}),
          status: "ready",
        } as BinaryResourceResult<TData, TMetadata>;
      },
    );
  }

  private async executeBinaryOpenApiFetch(
    input: RequestInfo | URL,
    init: RequestInit | undefined,
  ): Promise<Response> {
    const request = await normalizeFetchInput(input, init);
    return this.executeFetchRequest(
      request.url,
      request.method,
      request.init,
      new Set([204, 304]),
      true,
    );
  }

  private async executeOpenApiFetch(
    input: RequestInfo | URL,
    init: RequestInit | undefined,
  ): Promise<Response> {
    const request = await normalizeFetchInput(input, init);
    return this.executeFetchRequest(
      request.url,
      request.method,
      request.init,
      new Set(),
      false,
    );
  }

  private async executeFetchRequest(
    url: string,
    method: string,
    init: RequestInit,
    acceptedStatuses: Set<number>,
    allowMissingContractVersion: boolean,
  ): Promise<Response> {
    if (this.apiInstanceMismatch) {
      throw new ControlRoomApiError("API instance changed; reopen Fullmag", 409, null, "API_INSTANCE_MISMATCH");
    }
    const headers = new Headers(init.headers);
    if (this.expectedApiInstance) {
      headers.set(API_INSTANCE_HEADER, this.expectedApiInstance);
    }
    const requestId = this.requestIdFactory();
    headers.set("x-request-id", requestId);

    const started = Date.now();
    const path = pathFromUrl(url);
    const maxAttempts = method === "GET" ? this.maxGetRetries + 1 : 1;
    let lastError: unknown = null;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        if (this.apiInstanceMismatch) {
          throw new ControlRoomApiError("API instance changed; reopen Fullmag", 409, null, "API_INSTANCE_MISMATCH");
        }
        this.requestDiagnostics?.record({
          byteLength: byteLengthFromBody(init.body),
          channel: "http",
          contentType: headers.get("content-type"),
          detail: `attempt ${attempt}`,
          direction: "tx",
          durationMs: null,
          etag: null,
          method,
          outcome: "sent",
          path,
          requestId,
          resourceKey: path,
          status: null,
        });

        const fetchImpl = this.fetchImpl;
        const response = await fetchImpl(url, {
          ...init,
          cache: init.cache ?? "no-store",
          headers,
          method,
        });

        const transportUnavailable = isTransportUnavailableResponse(
          response,
          this.expectedApiInstance,
        );
        if (!transportUnavailable && (this.apiInstanceMismatch || (this.expectedApiInstance && response.headers.get(API_INSTANCE_HEADER) !== this.expectedApiInstance))) {
          this.apiInstanceMismatch = true;
          throw new ControlRoomApiError("API instance changed; reopen Fullmag", 409, response.headers.get("x-request-id"), "API_INSTANCE_MISMATCH");
        }

        const contractVersionError = transportUnavailable
          ? null
          : resolveContractVersionError(response, {
              allowMissing: allowMissingContractVersion,
            });
        const accepted =
          (response.ok || acceptedStatuses.has(response.status)) &&
          !contractVersionError &&
          !transportUnavailable;
        const responseDetail = await resolveResponseDiagnosticDetail({
          attempt,
          method,
          path,
          response,
        });
        this.requireApiInstanceCurrent();
        this.requestDiagnostics?.record({
          byteLength: byteLengthFromHeaders(response.headers),
          channel: "http",
          contentType: response.headers.get("content-type"),
          detail: responseDetail,
          direction: "rx",
          durationMs: Date.now() - started,
          etag: response.headers.get("etag"),
          method,
          outcome: accepted ? "ok" : "error",
          path,
          requestId,
          resourceKey: path,
          status: response.status,
        });

        if (attempt < maxAttempts && retryableGetStatus(method, response.status)) {
          await delayRetry(this.retryDelayMs, init.signal);
          continue;
        }

        if (contractVersionError) {
          throw contractVersionError;
        }

        if (transportUnavailable) {
          throw new ControlRoomApiError(
            API_UNAVAILABLE_MESSAGE,
            response.status,
            response.headers.get("x-request-id") ?? requestId,
            API_UNAVAILABLE_CODE,
          );
        }

        return response;
      } catch (error) {
        if (error instanceof ControlRoomApiError) {
          throw error;
        }

        lastError = error;
        if (attempt < maxAttempts && !isAbortError(error)) {
          await delayRetry(this.retryDelayMs, init.signal);
          continue;
        }
        break;
      }
    }

    this.requestDiagnostics?.record({
      byteLength: null,
      channel: "http",
      contentType: null,
      detail: null,
      direction: "rx",
      durationMs: Date.now() - started,
      etag: null,
      method,
      outcome: isAbortError(lastError) ? "aborted" : "network-error",
      path,
      requestId,
      resourceKey: path,
      status: null,
    });

    if (isAbortError(lastError)) {
      throw lastError;
    }
    throw new ControlRoomApiError(
      API_UNAVAILABLE_MESSAGE,
      0,
      requestId,
      API_UNAVAILABLE_CODE,
    );
  }
}

const API_UNAVAILABLE_CODE = "API_UNAVAILABLE";
const API_UNAVAILABLE_MESSAGE = "Fullmag API unavailable";

function isTransportUnavailableResponse(
  response: Response,
  expectedApiInstance: string | null,
): boolean {
  return (
    !response.ok &&
    response.status >= 500 &&
    response.headers.get(API_CONTRACT_VERSION_HEADER) == null &&
    (expectedApiInstance == null ||
      response.headers.get(API_INSTANCE_HEADER) == null ||
      response.headers.get(API_INSTANCE_HEADER) === expectedApiInstance)
  );
}

function isAbortError(error: unknown): boolean {
  return (
    (error instanceof DOMException && error.name === "AbortError") ||
    (error instanceof Error && error.name === "AbortError")
  );
}

function retryableGetStatus(method: string, status: number): boolean {
  return (
    method === "GET" &&
    (status === 408 ||
      status === 429 ||
      status === 502 ||
      status === 503 ||
      status === 504)
  );
}

async function delayRetry(
  delayMs: number,
  signal: AbortSignal | null | undefined,
): Promise<void> {
  if (delayMs <= 0) return;
  await new Promise<void>((resolve, reject) => {
    const timer = globalThis.setTimeout(resolve, delayMs);
    signal?.addEventListener(
      "abort",
      () => {
        globalThis.clearTimeout(timer);
        reject(new DOMException("Aborted", "AbortError"));
      },
      { once: true },
    );
  });
}

function resolveBaseUrl(baseUrl: string | undefined): string {
  if (baseUrl !== undefined) {
    return baseUrl.replace(/\/$/, "");
  }

  if (typeof window !== "undefined") {
    return window.location.origin;
  }

  return "http://localhost";
}

function resolveDefaultFetch(): FetchLike {
  if (typeof globalThis.fetch !== "function") {
    throw new ControlRoomApiError("Fetch API is not available", 0);
  }

  return globalThis.fetch.bind(globalThis);
}

function createRequestId(): string {
  const cryptoApi = globalThis.crypto;
  if (typeof cryptoApi?.randomUUID === "function") {
    return cryptoApi.randomUUID();
  }

  const bytes = new Uint8Array(16);
  if (typeof cryptoApi?.getRandomValues === "function") {
    try {
      cryptoApi.getRandomValues(bytes);
    } catch {
      fillRequestIdBytesWithMathRandom(bytes);
    }
  } else {
    fillRequestIdBytesWithMathRandom(bytes);
  }

  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function fillRequestIdBytesWithMathRandom(bytes: Uint8Array): void {
  for (let index = 0; index < bytes.length; index += 1) {
    bytes[index] = Math.floor(Math.random() * 256);
  }
}

async function normalizeFetchInput(
  input: RequestInfo | URL,
  init: RequestInit | undefined,
): Promise<{ init: RequestInit; method: string; url: string }> {
  if (typeof Request !== "undefined" && input instanceof Request) {
    const method = init?.method ?? input.method;
    let body = init?.body;

    if (
      body === undefined &&
      method !== "GET" &&
      method !== "HEAD" &&
      input.body != null
    ) {
      body = await input.clone().arrayBuffer();
    }

    return {
      init: {
        ...init,
        body,
        cache: init?.cache ?? input.cache,
        headers: init?.headers ?? input.headers,
        signal: init?.signal ?? input.signal,
      },
      method,
      url: input.url,
    };
  }

  return {
    init: init ?? {},
    method: init?.method ?? "GET",
    url: String(input),
  };
}

function pathFromUrl(url: string): string {
  try {
    const parsed = new URL(url);
    return `${parsed.pathname}${parsed.search}`;
  } catch {
    return url;
  }
}

function requireExactContentRange(
  value: string | null | undefined,
  expectedStart: number,
  requestedEnd: number,
  expectedTotal?: number,
): { end: number; start: number; total: number } {
  const match = value ? /^bytes\s+(\d+)-(\d+)\/(\d+)$/i.exec(value.trim()) : null;
  if (!match) {
    throw new ControlRoomApiError("Expected an exact topology Content-Range header", 0);
  }
  const start = Number(match[1]);
  const end = Number(match[2]);
  const total = Number(match[3]);
  if (
    !Number.isSafeInteger(start) ||
    !Number.isSafeInteger(end) ||
    !Number.isSafeInteger(total) ||
    total <= 0 ||
    start !== expectedStart ||
    end !== Math.min(requestedEnd, total - 1) ||
    (expectedTotal !== undefined && total !== expectedTotal)
  ) {
    throw new ControlRoomApiError(
      `Unexpected topology Content-Range: expected bytes ${expectedStart}-${Math.min(requestedEnd, (expectedTotal ?? total) - 1)}/${expectedTotal ?? total}, got ${value}`,
      0,
    );
  }
  return { end, start, total };
}

function isStrongEtag(value: string | null | undefined): value is string {
  return Boolean(value && !value.startsWith("W/") && /^"[^"\r\n]*"$/.test(value));
}

function sequentialTopologyOffsets(count: number, arity: number): Uint32Array {
  const offsets = new Uint32Array(count + 1);
  for (let index = 0; index <= count; index += 1) {
    offsets[index] = index * arity;
  }
  return offsets;
}

function scalarWindowQueryParams(query: ScalarWindowQuery): QueryParams {
  return {
    columns:
      query.columns && query.columns.length > 0
        ? query.columns.join(",")
        : undefined,
    limit: query.limit,
    since_revision: query.sinceRevision,
    tail: query.tail,
  };
}

function fieldMetaQueryParams(query: FieldMetaQuery): QueryParams {
  return {
    carrier_id: query.carrier_id ?? undefined,
    expected_carrier_revision: query.expected_carrier_revision ?? undefined,
    view: query.view ?? undefined,
    component: query.component ?? undefined,
    owner_object_id: query.owner_object_id ?? undefined,
    scope_id: normalizeFieldMetaScopeId(
      query.scope_kind,
      query.scope_id,
    ) ?? undefined,
    scope_kind: query.scope_kind ?? undefined,
    snapshot_id: query.snapshot_id ?? undefined,
    stage_id: query.stage_id ?? undefined,
  };
}

function fieldAvailabilityQueryParams(query: FieldAvailabilityQuery): QueryParams {
  return {
    stage_id: query.stage_id ?? undefined,
    carrier_id: query.carrier_id ?? undefined,
    expected_carrier_revision: query.expected_carrier_revision ?? undefined,
    view: query.view ?? undefined,
    target_id: query.target_id ?? undefined,
    scope_kind: query.scope_kind ?? undefined,
    scope_id: query.scope_id ?? undefined,
    owner_object_id: query.owner_object_id ?? undefined,
  };
}

function fieldVectorQueryParams(query: FieldVectorQuery): QueryParams {
  return canonicalFieldVectorQueryParams(canonicalFieldVectorQuery("m", query));
}

function parseFieldVectorPendingResponse(
  data: unknown,
): FieldVectorPendingResponse {
  let value: unknown = data;
  if (value instanceof ArrayBuffer) {
    try {
      value = JSON.parse(new TextDecoder().decode(value));
    } catch {
      throw new ControlRoomApiError(
        "Invalid pending field-vector response body",
        202,
      );
    }
  }
  if (!value || typeof value !== "object") {
    throw new ControlRoomApiError("Invalid pending field-vector response body", 202);
  }
  const pending = value as Record<string, unknown>;
  if (
    pending.state !== "pending" ||
    typeof pending.reason_code !== "string" ||
    typeof pending.retry_after_ms !== "number" ||
    !Number.isFinite(pending.retry_after_ms) ||
    pending.retry_after_ms < 0 ||
    typeof pending.generation_id !== "string" ||
    typeof pending.quantity_id !== "string" ||
    typeof pending.scope_kind !== "string"
  ) {
    throw new ControlRoomApiError("Invalid pending field-vector response body", 202);
  }
  return pending as unknown as FieldVectorPendingResponse;
}

function topologicalChargeQueryParams(
  query: TopologicalChargeQuery,
): QueryParams {
  return {
    plane: query.plane,
    support: query.support,
    profile_samples:
      typeof query.profile_samples === "number"
        ? String(query.profile_samples)
        : query.profile_samples,
    snapshot_id: query.snapshot_id ?? undefined,
    stage_id: query.stage_id ?? undefined,
  };
}

function normalizeFieldMetaScopeId(
  scopeKind: FieldMetaQuery["scope_kind"],
  scopeId: FieldMetaQuery["scope_id"],
): string | null | undefined {
  if (
    scopeKind === "object" &&
    typeof scopeId === "string" &&
    scopeId.startsWith("object:")
  ) {
    return scopeId.slice("object:".length);
  }
  return scopeId;
}

function tableRowsQueryParams(query: TableRowsQuery): QueryParams {
  return {
    columns:
      query.columns && query.columns.length > 0
        ? query.columns.join(",")
        : undefined,
    cursor: query.cursor,
    decimation: query.decimation,
    from_row: query.fromRow,
    from_t: query.fromT,
    include_tail: query.includeTail,
    limit: query.limit,
    target_points: query.targetPoints,
    to_row: query.toRow,
    to_t: query.toT,
  };
}

function byteLengthFromHeaders(headers: Headers): number | null {
  const contentLength = headers.get("content-length");
  if (!contentLength) {
    return null;
  }

  const parsed = Number.parseInt(contentLength, 10);
  return Number.isFinite(parsed) ? parsed : null;
}

async function measureControlRoomApiPerformance<T>(
  name: string,
  task: () => Promise<T>,
): Promise<T> {
  const performanceTarget =
    typeof performance !== "undefined" ? performance : null;
  if (
    !performanceTarget ||
    typeof performanceTarget.mark !== "function" ||
    typeof performanceTarget.measure !== "function"
  ) {
    return task();
  }

  const startMark = `${name}:start`;
  const endMark = `${name}:end`;
  performanceTarget.mark(startMark);
  try {
    return await task();
  } finally {
    performanceTarget.mark(endMark);
    try {
      performanceTarget.measure(name, startMark, endMark);
    } catch {
      // Gracefully ignore measurement errors to prevent crashing the API
    }
    performanceTarget.clearMarks?.(startMark);
    performanceTarget.clearMarks?.(endMark);
  }
}

function nowMs(): number {
  return typeof performance !== "undefined" &&
    typeof performance.now === "function"
    ? performance.now()
    : Date.now();
}

function byteLengthFromBody(body: BodyInit | null | undefined): number | null {
  if (body == null) {
    return 0;
  }

  if (typeof body === "string") {
    return new TextEncoder().encode(body).byteLength;
  }

  if (body instanceof ArrayBuffer) {
    return body.byteLength;
  }

  if (ArrayBuffer.isView(body)) {
    return body.byteLength;
  }

  if (typeof URLSearchParams !== "undefined" && body instanceof URLSearchParams) {
    return new TextEncoder().encode(body.toString()).byteLength;
  }

  if (typeof Blob !== "undefined" && body instanceof Blob) {
    return body.size;
  }

  return null;
}

async function resolveResponseDiagnosticDetail({
  attempt,
  method,
  path,
  response,
}: {
  attempt: number;
  method: string;
  path: string;
  response: Response;
}): Promise<string> {
  const base = `attempt ${attempt}`;
  if (method !== "POST" || path !== SIMULATION_COMMANDS_PATH) {
    return base;
  }

  try {
    const payload = (await response.clone().json()) as Record<string, unknown>;
    const details = [base];
    const commandId = stringField(payload.command_id);
    if (commandId) {
      details.push(`command_id=${commandId}`);
    }
    if (typeof payload.accepted === "boolean") {
      details.push(`accepted=${payload.accepted}`);
    }
    const error = stringField(payload.error);
    if (error) {
      details.push(`error=${error}`);
    }
    return details.join("; ");
  } catch {
    return base;
  }
}

function stringField(value: unknown): string | null {
  return typeof value === "string" && value.length > 0 ? value : null;
}

function resolveContractVersionError(
  response: Response,
  options: { allowMissing?: boolean } = {},
): ControlRoomApiError | null {
  const actual = response.headers.get(API_CONTRACT_VERSION_HEADER);
  if (actual == null && options.allowMissing) {
    return null;
  }
  if (actual === EXPECTED_API_CONTRACT_VERSION) {
    return null;
  }

  return new ControlRoomApiError(
    `API contract version mismatch: expected ${EXPECTED_API_CONTRACT_VERSION}, got ${actual ?? "missing"}`,
    0,
  );
}

function readOpenApiResult<T>(result: {
  data?: unknown;
  error?: unknown;
  response?: Response;
}): T {
  const response = result.response;

  if (!response) {
    throw new ControlRoomApiError("OpenAPI transport returned no response", 0);
  }

  if (response.status === 304) {
    return undefined as T;
  }

  if (!response.ok) {
    const apiError = parseOpenApiError(result.error, response.status);
    throw new ControlRoomApiError(
      apiError.message,
      response.status,
      response.headers.get("x-request-id"),
      apiError.code,
    );
  }

  return result.data as T;
}

interface ParsedOpenApiError {
  code: string | null;
  message: string;
}

function parseOpenApiError(error: unknown, status?: number): ParsedOpenApiError {
  if (error == null) {
    return { code: null, message: "Request failed" };
  }

  if (error instanceof ArrayBuffer) {
    const text = new TextDecoder().decode(error);
    if (!text) {
      return { code: null, message: "Request failed" };
    }
    try {
      return parseOpenApiError(JSON.parse(text), status);
    } catch {
      return { code: null, message: formatPlainErrorBody(status ?? 0, text) };
    }
  }

  if (typeof error === "string") {
    return { code: null, message: formatPlainErrorBody(status ?? 0, error) };
  }

  if (typeof error === "object") {
    const record = error as Record<string, unknown>;
    const code = typeof record.code === "string" ? record.code : null;
    if (typeof record.message === "string") {
      return { code, message: record.message };
    }
    if (typeof record.error === "string") {
      return { code, message: record.error };
    }
    return { code, message: "Request failed" };
  }

  return { code: null, message: "Request failed" };
}

function formatOpenApiError(error: unknown): string {
  return parseOpenApiError(error).message;
}

async function formatResponseError(response: Response): Promise<string> {
  try {
    const text = await response.text();
    if (!text) {
      return `Request failed with status ${response.status}`;
    }

    try {
      return formatOpenApiError(JSON.parse(text));
    } catch {
      return formatPlainErrorBody(response.status, text);
    }
  } catch {
    return `Request failed with status ${response.status}`;
  }
}

const MAX_PLAIN_ERROR_CHARS = 240;

/**
 * Gateways and proxies may answer with HTML or long plain text. Present a
 * short, markup-free summary with the HTTP status instead of the raw body.
 */
function formatPlainErrorBody(status: number, text: string): string {
  const looksLikeMarkup = /<\s*(?:!doctype|html|head|body)\b/i.test(text);
  const titleMatch = looksLikeMarkup ? /<title[^>]*>([^<]*)<\/title>/i.exec(text) : null;
  const plain = (titleMatch?.[1] ?? (looksLikeMarkup ? "" : text))
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!plain) {
    return `Request failed with status ${status} (non-JSON response)`;
  }
  const bounded = plain.length > MAX_PLAIN_ERROR_CHARS
    ? `${plain.slice(0, MAX_PLAIN_ERROR_CHARS)}…`
    : plain;
  return looksLikeMarkup ? `Request failed with status ${status}: ${bounded}` : bounded;
}

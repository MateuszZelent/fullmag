"use client";

import { useSavedRunSelection } from "../saved-results/useSavedRun";

import { isProjectWorkspaceCommand } from "../commands/projectWorkspaceCommandPolicy";

import { ArrowLeft, House, Menu, Search } from "lucide-react";
import { useEffect, useMemo, useReducer, useSyncExternalStore } from "react";

import { useTheme } from "@/design/theme/ThemeProvider";
import {
  SIMULATION_SOLVER_STATUS_PATH,
  SESSION_STATUS_PATH,
} from "@/kernel/api/apiPaths";
import { createCommandContext } from "@/kernel/commands/commandContext";
import { useKernel } from "@/kernel/KernelContext";
import { useRuntimeCommandControlResourceData } from "@/kernel/resources/studyRuntimeResources";
import { readDetailedRuntimeState } from "@/kernel/runtime/runtimeStateDisplay";
import {
  useSessionResourceIdentity,
  useSessionStatusSelector,
} from "@/kernel/resources/useSessionStatus";
import { sessionRequestScopeKey } from "@/kernel/resources/sessionResourceIdentity";
import { useSessionCollection } from "@/kernel/resources/useSessionCollection";
import {
  EMPTY_OBJECT_VISUALIZATION_SNAPSHOT,
  useObjectVisualizationSelector,
} from "@/kernel/visualization/useObjectVisualization";
import { useVisualizationStateResource } from "@/kernel/visualization/useVisualizationStateResource";
import { FullmagMark } from "@/shared/brand/FullmagLogo";
import { Button } from "@/shared/ui/Button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/shared/ui/Dialog";
import { ThemeSwitcher } from "@/shared/ui/ThemeSwitcher";
import {
  ProjectDocumentStatus,
  useProjectDocumentSnapshot,
} from "../persistence/ProjectDocumentStatus";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/shared/ui/DropdownMenu";

import {
  MAIN_MENUS,
  QUICK_ACTIONS,
  RUN_CONTROLS,
  type AppMenuNode,
  type HeaderQuickAction,
} from "./appMenuModel";
import {
  type ApiConnectionErrorDetails,
  headerSessionSourceEquals,
  latestRequestForPath,
  resolveApiConnectionErrorDetails,
  resolveHeaderSessionDisplay,
  resolveHydrationSafeHeaderSessionSource,
  resolveNoSessionSubtitle,
  selectHeaderSessionSource,
} from "./AppMenuBarHeaderModel";
import { CommunicationPolicyDialog } from "./CommunicationPolicyDialog";
import { DataPreviewDialog } from "./DataPreviewDialog";
import { MaterialLibraryDialog } from "./MaterialLibraryDialog";
import { RegistryInspectorDialog } from "./RegistryInspectorDialog";
import { DiagnosticRecorderDialog } from "./diagnostic-recorder/DiagnosticRecorderDialog";
import { useHomeViewOpen } from "./homeView";
import { NewProblemDialog, useNewProblemRequest } from "./NewProblemDialog";
import { ReadinessHelperHeaderControl } from "./ReadinessHelperDialog";

function subscribeToHydration(): () => void {
  return () => {};
}

function clientHydratedSnapshot(): boolean {
  return true;
}

function serverHydratedSnapshot(): boolean {
  return false;
}

function noopRefetch(): void {}

type CommandDisabledReasonResolver = (commandId: string) => string | null;

function MenuDisabledReason({ reason }: { readonly reason: string | null }) {
  return reason ? <span className="fm-dropdown-reason">{reason}</span> : null;
}

function MenuNode({
  commandDisabledReason,
  isCommandActive,
  isCommandDisabled,
  node,
  onCommand,
}: {
  commandDisabledReason: CommandDisabledReasonResolver;
  isCommandActive: (commandId: string) => boolean;
  isCommandDisabled: (commandId: string) => boolean;
  node: AppMenuNode;
  onCommand: (commandId: string, input?: unknown) => void;
}) {
  const commandDisabled = isCommandDisabled(node.id);
  const disabled = node.disabled || commandDisabled;
  // The registry reason takes precedence over the static label.
  const reason = commandDisabled ? commandDisabledReason(node.id) : null;
  if (node.children?.length) {
    return (
      <DropdownMenuSub>
        <DropdownMenuSubTrigger disabled={disabled}>
          {node.icon}
          <span>{node.label}</span>
        </DropdownMenuSubTrigger>
        <DropdownMenuSubContent>
          {node.children.map((child) => (
            <MenuNode
              key={child.id}
              commandDisabledReason={commandDisabledReason}
              isCommandActive={isCommandActive}
              isCommandDisabled={isCommandDisabled}
              node={child}
              onCommand={onCommand}
            />
          ))}
        </DropdownMenuSubContent>
      </DropdownMenuSub>
    );
  }

  if (node.checkable) {
    return (
      <DropdownMenuCheckboxItem
        checked={isCommandActive(node.id)}
        disabled={disabled}
        onCheckedChange={(checked) => onCommand(node.id, Boolean(checked))}
      >
        {node.icon}
        <span>{node.label}</span>
        {node.shortcut ? (
          <span className="fm-dropdown-shortcut">{node.shortcut}</span>
        ) : null}
        <MenuDisabledReason reason={reason} />
      </DropdownMenuCheckboxItem>
    );
  }

  return (
    <DropdownMenuItem
      disabled={disabled}
      onSelect={() => onCommand(node.id)}
    >
      {node.icon}
      <span>{node.label}</span>
      {node.shortcut ? (
        <span className="fm-dropdown-shortcut">{node.shortcut}</span>
      ) : null}
      <MenuDisabledReason reason={reason} />
    </DropdownMenuItem>
  );
}

function HeaderDropdown({
  commandDisabledReason,
  isCommandActive,
  isCommandDisabled,
  menu,
  onCommand,
}: {
  commandDisabledReason: CommandDisabledReasonResolver;
  isCommandActive: (commandId: string) => boolean;
  isCommandDisabled: (commandId: string) => boolean;
  menu: AppMenuNode;
  onCommand: (commandId: string, input?: unknown) => void;
}) {
  const hydrated = useSyncExternalStore(
    subscribeToHydration,
    clientHydratedSnapshot,
    serverHydratedSnapshot,
  );
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          className="fm-header__nav-item"
          disabled={!hydrated}
          size="sm"
          type="button"
          variant="ghost"
        >
          {menu.label}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start">
        <DropdownMenuLabel>{menu.label}</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {menu.children?.map((node) => (
          <MenuNode
            key={node.id}
            commandDisabledReason={commandDisabledReason}
            isCommandActive={isCommandActive}
            isCommandDisabled={isCommandDisabled}
            node={node}
            onCommand={onCommand}
          />
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

interface HeaderNavigationProps {
  homeActive: boolean;
  returnLabel?: string;
  onHome: () => void;
  commandDisabledReason: CommandDisabledReasonResolver;
  isCommandActive: (commandId: string) => boolean;
  isCommandDisabled: (commandId: string) => boolean;
  onCommand: (commandId: string, input?: unknown) => void;
}

/** Both menu presentations share the same nodes, command guards and reasons. */
function HeaderNavigation({ homeActive, returnLabel, onHome, ...commands }: HeaderNavigationProps) {
  const hydrated = useSyncExternalStore(
    subscribeToHydration,
    clientHydratedSnapshot,
    serverHydratedSnapshot,
  );
  return (
    <>
      <nav className="fm-header__nav" aria-label="Main menu">
        <StartNavItem active={homeActive} returnLabel={returnLabel} onCommand={onHome} />
        {MAIN_MENUS.map((menu) => <HeaderDropdown key={menu.id} menu={menu} {...commands} />)}
      </nav>
      <div className="fm-header__compact-menu">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button aria-label="Main menu" disabled={!hydrated} size="icon" variant="ghost" type="button">
              <Menu aria-hidden="true" size={16} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onSelect={onHome}>
              <House aria-hidden="true" size={14} />
              {homeActive && returnLabel ? returnLabel : "Home"}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            {MAIN_MENUS.map((node) => <MenuNode key={node.id} node={node} {...commands} />)}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </>
  );
}

function HeaderRunControls({
  commandDisabledReason,
  isCommandDisabled,
  onCommand,
}: Pick<HeaderNavigationProps, "commandDisabledReason" | "isCommandDisabled" | "onCommand">) {
  return (
    <div className="fm-header__run-controls" aria-label="Runtime controls">
      {RUN_CONTROLS.map((action) => (
        <Button
          key={action.id}
          className="fm-header__run-btn"
          data-command-id={action.id}
          data-run-control={action.id.replace(/^study\./, "")}
          disabled={Boolean(action.disabled || isCommandDisabled(action.id))}
          disabledReason={commandDisabledReason(action.id)}
          aria-label={action.label}
          size="icon"
          title={commandDisabledReason(action.id) ? undefined : action.label}
          type="button"
          variant="ghost"
          onClick={() => onCommand(action.id)}
        >
          {action.icon}
        </Button>
      ))}
    </div>
  );
}

function HeaderBrand({ subtitle }: { readonly subtitle: string }) {
  return (
    <div className="fm-header__brand">
      <FullmagMark size={20} className="fm-header__logo" />
      <span className="fm-header__brand-copy">
        <span className="fm-header__title">Fullmag</span>
        <span className="fm-header__subtitle" title={subtitle}>{subtitle}</span>
      </span>
    </div>
  );
}

/** First entry of the main menu: brings the start screen back over a workspace. */
function StartNavItem({
  active,
  onCommand,
  returnLabel,
}: {
  readonly active: boolean;
  readonly onCommand: () => void;
  readonly returnLabel?: string;
}) {
  const returning = active && Boolean(returnLabel);
  const label = returning ? returnLabel : "Home";
  return (
    <Button
      aria-current={active && !returning ? "page" : undefined}
      className="fm-header__nav-item"
      data-active={active ? "true" : undefined}
      size="sm"
      title={label}
      type="button"
      variant="ghost"
      onClick={onCommand}
    >
      {returning ? <ArrowLeft aria-hidden="true" size={14} /> : <House aria-hidden="true" size={14} />}
      {label}
    </Button>
  );
}

function QuickActionButton({
  action,
  disabled,
  disabledReason,
  onCommand,
}: {
  action: HeaderQuickAction;
  disabled: boolean;
  disabledReason: string | null;
  onCommand: (commandId: string, input?: unknown) => void;
}) {
  const reason = disabled ? disabledReason : null;
  return (
    <Button
      aria-label={action.label}
      className="fm-header__quick-action"
      disabled={action.disabled || disabled}
      disabledReason={reason}
      size="sm"
      title={reason ? undefined : action.label}
      type="button"
      variant="ghost"
      onClick={() => onCommand(action.id)}
    >
      {action.icon}
      <span>{action.label}</span>
    </Button>
  );
}

function ApiConnectionErrorDialog({
  details,
  onOpenChange,
  onRetry,
  open,
}: {
  details: ApiConnectionErrorDetails | null;
  onOpenChange: (open: boolean) => void;
  onRetry: () => void;
  open: boolean;
}) {
  if (!details) return null;

  const request = details.lastRequest;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        aria-describedby="fm-api-connection-error-description"
        aria-label="API connection error details"
      >
        <DialogHeader>
          <DialogTitle>API connection error</DialogTitle>
          <DialogDescription id="fm-api-connection-error-description">
            The session status resource failed. The exact frontend error and
            request target are shown below.
          </DialogDescription>
        </DialogHeader>
        <div className="fm-dialog__body">
          <dl className="fm-dialog__details">
            <div className="fm-dialog__details-row">
              <dt className="fm-dialog__details-label">Resource</dt>
              <dd className="fm-dialog__details-value">
                {details.resourceKey}
              </dd>
            </div>
            <div className="fm-dialog__details-row">
              <dt className="fm-dialog__details-label">Request</dt>
              <dd className="fm-dialog__details-value">
                GET {details.requestUrl}
              </dd>
            </div>
            <div className="fm-dialog__details-row">
              <dt className="fm-dialog__details-label">API base</dt>
              <dd className="fm-dialog__details-value">{details.apiBase}</dd>
            </div>
            <div className="fm-dialog__details-row">
              <dt className="fm-dialog__details-label">Contract</dt>
              <dd className="fm-dialog__details-value">
                expected {details.expectedContractVersion}
              </dd>
            </div>
            <div className="fm-dialog__details-row">
              <dt className="fm-dialog__details-label">HTTP status</dt>
              <dd className="fm-dialog__details-value">
                {details.httpStatus ?? request?.status ?? "not available"}
              </dd>
            </div>
            {request ? (
              <div className="fm-dialog__details-row">
                <dt className="fm-dialog__details-label">Request id</dt>
                <dd className="fm-dialog__details-value">
                  {request.requestId}
                </dd>
              </div>
            ) : null}
          </dl>
          <pre className="fm-dialog__error">
            {details.errorStack ?? `${details.errorName}: ${details.errorMessage}`}
          </pre>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button size="sm" type="button" variant="ghost">
              Close
            </Button>
          </DialogClose>
          <Button size="sm" type="button" onClick={onRetry}>
            Retry
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

interface AppMenuDialogState {
  apiDialogError: Error | null;
  communicationOpen: boolean;
  dataPreviewOpen: boolean;
  materialLibraryOpen: boolean;
  registryOpen: boolean;
  threadManagerOpen: boolean;
}

type AppMenuDialogAction =
  | { error: Error | null; type: "api-error" }
  | { open: boolean; type: "communication" }
  | { open: boolean; type: "data-preview" }
  | { open: boolean; type: "material-library" }
  | { open: boolean; type: "registry" }
  | { open: boolean; type: "thread-manager" };

const APP_MENU_DIALOG_INITIAL_STATE: AppMenuDialogState = {
  apiDialogError: null,
  communicationOpen: false,
  dataPreviewOpen: false,
  materialLibraryOpen: false,
  registryOpen: false,
  threadManagerOpen: false,
};

function appMenuDialogReducer(
  state: AppMenuDialogState,
  action: AppMenuDialogAction,
): AppMenuDialogState {
  switch (action.type) {
    case "api-error":
      return state.apiDialogError === action.error
        ? state
        : { ...state, apiDialogError: action.error };
    case "communication":
      return state.communicationOpen === action.open
        ? state
        : { ...state, communicationOpen: action.open };
    case "data-preview":
      return state.dataPreviewOpen === action.open
        ? state
        : { ...state, dataPreviewOpen: action.open };
    case "material-library":
      return state.materialLibraryOpen === action.open
        ? state
        : { ...state, materialLibraryOpen: action.open };
    case "registry":
      return state.registryOpen === action.open
        ? state
        : { ...state, registryOpen: action.open };
    case "thread-manager":
      return state.threadManagerOpen === action.open
        ? state
        : { ...state, threadManagerOpen: action.open };
  }
}

export function AppMenuBar() {
  const savedRun = useSavedRunSelection();
  const sessions = useSessionCollection();
  const identity = useSessionResourceIdentity();
  const [newProblem, setNewProblemOpen] = useNewProblemRequest();
  const hasActiveSession = !savedRun && sessions.state === "ready" && Boolean(identity);

  return (
    <>
      {hasActiveSession ? (
        <SessionAppMenuBar />
      ) : (
        <NoSessionAppMenuBar
          state={sessions.state === "ready" ? "loading" : sessions.state}
        />
      )}
      <NewProblemDialog
        hasActiveSession={hasActiveSession}
        initialBackend={newProblem.backend}
        key={newProblem.key}
        open={newProblem.open}
        onOpenChange={setNewProblemOpen}
      />
    </>
  );
}

function NoSessionAppMenuBar({
  state,
}: {
  readonly state: "error" | "loading" | "no-session";
}) {
  const kernel = useKernel();
  const { theme, setTheme } = useTheme();
  const homeOpen = useHomeViewOpen();
  const project = useProjectDocumentSnapshot();
  // Without a session the start screen is the page itself, unless a project is open.
  const homeVisible = project.state !== "ready" || homeOpen;
  const commandContext = createCommandContext("menu", kernel, {
    sourceDetail: "app-menu",
    sessionScopeKey: null,
  });
  const runCommand = (commandId: string, input?: unknown) => {
    if (!isProjectWorkspaceCommand(commandId)) return;
    if (kernel.commands.get(commandId)) {
      void kernel.commands.execute(commandId, commandContext, input);
    }
  };
  const commandDisabledReason = (commandId: string): string | null => {
    if (!isProjectWorkspaceCommand(commandId)) {
      return "Open or create a simulation to use this action.";
    }
    if (commandId === "workspace.new-problem" && state !== "no-session") {
      return "Waiting for session services.";
    }
    const command = kernel.commands.get(commandId);
    if (!command || kernel.commands.isEnabled(commandId, commandContext)) return null;
    return command.disabledReason?.(commandContext) ?? null;
  };
  const isCommandDisabled = (commandId: string) => {
    if (!isProjectWorkspaceCommand(commandId)) return true;
    if (commandId === "workspace.new-problem" && state !== "no-session") {
      return true;
    }
    const command = kernel.commands.get(commandId);
    return command ? !kernel.commands.isEnabled(commandId, commandContext) : false;
  };

  return (
    <header className="fm-header">
      <HeaderBrand
        subtitle={resolveNoSessionSubtitle(state)}
      />
      <HeaderNavigation
        homeActive={homeVisible}
        returnLabel={project.state === "ready" ? "Back to project" : undefined}
        onHome={() => runCommand(project.state === "ready"
          ? homeOpen ? "workspace.return-to-workspace" : "workspace.home"
          : "start.section.home")}
        commandDisabledReason={commandDisabledReason}
        isCommandActive={(commandId) => kernel.commands.isActive(commandId, commandContext)}
        isCommandDisabled={isCommandDisabled}
        onCommand={runCommand}
      />
      <button
        className="fm-header__search"
        disabled={isCommandDisabled("workspace.command-palette")}
        title="Command search (Ctrl+Shift+P)"
        type="button"
        onClick={() => runCommand("workspace.command-palette")}
      >
        <Search size={13} aria-hidden="true" />
        <span className="fm-header__search-label">Command search</span>
        <kbd className="fm-header__kbd">Ctrl ⇧ P</kbd>
      </button>
      {/* The start screen offers no simulation transport. */}
      {homeVisible ? null : (
        <>
          <div className="fm-header__separator" />
          <HeaderRunControls
            commandDisabledReason={commandDisabledReason}
            isCommandDisabled={isCommandDisabled}
            onCommand={runCommand}
          />
        </>
      )}
      <div className="fm-header__actions">
        <ProjectDocumentStatus />
        <ThemeSwitcher theme={theme} onThemeChange={setTheme} />
      </div>
    </header>
  );
}

function SessionAppMenuBar() {
  const kernel = useKernel();
  const { theme, setTheme } = useTheme();
  const sessionIdentity = useSessionResourceIdentity();
  const sessionScopeKey = sessionRequestScopeKey(sessionIdentity);
  const hydrated = useSyncExternalStore(
    subscribeToHydration,
    clientHydratedSnapshot,
    serverHydratedSnapshot,
  );
  const sessionStatus = useSessionStatusSelector(selectHeaderSessionSource, {
    enabled: sessionIdentity !== null,
    isEqual: headerSessionSourceEquals,
  });
  const visibleSessionStatus = resolveHydrationSafeHeaderSessionSource(
    sessionStatus,
    hydrated,
  );
  const [dialogState, dispatchDialogState] = useReducer(
    appMenuDialogReducer,
    APP_MENU_DIALOG_INITIAL_STATE,
  );
  const homeOpen = useHomeViewOpen();
  const setDataPreviewOpen = (open: boolean) =>
    dispatchDialogState({ open, type: "data-preview" });
  const setCommunicationOpen = (open: boolean) =>
    dispatchDialogState({ open, type: "communication" });
  const setRegistryOpen = (open: boolean) =>
    dispatchDialogState({ open, type: "registry" });
  const setThreadManagerOpen = (open: boolean) =>
    dispatchDialogState({ open, type: "thread-manager" });
  const setMaterialLibraryOpen = (open: boolean) =>
    dispatchDialogState({ open, type: "material-library" });
  useEffect(() => {
    return kernel.bus.on("diagnostics:recorder-open-requested", () => {
      dispatchDialogState({ open: true, type: "thread-manager" });
    });
  }, [kernel.bus]);
  const visualizationSnapshot = useObjectVisualizationSelector((snapshot) =>
    dialogState.registryOpen ? snapshot : EMPTY_OBJECT_VISUALIZATION_SNAPSHOT,
  );
  const runtimeResourceData = useRuntimeCommandControlResourceData({
    enabled: sessionIdentity !== null,
  });
  const sessionDisplay = resolveHeaderSessionDisplay(
    visibleSessionStatus,
    readDetailedRuntimeState(runtimeResourceData[SIMULATION_SOLVER_STATUS_PATH]),
  );
  const visualizationState = useVisualizationStateResource({ enabled: true });
  const visualizationSyncSnapshot = useSyncExternalStore(
    (onStoreChange) => kernel.visualizationSync.subscribe(onStoreChange),
    () => kernel.visualizationSync.getSnapshot(),
    () => kernel.visualizationSync.getSnapshot(),
  );
  const apiErrorDetails = useMemo(() => {
    if (!hydrated || !sessionStatus.error) return null;

    return resolveApiConnectionErrorDetails({
      apiBase: kernel.api.getBaseUrl(),
      error: sessionStatus.error,
      latestRequest: latestRequestForPath(
        kernel.diagnostics.list(),
        SESSION_STATUS_PATH,
      ),
    });
  }, [hydrated, kernel, sessionStatus.error]);
  const apiDialogOpen = Boolean(
    apiErrorDetails && dialogState.apiDialogError === sessionStatus.error,
  );
  const openApiDialog = () => {
    if (hydrated && sessionStatus.error) {
      dispatchDialogState({ error: sessionStatus.error, type: "api-error" });
    }
  };
  const onApiDialogOpenChange = (open: boolean) => {
    if (open) openApiDialog();
    else dispatchDialogState({ error: null, type: "api-error" });
  };
  const commandContext = createCommandContext("menu", kernel, {
    resourceData: runtimeResourceData,
    sessionScopeKey,
    sourceDetail: "app-menu",
  });
  const runCommand = (commandId: string, input?: unknown) => {
    if (commandId === "tools.registry-inspector") {
      setRegistryOpen(true);
      return;
    }
    if (commandId === "tools.thread-manager") {
      setThreadManagerOpen(true);
      return;
    }
    if (commandId === "tools.material-library") {
      setMaterialLibraryOpen(true);
      return;
    }
    if (commandId === "tools.data-preview") {
      setDataPreviewOpen(true);
      return;
    }
    if (commandId === "tools.communication") {
      setCommunicationOpen(true);
      return;
    }
    if (kernel.commands.get(commandId)) {
      void kernel.commands.execute(commandId, commandContext, input);
    }
  };
  const isCommandDisabled = (commandId: string): boolean => {
    const command = kernel.commands.get(commandId);
    return command ? !kernel.commands.isEnabled(commandId, commandContext) : false;
  };
  const commandDisabledReason = (commandId: string): string | null => {
    const command = kernel.commands.get(commandId);
    if (!command || kernel.commands.isEnabled(commandId, commandContext)) return null;
    return command.disabledReason?.(commandContext) ?? null;
  };
  const isCommandActive = (commandId: string): boolean =>
    kernel.commands.isActive(commandId, commandContext);

  return (
    <header className="fm-header">
      <HeaderBrand subtitle={sessionDisplay.subtitle} />

      <HeaderNavigation
        homeActive={homeOpen}
        returnLabel="Back to simulation"
        onHome={() => runCommand(homeOpen ? "workspace.return-to-workspace" : "workspace.home")}
        commandDisabledReason={commandDisabledReason}
        isCommandActive={isCommandActive}
        isCommandDisabled={isCommandDisabled}
        onCommand={runCommand}
      />

      {/* Home shows neither document edits nor simulation transport. */}
      {homeOpen ? null : (
        <div className="fm-header__quick-actions">
          {QUICK_ACTIONS.map((action) => (
            <QuickActionButton
              key={action.id}
              action={action}
              disabled={isCommandDisabled(action.id)}
              disabledReason={commandDisabledReason(action.id)}
              onCommand={runCommand}
            />
          ))}
        </div>
      )}

      <button
        className="fm-header__search"
        title="Command search (Ctrl+Shift+P)"
        type="button"
        onClick={() => runCommand("workspace.command-palette")}
      >
        <Search size={13} aria-hidden="true" />
        <span className="fm-header__search-label">Command search</span>
        <kbd className="fm-header__kbd">Ctrl ⇧ P</kbd>
      </button>

      <button
        className="fm-header__session-indicator"
        data-clickable={visibleSessionStatus.error ? "true" : undefined}
        type="button"
        onClick={openApiDialog}
        aria-expanded={apiDialogOpen ? true : undefined}
        aria-haspopup={visibleSessionStatus.error ? "dialog" : undefined}
        title={
          visibleSessionStatus.error
            ? "Open API error details"
            : sessionDisplay.indicatorLabel
        }
      >
        <span
          className="fm-header__session-dot"
          data-status={sessionDisplay.indicatorStatus}
          aria-label={sessionDisplay.indicatorLabel}
        />
        <span>{sessionDisplay.connectionLabel}</span>
        <span className="fm-header__session-badge">
          {sessionDisplay.sessionBadge}
        </span>
      </button>

      <ReadinessHelperHeaderControl
        commandContext={commandContext}
        kernel={kernel}
      />

      <ApiConnectionErrorDialog
        details={apiErrorDetails}
        onOpenChange={onApiDialogOpenChange}
        onRetry={sessionStatus.refetch ?? noopRefetch}
        open={apiDialogOpen}
      />

      <RegistryInspectorDialog
        open={dialogState.registryOpen}
        snapshot={visualizationSnapshot}
        syncSnapshot={visualizationSyncSnapshot}
        visualizationState={visualizationState.data}
        onOpenChange={setRegistryOpen}
        onRetryMutation={() => {
          void kernel.visualizationSync.retryRejectedMutation();
        }}
      />

      <DiagnosticRecorderDialog
        kernel={kernel}
        onOpenChange={setThreadManagerOpen}
        open={dialogState.threadManagerOpen}
      />

      <MaterialLibraryDialog
        onOpenChange={setMaterialLibraryOpen}
        open={dialogState.materialLibraryOpen}
      />

      <DataPreviewDialog
        onOpenChange={setDataPreviewOpen}
        open={dialogState.dataPreviewOpen}
      />

      <CommunicationPolicyDialog
        onOpenChange={setCommunicationOpen}
        open={dialogState.communicationOpen}
      />

      {homeOpen ? null : (
        <>
          <div className="fm-header__separator" />
          <HeaderRunControls
            commandDisabledReason={commandDisabledReason}
            isCommandDisabled={isCommandDisabled}
            onCommand={runCommand}
          />
        </>
      )}

      <div className="fm-header__separator" />

      <div className="fm-header__actions">
        <ProjectDocumentStatus />
        <ThemeSwitcher theme={theme} onThemeChange={setTheme} />
      </div>
    </header>
  );
}

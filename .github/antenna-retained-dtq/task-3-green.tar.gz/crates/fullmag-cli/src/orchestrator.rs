use anyhow::{anyhow, bail, Context, Result};
use clap::{Parser, ValueEnum};
use fullmag_ir::{
    AutosaveFormatIR, BackendPlanIR, BackendTarget, DiscretizationHintsIR, DynamicsIR,
    ExecutionPlanIR, FdmHintsIR, FemHintsIR, GeometryEntryIR, MagnetIR, MaterialIR, ObjectRegionIR,
    OutputDataFormatIR, OutputStorageIR, ProblemIR, RegionIR, RelaxationAlgorithmIR, StudyIR,
};
use std::collections::HashMap;
use std::ffi::OsString;
use std::fs;
use std::io::{Read, Write};
use std::path::{Component, Path, PathBuf};
use std::sync::{mpsc, Arc, Mutex};
use std::thread::JoinHandle;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use crate::args::*;
use crate::control_room::*;
use crate::dev_smoke::run_post_materialization_dev_smoke_tests;
use crate::formatting::*;
use crate::interactive_runtime_host::{CurrentLiveDisplaySelectionHandle, InteractiveRuntimeHost};
use crate::live_workspace::*;
use crate::nvtx_range;
use crate::python_bridge::*;
use crate::simulation_preparation::{
    PreparationLogLevel, PreparationStageId, PreparationStatus, SimulationPreparationState,
};
use crate::step_utils::*;
use crate::types::*;

mod manual_remesh;
use manual_remesh::execute_manual_interactive_remesh;
mod antenna_external_lead_inspection;
mod antenna_closed_loop_inspection;

// ── helpers local to the orchestrator ────────────────────────────────────────

const FEM_FREQUENCY_RESPONSE_PROGRESS_KEY: &str = "fem_frequency_response_progress";
const FREQUENCY_RESPONSE_TERMINAL_BAR_WIDTH: usize = 16;
const DEFERRED_MESH_FAILURE_SUMMARY: &str = "Shared-domain mesh build failed";
const SCRIPT_MESH_FAILURE_DETAIL: &str =
    "Script materialization reached mesh generation before failure; timing unavailable";
const INCOMPLETE_MATERIALIZED_IR_SKIP_DETAIL: &str =
    "Skipped because a complete materialized IR was unavailable after mesh generation failure";
const DEFERRED_DOMAIN_COMPLETION_DETAIL: &str =
    "Domain completed during deferred materialization; timing unavailable";
const DEFERRED_MESH_COMPLETION_DETAIL: &str =
    "Mesh completed during deferred materialization; timing unavailable";

struct ScriptOutputStorageLease {
    lease: Option<fullmag_runner::project_storage::ProjectStorageLease>,
}

impl ScriptOutputStorageLease {
    fn new(lease: fullmag_runner::project_storage::ProjectStorageLease) -> Self {
        Self { lease: Some(lease) }
    }

    fn resolved(&self) -> &fullmag_runner::project_storage::ResolvedOutputStorage {
        self.lease
            .as_ref()
            .expect("script storage lease is active")
            .resolved()
    }

    fn finish(&mut self, success: bool) -> Result<()> {
        let Some(mut lease) = self.lease.take() else {
            bail!("script storage lease is already finalized");
        };
        lease
            .finish(success)
            .map_err(|error| anyhow!("failed to finalize project output storage: {error}"))
    }
}

fn collect_authored_output_storage(
    config: &ScriptExecutionConfig,
) -> Result<Option<OutputStorageIR>> {
    let mut candidates = Vec::new();
    for problem in std::iter::once(&config.ir).chain(config.stages.iter().map(|stage| &stage.ir)) {
        if let Some(value) = problem.problem_meta.runtime_metadata.get("output_storage") {
            candidates.push(
                serde_json::from_value::<OutputStorageIR>(value.clone())
                    .context("invalid output_storage metadata")?,
            );
        }
    }
    let Some(first) = candidates.first().cloned() else {
        return Ok(None);
    };
    if candidates.iter().any(|candidate| candidate != &first) {
        bail!("script stages declare conflicting output_storage policies");
    }
    Ok(Some(first))
}

fn explicit_stage_output_format(problem: &ProblemIR) -> Option<OutputDataFormatIR> {
    match problem.study.sampling().stage_autosave.as_ref()?.format {
        AutosaveFormatIR::Zarr => Some(OutputDataFormatIR::Zarr),
        AutosaveFormatIR::Hdf5 => Some(OutputDataFormatIR::Hdf5),
        AutosaveFormatIR::Txt => None,
    }
}

fn prepare_script_output_storage(
    config: &mut ScriptExecutionConfig,
    args: &ScriptCli,
    script_path: &Path,
    run_id: &str,
) -> Result<(ScriptOutputStorageLease, OutputStorageIR, serde_json::Value)> {
    let authored = collect_authored_output_storage(config)?;
    let mut settings = authored.clone().unwrap_or_default();
    if authored.is_none() && args.data_format.is_none() {
        let mut stage_formats = std::iter::once(&config.ir)
            .chain(config.stages.iter().map(|stage| &stage.ir))
            .filter_map(explicit_stage_output_format);
        if let Some(format) = stage_formats.next() {
            if stage_formats.any(|other| other != format) {
                bail!("script stages declare conflicting primary autosave formats");
            }
            settings.data_format = format;
        }
    }

    if let Some(output_dir) = args.output_dir.as_ref() {
        let path = if output_dir.is_absolute() {
            output_dir.clone()
        } else {
            std::env::current_dir()?.join(output_dir)
        };
        settings.output_dir = Some(path.to_string_lossy().into_owned());
    }
    if let Some(temp_dir) = args.temp_dir.as_ref() {
        let path = if temp_dir.is_absolute() {
            temp_dir.clone()
        } else {
            std::env::current_dir()?.join(temp_dir)
        };
        settings.temp_dir = Some(path.to_string_lossy().into_owned());
    }
    if let Some(data_format) = args.data_format {
        settings.data_format = data_format.into();
    }
    if let Some(cleanup) = args.temp_cleanup {
        settings.cleanup = cleanup.into();
    }
    if let Some(existing_output) = args.existing_output {
        settings.existing_output = existing_output.into();
    }
    settings
        .validate()
        .map_err(|errors| anyhow!(errors.join("; ")))?;

    let script_dir = script_path.parent().unwrap_or_else(|| Path::new("."));
    let extension = match settings.data_format {
        OutputDataFormatIR::Zarr => "zarr",
        OutputDataFormatIR::Hdf5 => "results",
    };
    let default_output_dir = script_path.with_extension(extension);
    let lease = fullmag_runner::project_storage::ProjectStorageLease::prepare(
        &settings,
        &default_output_dir,
        script_dir,
        run_id,
    )
    .map_err(|error| anyhow!("failed to prepare project output storage: {error}"))?;
    let storage_lease = ScriptOutputStorageLease::new(lease);
    let resolved = serde_json::to_value(storage_lease.resolved())?;
    let settings_value = serde_json::to_value(&settings)?;
    let source_dir = script_dir.canonicalize()?.to_string_lossy().into_owned();
    let source_stem = script_path
        .file_stem()
        .and_then(|stem| stem.to_str())
        .unwrap_or("fullmag_script")
        .to_string();
    let attach_storage_metadata = |problem: &mut ProblemIR| {
        let metadata = &mut problem.problem_meta.runtime_metadata;
        metadata.insert("output_storage".to_string(), settings_value.clone());
        metadata.insert("resolved_output_storage".to_string(), resolved.clone());
        metadata.insert(
            "output_storage_source_dir".to_string(),
            serde_json::Value::String(source_dir.clone()),
        );
        metadata.insert(
            "output_storage_source_stem".to_string(),
            serde_json::Value::String(source_stem.clone()),
        );
    };
    attach_storage_metadata(&mut config.ir);
    for stage in &mut config.stages {
        attach_storage_metadata(&mut stage.ir);
    }
    Ok((storage_lease, settings, resolved))
}

fn prepare_grid_operation_storage(
    workspace_dir: &Path,
    command_id: &str,
    script_path: &Path,
) -> Result<(ScriptOutputStorageLease, OutputStorageIR, serde_json::Value)> {
    let operation_id = format!("grid-{}", fullmag_session::hex_sha256(command_id.as_bytes()));
    let operation_root = workspace_dir.join("grid-preparations").join(&operation_id);
    let settings = OutputStorageIR {
        output_dir: Some(operation_root.join("workspace").to_string_lossy().into_owned()),
        temp_dir: Some(operation_root.join("temporary").to_string_lossy().into_owned()),
        data_format: OutputDataFormatIR::Zarr,
        cleanup: fullmag_ir::TempCleanupIR::Never,
        existing_output: fullmag_ir::ExistingOutputIR::Error,
    };
    let source_dir = script_path.parent().context("grid source has no parent")?;
    let lease = fullmag_runner::project_storage::ProjectStorageLease::prepare(
        &settings, &operation_root.join("workspace"), source_dir, &operation_id,
    ).map_err(|error| anyhow!("failed to prepare private grid operation storage: {error}"))?;
    let lease = ScriptOutputStorageLease::new(lease);
    let resolved = serde_json::to_value(lease.resolved())?;
    Ok((lease, settings, resolved))
}

fn attached_session_id_or(generated: String) -> String {
    std::env::var("FULLMAG_ATTACHED_SESSION_ID")
        .ok()
        .map(|value| value.trim().to_string())
        .filter(|value| !value.is_empty())
        .unwrap_or(generated)
}

fn attached_session_started_at_or(generated: u128) -> Result<u128> {
    if std::env::var("FULLMAG_ATTACHED_SESSION_ID")
        .ok().is_none_or(|value| value.trim().is_empty())
    {
        return Ok(generated);
    }
    let raw = std::env::var("FULLMAG_ATTACHED_SESSION_STARTED_AT_UNIX_MS")
        .context("attached session requires its authoritative start timestamp")?;
    let timestamp = raw.parse::<u128>().context("invalid attached session start timestamp")?;
    anyhow::ensure!(timestamp > 0 && timestamp.to_string() == raw, "invalid attached session start timestamp");
    Ok(timestamp)
}

fn control_room_bootstrap_disabled() -> bool {
    std::env::var("FULLMAG_SKIP_CONTROL_ROOM")
        .ok()
        .is_some_and(|value| matches!(value.trim(), "1" | "true" | "yes"))
}

fn attached_wait_for_solve_enabled() -> bool {
    // `--wait-for-solve` is the flag form of the same gate.
    crate::script_launch::wait_for_solve_flag()
        || std::env::var("FULLMAG_ATTACHED_WAIT_FOR_SOLVE")
            .ok()
            .is_some_and(|value| matches!(value.trim(), "1" | "true" | "yes"))
}

fn frozen_spins_checkpoint_from_stage_artifacts(
    stage_artifact_dir: &Path,
) -> Result<Option<serde_json::Value>> {
    let path = stage_artifact_dir.join("constraints/frozen_spins_checkpoint.v1.json");
    if !path.is_file() {
        return Ok(None);
    }
    let bytes = fs::read(&path)
        .with_context(|| format!("reading Frozen Spins checkpoint {}", path.display()))?;
    let value = serde_json::from_slice(&bytes)
        .with_context(|| format!("parsing Frozen Spins checkpoint {}", path.display()))?;
    Ok(Some(value))
}

fn publish_frozen_spins_runtime_status_for_execution_plan(
    live_workspace: &LocalLiveWorkspace,
    execution_plan: &ExecutionPlanIR,
) -> Result<()> {
    let status =
        fullmag_runner::frozen_spins_runtime_status_for_backend_plan(&execution_plan.backend_plan)
            .map_err(|error| anyhow!(error.to_string()))?;
    live_workspace.update(|state| {
        let metadata = state.metadata.get_or_insert_with(|| serde_json::json!({}));
        let Some(metadata) = metadata.as_object_mut() else {
            return;
        };
        match status {
            Some(status) => {
                if let Ok(value) = serde_json::to_value(status) {
                    metadata.insert("frozen_spins_runtime_status".to_string(), value);
                }
            }
            None => {
                metadata.remove("frozen_spins_runtime_status");
            }
        }
    });
    Ok(())
}

fn preparation_unix_time_millis() -> Result<u64> {
    u64::try_from(unix_time_millis()?).context("preparation timestamp exceeds u64")
}

fn new_simulation_preparation(
    preparation_id: impl Into<String>,
    started_at_unix_ms: u64,
) -> Result<SimulationPreparationState> {
    let mut preparation = SimulationPreparationState::new(preparation_id, started_at_unix_ms);
    begin_preparation_stage(
        &mut preparation,
        PreparationStageId::RuntimeStartup,
        started_at_unix_ms,
        "Starting the local simulation runtime",
    )?;
    Ok(preparation)
}

fn push_preparation_log_once(
    preparation: &mut SimulationPreparationState,
    timestamp_unix_ms: u64,
    level: PreparationLogLevel,
    stage_id: PreparationStageId,
    message: &str,
) {
    let is_duplicate = preparation.log_tail.back().is_some_and(|entry| {
        entry.level == level && entry.stage_id == stage_id && entry.message == message
    });
    if !is_duplicate {
        preparation.push_log(timestamp_unix_ms, level, stage_id, message);
    }
}

fn begin_preparation_stage(
    preparation: &mut SimulationPreparationState,
    stage_id: PreparationStageId,
    timestamp_unix_ms: u64,
    detail: &str,
) -> std::result::Result<(), crate::simulation_preparation::PreparationTransitionError> {
    preparation.begin_stage(stage_id, timestamp_unix_ms, detail)?;
    push_preparation_log_once(
        preparation,
        timestamp_unix_ms,
        PreparationLogLevel::Info,
        stage_id,
        detail,
    );
    Ok(())
}

fn complete_preparation_stage(
    preparation: &mut SimulationPreparationState,
    stage_id: PreparationStageId,
    timestamp_unix_ms: u64,
    detail: &str,
) -> std::result::Result<(), crate::simulation_preparation::PreparationTransitionError> {
    preparation.complete_stage(stage_id, timestamp_unix_ms, detail)?;
    push_preparation_log_once(
        preparation,
        timestamp_unix_ms,
        PreparationLogLevel::Info,
        stage_id,
        detail,
    );
    Ok(())
}

fn skip_preparation_stage(
    preparation: &mut SimulationPreparationState,
    stage_id: PreparationStageId,
    timestamp_unix_ms: u64,
    detail: &str,
) -> std::result::Result<(), crate::simulation_preparation::PreparationTransitionError> {
    preparation.skip_stage(stage_id, detail)?;
    push_preparation_log_once(
        preparation,
        timestamp_unix_ms,
        PreparationLogLevel::Info,
        stage_id,
        detail,
    );
    Ok(())
}

fn fail_owned_preparation_stage(
    workspace: &LocalLiveWorkspace,
    stage_id: PreparationStageId,
    error_code: &str,
    safe_summary: &str,
) -> Result<()> {
    fail_owned_preparation_stage_with_detail(workspace, stage_id, error_code, safe_summary, None)
}

fn fail_owned_preparation_stage_with_detail(
    workspace: &LocalLiveWorkspace,
    stage_id: PreparationStageId,
    error_code: &str,
    safe_summary: &str,
    detail: Option<String>,
) -> Result<()> {
    let timestamp_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        preparation.fail_stage(stage_id, timestamp_unix_ms, error_code, safe_summary)?;
        preparation.set_failure_detail(detail);
        push_preparation_log_once(
            preparation,
            timestamp_unix_ms,
            PreparationLogLevel::Error,
            stage_id,
            safe_summary,
        );
        Ok(())
    })
}

fn fail_owned_preparation_stage_with_diagnostics(
    workspace: &LocalLiveWorkspace,
    stage_id: PreparationStageId,
    error_code: &str,
    safe_summary: &str,
    detail: Option<String>,
) -> Result<()> {
    let timestamp_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        preparation.fail_stage(stage_id, timestamp_unix_ms, error_code, safe_summary)?;
        preparation.set_failure_detail(detail);
        let correlation_id = format!(
            "preparation-{}-{}-{}",
            stage_id.as_str(),
            preparation.preparation_id,
            timestamp_unix_ms
        );
        if let Some(failure) = preparation.failure.as_mut() {
            failure.diagnostics_correlation_id = Some(correlation_id);
        }
        push_preparation_log_once(
            preparation,
            timestamp_unix_ms,
            PreparationLogLevel::Error,
            stage_id,
            safe_summary,
        );
        Ok(())
    })
}

fn safe_validation_failure_summary(error: &anyhow::Error, fallback: &str) -> String {
    error
        .chain()
        .find_map(|cause| safe_preparation_error_message(&cause.to_string()))
        .unwrap_or_else(|| fallback.to_string())
}

fn safe_preparation_error_detail(error: &anyhow::Error) -> Option<String> {
    error
        .chain()
        .filter_map(|cause| {
            let message = cause.to_string();
            safe_preparation_error_message(&message)
                .or_else(|| sanitized_preparation_error_message(&message))
        })
        .last()
}

fn safe_preparation_error_message(message: &str) -> Option<String> {
    let trimmed = message.trim();
    let is_single_line = !trimmed.contains('\n') && !trimmed.contains('\r');
    let is_bounded = !trimmed.is_empty() && trimmed.chars().count() <= 240;
    let has_private_path = trimmed.contains('/') || trimmed.contains('\\');
    let normalized = trimmed.to_ascii_lowercase();
    let has_secret_marker = normalized.contains("secret") || normalized.contains("token");
    (is_single_line && is_bounded && !has_private_path && !has_secret_marker)
        .then(|| trimmed.to_string())
}

fn sanitized_preparation_error_message(message: &str) -> Option<String> {
    let line = message
        .lines()
        .rev()
        .map(str::trim)
        .find(|line| !line.is_empty())?;
    let normalized = line.to_ascii_lowercase();
    if normalized.contains("secret") || normalized.contains("token") {
        return None;
    }
    let sanitized = line
        .split_whitespace()
        .map(|token| {
            if token.contains('/') || token.contains('\\') {
                "<path>"
            } else {
                token
            }
        })
        .collect::<Vec<_>>()
        .join(" ");
    let is_bounded = !sanitized.is_empty() && sanitized.chars().count() <= 240;
    is_bounded.then_some(sanitized)
}

fn fail_active_preparation_stage_with_diagnostics(
    workspace: &LocalLiveWorkspace,
    error_code: &str,
    safe_summary: &str,
    detail: Option<String>,
) -> Result<()> {
    let active_stage_id = workspace
        .snapshot()
        .simulation_preparation
        .as_ref()
        .and_then(|preparation| preparation.active_stage_id);
    if let Some(active_stage_id) = active_stage_id {
        fail_owned_preparation_stage_with_diagnostics(
            workspace,
            active_stage_id,
            error_code,
            safe_summary,
            detail,
        )?;
    }
    Ok(())
}

fn run_active_preparation_operation<T>(
    workspace: &LocalLiveWorkspace,
    error_code: &str,
    safe_failure_summary: &str,
    operation: impl FnOnce() -> Result<T>,
) -> Result<T> {
    match operation() {
        Ok(value) => Ok(value),
        Err(error) => {
            fail_active_preparation_stage_with_diagnostics(
                workspace,
                error_code,
                safe_failure_summary,
                safe_preparation_error_detail(&error),
            )?;
            Err(error)
        }
    }
}

fn own_preparation_boundary_failure<T>(
    workspace: &LocalLiveWorkspace,
    error_code: &str,
    safe_failure_summary: &str,
    result: Result<T>,
) -> Result<T> {
    match result {
        Ok(value) => Ok(value),
        Err(error) => {
            if let Err(record_error) = fail_owned_preparation_stage_with_diagnostics(
                workspace,
                PreparationStageId::ScriptMaterialization,
                error_code,
                safe_failure_summary,
                safe_preparation_error_detail(&error),
            ) {
                eprintln!(
                    "[fullmag-cli] WARNING: could not record safe preparation boundary failure: {}",
                    record_error
                );
            }
            Err(error)
        }
    }
}

fn wait_for_failed_preparation_close(
    workspace: &LocalLiveWorkspace,
    mut next_command: impl FnMut() -> Option<SessionCommand>,
) {
    let is_terminal_failure = workspace
        .snapshot()
        .simulation_preparation
        .as_ref()
        .is_some_and(|preparation| preparation.status == PreparationStatus::Failed);
    if !is_terminal_failure {
        return;
    }

    let failure = workspace
        .snapshot()
        .simulation_preparation
        .and_then(|preparation| preparation.failure);
    if let Some(failure) = failure {
        eprintln!(
            "[fullmag] simulation preparation failed: {}",
            failure.summary
        );
        if let Some(detail) = failure.detail {
            eprintln!("[fullmag] preparation failure detail: {detail}");
        }
        if let Some(correlation_id) = failure.diagnostics_correlation_id {
            eprintln!("[fullmag] diagnostic correlation id: {correlation_id}");
        }
    } else {
        eprintln!("[fullmag] simulation preparation failed");
    }
    eprintln!("[fullmag] Control Room remains available until explicit close");
    workspace.push_log(
        "system",
        "Simulation preparation failed — Control Room remains available until Close",
    );
    loop {
        let Some(command) = next_command() else {
            continue;
        };
        let is_close = command.kind == "close"
            || matches!(
                crate::command_bridge::classify_command(&command),
                Some(fullmag_runner::LiveControlCommand::Close)
            );
        if is_close {
            workspace.push_log(
                "system",
                "Close acknowledged — shutting down the failed workspace",
            );
            return;
        }
    }
}

fn begin_script_materialization(workspace: &LocalLiveWorkspace) -> Result<()> {
    let timestamp_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        complete_preparation_stage(
            preparation,
            PreparationStageId::RuntimeStartup,
            timestamp_unix_ms,
            "Local simulation runtime started",
        )?;
        begin_preparation_stage(
            preparation,
            PreparationStageId::ScriptMaterialization,
            timestamp_unix_ms,
            "Materializing the Python simulation script",
        )?;
        Ok(())
    })
}

fn run_owned_preparation_stage<T>(
    workspace: &LocalLiveWorkspace,
    stage_id: PreparationStageId,
    active_detail: &str,
    completed_detail: &str,
    skip_on_success: bool,
    error_code: &str,
    safe_failure_summary: &str,
    expose_safe_operation_error: bool,
    operation: impl FnOnce() -> Result<T>,
) -> Result<T> {
    let started_at_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        if stage_id == PreparationStageId::SolverInitialization
            && preparation.active_stage_id == Some(PreparationStageId::MeshPostprocessing)
        {
            complete_preparation_stage(
                preparation,
                PreparationStageId::MeshPostprocessing,
                started_at_unix_ms,
                "Mesh preparation complete",
            )?;
        }
        begin_preparation_stage(preparation, stage_id, started_at_unix_ms, active_detail)?;
        Ok(())
    })?;

    match operation() {
        Ok(value) => {
            let completed_at_unix_ms = preparation_unix_time_millis()?;
            transition_preparation(workspace, |preparation| {
                if skip_on_success {
                    skip_preparation_stage(
                        preparation,
                        stage_id,
                        completed_at_unix_ms,
                        completed_detail,
                    )?;
                } else {
                    complete_preparation_stage(
                        preparation,
                        stage_id,
                        completed_at_unix_ms,
                        completed_detail,
                    )?;
                }
                Ok(())
            })?;
            Ok(value)
        }
        Err(error) => {
            if expose_safe_operation_error {
                let summary = safe_validation_failure_summary(&error, safe_failure_summary);
                fail_owned_preparation_stage_with_diagnostics(
                    workspace,
                    stage_id,
                    error_code,
                    &summary,
                    safe_preparation_error_detail(&error),
                )?;
            } else {
                fail_owned_preparation_stage(
                    workspace,
                    stage_id,
                    error_code,
                    safe_failure_summary,
                )?;
            }
            Err(error)
        }
    }
}

fn run_solver_initialization_safety_check<T>(
    workspace: &LocalLiveWorkspace,
    active_detail: &'static str,
    error_code: &'static str,
    safe_failure_summary: &'static str,
    operation: impl FnOnce() -> Result<T>,
) -> Result<T> {
    let timestamp_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        begin_preparation_stage(
            preparation,
            PreparationStageId::SolverInitialization,
            timestamp_unix_ms,
            active_detail,
        )?;
        Ok(())
    })?;
    match operation() {
        Ok(value) => Ok(value),
        Err(error) => {
            fail_owned_preparation_stage_with_diagnostics(
                workspace,
                PreparationStageId::SolverInitialization,
                error_code,
                safe_failure_summary,
                safe_preparation_error_detail(&error),
            )?;
            Err(error)
        }
    }
}

fn run_solver_initialization<T>(
    workspace: &LocalLiveWorkspace,
    skip_on_success: bool,
    operation: impl FnOnce() -> Result<T>,
) -> Result<T> {
    let started_at_unix_ms = preparation_unix_time_millis()?;
    let active_detail = if skip_on_success {
        "Checking fully materialized workspace resources"
    } else {
        "Initializing the solver and checking the fully materialized runtime"
    };
    transition_preparation(workspace, |preparation| {
        if preparation.active_stage_id == Some(PreparationStageId::MeshPostprocessing) {
            complete_preparation_stage(
                preparation,
                PreparationStageId::MeshPostprocessing,
                started_at_unix_ms,
                "Mesh preparation complete",
            )?;
        }
        begin_preparation_stage(
            preparation,
            PreparationStageId::SolverInitialization,
            started_at_unix_ms,
            active_detail,
        )?;
        Ok(())
    })?;

    match operation() {
        Ok(value) => {
            let completed_at_unix_ms = preparation_unix_time_millis()?;
            transition_preparation(workspace, |preparation| {
                if skip_on_success {
                    skip_preparation_stage(
                        preparation,
                        PreparationStageId::SolverInitialization,
                        completed_at_unix_ms,
                        "No solver stage is present in this workspace preparation",
                    )?;
                } else {
                    complete_preparation_stage(
                        preparation,
                        PreparationStageId::SolverInitialization,
                        completed_at_unix_ms,
                        "Solver initialization complete",
                    )?;
                }
                Ok(())
            })?;
            Ok(value)
        }
        Err(error) => {
            let failure_is_already_owned = workspace
                .snapshot()
                .simulation_preparation
                .as_ref()
                .is_some_and(|preparation| preparation.failure.is_some());
            if !failure_is_already_owned {
                fail_owned_preparation_stage(
                    workspace,
                    PreparationStageId::SolverInitialization,
                    "solver_initialization_failed",
                    "Solver initialization failed",
                )?;
            }
            Err(error)
        }
    }
}

fn run_script_preparation_preflight(
    workspace: &LocalLiveWorkspace,
    validate: impl FnOnce() -> Result<()>,
    plan: impl FnOnce() -> Result<()>,
) -> Result<()> {
    let materialized_at_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        complete_preparation_stage(
            preparation,
            PreparationStageId::ScriptMaterialization,
            materialized_at_unix_ms,
            "Python script materialized",
        )?;
        Ok(())
    })?;
    run_owned_preparation_stage(
        workspace,
        PreparationStageId::Validation,
        "Validating the canonical simulation problem",
        "Simulation problem validated",
        false,
        "validation_failed",
        "Simulation validation failed",
        true,
        validate,
    )?;
    run_owned_preparation_stage(
        workspace,
        PreparationStageId::Planning,
        "Resolving the simulation execution plan",
        "Simulation execution plan resolved",
        false,
        "planning_failed",
        "Simulation planning failed",
        false,
        plan,
    )?;
    let domain_started_at_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        begin_preparation_stage(
            preparation,
            PreparationStageId::DomainPreparation,
            domain_started_at_unix_ms,
            "Preparing simulation domain inputs",
        )?;
        Ok(())
    })
}

fn project_completed_preparation_stage(
    preparation: &mut SimulationPreparationState,
    stage_id: PreparationStageId,
    timestamp_unix_ms: u64,
    detail: &str,
) -> std::result::Result<(), crate::simulation_preparation::PreparationTransitionError> {
    preparation.project_completed_stage(stage_id, detail)?;
    push_preparation_log_once(
        preparation,
        timestamp_unix_ms,
        PreparationLogLevel::Info,
        stage_id,
        detail,
    );
    Ok(())
}

fn deferred_mesh_failure_stage(
    detailed_mesh_workspace: Option<&serde_json::Value>,
) -> Option<PreparationStageId> {
    let workspace = detailed_mesh_workspace?.as_object()?;
    workspace
        .get("last_build_error")
        .and_then(serde_json::Value::as_str)
        .filter(|error| !error.trim().is_empty())?;
    let payload = workspace
        .get("last_build_attempt")
        .filter(|value| value.is_object())
        .or_else(|| workspace.get("last_build_summary"))?;
    match payload.get("phase").and_then(serde_json::Value::as_str) {
        Some("preparing_domain" | "meshing" | "postprocessing") => {}
        _ => return None,
    }
    match python_mesh_preparation_update("mesh_build_failed", payload)? {
        PythonMeshPreparationUpdate::Failed { stage_id, .. } => Some(stage_id),
        _ => None,
    }
}

fn project_deferred_mesh_failure(
    preparation: &mut SimulationPreparationState,
    failure_stage_id: PreparationStageId,
    timestamp_unix_ms: u64,
) -> std::result::Result<(), crate::simulation_preparation::PreparationTransitionError> {
    if !matches!(
        preparation.active_stage_id,
        None | Some(PreparationStageId::DomainPreparation)
    ) {
        return Err(
            crate::simulation_preparation::PreparationTransitionError::StageIsNotActive {
                stage_id: failure_stage_id,
                active_stage_id: preparation.active_stage_id,
            },
        );
    }
    if failure_stage_id != PreparationStageId::DomainPreparation {
        project_completed_preparation_stage(
            preparation,
            PreparationStageId::DomainPreparation,
            timestamp_unix_ms,
            DEFERRED_DOMAIN_COMPLETION_DETAIL,
        )?;
    }
    if failure_stage_id == PreparationStageId::MeshPostprocessing {
        project_completed_preparation_stage(
            preparation,
            PreparationStageId::Meshing,
            timestamp_unix_ms,
            DEFERRED_MESH_COMPLETION_DETAIL,
        )?;
    }
    preparation.project_failed_stage(
        failure_stage_id,
        "mesh_build_failed",
        DEFERRED_MESH_FAILURE_SUMMARY,
    )?;
    push_preparation_log_once(
        preparation,
        timestamp_unix_ms,
        PreparationLogLevel::Error,
        failure_stage_id,
        DEFERRED_MESH_FAILURE_SUMMARY,
    );
    Ok(())
}

fn project_authoritative_authored_preflight_failure(
    workspace: &LocalLiveWorkspace,
    error: &anyhow::Error,
) -> Result<bool> {
    let Some(detail) = safe_preparation_error_detail(error) else {
        return Ok(false);
    };
    if !detail.contains("fem_mixed_p1_scope_rejected: phase=authored_preflight;") {
        return Ok(false);
    }

    let timestamp_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        project_completed_preparation_stage(
            preparation,
            PreparationStageId::ScriptMaterialization,
            timestamp_unix_ms,
            "Python authored simulation materialized for capability preflight",
        )?;
        skip_preparation_stage(
            preparation,
            PreparationStageId::Validation,
            timestamp_unix_ms,
            "Full canonical validation was not reached after authored capability rejection",
        )?;
        preparation.project_failed_stage(
            PreparationStageId::Planning,
            "fem_mixed_p1_scope_rejected",
            "Simulation planning rejected unsupported mixed-P1 capability",
        )?;
        preparation.set_failure_detail(Some(detail.clone()));
        let correlation_id = format!(
            "preparation-{}-{}-{}",
            PreparationStageId::Planning.as_str(),
            preparation.preparation_id,
            timestamp_unix_ms
        );
        if let Some(failure) = preparation.failure.as_mut() {
            failure.diagnostics_correlation_id = Some(correlation_id);
        }
        push_preparation_log_once(
            preparation,
            timestamp_unix_ms,
            PreparationLogLevel::Error,
            PreparationStageId::Planning,
            "Simulation planning rejected unsupported mixed-P1 capability",
        );
        Ok(())
    })?;
    Ok(true)
}

fn project_script_export_failure(
    workspace: &LocalLiveWorkspace,
    early_preflight_completed: bool,
    error: anyhow::Error,
) -> Result<anyhow::Error> {
    let snapshot = workspace.snapshot();
    let deferred_failure_stage = deferred_mesh_failure_stage(snapshot.mesh_workspace.as_ref());
    let is_phase1_fallback = !early_preflight_completed
        && snapshot
            .simulation_preparation
            .as_ref()
            .is_some_and(|preparation| {
                preparation.active_stage_id == Some(PreparationStageId::ScriptMaterialization)
            });
    if let (true, Some(failure_stage_id)) = (is_phase1_fallback, deferred_failure_stage) {
        let timestamp_unix_ms = preparation_unix_time_millis()?;
        transition_preparation(workspace, |preparation| {
            project_completed_preparation_stage(
                preparation,
                PreparationStageId::ScriptMaterialization,
                timestamp_unix_ms,
                SCRIPT_MESH_FAILURE_DETAIL,
            )?;
            skip_preparation_stage(
                preparation,
                PreparationStageId::Validation,
                timestamp_unix_ms,
                INCOMPLETE_MATERIALIZED_IR_SKIP_DETAIL,
            )?;
            skip_preparation_stage(
                preparation,
                PreparationStageId::Planning,
                timestamp_unix_ms,
                INCOMPLETE_MATERIALIZED_IR_SKIP_DETAIL,
            )?;
            project_deferred_mesh_failure(preparation, failure_stage_id, timestamp_unix_ms)
        })?;
    } else {
        fail_active_preparation_stage_with_diagnostics(
            workspace,
            "materialization_failed",
            "Simulation materialization failed",
            safe_preparation_error_detail(&error),
        )?;
    }
    Ok(error)
}

fn finish_mesh_preparation(
    workspace: &LocalLiveWorkspace,
    detailed_mesh_workspace: Option<&serde_json::Value>,
) -> Result<()> {
    let deferred_failure_stage = deferred_mesh_failure_stage(detailed_mesh_workspace);
    if deferred_failure_stage.is_some()
        && workspace
            .snapshot()
            .simulation_preparation
            .as_ref()
            .is_some_and(|preparation| preparation.failure.is_some())
    {
        return Err(anyhow!(DEFERRED_MESH_FAILURE_SUMMARY));
    }
    let mesh_was_materialized = detailed_mesh_workspace
        .and_then(|resource| resource.get("last_build_summary"))
        .is_some_and(|summary| !summary.is_null());
    let timestamp_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        if let Some(failure_stage_id) = deferred_failure_stage {
            project_deferred_mesh_failure(preparation, failure_stage_id, timestamp_unix_ms)?;
            return Ok(());
        }
        match preparation.active_stage_id {
            Some(PreparationStageId::DomainPreparation) => {
                if mesh_was_materialized {
                    project_completed_preparation_stage(
                        preparation,
                        PreparationStageId::DomainPreparation,
                        timestamp_unix_ms,
                        DEFERRED_DOMAIN_COMPLETION_DETAIL,
                    )?;
                    project_completed_preparation_stage(
                        preparation,
                        PreparationStageId::Meshing,
                        timestamp_unix_ms,
                        DEFERRED_MESH_COMPLETION_DETAIL,
                    )?;
                    project_completed_preparation_stage(
                        preparation,
                        PreparationStageId::MeshPostprocessing,
                        timestamp_unix_ms,
                        "Mesh postprocessing completed during deferred materialization; timing unavailable",
                    )?;
                } else {
                    skip_preparation_stage(
                        preparation,
                        PreparationStageId::DomainPreparation,
                        timestamp_unix_ms,
                        "No shared-domain preparation was required",
                    )?;
                    skip_preparation_stage(
                        preparation,
                        PreparationStageId::Meshing,
                        timestamp_unix_ms,
                        "No meshing phase was required",
                    )?;
                    skip_preparation_stage(
                        preparation,
                        PreparationStageId::MeshPostprocessing,
                        timestamp_unix_ms,
                        "No mesh postprocessing phase was required",
                    )?;
                }
            }
            Some(PreparationStageId::Meshing) => {
                complete_preparation_stage(
                    preparation,
                    PreparationStageId::Meshing,
                    timestamp_unix_ms,
                    "Mesh generated",
                )?;
                skip_preparation_stage(
                    preparation,
                    PreparationStageId::MeshPostprocessing,
                    timestamp_unix_ms,
                    "No separate mesh postprocessing phase was reported",
                )?;
            }
            Some(PreparationStageId::MeshPostprocessing) => {
                complete_preparation_stage(
                    preparation,
                    PreparationStageId::MeshPostprocessing,
                    timestamp_unix_ms,
                    "Mesh preparation complete",
                )?;
            }
            None => {}
            _ => {
                return Err(
                    crate::simulation_preparation::PreparationTransitionError::StageIsNotActive {
                        stage_id: PreparationStageId::MeshPostprocessing,
                        active_stage_id: preparation.active_stage_id,
                    },
                );
            }
        }
        Ok(())
    })?;
    if deferred_failure_stage.is_some() {
        Err(anyhow!(DEFERRED_MESH_FAILURE_SUMMARY))
    } else {
        Ok(())
    }
}

fn mark_preparation_ready(workspace: &LocalLiveWorkspace, detail: &str) -> Result<()> {
    let ready_at_unix_ms = preparation_unix_time_millis()?;
    transition_preparation(workspace, |preparation| {
        preparation.mark_ready(ready_at_unix_ms, detail)?;
        push_preparation_log_once(
            preparation,
            ready_at_unix_ms,
            PreparationLogLevel::Info,
            PreparationStageId::Ready,
            detail,
        );
        Ok(())
    })
}

fn mark_ui_shell_preparation_ready(workspace: &LocalLiveWorkspace) -> Result<()> {
    let timestamp_unix_ms = preparation_unix_time_millis()?;
    const SKIP_DETAIL: &str =
        "The UI launch prepares an authoring workspace without materializing a simulation";
    transition_preparation(workspace, |preparation| {
        complete_preparation_stage(
            preparation,
            PreparationStageId::RuntimeStartup,
            timestamp_unix_ms,
            "Authoring workspace runtime started",
        )?;
        for stage_id in [
            PreparationStageId::ScriptMaterialization,
            PreparationStageId::Validation,
            PreparationStageId::Planning,
            PreparationStageId::DomainPreparation,
            PreparationStageId::Meshing,
            PreparationStageId::MeshPostprocessing,
            PreparationStageId::SolverInitialization,
        ] {
            skip_preparation_stage(preparation, stage_id, timestamp_unix_ms, SKIP_DETAIL)?;
        }
        preparation.mark_ready(timestamp_unix_ms, "Authoring workspace ready")?;
        push_preparation_log_once(
            preparation,
            timestamp_unix_ms,
            PreparationLogLevel::Info,
            PreparationStageId::Ready,
            "Authoring workspace ready",
        );
        Ok(())
    })
}

fn interactive_dense_ram_budget_bytes(available_ram: u64) -> u64 {
    let available_budget = (available_ram as f64 * 0.8) as u64;
    let default_interactive_budget = 12 * 1024 * 1024 * 1024_u64;

    match std::env::var("FULLMAG_FEM_INTERACTIVE_RAM_TARGET_GB") {
        Ok(raw) => {
            let value = raw.trim();
            if value.eq_ignore_ascii_case("off")
                || value.eq_ignore_ascii_case("none")
                || value == "0"
            {
                available_budget
            } else if let Ok(gb) = value.parse::<f64>() {
                if gb.is_finite() && gb > 0.0 {
                    ((gb * 1024.0 * 1024.0 * 1024.0) as u64).min(available_budget)
                } else {
                    default_interactive_budget.min(available_budget)
                }
            } else {
                default_interactive_budget.min(available_budget)
            }
        }
        Err(_) => default_interactive_budget.min(available_budget),
    }
}

fn fem_interactive_dense_ram_estimate(fem_plan: &fullmag_ir::FemPlanIR) -> Option<u64> {
    if !fem_plan.enable_demag {
        return None;
    }
    if fem_plan
        .demag_realization
        .is_some_and(|realization| realization.is_poisson())
    {
        return None;
    }
    Some(estimate_fem_dense_ram(fem_plan.mesh.nodes.len()))
}

fn current_live_metadata(
    problem: &ProblemIR,
    plan: &ExecutionPlanIR,
    status: &str,
) -> serde_json::Value {
    if matches!(&plan.backend_plan, BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)) {
        return serde_json::json!({
            "problem_name": &problem.problem_meta.name,
            "ir_version": &problem.ir_version,
            "source_hash": &problem.problem_meta.source_hash,
            "execution_plan": plan,
            "inspection_carrier_only": true,
            "magnetic_state_present": false,
            "runtime_engine": null,
            "resolved_execution": null,
            "execution_status": "requires_typed_accepted_worker",
            "qualification": "NOT VERIFIED",
            "artifact_layout": current_artifact_layout(problem, plan),
            "status": status,
        });
    }
    if antenna_external_lead_inspection::is_carrier(plan) {
        let closed_loop = plan.provenance.notes.iter().any(|note| note == "antenna_closed_loop_inspection_carrier_only:no_llg_execution");
        let inspection_family = if closed_loop { "antenna_closed_loop_inspection" } else { "antenna_external_lead_inspection" };
        return serde_json::json!({
            "session_protocol_version": "2026-04-04",
            "capability_profile_version": "2026-04-04",
            "problem_name": &problem.problem_meta.name,
            "ir_version": &problem.ir_version,
            "source_hash": &problem.problem_meta.source_hash,
            "execution_plan": if matches!(plan.backend_plan, BackendPlanIR::AntennaFieldOnly(_)) { serde_json::to_value(plan).ok() } else { Some(serde_json::json!({"backend_plan": {"kind": "antenna_external_lead_inspection"}})) },
            "magnetic_state_present": !problem.magnets.is_empty(),
            "inspection_carrier_only": true,
            "runtime_engine": {
                "backend_family": "fem",
                "engine_id": inspection_family,
                "engine_label": "Inspection-only V/RT0/H",
                "accelerator": "cpu",
            },
            "requested_execution": {
                "backend": backend_target_name(problem.backend_policy.requested_backend),
                "device": requested_device_from_problem(problem),
                "precision": execution_precision_name(problem.backend_policy.execution_precision),
                "mode": execution_mode_name(problem.validation_profile.execution_mode),
            },
            "resolved_execution": {
                "backend": "fem", "device": "cpu", "precision": "double", "mode": "strict",
                "runtime_family": inspection_family,
                "engine_id": inspection_family, "lossy_fallback_used": false,
            },
            "qualification": "NOT VERIFIED",
            "field_scope": if closed_loop { "closed_geometry_coincident_cut_full_volume" } else { "external_electrode_truncation" },
            "timestep_qualification": null,
            "capabilities": null,
            "artifact_layout": current_artifact_layout(problem, plan),
            "meshing_capabilities": current_meshing_capabilities(plan),
            "live_preview": {"mode": "inspection_resources_only", "supported_quantities": [], "downsampling": null},
            "engine_version": env!("CARGO_PKG_VERSION"),
            "status": status,
        });
    }
    let runtime_engine_info = fullmag_runner::resolve_planned_runtime_engine(problem, plan).ok();
    let resolved_session_runtime =
        fullmag_runner::resolve_session_runtime_for_plan_and_preview(problem, plan, u64::MAX).ok();
    let timestep_qualification = resolved_session_runtime.as_ref().and_then(|runtime| {
        fullmag_runner::timestep_qualification_for_plan(plan, &runtime.resolved_device)
    });
    let resolved_execution = resolved_session_runtime.as_ref().map(|runtime| {
        serde_json::json!({
            "backend": &runtime.resolved_backend,
            "device": &runtime.resolved_device,
            "precision": &runtime.resolved_precision,
            "mode": &runtime.resolved_mode,
            "runtime_family": &runtime.resolved_runtime_family,
            "engine_id": &runtime.resolved_engine_id,
            "lossy_fallback_used": runtime.resolved_fallback.is_some(),
        })
    });
    let capabilities = fullmag_runner::resolve_planned_runtime_capabilities(problem, plan).ok();
    let live_preview_supported_quantities = capabilities
        .as_ref()
        .map(|caps| caps.preview_quantities.clone())
        .unwrap_or_else(|| match &plan.backend_plan {
            BackendPlanIR::FdmMultilayer(_) => vec!["m".to_string()],
            BackendPlanIR::FemEigen(_) => vec![],
            _ => vec![],
        });
    let runtime_engine = runtime_engine_info.map(|engine| {
        serde_json::json!({
            "backend_family": engine.backend_family,
            "engine_id": engine.engine_id,
            "engine_label": engine.engine_label,
            "accelerator": engine.accelerator,
        })
    });
    serde_json::json!({
        "session_protocol_version": "2026-04-04",
        "capability_profile_version": capabilities.as_ref().map(|caps| caps.capability_profile_version.clone()).unwrap_or_else(|| "2026-04-04".to_string()),
        "problem_name": &problem.problem_meta.name,
        "ir_version": &problem.ir_version,
        "source_hash": &problem.problem_meta.source_hash,
        "problem_meta": &problem.problem_meta,
        "table_autosave": problem.study.sampling().table_autosave.as_ref(),
        "execution_plan": plan,
        "runtime_engine": runtime_engine,
        "resolved_execution": resolved_execution,
        "timestep_qualification": timestep_qualification,
        "capabilities": capabilities,
        "artifact_layout": current_artifact_layout(problem, plan),
        "meshing_capabilities": current_meshing_capabilities(plan),
        "live_preview": {
            "mode": "active_source",
            "supported_quantities": live_preview_supported_quantities,
            "downsampling": "runner_side_binned",
        },
        "engine_version": env!("CARGO_PKG_VERSION"),
        "status": status,
    })
}

fn requested_device_from_problem(problem: &ProblemIR) -> String {
    problem
        .problem_meta
        .runtime_metadata
        .get("runtime_selection")
        .and_then(serde_json::Value::as_object)
        .and_then(|selection| selection.get("device"))
        .and_then(serde_json::Value::as_str)
        .unwrap_or("auto")
        .to_string()
}

fn explicit_selection_from_problem(problem: &ProblemIR) -> bool {
    problem
        .problem_meta
        .runtime_metadata
        .get("runtime_selection")
        .and_then(serde_json::Value::as_object)
        .and_then(|selection| selection.get("explicit_selection"))
        .and_then(serde_json::Value::as_bool)
        .unwrap_or(false)
}

fn requested_cpu_threads_from_problem(problem: &ProblemIR) -> Option<u32> {
    problem
        .problem_meta
        .runtime_metadata
        .get("runtime_selection")
        .and_then(serde_json::Value::as_object)
        .and_then(|selection| selection.get("cpu_threads"))
        .and_then(serde_json::Value::as_u64)
        .and_then(|threads| u32::try_from(threads).ok())
}

fn is_gpu_device_label(value: &str) -> bool {
    matches!(value.trim().to_ascii_lowercase().as_str(), "gpu" | "cuda")
}

fn requested_execution_device(runtime: &SessionRuntimeSelection) -> String {
    let fem_override = std::env::var("FULLMAG_FEM_EXECUTION").ok();
    let fdm_override = std::env::var("FULLMAG_FDM_EXECUTION").ok();
    requested_execution_device_for_overrides(
        runtime,
        fem_override.as_deref(),
        fdm_override.as_deref(),
    )
}

fn requested_execution_device_for_overrides(
    runtime: &SessionRuntimeSelection,
    fem_override: Option<&str>,
    fdm_override: Option<&str>,
) -> String {
    let override_value = match runtime.requested_backend.as_str() {
        "fdm" => fdm_override.or(fem_override),
        "fem" => fem_override.or(fdm_override),
        _ => fem_override.or(fdm_override),
    };
    match override_value {
        Some(value) if matches!(value, "gpu" | "cuda" | "all_in_gpu") => "gpu".to_string(),
        Some("cpu") => "cpu".to_string(),
        _ => runtime.requested_device.replace("cuda", "gpu"),
    }
}

fn fem_gpu_execution_requested(problem: &ProblemIR, runtime: &SessionRuntimeSelection) -> bool {
    if is_gpu_device_label(&runtime.requested_device) {
        return true;
    }
    if runtime
        .resolved_device
        .as_deref()
        .is_some_and(is_gpu_device_label)
    {
        return true;
    }
    if is_gpu_device_label(&requested_device_from_problem(problem)) {
        return true;
    }
    std::env::var("FULLMAG_FEM_EXECUTION")
        .map(|value| is_gpu_device_label(&value))
        .unwrap_or(false)
}

fn fem_gpu_memory_preflight_message(
    estimated_memory_bytes: u64,
    status: &fullmag_runner::NativeFemGpuStatus,
) -> (&'static str, String) {
    let estimated_gb = estimated_memory_bytes as f64 / 1e9;
    if !status.available {
        let reason = if status.reason_gpu.trim().is_empty() {
            "native FEM GPU availability probe did not report a reason"
        } else {
            status.reason_gpu.trim()
        };
        return (
            "warn",
            format!(
                "GPU requested, but native FEM GPU is unavailable: {} · visible CUDA devices: {}",
                reason, status.visible_cuda_device_count
            ),
        );
    }

    if status.memory_total_bytes == 0 {
        return (
            "warn",
            format!(
                "GPU requested and native FEM GPU is available on CUDA device {}, but VRAM could not be sampled · Est. FEM memory: {:.1} GB",
                status.resolved_gpu_index, estimated_gb
            ),
        );
    }

    let free_gb = status.memory_free_bytes as f64 / 1e9;
    let total_gb = status.memory_total_bytes as f64 / 1e9;
    if status.memory_free_bytes < estimated_memory_bytes {
        (
            "warn",
            format!(
                "GPU VRAM warning: Est. FEM memory {:.1} GB exceeds {:.1} GB free on CUDA device {} ({:.1} GB total)",
                estimated_gb, free_gb, status.resolved_gpu_index, total_gb
            ),
        )
    } else {
        (
            "info",
            format!(
                "GPU VRAM: {:.1} GB / {:.1} GB free on CUDA device {} · Est. FEM memory: {:.1} GB",
                free_gb, total_gb, status.resolved_gpu_index, estimated_gb
            ),
        )
    }
}

fn log_fem_gpu_memory_preflight(
    live_workspace: &LocalLiveWorkspace,
    problem: &ProblemIR,
    runtime: &SessionRuntimeSelection,
    estimated_memory_bytes: u64,
) {
    if !fem_gpu_execution_requested(problem, runtime) {
        return;
    }
    let gpu_status = fullmag_runner::native_fem_gpu_status();
    let (level, message) = fem_gpu_memory_preflight_message(estimated_memory_bytes, &gpu_status);
    live_workspace.push_log(level, &message);
    eprintln!("[fullmag] {}", message);
}

#[derive(Debug, Clone, Copy)]
enum TorqueDisplayMode {
    /// `max_dm_dt` is already a torque-like metric (direct minimizers).
    DirectTorque,
    /// `max_dm_dt` is LLG RHS amplitude |dm/dt| and needs conversion.
    FromDmdt {
        gyromagnetic_ratio: f64,
        damping: f64,
        pure_damping_rhs: bool,
    },
}

fn torque_display_mode(problem: &ProblemIR) -> Option<TorqueDisplayMode> {
    if let StudyIR::Relaxation { algorithm, .. } = &problem.study {
        match algorithm {
            RelaxationAlgorithmIR::ProjectedGradientBb | RelaxationAlgorithmIR::NonlinearCg => {
                return Some(TorqueDisplayMode::DirectTorque);
            }
            RelaxationAlgorithmIR::LlgOverdamped => {}
            RelaxationAlgorithmIR::TangentPlaneImplicit => return None,
        }
    }

    let (gyromagnetic_ratio, pure_damping_rhs) = match &problem.study {
        StudyIR::TimeEvolution { dynamics, .. } => (
            match dynamics {
                DynamicsIR::Llg {
                    gyromagnetic_ratio, ..
                } => *gyromagnetic_ratio,
            },
            false,
        ),
        StudyIR::Relaxation {
            dynamics,
            algorithm,
            ..
        } => (
            match dynamics.as_ref()? {
                DynamicsIR::Llg {
                    gyromagnetic_ratio, ..
                } => *gyromagnetic_ratio,
            },
            *algorithm == RelaxationAlgorithmIR::LlgOverdamped,
        ),
        StudyIR::Eigenmodes { .. } => return None,
        StudyIR::FrequencyResponse { .. } => return None,
        StudyIR::Hysteresis { .. } | StudyIR::FieldOnly { .. } | StudyIR::AntennaFieldSolve { .. } => return None,
    };
    let damping = problem.materials.first()?.damping;
    Some(TorqueDisplayMode::FromDmdt {
        gyromagnetic_ratio,
        damping,
        pure_damping_rhs,
    })
}

fn estimate_max_torque_from_step(max_dm_dt: f64, mode: Option<TorqueDisplayMode>) -> Option<f64> {
    let mode = mode?;
    match mode {
        TorqueDisplayMode::DirectTorque => Some(max_dm_dt),
        TorqueDisplayMode::FromDmdt {
            gyromagnetic_ratio,
            damping,
            pure_damping_rhs,
        } => {
            if gyromagnetic_ratio <= 0.0 {
                return None;
            }
            if pure_damping_rhs {
                if damping <= 0.0 {
                    return None;
                }
                return Some(
                    max_dm_dt * (1.0 + damping * damping) / (gyromagnetic_ratio * damping),
                );
            }
            Some(max_dm_dt * (1.0 + damping * damping).sqrt() / gyromagnetic_ratio)
        }
    }
}

const LIVE_PROGRESS_PUBLISH_INTERVAL: Duration = Duration::from_secs(5);
const TERMINAL_PROGRESS_LOG_INTERVAL: Duration = Duration::from_secs(5);
const STAGE_HEARTBEAT_LOG_PREFIX: &str = "[heartbeat] ";

#[derive(Debug, Clone)]
struct LiveProgressCadence {
    last_publish_at: Option<Instant>,
    last_log_at: Option<Instant>,
    publish_interval: Duration,
    log_interval: Duration,
}

impl Default for LiveProgressCadence {
    fn default() -> Self {
        Self {
            last_publish_at: None,
            last_log_at: None,
            publish_interval: LIVE_PROGRESS_PUBLISH_INTERVAL,
            log_interval: TERMINAL_PROGRESS_LOG_INTERVAL,
        }
    }
}

impl LiveProgressCadence {
    fn should_publish(&mut self, update: &fullmag_runner::StepUpdate) -> bool {
        if update.stats.step <= 1
            || update.finished
            || has_heavy_live_payload(update)
            || step_update_has_parallel_execution_progress(update)
            || step_update_has_frequency_response_progress(update)
        {
            self.last_publish_at = Some(Instant::now());
            return true;
        }
        let should_publish = self
            .last_publish_at
            .is_none_or(|last_publish_at| last_publish_at.elapsed() >= self.publish_interval);
        if should_publish {
            self.last_publish_at = Some(Instant::now());
        }
        should_publish
    }

    fn should_log(&mut self, update: &fullmag_runner::StepUpdate) -> bool {
        // Always log step 1 (simulation started) and the final step.
        // All other steps go through the time gate so fast GPU runs don't flood
        // the terminal with milestone-based lines.
        if update.finished
            || update.stats.step <= 1
            || step_update_has_frequency_response_progress(update)
        {
            self.last_log_at = Some(Instant::now());
            return true;
        }
        let should_log = self
            .last_log_at
            .is_none_or(|last_log_at| last_log_at.elapsed() >= self.log_interval);
        if should_log {
            self.last_log_at = Some(Instant::now());
        }
        should_log
    }
}

fn has_heavy_live_payload(update: &fullmag_runner::StepUpdate) -> bool {
    let flags = crate::live_workspace::feature_flags();
    let live_magnetization_disabled = flags.disable_live_magnetization && !update.finished;
    let previews_disabled = flags.disable_preview_2d && flags.disable_preview_3d;
    (!live_magnetization_disabled && update.magnetization.is_some())
        || (!previews_disabled && update.preview_field.is_some())
        || (!previews_disabled
            && update
                .cached_preview_fields
                .as_ref()
                .is_some_and(|fields| !fields.is_empty()))
}

fn fem_eigen_progress_metrics(
    stats: &fullmag_runner::StepStats,
) -> Option<&std::collections::HashMap<String, f64>> {
    if stats.validate_record_kind().is_err() || !stats.kind.is_solver_progress() {
        return None;
    }
    match stats.solver_progress.as_ref()? {
        fullmag_quantities::SolverProgress::FemEigen { metrics } => Some(metrics),
    }
}

fn step_update_has_frequency_response_progress(update: &fullmag_runner::StepUpdate) -> bool {
    update
        .stats
        .per_object_scalars
        .get(FEM_FREQUENCY_RESPONSE_PROGRESS_KEY)
        .is_some_and(|progress| {
            progress
                .get("total_frequency_count")
                .is_some_and(|value| value.is_finite() && *value > 0.0)
        })
}

fn step_update_has_parallel_execution_progress(update: &fullmag_runner::StepUpdate) -> bool {
    fem_eigen_progress_metrics(&update.stats)
        .is_some_and(|metrics| metrics.get("parallel_telemetry_available") == Some(&1.0))
}

fn publish_live_step_update(
    live_workspace: &LocalLiveWorkspace,
    run_id: &str,
    session_id: &str,
    artifact_dir: &Path,
    update: fullmag_runner::StepUpdate,
    include_scalar_row: bool,
) -> fullmag_runner::StepUpdate {
    let mut remainder = None;
    let timings = live_workspace.update_profiled(|state| {
        remainder = Some(apply_live_step_update_to_workspace_state(
            state,
            run_id,
            session_id,
            artifact_dir,
            update,
            include_scalar_row,
        ));
    });
    let mut update = remainder.expect("live step update should be consumed under workspace lock");
    update.stats.live_state_build_wall_time_ns = update
        .stats
        .live_state_build_wall_time_ns
        .saturating_add(timings.live_state_build_wall_time_ns);
    update.stats.publisher_replace_wall_time_ns = update
        .stats
        .publisher_replace_wall_time_ns
        .saturating_add(timings.publisher_replace_wall_time_ns);
    update
}

fn solver_profile_config_from_command(
    command: &SessionCommand,
) -> Result<fullmag_runner::SolverProfileConfig> {
    let value = command
        .profile
        .clone()
        .ok_or_else(|| anyhow!("set_solver_profile command is missing profile payload"))?;
    serde_json::from_value::<fullmag_runner::SolverProfileConfig>(value)
        .context("failed to decode set_solver_profile payload")
        .map(fullmag_runner::SolverProfileConfig::normalized)
}

fn apply_solver_profile_command(live_workspace: &LocalLiveWorkspace, command: &SessionCommand) {
    match solver_profile_config_from_command(command) {
        Ok(config) => live_workspace.set_solver_profile_config(config),
        Err(error) => live_workspace.push_log(
            "error",
            format!("Solver profiler command rejected: {}", error),
        ),
    }
}

fn drain_solver_profile_commands(
    control: &CurrentLiveDisplaySelectionHandle,
    live_workspace: &LocalLiveWorkspace,
) {
    while let Some(command) = control.take_solver_profile_command() {
        apply_solver_profile_command(live_workspace, &command);
    }
}

#[derive(Clone, Copy)]
struct SolverProfileCallbackRecord {
    step: u64,
    recorded_callback_wall_time_ns: u64,
    callback_thread_cpu_started_ns: Option<u64>,
    recorded_callback_thread_cpu_time_ns: u64,
    sampled: bool,
    record_start: Instant,
}

fn begin_solver_profile_step_with_orchestration(
    live_workspace: &LocalLiveWorkspace,
    stats: &mut fullmag_runner::StepStats,
    callback_start: Option<Instant>,
) -> Option<SolverProfileCallbackRecord> {
    let Some(callback_start) = callback_start else {
        return None;
    };
    let orchestration_wall_time_ns = callback_start.elapsed().as_nanos() as u64;
    stats.orchestration_wall_time_ns = orchestration_wall_time_ns;
    let callback_thread_cpu_started_ns = stats.preview_callback_thread_cpu_started_ns;
    let callback_thread_cpu_time_ns =
        fullmag_runner::elapsed_current_thread_cpu_ns(callback_thread_cpu_started_ns);
    stats.preview_callback_thread_cpu_time_ns = callback_thread_cpu_time_ns;
    stats.wall_time_ns = stats
        .wall_time_ns
        .saturating_add(orchestration_wall_time_ns);
    let record_start = Instant::now();
    let sampled = live_workspace.record_solver_profile_step(stats);
    if sampled {
        // Allocate the trace identity only after the sampling gate accepted
        // this step.  The later callback finalization/publisher path can then
        // enrich the same bounded sample without adding profiler-off work.
        let _ = live_workspace.attach_solver_profile_trace(stats.step);
    }
    Some(SolverProfileCallbackRecord {
        step: stats.step,
        recorded_callback_wall_time_ns: orchestration_wall_time_ns,
        callback_thread_cpu_started_ns,
        recorded_callback_thread_cpu_time_ns: callback_thread_cpu_time_ns,
        sampled,
        record_start,
    })
}

fn finish_solver_profile_step_with_orchestration(
    live_workspace: &LocalLiveWorkspace,
    callback_start: Option<Instant>,
    record: Option<SolverProfileCallbackRecord>,
) {
    let (Some(callback_start), Some(record)) = (callback_start, record) else {
        return;
    };
    let callback_wall_time_ns = saturating_nanos_u64(callback_start.elapsed());
    let callback_thread_cpu_time_ns =
        fullmag_runner::elapsed_current_thread_cpu_ns(record.callback_thread_cpu_started_ns);
    if record.sampled {
        let _ = live_workspace.attach_solver_profile_trace_segment(
            record.step,
            fullmag_runner::SolverTraceSegment::new(
                fullmag_runner::SolverTraceSegmentKind::NativeToRunnerCallback,
                record.recorded_callback_wall_time_ns,
            ),
        );
    }
    live_workspace.finish_solver_profile_callback(
        record.step,
        record.recorded_callback_wall_time_ns,
        callback_wall_time_ns,
        record.recorded_callback_thread_cpu_time_ns,
        callback_thread_cpu_time_ns,
        record.sampled,
        record.record_start,
    );
}

fn solver_profile_callback_start(live_workspace: &LocalLiveWorkspace) -> Option<Instant> {
    live_workspace.solver_profile_enabled().then(Instant::now)
}

fn force_record_solver_profile_finalization(
    live_workspace: &LocalLiveWorkspace,
    result: &fullmag_runner::RunResult,
    step_offset: u64,
    time_offset: f64,
) {
    let Some(last) = result.steps.last() else {
        return;
    };
    if last.finalization_wall_time_ns == 0
        && last.finalization_field_copy_wall_time_ns == 0
        && last.finalization_field_copy_bytes == 0
    {
        return;
    }
    let adjusted = offset_step_stats(std::slice::from_ref(last), step_offset, time_offset)
        .into_iter()
        .next()
        .expect("single finalization step should offset");
    live_workspace.force_record_solver_profile_step(&adjusted);
}

fn apply_live_step_update_to_workspace_state(
    state: &mut LocalLiveWorkspaceState,
    run_id: &str,
    session_id: &str,
    artifact_dir: &Path,
    mut update: fullmag_runner::StepUpdate,
    include_scalar_row: bool,
) -> fullmag_runner::StepUpdate {
    preserve_frequency_response_progress_scalars_from_live_state(state, &mut update);
    state.session.status = if update.finished {
        "completed".to_string()
    } else {
        "running".to_string()
    };
    state.run = running_run_manifest_from_update(run_id, session_id, artifact_dir, &update);
    let disable_live_magnetization = crate::live_workspace::feature_flags()
        .disable_live_magnetization
        && !update.finished;
    let previous_step_is_physical = state.live_state.latest_step.is_physical_observation();
    let previous_magnetization = state.live_state.latest_step.magnetization.take();
    let previous_fem_mesh_generation_id =
        state.live_state.latest_step.fem_mesh_generation_id.take();
    let incoming_has_magnetization = ingest_magnetization_field_from_update(state, &mut update);
    let incoming_has_magnetization_preview = step_update_has_magnetization_preview(&update);
    crate::live_workspace::ingest_preview_fields_from_update(state, &mut update);
    apply_hysteresis_progress_to_stage_execution(state, &update);
    apply_fem_eigen_progress_to_stage_execution(state, &update);
    apply_fem_frequency_response_progress_to_stage_execution(state, &update);
    if include_scalar_row {
        set_latest_scalar_row_if_due(state, &update);
    }
    let remainder = fullmag_runner::StepUpdate {
        stats: update.stats.clone(),
        coupled_checkpoint: update.coupled_checkpoint.clone(),
        grid: update.grid,
        fem_mesh_generation_id: update.fem_mesh_generation_id.clone(),
        magnetization: None,
        preview_field: None,
        cached_preview_fields: None,
        hysteresis_field_m_t: update.hysteresis_field_m_t,
        hysteresis_point_index: update.hysteresis_point_index,
        hysteresis_settle_step_index: update.hysteresis_settle_step_index,
        hysteresis_settle_step_kind: update.hysteresis_settle_step_kind.clone(),
        hysteresis_settle_step_method: update.hysteresis_settle_step_method.clone(),
        scalar_row_due: update.scalar_row_due,
        terminal_field_snapshot: update.terminal_field_snapshot,
        finished: update.finished,
        magnetization_carrier: None,
    };
    state.live_state = live_state_manifest_from_update(update);
    if disable_live_magnetization {
        // Large-grid runs do not need a full m vector in every control-plane
        // frame. Keep the authoritative saved states and terminal artifacts,
        // but remove the expensive live carrier after bootstrap.
        state.latest_fields.0.remove("m");
    }
    if previous_step_is_physical
        && state.live_state.latest_step.is_physical_observation()
        && state.live_state.latest_step.magnetization.is_none()
        && !incoming_has_magnetization
        && !incoming_has_magnetization_preview
        && !disable_live_magnetization
    {
        state.live_state.latest_step.magnetization = previous_magnetization;
    }
    if state
        .live_state
        .latest_step
        .fem_mesh_generation_id
        .is_none()
    {
        state.live_state.latest_step.fem_mesh_generation_id = previous_fem_mesh_generation_id;
    }
    remainder
}

fn apply_terminal_live_step_update_to_workspace_state(
    state: &mut LocalLiveWorkspaceState,
    run_id: &str,
    session_id: &str,
    artifact_dir: &Path,
    update: fullmag_runner::StepUpdate,
) -> fullmag_runner::StepUpdate {
    let remainder = apply_live_step_update_to_workspace_state(
        state,
        run_id,
        session_id,
        artifact_dir,
        update,
        false,
    );
    set_latest_scalar_row_for_terminal_update(state, &remainder);
    remainder
}

fn ingest_magnetization_field_from_update(
    state: &mut LocalLiveWorkspaceState,
    update: &mut fullmag_runner::StepUpdate,
) -> bool {
    if crate::live_workspace::feature_flags().disable_live_magnetization && !update.finished {
        update.magnetization = None;
        return false;
    }
    if !update.stats.is_physical_observation() {
        return false;
    }
    let Some(values) = update.magnetization.take() else {
        return false;
    };
    let source_step = update
        .stats
        .magnetization_source_step
        .unwrap_or(update.stats.step);
    let source_revision = update
        .stats
        .magnetization_source_revision
        .unwrap_or(source_step);
    let materialized_at_unix_ms = update
        .stats
        .magnetization_materialized_at_unix_ms
        .unwrap_or_else(current_unix_millis_u64);
    let materialization_wall_time_ns = update
        .stats
        .magnetization_materialization_wall_time_ns
        .unwrap_or(update.stats.field_copy_wall_time_ns);
    state.latest_fields.insert(
        "m".to_string(),
        serde_json::json!({
            "quantity": "m",
            "unit": "1",
            "values": values,
            "source_step": source_step,
            "source_revision": source_revision,
            "materialized_at_unix_ms": materialized_at_unix_ms,
            "materialization_wall_time_ns": materialization_wall_time_ns,
            "layout": {
                "grid_cells": update.grid,
                "spatial_kind": "mesh",
                "quantity_domain": "magnetic_only",
            }
        }),
    );
    true
}

fn preserve_frequency_response_progress_scalars_from_live_state(
    state: &LocalLiveWorkspaceState,
    update: &mut fullmag_runner::StepUpdate,
) {
    if !update.stats.is_physical_observation() {
        return;
    }
    if update
        .stats
        .per_object_scalars
        .contains_key(FEM_FREQUENCY_RESPONSE_PROGRESS_KEY)
    {
        return;
    }
    if !active_stage_kind_is_frequency_response(state) {
        return;
    }
    let Some(previous) = state
        .live_state
        .latest_step
        .per_object_scalars
        .get(FEM_FREQUENCY_RESPONSE_PROGRESS_KEY)
        .cloned()
    else {
        return;
    };
    update
        .stats
        .per_object_scalars
        .insert(FEM_FREQUENCY_RESPONSE_PROGRESS_KEY.to_string(), previous);
}

fn active_stage_kind_is_frequency_response(state: &LocalLiveWorkspaceState) -> bool {
    state
        .stage_execution
        .as_ref()
        .and_then(|stage_execution| stage_execution.active_stage_kind.as_deref())
        .is_some_and(is_frequency_response_stage_kind)
}

fn is_frequency_response_stage_kind(kind: &str) -> bool {
    matches!(kind, "frequency_response" | "flat_frequency_response")
}

fn apply_fem_frequency_response_progress_to_stage_execution(
    state: &mut LocalLiveWorkspaceState,
    update: &fullmag_runner::StepUpdate,
) {
    if !update.stats.is_physical_observation() {
        return;
    }
    let Some(progress) = update
        .stats
        .per_object_scalars
        .get(FEM_FREQUENCY_RESPONSE_PROGRESS_KEY)
    else {
        return;
    };
    let Some(stage_execution) = state.stage_execution.as_mut() else {
        return;
    };
    let Some(active_index) = stage_execution.active_stage_index else {
        return;
    };
    let Some(stage) = stage_execution.stages.get_mut(active_index) else {
        return;
    };

    let percent = progress
        .get("percent")
        .copied()
        .filter(|value| value.is_finite())
        .map(|value| value.clamp(0.0, 100.0));
    if let Some(percent) = percent {
        stage.progress_percent = Some(percent);
    }
    stage.progress_label = Some("solving frequency point".to_string());
    stage.progress_detail = Some(fem_frequency_response_progress_detail(progress));
    stage.last_progress_unix_ms = Some(current_unix_millis_u64());
}

fn fem_frequency_response_progress_detail(
    progress: &std::collections::HashMap<String, f64>,
) -> String {
    let completed = progress
        .get("completed_frequency_count")
        .copied()
        .unwrap_or(0.0) as u64;
    let total = progress
        .get("total_frequency_count")
        .copied()
        .unwrap_or(0.0) as u64;
    let current = progress
        .get("frequency_index")
        .copied()
        .map(|index| index.max(0.0) as u64 + 1)
        .unwrap_or(completed)
        .min(total.max(1));
    let frequency_hz = progress.get("frequency_hz").copied().unwrap_or(0.0);
    let mut detail = String::new();
    if let Some(demag) = fem_frequency_response_demag_mode(progress) {
        detail.push_str("demag=");
        detail.push_str(demag);
        detail.push_str("; ");
    }
    if let Some((min_hz, max_hz)) = fem_frequency_response_range_hz(progress) {
        detail.push_str(&format!(
            "range={:.6}-{:.6} GHz; ",
            min_hz / 1.0e9,
            max_hz / 1.0e9
        ));
    }
    detail.push_str(&format!(
        "frequency point {current}/{total}; completed={completed}; f={:.6} GHz",
        frequency_hz / 1.0e9
    ));
    if let Some(iteration) = progress.get("iteration").copied() {
        if let Some(max_iterations) = progress.get("max_iterations_for_frequency").copied() {
            detail.push_str(&format!(
                "; GMRES iteration={}/{}",
                iteration as u64, max_iterations as u64
            ));
        } else {
            detail.push_str(&format!("; GMRES iteration={}", iteration as u64));
        }
    }
    if let Some(solve_fraction) = progress.get("current_frequency_solve_fraction").copied() {
        if solve_fraction.is_finite() {
            detail.push_str(&format!(
                "; current frequency solve={:.0}%",
                solve_fraction.clamp(0.0, 1.0) * 100.0
            ));
        }
    }
    if let Some(residual) = progress.get("relative_residual_l2_norm").copied() {
        detail.push_str(&format!("; relative residual={residual:.3e}"));
    }
    if progress.get("converged").is_some_and(|value| *value > 0.0) {
        detail.push_str("; converged=true");
    }
    detail
}

fn fem_frequency_response_demag_mode(
    progress: &std::collections::HashMap<String, f64>,
) -> Option<&'static str> {
    if progress
        .get("demag_periodic_airbox_k0")
        .is_some_and(|value| *value > 0.0)
    {
        Some("periodic_airbox_k0")
    } else if progress
        .get("demag_floquet_airbox")
        .is_some_and(|value| *value > 0.0)
    {
        Some("floquet_airbox")
    } else if progress
        .get("demag_enabled")
        .is_some_and(|value| *value > 0.0)
    {
        Some("enabled")
    } else {
        None
    }
}

fn fem_frequency_response_range_hz(
    progress: &std::collections::HashMap<String, f64>,
) -> Option<(f64, f64)> {
    let min_hz = progress.get("frequency_min_hz").copied()?;
    let max_hz = progress.get("frequency_max_hz").copied()?;
    if min_hz.is_finite() && max_hz.is_finite() && min_hz > 0.0 && max_hz >= min_hz {
        Some((min_hz, max_hz))
    } else {
        None
    }
}

fn apply_fem_eigen_progress_to_stage_execution(
    state: &mut LocalLiveWorkspaceState,
    update: &fullmag_runner::StepUpdate,
) {
    let Some(progress) = fem_eigen_progress_metrics(&update.stats) else {
        return;
    };
    let Some(stage_execution) = state.stage_execution.as_mut() else {
        return;
    };
    let Some(active_index) = stage_execution.active_stage_index else {
        return;
    };
    let Some(stage) = stage_execution.stages.get_mut(active_index) else {
        return;
    };

    let phase = fem_eigen_progress_phase(progress);
    let solver = fem_eigen_progress_solver(progress);
    let percent = progress
        .get("percent")
        .copied()
        .filter(|value| value.is_finite())
        .map(|value| value.clamp(0.0, 100.0));
    if let Some(percent) = percent {
        stage.progress_percent = Some(percent);
    }
    stage.progress_label = Some(phase.to_string());
    stage.progress_detail = Some(fem_eigen_progress_detail(progress, phase, solver));
    if progress.get("parallel_telemetry_available") == Some(&1.0) {
        stage.parallel_execution = parallel_execution_telemetry_from_progress(progress);
    }
    stage.last_progress_unix_ms = Some(current_unix_millis_u64());
}

fn parallel_execution_telemetry_from_progress(
    progress: &std::collections::HashMap<String, f64>,
) -> Option<fullmag_runner::LiveParallelExecutionTelemetry> {
    if progress.get("parallel_telemetry_available") != Some(&1.0) {
        return None;
    }

    fn scalar_u32(value: Option<&f64>) -> Option<u32> {
        let value = value.copied()?;
        (value.is_finite() && value >= 0.0 && value.fract() == 0.0 && value <= u32::MAX as f64)
            .then_some(value as u32)
    }

    fn scalar_u64_pair(
        progress: &std::collections::HashMap<String, f64>,
        key: &str,
    ) -> Option<u64> {
        let low = scalar_u32(progress.get(&format!("{key}_lo")))?;
        let high = scalar_u32(progress.get(&format!("{key}_hi")))?;
        Some((u64::from(high) << 32) | u64::from(low))
    }

    fn optional_u32(
        progress: &std::collections::HashMap<String, f64>,
        key: &str,
    ) -> Option<Option<u32>> {
        match progress.get(key) {
            None => Some(None),
            Some(value) => scalar_u32(Some(value)).map(Some),
        }
    }

    fn optional_f64(
        progress: &std::collections::HashMap<String, f64>,
        key: &str,
    ) -> Option<Option<f64>> {
        match progress.get(key) {
            None => Some(None),
            Some(value) if value.is_finite() => Some(Some(*value)),
            Some(_) => None,
        }
    }

    fn optional_u64_pair(
        progress: &std::collections::HashMap<String, f64>,
        key: &str,
    ) -> Option<Option<u64>> {
        let has_low = progress.contains_key(&format!("{key}_lo"));
        let has_high = progress.contains_key(&format!("{key}_hi"));
        match (has_low, has_high) {
            (false, false) => Some(None),
            (true, true) => scalar_u64_pair(progress, key).map(Some),
            _ => None,
        }
    }

    fn tagged(progress: &std::collections::HashMap<String, f64>, prefix: &str) -> Option<String> {
        let mut values = progress.iter().filter_map(|(key, value)| {
            (key.starts_with(prefix) && *value == 1.0).then(|| key[prefix.len()..].to_string())
        });
        let value = values.next().filter(|value| !value.is_empty())?;
        values.next().is_none().then_some(value)
    }

    let sampled_at_unix_ms = scalar_u64_pair(progress, "parallel_sampled_at_unix_ms")?;
    let active_workers = scalar_u32(progress.get("parallel_active_workers"))?;
    let admission_desired_workers = scalar_u32(progress.get("parallel_admission_desired_workers"))?;
    let admission_pending_samples = scalar_u32(progress.get("parallel_admission_pending_samples"))?;
    let cpu_target_percent = progress.get("parallel_cpu_target_percent").copied()?;
    let memory_target_percent = progress.get("parallel_memory_target_percent").copied()?;
    if !cpu_target_percent.is_finite()
        || !memory_target_percent.is_finite()
        || cpu_target_percent <= 0.0
        || memory_target_percent <= 0.0
    {
        return None;
    }
    let memory_reserve_bytes = scalar_u64_pair(progress, "parallel_memory_reserve_bytes")?;
    Some(fullmag_runner::LiveParallelExecutionTelemetry {
        sampled_at_unix_ms,
        active_workers,
        admission_desired_workers,
        admission_worker_limit: optional_u32(progress, "parallel_admission_worker_limit")?,
        admission_pending_samples,
        resolved_workers: optional_u32(progress, "parallel_resolved_workers")?,
        cpu_target_percent,
        memory_target_percent,
        memory_reserve_bytes,
        cpu_target_kind: tagged(progress, "parallel_cpu_target_kind:")?,
        cpu_busy_percent: optional_f64(progress, "parallel_cpu_busy_percent")?,
        allocated_cpu_cores: optional_f64(progress, "parallel_allocated_cpu_cores")?,
        cpu_available_cores: optional_f64(progress, "parallel_cpu_available_cores")?,
        memory_limit_bytes: optional_u64_pair(progress, "parallel_memory_limit_bytes")?,
        memory_available_bytes: optional_u64_pair(progress, "parallel_memory_available_bytes")?,
        worker_peak_cpu_cores: optional_f64(progress, "parallel_worker_peak_cpu_cores")?,
        worker_peak_rss_bytes: optional_u64_pair(progress, "parallel_worker_peak_rss_bytes")?,
        admission_reason: tagged(progress, "parallel_admission_reason:")?,
        terminal: progress.get("parallel_telemetry_terminal") == Some(&1.0),
    })
}

fn fem_eigen_progress_solver(progress: &std::collections::HashMap<String, f64>) -> &str {
    let mut kinds = progress.iter().filter_map(|(key, value)| {
        key.strip_prefix("solver_kind:")
            .filter(|kind| !kind.is_empty() && *value == 1.0)
    });
    if let Some(kind) = kinds.next() {
        return if kinds.next().is_none() {
            kind
        } else {
            "unknown"
        };
    }
    // Older producers explicitly exposed only LOBPCG. Absence of that flag
    // cannot prove a dense solver, a device lane, or an execution algorithm.
    if progress.get("solver_cpu_sparse_lobpcg") == Some(&1.0) {
        "cpu_sparse_lobpcg"
    } else {
        "unknown"
    }
}

fn fem_eigen_progress_phase(progress: &std::collections::HashMap<String, f64>) -> &'static str {
    if progress.get("window_phase_base") == Some(&1.0) {
        return "solving native frequency window base";
    }
    if progress.get("window_phase_refinement") == Some(&1.0) {
        return "solving native frequency window refinement";
    }
    if progress.get("phase_kind:solving_native_shift_invert") == Some(&1.0) {
        return "solving native shift-invert";
    }
    if progress.get("phase_kind:solving_native_contour_interval") == Some(&1.0) {
        return "solving native contour interval";
    }
    if progress
        .get("phase_materializing_equilibrium")
        .is_some_and(|value| *value > 0.0)
    {
        "materializing equilibrium"
    } else if progress
        .get("phase_assembling_operator")
        .is_some_and(|value| *value > 0.0)
    {
        "assembling eigen operator"
    } else if progress
        .get("phase_solving_sparse_lobpcg")
        .is_some_and(|value| *value > 0.0)
    {
        "solving sparse LOBPCG"
    } else if progress
        .get("phase_solving_dense")
        .is_some_and(|value| *value > 0.0)
    {
        "solving dense eigenproblem"
    } else if progress
        .get("phase_writing_artifacts")
        .is_some_and(|value| *value > 0.0)
    {
        "writing eigen artifacts"
    } else if progress
        .get("phase_completed")
        .is_some_and(|value| *value > 0.0)
    {
        "completed"
    } else {
        "solving"
    }
}

fn fem_eigen_progress_is_ksp_norm(
    progress: &std::collections::HashMap<String, f64>,
) -> bool {
    progress.get("residual_source:ksp_norm") == Some(&1.0)
}

fn fem_eigen_progress_counter(
    progress: &std::collections::HashMap<String, f64>,
    key: &str,
) -> Option<u64> {
    let value = progress.get(key).copied()?;
    (value.is_finite()
        && value >= 0.0
        && value.fract() == 0.0
        && value < u64::MAX as f64)
        .then_some(value as u64)
}

fn fem_eigen_progress_tagged_value<'a>(
    progress: &std::collections::HashMap<String, f64>,
    prefix: &str,
    allowed: &'a [&'a str],
) -> Option<&'a str> {
    let mut matches = allowed.iter().copied().filter(|value| {
        let key = format!("{prefix}{value}");
        progress
            .get(&key)
            .is_some_and(|flag| flag.is_finite() && *flag == 1.0)
    });
    let value = matches.next()?;
    matches.next().is_none().then_some(value)
}

fn fem_eigen_linear_progress_detail(
    progress: &std::collections::HashMap<String, f64>,
) -> Option<String> {
    if !fem_eigen_progress_is_ksp_norm(progress) {
        return None;
    }

    let mut fields = Vec::with_capacity(4);
    if let Some(iteration) = fem_eigen_progress_counter(progress, "linear_iteration") {
        fields.push(format!("linear_iteration={iteration}"));
    }
    if let Some(norm) = progress
        .get("linear_residual_norm")
        .copied()
        .filter(|value| value.is_finite() && *value >= 0.0)
    {
        fields.push(format!("ksp_norm={norm:.3e}"));
    }
    if let Some(role) =
        fem_eigen_progress_tagged_value(progress, "linear_solver_role:", &["poisson", "shift_invert"])
    {
        fields.push(format!("linear_solver_role={role}"));
    }
    if let Some(ksp_type) = fem_eigen_progress_tagged_value(
        progress,
        "linear_ksp_type:",
        &["gmres", "fgmres", "preonly"],
    ) {
        fields.push(format!("linear_ksp_type={ksp_type}"));
    }

    (!fields.is_empty()).then(|| fields.join("; "))
}

fn fem_eigen_progress_detail(
    progress: &std::collections::HashMap<String, f64>,
    phase: &str,
    solver: &str,
) -> String {
    let active_nodes = progress.get("active_nodes").copied().unwrap_or(0.0) as u64;
    let effective_dof = progress.get("effective_dof").copied().unwrap_or(0.0) as u64;
    let requested_modes = progress.get("requested_modes").copied().unwrap_or(0.0) as u64;
    let computed_modes = progress.get("computed_modes").copied().unwrap_or(0.0) as u64;
    let mut detail = format!(
        "{phase}; solver={solver}; active_nodes={active_nodes}; effective_dof={effective_dof}; requested_modes={requested_modes}; computed_modes={computed_modes}"
    );
    if let Some(iteration) = fem_eigen_progress_counter(progress, "iteration") {
        if let Some(max_iterations) = fem_eigen_progress_counter(progress, "max_iterations") {
            detail.push_str(&format!("; iteration={iteration}/{max_iterations}"));
        } else {
            detail.push_str(&format!("; iteration={iteration}"));
        }
    }
    if !fem_eigen_progress_is_ksp_norm(progress) {
        if let Some(residual) = progress.get("residual").copied() {
            detail.push_str(&format!("; residual={residual:.3e}"));
        }
    }
    if let Some(linear_progress) = fem_eigen_linear_progress_detail(progress) {
        detail.push_str(&format!("; {linear_progress}"));
    }
    let window_phase = if progress
        .get("window_phase_base")
        .is_some_and(|value| *value > 0.0)
    {
        Some("base")
    } else if progress
        .get("window_phase_refinement")
        .is_some_and(|value| *value > 0.0)
    {
        Some("refinement")
    } else {
        None
    };
    if let Some(window_phase) = window_phase {
        detail.push_str(&format!("; window_phase={window_phase}"));
    }
    if let (Some(current), Some(total)) = (
        fem_eigen_progress_counter(progress, "current_subwindow"),
        fem_eigen_progress_counter(progress, "total_subwindows"),
    ) {
        detail.push_str(&format!("; subwindow={current}/{total}"));
    }
    if let Some(seconds) = progress.get("subwindow_elapsed_seconds").copied() {
        if seconds.is_finite() {
            detail.push_str(&format!("; subwindow_s={seconds:.1}"));
        }
    }
    if let Some(seconds) = progress.get("window_elapsed_seconds").copied() {
        if seconds.is_finite() {
            detail.push_str(&format!("; window_s={seconds:.1}"));
        }
    }
    if progress
        .get("warning_dense_o_n3")
        .is_some_and(|value| *value > 0.0)
    {
        detail.push_str("; warning=dense O(n^3) path has no internal iteration telemetry");
    }
    detail
}

fn apply_hysteresis_progress_to_stage_execution(
    state: &mut LocalLiveWorkspaceState,
    update: &fullmag_runner::StepUpdate,
) {
    if update.hysteresis_field_m_t.is_none()
        && update.hysteresis_point_index.is_none()
        && update.hysteresis_settle_step_index.is_none()
        && update.hysteresis_settle_step_kind.is_none()
        && update.hysteresis_settle_step_method.is_none()
    {
        return;
    }
    let Some(stage_execution) = state.stage_execution.as_mut() else {
        return;
    };
    let Some(active_index) = stage_execution.active_stage_index else {
        return;
    };
    let Some(stage) = stage_execution.stages.get_mut(active_index) else {
        return;
    };
    stage.current_field_m_t = update.hysteresis_field_m_t;
    stage.current_point_index = update.hysteresis_point_index;
    stage.current_settle_step_index = update.hysteresis_settle_step_index;
    stage.current_settle_step_kind = update.hysteresis_settle_step_kind.clone();
    stage.current_settle_step_method = update.hysteresis_settle_step_method.clone();
}

fn step_update_has_magnetization_preview(update: &fullmag_runner::StepUpdate) -> bool {
    update
        .preview_field
        .as_ref()
        .is_some_and(|field| field.quantity == "m")
        || update
            .cached_preview_fields
            .as_ref()
            .is_some_and(|fields| fields.iter().any(|field| field.quantity == "m"))
}

fn saturating_nanos_u64(duration: Duration) -> u64 {
    duration.as_nanos().min(u128::from(u64::MAX)) as u64
}

fn current_unix_millis_u64() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis()
        .min(u128::from(u64::MAX)) as u64
}

fn stage_progress_detail_is_heartbeat(detail: &str) -> bool {
    detail.starts_with("heartbeat ")
}

fn stage_has_solver_progress_detail(stage: &CurrentLiveStageExecutionRecord) -> bool {
    stage
        .progress_detail
        .as_deref()
        .is_some_and(|detail| !stage_progress_detail_is_heartbeat(detail))
}

fn apply_stage_heartbeat_progress(stage: &mut CurrentLiveStageExecutionRecord, idle_for: Duration) {
    if stage_has_solver_progress_detail(stage) {
        return;
    }
    stage.progress_percent = stage
        .progress_percent
        .map(|value| value.max(35.0))
        .or(Some(35.0));
    stage.progress_label = Some("solving".to_string());
    stage.progress_detail = Some(format!(
        "heartbeat {:.1}s since last solver update",
        idle_for.as_secs_f64()
    ));
    stage.last_progress_unix_ms = Some(current_unix_millis_u64());
}

fn detailed_fem_step_profile_enabled() -> bool {
    std::env::var("FULLMAG_FEM_STEP_PROFILE")
        .ok()
        .is_some_and(|raw| {
            matches!(
                raw.as_str(),
                "1" | "true" | "TRUE" | "on" | "ON" | "yes" | "YES"
            )
        })
}

fn append_detailed_fem_step_profile(line: &mut String, stats: &fullmag_runner::StepStats) {
    if !detailed_fem_step_profile_enabled() {
        return;
    }
    let exchange_ms = stats.exchange_wall_time_ns as f64 / 1e6;
    let demag_ms = stats.demag_wall_time_ns as f64 / 1e6;
    let rhs_ms = stats.rhs_wall_time_ns as f64 / 1e6;
    let extra_ms = stats.extra_energy_wall_time_ns as f64 / 1e6;
    let snapshot_ms = stats.snapshot_wall_time_ns as f64 / 1e6;
    let relax_preconditioner_ms = stats.relaxation_preconditioner_wall_time_ns as f64 / 1e6;
    let dt_next = stats.dt_suggested.unwrap_or(0.0);
    line.push_str(&format!(
        "  phases[ex={exchange_ms:.0}ms demag={demag_ms:.0}ms relax_prec={relax_preconditioner_ms:.0}ms rhs={rhs_ms:.0}ms extra={extra_ms:.0}ms snap={snapshot_ms:.0}ms]  relax_prec_cache={}/{}  rk[rhs_evals={} rejected={} fsal={}]  demag[solves={} lin_iters={} residual={:.3e}]  err={:.3e}  dt_next={:.3e}",
        stats.relaxation_preconditioner_cache_hits,
        stats.relaxation_preconditioner_cache_misses,
        stats.rhs_evals,
        stats.rejected_attempts,
        if stats.fsal_reused { 1 } else { 0 },
        stats.demag_solves,
        stats.poisson_iterations,
        stats.poisson_final_residual,
        stats.error_estimate.unwrap_or(0.0),
        dt_next,
    ));
}

fn append_fem_eigen_step_progress(line: &mut String, stats: &fullmag_runner::StepStats) {
    let Some(progress) = fem_eigen_progress_metrics(stats) else {
        return;
    };
    let window_phase = if progress
        .get("window_phase_base")
        .is_some_and(|value| *value == 1.0)
    {
        Some("base")
    } else if progress
        .get("window_phase_refinement")
        .is_some_and(|value| *value == 1.0)
    {
        Some("refinement")
    } else {
        None
    };
    let linear_progress = fem_eigen_linear_progress_detail(progress);
    if window_phase.is_none() && linear_progress.is_none() {
        return;
    }
    let mut segment = window_phase
        .map(|phase| format!("  modal window phase={phase}"))
        .unwrap_or_else(|| "  modal linear solve".to_string());
    if let (Some(current), Some(total)) = (
        fem_eigen_progress_counter(progress, "current_subwindow"),
        fem_eigen_progress_counter(progress, "total_subwindows"),
    ) {
        segment.push_str(&format!(" subwindow={current}/{total}"));
    }
    if let Some(seconds) = progress.get("subwindow_elapsed_seconds").copied() {
        if seconds.is_finite() {
            segment.push_str(&format!(" subwindow_s={seconds:.1}"));
        }
    }
    if let Some(seconds) = progress.get("window_elapsed_seconds").copied() {
        if seconds.is_finite() {
            segment.push_str(&format!(" window_s={seconds:.1}"));
        }
    }
    if let Some(linear_progress) = linear_progress {
        if !line.contains(linear_progress.as_str()) {
            segment.push_str(&format!(" {linear_progress}"));
        }
    }
    if !fem_eigen_progress_is_ksp_norm(progress) {
        if let Some(residual) = progress
            .get("residual")
            .copied()
            .filter(|value| value.is_finite())
        {
            segment.push_str(&format!(" relres={residual:.3e}"));
        }
    }
    line.push_str(&segment);
}

fn frequency_response_step_progress_segment(stats: &fullmag_runner::StepStats) -> Option<String> {
    let Some(progress) = stats
        .per_object_scalars
        .get(FEM_FREQUENCY_RESPONSE_PROGRESS_KEY)
    else {
        return None;
    };
    let completed = progress
        .get("completed_frequency_count")
        .copied()
        .unwrap_or(0.0) as u64;
    let total = progress
        .get("total_frequency_count")
        .copied()
        .unwrap_or(0.0) as u64;
    let current = progress
        .get("frequency_index")
        .copied()
        .map(|index| index.max(0.0) as u64 + 1)
        .unwrap_or(completed)
        .min(total.max(1));
    let percent = progress
        .get("percent")
        .copied()
        .filter(|value| value.is_finite())
        .map(|value| value.clamp(0.0, 100.0));
    let frequency_hz = progress.get("frequency_hz").copied().unwrap_or(0.0);
    let mut segment = String::from("freq[");
    if let Some(demag) = fem_frequency_response_demag_mode(progress) {
        segment.push_str("demag=");
        segment.push_str(demag);
        segment.push(' ');
    }
    segment.push_str(&format!("solution {current}/{total}"));
    if let Some(percent) = percent {
        segment.push(' ');
        segment.push_str(&frequency_response_terminal_progress_bar(percent));
        segment.push_str(&format!(" {:.0}%", percent));
    }
    if let Some((min_hz, max_hz)) = fem_frequency_response_range_hz(progress) {
        segment.push_str(&format!(
            " range={:.6}-{:.6}GHz",
            min_hz / 1.0e9,
            max_hz / 1.0e9
        ));
    }
    segment.push_str(&format!(" f={:.6} GHz", frequency_hz / 1.0e9));
    if let Some(iteration) = progress.get("iteration").copied() {
        if let Some(max_iterations) = progress.get("max_iterations_for_frequency").copied() {
            segment.push_str(&format!(
                " GMRES={}/{}",
                iteration as u64, max_iterations as u64
            ));
        } else {
            segment.push_str(&format!(" GMRES={}", iteration as u64));
        }
    }
    if let Some(solve_fraction) = progress.get("current_frequency_solve_fraction").copied() {
        if solve_fraction.is_finite() {
            segment.push_str(&format!(
                " solve={:.0}%",
                solve_fraction.clamp(0.0, 1.0) * 100.0
            ));
        }
    }
    if let Some(residual) = progress.get("relative_residual_l2_norm").copied() {
        segment.push_str(&format!(" relres={residual:.3e}"));
    }
    segment.push(']');
    Some(segment)
}

fn append_frequency_response_step_progress(line: &mut String, stats: &fullmag_runner::StepStats) {
    if let Some(segment) = frequency_response_step_progress_segment(stats) {
        line.push_str("  ");
        line.push_str(&segment);
    }
}

fn frequency_response_terminal_progress_bar(percent: f64) -> String {
    let clamped = percent.clamp(0.0, 100.0);
    let filled =
        ((clamped / 100.0) * FREQUENCY_RESPONSE_TERMINAL_BAR_WIDTH as f64).round() as usize;
    let filled = filled.min(FREQUENCY_RESPONSE_TERMINAL_BAR_WIDTH);
    let empty = FREQUENCY_RESPONSE_TERMINAL_BAR_WIDTH - filled;
    format!("[{}{}]", "#".repeat(filled), "-".repeat(empty))
}

fn format_average_magnetization(stats: &fullmag_runner::StepStats) -> String {
    format!(
        "m_avg=(mx={:.4e} my={:.4e} mz={:.4e})",
        stats.mx, stats.my, stats.mz
    )
}

fn format_stage_progress_line(
    prefix: &str,
    stats: &fullmag_runner::StepStats,
    torque_mode: Option<TorqueDisplayMode>,
    heartbeat_age: Option<Duration>,
    hysteresis_field_m_t: Option<f64>,
) -> String {
    let wall_ms = stats.wall_time_ns as f64 / 1e6;
    if let Some(progress) = frequency_response_step_progress_segment(stats) {
        let heartbeat = heartbeat_age
            .map(|age| format!("  heartbeat idle={:.1}s", age.as_secs_f64()))
            .unwrap_or_default();
        return format!("{prefix}  frequency sweep  {progress}{heartbeat}  [{wall_ms:.0}ms]");
    }
    if let Some(progress) = fem_eigen_progress_metrics(stats) {
        let detail = fem_eigen_progress_detail(
            progress,
            fem_eigen_progress_phase(progress),
            fem_eigen_progress_solver(progress),
        );
        let heartbeat = heartbeat_age
            .map(|age| format!("  heartbeat idle={:.1}s", age.as_secs_f64()))
            .unwrap_or_default();
        let mut line = format!("{prefix}  modal eigen  {detail}{heartbeat}  [{wall_ms:.0}ms]");
        append_fem_eigen_step_progress(&mut line, stats);
        return line;
    }
    let torque_t = if stats.max_torque_T > 0.0 {
        stats.max_torque_T
    } else {
        estimate_max_torque_from_step(stats.max_dm_dt, torque_mode).unwrap_or(0.0)
    };
    let hysteresis_field = hysteresis_field_m_t
        .map(|value| format!("  H={value:.3}mT"))
        .unwrap_or_default();
    let average_magnetization = format_average_magnetization(stats);
    if let Some(age) = heartbeat_age {
        let mut line = format!(
            "{prefix}  heartbeat  step {:>6}  t={:.4e}  dt={:.3e}  max_torque[T]={:.4e}  E_total={:.4e}  |H_eff|={:.4e}  {average_magnetization}{hysteresis_field}  idle={:.1}s  [{:.0}ms]",
            stats.step,
            stats.time,
            stats.dt,
            torque_t,
            stats.e_total,
            stats.max_h_eff,
            age.as_secs_f64(),
            wall_ms,
        );
        append_frequency_response_step_progress(&mut line, stats);
        append_detailed_fem_step_profile(&mut line, stats);
        line
    } else {
        let mut line = format!(
            "{prefix}  step {:>6}  t={:.4e}  dt={:.3e}  max_torque[T]={:.4e}  E_total={:.4e}  |H_eff|={:.4e}  {average_magnetization}{hysteresis_field}  [{:.0}ms]",
            stats.step,
            stats.time,
            stats.dt,
            torque_t,
            stats.e_total,
            stats.max_h_eff,
            wall_ms,
        );
        append_frequency_response_step_progress(&mut line, stats);
        append_detailed_fem_step_profile(&mut line, stats);
        line
    }
}

fn format_stop_reason(completion: Option<&fullmag_ir::StageCompletionIR>) -> String {
    let reason = completion
        .and_then(|c| c.reason.as_ref())
        .map(|r| match r {
            fullmag_ir::StageStopReason::Torque => "torque",
            fullmag_ir::StageStopReason::Energy => "energy",
            fullmag_ir::StageStopReason::MaxSteps => "max_steps",
            fullmag_ir::StageStopReason::MaxPseudotime => "max_pseudotime",
            fullmag_ir::StageStopReason::MaxPhysicalTime => "max_physical_time",
            fullmag_ir::StageStopReason::UserCancelled => "user_cancelled",
            fullmag_ir::StageStopReason::BackendError => "backend_error",
            fullmag_ir::StageStopReason::Gradient => "gradient",
        })
        .unwrap_or("?");
    let metric_desc = completion
        .and_then(|c| {
            c.metric_value
                .map(|v| (c.metric_name.as_deref(), v, c.threshold))
        })
        .map(|(name, value, threshold)| {
            let name = name.unwrap_or("metric");
            if let Some(thr) = threshold {
                format!("  {name}={value:.4e} (threshold={thr:.4e})")
            } else {
                format!("  {name}={value:.4e}")
            }
        })
        .unwrap_or_default();
    format!("{reason}{metric_desc}")
}

fn stage_requires_relaxed_frequency_response_equilibrium(stage: &ResolvedScriptStage) -> bool {
    matches!(
        &stage.ir.study,
        StudyIR::FrequencyResponse {
            equilibrium: fullmag_ir::EquilibriumSourceIR::RelaxedInitialState,
            ..
        }
    )
}

fn ensure_frequency_response_relaxed_continuation_is_qualified(
    stage: &ResolvedScriptStage,
    completion: Option<&fullmag_ir::StageCompletionIR>,
) -> Result<()> {
    if !stage_requires_relaxed_frequency_response_equilibrium(stage) {
        return Ok(());
    }
    let Some(completion) = completion else {
        bail!(
            "frequency-response stage '{}' requested equilibrium_source='relax', but the previous relaxation has no authoritative completion record; refusing to linearize around an unqualified state",
            stage.entrypoint_kind
        );
    };
    let coherent_equilibrium_metric = matches!(
        (completion.reason, completion.metric),
        (
            Some(fullmag_ir::StageStopReason::Torque),
            Some(fullmag_ir::StageMetricKind::MaxTorqueApm)
        ) | (
            Some(fullmag_ir::StageStopReason::Energy),
            Some(fullmag_ir::StageMetricKind::TotalEnergyPlateauRangeJ)
        )
    );
    let threshold_satisfied = matches!(
        (completion.metric_value, completion.threshold),
        (Some(value), Some(threshold))
            if value.is_finite() && threshold.is_finite() && value <= threshold
    );
    if completion.status == "completed"
        && completion.converged
        && coherent_equilibrium_metric
        && threshold_satisfied
    {
        return Ok(());
    }

    let reason = completion.reason;

    let metric_name = completion.metric_name.as_deref().unwrap_or("metric");
    let metric_value = completion
        .metric_value
        .map(|value| format!("{value:.6e}"))
        .unwrap_or_else(|| "n/a".to_string());
    let threshold = completion
        .threshold
        .map(|value| format!("{value:.6e}"))
        .unwrap_or_else(|| "n/a".to_string());
    bail!(
        "frequency-response stage '{}' requested equilibrium_source='relax', but the previous relaxation stopped before satisfying an equilibrium criterion: status={}, reason={:?}, {}={}, threshold={}; refusing to linearize around an unqualified state",
        stage.entrypoint_kind,
        completion.status,
        reason,
        metric_name,
        metric_value,
        threshold
    );
}

#[derive(Debug, Clone)]
struct ContinuationStageSource {
    run_id: String,
    stage_id: String,
    stage_kind: String,
    is_relaxation: bool,
}

fn accepted_relax_handoff_for_eigen_stage(
    backend_plan: &BackendPlanIR,
    continuation_magnetization: Option<&[[f64; 3]]>,
    prepared_handoff: Option<&fullmag_runner::AcceptedFemRelaxStageHandoff>,
) -> Result<Option<fullmag_runner::AcceptedFemRelaxStageHandoff>> {
    let BackendPlanIR::FemEigen(eigen) = backend_plan else {
        return Ok(None);
    };
    if !matches!(
        eigen.equilibrium,
        fullmag_ir::EquilibriumSourceIR::RelaxedInitialState
    ) || continuation_magnetization.is_none()
    {
        return Ok(None);
    }
    prepared_handoff.cloned().map(Some).ok_or_else(|| {
        anyhow!("relax-to-eigen continuation is missing the accepted Relax handoff v3")
    })
}

fn accepted_relax_handoff_from_completed_stage(
    backend_plan: &BackendPlanIR,
    source_stage: &ContinuationStageSource,
    source_mesh: &fullmag_runner::FemMeshPayload,
    completion: &fullmag_ir::StageCompletionIR,
    equilibrium_magnetization: &[[f64; 3]],
    accepted_fields: &fullmag_runner::CertifiedFemEquilibriumFields,
    certified_fields: &fullmag_runner::CertifiedFemEquilibriumFields,
    recomputed_certificate: &fullmag_runner::RecomputedFemLinearizationCertificateV1,
) -> Result<Option<fullmag_runner::AcceptedFemRelaxStageHandoff>> {
    let BackendPlanIR::Fem(source_plan) = backend_plan else {
        return Ok(None);
    };
    if !source_stage.is_relaxation {
        return Ok(None);
    }
    fullmag_runner::AcceptedFemRelaxStageHandoff::from_completed_relax_verified(
        &source_stage.run_id,
        &source_stage.stage_id,
        &source_stage.stage_kind,
        true,
        source_plan,
        source_mesh,
        completion,
        equilibrium_magnetization.to_vec(),
        accepted_fields.clone(),
        certified_fields.clone(),
        recomputed_certificate.clone(),
    )
    .map(Some)
    .map_err(|error| anyhow!(error.to_string()))
}

fn accepted_relax_handoff_from_completed_stage_with_exact_artifacts(
    backend_plan: &BackendPlanIR,
    source_stage: &ContinuationStageSource,
    source_mesh: &fullmag_runner::FemMeshPayload,
    completion: &fullmag_ir::StageCompletionIR,
    equilibrium_magnetization: &[[f64; 3]],
    artifact_dir: &Path,
    accepted_fields: &fullmag_runner::CertifiedFemEquilibriumFields,
    certified_fields: &fullmag_runner::CertifiedFemEquilibriumFields,
    recomputed_certificate: &fullmag_runner::RecomputedFemLinearizationCertificateV1,
) -> Result<Option<fullmag_runner::AcceptedFemRelaxStageHandoff>> {
    let BackendPlanIR::Fem(source_plan) = backend_plan else {
        return Ok(None);
    };
    if !source_stage.is_relaxation {
        return Ok(None);
    }
    let accepted_path = artifact_dir.join(
        fullmag_runner::CertifiedFemEquilibriumFields::accepted_artifact_path_for_material(
            &source_plan.material,
        ),
    );
    let (certified_relative_path, recomputed_relative_path) =
        fullmag_runner::CertifiedFemEquilibriumFields::artifact_paths_for_material(
            &source_plan.material,
        );
    let certified_path = artifact_dir.join(certified_relative_path);
    let recomputed_path = artifact_dir.join(recomputed_relative_path);
    let producer_provenance_path = artifact_dir.join(
        fullmag_runner::FEM_RELAXATION_PRODUCER_PROVENANCE_RELATIVE_PATH,
    );
    let read_exact = |path: &Path, label: &str| -> Result<Vec<u8>> {
        fs::read(path).with_context(|| {
            format!(
                "verified FEM relaxation handoff did not publish exact {label} bytes {}",
                path.display()
            )
        })
    };
    let producer_provenance_json = read_exact(&producer_provenance_path, "producer provenance")?;
    let producer_provenance: fullmag_runner::FemRelaxationProducerProvenance =
        serde_json::from_slice(&producer_provenance_json)
        .with_context(|| {
            format!(
                "failed to decode producer provenance sidecar {}",
                producer_provenance_path.display()
            )
        })?;
    fullmag_runner::AcceptedFemRelaxStageHandoff::from_completed_relax_verified_with_exact_artifacts_and_provenance(
        &source_stage.run_id,
        &source_stage.stage_id,
        &source_stage.stage_kind,
        true,
        source_plan,
        source_mesh,
        completion,
        equilibrium_magnetization.to_vec(),
        accepted_fields.clone(),
        certified_fields.clone(),
        recomputed_certificate.clone(),
        fullmag_runner::AcceptedFemRelaxExactArtifacts {
            accepted_fields_json: read_exact(&accepted_path, "accepted fields")?,
            certified_fields_json: read_exact(&certified_path, "certified fields")?,
            recomputed_certificate_json: read_exact(&recomputed_path, "recomputed certificate")?,
        },
        producer_provenance,
        producer_provenance_json,
    )
    .map(Some)
    .map_err(|error| anyhow!(error.to_string()))
}

// This value follows the physical continuation, independently of preview state.
// A missing value never proves that a continued state has empty frozen history.
struct HeadlessFrozenContinuation {
    lifecycle: fullmag_runner::constraints::FrozenOutputLifecycleV1,
    source_plan: Option<fullmag_ir::ResolvedFrozenSpinsPlanIR>,
    source_stage_id: String,
    source_grid: fullmag_ir::FdmGridCertificateIR,
}

fn headless_frozen_grid(plan: &fullmag_ir::FdmPlanIR) -> Result<&fullmag_ir::FdmGridCertificateIR> {
    let certificate = plan.grid_certificate.as_ref()
        .context("headless frozen continuation requires its resolved grid certificate")?;
    certificate.validate_against_masks(plan.active_mask.as_deref(), &plan.region_mask)
        .map_err(|error| anyhow!(error))?;
    if certificate.counts != plan.grid.cells
        || certificate.origin_m.map(f64::to_bits) != plan.origin_m.map(f64::to_bits)
        || certificate.cell_m.map(f64::to_bits) != plan.cell_size.map(f64::to_bits)
    {
        bail!("headless frozen continuation grid certificate differs from the physical plan");
    }
    Ok(certificate)
}

fn same_headless_frozen_grid(left: &fullmag_ir::FdmGridCertificateIR, right: &fullmag_ir::FdmGridCertificateIR) -> bool {
    left.grid_fingerprint == right.grid_fingerprint
        && left.region_legend_fingerprint == right.region_legend_fingerprint
        && left.region_legend == right.region_legend
        && left.object_ids == right.object_ids
}

fn read_headless_frozen_terminal(
    artifact_dir: &Path,
    plan: &fullmag_ir::FdmPlanIR,
    result: &fullmag_runner::RunResult,
    context: &fullmag_runner::constraints::FrozenStageContextV1,
    stage_id: &str,
) -> Result<HeadlessFrozenContinuation> {
    let path = artifact_dir.join("solver/frozen_output_lifecycle.v1.json");
    let mut bytes = Vec::new();
    fs::File::open(&path)
        .with_context(|| format!("missing terminal frozen lifecycle {}", path.display()))?
        .take(64 * 1024 * 1024 + 1)
        .read_to_end(&mut bytes)?;
    if bytes.len() > 64 * 1024 * 1024 {
        bail!("terminal frozen lifecycle exceeds its decode budget");
    }
    let lifecycle = fullmag_runner::constraints::FrozenOutputLifecycleV1::decode(&bytes)
        .map_err(|error| anyhow!(error.message))?;
    // Scalar samples can coalesce near the endpoint. Their last timestamp
    // does not replace the exact terminal clock emitted by the solver owner.
    #[derive(serde::Deserialize)]
    #[serde(deny_unknown_fields)]
    struct TerminalClock {
        schema_version: String,
        terminal_step: u64,
        terminal_time_s: f64,
        #[serde(rename = "outputs")]
        _outputs: serde::de::IgnoredAny,
        #[serde(rename = "origin_s")]
        _origin_s: serde::de::IgnoredAny,
        #[serde(rename = "scalar_cursors")]
        _scalar_cursors: serde::de::IgnoredAny,
        #[serde(rename = "field_cursors")]
        _field_cursors: serde::de::IgnoredAny,
        #[serde(rename = "default_scalar_trace")]
        _default_scalar_trace: serde::de::IgnoredAny,
    }
    let mut clock_bytes = Vec::new();
    fs::File::open(artifact_dir.join("solver/terminal_output_coverage.v1.json"))?
        .take(4 * 1024 * 1024 + 1).read_to_end(&mut clock_bytes)?;
    if clock_bytes.len() > 4 * 1024 * 1024 {
        bail!("terminal output coverage exceeds its metadata budget");
    }
    let clock: TerminalClock = serde_json::from_slice(&clock_bytes)?;
    if clock.schema_version != "fullmag.runner.terminal_output_coverage.v1" {
        bail!("terminal frozen lifecycle has an unsupported clock owner");
    }
    lifecycle.validate(
        plan.frozen_spins.as_ref(),
        fullmag_runner::ObservationClock {
            accepted_step: clock.terminal_step,
            time_seconds: clock.terminal_time_s,
            dt_seconds: lifecycle.frozen_spins.as_ref().map(|child| child.dt).filter(|dt| *dt > 0.0),
        },
        &result.final_magnetization,
    ).map_err(|error| anyhow!(error.message))?;
    if lifecycle.frozen_activation_set != context.prepared_activation_set {
        bail!("terminal frozen lifecycle differs from its prepared stage entry");
    }
    Ok(HeadlessFrozenContinuation {
        lifecycle,
        source_plan: plan.frozen_spins.clone(),
        source_stage_id: stage_id.to_string(),
        source_grid: headless_frozen_grid(plan)?.clone(),
    })
}

fn replace_continuation_after_synthetic_stage(
    continuation_magnetization: &mut Option<Vec<[f64; 3]>>,
    continuation_source: &mut Option<ContinuationSource>,
    continuation_fem_mesh_payload: &mut Option<fullmag_runner::FemMeshPayload>,
    continuation_completion: &mut Option<fullmag_ir::StageCompletionIR>,
    continuation_stage_source: &mut Option<ContinuationStageSource>,
    continuation_accepted_fields: &mut Option<fullmag_runner::CertifiedFemEquilibriumFields>,
    continuation_certified_fields: &mut Option<fullmag_runner::CertifiedFemEquilibriumFields>,
    continuation_relax_handoff: &mut Option<fullmag_runner::AcceptedFemRelaxStageHandoff>,
    magnetization: Vec<[f64; 3]>,
    preserves_certified_equilibrium: bool,
) {
    *continuation_magnetization = Some(magnetization);
    if preserves_certified_equilibrium {
        return;
    }
    *continuation_source = None;
    *continuation_fem_mesh_payload = None;
    *continuation_completion = None;
    *continuation_stage_source = None;
    *continuation_accepted_fields = None;
    *continuation_certified_fields = None;
    *continuation_relax_handoff = None;
}

struct StageProgressHeartbeat {
    snapshot: Arc<Mutex<crate::stage_heartbeat::StageHeartbeatProgress>>,
    stop_tx: Option<mpsc::Sender<()>>,
    join_handle: Option<JoinHandle<()>>,
}

impl StageProgressHeartbeat {
    fn spawn(
        initial_update: fullmag_runner::StepUpdate,
        live_workspace: LocalLiveWorkspace,
        run_id: String,
        _session_id: String,
        _artifact_dir: PathBuf,
        terminal_prefix: String,
        ui_label: String,
        torque_mode: Option<TorqueDisplayMode>,
    ) -> Self {
        let snapshot = Arc::new(Mutex::new(
            crate::stage_heartbeat::StageHeartbeatProgress::new(&initial_update),
        ));
        let (stop_tx, stop_rx) = mpsc::channel();
        let thread_snapshot = Arc::clone(&snapshot);
        let join_handle = std::thread::Builder::new()
            .name(format!(
                "fullmag-stage-heartbeat-{}",
                run_id.chars().take(24).collect::<String>()
            ))
            .spawn(move || loop {
                match stop_rx.recv_timeout(LIVE_PROGRESS_PUBLISH_INTERVAL) {
                    Ok(()) | Err(mpsc::RecvTimeoutError::Disconnected) => break,
                    Err(mpsc::RecvTimeoutError::Timeout) => {}
                }
                let progress = match thread_snapshot.lock() {
                    Ok(snapshot) => snapshot.clone(),
                    Err(_) => break,
                };
                if progress.finished
                    || progress.last_step_at.elapsed() < LIVE_PROGRESS_PUBLISH_INTERVAL
                {
                    continue;
                }

                let mut progress = progress;
                progress.stats.wall_time_ns = progress
                    .stats
                    .wall_time_ns
                    .max(saturating_nanos_u64(progress.stage_started_at.elapsed()));
                let idle_for = progress.last_step_at.elapsed();
                let terminal_line = format_stage_progress_line(
                    &terminal_prefix,
                    &progress.stats,
                    torque_mode,
                    Some(idle_for),
                    progress.hysteresis_field_m_t,
                );
                eprintln!("{terminal_line}");
                let heartbeat_message =
                    format_stage_heartbeat_message(&ui_label, &progress.stats, idle_for);
                live_workspace.update(|state| {
                    state.session.status = if progress.finished {
                        "completed".to_string()
                    } else {
                        "running".to_string()
                    };
                    progress.apply_to_run(&mut state.run);
                    state.live_state.status = state.session.status.clone();
                    state.live_state.runtime_status = Some(
                        fullmag_runner::RuntimeStatus::from_status_code(&state.session.status),
                    );
                    state.live_state.updated_at_unix_ms = unix_time_millis().unwrap_or(0);
                    progress.apply_to_live_step(&mut state.live_state.latest_step);
                    if let Some(stage_execution) = state.stage_execution.as_mut() {
                        if let Some(active_index) = stage_execution.active_stage_index {
                            if let Some(stage) = stage_execution.stages.get_mut(active_index) {
                                apply_stage_heartbeat_progress(stage, idle_for);
                            }
                        }
                    }
                    upsert_engine_log_tail(
                        &mut state.engine_log,
                        "info",
                        STAGE_HEARTBEAT_LOG_PREFIX,
                        heartbeat_message,
                    );
                });
            })
            .expect("stage heartbeat thread should spawn");
        Self {
            snapshot,
            stop_tx: Some(stop_tx),
            join_handle: Some(join_handle),
        }
    }

    fn record(&mut self, update: &mut fullmag_runner::StepUpdate) {
        if let Ok(mut snapshot) = self.snapshot.lock() {
            snapshot.record(update);
        }
    }

    fn finish(&mut self) {
        if let Some(stop_tx) = self.stop_tx.take() {
            let _ = stop_tx.send(());
        }
        if let Some(join_handle) = self.join_handle.take() {
            let _ = join_handle.join();
        }
    }
}

fn format_stage_heartbeat_message(
    ui_label: &str,
    stats: &fullmag_runner::StepStats,
    idle_for: Duration,
) -> String {
    let mut message = format!(
        "{STAGE_HEARTBEAT_LOG_PREFIX}{ui_label}: last completed step {} at t={:.4e}, waiting {:.1}s for the next solver update",
        stats.step,
        stats.time,
        idle_for.as_secs_f64(),
    );
    if let Some(progress) = frequency_response_step_progress_segment(stats) {
        message.push_str("; ");
        message.push_str(&progress);
    }
    message
}

impl Drop for StageProgressHeartbeat {
    fn drop(&mut self) {
        self.finish();
    }
}

pub(crate) fn requested_runtime_selection(
    requested_backend: &str,
    explicit_selection: bool,
    requested_device: &str,
    requested_precision: &str,
    requested_mode: &str,
    requested_cpu_threads: Option<u32>,
) -> SessionRuntimeSelection {
    SessionRuntimeSelection {
        requested_backend: requested_backend.to_string(),
        explicit_selection,
        authored_requested_device: requested_device.to_string(),
        requested_device: requested_device.to_string(),
        requested_precision: requested_precision.to_string(),
        requested_mode: requested_mode.to_string(),
        requested_cpu_threads,
        resolved_backend: None,
        resolved_device: None,
        resolved_precision: None,
        resolved_mode: None,
        resolved_runtime_family: None,
        resolved_engine_id: None,
        resolved_worker: None,
        resolved_cpu_threads: None,
        resolved_fallback: None,
        fem_crossover_decision: None,
    }
}

fn session_runtime_selection_for_problem(
    problem: &ProblemIR,
    plan: Option<&ExecutionPlanIR>,
    field_every_n: u64,
    fallback_requested_backend: &str,
    fallback_requested_mode: &str,
    fallback_requested_precision: &str,
) -> SessionRuntimeSelection {
    let requested_backend = backend_target_name(problem.backend_policy.requested_backend);
    let requested_mode = execution_mode_name(problem.validation_profile.execution_mode);
    let requested_precision = execution_precision_name(problem.backend_policy.execution_precision);
    let explicit_selection = explicit_selection_from_problem(problem);
    let requested_device = requested_device_from_problem(problem);
    let requested_cpu_threads = requested_cpu_threads_from_problem(problem);
    let mut selection = requested_runtime_selection(
        requested_backend,
        explicit_selection,
        &requested_device,
        requested_precision,
        requested_mode,
        requested_cpu_threads,
    );
    if plan.is_some_and(|plan| matches!(
        &plan.backend_plan, BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)
    )) {
        return selection;
    }
    if plan.is_some_and(antenna_external_lead_inspection::is_carrier) {
        selection.resolved_backend = Some("fem".into());
        selection.resolved_device = Some("cpu".into());
        selection.resolved_precision = Some("double".into());
        selection.resolved_mode = Some("strict".into());
        let closed_loop = plan.is_some_and(|plan| plan.provenance.notes.iter().any(|note| note == "antenna_closed_loop_inspection_carrier_only:no_llg_execution"));
        let inspection_family = if closed_loop { "antenna_closed_loop_inspection" } else { "antenna_external_lead_inspection" };
        selection.resolved_runtime_family = Some(inspection_family.into());
        selection.resolved_engine_id = Some(inspection_family.into());
        return selection;
    }
    let resolved_runtime = plan
        .map(|plan| {
            fullmag_runner::resolve_session_runtime_for_plan_and_preview(
                problem,
                plan,
                field_every_n,
            )
        })
        .unwrap_or_else(|| {
            fullmag_runner::resolve_session_runtime_for_preview(problem, field_every_n)
        });
    match resolved_runtime {
        Ok(resolved) => {
            selection.requested_device = resolved.requested_device;
            selection.requested_cpu_threads = resolved
                .requested_cpu_threads
                .and_then(|threads| u32::try_from(threads).ok())
                .or(selection.requested_cpu_threads);
            selection.resolved_backend = Some(resolved.resolved_backend);
            selection.resolved_device = Some(resolved.resolved_device);
            selection.resolved_precision = Some(resolved.resolved_precision);
            selection.resolved_mode = Some(resolved.resolved_mode);
            selection.resolved_runtime_family = resolved.resolved_runtime_family;
            selection.resolved_engine_id = resolved.resolved_engine_id;
            selection.resolved_worker = resolved.resolved_worker;
            selection.resolved_cpu_threads = u32::try_from(resolved.resolved_cpu_threads).ok();
            selection.resolved_fallback = resolved.resolved_fallback;
            selection.fem_crossover_decision = resolved.fem_crossover_decision;
        }
        Err(_) => {
            selection.requested_backend = fallback_requested_backend.to_string();
            selection.requested_precision = fallback_requested_precision.to_string();
            selection.requested_mode = fallback_requested_mode.to_string();
        }
    }
    selection
}

fn fem_mesh_payload_from_backend_plan(
    backend_plan: &BackendPlanIR,
) -> Option<fullmag_runner::FemMeshPayload> {
    match backend_plan {
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => None,
        BackendPlanIR::AntennaFieldOnly(plan) => Some(fullmag_runner::StageFemMeshAsset::build_from_antenna_field_only_plan(plan).payload),
        BackendPlanIR::Fem(fem) => Some(fullmag_runner::FemMeshPayload::from(fem)),
        BackendPlanIR::FemEigen(fem) => Some(fullmag_runner::FemMeshPayload::from(fem)),
        BackendPlanIR::FemFrequencyResponse(fem) => Some(fullmag_runner::FemMeshPayload::from(fem)),
        BackendPlanIR::Fdm(_) | BackendPlanIR::FdmMultilayer(_)
        | BackendPlanIR::AntennaExternalLeadInspection(_) => None,
    }
}

#[cfg(test)]
fn fem_live_mesh_payload_and_initial_magnetization(
    backend_plan: &BackendPlanIR,
) -> anyhow::Result<(fullmag_runner::FemMeshPayload, Vec<[f64; 3]>)> {
    let mesh_payload = fem_mesh_payload_from_backend_plan(backend_plan)
        .ok_or_else(|| anyhow!("backend plan did not produce a FEM mesh payload"))?;
    let initial_magnetization = current_stage_magnetization_vectors(None, backend_plan);
    if mesh_payload.nodes.len() != initial_magnetization.len() {
        return Err(anyhow!(
            "FEM live mesh has {} nodes but initial magnetization has {} vectors",
            mesh_payload.nodes.len(),
            initial_magnetization.len()
        ));
    }
    Ok((mesh_payload, initial_magnetization))
}

fn initial_live_state_manifest_from_backend_plan(
    update: &fullmag_runner::StepUpdate,
    backend_plan: &BackendPlanIR,
    mesh_payload: Option<fullmag_runner::FemMeshPayload>,
    continuation_magnetization: Option<&[[f64; 3]]>,
) -> anyhow::Result<(LiveStateManifest, Option<fullmag_runner::FemMeshPayload>)> {
    let mut live_state = live_state_manifest_from_update(update.clone());
    if matches!(backend_plan, BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)) {
        bail!("retained-current H-only live state requires its typed accepted worker; generic magnetic-state publication is forbidden");
    }
    if matches!(backend_plan, BackendPlanIR::AntennaFieldOnly(_)) {
        if continuation_magnetization.is_some_and(|values| !values.is_empty()) {
            bail!("field_only cannot inherit magnetic continuation state");
        }
        live_state.latest_step.magnetization = None;
        live_state.latest_step.fem_mesh_generation_id = mesh_payload.as_ref().and_then(|mesh| mesh.generation_id.clone());
        return Ok((live_state, mesh_payload));
    }
    if matches!(backend_plan, BackendPlanIR::AntennaExternalLeadInspection(_)) {
        live_state.latest_step.magnetization = None;
        live_state.latest_step.grid = [0; 3];
        live_state.latest_step.preview_field = None;
        live_state.latest_step.fem_mesh_generation_id = None;
        return Ok((live_state, None));
    }
    if let Some(mesh_payload) = mesh_payload.as_ref() {
        let initial_magnetization =
            current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
        if mesh_payload.nodes.len() != initial_magnetization.len() {
            bail!(
                "initial FEM live mesh has {} nodes but initial magnetization has {} vectors",
                mesh_payload.nodes.len(),
                initial_magnetization.len()
            );
        }
        live_state.latest_step.fem_mesh_generation_id = mesh_payload.generation_id.clone();
        live_state.latest_step.magnetization = Some(flatten_magnetization(&initial_magnetization));
    }
    Ok((live_state, mesh_payload))
}

fn default_domain_region_markers(
    geometry_entries: &[fullmag_ir::GeometryEntryIR],
) -> Vec<fullmag_ir::FemDomainRegionMarkerIR> {
    geometry_entries
        .iter()
        .enumerate()
        .map(|(index, geometry)| fullmag_ir::FemDomainRegionMarkerIR {
            geometry_name: geometry.name().to_string(),
            marker: (index + 1) as u32,
        })
        .collect()
}

fn shared_domain_object_region_mesh_specs(problem: &ProblemIR) -> Result<Vec<serde_json::Value>> {
    let mut owner_geometry_by_object = std::collections::BTreeMap::<&str, &str>::new();
    for magnet in &problem.magnets {
        let geometry_name = problem
            .regions
            .iter()
            .find(|region| region.name == magnet.region)
            .map(|region| region.geometry.as_str())
            .ok_or_else(|| {
                anyhow!(
                    "object-region remesh cannot resolve magnet '{}' region '{}'",
                    magnet.name,
                    magnet.region
                )
            })?;
        if let Some(previous) = owner_geometry_by_object.insert(&magnet.name, geometry_name) {
            if previous != geometry_name {
                bail!(
                    "object '{}' resolves to multiple owner geometries ('{}' and '{}')",
                    magnet.name,
                    previous,
                    geometry_name
                );
            }
        }
    }

    problem
        .object_regions
        .iter()
        .map(|region| {
            let owner_geometry_name = owner_geometry_by_object
                .get(region.owner_object.as_str())
                .copied()
                .ok_or_else(|| {
                    anyhow!(
                        "object-region '{}' references owner object '{}' without a current geometry",
                        region.region_id,
                        region.owner_object
                    )
                })?;
            let mut payload = serde_json::to_value(region)
                .context("failed to serialize object-region remesh payload")?;
            let object = payload.as_object_mut().ok_or_else(|| {
                anyhow!("serialized object-region '{}' is not a JSON object", region.region_id)
            })?;
            object.insert(
                "owner_geometry_name".to_string(),
                serde_json::Value::String(owner_geometry_name.to_string()),
            );
            Ok(payload)
        })
        .collect()
}

fn shared_domain_body_material_payload(
    problem: &ProblemIR,
) -> Result<(serde_json::Value, serde_json::Value)> {
    let mut body_material_fields = serde_json::Map::new();
    let mut geometry_object_ids = serde_json::Map::new();

    for magnet in &problem.magnets {
        let geometry_name = problem
            .regions
            .iter()
            .find(|region| region.name == magnet.region)
            .map(|region| region.geometry.as_str())
            .ok_or_else(|| {
                anyhow!(
                    "shared-domain remesh cannot resolve magnet '{}' region '{}'",
                    magnet.name,
                    magnet.region
                )
            })?;
        if body_material_fields.contains_key(geometry_name) {
            bail!(
                "shared-domain remesh has multiple magnetic bodies for geometry '{}'",
                geometry_name
            );
        }
        let material = problem
            .materials
            .iter()
            .find(|material| material.name == magnet.material)
            .ok_or_else(|| {
                anyhow!(
                    "shared-domain remesh cannot resolve material '{}' for magnet '{}'",
                    magnet.material,
                    magnet.name
                )
            })?;
        let object_id = magnet.object_id.as_deref().unwrap_or(&magnet.name);
        let axis = material.anisotropy_axis.unwrap_or([0.0, 0.0, 1.0]);
        for (label, value) in [
            ("Ms", material.saturation_magnetisation),
            ("Aex", material.exchange_stiffness),
            ("alpha", material.damping),
            ("Ku1", material.uniaxial_anisotropy.unwrap_or(0.0)),
        ] {
            if !value.is_finite() {
                bail!(
                    "shared-domain remesh material field '{}' for magnet '{}' is not finite",
                    label,
                    magnet.name
                );
            }
        }
        if axis.iter().any(|value| !value.is_finite()) {
            bail!(
                "shared-domain remesh anisotropy_axis for magnet '{}' is not finite",
                magnet.name
            );
        }
        body_material_fields.insert(
            geometry_name.to_string(),
            serde_json::json!({
                "Ms": material.saturation_magnetisation,
                "Aex": material.exchange_stiffness,
                "alpha": material.damping,
                "Ku1": material.uniaxial_anisotropy.unwrap_or(0.0),
                "anisotropy_axis": axis,
            }),
        );
        geometry_object_ids.insert(
            geometry_name.to_string(),
            serde_json::Value::String(object_id.to_string()),
        );
    }

    Ok((
        serde_json::Value::Object(body_material_fields),
        serde_json::Value::Object(geometry_object_ids),
    ))
}

fn resolved_shared_domain_object_region_markers(
    problem: &ProblemIR,
    markers: &[fullmag_ir::FemDomainRegionMarkerIR],
) -> Result<Vec<fullmag_ir::FemDomainRegionMarkerIR>> {
    let expected = problem
        .object_regions
        .iter()
        .filter(|region| {
            region.enabled
                && matches!(
                    region.realization_policy,
                    fullmag_ir::RegionRealizationPolicyIR::Conformal
                )
        })
        .map(|region| region.region_id.as_str())
        .collect::<std::collections::BTreeSet<_>>();
    if markers.len() != expected.len() {
        bail!(
            "shared-domain remesh returned {} object-region markers, expected {} conformal enabled regions",
            markers.len(),
            expected.len()
        );
    }
    let mut seen_ids = std::collections::BTreeSet::new();
    let mut seen_markers = std::collections::BTreeSet::new();
    for marker in markers {
        if marker.geometry_name.trim().is_empty() || marker.marker == 0 {
            bail!(
                "shared-domain remesh returned an invalid object-region marker {:?}",
                marker
            );
        }
        if !expected.contains(marker.geometry_name.as_str()) {
            bail!(
                "shared-domain remesh returned unexpected object-region marker '{}'",
                marker.geometry_name
            );
        }
        if !seen_ids.insert(marker.geometry_name.as_str()) {
            bail!(
                "shared-domain remesh returned duplicate object-region marker '{}'",
                marker.geometry_name
            );
        }
        if !seen_markers.insert(marker.marker) {
            bail!(
                "shared-domain remesh returned duplicate object-region marker value {}",
                marker.marker
            );
        }
    }
    Ok(markers.to_vec())
}

fn adaptive_remesh_legality_reason(problem: &ProblemIR) -> Option<&'static str> {
    if problem.object_regions.iter().any(|region| {
        region.enabled
            && matches!(
                region.realization_policy,
                fullmag_ir::RegionRealizationPolicyIR::Conformal
            )
    }) {
        return Some("adaptive_region_remesh_not_certified");
    }
    let has_periodic_mesh = problem
        .geometry_assets
        .as_ref()
        .and_then(|assets| assets.fem_domain_mesh_asset.as_ref())
        .and_then(|asset| asset.mesh.as_ref())
        .is_some_and(|mesh| !mesh.periodic_boundary_pairs.is_empty());
    has_periodic_mesh.then_some("adaptive_periodic_remesh_not_certified")
}

fn adaptive_remesh_backend_legality_reason(backend_plan: &BackendPlanIR) -> Option<&'static str> {
    let domain_mesh_mode = match backend_plan {
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => return Some("retained_current_h_only_requires_owned_target_rebinding"),
        BackendPlanIR::AntennaFieldOnly(_) => return Some("field_only_remesh_requires_explicit_source_rebinding"),
        BackendPlanIR::Fem(plan) => Some(plan.domain_mesh_mode),
        BackendPlanIR::FemEigen(plan) => Some(plan.domain_mesh_mode),
        BackendPlanIR::FemFrequencyResponse(plan) => Some(plan.domain_mesh_mode),
        BackendPlanIR::Fdm(_) | BackendPlanIR::FdmMultilayer(_)
        | BackendPlanIR::AntennaExternalLeadInspection(_) => None,
    };
    matches!(
        domain_mesh_mode,
        Some(fullmag_ir::FemDomainMeshModeIR::SharedDomainMeshWithAir)
    )
    .then_some("adaptive_shared_domain_remesh_requires_dedicated_remesher")
}

fn validate_periodic_remesh_candidate(
    previous: &fullmag_ir::MeshIR,
    candidate: &fullmag_ir::MeshIR,
) -> Result<()> {
    if previous.periodic_boundary_pairs.is_empty() {
        return Ok(());
    }
    if candidate.periodic_boundary_pairs.is_empty() || candidate.periodic_node_pairs.is_empty() {
        bail!("periodic_remesh_requires_recertification");
    }
    let certificate = candidate.periodic_mesh_certificate_v6().map_err(|errors| {
        anyhow!(
            "periodic_remesh_candidate_recertification_failed: {}",
            errors.join("; ")
        )
    })?;
    if certificate.certificate_status != "accepted" {
        bail!(
            "periodic_remesh_candidate_recertification_failed: status={}",
            certificate.certificate_status
        );
    }
    Ok(())
}

#[derive(Debug, Clone, serde::Deserialize)]
struct SceneProblemPatch {
    #[serde(default)]
    geometry_entries: Vec<GeometryEntryIR>,
    #[serde(default)]
    magnets: Vec<MagnetIR>,
    #[serde(default)]
    materials: Vec<MaterialIR>,
    #[serde(default)]
    regions: Vec<RegionIR>,
    #[serde(default)]
    object_regions: Vec<ObjectRegionIR>,
    #[serde(default)]
    universe: Option<serde_json::Value>,
    #[serde(default)]
    fdm: Option<serde_json::Value>,
    #[serde(default)]
    runtime_selection: Option<serde_json::Value>,
}

fn scene_problem_patch_from_mesh_options(
    mesh_options: &serde_json::Value,
) -> Result<Option<SceneProblemPatch>> {
    let Some(value) = mesh_options.get("scene_problem_patch") else {
        return Ok(None);
    };
    let patch = serde_json::from_value::<SceneProblemPatch>(value.clone())
        .context("failed to parse scene_problem_patch from mesh build command")?;
    if patch.geometry_entries.is_empty()
        || patch.magnets.is_empty()
        || patch.materials.is_empty()
        || patch.regions.is_empty()
    {
        bail!("scene_problem_patch must include geometry_entries, regions, materials, and magnets");
    }
    Ok(Some(patch))
}

fn apply_scene_problem_patch(problem: &mut ProblemIR, patch: &SceneProblemPatch) -> Result<()> {
    problem.geometry.entries = patch.geometry_entries.clone();
    problem.regions = patch.regions.clone();
    problem.materials = patch.materials.clone();
    problem.magnets = patch.magnets.clone();
    problem.object_regions = patch.object_regions.clone();
    apply_scene_discretization_patch(problem, patch)
}

fn apply_scene_discretization_patch(
    problem: &mut ProblemIR,
    patch: &SceneProblemPatch,
) -> Result<()> {
    if let Some(universe) = patch.universe.as_ref() {
        problem
            .problem_meta
            .runtime_metadata
            .insert("study_universe".to_string(), universe.clone());
        problem.problem_meta.runtime_metadata.remove("domain_frame");
    }
    if let Some(fdm) = patch.fdm.as_ref() {
        let mut fdm = fdm.clone();
        let fallback_cell = problem
            .backend_policy
            .discretization_hints
            .as_ref()
            .and_then(|hints| hints.fdm.as_ref())
            .map(|hints| hints.cell);
        if let Some(object) = fdm.as_object_mut() {
            if let Some(per_object_grid) = object
                .remove("per_object_grid")
                .or_else(|| object.remove("per_magnet"))
            {
                object.insert("per_magnet".to_string(), per_object_grid);
            }
            if let Some(demag) = object
                .get_mut("demag")
                .and_then(|value| value.as_object_mut())
            {
                demag.remove("explain");
                demag
                    .entry("fft_backend".to_string())
                    .or_insert_with(|| serde_json::json!("auto"));
            }
            if !object.contains_key("cell") {
                if let Some(default_cell) = object.get("default_cell").cloned() {
                    object.insert("cell".to_string(), default_cell);
                } else if let Some(fallback_cell) = fallback_cell {
                    object.insert("cell".to_string(), serde_json::json!(fallback_cell));
                }
            }
        }
        let fdm_hints: FdmHintsIR = serde_json::from_value(fdm)
            .context("failed to apply FDM discretization patch to ProblemIR")?;
        let hints = problem
            .backend_policy
            .discretization_hints
            .get_or_insert_with(|| DiscretizationHintsIR {
                fdm: None,
                fem: None,
                hybrid: None,
            });
        hints.fdm = Some(fdm_hints);
        problem.backend_policy.requested_backend = BackendTarget::Fdm;
    }
    if let Some(runtime_selection) = patch.runtime_selection.as_ref() {
        problem
            .problem_meta
            .runtime_metadata
            .insert("runtime_selection".to_string(), runtime_selection.clone());
    }
    Ok(())
}

fn apply_remeshed_problem_snapshot_to_stages(
    stages: &mut [ResolvedScriptStage],
    scene_problem_patch: Option<&SceneProblemPatch>,
    mesh: &fullmag_ir::MeshIR,
    hmax: f64,
    shared_domain_remesh: bool,
    region_markers: &[fullmag_ir::FemDomainRegionMarkerIR],
    object_region_markers: &[fullmag_ir::FemDomainRegionMarkerIR],
    adaptive_runtime_state: Option<&serde_json::Value>,
) -> Result<()> {
    for stage in stages {
        if let Some(patch) = scene_problem_patch {
            apply_scene_problem_patch(&mut stage.ir, patch)?;
        }
        apply_current_fem_overrides(
            &mut stage.ir,
            Some(mesh),
            Some(hmax),
            adaptive_runtime_state,
        );
        if shared_domain_remesh {
            let resolved_region_markers = if region_markers.is_empty() {
                default_domain_region_markers(&stage.ir.geometry.entries)
            } else {
                region_markers.to_vec()
            };
            let resolved_object_region_markers =
                resolved_shared_domain_object_region_markers(&stage.ir, object_region_markers)?;
            let domain_asset = stage
                .ir
                .geometry_assets
                .as_mut()
                .and_then(|assets| assets.fem_domain_mesh_asset.as_mut())
                .ok_or_else(|| {
                    anyhow!(
                        "shared-domain remesh produced no fem_domain_mesh_asset for updated stage"
                    )
                })?;
            domain_asset.region_markers = resolved_region_markers;
            domain_asset.object_region_markers = resolved_object_region_markers;
        }
    }
    Ok(())
}

fn refresh_materialized_stage_execution_plans(
    stages: &[ResolvedScriptStage],
    stage_execution_plans: &mut [ExecutionPlanIR],
    first_stage_plan: Option<ExecutionPlanIR>,
) -> Result<()> {
    if stages.len() != stage_execution_plans.len() {
        bail!(
            "stage/plan snapshot mismatch after interactive remesh: {} stages, {} plans",
            stages.len(),
            stage_execution_plans.len()
        );
    }

    let mut first_stage_plan = first_stage_plan;
    for (index, (stage, plan_slot)) in stages
        .iter()
        .zip(stage_execution_plans.iter_mut())
        .enumerate()
    {
        validate_ir(&stage.ir)?;
        if index == 0 {
            if let Some(plan) = first_stage_plan.take() {
                *plan_slot = plan;
                continue;
            }
        }
        *plan_slot = plan_materialized_stage_snapshot(stage)?;
    }
    Ok(())
}

fn plan_materialized_stage_snapshot(stage: &ResolvedScriptStage) -> Result<ExecutionPlanIR> {
    if matches!(&stage.action, Some(ResolvedScriptStageAction::AntennaRetainedCurrentInspection { .. }
        | ResolvedScriptStageAction::AntennaRetainedDirectInspection { .. } | ResolvedScriptStageAction::AntennaRetainedPreparationInspection { .. })) {
        bail!("retained-current H-only inspection requires the accepted task preparation and worker; the legacy CLI stage executor cannot load its durable parent or start fresh current transport");
    }
    if let Some(ResolvedScriptStageAction::AntennaClosedLoopInspection {
        input, requested_execution, output_id,
    }) = &stage.action {
        return antenna_external_lead_inspection::plan_closed_loop_carrier(
            &stage.ir, input, requested_execution, output_id,
        );
    }
    if let Some(ResolvedScriptStageAction::AntennaExternalLeadInspection {
        input, requested_execution, output_id,
    }) = &stage.action {
        return antenna_external_lead_inspection::plan_carrier(
            &stage.ir, input, requested_execution, output_id,
        );
    }
    let mut planning_ir = stage.ir.clone();
    if stage.action.is_some() {
        let sampling = planning_ir.study.sampling_mut();
        if sampling.table_autosave.as_ref().is_some_and(|table| {
            table.requests_auto_sinc_cutoff() && table.resolved_sample_period_s.is_none()
        }) {
            sampling.table_autosave = None;
        }
        sampling.outputs.retain(|output| {
            !matches!(
                output,
                fullmag_ir::OutputIR::FieldAuto { .. } | fullmag_ir::OutputIR::ScalarAuto { .. }
            )
        });
    }
    let plan = fullmag_plan::plan(&planning_ir).map_err(|error| anyhow!(error.to_string()))?;
    if matches!(&plan.backend_plan, BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)) {
        bail!("retained-current H-only inspection requires its typed accepted preparation and worker; the legacy CLI stage executor cannot load its durable parent or start fresh current transport");
    }
    Ok(plan)
}

/// Re-resolve the dedicated conductor solve solely to calculate the current
/// dependency signature.  This does not execute the native solve; it rebuilds
/// the canonical plan so an old immutable asset cannot be accepted merely
/// because its own bytes and digest are intact.
fn current_antenna_solution_expectation(
    problem: &ProblemIR,
    stage_id: &str,
    port_mode_id: &str,
    reference: fullmag_ir::AntennaFieldSolutionRefIR,
) -> Result<fullmag_runner::ExpectedAntennaSolution> {
    let mut verification_problem = problem.clone();
    verification_problem.backend_policy.requested_backend = BackendTarget::Fem;
    let solve_plan =
        fullmag_plan::plan_antenna_field_solve(&verification_problem, stage_id, port_mode_id)
            .map_err(|error| anyhow!("re-resolve current antenna dependencies: {error}"))?;
    let signatures = fullmag_runner::antenna_field_solution_signatures(&solve_plan).map_err(|error| {
        anyhow!(
            "compute current antenna dependency signature: {}",
            error.message
        )
    })?;
    let request = solve_plan.conductor.charge_transport_plans[0]
        .antenna_field_solution_request
        .as_ref()
        .ok_or_else(|| anyhow!("resolved antenna solve has no field-solution request"))?;
    Ok(fullmag_runner::ExpectedAntennaSolution::new(reference, signatures)
        .with_source_revisions(
            request.geometry_revision.clone(),
            request.material_revision.clone(),
            request.mesh_digest.clone(),
        ))
}

/// Validate activation before resolving any asset storage. Clear obsolete
/// bases when this exact problem has no active antenna consumer.
pub(super) fn prepare_solved_antenna_drive_activation(
    problem: &ProblemIR,
    execution_plan: &mut ExecutionPlanIR,
) -> Result<bool> {
    let active_stage_id = problem
        .problem_meta
        .runtime_metadata
        .get("active_stage_id")
        .and_then(serde_json::Value::as_str);
    if !problem.solved_antenna_drives.is_empty() {
        let time_stage = match &execution_plan.backend_plan {
            BackendPlanIR::Fem(plan) => Some(&plan.time_stage),
            BackendPlanIR::Fdm(plan) => Some(&plan.time_stage),
            _ => None,
        };
        if time_stage.is_some_and(|stage| {
            stage.study_kind != problem.study.kind()
                || stage.active_stage_id.as_deref() != active_stage_id
        }) {
            bail!("solved antenna drive activation context differs between ProblemIR and execution plan");
        }
    }
    if !problem.solved_antenna_drives.iter().any(|drive| {
        drive
            .activation
            .is_active_for(problem.study.kind(), active_stage_id)
    }) {
        match &mut execution_plan.backend_plan {
            BackendPlanIR::Fem(plan) => plan.solved_antenna_drive_bases.clear(),
            BackendPlanIR::Fdm(plan) => plan.solved_antenna_drive_bases.clear(),
            _ => {}
        }
        return Ok(false);
    }
    match &execution_plan.backend_plan {
        BackendPlanIR::Fem(_) | BackendPlanIR::Fdm(_) => {}
        BackendPlanIR::FdmMultilayer(_) => {
            bail!("solved antenna drives are not supported by the FDM multilayer lane")
        }
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => {
            bail!("retained-current H-only inspection is not a qualified solved LLG drive basis")
        }
        BackendPlanIR::AntennaFieldOnly(_) | BackendPlanIR::FemEigen(_) | BackendPlanIR::FemFrequencyResponse(_) => {
            bail!("solved antenna drives are supported only by the FEM time-evolution LLG lane")
        }
        BackendPlanIR::AntennaExternalLeadInspection(_) => {
            bail!("raw antenna inspection is not a solved LLG drive basis")
        }
    };
    Ok(true)
}

/// Attach published immutable antenna bases to the backend execution plan
/// that will consume them. The field-solve stage only publishes an asset; this
/// boundary is the explicit asset-to-LLG hand-off. FEM and FDM use separate
/// target projections, while missing/stale assets fail closed instead of
/// silently dropping the authored drive.
pub(super) fn attach_solved_antenna_drive_bases(
    problem: &ProblemIR,
    execution_plan: &mut ExecutionPlanIR,
    artifact_dir: &Path,
) -> Result<()> {
    if !prepare_solved_antenna_drive_activation(problem, execution_plan)? {
        return Ok(());
    }

    let time_stage = match &execution_plan.backend_plan {
        BackendPlanIR::Fem(plan) => &plan.time_stage,
        BackendPlanIR::Fdm(plan) => &plan.time_stage,
        _ => unreachable!("backend lane was validated before antenna activation"),
    };
    let active_drives = problem
        .solved_antenna_drives
        .iter()
        .filter(|drive| {
            drive.activation.is_active_for(
                time_stage.study_kind,
                time_stage.active_stage_id.as_deref(),
            )
        })
        .collect::<Vec<_>>();

    let mut assets = std::collections::BTreeMap::new();
    for drive in active_drives {
        let projection = problem
            .antenna_target_projections
            .iter()
            .find(|projection| projection.id == drive.projection_ref)
            .ok_or_else(|| {
                anyhow!(
                    "solved antenna drive '{}' references missing projection '{}'",
                    drive.id,
                    drive.projection_ref
                )
            })?;
        let stage = problem
            .antenna_field_solve_stages
            .iter()
            .find(|stage| stage.id == projection.solution.stage_id())
            .ok_or_else(|| {
                anyhow!(
                    "antenna projection '{}' references missing solve stage '{}'",
                    projection.id,
                    projection.solution.stage_id()
                )
            })?;
        let reference = projection
            .solution
            .published()
            .ok_or_else(|| anyhow!("antenna projection '{}' is not resolved", projection.id))?;
        let expected = current_antenna_solution_expectation(
            problem,
            &stage.id,
            &drive.port_mode_id,
            reference.clone(),
        )?;
        let asset = fullmag_runner::load_expected_antenna_field_solution(artifact_dir, &expected)
            .map_err(|error| {
                anyhow!(
                    "load current antenna solution asset '{}' for drive '{}': {}",
                    reference.asset_id,
                    drive.id,
                    error.message
                )
            })?;
        if let Some(previous) = assets.get(&reference.asset_id) {
            if previous != &asset {
                bail!(
                    "antenna solution asset '{}' was resolved with conflicting immutable payloads",
                    reference.asset_id
                );
            }
        } else {
            assets.insert(reference.asset_id.clone(), asset);
        }
    }

    match &mut execution_plan.backend_plan {
        BackendPlanIR::Fem(plan) => {
            fullmag_runner::materialize_fem_solved_antenna_drives_v03(problem, plan, &assets)
                .map_err(|error| anyhow!("materialize solved antenna drives: {}", error.message))
        }
        BackendPlanIR::Fdm(plan) => {
            fullmag_runner::materialize_fdm_solved_antenna_drives_v03(problem, plan, &assets)
                .map_err(|error| anyhow!("materialize solved antenna drives: {}", error.message))
        }
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)
        | BackendPlanIR::AntennaFieldOnly(_)
        | BackendPlanIR::AntennaExternalLeadInspection(_)
        | BackendPlanIR::FdmMultilayer(_)
        | BackendPlanIR::FemEigen(_)
        | BackendPlanIR::FemFrequencyResponse(_) => unreachable!(
            "backend lane was validated before antenna solution assets were materialized"
        ),
    }
}

fn resolve_active_antenna_stage_outputs(
    problem: &mut ProblemIR,
    published: &std::collections::BTreeMap<
        (String, String, String),
        fullmag_ir::AntennaFieldSolutionRefIR,
    >,
) -> Result<()> {
    let mut resolved_projection_ports = std::collections::BTreeMap::<&str, &str>::new();
    let mut resolved = Vec::new();
    let active_stage_id = problem
        .problem_meta
        .runtime_metadata
        .get("active_stage_id")
        .and_then(serde_json::Value::as_str);
    for drive in &problem.solved_antenna_drives {
        if !drive
            .activation
            .is_active_for(problem.study.kind(), active_stage_id)
        {
            continue;
        }
        if let Some(previous_port) =
            resolved_projection_ports.insert(&drive.projection_ref, &drive.port_mode_id)
        {
            if previous_port != drive.port_mode_id.as_str() {
                bail!(
                    "antenna projection '{}' is shared by active drives with different ports '{}' and '{}'",
                    drive.projection_ref,
                    previous_port,
                    drive.port_mode_id
                );
            }
        }
        let (projection_index, projection) = problem
            .antenna_target_projections
            .iter()
            .enumerate()
            .find(|(_, projection)| projection.id == drive.projection_ref)
            .ok_or_else(|| {
                anyhow!(
                    "solved antenna drive '{}' has no projection '{}'",
                    drive.id,
                    drive.projection_ref
                )
            })?;
        if let fullmag_ir::AntennaSolutionRefIR::StageOutput(
            fullmag_ir::AntennaStageOutputRefIR::StageOutput { stage_id, output_id },
        ) = &projection.solution
        {
            let reference = published
                .get(&(stage_id.clone(), output_id.clone(), drive.port_mode_id.clone()))
                .ok_or_else(|| anyhow!(
                    "antenna drive '{}' requires prior ready stage output '{}/{}' for port '{}'; forward, failed, or cancelled references are not executable",
                    drive.id, stage_id, output_id, drive.port_mode_id
                ))?;
            if reference.stage_id != *stage_id || reference.output_id != *output_id {
                bail!("antenna drive '{}' resolved an incompatible stage output", drive.id);
            }
            resolved.push((projection_index, reference.clone()));
        }
    }
    for (index, reference) in resolved {
        problem.antenna_target_projections[index].solution =
            fullmag_ir::AntennaSolutionRefIR::Published(reference);
    }
    Ok(())
}

fn resolve_antenna_spectrum_stage_outputs(
    problem: &mut ProblemIR,
    published: &std::collections::BTreeMap<
        (String, String, String),
        fullmag_ir::AntennaFieldSolutionRefIR,
    >,
) -> Result<()> {
    let mut resolved = Vec::new();
    for (index, request) in problem.antenna_spectrum_requests.iter().enumerate() {
        if let fullmag_ir::AntennaSolutionRefIR::StageOutput(
            fullmag_ir::AntennaStageOutputRefIR::StageOutput { stage_id, output_id },
        ) = &request.solution_ref
        {
            let stage = problem
                .antenna_field_solve_stages
                .iter()
                .find(|stage| stage.id == *stage_id)
                .ok_or_else(|| anyhow!("antenna spectrum request '{}' references missing solve stage '{}'", request.id, stage_id))?;
            let port_mode_id = request.port_mode_id.as_deref().or_else(|| {
                (stage.port_mode_ids.len() == 1).then(|| stage.port_mode_ids[0].as_str())
            }).ok_or_else(|| anyhow!("antenna spectrum request '{}' must select one port", request.id))?;
            let reference = published
                .get(&(stage_id.clone(), output_id.clone(), port_mode_id.to_string()))
                .ok_or_else(|| anyhow!(
                    "antenna spectrum request '{}' requires prior ready stage output '{}/{}' for port '{}'",
                    request.id, stage_id, output_id, port_mode_id
                ))?;
            if reference.stage_id != *stage_id || reference.output_id != *output_id {
                bail!("antenna spectrum request '{}' resolved an incompatible stage output", request.id);
            }
            resolved.push((index, reference.clone()));
        }
    }
    for (index, reference) in resolved {
        problem.antenna_spectrum_requests[index].solution_ref =
            fullmag_ir::AntennaSolutionRefIR::Published(reference);
    }
    Ok(())
}

/// Execute authored source-spectrum requests only from a published immutable
/// antenna field asset.  This is an analysis product, not a hidden field solve
/// and not a magnetization-response FFT.
fn collect_published_spectrum_files(root: &Path) -> Result<std::collections::BTreeSet<PathBuf>> {
    let mut pending = vec![PathBuf::new()];
    let mut files = std::collections::BTreeSet::new();
    while let Some(relative_dir) = pending.pop() {
        let directory = root.join(&relative_dir);
        for entry in fs::read_dir(&directory).with_context(|| {
            format!(
                "scan antenna source-spectrum directory {}",
                directory.display()
            )
        })? {
            let entry = entry?;
            let relative = relative_dir.join(entry.file_name());
            let file_type = entry.file_type()?;
            if file_type.is_dir() {
                pending.push(relative);
            } else if file_type.is_file() {
                files.insert(relative);
            } else {
                bail!(
                    "antenna source-spectrum output contains unsupported filesystem entry '{}'",
                    entry.path().display()
                );
            }
        }
    }
    Ok(files)
}

fn verify_existing_antenna_spectrum_output(
    final_dir: &Path,
    output_id: &str,
    normalized: &[(PathBuf, &fullmag_runner::AuxiliaryArtifact)],
    interrupt_requested: Option<&std::sync::atomic::AtomicBool>,
) -> Result<()> {
    if !final_dir.is_dir() {
        bail!(
            "antenna source-spectrum output '{}' already exists as a non-directory",
            output_id
        );
    }
    let expected_files = normalized
        .iter()
        .map(|(relative, _)| relative.clone())
        .collect::<std::collections::BTreeSet<_>>();
    let actual_files = collect_published_spectrum_files(final_dir)?;
    if actual_files != expected_files {
        bail!(
            "antenna source-spectrum output '{}' has a different published file set (expected {}, found {})",
            output_id,
            expected_files.len(),
            actual_files.len()
        );
    }
    let mut buffer = [0_u8; 64 * 1024];
    for (relative, artifact) in normalized {
        let existing = final_dir.join(relative);
        let mut file = fs::File::open(&existing)
            .with_context(|| format!("open existing antenna source-spectrum artifact {}", existing.display()))?;
        let mut offset = 0_usize;
        loop {
            if synthetic_interrupt_requested(interrupt_requested) {
                bail!("antenna source-spectrum stage was cancelled before reuse");
            }
            let count = file.read(&mut buffer)
                .with_context(|| format!("read existing antenna source-spectrum artifact {}", existing.display()))?;
            if count == 0 {
                break;
            }
            let end = offset.checked_add(count)
                .ok_or_else(|| anyhow!("existing antenna source-spectrum artifact exceeds addressable size"))?;
            if artifact.bytes.get(offset..end) != Some(&buffer[..count]) {
                bail!(
                    "antenna source-spectrum output '{}' already exists with different content at '{}'",
                    output_id,
                    relative.display()
                );
            }
            offset = end;
        }
        if offset != artifact.bytes.len() {
            bail!(
                "antenna source-spectrum output '{}' already exists with different content at '{}'",
                output_id,
                relative.display()
            );
        }
    }
    if synthetic_interrupt_requested(interrupt_requested) {
        bail!("antenna source-spectrum stage was cancelled before reuse");
    }
    Ok(())
}

fn verify_staged_antenna_spectrum_output(
    staging_dir: &Path,
    normalized: &[(PathBuf, &fullmag_runner::AuxiliaryArtifact)],
) -> Result<()> {
    let mut buffer = [0_u8; 64 * 1024];
    for (relative, artifact) in normalized {
        let path = staging_dir.join(relative);
        let mut file = fs::File::open(&path)
            .with_context(|| format!("open staged antenna spectrum artifact {}", path.display()))?;
        let mut offset = 0_usize;
        loop {
            let count = file.read(&mut buffer)?;
            if count == 0 {
                break;
            }
            let end = offset.checked_add(count).ok_or_else(|| {
                anyhow!("staged antenna spectrum artifact '{}' exceeds addressable size", relative.display())
            })?;
            if artifact.bytes.get(offset..end) != Some(&buffer[..count]) {
                bail!("staged antenna spectrum artifact '{}' differs from generated content", relative.display());
            }
            offset = end;
        }
        if offset != artifact.bytes.len() {
            bail!("staged antenna spectrum artifact '{}' has an incomplete payload", relative.display());
        }
    }
    Ok(())
}

fn publish_antenna_spectrum_artifacts_atomically(
    current_stage_artifact_dir: &Path,
    output_id: &str,
    artifacts: &[fullmag_runner::AuxiliaryArtifact],
    interrupt_requested: Option<&std::sync::atomic::AtomicBool>,
) -> Result<()> {
    publish_antenna_spectrum_artifacts_atomically_with_hook(
        current_stage_artifact_dir,
        output_id,
        artifacts,
        interrupt_requested,
        None,
    )
}

fn publish_antenna_spectrum_artifacts_atomically_with_hook(
    current_stage_artifact_dir: &Path,
    output_id: &str,
    artifacts: &[fullmag_runner::AuxiliaryArtifact],
    interrupt_requested: Option<&std::sync::atomic::AtomicBool>,
    before_rename: Option<&dyn Fn() -> Result<()>>,
) -> Result<()> {
    publish_antenna_artifacts_atomically(
        current_stage_artifact_dir, output_id, "source_spectra",
        &["spectrum.v2.json", "spectrum.v3.json"], artifacts, interrupt_requested, before_rename,
    )
}

fn publish_antenna_artifacts_atomically(
    current_stage_artifact_dir: &Path,
    output_id: &str,
    family: &str,
    manifest_names: &[&str],
    artifacts: &[fullmag_runner::AuxiliaryArtifact],
    interrupt_requested: Option<&std::sync::atomic::AtomicBool>,
    before_rename: Option<&dyn Fn() -> Result<()>>,
) -> Result<()> {
    let output_id_path = Path::new(output_id);
    if output_id.trim().is_empty()
        || output_id_path.components().count() != 1
        || !matches!(
            output_id_path.components().next(),
            Some(Component::Normal(_))
        )
    {
        bail!("antenna artifact output_id '{output_id}' must be one safe path component");
    }
    if artifacts.is_empty() {
        bail!("antenna artifact output '{output_id}' produced no artifacts");
    }
    let output_prefix = Path::new("antenna").join(family).join(output_id);
    let final_dir = current_stage_artifact_dir.join(&output_prefix);
    for ancestor in final_dir.ancestors() {
        match fs::symlink_metadata(ancestor) {
            Ok(metadata) if metadata.file_type().is_symlink() => bail!("antenna publication path contains a symbolic link"),
            Ok(_) => {},
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {},
            Err(error) => return Err(error.into()),
        }
    }
    let parent = final_dir
        .parent()
        .ok_or_else(|| anyhow!("antenna artifact output has no parent directory"))?;
    let mut normalized = Vec::with_capacity(artifacts.len());
    let mut seen = std::collections::BTreeSet::new();
    let mut has_manifest = false;
    for artifact in artifacts {
        let path = Path::new(&artifact.relative_path);
        let relative = path.strip_prefix(&output_prefix).map_err(|_| {
            anyhow!(
                "antenna artifact artifact '{}' is outside output '{}'",
                artifact.relative_path,
                output_id
            )
        })?;
        if relative.as_os_str().is_empty()
            || relative.components().any(|component| {
                matches!(
                    component,
                    Component::ParentDir | Component::RootDir | Component::Prefix(_)
                )
            })
        {
            bail!(
                "antenna artifact artifact '{}' has an unsafe relative path",
                artifact.relative_path
            );
        }
        if !seen.insert(relative.to_string_lossy().into_owned()) {
            bail!(
                "antenna artifact output '{}' contains duplicate artifact '{}'",
                output_id,
                relative.display()
            );
        }
        if manifest_names.iter().any(|name| relative == Path::new(name)) {
            has_manifest = true;
        }
        normalized.push((relative.to_path_buf(), artifact));
    }
    if !has_manifest {
        bail!(
            "antenna artifact output '{}' has no required manifest",
            output_id
        );
    }
    if synthetic_interrupt_requested(interrupt_requested) {
        bail!("antenna artifact stage was cancelled before publication");
    }

    if final_dir.exists() {
        return verify_existing_antenna_spectrum_output(
            &final_dir,
            output_id,
            &normalized,
            interrupt_requested,
        );
    }

    fs::create_dir_all(parent).with_context(|| {
        format!(
            "create antenna artifact publication directory {}",
            parent.display()
        )
    })?;
    let staging_dir = parent.join(format!(
        ".{output_id}.staging-{}-{}",
        std::process::id(),
        uuid::Uuid::new_v4().simple()
    ));
    fs::create_dir(&staging_dir).with_context(|| {
        format!(
            "create antenna artifact staging directory {}",
            staging_dir.display()
        )
    })?;
    let publish_result = (|| -> Result<()> {
        normalized.sort_by_key(|(relative, _)| manifest_names.iter().any(|name| relative == Path::new(name)));
        for (relative, artifact) in &normalized {
            let target = staging_dir.join(relative);
            if let Some(parent) = target.parent() {
                fs::create_dir_all(parent)?;
            }
            let mut file = fs::OpenOptions::new().write(true).create_new(true).open(&target)?;
            file.write_all(&artifact.bytes).with_context(|| {
                format!(
                    "write staged antenna artifact artifact {}",
                    target.display()
                )
            })?;
            file.sync_all()?;
        }
        if synthetic_interrupt_requested(interrupt_requested) {
            bail!("antenna artifact stage was cancelled before publication");
        }
        if let Some(before_rename) = before_rename {
            before_rename()?;
        }
        verify_staged_antenna_spectrum_output(&staging_dir, &normalized)?;
        if synthetic_interrupt_requested(interrupt_requested) {
            bail!("antenna artifact stage was cancelled before publication");
        }
        fs::rename(&staging_dir, &final_dir).with_context(|| {
            format!(
                "atomically publish antenna artifact output {}",
                final_dir.display()
            )
        })?;
        Ok(())
    })();
    if publish_result.is_err() {
        let _ = fs::remove_dir_all(&staging_dir);
        if final_dir.exists() && !synthetic_interrupt_requested(interrupt_requested) {
            return verify_existing_antenna_spectrum_output(
                &final_dir,
                output_id,
                &normalized,
                interrupt_requested,
            );
        }
    }
    publish_result
}

fn validate_antenna_spectrum_output_ids<'a>(
    requests: impl IntoIterator<Item = (&'a str, &'a str)>,
) -> Result<()> {
    let mut output_ids = std::collections::BTreeSet::new();
    for (request_id, output_id) in requests {
        if !output_ids.insert(output_id) {
            bail!("antenna source-spectrum output_id '{output_id}' is declared more than once");
        }
        let output_id_path = Path::new(output_id);
        if output_id.trim().is_empty()
            || output_id_path.components().count() != 1
            || !matches!(output_id_path.components().next(), Some(Component::Normal(_)))
        {
            bail!("antenna spectrum request '{request_id}' has an unsafe output_id");
        }
    }
    Ok(())
}

fn execute_antenna_spectrum_requests(
    problem: &ProblemIR,
    artifact_dir: &Path,
    current_stage_artifact_dir: &Path,
    interrupt_requested: Option<&std::sync::atomic::AtomicBool>,
) -> Result<()> {
    if problem.antenna_spectrum_requests.is_empty() {
        return Ok(());
    }
    validate_antenna_spectrum_output_ids(problem.antenna_spectrum_requests.iter()
        .map(|request| (request.id.as_str(), request.output_id.as_str())))?;
    let mut resolved_requests = Vec::with_capacity(problem.antenna_spectrum_requests.len());
    for (request_index, request) in problem.antenna_spectrum_requests.iter().enumerate() {
        if synthetic_interrupt_requested(interrupt_requested) {
            bail!("antenna source-spectrum stage was cancelled before request '{}'", request.id);
        }
        let reference = request.solution_ref.published().ok_or_else(|| anyhow!(
            "antenna spectrum request '{}' has an unresolved stage output '{}/{}'",
            request.id,
            request.solution_ref.stage_id(),
            request.solution_ref.output_id()
        ))?;
        let stage_index = problem
            .antenna_field_solve_stages
            .iter()
            .position(|stage| stage.id == request.solution_ref.stage_id())
            .ok_or_else(|| {
                anyhow!(
                    "antenna spectrum request '{}' references missing solve stage '{}'",
                    request.id,
                    request.solution_ref.stage_id()
                )
            })?;
        let stage = &problem.antenna_field_solve_stages[stage_index];
        let port_mode_id = request
            .port_mode_id
            .as_deref()
            .or_else(|| (stage.port_mode_ids.len() == 1).then(|| stage.port_mode_ids[0].as_str()))
            .ok_or_else(|| {
                anyhow!(
                    "antenna spectrum request '{}' must identify one port mode for dependency validation",
                    request.id
                )
            })?;
        let expected = current_antenna_solution_expectation(
            problem,
            &stage.id,
            port_mode_id,
            reference.clone(),
        )?;
        resolved_requests.push((request_index, stage_index, port_mode_id.to_owned(), expected));
    }
    for (request_index, stage_index, port_mode_id, expected) in resolved_requests {
        let request = &problem.antenna_spectrum_requests[request_index];
        let stage = &problem.antenna_field_solve_stages[stage_index];
        let reference = &expected.reference;
        if synthetic_interrupt_requested(interrupt_requested) {
            bail!("antenna source-spectrum stage was cancelled before request '{}'", request.id);
        }
        let asset = fullmag_runner::load_expected_antenna_field_solution(artifact_dir, &expected)
            .map_err(|error| {
                anyhow!(
                    "load current antenna solution asset '{}' for spectrum request '{}': {}",
                    reference.asset_id,
                    request.id,
                    error.message
                )
            })?;
        let output_dir = current_stage_artifact_dir
            .join("antenna/source_spectra")
            .join(&request.output_id);
        let equilibrium = request.equilibrium_ref.as_ref().map(|reference|
            fullmag_runner::load_verified_antenna_equilibrium(artifact_dir, reference)
                .map_err(|error| anyhow!("load accepted equilibrium for '{}': {}", request.id, error.message))
        ).transpose()?;
        // Transverse reuse is checked by the atomic publisher after recomputing
        // with the canonical full binding; the Cartesian cache remains v2.
        if equilibrium.is_none() && fullmag_runner::reusable_antenna_source_spectrum_output(
            &output_dir,
            request,
            &reference.output_id,
            &stage.source_object_id,
            &port_mode_id,
            &reference.content_digest,
            interrupt_requested,
        )
        .map_err(|error| anyhow!(
            "inspect cached antenna spectrum request '{}': {}",
            request.id,
            error.message
        ))? {
            continue;
        }
        let samples = fullmag_runner::load_antenna_field_solution_samples_for_spectrum(
            &asset.manifest_bytes,
            &asset.payloads,
            request,
        )
        .map_err(|error| {
            anyhow!(
                "load antenna spectrum source samples for request '{}': {}",
                request.id,
                error.message
            )
        })?;
        let spectrum = if let Some(context) = equilibrium.as_ref() {
            fullmag_runner::compute_antenna_source_spectrum_with_equilibrium(request, &samples, context, interrupt_requested)
        } else {
            fullmag_runner::compute_antenna_source_spectrum_artifact_interruptible(request, &samples, None, interrupt_requested)
        }
                .map_err(|error| {
                    anyhow!(
                        "compute antenna source spectrum request '{}': {}",
                        request.id,
                        error.message
                    )
                })?;
        let artifacts = fullmag_runner::antenna_source_spectrum_auxiliary_artifacts(&spectrum)
            .map_err(|error| {
                anyhow!(
                    "serialize antenna source-spectrum request '{}': {}",
                    request.id,
                    error.message
                )
            })?;
        fullmag_runner::verify_antenna_source_spectrum_auxiliary_artifacts(&artifacts)
            .map_err(|error| anyhow!(
                "verify antenna source-spectrum request '{}': {}",
                request.id,
                error.message
            ))?;
        publish_antenna_spectrum_artifacts_atomically(
            current_stage_artifact_dir,
            &request.output_id,
            &artifacts,
            interrupt_requested,
        )?;
    }
    Ok(())
}

#[derive(Debug, Clone)]
struct PreparedRemeshStageTransaction {
    stages: Vec<ResolvedScriptStage>,
    stage_execution_plans: Vec<ExecutionPlanIR>,
}

/// Prepare every stage and its execution plan on private candidate snapshots.
///
/// Callers must publish the returned snapshots only after this function succeeds. This
/// keeps a failure in marker validation, IR validation, or replanning from exposing a
/// partially updated mesh generation.
#[allow(clippy::too_many_arguments)]
fn prepare_remesh_stage_transaction(
    stages: &[ResolvedScriptStage],
    stage_execution_plans: &[ExecutionPlanIR],
    scene_problem_patch: Option<&SceneProblemPatch>,
    mesh: &fullmag_ir::MeshIR,
    hmax: f64,
    shared_domain_remesh: bool,
    region_markers: &[fullmag_ir::FemDomainRegionMarkerIR],
    object_region_markers: &[fullmag_ir::FemDomainRegionMarkerIR],
    adaptive_runtime_state: Option<&serde_json::Value>,
    first_stage_plan: Option<ExecutionPlanIR>,
    source_scene_revision: Option<u64>,
) -> Result<PreparedRemeshStageTransaction> {
    let mut candidate_stages = stages.to_vec();
    if let Some(revision) = source_scene_revision {
        for stage in &mut candidate_stages {
            stage.ir.problem_meta.runtime_metadata.insert(
                "mesh_source_scene_revision".to_string(),
                serde_json::json!(revision),
            );
        }
    }
    apply_remeshed_problem_snapshot_to_stages(
        &mut candidate_stages,
        scene_problem_patch,
        mesh,
        hmax,
        shared_domain_remesh,
        region_markers,
        object_region_markers,
        adaptive_runtime_state,
    )?;

    let mut candidate_stage_execution_plans = stage_execution_plans.to_vec();
    refresh_materialized_stage_execution_plans(
        &candidate_stages,
        &mut candidate_stage_execution_plans,
        first_stage_plan,
    )?;

    Ok(PreparedRemeshStageTransaction {
        stages: candidate_stages,
        stage_execution_plans: candidate_stage_execution_plans,
    })
}

fn current_fem_mesh_workspace(
    problem: &ProblemIR,
    mesh: &fullmag_ir::MeshIR,
    mesh_source: Option<&str>,
    fe_order: u32,
    hmax: f64,
    status: &str,
    adaptive_mesh: Option<&serde_json::Value>,
    adaptive_runtime_state: Option<&serde_json::Value>,
    quality_summary: Option<&crate::python_bridge::RemeshQualitySummary>,
    quality_data_artifact: Option<&crate::python_bridge::RemeshQualityDataArtifactRef>,
    mesh_statistics: Option<&serde_json::Value>,
    mesh_history: &[serde_json::Value],
) -> serde_json::Value {
    let mesh_bounds = fem_mesh_bbox(mesh);
    let (bounds_min, bounds_max, mesh_extent) = mesh_bounds
        .map(|(min, max)| {
            (
                Some(min),
                Some(max),
                Some([max[0] - min[0], max[1] - min[1], max[2] - min[2]]),
            )
        })
        .unwrap_or((None, None, None));
    let domain_frame = fem_domain_frame(problem, mesh_bounds);
    let world_extent = domain_frame
        .as_ref()
        .and_then(|frame| frame.effective_extent);
    let world_center = domain_frame
        .as_ref()
        .and_then(|frame| frame.effective_center);
    let world_extent_source = domain_frame
        .as_ref()
        .and_then(|frame| frame.effective_source.clone());
    let domain_mesh_mode = if mesh.element_markers.iter().any(|marker| *marker == 0) {
        "shared_domain_mesh_with_air"
    } else {
        "merged_magnetic_mesh"
    };

    let source_kind = match mesh_source {
        Some(source) if source.ends_with(".stl") => "stl_surface",
        Some(source)
            if source.ends_with(".step")
                || source.ends_with(".stp")
                || source.ends_with(".iges")
                || source.ends_with(".igs") =>
        {
            "cad_file"
        }
        Some(source)
            if source.ends_with(".msh")
                || source.ends_with(".vtk")
                || source.ends_with(".vtu")
                || source.ends_with(".xdmf")
                || source.ends_with(".json")
                || source.ends_with(".npz") =>
        {
            "prebuilt_mesh"
        }
        Some(_) => "external_source",
        None => "generated_inline_mesh",
    };
    let ram_estimate_gb = estimate_fem_dense_ram(mesh.nodes.len()) as f64 / 1e9;
    let available_ram_gb = available_system_ram_bytes() as f64 / 1e9;
    let readiness_status = if mesh.nodes.len() > 50_000 {
        "warning"
    } else if mesh.nodes.is_empty() {
        "idle"
    } else {
        "done"
    };
    let adaptive_settings = adaptive_mesh.and_then(|value| value.as_object());
    let adaptive_enabled = adaptive_settings
        .and_then(|settings| settings.get("enabled"))
        .and_then(|value| value.as_bool())
        .unwrap_or(false);
    let adaptive_policy = adaptive_settings
        .and_then(|settings| settings.get("policy"))
        .and_then(|value| value.as_str())
        .unwrap_or("manual");
    let adaptive_max_passes = adaptive_settings
        .and_then(|settings| settings.get("max_passes"))
        .and_then(|value| value.as_u64())
        .unwrap_or(0);
    let adaptive_indicator = adaptive_settings
        .and_then(|settings| settings.get("indicator"))
        .and_then(|value| value.as_str())
        .unwrap_or("geometric_only");
    let adaptive_target_quantity = adaptive_settings
        .and_then(|settings| settings.get("target_quantity"))
        .and_then(|value| value.as_str())
        .unwrap_or("auto");
    let adaptive_convergence_metric = adaptive_settings
        .and_then(|settings| settings.get("convergence_metric"))
        .and_then(|value| value.as_str())
        .unwrap_or("energy_delta");
    let adaptive_theta = adaptive_settings
        .and_then(|settings| settings.get("theta"))
        .and_then(|value| value.as_f64())
        .unwrap_or(0.3);
    let adaptive_h_min = adaptive_settings
        .and_then(|settings| settings.get("h_min"))
        .and_then(|value| value.as_f64());
    let adaptive_h_max = adaptive_settings
        .and_then(|settings| settings.get("h_max"))
        .and_then(|value| value.as_f64());
    let adaptive_error_tolerance = adaptive_settings
        .and_then(|settings| settings.get("error_tolerance"))
        .and_then(|value| value.as_f64())
        .unwrap_or(1e-3);
    let adaptive_runtime = adaptive_runtime_state.and_then(|value| value.as_object());
    let adaptive_pass_count = adaptive_runtime
        .and_then(|state| state.get("pass_count"))
        .and_then(|value| value.as_u64())
        .unwrap_or(0);
    let adaptive_convergence_status = adaptive_runtime
        .and_then(|state| state.get("convergence_status"))
        .and_then(|value| value.as_str())
        .map(ToOwned::to_owned)
        .unwrap_or_else(|| {
            if adaptive_enabled {
                "configured".to_string()
            } else {
                "idle".to_string()
            }
        });
    let adaptive_last_target_h_summary = adaptive_runtime
        .and_then(|state| state.get("last_target_h_summary"))
        .cloned()
        .or_else(|| adaptive_settings.cloned().map(serde_json::Value::Object));
    let adaptive_last_error_summary = adaptive_runtime
        .and_then(|state| state.get("last_error_summary"))
        .cloned();
    let adaptive_last_marking_summary = adaptive_runtime
        .and_then(|state| state.get("last_marking_summary"))
        .cloned();
    let adaptive_last_transfer_summary = adaptive_runtime
        .and_then(|state| state.get("last_transfer_summary"))
        .cloned();
    let adaptive_last_convergence_summary = adaptive_runtime
        .and_then(|state| state.get("last_convergence_summary"))
        .cloned();
    let supports_mesh_error_preview = adaptive_runtime
        .and_then(|state| state.get("last_error_summary"))
        .is_some();
    let supports_target_h_preview = adaptive_runtime
        .and_then(|state| state.get("last_target_h_summary"))
        .is_some();
    let mesh_time_seconds = mesh_history
        .last()
        .and_then(|entry| {
            entry
                .get("time_seconds")
                .or_else(|| entry.get("wall_time_seconds"))
                .or_else(|| entry.get("duration_seconds"))
        })
        .and_then(|value| value.as_f64());
    let quality_data_artifact_json =
        quality_data_artifact.and_then(|artifact| serde_json::to_value(artifact).ok());
    let has_quality_arrays = quality_data_artifact.is_some();

    serde_json::json!({
        "mesh_summary": {
            "mesh_id": format!("{}:{}:{}", mesh.mesh_name, mesh.nodes.len(), mesh.cell_count()),
            "mesh_name": mesh.mesh_name,
            "mesh_source": mesh_source,
            "backend": "fem",
            "source_kind": source_kind,
            "order": fe_order,
            "hmax": hmax,
            "node_count": mesh.nodes.len(),
            "element_count": mesh.cell_count(),
            "boundary_face_count": mesh.facet_count(),
            "bounds_min": bounds_min,
            "bounds_max": bounds_max,
            "mesh_extent": mesh_extent,
            "world_extent": world_extent,
            "world_center": world_center,
            "world_extent_source": world_extent_source,
            "domain_frame": domain_frame,
            "domain_mesh_mode": domain_mesh_mode,
            "generation_id": format!("{}:{}:{}", mesh.mesh_name, mesh.nodes.len(), mesh.cell_count()),
        },
        "mesh_quality_summary": quality_summary.map(|quality| serde_json::json!({
            "n_elements": quality.n_elements,
            "sicn_min": quality.sicn_min,
            "sicn_max": quality.sicn_max,
            "sicn_mean": quality.sicn_mean,
            "sicn_p5": quality.sicn_p5,
            "gamma_min": quality.gamma_min,
            "gamma_mean": quality.gamma_mean,
            "avg_quality": quality.avg_quality,
        })),
        "quality_data_artifact": quality_data_artifact_json,
        "mesh_statistics": mesh_statistics.cloned(),
        "mesh_cost_report": {
            "node_count": mesh.nodes.len(),
            "element_count": mesh.cell_count(),
            "boundary_face_count": mesh.facet_count(),
            "estimated_dense_ram_gb": ram_estimate_gb,
            "available_ram_gb": available_ram_gb,
            "time_seconds": mesh_time_seconds,
            "status": status,
        },
        "mesh_pipeline_status": [
            {"id": "import", "label": "Import", "status": "done", "detail": mesh_source.map(|source| source.to_string()).unwrap_or_else(|| "Inline/generated geometry".to_string())},
            {"id": "classify", "label": "Classify", "status": if source_kind == "stl_surface" { "done" } else { "idle" }, "detail": if source_kind == "stl_surface" { "Surface classification completed for STL import".to_string() } else { "No explicit surface classification stage".to_string() }},
            {"id": "generate", "label": "Generate", "status": if mesh.cells.is_empty() { "idle" } else { "done" }, "detail": format!("{} nodes, {} cells", mesh.nodes.len(), mesh.cell_count())},
            {"id": "optimize", "label": "Optimize", "status": "idle", "detail": "Optimization policy depends on remesh request".to_string()},
            {"id": "quality", "label": "Quality", "status": if quality_summary.is_some() { "done" } else { "idle" }, "detail": quality_summary.map(|quality| format!("SICN p5 {:.3}, gamma min {:.3}", quality.sicn_p5, quality.gamma_min)).unwrap_or_else(|| "Quality metrics not extracted yet".to_string())},
            {"id": "validation", "label": "Validation", "status": if mesh.cells.is_empty() { "warning" } else { "done" }, "detail": if mesh.cells.is_empty() { "Mesh has no cells".to_string() } else { "Mesh validated and ready for FEM plan lowering".to_string() }},
            {"id": "readiness", "label": "Solver Readiness", "status": readiness_status, "detail": format!("Estimated dense RAM {:.1} GB / {:.1} GB available · status {}", ram_estimate_gb, available_ram_gb, status)},
        ],
        "mesh_capabilities": {
            "has_volume_mesh": true,
            "has_quality_arrays": has_quality_arrays,
            "supports_adaptive_remesh": adaptive_enabled,
            "supports_compare_snapshots": true,
            "supports_size_field_remesh": true,
            "supports_edge_distance_fields": true,
            "supports_boundary_layers": true,
            "boundary_layer_status": "explicit_target_selectors_required",
            "supports_mesh_convergence_workflow": adaptive_enabled && adaptive_policy == "auto",
            "supports_mesh_error_preview": supports_mesh_error_preview,
            "supports_target_h_preview": supports_target_h_preview,
        },
        "mesh_adaptivity_state": {
            "enabled": adaptive_enabled,
            "policy": adaptive_policy,
            "indicator": adaptive_indicator,
            "target_quantity": adaptive_target_quantity,
            "convergence_metric": adaptive_convergence_metric,
            "theta": adaptive_theta,
            "h_min": adaptive_h_min,
            "h_max": adaptive_h_max,
            "error_tolerance": adaptive_error_tolerance,
            "pass_count": adaptive_pass_count,
            "max_passes": adaptive_max_passes,
            "convergence_status": adaptive_convergence_status,
            "last_target_h_summary": adaptive_last_target_h_summary,
            "last_error_summary": adaptive_last_error_summary,
            "last_marking_summary": adaptive_last_marking_summary,
            "last_transfer_summary": adaptive_last_transfer_summary,
            "last_convergence_summary": adaptive_last_convergence_summary,
        },
        "mesh_history": mesh_history,
    })
}

fn current_mesh_workspace(
    problem: &ProblemIR,
    plan: &ExecutionPlanIR,
    status: &str,
    quality_summary: Option<&crate::python_bridge::RemeshQualitySummary>,
    mesh_history: &[serde_json::Value],
) -> Option<serde_json::Value> {
    match &plan.backend_plan {
        BackendPlanIR::Fem(fem) => Some(current_fem_mesh_workspace(
            problem,
            &fem.mesh,
            fem.mesh_source.as_deref(),
            fem.fe_order,
            fem.hmax,
            status,
            problem.problem_meta.runtime_metadata.get("adaptive_mesh"),
            problem
                .problem_meta
                .runtime_metadata
                .get("adaptive_mesh_runtime_state"),
            quality_summary,
            None,
            None,
            mesh_history,
        )),
        BackendPlanIR::FemEigen(fem) => Some(current_fem_mesh_workspace(
            problem,
            &fem.mesh,
            fem.mesh_source.as_deref(),
            fem.fe_order,
            fem.hmax,
            status,
            problem.problem_meta.runtime_metadata.get("adaptive_mesh"),
            problem
                .problem_meta
                .runtime_metadata
                .get("adaptive_mesh_runtime_state"),
            quality_summary,
            None,
            None,
            mesh_history,
        )),
        BackendPlanIR::Fdm(fdm) => Some(current_fdm_mesh_workspace(fdm, status, mesh_history)),
        BackendPlanIR::FdmMultilayer(fdm) => Some(current_fdm_multilayer_mesh_workspace(
            fdm,
            status,
            mesh_history,
        )),
        _ => None,
    }
}

fn current_fdm_mesh_workspace(
    plan: &fullmag_ir::FdmPlanIR,
    status: &str,
    mesh_history: &[serde_json::Value],
) -> serde_json::Value {
    let certificate = plan.grid_certificate.as_ref();
    let counts = certificate
        .map(|certificate| certificate.counts)
        .unwrap_or(plan.grid.cells);
    let cell_size = certificate
        .map(|certificate| certificate.cell_m)
        .unwrap_or(plan.cell_size);
    let origin = certificate
        .map(|certificate| certificate.origin_m)
        .unwrap_or(plan.origin_m);
    let active_cells = certificate
        .map(|certificate| certificate.active_cells)
        .unwrap_or_else(|| {
            plan.active_mask
                .as_ref()
                .map(|mask| mask.iter().filter(|active| **active).count() as u64)
                .unwrap_or_else(|| {
                    plan.region_mask
                        .iter()
                        .filter(|marker| **marker != 0)
                        .count() as u64
                })
        });
    let fingerprint = certificate
        .map(|certificate| certificate.grid_fingerprint.clone())
        .unwrap_or_else(|| format!("fdm-grid-{}x{}x{}", counts[0], counts[1], counts[2]));
    fdm_mesh_workspace_value(
        "fdm",
        counts,
        cell_size,
        origin,
        active_cells,
        certificate.map(|certificate| certificate.estimated_bytes),
        fingerprint,
        status,
        mesh_history,
        true,
    )
}

fn current_fdm_multilayer_mesh_workspace(
    plan: &fullmag_ir::FdmMultilayerPlanIR,
    status: &str,
    mesh_history: &[serde_json::Value],
) -> serde_json::Value {
    let certificate = plan.grid_certificate.as_ref();
    let counts = certificate
        .map(|certificate| certificate.counts)
        .unwrap_or(plan.common_cells);
    let first_layer = plan.layers.first();
    let cell_size = certificate
        .map(|certificate| certificate.cell_m)
        .or_else(|| first_layer.map(|layer| layer.convolution_cell_size))
        .unwrap_or([0.0, 0.0, 0.0]);
    let origin = certificate
        .map(|certificate| certificate.origin_m)
        .or_else(|| first_layer.map(|layer| layer.convolution_origin))
        .unwrap_or([0.0, 0.0, 0.0]);
    let active_cells = certificate
        .map(|certificate| certificate.active_cells)
        .unwrap_or_else(|| {
            plan.layers
                .iter()
                .map(|layer| {
                    layer
                        .native_active_mask
                        .as_ref()
                        .map(|mask| mask.iter().filter(|active| **active).count() as u64)
                        .unwrap_or_else(|| {
                            layer
                                .native_grid
                                .iter()
                                .try_fold(1u64, |product, count| product.checked_mul(*count as u64))
                                .unwrap_or(0)
                        })
                })
                .sum()
        });
    let fingerprint = certificate
        .map(|certificate| certificate.grid_fingerprint.clone())
        .unwrap_or_else(|| format!("fdm-multilayer-{}x{}x{}", counts[0], counts[1], counts[2]));
    fdm_mesh_workspace_value(
        "fdm_multilayer",
        counts,
        cell_size,
        origin,
        active_cells,
        certificate.map(|certificate| certificate.estimated_bytes),
        fingerprint,
        status,
        mesh_history,
        false,
    )
}

fn fdm_mesh_workspace_value(
    backend: &str,
    counts: [u32; 3],
    cell_size: [f64; 3],
    origin: [f64; 3],
    active_cells: u64,
    estimated_bytes: Option<u64>,
    fingerprint: String,
    status: &str,
    mesh_history: &[serde_json::Value],
    supports_boundary_correction: bool,
) -> serde_json::Value {
    let total_cells = counts
        .iter()
        .try_fold(1u64, |product, count| product.checked_mul(*count as u64))
        .unwrap_or(0);
    let mesh_generation_id = format!("{backend}:{fingerprint}");
    let estimated_bytes = estimated_bytes.unwrap_or_else(|| {
        total_cells
            .saturating_mul(3)
            .saturating_mul(std::mem::size_of::<f64>() as u64)
    });
    serde_json::json!({
        "mesh_summary": {
            "mesh_id": mesh_generation_id,
            "mesh_name": format!("{backend}-structured-grid"),
            "backend": backend,
            "source_kind": "planner_resolved_structured_grid",
            "generation_id": mesh_generation_id,
            "grid": { "cells": counts },
            "cells": counts,
            "cell_size": cell_size,
            "cell_size_m": cell_size,
            "origin": origin,
            "origin_m": origin,
            "total_cells": total_cells,
            "active_cells": active_cells,
            "grid_fingerprint": fingerprint,
            "node_count": total_cells,
            "element_count": 0,
            "boundary_face_count": 0,
            "domain_mesh_mode": "structured_grid",
        },
        "mesh_quality_summary": null,
        "mesh_statistics": {
            "backend": backend,
            "total_cells": total_cells,
            "active_cells": active_cells,
            "mask_coverage": if total_cells > 0 { active_cells as f64 / total_cells as f64 } else { 0.0 },
        },
        "mesh_cost_report": {
            "total_cells": total_cells,
            "active_cells": active_cells,
            "estimated_bytes": estimated_bytes,
            "estimated_memory_mb": estimated_bytes as f64 / 1.0e6,
            "status": status,
        },
        "mesh_pipeline_status": [
            {"id": "grid", "label": "Grid", "status": if total_cells > 0 { "done" } else { "warning" }, "detail": format!("{} × {} × {} cells", counts[0], counts[1], counts[2])},
            {"id": "membership", "label": "Membership mask", "status": if active_cells > 0 { "done" } else { "warning" }, "detail": format!("{} active magnetic cells", active_cells)},
            {"id": "runtime", "label": "Runtime replan", "status": if status == "ready" || status == "awaiting_command" || status == "waiting_for_compute" { "done" } else { "active" }, "detail": "Execution plan and runtime are derived from the same committed scene snapshot"},
            {"id": "readiness", "label": "Solver readiness", "status": if total_cells > 0 { "done" } else { "warning" }, "detail": status},
        ],
        "mesh_capabilities": {
            "has_volume_mesh": false,
            "has_structured_grid": true,
            "has_membership_mask": active_cells > 0,
            "has_quality_arrays": false,
            "supports_adaptive_remesh": false,
            "supports_compare_snapshots": true,
            "supports_grid_replan": true,
            "supports_size_field_remesh": false,
            "supports_edge_distance_fields": false,
            "supports_boundary_layers": supports_boundary_correction,
            "supports_mesh_convergence_workflow": false,
            "supports_mesh_error_preview": false,
            "supports_target_h_preview": false,
        },
        "mesh_adaptivity_state": {
            "enabled": false,
            "policy": "manual",
            "convergence_status": "not_applicable",
        },
        "mesh_history": mesh_history,
    })
}

#[derive(Debug, Clone)]
struct CurrentMeshBuildOverlay {
    active_build: Option<serde_json::Value>,
    effective_airbox_target: Option<serde_json::Value>,
    effective_per_object_targets: Option<serde_json::Value>,
    last_build_summary: Option<serde_json::Value>,
    last_build_error: Option<String>,
    active_phase: Option<String>,
    progress_percent: Option<u8>,
    progress_label: Option<String>,
    attempt_index: Option<u64>,
    algorithm_3d: Option<String>,
    attempt_status: Option<String>,
    attempt_failure_reason: Option<String>,
    next_algorithm_3d: Option<String>,
    progress_kind: Option<String>,
    last_recoverable_attempt: Option<serde_json::Value>,
    phase_started_at: Instant,
    phase_durations_ms: Vec<(String, u64)>,
    failed: bool,
}

fn mesh_geometry_realization_json(mesh_options: &serde_json::Value) -> Option<serde_json::Value> {
    mesh_options
        .get("geometry_realization")
        .filter(|value| value.is_object())
        .cloned()
}

fn mesh_source_scene_revision(mesh_options: &serde_json::Value) -> Option<u64> {
    mesh_options
        .get("geometry_realization")
        .and_then(|value| value.get("source_scene_revision"))
        .and_then(serde_json::Value::as_u64)
        .or_else(|| {
            mesh_options
                .get("source_scene_revision")
                .and_then(serde_json::Value::as_u64)
        })
}

fn mesh_build_intent_json(
    mesh_target: &MeshCommandTarget,
    mesh_reason: &str,
    mesh_options: &serde_json::Value,
) -> serde_json::Value {
    let mut intent = match mesh_target {
        MeshCommandTarget::StudyDomain => serde_json::json!({
            "mode": if mesh_reason.contains("_all") { "all" } else { "selected" },
            "target": { "kind": "study_domain" },
        }),
        MeshCommandTarget::Airbox => serde_json::json!({
            "mode": "selected",
            "target": { "kind": "airbox" },
        }),
        MeshCommandTarget::ObjectMesh { object_id } => serde_json::json!({
            "mode": "selected",
            "target": { "kind": "object_mesh", "object_id": object_id },
        }),
        MeshCommandTarget::AdaptiveFollowup => serde_json::json!({
            "mode": "selected",
            "target": { "kind": "adaptive_followup" },
        }),
    };
    if let Some(realization) = mesh_geometry_realization_json(mesh_options) {
        if let Some(object) = intent.as_object_mut() {
            object.insert("geometry_realization".to_string(), realization);
        }
    }
    intent
}

fn mesh_build_stage_status(
    stage_id: &str,
    active_phase: Option<&str>,
    failed: bool,
) -> &'static str {
    let rank = |phase: &str| match phase {
        "queued" => 0,
        "materializing" => 1,
        "preparing_domain" => 2,
        "meshing" => 3,
        "postprocessing" => 4,
        "ready" => 5,
        _ => 0,
    };
    let current_rank = active_phase.map(rank).unwrap_or(0);
    let stage_rank = rank(stage_id);
    if failed && stage_rank == current_rank {
        return "warning";
    }
    if stage_rank < current_rank {
        return "done";
    }
    if stage_rank == current_rank {
        return if failed { "warning" } else { "active" };
    }
    "idle"
}

fn mesh_build_pipeline_status_json(
    active_phase: Option<&str>,
    failed: bool,
    failure_detail: Option<&str>,
    progress_percent: Option<u8>,
    progress_label: Option<&str>,
    active_elapsed_ms: Option<u64>,
    phase_durations_ms: &[(String, u64)],
    attempt_telemetry: Option<&CurrentMeshBuildOverlay>,
) -> serde_json::Value {
    let phase_details = [
        (
            "queued",
            "Queued",
            "Build request accepted and waiting for the next mesh pipeline step.",
        ),
        (
            "materializing",
            "Materializing Script",
            "Syncing the active scene back to canonical Python before remeshing.",
        ),
        (
            "preparing_domain",
            "Preparing Shared Domain",
            "Computing airbox/domain inputs, local sizing fields and the conformal FEM domain setup.",
        ),
        (
            "meshing",
            "Meshing",
            "Generating the tetrahedral mesh for the active shared domain.",
        ),
        (
            "postprocessing",
            "Post-Processing",
            "Collecting mesh quality, markers and runtime-ready mesh metadata.",
        ),
        (
            "ready",
            "Ready",
            "Mesh build completed and the viewport can now inspect the updated domain mesh.",
        ),
    ];
    serde_json::Value::Array(
        phase_details
            .iter()
            .map(|(id, label, detail)| {
                let status = mesh_build_stage_status(id, active_phase, failed);
                let resolved_detail = if failed && Some(*id) == active_phase {
                    failure_detail.unwrap_or("Mesh build failed before completion.")
                } else {
                    *detail
                };
                let mut phase = serde_json::json!({
                    "id": id,
                    "label": label,
                    "status": status,
                    "detail": resolved_detail,
                });
                if Some(*id) == active_phase {
                    if let Some(percent) = progress_percent {
                        phase["progress_percent"] = serde_json::json!(percent);
                    }
                    if let Some(label) = progress_label {
                        phase["progress_label"] = serde_json::json!(label);
                    }
                    if let Some(duration_ms) = active_elapsed_ms {
                        phase["duration_ms"] = serde_json::json!(duration_ms);
                    }
                    if let Some(telemetry) = attempt_telemetry {
                        if let Some(value) = telemetry.attempt_index {
                            phase["attempt_index"] = serde_json::json!(value);
                        }
                        if let Some(value) = telemetry.algorithm_3d.as_deref() {
                            phase["algorithm_3d"] = serde_json::json!(value);
                        }
                        if let Some(value) = telemetry.attempt_status.as_deref() {
                            phase["attempt_status"] = serde_json::json!(value);
                        }
                        if let Some(value) = telemetry.attempt_failure_reason.as_deref() {
                            phase["attempt_failure_reason"] = serde_json::json!(value);
                        }
                        if let Some(value) = telemetry.next_algorithm_3d.as_deref() {
                            phase["next_algorithm_3d"] = serde_json::json!(value);
                        }
                        if let Some(value) = telemetry.progress_kind.as_deref() {
                            phase["progress_kind"] = serde_json::json!(value);
                        }
                        if let Some(value) = telemetry.last_recoverable_attempt.as_ref() {
                            phase["last_recoverable_attempt"] = value.clone();
                        }
                    }
                } else if let Some((_, duration_ms)) = phase_durations_ms
                    .iter()
                    .find(|(phase_id, _)| phase_id == id)
                {
                    phase["duration_ms"] = serde_json::json!(duration_ms);
                }
                phase
            })
            .collect(),
    )
}

fn saturating_duration_millis_u64(duration: Duration) -> u64 {
    u64::try_from(duration.as_millis()).unwrap_or(u64::MAX)
}

fn transition_mesh_build_phase(overlay: &mut CurrentMeshBuildOverlay, next_phase: &str) {
    let now = Instant::now();
    if overlay.active_phase.as_deref() == Some(next_phase) {
        return;
    }
    if let Some(previous_phase) = overlay.active_phase.as_deref() {
        let duration_ms = saturating_duration_millis_u64(overlay.phase_started_at.elapsed());
        if let Some((_, previous_duration_ms)) = overlay
            .phase_durations_ms
            .iter_mut()
            .find(|(phase_id, _)| phase_id == previous_phase)
        {
            *previous_duration_ms = duration_ms;
        } else {
            overlay
                .phase_durations_ms
                .push((previous_phase.to_string(), duration_ms));
        }
    }
    overlay.active_phase = Some(next_phase.to_string());
    overlay.phase_started_at = now;
}

fn update_mesh_attempt_overlay_from_payload(
    overlay: &mut CurrentMeshBuildOverlay,
    kind: &str,
    payload: &serde_json::Value,
) -> bool {
    if kind != "mesh_build_phase" || payload.get("attempt_index").is_none() {
        return false;
    }
    let phase = payload
        .get("phase")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("meshing");
    transition_mesh_build_phase(overlay, phase);
    overlay.progress_percent = payload
        .get("progress_percent")
        .and_then(serde_json::Value::as_u64)
        .and_then(|value| u8::try_from(value).ok());
    overlay.progress_label = payload
        .get("progress_label")
        .and_then(serde_json::Value::as_str)
        .map(str::to_string);
    overlay.attempt_index = payload
        .get("attempt_index")
        .and_then(serde_json::Value::as_u64);
    overlay.algorithm_3d = payload
        .get("algorithm_3d")
        .and_then(serde_json::Value::as_str)
        .map(str::to_string);
    overlay.attempt_status = payload
        .get("attempt_status")
        .and_then(serde_json::Value::as_str)
        .map(str::to_string);
    overlay.attempt_failure_reason = payload
        .get("attempt_failure_reason")
        .and_then(serde_json::Value::as_str)
        .map(str::to_string);
    overlay.next_algorithm_3d = payload
        .get("next_algorithm_3d")
        .and_then(serde_json::Value::as_str)
        .map(str::to_string);
    overlay.progress_kind = payload
        .get("progress_kind")
        .and_then(serde_json::Value::as_str)
        .map(str::to_string);
    if overlay.attempt_status.as_deref() == Some("failed_recoverable") {
        overlay.last_recoverable_attempt = Some(serde_json::json!({
            "attempt_index": overlay.attempt_index,
            "algorithm_3d": overlay.algorithm_3d,
            "attempt_status": overlay.attempt_status,
            "attempt_failure_reason": overlay.attempt_failure_reason,
            "next_algorithm_3d": overlay.next_algorithm_3d,
            "progress_kind": overlay.progress_kind,
        }));
    }
    overlay.failed = false;
    true
}

fn gmsh_indeterminate_heartbeat(message: &str) -> bool {
    message.trim_start().starts_with("Gmsh: meshing active (")
}

fn remesh_progress_label(
    overlay: &CurrentMeshBuildOverlay,
    stage: RemeshTerminalProgress,
) -> String {
    match (overlay.attempt_index, overlay.algorithm_3d.as_deref()) {
        (Some(attempt_index), Some(algorithm)) if stage.percent.is_none() => {
            format!("Attempt {attempt_index} — {algorithm} — {}", stage.label)
        }
        _ => stage.label.to_string(),
    }
}

fn update_mesh_overlay_from_terminal_progress(
    overlay: &mut CurrentMeshBuildOverlay,
    stage: RemeshTerminalProgress,
) {
    let next_phase = match stage.label {
        "mesh ready" | "extracting quality metrics" | "extracting mesh data" => "postprocessing",
        "generating 3D mesh" | "meshing curves" | "meshing surfaces" | "meshing 3D volume"
        | "optimizing mesh" => "meshing",
        "accepted" => "queued",
        _ => "preparing_domain",
    };
    transition_mesh_build_phase(overlay, next_phase);
    overlay.progress_percent = stage.percent;
    overlay.progress_label = Some(remesh_progress_label(overlay, stage));
    if next_phase != "meshing" {
        overlay.attempt_index = None;
        overlay.algorithm_3d = None;
        overlay.attempt_status = None;
        overlay.attempt_failure_reason = None;
        overlay.next_algorithm_3d = None;
        overlay.progress_kind = None;
        overlay.last_recoverable_attempt = None;
    }
    overlay.failed = false;
}

fn overlay_mesh_workspace(
    mesh_workspace: &mut serde_json::Value,
    overlay: &CurrentMeshBuildOverlay,
) {
    if !mesh_workspace.is_object() {
        *mesh_workspace = serde_json::json!({});
    }
    let obj = mesh_workspace
        .as_object_mut()
        .expect("mesh workspace should be an object after initialization");
    obj.insert(
        "active_build".to_string(),
        overlay
            .active_build
            .clone()
            .map_or(serde_json::Value::Null, |mut value| {
                if let Some(object) = value.as_object_mut() {
                    if overlay.attempt_index.is_some() {
                        object.insert(
                            "runtime_attempt".to_string(),
                            serde_json::json!({
                                "attempt_index": overlay.attempt_index,
                                "algorithm_3d": overlay.algorithm_3d,
                                "attempt_status": overlay.attempt_status,
                                "attempt_failure_reason": overlay.attempt_failure_reason,
                                "next_algorithm_3d": overlay.next_algorithm_3d,
                                "progress_kind": overlay.progress_kind,
                            }),
                        );
                    }
                    if let Some(last_recoverable_attempt) =
                        overlay.last_recoverable_attempt.as_ref()
                    {
                        object.insert(
                            "last_recoverable_attempt".to_string(),
                            last_recoverable_attempt.clone(),
                        );
                    }
                }
                value
            }),
    );
    let effective_airbox_target = overlay
        .effective_airbox_target
        .clone()
        .or_else(|| obj.get("effective_airbox_target").cloned())
        .unwrap_or(serde_json::Value::Null);
    obj.insert(
        "effective_airbox_target".to_string(),
        effective_airbox_target,
    );
    let effective_per_object_targets = overlay
        .effective_per_object_targets
        .clone()
        .or_else(|| obj.get("effective_per_object_targets").cloned())
        .unwrap_or(serde_json::Value::Null);
    obj.insert(
        "effective_per_object_targets".to_string(),
        effective_per_object_targets,
    );
    let last_build_summary = overlay
        .last_build_summary
        .clone()
        .or_else(|| obj.get("last_build_summary").cloned())
        .unwrap_or(serde_json::Value::Null);
    obj.insert("last_build_summary".to_string(), last_build_summary);
    obj.insert(
        "last_build_error".to_string(),
        overlay
            .last_build_error
            .as_ref()
            .map(|value| serde_json::Value::String(value.clone()))
            .unwrap_or(serde_json::Value::Null),
    );
    obj.insert(
        "mesh_pipeline_status".to_string(),
        mesh_build_pipeline_status_json(
            overlay.active_phase.as_deref(),
            overlay.failed,
            overlay.last_build_error.as_deref(),
            overlay.progress_percent,
            overlay.progress_label.as_deref(),
            overlay
                .active_phase
                .as_ref()
                .map(|_| saturating_duration_millis_u64(overlay.phase_started_at.elapsed())),
            &overlay.phase_durations_ms,
            Some(overlay),
        ),
    );
}

fn completed_stage_indexes_from_records(stages: &[CurrentLiveStageExecutionRecord]) -> Vec<usize> {
    stages
        .iter()
        .enumerate()
        .filter_map(|(index, stage)| {
            matches!(stage.status.as_str(), "completed" | "skipped").then_some(index)
        })
        .collect()
}

fn stage_execution_from_records(
    stages: &[CurrentLiveStageExecutionRecord],
    active_stage_index: Option<usize>,
    active_stage_kind: Option<&str>,
    runtime_state: &str,
) -> CurrentLiveStageExecutionState {
    let total_stages = stages.len();
    let mut published_stages = if stages.is_empty() {
        vec![]
    } else {
        stages.to_vec()
    };
    if let Some(active_index) = active_stage_index.filter(|index| *index < total_stages) {
        published_stages[active_index].status = runtime_state.to_string();
    }
    let published_statuses = published_stages
        .iter()
        .map(|stage| stage.status.clone())
        .collect::<Vec<_>>();
    CurrentLiveStageExecutionState {
        total_stages,
        completed_stage_indexes: completed_stage_indexes_from_records(&published_stages),
        stages: published_stages,
        stage_statuses: published_statuses,
        active_stage_index,
        active_stage_kind: active_stage_kind.map(|kind| kind.to_string()),
        runtime_state: runtime_state.to_string(),
    }
}

fn mark_live_stage_execution_failed(
    stage_execution: &mut Option<CurrentLiveStageExecutionState>,
    completed_at_unix_ms: u128,
) {
    let Some(previous) = stage_execution.take() else {
        return;
    };
    let mut stages = previous.stages;
    let active_index = previous
        .active_stage_index
        .or_else(|| stages.iter().position(|stage| stage.status == "running"));
    if let Some(active_index) = active_index.and_then(|index| stages.get_mut(index)) {
        active_index.status = "failed".to_string();
        active_index.completed_at_unix_ms = Some(millis_to_u64(completed_at_unix_ms));
        active_index.progress_label = Some("failed".to_string());
        active_index.last_progress_unix_ms = Some(millis_to_u64(completed_at_unix_ms));
        active_index.parallel_execution = None;
    }
    *stage_execution = Some(stage_execution_from_records(&stages, None, None, "failed"));
}

fn preserve_completed_parallel_execution(
    next: &mut CurrentLiveStageExecutionState,
    previous: Option<&CurrentLiveStageExecutionState>,
    stage_index: usize,
) {
    if next
        .stages
        .get(stage_index)
        .is_none_or(|stage| stage.status != "completed")
    {
        return;
    }
    let Some(telemetry) = previous
        .and_then(|state| state.stages.get(stage_index))
        .and_then(|stage| stage.parallel_execution.clone())
    else {
        return;
    };
    if let Some(stage) = next.stages.get_mut(stage_index) {
        stage.parallel_execution = Some(telemetry);
    }
}

fn scripted_stage_execution_state(
    total_stages: usize,
    active_index: usize,
    active_stage_kind: &str,
    runtime_state: &str,
    command_id: Option<&str>,
    started_at_unix_ms: Option<u128>,
    completed_at_unix_ms: Option<u128>,
    artifact_ref: Option<String>,
    reason: Option<fullmag_ir::StageStopReason>,
    incoming_transition: Option<&StageTransitionMetadata>,
) -> CurrentLiveStageExecutionState {
    let mut stages = vec![
        CurrentLiveStageExecutionRecord {
            stage_id: None,
            antenna_solve_stage_id: None,
            kind: None,
            status: "pending".to_string(),
            command_id: None,
            mesh_generation_id: None,
            mesh_topology_fingerprint: None,
            mesh_revision: None,
            started_at_unix_ms: None,
            applied_step: None,
            completed_step: None,
            applied_time_seconds: None,
            segment_id: None,
            completed_at_unix_ms: None,
            reason: None,
            converged: false,
            artifact_refs: Vec::new(),
            checkpoint_ref: None,
            loaded_state_ref: None,
            resume_from_checkpoint_ref: None,
            state_transition: None,
            state_transition_kind: None,
            state_transition_reason: None,
            state_transfer_operator_kind: None,
            state_transition_ui_presentation: None,
            metric: None,
            metric_name: None,
            metric_value: None,
            threshold: None,
            progress_percent: None,
            progress_label: None,
            progress_detail: None,
            last_progress_unix_ms: None,
            current_field_m_t: None,
            current_point_index: None,
            current_settle_step_index: None,
            current_settle_step_kind: None,
            current_settle_step_method: None,
            parallel_execution: None,
        };
        total_stages
    ];

    for (index, stage) in stages.iter_mut().enumerate() {
        stage.stage_id = Some(format!("stage-{index:03}"));
    }
    for stage in stages.iter_mut().take(active_index) {
        stage.status = "completed".to_string();
    }

    if let Some(stage) = stages.get_mut(active_index) {
        stage.kind = Some(active_stage_kind.to_string());
        stage.status = runtime_state.to_string();
        stage.command_id = command_id.map(str::to_string);
        stage.started_at_unix_ms = started_at_unix_ms.map(millis_to_u64);
        stage.completed_at_unix_ms = completed_at_unix_ms.map(millis_to_u64);
        stage.reason = reason;
        if let Some(artifact_ref) = artifact_ref {
            push_unique_artifact_ref(&mut stage.artifact_refs, artifact_ref);
        }
        apply_stage_transition_metadata(stage, incoming_transition);
    }

    let is_intermediate_completion =
        runtime_state == "completed" && active_index + 1 < total_stages;
    let published_runtime_state = if is_intermediate_completion {
        "materializing"
    } else {
        runtime_state
    };
    let active_stage_index =
        matches!(published_runtime_state, "running" | "paused").then_some(active_index);
    let active_stage_kind = (!is_intermediate_completion).then_some(active_stage_kind);
    stage_execution_from_records(
        &stages,
        active_stage_index,
        active_stage_kind,
        published_runtime_state,
    )
}

fn scripted_stage_execution_state_with_completion(
    total_stages: usize,
    active_index: usize,
    active_stage_kind: &str,
    runtime_state: &str,
    command_id: Option<&str>,
    started_at_unix_ms: Option<u128>,
    completed_at_unix_ms: Option<u128>,
    artifact_ref: Option<String>,
    completion: Option<&fullmag_ir::StageCompletionIR>,
    incoming_transition: Option<&StageTransitionMetadata>,
) -> CurrentLiveStageExecutionState {
    let mut execution = scripted_stage_execution_state(
        total_stages,
        active_index,
        active_stage_kind,
        runtime_state,
        command_id,
        started_at_unix_ms,
        completed_at_unix_ms,
        artifact_ref,
        completion.and_then(|value| value.reason),
        incoming_transition,
    );
    if let Some(stage) = execution.stages.get_mut(active_index) {
        stage.reason = completion.and_then(|value| value.reason);
        stage.converged = completion.is_some_and(|value| value.converged);
        stage.metric = completion.and_then(|value| value.metric);
        stage.metric_name = completion.and_then(|value| value.metric_name.clone());
        stage.metric_value = completion.and_then(|value| value.metric_value);
        stage.threshold = completion.and_then(|value| value.threshold);
    }
    execution
}

fn attach_stage_antenna_solve_identity(
    execution: &mut CurrentLiveStageExecutionState,
    stage_index: usize,
    action: Option<&ResolvedScriptStageAction>,
) {
    let Some(record) = execution.stages.get_mut(stage_index) else {
        return;
    };
    record.antenna_solve_stage_id = match action {
        Some(ResolvedScriptStageAction::AntennaRetainedDirectInspection { plan }) => {
            Some(plan.stage.id.clone())
        }
        Some(ResolvedScriptStageAction::AntennaRetainedPreparationInspection { plan }) => {
            Some(plan.stage.id.clone())
        }
        Some(ResolvedScriptStageAction::AntennaRetainedCurrentInspection { plan }) => {
            Some(plan.stage.id.clone())
        }
        Some(ResolvedScriptStageAction::AntennaClosedLoopInspection { input, .. }) => {
            Some(input.stage.id.clone())
        }
        Some(ResolvedScriptStageAction::AntennaExternalLeadInspection { input, .. }) => {
            Some(input.stage.id.clone())
        }
        Some(ResolvedScriptStageAction::AntennaFieldSolve { stage_id, .. }) => {
            Some(stage_id.clone())
        }
        _ => None,
    };
}

fn attach_stage_fem_mesh_identity(
    execution: &mut CurrentLiveStageExecutionState,
    stage_index: usize,
    asset: Option<&fullmag_runner::StageFemMeshAsset>,
) {
    let (Some(record), Some(asset)) = (execution.stages.get_mut(stage_index), asset) else {
        return;
    };
    record.mesh_generation_id = Some(asset.identity.generation_id().to_string());
    record.mesh_topology_fingerprint = Some(fullmag_runner::fem_mesh_topology_fingerprint(
        &asset.payload,
    ));
}

fn publish_scripted_stages_awaiting_command(execution: &mut CurrentLiveStageExecutionState) {
    // Completed stages are history; the interactive owner still accepts commands.
    *execution = stage_execution_from_records(&execution.stages, None, None, "awaiting_command");
}

fn attach_scripted_stage_solver_steps(
    execution: &mut CurrentLiveStageExecutionState,
    stage_index: usize,
    boundary: Option<&CommandApplicationBoundary>,
    completed_step: Option<u64>,
) {
    let Some(record) = execution.stages.get_mut(stage_index) else {
        return;
    };
    record.applied_step = boundary.map(|boundary| boundary.applied_step);
    record.applied_time_seconds = boundary.map(|boundary| boundary.applied_time_seconds);
    record.segment_id = boundary.map(|boundary| boundary.segment_id.clone());
    record.completed_step = completed_step;
}

fn preserve_terminal_stage_history(
    next: &mut CurrentLiveStageExecutionState,
    previous: Option<&CurrentLiveStageExecutionState>,
) {
    let Some(previous) = previous else {
        return;
    };
    let active_index = next.active_stage_index.unwrap_or(next.total_stages);
    let limit = active_index
        .min(next.stages.len())
        .min(previous.stages.len());
    for index in 0..limit {
        if matches!(
            previous.stages[index].status.as_str(),
            "completed" | "skipped" | "cancelled" | "stopped" | "failed"
        ) {
            next.stages[index] = previous.stages[index].clone();
        }
    }
    let runtime_state = next.runtime_state.clone();
    let active_stage_index = next.active_stage_index;
    let active_stage_kind = next.active_stage_kind.clone();
    *next = stage_execution_from_records(
        &next.stages,
        active_stage_index,
        active_stage_kind.as_deref(),
        &runtime_state,
    );
}

fn apply_stage_transition_metadata(
    record: &mut CurrentLiveStageExecutionRecord,
    transition: Option<&StageTransitionMetadata>,
) {
    let Some(transition) = transition else {
        return;
    };
    record.state_transition = Some(transition.legacy_state_transition_label().to_string());
    record.state_transition_kind = Some(transition.kind);
    record.state_transition_reason = Some(transition.reason);
    record.state_transfer_operator_kind = transition.transfer_operator;
    record.state_transition_ui_presentation = Some(transition.ui_presentation);
}

#[cfg(test)]
fn stage_continues_in_place(stage: &ResolvedScriptStage) -> bool {
    stage
        .incoming_transition
        .as_ref()
        .is_some_and(|transition| transition.kind == StageTransitionKind::ContinueInPlace)
}

#[cfg(test)]
fn stage_allows_sampled_continuation_initial_state(stage: &ResolvedScriptStage) -> bool {
    !stage_continues_in_place(stage)
}

fn user_cancelled_stage_completion(status: &str) -> fullmag_ir::StageCompletionIR {
    fullmag_ir::StageCompletionIR {
        status: status.to_string(),
        converged: false,
        reason: Some(fullmag_ir::StageStopReason::UserCancelled),
        metric: None,
        metric_name: None,
        metric_value: None,
        threshold: None,
    }
}

fn stage_record(index: usize, kind: Option<&str>) -> CurrentLiveStageExecutionRecord {
    CurrentLiveStageExecutionRecord {
        stage_id: Some(format!("stage-{index:03}")),
        antenna_solve_stage_id: None,
        kind: kind.map(str::to_string),
        status: "pending".to_string(),
        command_id: None,
        mesh_generation_id: None,
        mesh_topology_fingerprint: None,
        mesh_revision: None,
        started_at_unix_ms: None,
        applied_step: None,
        completed_step: None,
        applied_time_seconds: None,
        segment_id: None,
        completed_at_unix_ms: None,
        reason: None,
        converged: false,
        artifact_refs: Vec::new(),
        checkpoint_ref: None,
        loaded_state_ref: None,
        resume_from_checkpoint_ref: None,
        state_transition: None,
        state_transition_kind: None,
        state_transition_reason: None,
        state_transfer_operator_kind: None,
        state_transition_ui_presentation: None,
        metric: None,
        metric_name: None,
        metric_value: None,
        threshold: None,
        progress_percent: None,
        progress_label: None,
        progress_detail: None,
        last_progress_unix_ms: None,
        current_field_m_t: None,
        current_point_index: None,
        current_settle_step_index: None,
        current_settle_step_kind: None,
        current_settle_step_method: None,
        parallel_execution: None,
    }
}

#[derive(Debug, Clone, PartialEq)]
struct CommandApplicationBoundary {
    applied_step: u64,
    applied_time_seconds: f64,
    segment_id: String,
}

impl CommandApplicationBoundary {
    fn new(run_id: &str, command_id: &str, applied_step: u64, applied_time_seconds: f64) -> Self {
        let time_bits = applied_time_seconds.to_bits();
        Self {
            applied_step,
            applied_time_seconds,
            segment_id: format!("segment:{run_id}:{command_id}:{applied_step}:{time_bits:016x}"),
        }
    }
}

#[derive(Clone)]
struct ActiveSequenceState {
    remaining_stages: Vec<fullmag_runner::SequenceStage>,
    current_stage_1based: usize,
    stages: Vec<CurrentLiveStageExecutionRecord>,
}

impl ActiveSequenceState {
    fn new(stages: Vec<fullmag_runner::SequenceStage>) -> Self {
        let total_stages = stages.len();
        let built_stages = (0..total_stages)
            .map(|index| {
                let kind = stages.get(index).map(|s| s.label());
                stage_record(index, kind)
            })
            .collect();
        Self {
            remaining_stages: stages,
            current_stage_1based: 1,
            stages: built_stages,
        }
    }

    fn single_current() -> Self {
        Self {
            remaining_stages: Vec::new(),
            current_stage_1based: 1,
            stages: vec![stage_record(0, Some("relax"))],
        }
    }

    fn mark_current_started(
        &mut self,
        command_id: &str,
        started_at_unix_ms: u128,
        artifact_ref: Option<String>,
        application_boundary: Option<&CommandApplicationBoundary>,
    ) {
        let current_index = self.current_stage_index();
        if current_index >= self.stages.len() {
            return;
        }

        let mut record = self.stages[current_index].clone();
        record.status = "running".to_string();
        record.command_id = Some(command_id.to_string());
        record.started_at_unix_ms = Some(millis_to_u64(started_at_unix_ms));
        record.applied_step = application_boundary.map(|boundary| boundary.applied_step);
        record.applied_time_seconds =
            application_boundary.map(|boundary| boundary.applied_time_seconds);
        record.segment_id = application_boundary.map(|boundary| boundary.segment_id.clone());
        record.completed_at_unix_ms = None;
        record.progress_percent = Some(5.0);
        record.progress_label = Some("starting".to_string());
        record.progress_detail = Some("stage accepted by runtime".to_string());
        record.last_progress_unix_ms = Some(millis_to_u64(started_at_unix_ms));
        if let Some(artifact_ref) = artifact_ref {
            push_unique_artifact_ref(&mut record.artifact_refs, artifact_ref);
        }
        self.stages[current_index] = record;
    }

    fn mark_current_fem_mesh_identity(
        &mut self,
        asset: Option<&fullmag_runner::StageFemMeshAsset>,
    ) {
        let current_index = self.current_stage_index();
        let Some(record) = self.stages.get_mut(current_index) else {
            return;
        };
        let Some(asset) = asset else {
            return;
        };
        record.mesh_generation_id = Some(asset.identity.generation_id().to_string());
        record.mesh_topology_fingerprint = Some(fullmag_runner::fem_mesh_topology_fingerprint(
            &asset.payload,
        ));
    }

    fn mark_current_checkpoint_preserved(
        &mut self,
        checkpoint_id: &str,
        artifact_ref: Option<String>,
    ) {
        let current_index = self.current_stage_index();
        if current_index >= self.stages.len() {
            return;
        }

        let mut record = self.stages[current_index].clone();
        record.checkpoint_ref = Some(checkpoint_id.to_string());
        record.state_transition = Some("preserved".to_string());
        record.state_transition_kind = Some(StageTransitionKind::SaveCheckpoint);
        record.state_transition_reason = Some(StageTransitionReason::UserExport);
        record.state_transfer_operator_kind = None;
        record.state_transition_ui_presentation = Some(StageTransitionUiPresentation::BoundaryBar);
        if let Some(artifact_ref) = artifact_ref {
            push_unique_artifact_ref(&mut record.artifact_refs, artifact_ref);
        }
        self.stages[current_index] = record;
    }

    fn mark_current_resume_from_checkpoint(&mut self, checkpoint_id: &str) {
        let current_index = self.current_stage_index();
        if current_index >= self.stages.len() {
            return;
        }

        let mut record = self.stages[current_index].clone();
        record.resume_from_checkpoint_ref = Some(checkpoint_id.to_string());
        record.state_transition = Some("restored".to_string());
        record.state_transition_kind = Some(StageTransitionKind::LoadState);
        record.state_transition_reason = Some(StageTransitionReason::CheckpointLoad);
        record.state_transfer_operator_kind = Some(StateTransferOperatorKind::CheckpointLoad);
        record.state_transition_ui_presentation = Some(StageTransitionUiPresentation::BoundaryBar);
        self.stages[current_index] = record;
    }

    fn total_stages(&self) -> usize {
        self.stages.len()
    }

    fn current_stage_index(&self) -> usize {
        self.current_stage_1based.saturating_sub(1)
    }

    fn mark_current_materialized_kind(&mut self, kind: &str) {
        let current_index = self.current_stage_index();
        if let Some(stage) = self.stages.get_mut(current_index) {
            stage.kind = Some(kind.to_string());
        }
    }

    fn mark_current(
        &mut self,
        status: &str,
        completion: Option<&fullmag_ir::StageCompletionIR>,
        completed_at_unix_ms: Option<u128>,
        artifact_ref: Option<String>,
    ) {
        let current_index = self.current_stage_index();
        if current_index < self.stages.len() {
            let previous = self.stages[current_index].clone();
            let mut artifact_refs = previous.artifact_refs;
            if let Some(artifact_ref) = artifact_ref {
                push_unique_artifact_ref(&mut artifact_refs, artifact_ref);
            }
            self.stages[current_index] = CurrentLiveStageExecutionRecord {
                stage_id: previous.stage_id,
                antenna_solve_stage_id: previous.antenna_solve_stage_id,
                kind: previous.kind,
                status: status.to_string(),
                command_id: previous.command_id,
                mesh_generation_id: previous.mesh_generation_id,
                mesh_topology_fingerprint: previous.mesh_topology_fingerprint,
                mesh_revision: previous.mesh_revision,
                started_at_unix_ms: previous.started_at_unix_ms,
                applied_step: previous.applied_step,
                completed_step: previous.completed_step,
                applied_time_seconds: previous.applied_time_seconds,
                segment_id: previous.segment_id,
                completed_at_unix_ms: completed_at_unix_ms
                    .map(millis_to_u64)
                    .or(previous.completed_at_unix_ms),
                reason: completion.and_then(|value| value.reason),
                converged: completion.is_some_and(|value| value.converged),
                artifact_refs,
                checkpoint_ref: previous.checkpoint_ref,
                loaded_state_ref: previous.loaded_state_ref,
                resume_from_checkpoint_ref: previous.resume_from_checkpoint_ref,
                state_transition: previous.state_transition,
                state_transition_kind: previous.state_transition_kind,
                state_transition_reason: previous.state_transition_reason,
                state_transfer_operator_kind: previous.state_transfer_operator_kind,
                state_transition_ui_presentation: previous.state_transition_ui_presentation,
                metric: completion.and_then(|value| value.metric),
                metric_name: completion.and_then(|value| value.metric_name.clone()),
                metric_value: completion.and_then(|value| value.metric_value),
                threshold: completion.and_then(|value| value.threshold),
                progress_percent: match status {
                    "completed" => Some(100.0),
                    "failed" | "cancelled" | "skipped" | "stopped" => previous.progress_percent,
                    _ => previous.progress_percent,
                },
                progress_label: match status {
                    "completed" => Some("completed".to_string()),
                    "failed" => Some("failed".to_string()),
                    "cancelled" => Some("cancelled".to_string()),
                    "skipped" => Some("skipped".to_string()),
                    "stopped" => Some("stopped".to_string()),
                    _ => previous.progress_label,
                },
                progress_detail: previous.progress_detail,
                last_progress_unix_ms: completed_at_unix_ms
                    .map(millis_to_u64)
                    .or(previous.last_progress_unix_ms),
                current_field_m_t: previous.current_field_m_t,
                current_point_index: previous.current_point_index,
                current_settle_step_index: previous.current_settle_step_index,
                current_settle_step_kind: previous.current_settle_step_kind,
                current_settle_step_method: previous.current_settle_step_method,
                parallel_execution: (status == "completed")
                    .then_some(previous.parallel_execution)
                    .flatten(),
            };
        }
    }

    fn advance(&mut self) {
        self.current_stage_1based += 1;
    }

    fn stage_execution(
        &self,
        active_stage_kind: Option<&str>,
        runtime_state: &str,
    ) -> CurrentLiveStageExecutionState {
        stage_execution_from_records(
            &self.stages,
            active_stage_kind.map(|_| self.current_stage_index()),
            active_stage_kind,
            runtime_state,
        )
    }

    fn completed_stage_execution(&self, runtime_state: &str) -> CurrentLiveStageExecutionState {
        stage_execution_from_records(&self.stages, None, None, runtime_state)
    }
}

fn discard_active_paused_stage_execution(
    active_sequence: &mut Option<ActiveSequenceState>,
    completed_at_unix_ms: u128,
) -> Option<CurrentLiveStageExecutionState> {
    finish_active_paused_stage_execution(active_sequence, "cancelled", completed_at_unix_ms)
}

fn finish_active_paused_stage_execution(
    active_sequence: &mut Option<ActiveSequenceState>,
    status: &str,
    completed_at_unix_ms: u128,
) -> Option<CurrentLiveStageExecutionState> {
    let Some(mut sequence) = active_sequence.take() else {
        return None;
    };
    let cancelled_completion = user_cancelled_stage_completion(status);
    sequence.mark_current(
        status,
        Some(&cancelled_completion),
        Some(completed_at_unix_ms),
        None,
    );
    Some(sequence.completed_stage_execution("awaiting_command"))
}

fn millis_to_u64(value: u128) -> u64 {
    value.min(u64::MAX as u128) as u64
}

fn push_unique_artifact_ref(artifact_refs: &mut Vec<String>, artifact_ref: String) {
    if !artifact_refs
        .iter()
        .any(|existing| existing == &artifact_ref)
    {
        artifact_refs.push(artifact_ref);
    }
}

#[derive(Debug, Clone)]
struct AdaptiveMeshSettings {
    enabled: bool,
    policy: String,
    indicator: String,
    target_quantity: String,
    convergence_metric: String,
    theta: f64,
    h_min: Option<f64>,
    h_max: Option<f64>,
    max_passes: u32,
    error_tolerance: f64,
}

fn adaptive_mesh_settings(problem: &ProblemIR) -> Option<AdaptiveMeshSettings> {
    let adaptive = problem
        .problem_meta
        .runtime_metadata
        .get("adaptive_mesh")?
        .as_object()?;
    Some(AdaptiveMeshSettings {
        enabled: adaptive
            .get("enabled")
            .and_then(|value| value.as_bool())
            .unwrap_or(true),
        policy: adaptive
            .get("policy")
            .and_then(|value| value.as_str())
            .unwrap_or("manual")
            .to_string(),
        indicator: adaptive
            .get("indicator")
            .and_then(|value| value.as_str())
            .unwrap_or("geometric_only")
            .to_string(),
        target_quantity: adaptive
            .get("target_quantity")
            .and_then(|value| value.as_str())
            .unwrap_or("auto")
            .to_string(),
        convergence_metric: adaptive
            .get("convergence_metric")
            .and_then(|value| value.as_str())
            .unwrap_or("energy_delta")
            .to_string(),
        theta: adaptive
            .get("theta")
            .and_then(|value| value.as_f64())
            .unwrap_or(0.3),
        h_min: adaptive.get("h_min").and_then(|value| value.as_f64()),
        h_max: adaptive.get("h_max").and_then(|value| value.as_f64()),
        max_passes: adaptive
            .get("max_passes")
            .and_then(|value| value.as_u64())
            .unwrap_or(5) as u32,
        error_tolerance: adaptive
            .get("error_tolerance")
            .and_then(|value| value.as_f64())
            .unwrap_or(1e-3),
    })
}

#[derive(Debug, Clone, Copy)]
struct RelaxationSolveSummary {
    energy_total: f64,
    max_torque_apm: f64,
    max_dm_dt: f64,
}

#[derive(Debug, Clone)]
struct AdaptiveConvergenceSummary {
    metric: String,
    delta: f64,
    tolerance: f64,
    converged: bool,
}

fn latest_relaxation_solve_summary(
    stage_result: &fullmag_runner::RunResult,
) -> Option<RelaxationSolveSummary> {
    stage_result
        .steps
        .last()
        .map(|step| RelaxationSolveSummary {
            energy_total: step.e_total,
            max_torque_apm: step.max_torque_Apm,
            max_dm_dt: step.max_dm_dt,
        })
}

fn adaptive_convergence_summary(
    metric: &str,
    tolerance: f64,
    previous: RelaxationSolveSummary,
    current: RelaxationSolveSummary,
) -> Result<AdaptiveConvergenceSummary, &'static str> {
    let (resolved_metric, delta) = match metric {
        "energy_delta" => {
            let denom = previous.energy_total.abs().max(1e-30);
            (
                "energy_delta".to_string(),
                (current.energy_total - previous.energy_total).abs() / denom,
            )
        }
        "max_torque_delta" => {
            let denom = previous.max_torque_apm.abs().max(1e-30);
            (
                "max_torque_delta".to_string(),
                (current.max_torque_apm - previous.max_torque_apm).abs() / denom,
            )
        }
        "solution_change" => {
            let denom = previous.max_dm_dt.abs().max(1e-30);
            (
                "solution_change".to_string(),
                (current.max_dm_dt - previous.max_dm_dt).abs() / denom,
            )
        }
        _ => return Err("unsupported_mesh_adaptivity_criterion"),
    };
    Ok(AdaptiveConvergenceSummary {
        metric: resolved_metric,
        delta,
        tolerance,
        converged: delta <= tolerance,
    })
}

fn resolve_adaptive_convergence_metric(metric: &str) -> Result<&'static str, &'static str> {
    match metric {
        "energy_delta" => Ok("energy_delta"),
        "max_torque_delta" => Ok("max_torque_delta"),
        "solution_change" => Ok("solution_change"),
        _ => Err("unsupported_mesh_adaptivity_criterion"),
    }
}

fn apply_current_fem_overrides(
    problem: &mut ProblemIR,
    mesh_override: Option<&fullmag_ir::MeshIR>,
    hmax_override: Option<f64>,
    adaptive_runtime_state: Option<&serde_json::Value>,
) {
    if let Some(mesh) = mesh_override {
        let fallback_region_markers = default_domain_region_markers(&problem.geometry.entries);
        if let Some(assets) = problem.geometry_assets.as_mut() {
            if let Some(domain_asset) = assets.fem_domain_mesh_asset.as_mut() {
                domain_asset.mesh = Some(mesh.clone());
                if domain_asset.region_markers.is_empty() {
                    domain_asset.region_markers = fallback_region_markers;
                }
            } else {
                for fem_asset in &mut assets.fem_mesh_assets {
                    fem_asset.mesh = Some(mesh.clone());
                }
            }
        }
    }

    if let Some(hmax) = hmax_override {
        let hints =
            problem
                .backend_policy
                .discretization_hints
                .get_or_insert(DiscretizationHintsIR {
                    fdm: None,
                    fem: None,
                    hybrid: None,
                });
        match hints.fem.as_mut() {
            Some(fem) => fem.hmax = hmax,
            None => {
                hints.fem = Some(FemHintsIR {
                    order: 1,
                    hmax,
                    mesh: None,
                    demag_solver_policy: None,
                });
            }
        }
    }

    match adaptive_runtime_state {
        Some(state) => {
            problem
                .problem_meta
                .runtime_metadata
                .insert("adaptive_mesh_runtime_state".to_string(), state.clone());
        }
        None => {
            problem
                .problem_meta
                .runtime_metadata
                .remove("adaptive_mesh_runtime_state");
        }
    }
}

fn continuation_state_trace(values: &[[f64; 3]]) -> String {
    let active = values
        .iter()
        .filter(|value| value.iter().any(|component| component.abs() > 0.0))
        .count();
    let max_transverse = values
        .iter()
        .map(|value| (value[1] * value[1] + value[2] * value[2]).sqrt())
        .fold(0.0, f64::max);
    format!(
        "vectors={} active={} max_transverse={:.6e}",
        values.len(),
        active,
        max_transverse
    )
}

fn trace_continuation_state(label: &str, values: &[[f64; 3]]) {
    if std::env::var_os("FULLMAG_TRACE_CONTINUATION").is_some() {
        eprintln!(
            "[fullmag] continuation {label}: {}",
            continuation_state_trace(values)
        );
    }
}

fn attach_region_realization_revisions(
    problem: &mut ProblemIR,
    precondition: Option<&RuntimeCommandPrecondition>,
) {
    let Some(precondition) = precondition else {
        return;
    };
    let revisions = [
        ("topology", precondition.region_topology_revision),
        ("membership", precondition.region_membership_revision),
        ("coefficients", precondition.region_coefficients_revision),
        ("initial_state", precondition.region_initial_state_revision),
    ];
    if revisions.iter().all(|(_, revision)| revision.is_none()) {
        return;
    }
    let complete = revisions.iter().all(|(_, revision)| revision.is_some());
    let mut tuple = serde_json::Map::new();
    tuple.insert("complete".to_string(), serde_json::Value::Bool(complete));
    for (lane, revision) in revisions {
        tuple.insert(
            lane.to_string(),
            revision.map_or(serde_json::Value::Null, serde_json::Value::from),
        );
    }
    problem.problem_meta.runtime_metadata.insert(
        "region_realization_revisions".to_string(),
        serde_json::Value::Object(tuple),
    );
}

fn renormalize_magnetization(values: &mut [[f64; 3]]) {
    for value in values {
        let norm = (value[0] * value[0] + value[1] * value[1] + value[2] * value[2]).sqrt();
        if norm > 0.0 {
            value[0] /= norm;
            value[1] /= norm;
            value[2] /= norm;
        } else {
            *value = [1.0, 0.0, 0.0];
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn maybe_execute_adaptive_relaxation_followup_passes(
    stage: &mut ResolvedScriptStage,
    execution_plan: &mut ExecutionPlanIR,
    stage_result: &mut fullmag_runner::RunResult,
    stage_fem_mesh_asset: &mut Option<fullmag_runner::StageFemMeshAsset>,
    live_workspace: &LocalLiveWorkspace,
    stage_index: usize,
    stage_count: usize,
    run_id: &str,
    session_id: &str,
    artifact_dir: &Path,
    current_stage_artifact_dir: &Path,
    field_every_n: u64,
    global_step_offset: u64,
    current_mesh_quality: &mut Option<crate::python_bridge::RemeshQualitySummary>,
    current_mesh_history: &mut Vec<serde_json::Value>,
    current_fem_mesh_override: &mut Option<fullmag_ir::MeshIR>,
    current_fem_hmax_override: &mut Option<f64>,
    current_adaptive_runtime_state: &mut Option<serde_json::Value>,
) -> Result<bool> {
    let Some(settings) = adaptive_mesh_settings(&stage.ir) else {
        return Ok(false);
    };
    if !settings.enabled || settings.policy != "auto" || settings.max_passes == 0 {
        return Ok(false);
    }
    if let Some(reason) = adaptive_remesh_backend_legality_reason(&execution_plan.backend_plan) {
        return Err(anyhow!(
            "{reason}: generic adaptive remeshing cannot preserve the non-overlapping shared magnetic-domain and airbox topology"
        ));
    }
    if let Some(reason) = adaptive_remesh_legality_reason(&stage.ir) {
        return Err(anyhow!(
            "{reason}: adaptive FEM remesh requires a certified region/PBC candidate transaction"
        ));
    }
    if !matches!(stage.ir.study, fullmag_ir::StudyIR::Relaxation { .. }) {
        live_workspace.push_log(
            "warning",
            "Adaptive mesh auto policy is currently implemented only for FEM relaxation stages",
        );
        return Ok(false);
    }
    if stage.ir.geometry.entries.len() != 1 {
        live_workspace.push_log(
            "warning",
            "Adaptive mesh auto policy currently requires exactly one geometry entry",
        );
        return Ok(false);
    }
    if !matches!(stage_result.status, fullmag_runner::RunStatus::Completed) {
        return Ok(false);
    }
    let runtime_engine = fullmag_runner::resolve_runtime_engine(&stage.ir)
        .map_err(|error| anyhow!(error.message))?;
    if runtime_engine.engine_id != "fem_cpu_native" {
        live_workspace.push_log(
            "warning",
            format!(
                "Adaptive mesh auto policy is currently limited to FEM CPU-native runtime; current engine is {}",
                runtime_engine.engine_label
            ),
        );
        return Ok(false);
    }
    let resolved_convergence_metric =
        resolve_adaptive_convergence_metric(&settings.convergence_metric).map_err(|reason| {
            anyhow!(
                "{reason}: no estimator is available for convergence metric '{}'",
                settings.convergence_metric
            )
        })?;

    let geometry_entry = stage
        .ir
        .geometry
        .entries
        .first()
        .cloned()
        .ok_or_else(|| anyhow!("adaptive FEM remesh requires a geometry entry"))?;
    let mut afem_history = fullmag_engine::fem_afem_loop::AfemHistory::new();
    let mut remesh_pass_count = 0u32;
    let mut local_step_offset = stage_result.steps.last().map(|step| step.step).unwrap_or(0);
    let mut physical_end_time_s = stage_result
        .steps
        .last()
        .map(|step| step.time)
        .unwrap_or(stage.ir.problem_meta.runtime_metadata
            .get("stage_start_time_s")
            .and_then(serde_json::Value::as_f64)
            .unwrap_or(0.0));
    let mut mutated = false;
    let mut previous_solve_summary: Option<RelaxationSolveSummary> = None;
    let torque_mode = torque_display_mode(&stage.ir);
    let indicator_effective = match settings.indicator.as_str() {
        "geometric_only" | "micromagnetics_hybrid" | "magnetostatic_potential" => {
            settings.indicator.clone()
        }
        unsupported => {
            live_workspace.push_log(
                "warning",
                format!(
                    "Adaptive indicator '{}' is unsupported for FEM relaxation auto follow-up; supported: geometric_only, micromagnetics_hybrid, magnetostatic_potential",
                    unsupported
                ),
            );
            return Ok(false);
        }
    };

    while remesh_pass_count < settings.max_passes {
        let fem_plan = match &execution_plan.backend_plan {
            BackendPlanIR::Fem(plan) => plan.clone(),
            _ => break,
        };
        let current_solve_summary = latest_relaxation_solve_summary(stage_result);
        let convergence_summary = previous_solve_summary
            .zip(current_solve_summary)
            .map(|(previous, current)| {
                adaptive_convergence_summary(
                    resolved_convergence_metric,
                    settings.error_tolerance,
                    previous,
                    current,
                )
            })
            .transpose()
            .map_err(|reason| anyhow!("{reason}"))?;
        if let Some(summary) = convergence_summary.as_ref() {
            if summary.converged {
                let current_runtime_state = serde_json::json!({
                    "pass_count": remesh_pass_count,
                    "max_passes": settings.max_passes,
                    "convergence_status": "converged_by_metric",
                    "indicator_effective": indicator_effective.as_str(),
                    "target_quantity": settings.target_quantity.as_str(),
                    "convergence_metric": settings.convergence_metric.as_str(),
                    "last_convergence_summary": {
                        "metric": summary.metric,
                        "delta": summary.delta,
                        "tolerance": summary.tolerance,
                        "converged": summary.converged,
                    },
                });
                stage.ir.problem_meta.runtime_metadata.insert(
                    "adaptive_mesh_runtime_state".to_string(),
                    current_runtime_state.clone(),
                );
                *current_adaptive_runtime_state = Some(current_runtime_state);
                live_workspace.update(|state| {
                    state.mesh_workspace = current_mesh_workspace(
                        &stage.ir,
                        execution_plan,
                        "running",
                        current_mesh_quality.as_ref(),
                        current_mesh_history,
                    );
                });
                live_workspace.push_log(
                    "info",
                    format!(
                        "Adaptive follow-up converged by {}: delta={:.3e} <= {:.3e}",
                        summary.metric, summary.delta, summary.tolerance
                    ),
                );
                break;
            }
        }
        let topo = fullmag_engine::fem::MeshTopology::from_ir(&fem_plan.mesh)
            .map_err(|error| anyhow!("adaptive mesh topology build failed: {error}"))?;
        let afem_config = fullmag_engine::fem_afem_loop::AfemConfig {
            tolerance: settings.error_tolerance,
            max_iterations: settings.max_passes,
            theta: settings.theta,
            h_min: settings.h_min.unwrap_or((fem_plan.hmax * 0.25).max(1e-12)),
            h_max: settings.h_max.unwrap_or(fem_plan.hmax),
            grad_limit: 1.3,
            max_mark_fraction: 0.8,
            ..Default::default()
        };
        let afem_step = match indicator_effective.as_str() {
            "geometric_only" | "micromagnetics_hybrid" => {
                fullmag_engine::fem_afem_loop::afem_step_vector_field(
                    &topo,
                    &stage_result.final_magnetization,
                    &afem_config,
                    &mut afem_history,
                )
            }
            "magnetostatic_potential" => {
                let observables = fullmag_runner::fem_observables_for_magnetization(
                    &fem_plan,
                    &stage_result.final_magnetization,
                )
                .map_err(|error| {
                    anyhow!("magnetostatic indicator observe failed: {}", error.message)
                })?;
                fullmag_engine::fem_afem_loop::afem_step_vector_field(
                    &topo,
                    &observables.demag_field,
                    &afem_config,
                    &mut afem_history,
                )
            }
            _ => fullmag_engine::fem_afem_loop::afem_step_vector_field(
                &topo,
                &stage_result.final_magnetization,
                &afem_config,
                &mut afem_history,
            ),
        }
        .map_err(|error| anyhow!("adaptive AFEM step failed: {error}"))?;

        let target_h_min = afem_step
            .size_field
            .h_target
            .iter()
            .copied()
            .reduce(f64::min)
            .unwrap_or(afem_config.h_max);
        let target_h_max = afem_step
            .size_field
            .h_target
            .iter()
            .copied()
            .reduce(f64::max)
            .unwrap_or(afem_config.h_max);
        let target_h_mean = if afem_step.size_field.h_target.is_empty() {
            afem_config.h_max
        } else {
            afem_step.size_field.h_target.iter().sum::<f64>()
                / afem_step.size_field.h_target.len() as f64
        };
        let convergence_status = match afem_step.stop_reason {
            fullmag_engine::fem_afem_loop::StopReason::Continue
                if afem_step.marking.n_marked > 0 =>
            {
                "remesh_requested"
            }
            fullmag_engine::fem_afem_loop::StopReason::Continue => "stable",
            fullmag_engine::fem_afem_loop::StopReason::Converged => "converged",
            fullmag_engine::fem_afem_loop::StopReason::MaxIterations => "max_passes_reached",
            fullmag_engine::fem_afem_loop::StopReason::MaxElements => "max_elements_reached",
            fullmag_engine::fem_afem_loop::StopReason::Stagnation => "stagnated",
        };
        let adaptive_runtime_state = serde_json::json!({
            "pass_count": remesh_pass_count,
            "max_passes": settings.max_passes,
            "convergence_status": convergence_status,
            "indicator_effective": indicator_effective.as_str(),
            "target_quantity": settings.target_quantity.as_str(),
            "convergence_metric": settings.convergence_metric.as_str(),
            "last_target_h_summary": {
                "h_target_min": target_h_min,
                "h_target_mean": target_h_mean,
                "h_target_max": target_h_max,
                "gradation_iterations": afem_step.size_field.gradation_iterations,
                "recommended_action": if matches!(afem_step.stop_reason, fullmag_engine::fem_afem_loop::StopReason::Continue) && afem_step.marking.n_marked > 0 { "remesh" } else { "stop" },
            },
            "last_error_summary": {
                "eta_global": afem_step.indicators.eta_global,
                "eta_max": afem_step.indicators.eta.iter().copied().reduce(f64::max).unwrap_or(0.0),
            },
            "last_marking_summary": {
                "n_marked": afem_step.marking.n_marked,
                "fraction_marked": afem_step.marking.fraction_marked,
                "captured_error_fraction": afem_step.marking.captured_error_fraction,
            },
            "last_convergence_summary": convergence_summary.as_ref().map(|summary| serde_json::json!({
                "metric": summary.metric,
                "delta": summary.delta,
                "tolerance": summary.tolerance,
                "converged": summary.converged,
            })),
        });
        stage.ir.problem_meta.runtime_metadata.insert(
            "adaptive_mesh_runtime_state".to_string(),
            adaptive_runtime_state.clone(),
        );
        *current_adaptive_runtime_state = Some(adaptive_runtime_state);
        live_workspace.update(|state| {
            state.mesh_workspace = current_mesh_workspace(
                &stage.ir,
                execution_plan,
                "running",
                current_mesh_quality.as_ref(),
                current_mesh_history,
            );
        });

        if !matches!(
            afem_step.stop_reason,
            fullmag_engine::fem_afem_loop::StopReason::Continue
        ) || afem_step.marking.n_marked == 0
        {
            live_workspace.push_log(
                "info",
                format!(
                    "Adaptive mesh pass {} reached status '{}' (eta={:.3e}, marked={})",
                    remesh_pass_count,
                    convergence_status,
                    afem_step.indicators.eta_global,
                    afem_step.marking.n_marked
                ),
            );
            break;
        }

        let remesh_hmax = settings.h_max.unwrap_or(fem_plan.hmax);
        live_workspace.push_log(
            "system",
            format!(
                "Adaptive mesh pass {} — eta={:.3e}, marked {} elements, remeshing",
                remesh_pass_count + 1,
                afem_step.indicators.eta_global,
                afem_step.marking.n_marked
            ),
        );
        previous_solve_summary = current_solve_summary;
        let remesh_result = invoke_adaptive_remesh_full(
            &geometry_entry,
            remesh_hmax,
            fem_plan.fe_order,
            &serde_json::json!({
                "compute_quality": true,
                "per_element_quality": false,
            }),
            &serde_json::json!({
                "node_coords": fem_plan.mesh.nodes,
                "h_values": afem_step.nodal_h,
            }),
            None,
        )?;
        let new_mesh = remesh_result.clone().into_mesh_ir();
        let new_topo = fullmag_engine::fem::MeshTopology::from_ir(&new_mesh)
            .map_err(|error| anyhow!("new adaptive mesh topology failed: {error}"))?;
        let transfer = fullmag_engine::fem_solution_transfer::transfer_vector_field(
            &topo,
            &stage_result.final_magnetization,
            &new_topo,
        );
        let mut transferred_magnetization = transfer.values;
        renormalize_magnetization(&mut transferred_magnetization);

        remesh_pass_count += 1;
        let remeshed_runtime_state = serde_json::json!({
            "pass_count": remesh_pass_count,
            "max_passes": settings.max_passes,
            "convergence_status": "remeshed",
            "indicator_effective": indicator_effective.as_str(),
            "target_quantity": settings.target_quantity.as_str(),
            "convergence_metric": settings.convergence_metric.as_str(),
            "last_target_h_summary": {
                "h_target_min": target_h_min,
                "h_target_mean": target_h_mean,
                "h_target_max": target_h_max,
                "gradation_iterations": afem_step.size_field.gradation_iterations,
                "recommended_action": "rerun_relaxation",
            },
            "last_error_summary": {
                "eta_global": afem_step.indicators.eta_global,
                "eta_max": afem_step.indicators.eta.iter().copied().reduce(f64::max).unwrap_or(0.0),
            },
            "last_marking_summary": {
                "n_marked": afem_step.marking.n_marked,
                "fraction_marked": afem_step.marking.fraction_marked,
                "captured_error_fraction": afem_step.marking.captured_error_fraction,
            },
            "last_transfer_summary": {
                "n_total": transfer.n_total,
                "n_located": transfer.n_located,
                "n_nearest_fallback": transfer.n_nearest_fallback,
            },
            "last_convergence_summary": convergence_summary.as_ref().map(|summary| serde_json::json!({
                "metric": summary.metric,
                "delta": summary.delta,
                "tolerance": summary.tolerance,
                "converged": summary.converged,
            })),
        });
        let mut candidate_stage = stage.clone();
        apply_current_fem_overrides(
            &mut candidate_stage.ir,
            Some(&new_mesh),
            Some(remesh_hmax),
            Some(&remeshed_runtime_state),
        );
        apply_continuation_initial_state(&mut candidate_stage.ir, &transferred_magnetization)?;
        candidate_stage.ir.problem_meta.runtime_metadata.insert(
            "stage_start_time_s".to_string(),
            serde_json::json!(physical_end_time_s),
        );

        let candidate_execution_plan =
            fullmag_plan::plan(&candidate_stage.ir).map_err(|error| anyhow!(error.to_string()))?;
        let remeshed_mesh_asset = fullmag_runner::StageFemMeshAsset::build_from_backend_plan(
            &candidate_execution_plan.backend_plan,
        )
        .ok_or_else(|| anyhow!("adaptive FEM replan did not produce an exact FEM mesh payload"))?;
        let mesh_payload = remeshed_mesh_asset.payload.clone();

        // Commit only after transfer, marker propagation, IR validation and replanning succeed.
        *stage = candidate_stage;
        *execution_plan = candidate_execution_plan;
        mutated = true;
        *current_mesh_quality = remesh_result.quality.clone();
        *current_fem_mesh_override = Some(new_mesh.clone());
        *current_fem_hmax_override = Some(remesh_hmax);
        *current_adaptive_runtime_state = Some(remeshed_runtime_state.clone());
        current_mesh_history.push(serde_json::json!({
            "mesh_name": new_mesh.mesh_name,
            "generation_mode": remesh_result.generation_mode,
            "node_count": new_mesh.nodes.len(),
            "element_count": new_mesh.cell_count(),
            "boundary_face_count": new_mesh.facet_count(),
            "kind": "adaptive_pass",
            "adaptive_pass": remesh_pass_count,
            "quality": remesh_result.quality.as_ref().map(|quality| serde_json::json!({
                "sicn_p5": quality.sicn_p5,
                "gamma_min": quality.gamma_min,
                "avg_quality": quality.avg_quality,
            })),
            "mesh_provenance": remesh_result.mesh_provenance,
            "size_field_stats": remesh_result.size_field_stats,
        }));
        live_workspace.update(|state| {
            state.metadata = Some(current_live_metadata(&stage.ir, execution_plan, "running"));
            state.live_state.latest_step.fem_mesh_generation_id =
                mesh_payload.generation_id.clone();
            state.fem_mesh = Some(mesh_payload);
            state.live_state.latest_step.magnetization =
                Some(flatten_magnetization(&transferred_magnetization));
            state.mesh_workspace = current_mesh_workspace(
                &stage.ir,
                execution_plan,
                "running",
                current_mesh_quality.as_ref(),
                current_mesh_history,
            );
            clear_cached_preview_fields(state);
        });
        live_workspace.push_log(
            "success",
            format!(
                "Adaptive remesh {} complete — {} nodes, {} elements (transfer fallback: {})",
                remesh_pass_count,
                new_mesh.nodes.len(),
                new_mesh.cell_count(),
                transfer.n_nearest_fallback
            ),
        );

        let pass_output_dir =
            current_stage_artifact_dir.join(format!("adaptive_pass_{:02}", remesh_pass_count));
        fs::create_dir_all(&pass_output_dir)?;
        let adaptive_pass_label = format!("adaptive remesh pass {}", remesh_pass_count);
        let mut adaptive_initial_update = initial_step_update(
            &execution_plan.backend_plan,
            Some(remeshed_mesh_asset.identity.generation_id().to_string()),
        );
        adaptive_initial_update.stats.step += global_step_offset + local_step_offset;
        adaptive_initial_update.stats.time = physical_end_time_s;
        let mut stage_heartbeat = Some(StageProgressHeartbeat::spawn(
            adaptive_initial_update,
            live_workspace.clone(),
            run_id.to_string(),
            session_id.to_string(),
            artifact_dir.to_path_buf(),
            adaptive_pass_label.clone(),
            adaptive_pass_label,
            torque_mode,
        ));
        let mut live_cadence = LiveProgressCadence::default();
        let pass_result = fullmag_runner::run_planned_problem_with_callback_and_fem_mesh_identity(
            &stage.ir,
            execution_plan,
            Some(&remeshed_mesh_asset.identity),
            stage.until_seconds,
            &pass_output_dir,
            field_every_n,
            |update| {
                let callback_start = solver_profile_callback_start(live_workspace);
                let _callback_nvtx = nvtx_range::Range::new(b"fem.host.callback\0");
                let mut adjusted = offset_step_update(
                    update,
                    global_step_offset + local_step_offset,
                    0.0,
                    false,
                );
                if let Some(heartbeat) = stage_heartbeat.as_mut() {
                    heartbeat.record(&mut adjusted);
                }
                let profile_record = begin_solver_profile_step_with_orchestration(
                    live_workspace,
                    &mut adjusted.stats,
                    callback_start,
                );
                if live_cadence.should_publish(&adjusted) {
                    let mut next_adjusted = None;
                    let timings = live_workspace.update_profiled(|state| {
                        next_adjusted = Some(apply_live_step_update_to_workspace_state(
                            state,
                            run_id,
                            session_id,
                            artifact_dir,
                            adjusted,
                            true,
                        ));
                        state.metadata =
                            Some(current_live_metadata(&stage.ir, execution_plan, "running"));
                        state.mesh_workspace = current_mesh_workspace(
                            &stage.ir,
                            execution_plan,
                            "running",
                            current_mesh_quality.as_ref(),
                            current_mesh_history,
                        );
                    });
                    adjusted = next_adjusted
                        .expect("adaptive live update should be consumed under workspace lock");
                    adjusted.stats.live_state_build_wall_time_ns = adjusted
                        .stats
                        .live_state_build_wall_time_ns
                        .saturating_add(timings.live_state_build_wall_time_ns);
                    adjusted.stats.publisher_replace_wall_time_ns = adjusted
                        .stats
                        .publisher_replace_wall_time_ns
                        .saturating_add(timings.publisher_replace_wall_time_ns);
                }
                finish_solver_profile_step_with_orchestration(
                    live_workspace,
                    callback_start,
                    profile_record,
                );
                fullmag_runner::StepAction::Continue
            },
        );
        if let Some(mut heartbeat) = stage_heartbeat.take() {
            heartbeat.finish();
        }
        let pass_result = pass_result.map_err(|error| anyhow!(error.message))?;

        let pass_steps = offset_step_stats(&pass_result.steps, local_step_offset, 0.0);
        if let Some(last) = pass_steps.last() {
            local_step_offset = last.step;
            physical_end_time_s = last.time;
        }
        stage_result.steps.extend(pass_steps);
        stage_result.final_magnetization = pass_result.final_magnetization;
        stage_result.status = pass_result.status;
        *stage_fem_mesh_asset = Some(remeshed_mesh_asset);

        eprintln!(
            "stage {}/{} ({}) adaptive pass {} complete",
            stage_index + 1,
            stage_count,
            stage.entrypoint_kind,
            remesh_pass_count
        );
    }

    Ok(mutated)
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn build_session_manifest(
    session_id: &str,
    run_id: &str,
    status: &str,
    interactive_session_requested: bool,
    script_path: &Path,
    problem_name: &str,
    runtime: &SessionRuntimeSelection,
    artifact_dir: &Path,
    started_at_unix_ms: u128,
    finished_at_unix_ms: u128,
    plan_summary: serde_json::Value,
) -> SessionManifest {
    // A managed run's receipt reports the latest requested/resolved selection.
    crate::script_launch::note_runtime(runtime);
    SessionManifest {
        session_id: session_id.to_string(),
        run_id: run_id.to_string(),
        status: status.to_string(),
        interactive_session_requested,
        script_path: script_path.display().to_string(),
        problem_name: problem_name.to_string(),
        requested_backend: runtime.requested_backend.clone(),
        explicit_selection: runtime.explicit_selection,
        authored_requested_device: runtime.authored_requested_device.clone(),
        requested_device: runtime.requested_device.clone(),
        requested_precision: runtime.requested_precision.clone(),
        requested_mode: runtime.requested_mode.clone(),
        requested_cpu_threads: runtime.requested_cpu_threads,
        execution_mode: runtime.requested_mode.clone(),
        precision: runtime.requested_precision.clone(),
        resolved_backend: runtime.resolved_backend.clone(),
        resolved_device: runtime.resolved_device.clone(),
        resolved_precision: runtime.resolved_precision.clone(),
        resolved_mode: runtime.resolved_mode.clone(),
        resolved_runtime_family: runtime.resolved_runtime_family.clone(),
        resolved_engine_id: runtime.resolved_engine_id.clone(),
        resolved_worker: runtime.resolved_worker.clone(),
        resolved_cpu_threads: runtime.resolved_cpu_threads,
        resolved_fallback: runtime.resolved_fallback.clone(),
        fem_crossover_decision: runtime.fem_crossover_decision.clone(),
        artifact_dir: artifact_dir.display().to_string(),
        started_at_unix_ms,
        finished_at_unix_ms,
        plan_summary,
    }
}

fn build_run_manifest(
    run_id: &str,
    session_id: &str,
    status: &str,
    artifact_dir: &Path,
) -> RunManifest {
    run_manifest_from_steps(run_id, session_id, status, artifact_dir, &[])
}

pub(crate) fn run_manifest_from_steps(
    run_id: &str,
    session_id: &str,
    status: &str,
    artifact_dir: &Path,
    steps: &[fullmag_runner::StepStats],
) -> RunManifest {
    RunManifest {
        run_id: run_id.to_string(),
        session_id: session_id.to_string(),
        status: status.to_string(),
        total_steps: steps.last().map(|step| step.step as usize).unwrap_or(0),
        final_time: steps.last().map(|step| step.time),
        final_e_ex: steps.last().map(|step| step.e_ex),
        final_e_demag: steps.last().map(|step| step.e_demag),
        final_e_ext: steps.last().map(|step| step.e_ext),
        final_e_ani: steps.last().map(|step| step.e_ani),
        final_e_dmi: steps.last().map(|step| step.e_dmi),
        final_e_rotated_dmi: steps.last().map(|step| step.e_rotated_dmi),
        final_e_total: steps.last().map(|step| step.e_total),
        artifact_dir: artifact_dir.display().to_string(),
    }
}

#[derive(Debug, Clone)]
struct PausedInteractiveStage {
    command: SessionCommand,
    source_kind: String,
    checkpoint_ref: Option<String>,
    checkpoint_resume_error: Option<String>,
    waveform_origin_time_s: f64,
    requires_exact_waveform_clock: bool,
}

fn elapsed_stage_seconds(
    result: &fullmag_runner::RunResult,
    stage_start_time_s: f64,
    frame: fullmag_runner::StageStepTimeFrame,
) -> Result<f64> {
    let Some(last) = result.steps.last() else {
        return Ok(0.0);
    };
    let elapsed = match frame {
        fullmag_runner::StageStepTimeFrame::StageLocal => last.time,
        fullmag_runner::StageStepTimeFrame::Absolute => last.time - stage_start_time_s,
    };
    if !elapsed.is_finite() || elapsed < 0.0 {
        bail!("runner reported an invalid elapsed stage time {elapsed}");
    }
    Ok(elapsed)
}

fn has_time_dependent_stage_drive(problem: &ProblemIR) -> bool {
    let dynamic = |waveform: &fullmag_ir::TimeDependenceIR| {
        !matches!(waveform, fullmag_ir::TimeDependenceIR::Constant)
    };
    let active_stage_id = problem
        .problem_meta
        .runtime_metadata
        .get("active_stage_id")
        .and_then(serde_json::Value::as_str);
    let study_kind = problem.study.kind();
    problem.field_drives.iter().any(|drive| {
        drive.enabled
            && drive.activation.is_active_for(study_kind, active_stage_id)
            && dynamic(&drive.waveform)
    })
        || problem
            .solved_antenna_drives
            .iter()
            .any(|drive| {
                drive.activation.is_active_for(study_kind, active_stage_id)
                    && dynamic(&drive.waveform)
            })
        || problem.current_modules.iter().any(|module| match module {
            fullmag_ir::CurrentModuleIR::AntennaFieldSource { drive, waveform, .. } => {
                drive.as_ref()
                    .and_then(|drive| drive.waveform.as_ref())
                    .is_some_and(dynamic)
                    || waveform.as_ref().is_some_and(dynamic)
            }
            fullmag_ir::CurrentModuleIR::CurrentTransport { time_envelope, .. } => {
                time_envelope.as_ref().is_some_and(|envelope| {
                    !matches!(envelope, fullmag_ir::TimeEnvelopeIR::Constant { .. })
                })
            }
        })
}

struct PauseCheckpointProvider {
    step: u64,
    time_s: f64,
    dt: f64,
    energies: fullmag_session::SolverEnergies,
    magnetization: Vec<[f64; 3]>,
    compatibility: fullmag_session::CheckpointCompatibility,
    backend_checkpoint: Option<serde_json::Value>,
}

impl fullmag_session::CheckpointSnapshotProvider for PauseCheckpointProvider {
    fn step(&self) -> u64 {
        self.step
    }

    fn time_s(&self) -> f64 {
        self.time_s
    }

    fn dt(&self) -> f64 {
        self.dt
    }

    fn energies(&self) -> fullmag_session::SolverEnergies {
        self.energies.clone()
    }

    fn magnetization(&self) -> Result<Vec<[f64; 3]>> {
        Ok(self.magnetization.clone())
    }

    fn auxiliary_fields(
        &self,
        _policy: fullmag_session::FieldCapturePolicy,
    ) -> Result<Vec<(String, Vec<[f64; 3]>)>> {
        Ok(Vec::new())
    }

    fn backend_state_payload(&self) -> Result<Option<fullmag_session::BackendStatePayload>> {
        let Some(checkpoint) = self.backend_checkpoint.clone() else {
            return Ok(None);
        };
        Ok(Some(fullmag_session::BackendStatePayload {
            format: "fullmag.backend_state.v1".to_string(),
            backend_family: "fdm_cpu_reference".to_string(),
            integrator_kind: Some("frozen_spins".to_string()),
            integrator_state: Some(checkpoint),
            rng_state: None,
            extra: serde_json::json!({
                "checkpoint_schema": fullmag_runner::constraints::FROZEN_SPINS_CHECKPOINT_SCHEMA
            }),
        }))
    }

    fn compatibility(&self) -> fullmag_session::CheckpointCompatibility {
        self.compatibility.clone()
    }
}

fn checkpoint_resume_error_for_backend_plan(backend_plan: &BackendPlanIR) -> Option<String> {
    match backend_plan {
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => Some(
            "retained-current H-only inspection has no magnetic pause/resume checkpoint".to_string(),
        ),
        BackendPlanIR::Fdm(fdm) => {
            fullmag_runner::validate_fdm_transport_checkpoint_resume_support(fdm)
                .err()
                .map(|error| error.message)
        }
        _ => None,
    }
}

fn capture_pause_checkpoint(
    run_id: &str,
    step: Option<&fullmag_runner::StepStats>,
    magnetization: &[[f64; 3]],
    backend_plan: &BackendPlanIR,
    stage_artifact_dir: &Path,
) -> Result<fullmag_session::CaptureResult> {
    if let Some(error) = checkpoint_resume_error_for_backend_plan(backend_plan) {
        bail!("{error}");
    }
    let store_root = runtime_state_root(&repo_root())
        .join("local-live")
        .join("session-store");
    let store = fullmag_session::SessionStore::open(store_root)?;
    let provider = PauseCheckpointProvider {
        step: step.map(|value| value.step).unwrap_or(0),
        time_s: step.map(|value| value.time).unwrap_or(0.0),
        dt: step.map(|value| value.dt).unwrap_or(0.0),
        energies: fullmag_session::SolverEnergies {
            exchange: step.map(|value| value.e_ex).unwrap_or(0.0),
            demag: step.map(|value| value.e_demag).unwrap_or(0.0),
            zeeman: step.map(|value| value.e_ext).unwrap_or(0.0),
            anisotropy: step.map(|value| value.e_ani).unwrap_or(0.0),
            dmi: step.map(|value| value.e_dmi).unwrap_or(0.0),
            rotated_dmi: step.map(|value| value.e_rotated_dmi).unwrap_or(0.0),
            total: step.map(|value| value.e_total).unwrap_or(0.0),
        },
        magnetization: magnetization.to_vec(),
        compatibility: pause_checkpoint_compatibility(backend_plan, magnetization.len()),
        backend_checkpoint: frozen_spins_checkpoint_from_stage_artifacts(stage_artifact_dir)?,
    };
    fullmag_session::capture_checkpoint(
        &store,
        &provider,
        &fullmag_session::CaptureRequest {
            run_id: run_id.to_string(),
            profile: fullmag_session::SaveProfile::Resume,
            field_policy: fullmag_session::FieldCapturePolicy::PrimaryOnly,
        },
    )
}

fn pause_checkpoint_compatibility(
    backend_plan: &BackendPlanIR,
    vector_count: usize,
) -> fullmag_session::CheckpointCompatibility {
    fullmag_session::CheckpointCompatibility {
        state_schema_version: Some("fullmag.checkpoint.v1".to_string()),
        runtime_family: Some(backend_plan_family(backend_plan).to_string()),
        precision: Some("double".to_string()),
        discretization_signature: Some(format!(
            "backend:{};vectors:{}",
            backend_plan_family(backend_plan),
            vector_count
        )),
        field_layout_signature: Some(format!("magnetization:{}x3", vector_count)),
        ..Default::default()
    }
}

fn backend_plan_family(backend_plan: &BackendPlanIR) -> &'static str {
    match backend_plan {
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) => "antenna_retained_current_field_inspection",
        BackendPlanIR::AntennaRetainedDirectFieldInspection(_) => "antenna_retained_direct_field_inspection",
        BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => "antenna_retained_preparation_field_inspection",
        BackendPlanIR::AntennaFieldOnly(_) => "fem",
        BackendPlanIR::AntennaExternalLeadInspection(_) => "antenna_external_lead_inspection",
        BackendPlanIR::Fdm(_) => "fdm",
        BackendPlanIR::FdmMultilayer(_) => "fdm_multilayer",
        BackendPlanIR::Fem(_) => "fem",
        BackendPlanIR::FemEigen(_) => "fem_eigen",
        BackendPlanIR::FemFrequencyResponse(_) => "fem_frequency_response",
    }
}

fn announce_session_start(_session_id: &str, script_path: &Path, backend: &str, headless: bool) {
    eprintln!("fullmag live workspace started");
    eprintln!("- script: {}", script_path.display());
    eprintln!("- requested_backend: {}", backend);
    if headless {
        eprintln!(
            "- live_hint: start the control room manually with `./scripts/dev-control-room.sh`"
        );
    } else {
        eprintln!("- live_hint: GUI bootstrap requested before solver start");
    }
}

fn print_script_summary(summary: &ScriptRunSummary) {
    println!("fullmag workspace summary");
    println!("- workspace_id: {}", summary.session_id);
    println!("- run_id: {}", summary.run_id);
    println!("- script: {}", summary.script_path);
    println!("- problem: {}", summary.problem_name);
    println!(
        "- execution: backend={} mode={} precision={}",
        summary.backend, summary.mode, summary.precision
    );
    println!("- status: {}", summary.status);
    println!("- total_steps: {}", summary.total_steps);
    if let Some(final_time) = summary.final_time {
        println!("- final_time: {:.6e} s", final_time);
    }
    if let Some(final_e_ex) = summary.final_e_ex {
        println!("- final_E_ex: {:.6e} J", final_e_ex);
    }
    if let Some(final_e_demag) = summary.final_e_demag {
        println!("- final_E_demag: {:.6e} J", final_e_demag);
    }
    if let Some(final_e_ext) = summary.final_e_ext {
        println!("- final_E_ext: {:.6e} J", final_e_ext);
    }
    if let Some(final_e_ani) = summary.final_e_ani {
        println!("- final_E_ani: {:.6e} J", final_e_ani);
    }
    if let Some(final_e_dmi) = summary.final_e_dmi {
        println!("- final_E_dmi: {:.6e} J", final_e_dmi);
    }
    if let Some(final_e_rotated_dmi) = summary.final_e_rotated_dmi {
        println!("- final_E_rotated_dmi: {:.6e} J", final_e_rotated_dmi);
    }
    if let Some(final_e_total) = summary.final_e_total {
        println!("- final_E_total: {:.6e} J", final_e_total);
    }
    if let Some(count) = summary.eigen_mode_count {
        println!("- eigen_modes_found: {count}");
    }
    if let Some(f_hz) = summary.eigen_lowest_frequency_hz {
        println!(
            "- eigen_lowest_frequency: {:.3e} Hz  ({:.3} GHz)",
            f_hz,
            f_hz / 1e9
        );
    }
    println!("- artifact_dir: {}", summary.artifact_dir);
    println!("- workspace_dir: {}", summary.workspace_dir);
    println!("- web_ui: bootstrap auto-launch attempted for this workspace");
    println!(
        "- control_room_hint: if the browser did not open, run `./scripts/dev-control-room.sh {}` from the repo root for this workspace",
        summary.session_id
    );
}

fn cumulative_rhs_evals(steps: &[fullmag_runner::StepStats]) -> u64 {
    steps.iter().map(|step| u64::from(step.rhs_evals)).sum()
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ProblemPreviewRefreshMode {
    PreviewOnly,
    MaterializeFields,
}

fn refresh_problem_preview_state(
    base_problem: &ProblemIR,
    continuation_magnetization: Option<&[[f64; 3]]>,
    display_selection: &CurrentDisplaySelection,
    live_workspace: &LocalLiveWorkspace,
    refresh_mode: ProblemPreviewRefreshMode,
) -> Result<()> {
    let mut problem = base_problem.clone();
    if let Some(previous_final_magnetization) = continuation_magnetization {
        apply_continuation_initial_state(&mut problem, previous_final_magnetization)?;
    }

    let plan = crate::antenna_workflow::plan_antenna_observation(&problem, live_workspace)?;
    let preview_request = display_selection.preview_request();
    let (preview_field, cached_fields, auxiliary_artifacts) = if refresh_mode
        == ProblemPreviewRefreshMode::MaterializeFields
    {
        let cached_quantities = fullmag_runner::quantities::field_materialization_quantity_ids();
        let materialization_request = full_field_materialization_request(preview_request.clone());
        let batch = fullmag_runner::snapshot_planned_problem_vector_field_batch(
            &problem,
            &plan,
            &cached_quantities,
            &materialization_request,
        )?;
        let preview_field =
            fullmag_runner::snapshot_planned_problem_preview(&problem, &plan, &preview_request)?;
        (preview_field, Some(batch.fields), batch.auxiliary_artifacts)
    } else {
        (
            fullmag_runner::snapshot_planned_problem_preview(&problem, &plan, &preview_request)?,
            None,
            Vec::new(),
        )
    };
    live_workspace.replace_auxiliary_artifacts(&auxiliary_artifacts)?;

    live_workspace.update(|state| {
        state.live_state.updated_at_unix_ms = unix_time_millis().unwrap_or(0);
        state.live_state.latest_step.preview_field = Some(preview_field.clone());
        if let Some(cached_fields) = cached_fields.clone() {
            replace_cached_preview_fields(state, cached_fields);
        }
    });

    Ok(())
}

fn refresh_problem_energy_state(
    base_problem: &ProblemIR,
    continuation_magnetization: Option<&[[f64; 3]]>,
    live_workspace: &LocalLiveWorkspace,
) -> Result<()> {
    let mut problem = base_problem.clone();
    if let Some(previous_final_magnetization) = continuation_magnetization {
        apply_continuation_initial_state(&mut problem, previous_final_magnetization)?;
    }

    let plan = crate::antenna_workflow::plan_antenna_observation(&problem, live_workspace)?;
    let mut runtime = fullmag_runner::create_planned_interactive_runtime(&problem, &plan, None)
        .map_err(|error| anyhow!(error.to_string()))?;
    let step_stats = runtime
        .snapshot_step_stats()
        .map_err(|error| anyhow!(error.to_string()))?;
    live_workspace.update(|state| {
        state.live_state.updated_at_unix_ms = unix_time_millis().unwrap_or(0);
        state.live_state.latest_step.step = step_stats.step;
        state.live_state.latest_step.time = step_stats.time;
        state.live_state.latest_step.dt = step_stats.dt;
        state.live_state.latest_step.pseudo_time_s = step_stats.pseudo_time_s;
        state.live_state.latest_step.e_ex = step_stats.e_ex;
        state.live_state.latest_step.e_demag = step_stats.e_demag;
        state.live_state.latest_step.e_ext = step_stats.e_ext;
        state.live_state.latest_step.e_ani = step_stats.e_ani;
        state.live_state.latest_step.e_dmi = step_stats.e_dmi;
        state.live_state.latest_step.e_rotated_dmi = step_stats.e_rotated_dmi;
        state.live_state.latest_step.e_total = step_stats.e_total;
        state.live_state.latest_step.max_dm_dt = step_stats.max_dm_dt;
        state.live_state.latest_step.max_h_eff = step_stats.max_h_eff;
        state.live_state.latest_step.max_h_demag = step_stats.max_h_demag;
        state.live_state.latest_step.max_torque_Apm = step_stats.max_torque_Apm;
        state.live_state.latest_step.max_torque_T = step_stats.max_torque_T;
        state.live_state.latest_step.per_object_scalars = step_stats.per_object_scalars.clone();
        state.latest_scalar_row = Some(scalar_row_from_stats(&step_stats));
    });

    Ok(())
}

fn is_control_checkpoint_only(update: &fullmag_runner::StepUpdate) -> bool {
    update.preview_field.is_none()
        && !update.scalar_row_due
        && update.fem_mesh_generation_id.is_none()
        && update.magnetization.is_none()
        && !update.finished
}

fn wait_for_solve_supported(backend_plan: &BackendPlanIR) -> bool {
    matches!(
        backend_plan,
        BackendPlanIR::Fdm(_) | BackendPlanIR::FdmMultilayer(_) | BackendPlanIR::Fem(_)
    )
}

fn wait_for_solve_should_block(requested: bool, supported: bool, headless: bool) -> bool {
    requested && supported && !headless
}

fn interactive_session_should_stay_alive(
    cli_interactive: bool,
    script_requested_interactive: bool,
    headless: bool,
) -> bool {
    !headless && (cli_interactive || script_requested_interactive)
}

fn wait_for_solve_prompt(backend_plan: &BackendPlanIR) -> &'static str {
    match backend_plan {
        BackendPlanIR::Fem(_) => {
            "Waiting for compute — adjust mesh in the control room, then click COMPUTE"
        }
        BackendPlanIR::Fdm(_) => {
            "Waiting for compute — inspect the workspace in the control room, then click COMPUTE"
        }
        _ => "Waiting for compute — click COMPUTE to continue",
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum WaitForSolveCommandAction {
    RefreshFields,
    RefreshEnergies,
    ConfigureProfiler,
    StartSolver,
    Remesh,
    Stop,
    Ignore,
}

fn classify_wait_for_solve_command(kind: &str) -> WaitForSolveCommandAction {
    match kind {
        "compute_fields" => WaitForSolveCommandAction::RefreshFields,
        "compute_energies" => WaitForSolveCommandAction::RefreshEnergies,
        "set_solver_profile" => WaitForSolveCommandAction::ConfigureProfiler,
        "solve" | "compute" | "run" | "relax" => WaitForSolveCommandAction::StartSolver,
        "remesh" | "fdm_grid_refresh" => WaitForSolveCommandAction::Remesh,
        "stop" => WaitForSolveCommandAction::Stop,
        _ => WaitForSolveCommandAction::Ignore,
    }
}

fn sanitize_stage_file_name(file_name: &str) -> String {
    Path::new(file_name)
        .file_name()
        .and_then(|name| name.to_str())
        .map(|name| name.replace(['/', '\\'], "_"))
        .unwrap_or_default()
}

fn preferred_magnetization_state_suffix(format: &str) -> &'static str {
    match format {
        "zarr" => ".zarr.zip",
        "h5" => ".h5",
        _ => ".json",
    }
}

fn normalize_magnetization_state_format(
    explicit_format: Option<&str>,
    file_name: Option<&str>,
) -> Result<String> {
    let normalized = explicit_format
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .unwrap_or("auto")
        .to_ascii_lowercase();
    if normalized != "auto" {
        let normalized = match normalized.as_str() {
            "hdf5" => "h5",
            "json" | "zarr" | "h5" => normalized.as_str(),
            other => bail!(
                "unsupported magnetization state format '{}'; supported formats: json, zarr, h5",
                other
            ),
        };
        return Ok(normalized.to_string());
    }

    let lower_name = file_name.unwrap_or_default().trim().to_ascii_lowercase();
    if lower_name.ends_with(".zarr.zip") || lower_name.ends_with(".zarr") {
        Ok("zarr".to_string())
    } else if lower_name.ends_with(".h5") || lower_name.ends_with(".hdf5") {
        Ok("h5".to_string())
    } else {
        Ok("json".to_string())
    }
}

fn ensure_magnetization_state_file_name(file_name: &str, format: &str) -> String {
    let safe = sanitize_stage_file_name(file_name);
    if safe.is_empty() {
        return format!(
            "m_state_stage_{}{}",
            unix_time_millis().unwrap_or(0),
            preferred_magnetization_state_suffix(format)
        );
    }
    let lower = safe.to_ascii_lowercase();
    if format == "zarr" && lower.ends_with(".zarr") {
        return format!("{safe}.zip");
    }
    if format == "h5" && (lower.ends_with(".h5") || lower.ends_with(".hdf5")) {
        return safe;
    }
    if lower.ends_with(preferred_magnetization_state_suffix(format)) {
        return safe;
    }
    format!("{safe}{}", preferred_magnetization_state_suffix(format))
}

fn magnetization_state_json_payload(values: &[[f64; 3]]) -> Vec<u8> {
    serde_json::to_vec_pretty(&serde_json::json!({
        "kind": "magnetization_state",
        "observable": "m",
        "format": "json",
        "vector_count": values.len(),
        "values": values,
    }))
    .expect("magnetization state JSON encoding should succeed")
}

fn write_magnetization_state_artifact(
    output_path: &Path,
    vectors: &[[f64; 3]],
    format: &str,
    dataset: Option<&str>,
) -> Result<()> {
    let parent = output_path.parent().ok_or_else(|| {
        anyhow!(
            "failed to determine output directory for magnetization artifact {}",
            output_path.display()
        )
    })?;
    fs::create_dir_all(parent)?;
    if format == "json" {
        fs::write(output_path, magnetization_state_json_payload(vectors))?;
        return Ok(());
    }

    let temp_source_path = parent.join(format!(
        ".state-export-{}-{}.json",
        unix_time_millis().unwrap_or(0),
        std::process::id()
    ));
    fs::write(&temp_source_path, magnetization_state_json_payload(vectors))?;
    let convert_result = convert_magnetization_state(
        &temp_source_path,
        output_path,
        Some("json"),
        Some(format),
        None,
        dataset,
        None,
    );
    let _ = fs::remove_file(&temp_source_path);
    convert_result
}

fn current_stage_magnetization_vectors(
    continuation_magnetization: Option<&[[f64; 3]]>,
    backend_plan: &BackendPlanIR,
) -> Vec<[f64; 3]> {
    if matches!(backend_plan, BackendPlanIR::AntennaFieldOnly(_) | BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)) {
        return Vec::new();
    }
    if let Some(current) = continuation_magnetization {
        return current.to_vec();
    }
    match backend_plan {
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => Vec::new(),
        BackendPlanIR::AntennaFieldOnly(_) => Vec::new(),
        BackendPlanIR::AntennaExternalLeadInspection(_) => Vec::new(),
        BackendPlanIR::Fdm(fdm) => fdm.initial_magnetization.clone(),
        BackendPlanIR::FdmMultilayer(fdm) => fdm
            .layers
            .iter()
            .flat_map(|layer| layer.initial_magnetization.iter().copied())
            .collect(),
        BackendPlanIR::Fem(fem) => fem.initial_magnetization.clone(),
        BackendPlanIR::FemEigen(fem) => fem.equilibrium_magnetization.clone(),
        BackendPlanIR::FemFrequencyResponse(fem) => fem.equilibrium_magnetization.clone(),
    }
}

struct LoadedInitialMagnetizationState {
    values: Vec<[f64; 3]>,
    provenance: serde_json::Value,
}

fn initial_magnetization_state_override(
    args: &ScriptCli,
) -> Result<Option<LoadedInitialMagnetizationState>> {
    let Some(path) = args.initial_magnetization_state.as_deref() else {
        return Ok(None);
    };
    let path_label = path.display().to_string();
    let format = normalize_magnetization_state_format(
        args.initial_magnetization_state_format.as_deref(),
        Some(&path_label),
    )?;
    let loaded = read_magnetization_state(
        path,
        Some(format.as_str()),
        args.initial_magnetization_state_dataset.as_deref(),
        args.initial_magnetization_state_sample_index,
    )
    .with_context(|| {
        format!(
            "failed to load --initial-magnetization-state {}",
            path.display()
        )
    })?;
    Ok(Some(LoadedInitialMagnetizationState {
        provenance: serde_json::json!({
            "kind": "initial_magnetization_state_override",
            "source_path": path_label,
            "format": format,
            "dataset": args.initial_magnetization_state_dataset,
            "sample_index": args.initial_magnetization_state_sample_index,
            "vector_count": loaded.vector_count,
        }),
        values: loaded.values,
    }))
}

fn attach_initial_magnetization_state_override_metadata(
    problem: &mut ProblemIR,
    provenance: Option<&serde_json::Value>,
) {
    if let Some(provenance) = provenance {
        problem.problem_meta.runtime_metadata.insert(
            "initial_magnetization_state_override".to_string(),
            provenance.clone(),
        );
    }
}

fn apply_initial_magnetization_state_override(
    problem: &mut ProblemIR,
    state: Option<&LoadedInitialMagnetizationState>,
) -> Result<()> {
    if let Some(state) = state {
        apply_continuation_initial_state(problem, &state.values)?;
        attach_initial_magnetization_state_override_metadata(problem, Some(&state.provenance));
    }
    Ok(())
}

fn resolve_named_state_artifact_path(artifact_dir: &Path, artifact_name: &str) -> Option<PathBuf> {
    let safe = sanitize_stage_file_name(artifact_name);
    if safe.is_empty() {
        return None;
    }
    for base_dir in [
        artifact_dir.join("states"),
        artifact_dir.join("exports"),
        artifact_dir.to_path_buf(),
    ] {
        let exact = base_dir.join(&safe);
        if exact.is_file() {
            return Some(exact);
        }
        for suffix in [".json", ".zarr", ".zarr.zip", ".h5", ".hdf5"] {
            let candidate = base_dir.join(format!("{safe}{suffix}"));
            if candidate.is_file() {
                return Some(candidate);
            }
        }
    }
    None
}

fn resolve_state_input_path(
    artifact_dir: &Path,
    state_path: Option<&str>,
    artifact_name: Option<&str>,
) -> Result<PathBuf> {
    if let Some(raw_path) = state_path.map(str::trim).filter(|value| !value.is_empty()) {
        let direct = PathBuf::from(raw_path);
        if direct.is_file() {
            return Ok(direct);
        }
        for candidate in [
            artifact_dir.join(raw_path),
            artifact_dir.join("states").join(raw_path),
            artifact_dir.join("exports").join(raw_path),
        ] {
            if candidate.is_file() {
                return Ok(candidate);
            }
        }
        bail!("load_state could not find state_path '{}'", raw_path);
    }

    let artifact_name = artifact_name
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .ok_or_else(|| anyhow!("load_state requires either state_path or artifact_name"))?;
    resolve_named_state_artifact_path(artifact_dir, artifact_name).ok_or_else(|| {
        anyhow!(
            "load_state could not find saved state '{}'; searched artifact states/exports directories",
            artifact_name
        )
    })
}

fn write_synthetic_stage_record(
    current_stage_artifact_dir: &Path,
    payload: serde_json::Value,
) -> Result<()> {
    fs::create_dir_all(current_stage_artifact_dir)?;
    fs::write(
        current_stage_artifact_dir.join("synthetic_stage.json"),
        serde_json::to_vec_pretty(&payload)?,
    )?;
    Ok(())
}

const ANTENNA_STAGE_OUTPUT_CATALOG_NAME: &str = "stage_output_catalog.v1.json";

#[derive(serde::Deserialize)]
struct ReadyAntennaStageOutputCatalog {
    schema_version: String,
    stage_id: String,
    stage_kind: String,
    port_mode_id: String,
    status: String,
    outputs: Vec<ReadyAntennaStageOutput>,
}

#[derive(serde::Deserialize)]
struct ReadyAntennaStageOutput {
    kind: String,
    output_id: String,
    solution_ref: fullmag_ir::AntennaFieldSolutionRefIR,
    manifest_ref: String,
    quantity_ids: Vec<String>,
}

fn read_ready_antenna_stage_outputs(
    path: &Path,
    artifact_dir: &Path,
    expected_stage_id: &str,
    expected_port_mode_id: &str,
) -> Result<Vec<fullmag_ir::AntennaFieldSolutionRefIR>> {
    let catalog: ReadyAntennaStageOutputCatalog = serde_json::from_slice(
        &fs::read(path)
            .with_context(|| format!("read antenna stage output catalog {}", path.display()))?,
    )
    .with_context(|| format!("parse antenna stage output catalog {}", path.display()))?;
    if catalog.schema_version != "stage_output_catalog.v1"
        || catalog.status != "ready"
        || catalog.stage_kind != "antenna_field_solve"
        || catalog.stage_id != expected_stage_id
        || catalog.port_mode_id != expected_port_mode_id
        || catalog.outputs.is_empty()
    {
        bail!(
            "antenna stage output catalog {} is not the expected ready output",
            path.display()
        );
    }
    let mut output_ids = std::collections::BTreeSet::new();
    let artifact_root = fs::canonicalize(artifact_dir).with_context(|| {
        format!("resolve antenna artifact directory {}", artifact_dir.display())
    })?;
    catalog
        .outputs
        .into_iter()
        .map(|output| {
            let reference = output.solution_ref;
            let manifest_ref = Path::new(&output.manifest_ref);
            let solution_dir = Path::new("antenna")
                .join("field_solutions")
                .join(&reference.output_id);
            let revision_manifest = solution_dir
                .join(&reference.asset_id)
                .join("manifest.v1.json");
            let legacy_manifest = solution_dir.join("manifest.v1.json");
            let manifest_path = artifact_dir.join(manifest_ref);
            let manifest_available = !manifest_ref.as_os_str().is_empty()
                && (manifest_ref == revision_manifest.as_path()
                    || manifest_ref == legacy_manifest.as_path())
                && manifest_ref.components().all(|component| matches!(component, std::path::Component::Normal(_)))
                && fs::canonicalize(&manifest_path).ok().is_some_and(|resolved| {
                    resolved.starts_with(&artifact_root) && resolved.is_file()
                });
            if output.kind != "antenna_field_solution"
                || !output.quantity_ids.iter().any(|quantity| quantity == "H_ant_basis")
                || !output_ids.insert(output.output_id.clone())
                || output.output_id != reference.output_id
                || reference.stage_id != expected_stage_id
                || reference.asset_id.trim().is_empty()
                || reference.content_digest.trim().is_empty()
                || !manifest_available
            {
                bail!(
                    "antenna stage output catalog {} contains an incompatible reference",
                    path.display()
                );
            }
            let asset = fullmag_runner::load_published_antenna_field_solution_for_port(
                artifact_dir,
                &reference,
                expected_port_mode_id,
            ).map_err(|error| anyhow!(
                "verify antenna stage output catalog asset: {}", error.message
            ))?;
            if asset.manifest_bytes != fs::read(&manifest_path)? {
                bail!("antenna stage output catalog manifest differs from the verified asset");
            }
            Ok(reference)
        })
        .collect()
}

fn antenna_stage_output_catalog_path(current_stage_artifact_dir: &Path) -> PathBuf {
    current_stage_artifact_dir.join(ANTENNA_STAGE_OUTPUT_CATALOG_NAME)
}

fn relative_artifact_ref(artifact_dir: &Path, path: &Path) -> Result<String> {
    let artifact_root = fs::canonicalize(artifact_dir)?;
    let manifest = fs::canonicalize(path)?;
    let relative = manifest.strip_prefix(&artifact_root).with_context(|| {
        format!(
            "antenna manifest {} is outside artifact directory {}",
            path.display(),
            artifact_dir.display()
        )
    })?;
    if relative.as_os_str().is_empty()
        || !relative.components().all(|component| matches!(component, std::path::Component::Normal(_)))
        || !manifest.starts_with(&artifact_root)
        || !manifest.is_file()
    {
        bail!("antenna manifest {} is not a file inside artifact directory {}", path.display(), artifact_dir.display());
    }
    Ok(relative
        .to_str()
        .context("antenna manifest path is not UTF-8")?
        .replace('\\', "/"))
}

fn write_antenna_stage_output_catalog(
    current_stage_artifact_dir: &Path,
    payload: &serde_json::Value,
) -> Result<()> {
    write_antenna_stage_output_catalog_with_hook(
        current_stage_artifact_dir,
        payload,
        None,
    )
}

fn write_antenna_stage_output_catalog_with_hook(
    current_stage_artifact_dir: &Path,
    payload: &serde_json::Value,
    before_rename: Option<&dyn Fn() -> Result<()>>,
) -> Result<()> {
    fs::create_dir_all(current_stage_artifact_dir).with_context(|| {
        format!(
            "creating antenna stage artifact directory {}",
            current_stage_artifact_dir.display()
        )
    })?;
    let path = antenna_stage_output_catalog_path(current_stage_artifact_dir);
    let bytes = serde_json::to_vec_pretty(payload)
        .context("serializing antenna stage output catalog")?;
    if path.exists() {
        let existing = fs::read(&path).with_context(|| {
            format!("reading existing antenna stage output catalog {}", path.display())
        })?;
        if existing == bytes {
            if let Some(before_rename) = before_rename {
                before_rename()?;
            }
            return Ok(());
        }
        bail!(
            "antenna stage output catalog already exists with different content: {}",
            path.display()
        );
    }

    let temporary = current_stage_artifact_dir.join(format!(
        ".{ANTENNA_STAGE_OUTPUT_CATALOG_NAME}.tmp-{}",
        uuid::Uuid::new_v4().simple()
    ));
    let write_result = (|| -> Result<()> {
        fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temporary)
            .and_then(|mut file| file.write_all(&bytes))
            .with_context(|| {
                format!(
                    "writing temporary antenna stage output catalog {}",
                    temporary.display()
                )
            })?;
        if let Some(before_rename) = before_rename {
            before_rename()?;
        }
        fs::hard_link(&temporary, &path).with_context(|| {
            format!(
                "publishing antenna stage output catalog {}",
                path.display()
            )
        })?;
        let _ = fs::remove_file(&temporary);
        Ok(())
    })();
    if let Err(error) = write_result {
        let _ = fs::remove_file(&temporary);
        if path.exists() && fs::read(&path).ok().as_deref() == Some(bytes.as_slice()) {
            if let Some(before_rename) = before_rename {
                before_rename()?;
            }
            return Ok(());
        }
        return Err(error);
    }
    Ok(())
}

fn write_antenna_stage_output_catalog_ready(
    current_stage_artifact_dir: &Path,
    artifact_dir: &Path,
    stage_id: &str,
    port_mode_id: &str,
    reference: &fullmag_ir::AntennaFieldSolutionRefIR,
    manifest_path: &Path,
    quantity_ids: &[String],
    reused_existing: bool,
    interrupt_requested: Option<&std::sync::atomic::AtomicBool>,
) -> Result<()> {
    let before_rename = || {
        if synthetic_interrupt_requested(interrupt_requested) {
            bail!("{SYNTHETIC_ANTENNA_CANCELLED}");
        }
        Ok(())
    };
    write_antenna_stage_output_catalog_with_hook(
        current_stage_artifact_dir,
        &serde_json::json!({
            "schema_version": "stage_output_catalog.v1",
            "stage_id": stage_id,
            "stage_kind": "antenna_field_solve",
            "port_mode_id": port_mode_id,
            "status": "ready",
            "outputs": [{
                "kind": "antenna_field_solution",
                "output_id": reference.output_id,
                "solution_ref": reference,
                "manifest_ref": relative_artifact_ref(artifact_dir, manifest_path)?,
                "quantity_ids": quantity_ids,
                "reused_existing": reused_existing,
            }],
        }),
        Some(&before_rename),
    )
}

fn write_antenna_stage_output_catalog_terminal(
    current_stage_artifact_dir: &Path,
    stage_id: &str,
    solution_id: &str,
    port_mode_id: &str,
    status: &str,
    diagnostic: &str,
) -> Result<()> {
    write_antenna_stage_output_catalog(
        current_stage_artifact_dir,
        &serde_json::json!({
            "schema_version": "stage_output_catalog.v1",
            "stage_id": stage_id,
            "stage_kind": "antenna_field_solve",
            "solution_id": solution_id,
            "port_mode_id": port_mode_id,
            "status": status,
            "outputs": [],
            "diagnostic": diagnostic,
        }),
    )
}

fn synthetic_stage_artifact_ref(
    action: &ResolvedScriptStageAction,
    current_stage_artifact_dir: &Path,
) -> PathBuf {
    if matches!(action, ResolvedScriptStageAction::AntennaExternalLeadInspection { .. }) {
        current_stage_artifact_dir.join(antenna_external_lead_inspection::STAGE_OUTPUT_NAME)
    } else if matches!(action, ResolvedScriptStageAction::AntennaClosedLoopInspection { .. }) {
        current_stage_artifact_dir.join(antenna_closed_loop_inspection::STAGE_OUTPUT_NAME)
    } else if matches!(action, ResolvedScriptStageAction::AntennaFieldSolve { .. }) {
        antenna_stage_output_catalog_path(current_stage_artifact_dir)
    } else {
        current_stage_artifact_dir.to_path_buf()
    }
}

fn write_sampling_resolution_stage_record(
    current_stage_artifact_dir: &Path,
    sampling_resolution: Option<&serde_json::Value>,
) -> Result<()> {
    let Some(sampling_resolution) = sampling_resolution else {
        return Ok(());
    };
    fs::create_dir_all(current_stage_artifact_dir)?;
    fs::write(
        current_stage_artifact_dir.join("sampling_stage_record.v1.json"),
        serde_json::to_vec_pretty(&serde_json::json!({
            "schema_version": "sampling_stage_record.v1",
            "sampling_resolution": sampling_resolution,
        }))?,
    )?;
    Ok(())
}

struct SyntheticStageOutcome {
    magnetization: Vec<[f64; 3]>,
    message: String,
}

const SYNTHETIC_ANTENNA_CANCELLED: &str =
    "antenna field solve cancelled: interrupt_requested";

fn synthetic_interrupt_requested(
    interrupt_requested: Option<&std::sync::atomic::AtomicBool>,
) -> bool {
    interrupt_requested.is_some_and(|signal| {
        signal.load(std::sync::atomic::Ordering::Acquire)
    })
}

fn update_antenna_live_stage_progress(
    execution: &mut CurrentLiveStageExecutionState,
    stage_index: usize,
    phase: fullmag_runner::AntennaFieldStageStatus,
    diagnostic: Option<String>,
    at_unix_ms: u64,
) -> bool {
    if execution.active_stage_index != Some(stage_index) {
        return false;
    }
    let Some(stage) = execution.stages.get_mut(stage_index) else {
        return false;
    };
    if stage.status != "running" {
        return false;
    }
    let (label, default_detail) = match phase {
        fullmag_runner::AntennaFieldStageStatus::Meshing =>
            ("mesh reused", "using meshes resolved by the planner"),
        fullmag_runner::AntennaFieldStageStatus::SolvingCurrent =>
            ("solving current", "solving the static conductor current"),
        fullmag_runner::AntennaFieldStageStatus::EvaluatingField =>
            ("evaluating field", "evaluating the antenna Oersted field"),
        fullmag_runner::AntennaFieldStageStatus::ProjectingTargets =>
            ("publishing field basis", "publishing the resolved target field basis"),
        _ => return false,
    };
    stage.progress_label = Some(label.to_string());
    stage.progress_detail = Some(diagnostic.unwrap_or_else(|| default_detail.into()));
    stage.last_progress_unix_ms = Some(at_unix_ms);
    true
}

fn record_cancelled_antenna_stage(
    lifecycle: &mut fullmag_runner::AntennaFieldStageState,
    stage_id: &str,
    port_mode_id: &str,
    current_stage_artifact_dir: &Path,
    diagnostic: &str,
) -> Result<()> {
    lifecycle.transition(
        fullmag_runner::AntennaFieldStageStatus::Cancelled,
        Some(diagnostic.to_string()),
    )?;
    let solution_id = lifecycle.solution_id.clone();
    write_synthetic_stage_record(
        current_stage_artifact_dir,
        serde_json::json!({
            "kind": "antenna_field_solve",
            "stage_id": stage_id,
            "port_mode_id": port_mode_id,
            "stage_state": lifecycle,
        }),
    )?;
    write_antenna_stage_output_catalog_terminal(
        current_stage_artifact_dir,
        stage_id,
        &solution_id,
        port_mode_id,
        "cancelled",
        diagnostic,
    )?;
    Ok(())
}

fn execute_synthetic_stage(
    action: &ResolvedScriptStageAction,
    artifact_dir: &Path,
    current_stage_artifact_dir: &Path,
    backend_plan: &BackendPlanIR,
    continuation_magnetization: Option<&[[f64; 3]]>,
) -> Result<SyntheticStageOutcome> {
    execute_synthetic_stage_with_interrupt(
        action,
        None,
        artifact_dir,
        current_stage_artifact_dir,
        backend_plan,
        continuation_magnetization,
        None,
        None,
    )
}

fn execute_synthetic_stage_with_interrupt(
    action: &ResolvedScriptStageAction,
    problem: Option<&ProblemIR>,
    artifact_dir: &Path,
    current_stage_artifact_dir: &Path,
    backend_plan: &BackendPlanIR,
    continuation_magnetization: Option<&[[f64; 3]]>,
    interrupt_requested: Option<&std::sync::atomic::AtomicBool>,
    mut progress_observer: Option<
        &mut dyn FnMut(fullmag_runner::AntennaFieldStageStatus, Option<String>),
    >,
) -> Result<SyntheticStageOutcome> {
    match action {
        ResolvedScriptStageAction::AntennaRetainedCurrentInspection { .. }
        | ResolvedScriptStageAction::AntennaRetainedDirectInspection { .. } | ResolvedScriptStageAction::AntennaRetainedPreparationInspection { .. } => {
            bail!("retained-current H-only inspection requires its accepted parent-bound preparation and worker; synthetic execution and fresh current transport are forbidden");
        }
        ResolvedScriptStageAction::AntennaClosedLoopInspection {
            input, requested_execution, output_id,
        } => antenna_closed_loop_inspection::execute(
            input, requested_execution, output_id, artifact_dir, current_stage_artifact_dir,
            backend_plan, continuation_magnetization, interrupt_requested, progress_observer,
        ),
        ResolvedScriptStageAction::AntennaExternalLeadInspection {
            input,
            requested_execution,
            output_id,
        } => antenna_external_lead_inspection::execute(
            input,
            requested_execution,
            output_id,
            artifact_dir,
            current_stage_artifact_dir,
            backend_plan,
            continuation_magnetization,
            interrupt_requested,
            progress_observer,
        ),
        ResolvedScriptStageAction::AntennaSourceSpectrum { request_id } => {
            if synthetic_interrupt_requested(interrupt_requested) {
                bail!("antenna source-spectrum stage was cancelled before execution");
            }
            let mut analysis = problem
                .context("antenna source-spectrum stage requires its resolved ProblemIR")?
                .clone();
            analysis.antenna_spectrum_requests.retain(|request| request.id == *request_id);
            if analysis.antenna_spectrum_requests.len() != 1 {
                bail!("antenna source-spectrum request '{}' is missing from this stage", request_id);
            }
            execute_antenna_spectrum_requests(
                &analysis,
                artifact_dir,
                current_stage_artifact_dir,
                interrupt_requested,
            )?;
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({"kind": "antenna_source_spectrum", "request_id": request_id}),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: current_stage_magnetization_vectors(continuation_magnetization, backend_plan),
                message: format!("Computed antenna source spectrum '{}'", request_id),
            })
        }
        ResolvedScriptStageAction::AddSolvedAntennaDrive { projection_id, drive_id } => {
            let vectors = current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "add_solved_antenna_drive",
                    "projection_id": projection_id,
                    "drive_id": drive_id,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!("Registered solved antenna drive '{}'", drive_id),
            })
        }
        ResolvedScriptStageAction::AntennaFieldSolve {
            stage_id,
            port_mode_id,
            plan,
        } => {
            let mut lifecycle = fullmag_runner::AntennaFieldStageState {
                stage_id: stage_id.clone(),
                solution_id: plan.solution_id.clone(),
                status: fullmag_runner::AntennaFieldStageStatus::Missing,
                transitions: Vec::new(),
                signatures: None,
                diagnostic: None,
            };
            if synthetic_interrupt_requested(interrupt_requested) {
                lifecycle.transition(fullmag_runner::AntennaFieldStageStatus::Queued, None)?;
                record_cancelled_antenna_stage(
                    &mut lifecycle,
                    stage_id,
                    port_mode_id,
                    current_stage_artifact_dir,
                    SYNTHETIC_ANTENNA_CANCELLED,
                )?;
                bail!("{SYNTHETIC_ANTENNA_CANCELLED}");
            }
            let cache_state =
                fullmag_runner::inspect_cached_antenna_field_solution(artifact_dir, plan)?;
            if let fullmag_runner::AntennaFieldSolutionCacheState::Stale {
                expected_asset_id,
                cached_asset_id,
                manifest_path,
            } = &cache_state
            {
                lifecycle.transition(
                    fullmag_runner::AntennaFieldStageStatus::Stale,
                    Some(format!(
                        "immutable field solution is stale: cached_asset_id={cached_asset_id} expected_asset_id={expected_asset_id} manifest_path={}",
                        manifest_path.display()
                    )),
                )?;
                lifecycle.transition(
                    fullmag_runner::AntennaFieldStageStatus::Queued,
                    Some("re-solving stale immutable field solution".into()),
                )?;
            } else {
                lifecycle.transition(fullmag_runner::AntennaFieldStageStatus::Queued, None)?;
            }

            if synthetic_interrupt_requested(interrupt_requested) {
                record_cancelled_antenna_stage(
                    &mut lifecycle,
                    stage_id,
                    port_mode_id,
                    current_stage_artifact_dir,
                    SYNTHETIC_ANTENNA_CANCELLED,
                )?;
                bail!("{SYNTHETIC_ANTENNA_CANCELLED}");
            }

            if let fullmag_runner::AntennaFieldSolutionCacheState::Ready(cached) = cache_state {
                let reuse_diagnostic = "reused verified immutable field solution".to_string();
                lifecycle.transition(
                    fullmag_runner::AntennaFieldStageStatus::ProjectingTargets,
                    Some(reuse_diagnostic.clone()),
                )?;
                if let Some(observer) = progress_observer.as_deref_mut() {
                    observer(
                        fullmag_runner::AntennaFieldStageStatus::ProjectingTargets,
                        Some(reuse_diagnostic),
                    );
                }
                if synthetic_interrupt_requested(interrupt_requested) {
                    record_cancelled_antenna_stage(
                        &mut lifecycle,
                        stage_id,
                        port_mode_id,
                        current_stage_artifact_dir,
                        SYNTHETIC_ANTENNA_CANCELLED,
                    )?;
                    bail!("{SYNTHETIC_ANTENNA_CANCELLED}");
                }
                let quantity_ids = vec!["H_ant_basis".to_string()];
                if let Err(error) = write_antenna_stage_output_catalog_ready(
                    current_stage_artifact_dir,
                    artifact_dir,
                    stage_id,
                    port_mode_id,
                    &cached.reference,
                    &cached.manifest_path,
                    &quantity_ids,
                    true,
                    interrupt_requested,
                ) {
                    if synthetic_interrupt_requested(interrupt_requested) {
                        record_cancelled_antenna_stage(
                            &mut lifecycle,
                            stage_id,
                            port_mode_id,
                            current_stage_artifact_dir,
                            SYNTHETIC_ANTENNA_CANCELLED,
                        )?;
                    }
                    return Err(error);
                }
                lifecycle.signatures = Some(cached.signatures.clone());
                lifecycle.transition(fullmag_runner::AntennaFieldStageStatus::Ready, None)?;
                write_synthetic_stage_record(
                    current_stage_artifact_dir,
                    serde_json::json!({
                        "kind": "antenna_field_solve",
                        "stage_id": stage_id,
                        "port_mode_id": port_mode_id,
                        "solution_id": cached.reference.output_id,
                        "asset_id": cached.reference.asset_id,
                        "content_digest": cached.reference.content_digest,
                        "manifest_path": cached.manifest_path.display().to_string(),
                        "reused_existing": true,
                        "quantity_ids": ["H_ant_basis"],
                        "stage_state": lifecycle,
                    }),
                )?;
                let vectors =
                    current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
                return Ok(SyntheticStageOutcome {
                    magnetization: vectors,
                    message: format!(
                        "Reused immutable antenna field basis '{}' for port '{}'.",
                        cached.reference.output_id, cached.reference.stage_id
                    ),
                });
            }

            let result = match fullmag_runner::execute_antenna_field_solve_plan_with_progress_interruptible(
                plan,
                interrupt_requested,
                &mut |status, diagnostic| {
                    lifecycle.transition(status, diagnostic.clone())?;
                    if let Some(observer) = progress_observer.as_deref_mut() {
                        observer(status, diagnostic);
                    }
                    Ok(())
                },
            ) {
                Ok(result) => result,
                Err(error) => {
                    let diagnostic = error.to_string();
                    if synthetic_interrupt_requested(interrupt_requested) {
                        record_cancelled_antenna_stage(
                            &mut lifecycle,
                            stage_id,
                            port_mode_id,
                            current_stage_artifact_dir,
                            &diagnostic,
                        )?;
                    } else {
                        let _ = lifecycle.transition(
                            fullmag_runner::AntennaFieldStageStatus::Failed,
                            Some(diagnostic.clone()),
                        );
                        let _ = write_synthetic_stage_record(
                            current_stage_artifact_dir,
                            serde_json::json!({
                                "kind": "antenna_field_solve",
                                "stage_id": stage_id,
                                "port_mode_id": port_mode_id,
                                "stage_state": lifecycle,
                            }),
                        );
                    }
                    return Err(error.into());
                }
            };
            if synthetic_interrupt_requested(interrupt_requested) {
                record_cancelled_antenna_stage(
                    &mut lifecycle,
                    stage_id,
                    port_mode_id,
                    current_stage_artifact_dir,
                    SYNTHETIC_ANTENNA_CANCELLED,
                )?;
                bail!("{SYNTHETIC_ANTENNA_CANCELLED}");
            }
            lifecycle.transition(
                fullmag_runner::AntennaFieldStageStatus::ProjectingTargets,
                None,
            )?;
            if let Some(observer) = progress_observer.as_deref_mut() {
                observer(fullmag_runner::AntennaFieldStageStatus::ProjectingTargets, None);
            }
            if synthetic_interrupt_requested(interrupt_requested) {
                record_cancelled_antenna_stage(
                    &mut lifecycle,
                    stage_id,
                    port_mode_id,
                    current_stage_artifact_dir,
                    SYNTHETIC_ANTENNA_CANCELLED,
                )?;
                bail!("{SYNTHETIC_ANTENNA_CANCELLED}");
            }
            let published = match fullmag_runner::publish_antenna_field_solution_atomically_interruptible(
                artifact_dir,
                &result,
                interrupt_requested,
            ) {
                Ok(published) => published,
                Err(error) => {
                    let diagnostic = error.to_string();
                    if synthetic_interrupt_requested(interrupt_requested) {
                        record_cancelled_antenna_stage(
                            &mut lifecycle,
                            stage_id,
                            port_mode_id,
                            current_stage_artifact_dir,
                            &diagnostic,
                        )?;
                    } else {
                        let _ = lifecycle.transition(
                            fullmag_runner::AntennaFieldStageStatus::Failed,
                            Some(diagnostic.clone()),
                        );
                        let _ = write_synthetic_stage_record(
                            current_stage_artifact_dir,
                            serde_json::json!({
                                "kind": "antenna_field_solve",
                                "stage_id": stage_id,
                                "port_mode_id": port_mode_id,
                                "stage_state": lifecycle,
                            }),
                        );
                    }
                    return Err(error.into());
                }
            };
            if synthetic_interrupt_requested(interrupt_requested) {
                record_cancelled_antenna_stage(
                    &mut lifecycle,
                    stage_id,
                    port_mode_id,
                    current_stage_artifact_dir,
                    SYNTHETIC_ANTENNA_CANCELLED,
                )?;
                bail!("{SYNTHETIC_ANTENNA_CANCELLED}");
            }
            let quantity_ids = result
                .quantities
                .iter()
                .map(|quantity| quantity.quantity_id.clone())
                .collect::<Vec<_>>();
            if let Err(error) = write_antenna_stage_output_catalog_ready(
                current_stage_artifact_dir,
                artifact_dir,
                stage_id,
                port_mode_id,
                &published.reference,
                &published.manifest_path,
                &quantity_ids,
                published.reused_existing,
                interrupt_requested,
            ) {
                if synthetic_interrupt_requested(interrupt_requested) {
                    record_cancelled_antenna_stage(
                        &mut lifecycle,
                        stage_id,
                        port_mode_id,
                        current_stage_artifact_dir,
                        SYNTHETIC_ANTENNA_CANCELLED,
                    )?;
                }
                return Err(error);
            }
            lifecycle.signatures = Some(published.signatures.clone());
            lifecycle.transition(fullmag_runner::AntennaFieldStageStatus::Ready, None)?;
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "antenna_field_solve",
                    "stage_id": stage_id,
                    "port_mode_id": port_mode_id,
                    "solution_id": result.solution_id,
                    "asset_id": published.reference.asset_id,
                    "content_digest": published.reference.content_digest,
                    "manifest_path": published.manifest_path.display().to_string(),
                    "reused_existing": published.reused_existing,
                    "quantity_ids": quantity_ids,
                    "transport_provenance": result.transport_provenance,
                    "stage_state": lifecycle,
                }),
            )?;
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!(
                    "Solved antenna field basis '{}' for port '{}' ({}{}).",
                    result.solution_id,
                    result.port_mode_id,
                    published.reference.asset_id,
                    if published.reused_existing {
                        ", reused immutable asset"
                    } else {
                        ""
                    }
                ),
            })
        }
        ResolvedScriptStageAction::SaveState {
            artifact_name,
            format,
            dataset,
        } => {
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            let format =
                normalize_magnetization_state_format(format.as_deref(), Some(artifact_name))?;
            let file_name = ensure_magnetization_state_file_name(artifact_name, &format);
            let output_path = artifact_dir.join("states").join(&file_name);
            write_magnetization_state_artifact(
                &output_path,
                &vectors,
                &format,
                dataset.as_deref(),
            )?;
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "save_state",
                    "stored_path": output_path.display().to_string(),
                    "format": format,
                    "dataset": dataset,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!("Saved stage state to {}", output_path.display()),
            })
        }
        ResolvedScriptStageAction::LoadState {
            artifact_name,
            state_path,
            format,
            dataset,
            sample_index,
        } => {
            let input_path = resolve_state_input_path(
                artifact_dir,
                state_path.as_deref(),
                artifact_name.as_deref(),
            )?;
            let loaded = read_magnetization_state(
                &input_path,
                format.as_deref(),
                dataset.as_deref(),
                *sample_index,
            )?;
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "load_state",
                    "source_path": input_path.display().to_string(),
                    "vector_count": loaded.vector_count,
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: loaded.values,
                message: format!("Loaded stage state from {}", input_path.display()),
            })
        }
        ResolvedScriptStageAction::Export {
            artifact_name,
            quantity,
            format,
            dataset,
        } => {
            let normalized_quantity = quantity.trim().to_ascii_lowercase();
            if normalized_quantity != "magnetization" && normalized_quantity != "m" {
                bail!(
                    "export stage currently supports only quantity='magnetization'/'m', got '{}'",
                    quantity
                );
            }
            let normalized_format =
                normalize_magnetization_state_format(Some(format), artifact_name.as_deref())?;
            let base_name = artifact_name
                .as_deref()
                .map(str::trim)
                .filter(|value| !value.is_empty())
                .unwrap_or("magnetization_export");
            let file_name = ensure_magnetization_state_file_name(base_name, &normalized_format);
            let output_path = artifact_dir.join("exports").join(&file_name);
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_magnetization_state_artifact(
                &output_path,
                &vectors,
                &normalized_format,
                dataset.as_deref(),
            )?;
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "export",
                    "quantity": normalized_quantity,
                    "stored_path": output_path.display().to_string(),
                    "format": normalized_format,
                    "dataset": dataset,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!("Exported {} to {}", quantity.trim(), output_path.display()),
            })
        }
        ResolvedScriptStageAction::ChangeDevice { device } => {
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "change_device",
                    "device": device,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!("Changed execution device to {}", device),
            })
        }
        ResolvedScriptStageAction::AddFieldDrive { drive } => {
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "add_field_drive",
                    "drive": drive,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!("Added regional field drive {}", drive.id),
            })
        }
        ResolvedScriptStageAction::RemoveFieldDrive { drive_id } => {
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "remove_field_drive",
                    "drive_id": drive_id,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!("Removed regional field drive {}", drive_id),
            })
        }
        ResolvedScriptStageAction::TableAutosave {
            enabled,
            table_autosave,
        } => {
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "table_autosave",
                    "enabled": enabled,
                    "table_autosave": table_autosave,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!(
                    "Table autosave {}",
                    if *enabled { "enabled" } else { "disabled" }
                ),
            })
        }
        ResolvedScriptStageAction::Autosave {
            enabled,
            quantity,
            output,
        } => {
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "autosave",
                    "enabled": enabled,
                    "quantity": quantity,
                    "output": output,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!(
                    "Autosave {}{}",
                    if *enabled { "enabled" } else { "disabled" },
                    quantity
                        .as_deref()
                        .map(|quantity| format!(" for {quantity}"))
                        .unwrap_or_default()
                ),
            })
        }
        ResolvedScriptStageAction::FftResponse { enabled, request } => {
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "fft_response",
                    "enabled": enabled,
                    "request": request,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!(
                    "FFT response {}",
                    if *enabled { "enabled" } else { "disabled" }
                ),
            })
        }
        ResolvedScriptStageAction::SetTransportCurrent {
            module_id,
            terminal_outward_current_density_apm2,
        } => {
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "set_transport_current",
                    "module_id": module_id,
                    "terminal_outward_current_density_Apm2": terminal_outward_current_density_apm2,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!("Set solved-current drive for transport module {module_id}"),
            })
        }
        ResolvedScriptStageAction::SetSpinTorqueEnabled { module_id, enabled } => {
            let vectors =
                current_stage_magnetization_vectors(continuation_magnetization, backend_plan);
            write_synthetic_stage_record(
                current_stage_artifact_dir,
                serde_json::json!({
                    "kind": "set_spin_torque_enabled",
                    "module_id": module_id,
                    "enabled": enabled,
                    "vector_count": vectors.len(),
                }),
            )?;
            Ok(SyntheticStageOutcome {
                magnetization: vectors,
                message: format!(
                    "Spin torque module {module_id} {}",
                    if *enabled { "enabled" } else { "disabled" }
                ),
            })
        }
    }
}

// ── main orchestration entry point ───────────────────────────────────────────

fn resolve_preview_field_every_n(
    preview_3d_disabled: bool,
    requested_backend_name: &str,
    override_raw: Option<&str>,
) -> Result<u64> {
    if preview_3d_disabled {
        return Ok(u64::MAX);
    }
    if let Some(raw) = override_raw {
        let every_n = match raw.trim().parse::<u64>() {
            Ok(every_n) => every_n,
            Err(_) => bail!("FULLMAG_PREVIEW_EVERY_N must be a positive integer, got '{raw}'"),
        };
        if every_n == 0 || every_n > u64::from(u32::MAX) {
            bail!(
                "FULLMAG_PREVIEW_EVERY_N must be between 1 and {}, got {}",
                u32::MAX,
                every_n
            );
        }
        return Ok(every_n);
    }
    Ok(if requested_backend_name == "fem" {
        10
    } else {
        50
    })
}

const DEFAULT_AUTO_RAYON_THREAD_CAP: usize = 16;

fn parse_positive_thread_count(raw: Option<&str>) -> Option<usize> {
    raw.and_then(|value| value.parse::<usize>().ok())
        .filter(|&threads| threads >= 1)
}

fn resolve_rayon_cpu_threads(
    default_cpu_threads: usize,
    fullmag_cpu_threads: Option<&str>,
    rayon_cpu_threads: Option<&str>,
    external_auto_resolved: Option<&str>,
) -> (usize, bool) {
    if fullmag_cpu_threads.is_some_and(|value| value.eq_ignore_ascii_case("auto")) {
        let external = parse_positive_thread_count(external_auto_resolved);
        return (
            external
                .unwrap_or(DEFAULT_AUTO_RAYON_THREAD_CAP)
                .min(default_cpu_threads.max(1)),
            true,
        );
    }
    (
        parse_positive_thread_count(fullmag_cpu_threads)
            .or_else(|| parse_positive_thread_count(rayon_cpu_threads))
            .unwrap_or(default_cpu_threads.max(1)),
        false,
    )
}

pub(crate) fn run_script_mode(raw_args: Vec<OsString>) -> Result<()> {
    let mut args = ScriptCli::parse_from(raw_args);
    let ui_plan = crate::script_launch::ui_plan(&args);
    if ui_plan == crate::script_launch::UiPlan::None {
        // `--ui none` is the headless web side.
        args.headless = true;
    }
    if let Some(port) = args.api_port {
        // `--api-port` replaces the FULLMAG_API_PORT convention for this run.
        std::env::set_var("FULLMAG_API_PORT", port.to_string());
    }
    if args.headless {
        init_headless_api_port()?;
    } else {
        init_api_port()?;
    }
    if crate::script_launch::is_managed_run() && api_port() != 0 {
        crate::script_launch::note_api_port(api_port());
    }

    // Eagerly configure the global Rayon pool used by Rust-side control-plane
    // work. Native FEM CPU OpenMP thread selection is resolved separately and
    // logged by the managed/runtime backend.
    let default_cpu_threads = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1);
    let fullmag_cpu_threads = std::env::var("FULLMAG_CPU_THREADS").ok();
    let rayon_cpu_threads = std::env::var("RAYON_NUM_THREADS").ok();
    let external_auto_resolved = std::env::var("FULLMAG_CPU_THREADS_AUTO_RESOLVED").ok();
    let (cpu_threads, auto_cap_applied) = resolve_rayon_cpu_threads(
        default_cpu_threads,
        fullmag_cpu_threads.as_deref(),
        rayon_cpu_threads.as_deref(),
        external_auto_resolved.as_deref(),
    );
    let rayon_log_detail = match fullmag_cpu_threads.as_deref() {
        Some(raw) if raw.eq_ignore_ascii_case("auto") => {
            if auto_cap_applied && external_auto_resolved.is_some() {
                " (FULLMAG_CPU_THREADS=auto; external auto-resolved cap)"
            } else {
                " (FULLMAG_CPU_THREADS=auto; conservative control-plane cap)"
            }
        }
        Some(_) => " (source=FULLMAG_CPU_THREADS)",
        None => match rayon_cpu_threads {
            Some(_) => " (source=RAYON_NUM_THREADS)",
            None => " (default host parallelism)",
        },
    };
    if let Err(e) = rayon::ThreadPoolBuilder::new()
        .num_threads(cpu_threads)
        .build_global()
    {
        eprintln!(
            "[fullmag-cli] WARNING: could not configure Rayon control-plane pool ({cpu_threads} threads): {e}"
        );
    } else {
        eprintln!(
            "[fullmag-cli] Rayon control-plane pool: {cpu_threads} threads{rayon_log_detail}"
        );
    }

    // Load feature flags once at startup (file > env > defaults)
    let feature_flags = crate::feature_flags::FeatureFlags::resolve();
    if feature_flags.any_active() {
        eprintln!(
            "[fullmag-cli] Feature flags active: {}",
            feature_flags.summary()
        );
    }
    crate::live_workspace::init_feature_flags(feature_flags);

    let started_at_unix_ms = attached_session_started_at_or(unix_time_millis()?)?;
    let script_path = args
        .script
        .canonicalize()
        .with_context(|| format!("failed to resolve script path {}", args.script.display()))?;
    if let Err(error) = check_script_syntax_via_python(&script_path) {
        crate::script_launch::mark_failure(crate::script_launch::ExitKind::Syntax);
        return Err(error);
    }
    crate::script_launch::note_stage(crate::script_launch::Stage::Materializing);
    eprintln!("fullmag syntax check passed");
    eprintln!("- script: {}", script_path.display());
    let requested_backend_name = args
        .backend
        .map(|value| value.to_possible_value().unwrap().get_name().to_string())
        .unwrap_or_else(|| "auto".to_string());
    let requested_mode_name = args
        .mode
        .map(|value| value.to_possible_value().unwrap().get_name().to_string())
        .unwrap_or_else(|| "strict".to_string());
    let requested_precision_name = args
        .precision
        .map(|value| value.to_possible_value().unwrap().get_name().to_string())
        .unwrap_or_else(|| "double".to_string());

    let session_id = attached_session_id_or(format!(
        "session-{}-{}",
        started_at_unix_ms,
        std::process::id()
    ));
    let run_id = format!("run-{}", session_id);
    crate::script_launch::note_ids(&session_id, &run_id);
    let default_session_root = runtime_state_root(&repo_root())
        .join("local-live")
        .join("history");
    let session_root = if args.session_root == Path::new(".fullmag/local-live/history") {
        default_session_root.as_path()
    } else {
        args.session_root.as_path()
    };
    // Keep preparation state in its session directory until authored storage has
    // been captured and the shared lease reserves the actual result directory.
    let mut output_paths = ScriptOutputPaths {
        workspace_dir: session_root.join(&session_id),
        artifact_dir: session_root.join(&session_id).join("artifacts"),
        is_sibling_zarr_bundle: false,
    };
    let mut workspace_dir = output_paths.workspace_dir.clone();
    let mut artifact_dir = output_paths.artifact_dir.clone();
    fs::create_dir_all(&artifact_dir).with_context(|| {
        format!(
            "failed to create session artifact directory {}",
            artifact_dir.display()
        )
    })?;
    // When 3D preview is disabled, set field_every_n to infinity to skip expensive computations.
    // Keep FEM cadence aligned with interactive control-room expectations:
    // too-large step intervals make 3D magnetization look "stuck" even while
    // the run progresses in wall-clock time. The explicit override exists for
    // reproducible preview performance qualification and applies to both the
    // active field and the cached-field refresh cadence.
    let preview_3d_disabled = crate::live_workspace::feature_flags().disable_preview_3d;
    let preview_every_n_override_raw = std::env::var("FULLMAG_PREVIEW_EVERY_N").ok();
    let field_every_n = resolve_preview_field_every_n(
        preview_3d_disabled,
        &requested_backend_name,
        preview_every_n_override_raw.as_deref(),
    )?;
    let preview_every_n_override = preview_every_n_override_raw
        .as_ref()
        .map(|_| field_every_n as u32);
    let grid_refresh_command_id = std::env::var("FULLMAG_ATTACHED_GRID_REFRESH_COMMAND_ID").ok();
    let current_live_publisher = if grid_refresh_command_id.is_some() {
        CurrentLivePublisher::unpublished_grid_refresh()
    } else {
        CurrentLivePublisher::spawn(&session_id)
    };
    let bootstrapping_runtime = requested_runtime_selection(
        &requested_backend_name,
        false,
        "auto",
        &requested_precision_name,
        &requested_mode_name,
        None,
    );
    let bootstrapping_session_manifest = build_session_manifest(
        &session_id,
        &run_id,
        "bootstrapping",
        args.interactive,
        &script_path,
        script_path
            .file_stem()
            .and_then(|stem| stem.to_str())
            .unwrap_or("fullmag_script"),
        &bootstrapping_runtime,
        &artifact_dir,
        started_at_unix_ms,
        started_at_unix_ms,
        serde_json::json!({ "status": "bootstrapping" }),
    );
    let bootstrapping_run_manifest =
        build_run_manifest(&run_id, &session_id, "bootstrapping", &artifact_dir);
    let bootstrap_live_state_manifest = bootstrap_live_state("bootstrapping");
    let simulation_preparation = new_simulation_preparation(
        format!("preparation-{session_id}"),
        u64::try_from(started_at_unix_ms).context("preparation start timestamp exceeds u64")?,
    )?;
    let live_workspace = LocalLiveWorkspace::new(
        LocalLiveWorkspaceState {
            session: bootstrapping_session_manifest.clone(),
            run: bootstrapping_run_manifest.clone(),
            live_state: bootstrap_live_state_manifest.clone(),
            fem_mesh: None,
            metadata: None,
            mesh_workspace: None,
            stage_execution: None,
            simulation_preparation: Some(simulation_preparation),
            latest_scalar_row: None,
            latest_fields: CurrentLiveLatestFields::default(),
            replace_latest_fields: false,
            field_generation: None,
            preview_fields: CurrentLivePreviewFieldCache::default(),
            pending_preview_fields: CurrentLivePreviewFieldCache::default(),
            superseded_pending_preview_fields: Vec::new(),
            clear_preview_cache: false,
            preview_cache_revision: 0,
            engine_log: Vec::new(),
            solver_profile: fullmag_runner::SolverProfileState::default(),
            published_fem_mesh_generation_id: None,
        },
        current_live_publisher.clone(),
    );
    let display_selection_handle = if let Some(command_id) = grid_refresh_command_id.as_ref() {
        CurrentLiveDisplaySelectionHandle::spawn_for_grid_refresh(session_id.clone(), command_id.clone())
    } else {
        CurrentLiveDisplaySelectionHandle::spawn_for_session(Some(session_id.clone()))
    };
    live_workspace.push_log(
        "system",
        format!(
            "Workspace started for {}",
            script_path
                .file_name()
                .and_then(|file_name| file_name.to_str())
                .unwrap_or("script.py")
        ),
    );
    live_workspace.push_log(
        "info",
        format!(
            "Requested backend: {} · mode: {} · precision: {}",
            requested_backend_name, requested_mode_name, requested_precision_name
        ),
    );

    announce_session_start(
        &session_id,
        &script_path,
        &requested_backend_name,
        args.headless,
    );

    let mut _control_room_guard = ControlRoomGuard::inactive();

    // ── Parallelize: Phase-1 Python (skip geometry assets) + control room bootstrap ──
    // Phase 1 returns the lightweight ProblemIR without triggering Gmsh.
    // The control room (API + frontend) starts concurrently.
    // This gives the frontend early metadata (~300ms) while the mesh builds.
    live_workspace.publish_snapshot();
    begin_script_materialization(&live_workspace)?;
    live_workspace.update(|state| {
        state.session.status = "materializing_script".to_string();
        state.run.status = "materializing_script".to_string();
        set_live_state_status(&mut state.live_state, "materializing_script", Some(false));
    });
    live_workspace.push_log(
        "info",
        "Materializing Python script, importing geometry, and preparing execution plan",
    );

    // Phase 1: fast pre-pass without geometry assets, runs concurrently with frontend startup.
    // A headless run has no frontend that can consume the early metadata, and
    // the full materialization/solver-initialization safety boundary below
    // performs the authoritative validation.  Skip this duplicate Python
    // import in headless mode to remove one process start and one script pass.
    let phase1_handle = if args.headless {
        None
    } else {
        let phase1_script_path = script_path.clone();
        let phase1_backend = args.backend;
        let phase1_mode = args.mode;
        let phase1_precision = args.precision;
        let phase1_execution_layers = crate::python_bridge::script_cli_execution_layers(&args)?;
        let phase1_runtime_device = crate::python_bridge::managed_execution_device(
            phase1_backend,
            std::env::var("FULLMAG_FEM_EXECUTION").ok().as_deref(),
            std::env::var("FULLMAG_FDM_EXECUTION").ok().as_deref(),
        );
        Some(own_preparation_boundary_failure(
            &live_workspace,
            "script_materialization_thread_start_failed",
            "Python script materialization could not start",
            std::thread::Builder::new()
                .name("fullmag-materialize-phase1".to_string())
                .spawn(move || -> Result<ScriptExecutionConfig> {
                    use clap::ValueEnum;
                    let mut helper_args = vec![
                        "-m".to_string(),
                        "fullmag.runtime.helper".to_string(),
                        "export-run-config".to_string(),
                        "--script".to_string(),
                        phase1_script_path.display().to_string(),
                        "--skip-geometry-assets".to_string(),
                    ];
                    if let Some(backend) = phase1_backend {
                        helper_args.push("--backend".to_string());
                        helper_args
                            .push(backend.to_possible_value().unwrap().get_name().to_string());
                    }
                    if let Some(mode) = phase1_mode {
                        helper_args.push("--mode".to_string());
                        helper_args.push(mode.to_possible_value().unwrap().get_name().to_string());
                    }
                    if let Some(precision) = phase1_precision {
                        helper_args.push("--precision".to_string());
                        helper_args.push(
                            precision
                                .to_possible_value()
                                .unwrap()
                                .get_name()
                                .to_string(),
                        );
                    }
                    if let Some(device) = phase1_runtime_device {
                        helper_args.push("--runtime-device".to_string());
                        helper_args.push(device.to_string());
                    }
                    let output = run_python_helper_with_progress(&helper_args, None)
                        .context("phase-1 python helper failed")?;
                    if !output.status.success() {
                        let stderr = String::from_utf8_lossy(&output.stderr);
                        bail!("phase-1 python helper exited non-zero: {}", stderr.trim());
                    }
                    let stdout = String::from_utf8(output.stdout)
                        .context("phase-1 output not valid UTF-8")?;
                    let json_str = crate::python_bridge::extract_json_from_stdout(&stdout)?;
                    let mut config = serde_json::from_str(json_str)
                        .context("failed to deserialize phase-1 script execution config")?;
                    crate::python_bridge::bind_script_execution_profiles(
                        &mut config,
                        &phase1_execution_layers,
                    )?;
                    Ok(config)
                })
                .context("failed to spawn phase-1 materialization thread"),
        )?)
    };

    eprintln!("fullmag materializing script");

    if !args.headless && !control_room_bootstrap_disabled() {
        let (web_port, child, frontend_child) = own_preparation_boundary_failure(
            &live_workspace,
            "control_room_bootstrap_failed",
            "Control Room bootstrap failed",
            spawn_control_room(
                &session_id,
                args.dev,
                args.web_port,
                &live_workspace,
                ui_plan,
            )
            .with_context(|| {
                format!(
                    "failed to bootstrap control room for workspace {}",
                    session_id
                )
            }),
        )?;
        eprintln!("fullmag control room bootstrap verified");
        crate::script_launch::note_ui_ready();
        live_workspace.push_log("system", "Control room bootstrap verified");
        _control_room_guard = ControlRoomGuard::active(web_port, child, frontend_child);
        let failed_workspace = live_workspace.clone();
        let failure_control = display_selection_handle.clone();
        _control_room_guard.retain_terminal_failure_until_close(move || {
            wait_for_failed_preparation_close(&failed_workspace, || {
                failure_control.wait_next_command_coalesced(Duration::from_millis(250))
            });
        });
    }

    // Keep a small bridge alive for a Control Room-created scratch session.
    // The bridge ignores this script-backed session and only attaches a fresh
    // runtime after the browser explicitly replaces it with a runnable scene.
    let _scratch_runtime = if !args.headless {
        std::env::current_exe()
            .ok()
            .map(|executable| {
                fullmag_runtime_control::application_attach::prepare_for_authoring(
                    &crate::control_room::repo_root(),
                    &crate::control_room::runtime_state_root(&crate::control_room::repo_root()),
                    api_port(),
                )
                .map(|binding| {
                    crate::scratch_runtime::spawn(
                        api_port(),
                        executable,
                        Some(session_id.clone()),
                        binding.api_instance_id().to_owned(),
                    )
                })
                .map_err(|error| {
                    eprintln!("[fullmag] scratch observer identity unavailable: {error:#}")
                })
                .ok()
            })
            .flatten()
    } else {
        None
    };

    // Join Phase 1 and push early metadata to the already-loaded frontend.
    let (early_config, authoritative_preflight_error) = match phase1_handle {
        None => (None, None),
        Some(phase1_handle) => match phase1_handle
            .join()
            .unwrap_or_else(|_| Err(anyhow::anyhow!("phase-1 thread panicked")))
        {
            Ok(early_config) => {
                let early_problem = early_config
                    .stages
                    .last()
                    .map(|s| &s.ir)
                    .unwrap_or(&early_config.ir);
                let problem_name = early_problem.problem_meta.name.clone();
                let stage_names: Vec<String> = early_config
                    .stages
                    .iter()
                    .map(|s| s.ir.problem_meta.name.clone())
                    .collect();
                let geometry_names: Vec<String> = early_problem
                    .geometry
                    .entries
                    .iter()
                    .map(|e| e.name().to_string())
                    .collect();
                live_workspace.update(|state| {
                    if state.metadata.is_none() {
                        state.metadata = Some(serde_json::json!({
                            "problem_name": problem_name,
                            "stage_count": early_config.stages.len(),
                            "stage_names": stage_names,
                            "geometry_names": geometry_names,
                            "early_preview": true,
                        }));
                    }
                });
                live_workspace.push_log(
                    "info",
                    format!(
                        "Problem: {} · {} stage(s) · {} geometry object(s)",
                        problem_name,
                        early_config.stages.len().max(1),
                        geometry_names.len()
                    ),
                );
                (Some(early_config), None)
            }
            Err(err) => {
                if project_authoritative_authored_preflight_failure(&live_workspace, &err)? {
                    eprintln!(
                        "[fullmag] authored capability preflight rejected the execution plan"
                    );
                    (None, Some(err))
                } else {
                    // A transport or helper failure remains non-fatal; Phase 2 owns the real result.
                    eprintln!("[fullmag] phase-1 pre-pass skipped: {:#}", err);
                    let timestamp_unix_ms = preparation_unix_time_millis()?;
                    transition_preparation(&live_workspace, |preparation| {
                        push_preparation_log_once(
                        preparation,
                        timestamp_unix_ms,
                        PreparationLogLevel::Warning,
                        PreparationStageId::ScriptMaterialization,
                        "Lightweight script preflight was unavailable; using full materialization",
                    );
                        Ok(())
                    })?;
                    (None, None)
                }
            }
        },
    };
    if let Some(config) = early_config.as_ref().filter(|config| requires_antenna_lead_materialization(config)) {
        run_active_preparation_operation(
            &live_workspace,
            "script_materialization_failed",
            "Authored antenna lead validation failed",
            || {
                config.antenna_inventory.validate().map_err(anyhow::Error::msg)?;
                validate_ir(&config.ir)?;
                for stage in &config.stages {
                    validate_ir(&stage.ir)?;
                }
                Ok(())
            },
        )?;
        live_workspace.push_log(
            "info",
            "Antenna lead planning deferred until the independent conductor mesh is materialized",
        );
    }
    let early_preflight_completed = if let Some(early_config) = early_config.filter(|config| !requires_antenna_lead_materialization(config)) {
        let early_stages = run_active_preparation_operation(
            &live_workspace,
            "script_materialization_failed",
            "Python script materialization failed",
            || materialize_script_stages(early_config),
        )?;
        run_script_preparation_preflight(
            &live_workspace,
            || {
                if early_stages.is_empty() {
                    bail!("script did not produce any executable stages");
                }
                for stage in &early_stages {
                    validate_ir(&stage.ir)?;
                }
                Ok(())
            },
            || {
                for stage in &early_stages {
                    stage
                        .ir
                        .plan_for(args.backend.map(BackendTarget::from))
                        .map_err(join_errors)?;
                }
                Ok(())
            },
        )?;
        true
    } else {
        false
    };
    let export_full_script = || {
        export_script_execution_config_via_python(
            &script_path,
            &args,
            Some({
                let live_workspace = live_workspace.clone();
                Arc::new(move |event: PythonProgressEvent| {
                    let terminal_line = match &event {
                        PythonProgressEvent::Message(message) => {
                            (!message.trim_start().starts_with("json:"))
                                .then(|| format!("[fullmag] materialize - {}", message))
                        }
                        PythonProgressEvent::FemSurfacePreview { message, .. } => message
                            .as_ref()
                            .map(|text| format!("[fullmag] materialize - {}", text)),
                        PythonProgressEvent::Structured { payload, .. } => payload
                            .get("message")
                            .and_then(|value| value.as_str())
                            .map(|message| format!("[fullmag] materialize - {}", message)),
                    };
                    apply_python_progress_event(&live_workspace, event);
                    if let Some(line) = terminal_line {
                        eprintln!("{}", line);
                    }
                })
            }),
        )
    };
    let script_export = authoritative_preflight_error.map_or_else(export_full_script, Err);
    let mut script_config = match script_export {
        Ok(config) => config,
        Err(error) => {
            let error =
                project_script_export_failure(&live_workspace, early_preflight_completed, error)?;
            let failed_at_unix_ms = unix_time_millis()?;
            let failed_snapshot = live_workspace.snapshot();
            let failed_runtime = requested_runtime_selection(
                &requested_backend_name,
                false,
                "auto",
                &requested_precision_name,
                &requested_mode_name,
                None,
            );
            live_workspace.replace(LocalLiveWorkspaceState {
                session: build_session_manifest(
                    &session_id,
                    &run_id,
                    "failed",
                    args.interactive,
                    &script_path,
                    script_path
                        .file_stem()
                        .and_then(|stem| stem.to_str())
                        .unwrap_or("fullmag_script"),
                    &failed_runtime,
                    &artifact_dir,
                    started_at_unix_ms,
                    failed_at_unix_ms,
                    serde_json::json!({ "status": "bootstrap_failed" }),
                ),
                run: build_run_manifest(&run_id, &session_id, "failed", &artifact_dir),
                live_state: {
                    let mut live_state = bootstrap_live_state("failed");
                    live_state.latest_step.finished = true;
                    live_state
                },
                fem_mesh: failed_snapshot.fem_mesh,
                metadata: failed_snapshot.metadata,
                mesh_workspace: failed_snapshot.mesh_workspace,
                stage_execution: None,
                simulation_preparation: failed_snapshot.simulation_preparation,
                latest_scalar_row: None,
                latest_fields: CurrentLiveLatestFields::default(),
                replace_latest_fields: false,
                field_generation: None,
                preview_fields: CurrentLivePreviewFieldCache::default(),
                pending_preview_fields: CurrentLivePreviewFieldCache::default(),
                superseded_pending_preview_fields: Vec::new(),
                clear_preview_cache: false,
                preview_cache_revision: 0,
                engine_log: failed_snapshot.engine_log,
                solver_profile: fullmag_runner::SolverProfileState::default(),
                published_fem_mesh_generation_id: None,
            });
            live_workspace.push_log("error", format!("Script materialization failed: {}", error));
            return Err(error);
        }
    };
    // Grid authoring must not reserve the user's next scientific output path
    // or modify its existing-output policy in the canonical script/IR.
    let (mut storage_lease, storage_settings, resolved_storage) =
        if let Some(command_id) = grid_refresh_command_id.as_deref() {
            prepare_grid_operation_storage(&workspace_dir, command_id, &script_path)?
        } else {
            prepare_script_output_storage(&mut script_config, &args, &script_path, &run_id)?
        };
    workspace_dir = storage_lease.resolved().output_dir.clone();
    crate::script_launch::note_results_dir(&workspace_dir);
    crate::script_launch::note_source_hash(script_config.ir.problem_meta.source_hash.as_deref());
    artifact_dir = workspace_dir.join("artifacts");
    output_paths = ScriptOutputPaths {
        workspace_dir: workspace_dir.clone(),
        artifact_dir: artifact_dir.clone(),
        is_sibling_zarr_bundle: storage_settings.data_format == OutputDataFormatIR::Zarr,
    };
    fs::create_dir_all(&artifact_dir).with_context(|| {
        format!(
            "failed to create project artifact directory {}",
            artifact_dir.display()
        )
    })?;
    fs::create_dir_all(workspace_dir.join("stages")).with_context(|| {
        format!(
            "failed to create project stage directory {}",
            workspace_dir.join("stages").display()
        )
    })?;
    if output_paths.is_sibling_zarr_bundle {
        initialize_zarr_group(
            &artifact_dir,
            serde_json::json!({"fullmag_role": "final_stage_artifacts"}),
        )?;
        initialize_zarr_group(
            &workspace_dir.join("stages"),
            serde_json::json!({"fullmag_role": "stage_artifacts"}),
        )?;
        eprintln!("- result_bundle: {}", workspace_dir.display());
    }
    live_workspace.update(|state| {
        state.session.artifact_dir = artifact_dir.display().to_string();
        state.run.artifact_dir = artifact_dir.display().to_string();
        state.metadata = Some(serde_json::json!({
            "output_storage": storage_settings,
            "resolved_output_storage": resolved_storage,
        }));
    });
    let mut stages = run_active_preparation_operation(
        &live_workspace,
        "script_materialization_failed",
        "Simulation stage materialization failed",
        || materialize_script_stages(script_config),
    )?;
    if !early_preflight_completed {
        if args.headless {
            // Headless runs perform the authoritative validation and planning
            // inside `run_solver_initialization` after the complete script
            // export has been materialized.  Keep the preparation state
            // transitions for the live manifest without repeating those
            // expensive passes here.
            run_script_preparation_preflight(
                &live_workspace,
                || {
                    if stages.is_empty() {
                        bail!("script did not produce any executable stages");
                    }
                    Ok(())
                },
                || Ok(()),
            )?;
        } else {
            run_script_preparation_preflight(
                &live_workspace,
                || {
                    if stages.is_empty() {
                        bail!("script did not produce any executable stages");
                    }
                    for stage in &stages {
                        validate_ir(&stage.ir)?;
                    }
                    Ok(())
                },
                || {
                    for stage in &stages {
                        stage
                            .ir
                            .plan_for(args.backend.map(BackendTarget::from))
                            .map_err(join_errors)?;
                    }
                    Ok(())
                },
            )?;
        }
    }
    let detailed_mesh_workspace = live_workspace.snapshot().mesh_workspace;
    finish_mesh_preparation(&live_workspace, detailed_mesh_workspace.as_ref())?;
    let solver_initialization_required = stages
        .iter()
        .any(|stage| stage.action.is_none() && stage.entrypoint_kind != "flat_workspace");

    let (
        mut stage_execution_plans,
        mut current_plan_summary,
        mut initial_execution_plan,
        initial_live_state,
        initial_fem_mesh,
        mut initial_fem_mesh_asset,
    ) = run_solver_initialization(&live_workspace, !solver_initialization_required, || {
        let initial_magnetization_override = run_solver_initialization_safety_check(
            &live_workspace,
            "Checking fully materialized runtime validity",
            "solver_initialization_materialized_validation_failed",
            "Fully materialized runtime validation failed during solver initialization",
            || {
                if stages.is_empty() {
                    bail!("script did not produce any executable stages");
                }
                let initial_magnetization_override = initial_magnetization_state_override(&args)?;
                apply_initial_magnetization_state_override(
                    &mut stages[0].ir,
                    initial_magnetization_override.as_ref(),
                )?;
                for stage in &stages {
                    validate_ir(&stage.ir)?;
                }
                Ok(initial_magnetization_override)
            },
        )?;
        let (stage_execution_plans, current_plan_summary) = run_solver_initialization_safety_check(
            &live_workspace,
            "Checking the fully materialized execution plan",
            "solver_initialization_materialized_planning_failed",
            "Fully materialized execution planning failed during solver initialization",
            || {
                let stage_execution_plans = stages
                    .iter()
                    .map(plan_materialized_stage_snapshot)
                    .collect::<Result<Vec<_>>>()?;
                let current_plan_summary = stages[0]
                    .ir
                    .plan_for(args.backend.map(BackendTarget::from))
                    .map_err(join_errors)?;
                Ok((stage_execution_plans, current_plan_summary))
            },
        )?;
        let initial_execution_plan = stage_execution_plans[0].clone();
        let initial_fem_mesh_asset = fullmag_runner::StageFemMeshAsset::build_from_backend_plan(
            &initial_execution_plan.backend_plan,
        );
        let initial_update = initial_step_update(
            &initial_execution_plan.backend_plan,
            initial_fem_mesh_asset
                .as_ref()
                .map(|asset| asset.identity.generation_id().to_string()),
        );
        let initial_magnetization_override_values = initial_magnetization_override
            .as_ref()
            .map(|state| state.values.clone());
        let (initial_live_state, initial_fem_mesh) = initial_live_state_manifest_from_backend_plan(
            &initial_update,
            &initial_execution_plan.backend_plan,
            initial_fem_mesh_asset
                .as_ref()
                .map(|asset| asset.payload.clone()),
            initial_magnetization_override_values.as_deref(),
        )?;
        Ok((
            stage_execution_plans,
            current_plan_summary,
            initial_execution_plan,
            initial_live_state,
            initial_fem_mesh,
            initial_fem_mesh_asset,
        ))
    })?;
    let mut current_mesh_history = Vec::<serde_json::Value>::new();
    let mut current_mesh_quality: Option<crate::python_bridge::RemeshQualitySummary> = None;
    let mut current_fem_mesh_override: Option<fullmag_ir::MeshIR> = None;
    let mut current_fem_hmax_override: Option<f64> = None;
    let mut current_adaptive_runtime_state: Option<serde_json::Value> = None;

    let final_problem_name = stages
        .last()
        .expect("stages should be non-empty after validation")
        .ir
        .problem_meta
        .name
        .clone();
    let final_requested_backend = stages
        .last()
        .expect("stages should be non-empty after validation")
        .ir
        .backend_policy
        .requested_backend;
    let final_execution_mode = stages
        .last()
        .expect("stages should be non-empty after validation")
        .ir
        .validation_profile
        .execution_mode;
    let final_precision = stages
        .last()
        .expect("stages should be non-empty after validation")
        .ir
        .backend_policy
        .execution_precision;
    let mut interactive_template_ir = stages
        .last()
        .expect("stages should be non-empty after validation")
        .ir
        .clone();
    let script_requested_interactive = stages
        .last()
        .and_then(|stage| {
            stage
                .ir
                .problem_meta
                .runtime_metadata
                .get("interactive_session_requested")
        })
        .and_then(|value| value.as_bool())
        .unwrap_or(false);
    let interactive_requested = interactive_session_should_stay_alive(
        args.interactive,
        script_requested_interactive,
        args.headless,
    );
    let mut final_session_runtime = stages
        .last()
        .map(|stage| {
            session_runtime_selection_for_problem(
                &stage.ir,
                stage_execution_plans.last(),
                field_every_n,
                backend_target_name(final_requested_backend),
                execution_mode_name(final_execution_mode),
                execution_precision_name(final_precision),
            )
        })
        .unwrap_or_else(|| {
            requested_runtime_selection(
                backend_target_name(final_requested_backend),
                false,
                "auto",
                execution_precision_name(final_precision),
                execution_mode_name(final_execution_mode),
                None,
            )
        });

    let previous_workspace = live_workspace.snapshot();
    let initial_runtime = session_runtime_selection_for_problem(
        &stages[0].ir,
        Some(&initial_execution_plan),
        field_every_n,
        backend_target_name(final_requested_backend),
        execution_mode_name(final_execution_mode),
        execution_precision_name(final_precision),
    );
    let initial_live_metadata =
        current_live_metadata(&stages[0].ir, &initial_execution_plan, "running");
    let initial_mesh_workspace = current_mesh_workspace(
        &stages[0].ir,
        &initial_execution_plan,
        "running",
        current_mesh_quality.as_ref(),
        &current_mesh_history,
    );
    live_workspace.replace(LocalLiveWorkspaceState {
        session: build_session_manifest(
            &session_id,
            &run_id,
            "running",
            interactive_requested,
            &script_path,
            &final_problem_name,
            &initial_runtime,
            &artifact_dir,
            started_at_unix_ms,
            started_at_unix_ms,
            plan_summary_json(&current_plan_summary),
        ),
        run: build_run_manifest(&run_id, &session_id, "running", &artifact_dir),
        live_state: initial_live_state,
        fem_mesh: initial_fem_mesh,
        metadata: Some(initial_live_metadata),
        mesh_workspace: merge_detailed_mesh_workspace(
            initial_mesh_workspace,
            previous_workspace.mesh_workspace.as_ref(),
        ),
        stage_execution: None,
        simulation_preparation: previous_workspace.simulation_preparation,
        latest_scalar_row: None,
        latest_fields: CurrentLiveLatestFields::default(),
        replace_latest_fields: false,
        field_generation: None,
        preview_fields: CurrentLivePreviewFieldCache::default(),
        pending_preview_fields: CurrentLivePreviewFieldCache::default(),
        superseded_pending_preview_fields: Vec::new(),
        clear_preview_cache: false,
        preview_cache_revision: 0,
        engine_log: previous_workspace.engine_log,
        solver_profile: fullmag_runner::SolverProfileState::default(),
        published_fem_mesh_generation_id: None,
    });
    mark_preparation_ready(&live_workspace, "Simulation is ready")?;
    live_workspace.push_log(
        "system",
        format!(
            "Script materialized — problem: {} · stages: {}",
            final_problem_name,
            stages.len()
        ),
    );
    eprintln!(
        "fullmag script materialized\n- problem: {}\n- stages: {}",
        final_problem_name,
        stages.len()
    );
    for (stage_index, (stage, plan)) in stages.iter().zip(stage_execution_plans.iter()).enumerate()
    {
        log_execution_plan(stage_index, stages.len(), stage, plan);
        for line in execution_plan_log_lines(stage_index, stages.len(), stage, plan) {
            live_workspace.push_log("info", line);
        }
    }
    if args.dev && !args.headless {
        let _ = run_post_materialization_dev_smoke_tests(
            &session_id,
            &initial_execution_plan,
            &live_workspace,
        );
    }

    // All physical predecessors must export history before the first active
    // constraint or M3 stage; an earlier unconstrained Relax is not M-only.
    let headless_frozen_lifecycle_required = args.headless && stage_execution_plans.iter().any(|execution| {
        matches!(&execution.backend_plan, BackendPlanIR::Fdm(plan)
            if plan.frozen_spins.is_some() || plan.spin_transport_plans.iter()
                .any(|transport| transport.fdm_cpu_double_transient.is_some()))
    });
    let mut headless_frozen_continuation: Option<HeadlessFrozenContinuation> = None;
    let mut headless_has_physical_predecessor = false;
    let stage_count = stages.len();
    let mut aggregated_steps = Vec::<fullmag_runner::StepStats>::new();
    let mut step_offset = 0u64;
    let mut time_offset = 0.0f64;
    let mut published_antenna_outputs = std::collections::BTreeMap::new();
    let scheduled_spectrum_request_ids = stages
        .iter()
        .filter_map(|stage| match stage.action.as_ref() {
            Some(ResolvedScriptStageAction::AntennaSourceSpectrum { request_id }) => Some(request_id.clone()),
            _ => None,
        })
        .collect::<std::collections::BTreeSet<_>>();
    let scheduled_solved_drives = stages
        .iter()
        .filter_map(|stage| match stage.action.as_ref() {
            Some(ResolvedScriptStageAction::AddSolvedAntennaDrive { projection_id, drive_id }) => {
                Some((projection_id.clone(), drive_id.clone()))
            }
            _ => None,
        })
        .collect::<Vec<_>>();
    let mut activated_solved_drive_ids = std::collections::BTreeSet::new();
    let mut continuation_magnetization: Option<Vec<[f64; 3]>> = None;
    let mut continuation_source: Option<ContinuationSource> = None;
    let mut saved_state_sources: HashMap<String, ContinuationSource> = HashMap::new();
    let mut continuation_fem_mesh_payload: Option<fullmag_runner::FemMeshPayload> = None;
    let mut continuation_completion: Option<fullmag_ir::StageCompletionIR> = None;
    let mut continuation_stage_source: Option<ContinuationStageSource> = None;
    let mut continuation_accepted_fields: Option<fullmag_runner::CertifiedFemEquilibriumFields> =
        None;
    let mut continuation_certified_fields: Option<fullmag_runner::CertifiedFemEquilibriumFields> =
        None;
    let mut continuation_relax_handoff: Option<fullmag_runner::AcceptedFemRelaxStageHandoff> = None;
    let mut start_solver_command_id: Option<String> = None;
    // The first solver command may be consumed by the wait-for-compute gate
    // before the regular interactive command loop starts. Keep the applied
    // scene revision across both paths so a Frozen Spins binding is neither
    // skipped at initial launch nor replayed later.
    let mut frozen_spins_applied_scene_revision: Option<u64> = None;
    let mut paused_stage: Option<PausedInteractiveStage> = None;
    let mut scripted_cancelled = false;

    // ── visualization quantity hint ──────────────────────────────────────
    // If the script declared `fm.visualization(active_quantity_id="...")`, push a
    // synthetic display-sync so the control room opens on that quantity.
    // If airbox or geometry hints are present, patch visualization overrides once.
    let mut initial_display_hint_applied = false;
    if let Some(viz_hint) = stages[0]
        .ir
        .problem_meta
        .runtime_metadata
        .get("visualization_hint")
    {
        if let Some(qty) = viz_hint.get("active_quantity_id").and_then(|v| v.as_str()) {
            if !qty.is_empty() {
                display_selection_handle.set_quantity_hint(qty, preview_every_n_override);
                initial_display_hint_applied = true;
            }
        }

        // Build VisualizationOverrideState entries for airbox and per-geometry hints.
        let mut overrides: Vec<serde_json::Value> = Vec::new();

        if let Some(airbox_hint) = viz_hint.get("airbox") {
            let show = airbox_hint
                .get("show")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);
            let mode = airbox_hint
                .get("mode")
                .and_then(|v| v.as_str())
                .unwrap_or("");
            let active_quantity_id = airbox_hint
                .get("active_quantity_id")
                .and_then(|v| v.as_str())
                .filter(|v| !v.is_empty());

            let mut display = serde_json::json!({ "visible": show });

            // mode-derived layer defaults
            match mode {
                "vectors" => {
                    display["vectors"] =
                        serde_json::json!({ "visible": true, "domain": "airbox_only" });
                }
                "surface" => {
                    display["surface"] = serde_json::json!({ "visible": true });
                }
                "wireframe" => {
                    display["wireframe"] = serde_json::json!({ "visible": true });
                }
                "surface+edges" => {
                    display["surface"] = serde_json::json!({ "visible": true });
                    display["wireframe"] = serde_json::json!({ "visible": true });
                }
                _ => {}
            }

            // explicit per-layer overrides
            if let Some(v) = airbox_hint.get("shaded").and_then(|v| v.as_bool()) {
                display["surface"] = serde_json::json!({ "visible": v });
            }
            if let Some(v) = airbox_hint.get("wireframe").and_then(|v| v.as_bool()) {
                display["wireframe"] = serde_json::json!({ "visible": v });
            }
            if let Some(v) = airbox_hint.get("bounds").and_then(|v| v.as_bool()) {
                display["bounds"] = serde_json::json!({ "visible": v });
            }
            if let Some(v) = airbox_hint.get("points").and_then(|v| v.as_bool()) {
                display["points"] = serde_json::json!({ "visible": v });
            }
            if let Some(v) = airbox_hint.get("opacity").and_then(|v| v.as_f64()) {
                display["opacity"] = serde_json::json!(v / 100.0);
            }
            if let Some(v) = airbox_hint.get("geometry_scope").and_then(|v| v.as_str()) {
                display["geometry_scope"] = serde_json::json!(v);
            }
            if let Some(density) = airbox_hint.get("vector_density").and_then(|v| v.as_u64()) {
                if display["vectors"].is_object() {
                    display["vectors"]["density"] = serde_json::json!(density);
                    display["vectors"]["domain"] = serde_json::json!("airbox_only");
                } else {
                    display["vectors"] = serde_json::json!({ "visible": true, "density": density, "domain": "airbox_only" });
                }
            }

            // style overrides
            let mut style = serde_json::Map::new();
            if let Some(v) = airbox_hint
                .get("vector_length_scale")
                .and_then(|v| v.as_f64())
            {
                style.insert("vector_length_scale".to_string(), serde_json::json!(v));
            }
            if let Some(v) = airbox_hint.get("vector_thickness").and_then(|v| v.as_f64()) {
                style.insert("vector_thickness".to_string(), serde_json::json!(v));
            }
            if let Some(v) = airbox_hint.get("vector_alpha").and_then(|v| v.as_f64()) {
                style.insert("vector_alpha".to_string(), serde_json::json!(v));
            }
            if let Some(v) = airbox_hint
                .get("vector_color_mode")
                .and_then(|v| v.as_str())
            {
                style.insert("vector_color_mode".to_string(), serde_json::json!(v));
            }

            let mut target_override = serde_json::json!({
                "scope": "airbox",
                "scope_id": "airbox",
                "visible": show,
                "display": display,
            });
            if !style.is_empty() {
                target_override["style"] = serde_json::Value::Object(style);
            }
            if let Some(qty) = active_quantity_id {
                target_override["quantity"] = serde_json::json!({ "active_quantity_id": qty });
            }
            overrides.push(target_override);
        }

        if let Some(geom_hints) = viz_hint.get("geometry_hints").and_then(|v| v.as_object()) {
            for (geom_name, geom_hint) in geom_hints {
                let show = geom_hint
                    .get("show")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(true);
                let mode = geom_hint.get("mode").and_then(|v| v.as_str()).unwrap_or("");
                let active_quantity_id = geom_hint
                    .get("active_quantity_id")
                    .and_then(|v| v.as_str())
                    .filter(|v| !v.is_empty());

                let mut display = serde_json::json!({ "visible": show });

                // mode-derived layer defaults
                match mode {
                    "vectors" => {
                        display["vectors"] =
                            serde_json::json!({ "visible": true, "domain": "object" });
                    }
                    "surface" => {
                        display["surface"] = serde_json::json!({ "visible": true });
                        display["wireframe"] = serde_json::json!({ "visible": false });
                    }
                    "wireframe" => {
                        display["surface"] = serde_json::json!({ "visible": false });
                        display["wireframe"] = serde_json::json!({ "visible": true });
                    }
                    "surface+edges" => {
                        display["surface"] = serde_json::json!({ "visible": true });
                        display["wireframe"] = serde_json::json!({ "visible": true });
                    }
                    "points" => {
                        display["surface"] = serde_json::json!({ "visible": false });
                        display["wireframe"] = serde_json::json!({ "visible": false });
                        display["points"] = serde_json::json!({ "visible": true });
                    }
                    _ => {}
                }

                // explicit per-layer overrides
                if let Some(v) = geom_hint.get("wireframe").and_then(|v| v.as_bool()) {
                    display["wireframe"] = serde_json::json!({ "visible": v });
                }
                if let Some(v) = geom_hint.get("bounds").and_then(|v| v.as_bool()) {
                    display["bounds"] = serde_json::json!({ "visible": v });
                }
                if let Some(v) = geom_hint.get("points").and_then(|v| v.as_bool()) {
                    display["points"] = serde_json::json!({ "visible": v });
                }
                if let Some(v) = geom_hint.get("opacity").and_then(|v| v.as_f64()) {
                    display["opacity"] = serde_json::json!(v / 100.0);
                }
                if let Some(v) = geom_hint.get("geometry_scope").and_then(|v| v.as_str()) {
                    display["geometry_scope"] = serde_json::json!(v);
                }
                if let Some(density) = geom_hint.get("vector_density").and_then(|v| v.as_u64()) {
                    let domain = geom_hint
                        .get("vector_domain")
                        .and_then(|v| v.as_str())
                        .unwrap_or("object");
                    if display["vectors"].is_object() {
                        display["vectors"]["density"] = serde_json::json!(density);
                        display["vectors"]["domain"] = serde_json::json!(domain);
                    } else {
                        display["vectors"] = serde_json::json!({ "visible": true, "density": density, "domain": domain });
                    }
                } else if let Some(domain) = geom_hint.get("vector_domain").and_then(|v| v.as_str())
                {
                    if display["vectors"].is_object() {
                        display["vectors"]["domain"] = serde_json::json!(domain);
                    }
                }

                // style overrides
                let mut style = serde_json::Map::new();
                if let Some(v) = geom_hint
                    .get("surface_color_source")
                    .and_then(|v| v.as_str())
                {
                    style.insert("surface_color_source".to_string(), serde_json::json!(v));
                }
                if let Some(v) = geom_hint
                    .get("vector_length_scale")
                    .and_then(|v| v.as_f64())
                {
                    style.insert("vector_length_scale".to_string(), serde_json::json!(v));
                }
                if let Some(v) = geom_hint.get("vector_thickness").and_then(|v| v.as_f64()) {
                    style.insert("vector_thickness".to_string(), serde_json::json!(v));
                }
                if let Some(v) = geom_hint.get("vector_alpha").and_then(|v| v.as_f64()) {
                    style.insert("vector_alpha".to_string(), serde_json::json!(v));
                }
                if let Some(v) = geom_hint.get("vector_color_mode").and_then(|v| v.as_str()) {
                    style.insert("vector_color_mode".to_string(), serde_json::json!(v));
                }
                if let Some(v) = geom_hint.get("vector_density").and_then(|v| v.as_u64()) {
                    style.insert("vector_budget".to_string(), serde_json::json!(v));
                }

                let mut target_override = serde_json::json!({
                    "scope": "object",
                    "scope_id": geom_name,
                    "visible": show,
                    "display": display,
                });
                if !style.is_empty() {
                    target_override["style"] = serde_json::Value::Object(style);
                }
                if let Some(qty) = active_quantity_id {
                    target_override["quantity"] = serde_json::json!({ "active_quantity_id": qty });
                }
                overrides.push(target_override);
            }
        }

        // Build global state patch from top-level visualization hint fields.
        let mut state_patch = serde_json::json!({});
        if !overrides.is_empty() {
            state_patch["overrides"] = serde_json::Value::Array(overrides);
        }

        // quantity patch (colormap, auto_contrast, field_component)
        {
            let mut qty_patch = serde_json::Map::new();
            if let Some(qty) = viz_hint.get("active_quantity_id").and_then(|v| v.as_str()) {
                if !qty.is_empty() {
                    qty_patch.insert("active_quantity_id".to_string(), serde_json::json!(qty));
                }
            }
            if let Some(v) = viz_hint.get("colormap").and_then(|v| v.as_str()) {
                qty_patch.insert("colormap".to_string(), serde_json::json!(v));
            }
            if let Some(v) = viz_hint.get("auto_contrast").and_then(|v| v.as_bool()) {
                qty_patch.insert("auto_contrast".to_string(), serde_json::json!(v));
            }
            if let Some(v) = viz_hint.get("field_component").and_then(|v| v.as_str()) {
                qty_patch.insert("field_component".to_string(), serde_json::json!(v));
            }
            if !qty_patch.is_empty() {
                state_patch["quantity"] = serde_json::Value::Object(qty_patch);
            }
        }

        // clip patch
        {
            let clip_enabled = viz_hint.get("clip_enabled").and_then(|v| v.as_bool());
            let clip_axis = viz_hint.get("clip_axis").and_then(|v| v.as_str());
            let clip_position = viz_hint.get("clip_position").and_then(|v| v.as_f64());
            if clip_enabled.is_some() || clip_axis.is_some() || clip_position.is_some() {
                let mut clip = serde_json::Map::new();
                if let Some(v) = clip_enabled {
                    clip.insert("enabled".to_string(), serde_json::json!(v));
                }
                if let Some(v) = clip_axis {
                    clip.insert("axis".to_string(), serde_json::json!(v));
                }
                if let Some(v) = clip_position {
                    clip.insert("position_percent".to_string(), serde_json::json!(v));
                }
                state_patch["clip"] = serde_json::Value::Object(clip);
            }
        }

        // vector_style patch
        {
            let mut vs = serde_json::Map::new();
            if let Some(v) = viz_hint.get("vector_length_scale").and_then(|v| v.as_f64()) {
                vs.insert("length_scale".to_string(), serde_json::json!(v));
            }
            if let Some(v) = viz_hint.get("vector_thickness").and_then(|v| v.as_f64()) {
                vs.insert("thickness".to_string(), serde_json::json!(v));
            }
            if let Some(v) = viz_hint.get("vector_alpha").and_then(|v| v.as_f64()) {
                vs.insert("alpha".to_string(), serde_json::json!(v));
            }
            if let Some(v) = viz_hint.get("vector_color_mode").and_then(|v| v.as_str()) {
                vs.insert("color_mode".to_string(), serde_json::json!(v));
            }
            if !vs.is_empty() {
                state_patch["vector_style"] = serde_json::Value::Object(vs);
            }
        }

        // layers patch (from global render_mode and vector_density)
        {
            let mut layers = serde_json::Map::new();
            if let Some(rm) = viz_hint.get("render_mode").and_then(|v| v.as_str()) {
                let (surf, wire, pts) = match rm {
                    "surface" => (true, false, false),
                    "wireframe" => (false, true, false),
                    "surface+edges" => (true, true, false),
                    "points" => (false, false, true),
                    _ => (true, false, false),
                };
                layers.insert(
                    "surface".to_string(),
                    serde_json::json!({ "visible": surf }),
                );
                layers.insert(
                    "wireframe".to_string(),
                    serde_json::json!({ "visible": wire }),
                );
                layers.insert("points".to_string(), serde_json::json!({ "visible": pts }));
            }
            if let Some(density) = viz_hint.get("vector_density").and_then(|v| v.as_u64()) {
                layers.insert(
                    "vectors".to_string(),
                    serde_json::json!({ "density": density }),
                );
            }
            if !layers.is_empty() {
                state_patch["layers"] = serde_json::Value::Object(layers);
            }
        }

        let has_patch = state_patch
            .as_object()
            .map(|o| !o.is_empty())
            .unwrap_or(false);
        if !args.headless && has_patch {
            if let Err(e) = sync_initial_visualization_state(state_patch) {
                eprintln!(
                    "[fullmag-host] failed to apply initial visualization state: {}",
                    e
                );
            }
        }
    }
    if !initial_display_hint_applied {
        if let Some(every_n) = preview_every_n_override {
            display_selection_handle.set_quantity_hint("m", Some(every_n));
        }
    }

    // The attached scratch runtime may use `wait_for_solve` to consume the
    // initial remesh/solve command before the general interactive host is
    // constructed. Materialization is complete at this point, so command
    // polling is safe to enable and no command can be lost during startup.
    display_selection_handle.enable_command_polling();

    // ── wait_for_solve gate ──────────────────────────────────────────────
    let wait_for_solve_requested = attached_wait_for_solve_enabled()
        || stages
            .first()
            .map(|stage| {
                stage
                    .ir
                    .problem_meta
                    .runtime_metadata
                    .get("wait_for_solve")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(false)
            })
            .unwrap_or(false);
    let _is_fem_backend = matches!(&initial_execution_plan.backend_plan, BackendPlanIR::Fem(_));
    let wait_for_solve_supported = wait_for_solve_supported(&initial_execution_plan.backend_plan);
    if let Some(command_id) = grid_refresh_command_id.as_deref() {
        anyhow::ensure!(
            !command_id.is_empty()
                && wait_for_solve_should_block(wait_for_solve_requested, wait_for_solve_supported, args.headless)
                && matches!(&initial_execution_plan.backend_plan, BackendPlanIR::Fdm(_) | BackendPlanIR::FdmMultilayer(_)),
            "grid-only attached runtime requires an interactive FDM wait-for-solve command pin"
        );
    }

    if wait_for_solve_should_block(
        wait_for_solve_requested,
        wait_for_solve_supported,
        args.headless,
    ) {
        let wait_message = wait_for_solve_prompt(&initial_execution_plan.backend_plan);
        eprintln!("[fullmag] {}", wait_message.to_lowercase());
        live_workspace.push_log("system", wait_message);
        crate::script_launch::note_stage(crate::script_launch::Stage::WaitingForSolve);
        // Switch to slow publish mode — solver loop will produce its own cadenced updates.
        live_workspace.set_publish_fast_mode(false);
        live_workspace.update(|state| {
            state.session.status = "waiting_for_compute".to_string();
            state.run.status = "waiting_for_compute".to_string();
            set_live_state_status(&mut state.live_state, "waiting_for_compute", Some(false));
            state.mesh_workspace = current_mesh_workspace(
                &stages[0].ir,
                &initial_execution_plan,
                "waiting_for_compute",
                current_mesh_quality.as_ref(),
                &current_mesh_history,
            );
        });

        // ── Auto-coarsen: if mesh exceeds the interactive RAM budget, remesh with larger hmax ──
        if let BackendPlanIR::Fem(fem_plan) = &initial_execution_plan.backend_plan {
            let node_count = fem_plan.mesh.nodes.len();
            let available_ram = available_system_ram_bytes();
            let ram_budget = interactive_dense_ram_budget_bytes(available_ram);
            let dense_ram_estimate = fem_interactive_dense_ram_estimate(fem_plan);
            let ram_msg = if let Some(required_ram) = dense_ram_estimate {
                format!(
                    "Mesh: {} nodes · Est. dense FEM RAM: {:.1} GB / {:.1} GB available",
                    node_count,
                    required_ram as f64 / 1e9,
                    available_ram as f64 / 1e9
                )
            } else {
                let demag_label = fem_plan
                    .demag_realization
                    .map(|realization| realization.provenance_name())
                    .unwrap_or("demag_disabled_or_unspecified");
                format!(
                    "Mesh: {} nodes · dense FEM auto-coarsen not applicable ({}) · {:.1} GB available",
                    node_count,
                    demag_label,
                    available_ram as f64 / 1e9
                )
            };
            live_workspace.push_log("info", &ram_msg);
            eprintln!("[fullmag] {}", ram_msg);
            if let Some(required_ram) = dense_ram_estimate {
                log_fem_gpu_memory_preflight(
                    &live_workspace,
                    &stages[0].ir,
                    &initial_runtime,
                    required_ram,
                );
            }

            if let Some(required_ram) =
                dense_ram_estimate.filter(|required_ram| *required_ram > ram_budget)
            {
                eprintln!(
                    "[fullmag] mesh too large for interactive dense FEM budget ({} nodes, {:.1} GB required, {:.1} GB budget, {:.1} GB available)",
                    node_count,
                    required_ram as f64 / 1e9,
                    ram_budget as f64 / 1e9,
                    available_ram as f64 / 1e9
                );
                live_workspace.push_log(
                    "warn",
                    format!(
                        "⛔ Mesh ({} nodes) requires {:.1} GB dense RAM, above the interactive target {:.1} GB — auto-optimizing",
                        node_count,
                        required_ram as f64 / 1e9,
                        ram_budget as f64 / 1e9
                    ),
                );

                let geometry_entry = stages[0].ir.geometry.entries.first().cloned();
                let fe_order = fem_plan.fe_order;
                let mut current_hmax = fem_plan.hmax;
                let shared_domain_remesh = matches!(
                    fem_plan.domain_mesh_mode,
                    fullmag_ir::FemDomainMeshModeIR::SharedDomainMeshWithAir
                );

                if let Some(geom) = geometry_entry {
                    for attempt in 1..=5 {
                        current_hmax *= 1.5;
                        eprintln!(
                            "[fullmag] auto-coarsen attempt {}/5 — trying hmax={:.2e}",
                            attempt, current_hmax
                        );
                        live_workspace.push_log(
                            "info",
                            format!(
                                "Auto-coarsen attempt {}/5 — hmax = {:.2e} m",
                                attempt, current_hmax
                            ),
                        );

                        let remesh_attempt = if shared_domain_remesh {
                            let declared_universe = fem_declared_universe(&stages[0].ir)
                                .ok_or_else(|| {
                                    anyhow!(
                                        "shared-domain auto-coarsen requires a declared universe in domain_frame or study_universe metadata"
                                    )
                                })?;
                            let declared_universe_value =
                                serde_json::to_value(&declared_universe).context(
                                    "failed to serialize declared universe for shared-domain auto-coarsen",
                                )?;
                            let object_region_mesh_specs =
                                shared_domain_object_region_mesh_specs(&stages[0].ir)?;
                            let (body_material_fields, geometry_object_ids) =
                                shared_domain_body_material_payload(&stages[0].ir)?;
                            invoke_shared_domain_remesh_full(
                                &stages[0].ir.geometry.entries,
                                &object_region_mesh_specs,
                                &declared_universe_value,
                                &body_material_fields,
                                &geometry_object_ids,
                                current_hmax,
                                fe_order,
                                &serde_json::json!({"compute_quality": true}),
                                None,
                            )
                        } else {
                            invoke_remesh_full(
                                &geom,
                                current_hmax,
                                fe_order,
                                &serde_json::json!({"compute_quality": true}),
                                None,
                            )
                        };

                        match remesh_attempt {
                            Ok(remesh_result) => {
                                let new_mesh = remesh_result.clone().into_mesh_ir();
                                if let Some(previous_mesh) = stages[0]
                                    .ir
                                    .geometry_assets
                                    .as_ref()
                                    .and_then(|assets| assets.fem_domain_mesh_asset.as_ref())
                                    .and_then(|asset| asset.mesh.as_ref())
                                {
                                    validate_periodic_remesh_candidate(previous_mesh, &new_mesh)?;
                                }
                                let new_nodes = new_mesh.nodes.len();
                                let new_ram = estimate_fem_dense_ram(new_nodes);
                                eprintln!(
                                    "[fullmag] auto-coarsen: {} nodes, {:.1} GB required",
                                    new_nodes,
                                    new_ram as f64 / 1e9
                                );

                                let (remeshed_mesh_asset, remeshed_magnetization, remeshed_plan) = {
                                    let mut remeshed_problem = stages[0].ir.clone();
                                    apply_current_fem_overrides(
                                        &mut remeshed_problem,
                                        Some(&new_mesh),
                                        Some(current_hmax),
                                        current_adaptive_runtime_state.as_ref(),
                                    );
                                    if shared_domain_remesh {
                                        let region_markers =
                                            if remesh_result.region_markers.is_empty() {
                                                default_domain_region_markers(
                                                    &remeshed_problem.geometry.entries,
                                                )
                                            } else {
                                                remesh_result.region_markers.clone()
                                            };
                                        remeshed_problem
                                            .geometry_assets
                                            .as_mut()
                                            .and_then(|assets| {
                                                assets.fem_domain_mesh_asset.as_mut()
                                            })
                                            .ok_or_else(|| {
                                                anyhow!(
                                                    "shared-domain auto-coarsen produced no attached fem_domain_mesh_asset"
                                                )
                                            })?
                                            .region_markers = region_markers;
                                        let object_region_markers =
                                            resolved_shared_domain_object_region_markers(
                                                &remeshed_problem,
                                                &remesh_result.object_region_markers,
                                            )?;
                                        let domain_asset = remeshed_problem
                                            .geometry_assets
                                            .as_mut()
                                            .and_then(|assets| {
                                                assets.fem_domain_mesh_asset.as_mut()
                                            })
                                            .ok_or_else(|| {
                                                anyhow!(
                                                    "shared-domain auto-coarsen produced no attached fem_domain_mesh_asset"
                                                )
                                            })?;
                                        domain_asset.object_region_markers = object_region_markers;
                                    }
                                    let remeshed_plan = fullmag_plan::plan(&remeshed_problem)
                                        .map_err(|error| anyhow!(error.to_string()))?;
                                    let mesh_asset = fullmag_runner::StageFemMeshAsset::build_from_backend_plan(
                                        &remeshed_plan.backend_plan,
                                    )
                                    .ok_or_else(|| anyhow!("auto-coarsen updated backend plan did not produce a FEM mesh asset"))?;
                                    let magnetization = current_stage_magnetization_vectors(
                                        None,
                                        &remeshed_plan.backend_plan,
                                    );
                                    if mesh_asset.payload.nodes.len() != magnetization.len() {
                                        bail!(
                                            "auto-coarsen FEM mesh has {} nodes but initial magnetization has {} vectors",
                                            mesh_asset.payload.nodes.len(),
                                            magnetization.len()
                                        );
                                    }
                                    (mesh_asset, magnetization, remeshed_plan)
                                };
                                let prepared_remesh = prepare_remesh_stage_transaction(
                                    &stages,
                                    &stage_execution_plans,
                                    None,
                                    &new_mesh,
                                    current_hmax,
                                    shared_domain_remesh,
                                    &remesh_result.region_markers,
                                    &remesh_result.object_region_markers,
                                    current_adaptive_runtime_state.as_ref(),
                                    Some(remeshed_plan.clone()),
                                    None,
                                )?;

                                if new_ram <= ram_budget {
                                    let live_mesh_payload = remeshed_mesh_asset.payload.clone();
                                    initial_fem_mesh_asset = Some(remeshed_mesh_asset);
                                    current_mesh_quality = remesh_result.quality.clone();
                                    current_fem_mesh_override = Some(new_mesh.clone());
                                    current_fem_hmax_override = Some(current_hmax);
                                    stages = prepared_remesh.stages;
                                    stage_execution_plans = prepared_remesh.stage_execution_plans;
                                    current_mesh_history.push(serde_json::json!({
                                        "mesh_name": new_mesh.mesh_name,
                                        "generation_mode": remesh_result.generation_mode,
                                        "node_count": new_nodes,
                                        "element_count": new_mesh.cell_count(),
                                        "boundary_face_count": new_mesh.facet_count(),
                                        "kind": "auto_coarsen",
                                        "mesh_target": "study_domain",
                                        "mesh_reason": "auto_coarsen",
                                        "mesh_provenance": remesh_result.mesh_provenance.clone(),
                                        "quality_data_artifact": remesh_result.quality_data_artifact.clone(),
                                    }));
                                    live_workspace.update(|state| {
                                        state.live_state.latest_step.fem_mesh_generation_id =
                                            live_mesh_payload.generation_id.clone();
                                        state.fem_mesh = Some(live_mesh_payload);
                                        state.live_state.latest_step.magnetization =
                                            Some(flatten_magnetization(&remeshed_magnetization));
                                        state.mesh_workspace = Some(current_fem_mesh_workspace(
                                            &stages[0].ir,
                                            &new_mesh,
                                            if shared_domain_remesh {
                                                None
                                            } else {
                                                fem_plan.mesh_source.as_deref()
                                            },
                                            fe_order,
                                            current_hmax,
                                            "waiting_for_compute",
                                            stages[0]
                                                .ir
                                                .problem_meta
                                                .runtime_metadata
                                                .get("adaptive_mesh"),
                                            current_adaptive_runtime_state.as_ref(),
                                            current_mesh_quality.as_ref(),
                                            remesh_result.quality_data_artifact.as_ref(),
                                            None,
                                            &current_mesh_history,
                                        ));
                                        clear_cached_preview_fields(state);
                                    });
                                    live_workspace.push_log(
                                        "success",
                                        format!(
                                            "✅ Auto-coarsen complete — {} nodes ({:.1} GB), hmax = {:.2e} m",
                                            new_nodes,
                                            new_ram as f64 / 1e9,
                                            current_hmax
                                        ),
                                    );
                                    eprintln!(
                                        "[fullmag] auto-coarsen: mesh fits in RAM ({} nodes)",
                                        new_nodes
                                    );
                                    break;
                                }
                                live_workspace.push_log(
                                    "info",
                                    format!(
                                        "Still too large ({} nodes, {:.1} GB) — trying larger hmax",
                                        new_nodes,
                                        new_ram as f64 / 1e9
                                    ),
                                );
                            }
                            Err(e) => {
                                eprintln!("[fullmag] auto-coarsen remesh failed: {}", e);
                                live_workspace.push_log(
                                    "error",
                                    format!("Auto-coarsen remesh failed: {}", e),
                                );
                                break;
                            }
                        }
                    }
                }
            }
        }

        loop {
            if display_selection_handle.grid_refresh_command_refused() {
                bail!("grid-only control receiver refused an unpinned command");
            }
            if display_selection_handle.owner_session_lost() {
                live_workspace.push_log(
                    "warning",
                    "Attached runtime owner session was replaced — stopping before compute",
                );
                return Ok(());
            }
            let Some(cmd) =
                display_selection_handle.wait_next_command_coalesced(Duration::from_millis(250))
            else {
                if display_selection_handle.owner_session_lost() {
                    live_workspace.push_log(
                        "warning",
                        "Attached runtime owner session was replaced — stopping before compute",
                    );
                    return Ok(());
                }
                continue;
            };

            match cmd.kind.as_str() {
                "display_sync" => {
                    display_selection_handle.apply_display_sync_command(&cmd);
                    let display_selection = display_selection_handle.display_selection_snapshot();
                    if let Err(error) = refresh_problem_preview_state(
                        &stages[0].ir,
                        continuation_magnetization.as_deref(),
                        &display_selection,
                        &live_workspace,
                        ProblemPreviewRefreshMode::PreviewOnly,
                    ) {
                        live_workspace.push_log(
                            "warn",
                            format!("Preview refresh after selection change failed: {}", error),
                        );
                    }
                    continue;
                }
                "load_state" => {
                    let Some(state_path) = cmd.state_path.as_deref() else {
                        live_workspace
                            .push_command_log(&cmd.command_id, "error", "Failed to load workspace state: missing state_path");
                        continue;
                    };
                    match read_magnetization_state(
                        Path::new(state_path),
                        cmd.state_format.as_deref(),
                        cmd.state_dataset.as_deref(),
                        cmd.state_sample_index,
                    )
                    .and_then(|loaded_state| {
                        validate_imported_magnetization(&stages[0].ir, &loaded_state.values)?;
                        Ok(loaded_state)
                    }) {
                        Ok(loaded_state) => {
                            replace_continuation_after_synthetic_stage(
                                &mut continuation_magnetization,
                                &mut continuation_source,
                                &mut continuation_fem_mesh_payload,
                                &mut continuation_completion,
                                &mut continuation_stage_source,
                                &mut continuation_accepted_fields,
                                &mut continuation_certified_fields,
                                &mut continuation_relax_handoff,
                                loaded_state.values.clone(),
                                false,
                            );
                            live_workspace.update(|state| {
                                state.live_state.updated_at_unix_ms =
                                    unix_time_millis().unwrap_or(0);
                                state.live_state.latest_step.magnetization =
                                    Some(flatten_magnetization(&loaded_state.values));
                                clear_cached_preview_fields(state);
                            });
                            let display_selection =
                                display_selection_handle.display_selection_snapshot();
                            if let Err(error) = refresh_problem_preview_state(
                                &stages[0].ir,
                                continuation_magnetization.as_deref(),
                                &display_selection,
                                &live_workspace,
                                if supports_dynamic_live_preview(
                                    &stage_execution_plans[0].backend_plan,
                                ) {
                                    ProblemPreviewRefreshMode::MaterializeFields
                                } else {
                                    ProblemPreviewRefreshMode::PreviewOnly
                                },
                            ) {
                                live_workspace.push_log(
                                    "warn",
                                    format!("Loaded state preview refresh failed: {}", error),
                                );
                            }
                            live_workspace.push_command_log(
                                &cmd.command_id,
                                "success",
                                format!(
                                    "Loaded workspace state from {} ({} vectors)",
                                    state_path, loaded_state.vector_count
                                ),
                            );
                        }
                        Err(error) => {
                            live_workspace.push_command_log(
                                &cmd.command_id,
                                "error",
                                format!("Failed to load workspace state: {}", error),
                            );
                        }
                    }
                    continue;
                }
                _ => {}
            }

            match classify_wait_for_solve_command(cmd.kind.as_str()) {
                WaitForSolveCommandAction::RefreshFields => {
                    eprintln!("[fullmag] compute_fields requested — refreshing field snapshots");
                    live_workspace.push_log(
                        "system",
                        "Compute fields requested — evaluating current magnetization",
                    );
                    let display_selection = display_selection_handle.display_selection_snapshot();
                    let live_magnetization = live_workspace.latest_magnetization_vectors();
                    let compute_magnetization = live_magnetization
                        .as_deref()
                        .or(continuation_magnetization.as_deref());
                    match refresh_problem_preview_state(
                        &stages[0].ir,
                        compute_magnetization,
                        &display_selection,
                        &live_workspace,
                        ProblemPreviewRefreshMode::MaterializeFields,
                    ) {
                        Ok(()) => live_workspace.push_command_log(
                            &cmd.command_id,
                            "success",
                            "Field snapshots computed for the current magnetization",
                        ),
                        Err(error) => live_workspace
                            .push_command_log(&cmd.command_id, "error", format!("Compute fields failed: {}", error)),
                    }
                    continue;
                }
                WaitForSolveCommandAction::RefreshEnergies => {
                    eprintln!("[fullmag] compute_energies requested — evaluating current energies");
                    live_workspace.push_log(
                        "system",
                        "Compute energies requested — evaluating current magnetization",
                    );
                    let live_magnetization = live_workspace.latest_magnetization_vectors();
                    let compute_magnetization = live_magnetization
                        .as_deref()
                        .or(continuation_magnetization.as_deref());
                    match refresh_problem_energy_state(
                        &stages[0].ir,
                        compute_magnetization,
                        &live_workspace,
                    ) {
                        Ok(()) => live_workspace
                            .push_command_log(&cmd.command_id, "success", "Energies computed for the current magnetization"),
                        Err(error) => live_workspace
                            .push_command_log(&cmd.command_id, "error", format!("Compute energies failed: {}", error)),
                    }
                    continue;
                }
                WaitForSolveCommandAction::ConfigureProfiler => {
                    apply_solver_profile_command(&live_workspace, &cmd);
                    continue;
                }
                WaitForSolveCommandAction::StartSolver => {
                    anyhow::ensure!(grid_refresh_command_id.is_none(), "grid-only runtime cannot execute a solver command");
                    if matches!(cmd.kind.as_str(), "relax" | "run" | "solve") {
                        let frozen_binding_summary = cmd
                            .frozen_spins_runtime_plan_binding
                            .as_ref()
                            .map(|binding| {
                                format!(
                                    "revision {} with {} selection definition(s) and {} constraint(s)",
                                    binding.source_scene_revision,
                                    binding.selection_definitions.len(),
                                    binding.magnetization_constraints.len()
                                )
                            })
                            .unwrap_or_else(|| "missing".to_string());
                        let (command_base_ir, bound_frozen_spins_scene_revision) =
                            match problem_with_frozen_spins_runtime_plan_binding(
                                &stages[0].ir,
                                &cmd,
                                frozen_spins_applied_scene_revision,
                            ) {
                                Ok(Some((candidate, source_scene_revision))) => {
                                    (candidate, Some(source_scene_revision))
                                }
                                Ok(None) => (stages[0].ir.clone(), None),
                                Err(error) => {
                                    let message = format!(
                                        "wait_for_solve Frozen Spins runtime-plan binding rejected for command {}: {}",
                                        cmd.command_id, error
                                    );
                                    live_workspace.push_log("error", message.clone());
                                    eprintln!("[fullmag] {message}");
                                    continue;
                                }
                            };
                        let Some(mut command_stage) = (match crate::step_utils::build_initial_interactive_command_stage(
                            &stages[0],
                            &command_base_ir,
                            &cmd,
                        ) {
                            Ok(Some(stage)) => Some(stage),
                            Ok(None) => {
                                let message = format!(
                                        "wait_for_solve command '{}' did not produce an executable stage",
                                        cmd.kind
                                    );
                                live_workspace.push_log("error", message.clone());
                                eprintln!("[fullmag] {message}");
                                None
                            }
                            Err(error) => {
                                let message = format!(
                                    "wait_for_solve command '{}' rejected: {}",
                                    cmd.kind, error
                                );
                                live_workspace.push_log("error", message.clone());
                                eprintln!("[fullmag] {message}");
                                None
                            }
                        }) else {
                            continue;
                        };
                        apply_current_fem_overrides(
                            &mut command_stage.ir,
                            current_fem_mesh_override.as_ref(),
                            current_fem_hmax_override,
                            current_adaptive_runtime_state.as_ref(),
                        );
                        attach_region_realization_revisions(
                            &mut command_stage.ir,
                            cmd.precondition.as_ref(),
                        );
                        if let Err(error) = validate_ir(&command_stage.ir) {
                            let message = format!(
                                "wait_for_solve command '{}' rejected by validation: {}",
                                cmd.kind, error
                            );
                            live_workspace.push_log("error", message.clone());
                            eprintln!("[fullmag] {message}");
                            continue;
                        }
                        let command_plan = match fullmag_plan::plan(&command_stage.ir) {
                            Ok(plan) => plan,
                            Err(error) => {
                                let message = format!(
                                    "wait_for_solve command '{}' could not be planned: {}",
                                    cmd.kind, error
                                );
                                live_workspace.push_log("error", message.clone());
                                eprintln!("[fullmag] {message}");
                                continue;
                            }
                        };
                        let planned_frozen_spins_summary =
                            match fullmag_runner::frozen_spins_runtime_status_for_backend_plan(
                                &command_plan.backend_plan,
                            ) {
                                Ok(Some(status)) => format!(
                                    "certificate with {} frozen and {} free site(s)",
                                    status.frozen_site_count, status.free_site_count
                                ),
                                Ok(None) => "no certificate".to_string(),
                                Err(error) => format!("invalid certificate: {error}"),
                            };
                        if cmd.kind == "solve" {
                            command_stage.entrypoint_kind = stages[0].entrypoint_kind.clone();
                            command_stage.ir.problem_meta.entrypoint_kind =
                                stages[0].ir.problem_meta.entrypoint_kind.clone();
                            command_stage.incoming_transition =
                                stages[0].incoming_transition.clone();
                        }
                        stages[0] = command_stage;
                        stage_execution_plans[0] = command_plan.clone();
                        initial_execution_plan = command_plan;
                        current_plan_summary = stages[0]
                            .ir
                            .plan_for(args.backend.map(BackendTarget::from))
                            .map_err(join_errors)?;
                        if stages.len() == 1 {
                            interactive_template_ir = stages[0].ir.clone();
                        }
                        if let Some(source_scene_revision) = bound_frozen_spins_scene_revision {
                            frozen_spins_applied_scene_revision = Some(source_scene_revision);
                            live_workspace.push_log(
                                "system",
                                format!(
                                    "Applied Frozen Spins scene revision {source_scene_revision} at the initial runtime-plan boundary for command {}",
                                    cmd.command_id
                                ),
                            );
                        }
                        live_workspace.push_log(
                            "info",
                            format!(
                                "Applied solver command payload overrides for {}; Frozen Spins binding: {}; planned status: {}",
                                cmd.kind,
                                frozen_binding_summary,
                                planned_frozen_spins_summary
                            ),
                        );
                    }
                    eprintln!("[fullmag] compute requested — starting solver");
                    // The attached scratch runtime admits the command here, while the
                    // canonical SceneDocument stage remains the source of solver defaults.
                    // UI edits must be committed to the scene before issuing relax/run;
                    // explicit command payload overrides were materialized and replanned above.
                    start_solver_command_id = Some(cmd.command_id.clone());
                    live_workspace.push_log("system", "Compute requested — starting solver");
                    live_workspace.update(|state| {
                        state.session.status = "running".to_string();
                        state.run.status = "running".to_string();
                        set_live_state_status(&mut state.live_state, "running", Some(false));
                        clear_cached_preview_fields(state);
                    });
                    break;
                }
                WaitForSolveCommandAction::Remesh => {
                    if let Some(expected_id) = grid_refresh_command_id.as_deref() {
                        anyhow::ensure!(
                            cmd.kind == "fdm_grid_refresh" && cmd.command_id == expected_id,
                            "grid-only runtime received a different command"
                        );
                    }
                    let remesh_summary = execute_manual_interactive_remesh(
                        &cmd,
                        &mut stages,
                        &mut stage_execution_plans,
                        "waiting_for_compute",
                        &live_workspace,
                        &mut current_mesh_quality,
                        &mut current_mesh_history,
                        &mut current_fem_mesh_override,
                        &mut current_fem_hmax_override,
                        &current_adaptive_runtime_state,
                        &mut continuation_magnetization,
                        &mut continuation_source,
                        &mut continuation_completion,
                        None,
                        args.backend.map(BackendTarget::from),
                    );
                    let remesh_succeeded = remesh_summary.is_some();
                    if let Some(summary) = remesh_summary {
                        current_plan_summary = summary;
                        continuation_relax_handoff = None;
                        // The remesh invalidates all cached equilibrium field evidence.
                        continuation_fem_mesh_payload = None;
                        continuation_completion = None;
                        continuation_stage_source = None;
                        continuation_accepted_fields = None;
                        continuation_certified_fields = None;
                    }
                    if grid_refresh_command_id.is_some() {
                        let payload = live_workspace.grid_refresh_snapshot()?;
                        let publisher_scope = crate::control_room::live_publisher_scope::LivePublisherScope::new(&session_id);
                        anyhow::ensure!(publisher_scope.is_bound()?, "grid refresh requires its attached publisher scope");
                        sync_current_live_snapshot(&session_id, &payload, &publisher_scope)?;
                        storage_lease.finish(remesh_succeeded)?;
                        return Ok(());
                    }
                }
                WaitForSolveCommandAction::Stop => {
                    eprintln!("[fullmag] aborted by user during wait_for_solve");
                    crate::script_launch::mark_failure(crate::script_launch::ExitKind::Stopped);
                    live_workspace.push_log("system", "Aborted by user");
                    live_workspace.update(|state| {
                        state.session.status = "stopped".to_string();
                        state.run.status = "stopped".to_string();
                        set_live_state_status(&mut state.live_state, "stopped", Some(true));
                    });
                    return Ok(());
                }
                WaitForSolveCommandAction::Ignore => {
                    eprintln!(
                        "[fullmag] ignoring command '{}' during wait_for_solve",
                        cmd.kind
                    );
                }
            }
        }
    } else if wait_for_solve_requested && args.headless {
        eprintln!("[fullmag] wait_for_solve ignored in headless mode - proceeding immediately");
        live_workspace.push_log(
            "warn",
            "wait_for_solve is interactive-only and was ignored in headless mode - proceeding immediately",
        );
    } else if wait_for_solve_requested && !wait_for_solve_supported {
        eprintln!("[fullmag] wait_for_solve ignored — only supported for FDM/FEM solve backends");
        live_workspace.push_log(
            "warn",
            "wait_for_solve is only supported for FDM/FEM solve backends — proceeding immediately",
        );
    }

    crate::script_launch::note_stage(crate::script_launch::Stage::Running);
    for (stage_index, (mut stage, materialized_execution_plan)) in stages
        .into_iter()
        .zip(stage_execution_plans.into_iter())
        .enumerate()
    {
        if stage.entrypoint_kind == "flat_workspace" {
            live_workspace.push_log(
                "system",
                "Workspace-only script loaded — awaiting control-room command".to_string(),
            );
            continue;
        }
        let materialized_stage_ir = stage.ir.clone();
        let synthetic_action = stage.action.clone();
        let stage_start_time_s = time_offset;
        if synthetic_action.is_none() {
            stage.ir.problem_meta.runtime_metadata.insert(
                "stage_start_time_s".to_string(),
                serde_json::json!(stage_start_time_s),
            );
        }
        if let Some(ResolvedScriptStageAction::AddSolvedAntennaDrive { drive_id, .. }) = synthetic_action.as_ref() {
            activated_solved_drive_ids.insert(drive_id.clone());
        }
        stage.ir.solved_antenna_drives.retain(|drive| {
            !scheduled_solved_drives.iter().any(|(_, id)| id == &drive.id)
                || activated_solved_drive_ids.contains(&drive.id)
        });
        let active_projection_ids = stage.ir.solved_antenna_drives.iter()
            .map(|drive| drive.projection_ref.as_str())
            .collect::<std::collections::BTreeSet<_>>();
        stage.ir.antenna_target_projections.retain(|projection| {
            !scheduled_solved_drives.iter().any(|(id, _)| id == &projection.id)
                || active_projection_ids.contains(projection.id.as_str())
        });
        match synthetic_action.as_ref() {
            Some(ResolvedScriptStageAction::AntennaSourceSpectrum { request_id }) => {
                stage.ir.antenna_spectrum_requests.retain(|request| request.id == *request_id);
            }
            _ => {
                stage.ir.antenna_spectrum_requests.retain(|request| {
                    !scheduled_spectrum_request_ids.contains(&request.id)
                });
            }
        }
        if synthetic_action.is_none() {
            resolve_active_antenna_stage_outputs(&mut stage.ir, &published_antenna_outputs)?;
        }
        if synthetic_action.is_none()
            || matches!(synthetic_action.as_ref(), Some(ResolvedScriptStageAction::AntennaSourceSpectrum { .. }))
        {
            resolve_antenna_spectrum_stage_outputs(&mut stage.ir, &published_antenna_outputs)?;
        }
        apply_current_fem_overrides(
            &mut stage.ir,
            current_fem_mesh_override.as_ref(),
            current_fem_hmax_override,
            current_adaptive_runtime_state.as_ref(),
        );
        if synthetic_action.is_none() {
            if let Some(previous_final_magnetization) = continuation_magnetization.as_deref() {
                ensure_frequency_response_relaxed_continuation_is_qualified(
                    &stage,
                    continuation_completion.as_ref(),
                )?;
                // Check for cross-backend FEM→FDM transfer.
                if let Some(source) = continuation_source.as_ref() {
                    match resample_continuation_if_cross_backend(
                        previous_final_magnetization,
                        source,
                        &stage.ir,
                    ) {
                        Ok(Some(transfer)) => {
                            eprintln!(
                                "[fullmag] {} state transfer: {}/{} {} interpolated, {} fallback/outside",
                                transfer.label,
                                transfer.n_located,
                                transfer.n_total,
                                transfer.unit_label,
                                transfer.n_outside
                            );
                            if let Some(workspace) = Some(&live_workspace) {
                                workspace.push_log(
                                    "info",
                                    format!(
                                        "State transfer ({}): {}/{} {} interpolated from FEM mesh",
                                        transfer.label,
                                        transfer.n_located,
                                        transfer.n_total,
                                        transfer.unit_label
                                    ),
                                );
                            }
                            apply_continuation_initial_state(&mut stage.ir, &transfer.values)?;
                            trace_continuation_state("after-cross-backend-apply", &transfer.values);
                        }
                        Ok(None) => {
                            // Same-backend continuation — use values directly.
                            apply_continuation_initial_state(
                                &mut stage.ir,
                                previous_final_magnetization,
                            )?;
                            trace_continuation_state(
                                "after-same-backend-apply",
                                previous_final_magnetization,
                            );
                        }
                        Err(e) => {
                            eprintln!("[fullmag] magnetization state transfer failed: {}", e);
                            bail!("magnetization state transfer failed: {}", e);
                        }
                    }
                } else {
                    apply_continuation_initial_state(&mut stage.ir, previous_final_magnetization)?;
                    trace_continuation_state(
                        "after-untyped-backend-apply",
                        previous_final_magnetization,
                    );
                }
            }
        }
        let stage_plan_reusable = stage.ir == materialized_stage_ir;
        if !stage_plan_reusable {
            validate_ir(&stage.ir)?;
            current_plan_summary = stage
                .ir
                .plan_for(args.backend.map(BackendTarget::from))
                .map_err(join_errors)?;
        }
        let mut execution_plan = if stage_plan_reusable {
            materialized_execution_plan
        } else if matches!(stage.action.as_ref(), Some(ResolvedScriptStageAction::AntennaExternalLeadInspection { .. } | ResolvedScriptStageAction::AntennaClosedLoopInspection { .. })) {
            plan_materialized_stage_snapshot(&stage)?
        } else {
            fullmag_plan::plan(&stage.ir).map_err(|error| anyhow!(error.to_string()))?
        };
        if let BackendPlanIR::FemEigen(fem) = &execution_plan.backend_plan {
            trace_continuation_state("materialized-eigen-plan", &fem.equilibrium_magnetization);
        }
        let relax_handoff = accepted_relax_handoff_for_eigen_stage(
            &execution_plan.backend_plan,
            continuation_magnetization.as_deref(),
            continuation_relax_handoff.as_ref(),
        )?;
        if synthetic_action.is_none() {
            attach_solved_antenna_drive_bases(&stage.ir, &mut execution_plan, &artifact_dir)?;
        }
        let stage_time_frame = if synthetic_action.is_some() {
            fullmag_runner::StageStepTimeFrame::StageLocal
        } else {
            fullmag_runner::stage_step_time_frame(&stage.ir, &execution_plan)
                .map_err(|error| anyhow!(error.message))?
        };
        let runner_time_offset = match stage_time_frame {
            fullmag_runner::StageStepTimeFrame::StageLocal => time_offset,
            fullmag_runner::StageStepTimeFrame::Absolute => 0.0,
        };
        if !antenna_external_lead_inspection::is_carrier(&execution_plan) {
            emit_initial_state_warnings(Some(&live_workspace), &stage.ir, &execution_plan)?;
        }
        let use_live_callback = matches!(
            &execution_plan.backend_plan,
            BackendPlanIR::Fdm(_)
                | BackendPlanIR::FdmMultilayer(_)
                | BackendPlanIR::Fem(_)
                | BackendPlanIR::FemEigen(_)
                | BackendPlanIR::FemFrequencyResponse(_)
        );
        let is_final_stage = stage_index + 1 == stage_count;
        let is_session_final_stage = is_final_stage && !interactive_requested;
        let current_stage_id = format!("stage-{stage_index:03}");
        // The native runner receives the stage ProblemIR, while the session
        // run identity lives in orchestration.  Carry both identities through
        // runtime metadata so the artifact writer can publish producer
        // provenance from the actual run instead of reconstructing it later.
        stage.ir.problem_meta.runtime_metadata.insert(
            "producer_run_id".to_string(),
            serde_json::Value::String(run_id.clone()),
        );
        stage.ir.problem_meta.runtime_metadata.insert(
            "producer_stage_id".to_string(),
            serde_json::Value::String(current_stage_id.clone()),
        );
        stage.ir.problem_meta.runtime_metadata.insert(
            "producer_stage_kind".to_string(),
            serde_json::Value::String(stage.entrypoint_kind.clone()),
        );
        let current_stage_artifact_dir = stage_artifact_dir(
            &workspace_dir,
            &artifact_dir,
            stage_index,
            stage_count,
            &stage.entrypoint_kind,
        );
        fs::create_dir_all(&current_stage_artifact_dir).with_context(|| {
            format!(
                "failed to create stage artifact dir {}",
                current_stage_artifact_dir.display()
            )
        })?;
        if output_paths.is_sibling_zarr_bundle {
            initialize_zarr_group(
                &current_stage_artifact_dir,
                serde_json::json!({
                    "fullmag_role": "stage_artifacts",
                    "stage_index": stage_index,
                    "entrypoint_kind": stage.entrypoint_kind,
                }),
            )?;
            initialize_zarr_group(
                &current_stage_artifact_dir.join("fields"),
                serde_json::json!({"fullmag_role": "sampled_fields"}),
            )?;
        }
        if synthetic_action.is_none() {
            execute_antenna_spectrum_requests(
                &stage.ir,
                &artifact_dir,
                &current_stage_artifact_dir,
                None,
            )?;
        }
        write_sampling_resolution_stage_record(
            &current_stage_artifact_dir,
            stage
                .ir
                .problem_meta
                .runtime_metadata
                .get("sampling_resolution"),
        )?;

        let mut stage_fem_mesh_asset = if stage_index == 0 {
            initial_fem_mesh_asset.take()
        } else {
            fullmag_runner::StageFemMeshAsset::build_from_backend_plan(&execution_plan.backend_plan)
        };
        let stage_initial_update = offset_step_update(
            initial_step_update(
                &execution_plan.backend_plan,
                stage_fem_mesh_asset
                    .as_ref()
                    .map(|asset| asset.identity.generation_id().to_string()),
            ),
            step_offset,
            time_offset,
            false,
        );
        let stage_started_at_unix_ms = unix_time_millis()?;
        live_workspace.push_log(
            "system",
            format!(
                "Executing stage {}/{} ({})",
                stage_index + 1,
                stage_count,
                stage.entrypoint_kind
            ),
        );
        let stage_application_boundary = start_solver_command_id.as_deref().map(|command_id| {
            CommandApplicationBoundary::new(
                &run_id,
                command_id,
                stage_initial_update.stats.step,
                stage_initial_update.stats.time,
            )
        });
        live_workspace.update(|state| {
            let stage_runtime = session_runtime_selection_for_problem(
                &stage.ir,
                Some(&execution_plan),
                field_every_n,
                backend_target_name(stage.ir.backend_policy.requested_backend),
                execution_mode_name(stage.ir.validation_profile.execution_mode),
                execution_precision_name(stage.ir.backend_policy.execution_precision),
            );
            state.session = build_session_manifest(
                &session_id,
                &run_id,
                "running",
                interactive_requested,
                &script_path,
                &stage.ir.problem_meta.name,
                &stage_runtime,
                &artifact_dir,
                started_at_unix_ms,
                started_at_unix_ms,
                plan_summary_json(&current_plan_summary),
            );
            state.metadata = Some(current_live_metadata(&stage.ir, &execution_plan, "running"));
            state.mesh_workspace = current_mesh_workspace(
                &stage.ir,
                &execution_plan,
                "running",
                current_mesh_quality.as_ref(),
                &current_mesh_history,
            );
            state.run = running_run_manifest_from_update(
                &run_id,
                &session_id,
                &artifact_dir,
                &stage_initial_update,
            );
            state.live_state = live_state_manifest_from_update(stage_initial_update.clone());
            let previous_stage_execution = state.stage_execution.clone();
            let mut next_stage_execution = scripted_stage_execution_state(
                stage_count,
                stage_index,
                &stage.entrypoint_kind,
                "running",
                start_solver_command_id.as_deref(),
                Some(stage_started_at_unix_ms),
                None,
                Some(current_stage_artifact_dir.display().to_string()),
                None,
                stage.incoming_transition.as_ref(),
            );
            attach_scripted_stage_solver_steps(
                &mut next_stage_execution,
                stage_index,
                stage_application_boundary.as_ref(),
                None,
            );
            preserve_terminal_stage_history(
                &mut next_stage_execution,
                previous_stage_execution.as_ref(),
            );
            attach_stage_antenna_solve_identity(
                &mut next_stage_execution,
                stage_index,
                stage.action.as_ref(),
            );
            attach_stage_fem_mesh_identity(
                &mut next_stage_execution,
                stage_index,
                stage_fem_mesh_asset.as_ref(),
            );
            state.stage_execution = Some(next_stage_execution);
            clear_cached_preview_fields(state);
            if antenna_external_lead_inspection::is_carrier(&execution_plan) {
                antenna_external_lead_inspection::clear_magnetic_snapshot(state);
            }
        });

        if let Some(action) = synthetic_action {
            let synthetic_interrupt_signal = display_selection_handle.running_interrupt_signal();
            let synthetic_stage_output_dir = if matches!(
                &action, ResolvedScriptStageAction::AntennaExternalLeadInspection { .. }
            ) {
                artifact_dir.join("antenna").join("external_lead_stage_outputs").join(&current_stage_id)
            } else if matches!(&action, ResolvedScriptStageAction::AntennaClosedLoopInspection { .. }) {
                artifact_dir.join("antenna").join("closed_loop_stage_outputs").join(&current_stage_id)
            } else {
                current_stage_artifact_dir.clone()
            };
            let synthetic_artifact_ref =
                synthetic_stage_artifact_ref(&action, &synthetic_stage_output_dir);
            let mut antenna_progress = |
                phase: fullmag_runner::AntennaFieldStageStatus,
                diagnostic: Option<String>,
            | {
                live_workspace.update(|state| {
                    if let Some(execution) = state.stage_execution.as_mut() {
                        update_antenna_live_stage_progress(
                            execution,
                            stage_index,
                            phase,
                            diagnostic,
                            current_unix_millis_u64(),
                        );
                    }
                });
            };
            let synthetic_outcome = match execute_synthetic_stage_with_interrupt(
                &action,
                Some(&stage.ir),
                &artifact_dir,
                &synthetic_stage_output_dir,
                &execution_plan.backend_plan,
                continuation_magnetization.as_deref(),
                Some(synthetic_interrupt_signal.as_ref()),
                Some(&mut antenna_progress),
            ) {
                Ok(outcome) => outcome,
                Err(error) => {
                    let synthetic_cancelled =
                        synthetic_interrupt_requested(Some(synthetic_interrupt_signal.as_ref()));
                    let terminal_status = if synthetic_cancelled {
                        "cancelled"
                    } else {
                        "failed"
                    };
                    let terminal_at_unix_ms = unix_time_millis()?;
                    let mut snapshot = live_workspace.snapshot();
                    let terminal_runtime = session_runtime_selection_for_problem(
                        &stage.ir,
                        Some(&execution_plan),
                        field_every_n,
                        backend_target_name(final_requested_backend),
                        execution_mode_name(final_execution_mode),
                        execution_precision_name(final_precision),
                    );
                    snapshot.session = build_session_manifest(
                        &session_id,
                        &run_id,
                        terminal_status,
                        interactive_requested,
                        &script_path,
                        &final_problem_name,
                        &terminal_runtime,
                        &artifact_dir,
                        started_at_unix_ms,
                        terminal_at_unix_ms,
                        plan_summary_json(&current_plan_summary),
                    );
                    snapshot.metadata =
                        Some(current_live_metadata(
                            &stage.ir,
                            &execution_plan,
                            terminal_status,
                        ));
                    snapshot.mesh_workspace = current_mesh_workspace(
                        &stage.ir,
                        &execution_plan,
                        terminal_status,
                        current_mesh_quality.as_ref(),
                        &current_mesh_history,
                    );
                    snapshot.run = run_manifest_from_steps(
                        &run_id,
                        &session_id,
                        terminal_status,
                        &artifact_dir,
                        &aggregated_steps,
                    );
                    set_live_state_status(&mut snapshot.live_state, terminal_status, Some(true));
                    if synthetic_cancelled
                        || matches!(&action, ResolvedScriptStageAction::AntennaExternalLeadInspection { .. } | ResolvedScriptStageAction::AntennaClosedLoopInspection { .. })
                    {
                        let previous_stage_execution = snapshot.stage_execution.clone();
                        let terminal_completion = fullmag_ir::StageCompletionIR {
                            status: terminal_status.into(),
                            converged: false,
                            reason: Some(if synthetic_cancelled {
                                fullmag_ir::StageStopReason::UserCancelled
                            } else {
                                fullmag_ir::StageStopReason::BackendError
                            }),
                            metric: None,
                            metric_name: None,
                            metric_value: None,
                            threshold: None,
                        };
                        let mut next_stage_execution =
                            scripted_stage_execution_state_with_completion(
                                stage_count,
                                stage_index,
                                &stage.entrypoint_kind,
                                terminal_status,
                                start_solver_command_id.as_deref(),
                                Some(stage_started_at_unix_ms),
                                Some(terminal_at_unix_ms),
                                Some(synthetic_artifact_ref.display().to_string()),
                                Some(&terminal_completion),
                                stage.incoming_transition.as_ref(),
                            );
                        preserve_terminal_stage_history(
                            &mut next_stage_execution,
                            previous_stage_execution.as_ref(),
                        );
                        attach_stage_antenna_solve_identity(
                            &mut next_stage_execution,
                            stage_index,
                            stage.action.as_ref(),
                        );
                        attach_stage_fem_mesh_identity(
                            &mut next_stage_execution,
                            stage_index,
                            stage_fem_mesh_asset.as_ref(),
                        );
                        snapshot.stage_execution = Some(next_stage_execution);
                    } else {
                        mark_live_stage_execution_failed(
                            &mut snapshot.stage_execution,
                            terminal_at_unix_ms,
                        );
                    }
                    live_workspace.replace(snapshot);
                    if synthetic_cancelled {
                        scripted_cancelled = true;
                        display_selection_handle.clear_running_interrupt();
                        live_workspace.push_log(
                            "warning",
                            format!("Synthetic stage execution cancelled: {}", error),
                        );
                        break;
                    }
                    live_workspace.push_log(
                        "error",
                        format!("Synthetic stage execution failed: {}", error),
                    );
                    return Err(error);
                }
            };
            if let ResolvedScriptStageAction::AntennaFieldSolve {
                stage_id,
                port_mode_id,
                ..
            } = &action
            {
                for reference in read_ready_antenna_stage_outputs(
                    &antenna_stage_output_catalog_path(&current_stage_artifact_dir),
                    &artifact_dir,
                    stage_id,
                    port_mode_id,
                )? {
                    let key = (
                        reference.stage_id.clone(),
                        reference.output_id.clone(),
                        port_mode_id.clone(),
                    );
                    if published_antenna_outputs.insert(key, reference).is_some() {
                        bail!("antenna stage output was published more than once in this pipeline");
                    }
                }
            }

            let restored_saved_state_source = match &action {
                ResolvedScriptStageAction::SaveState { artifact_name, .. } => {
                    let source = continuation_source.clone().unwrap_or_else(|| {
                        continuation_source_from_backend_plan(&execution_plan.backend_plan)
                    });
                    saved_state_sources.insert(artifact_name.clone(), source);
                    None
                }
                ResolvedScriptStageAction::LoadState {
                    artifact_name: Some(artifact_name),
                    state_path: None,
                    ..
                } => saved_state_sources.get(artifact_name).cloned(),
                _ => None,
            };

            let synthetic_stats = aggregated_steps.last().cloned().unwrap_or_default();
            let final_update = snapshot_step_update_from_stats(
                &execution_plan.backend_plan,
                stage_fem_mesh_asset
                    .as_ref()
                    .map(|asset| asset.identity.generation_id().to_string()),
                synthetic_stats,
                &synthetic_outcome.magnetization,
                is_session_final_stage,
            );
            let synthetic_completed_at_unix_ms = unix_time_millis()?;
            live_workspace.update(|state| {
                // Synthetic stages still produce a real magnetization snapshot.  Route the
                // terminal update through the same ingest path as solver callbacks so the
                // field resource carries the synthetic stage's source step/revision instead of
                // retaining an older preview (for example source_step=0 after a step-342 run).
                let _ = apply_live_step_update_to_workspace_state(
                    state,
                    &run_id,
                    &session_id,
                    &artifact_dir,
                    final_update,
                    true,
                );
                let previous_stage_execution = state.stage_execution.clone();
                let mut next_stage_execution = scripted_stage_execution_state(
                    stage_count,
                    stage_index,
                    &stage.entrypoint_kind,
                    "completed",
                    start_solver_command_id.as_deref(),
                    Some(stage_started_at_unix_ms),
                    Some(synthetic_completed_at_unix_ms),
                    Some(synthetic_artifact_ref.display().to_string()),
                    None,
                    stage.incoming_transition.as_ref(),
                );
                preserve_terminal_stage_history(
                    &mut next_stage_execution,
                    previous_stage_execution.as_ref(),
                );
                attach_stage_antenna_solve_identity(
                    &mut next_stage_execution,
                    stage_index,
                    stage.action.as_ref(),
                );
                attach_stage_fem_mesh_identity(
                    &mut next_stage_execution,
                    stage_index,
                    stage_fem_mesh_asset.as_ref(),
                );
                if interactive_requested && is_session_final_stage {
                    publish_scripted_stages_awaiting_command(&mut next_stage_execution);
                }
                state.stage_execution = Some(next_stage_execution);
                if antenna_external_lead_inspection::is_carrier(&execution_plan) {
                    antenna_external_lead_inspection::clear_magnetic_snapshot(state);
                }
            });

            if matches!(action, ResolvedScriptStageAction::LoadState { .. }) {
                let display_selection = display_selection_handle.display_selection_snapshot();
                if let Err(error) = refresh_problem_preview_state(
                    &stage.ir,
                    Some(synthetic_outcome.magnetization.as_slice()),
                    &display_selection,
                    &live_workspace,
                    if supports_dynamic_live_preview(&execution_plan.backend_plan) {
                        ProblemPreviewRefreshMode::MaterializeFields
                    } else {
                        ProblemPreviewRefreshMode::PreviewOnly
                    },
                ) {
                    live_workspace.push_log(
                        "warn",
                        format!("Loaded state preview refresh failed: {}", error),
                    );
                }
            }

            // Inspection does not create or replace magnetic state. In
            // particular, absent continuation must stay None, not Some([]).
            if !matches!(
                action,
                ResolvedScriptStageAction::AntennaExternalLeadInspection { .. }
                    | ResolvedScriptStageAction::AntennaClosedLoopInspection { .. }
            ) {
                if matches!(action, ResolvedScriptStageAction::LoadState { .. }) {
                    headless_has_physical_predecessor = true;
                }
                let frozen_grid_matches = match (headless_frozen_continuation.as_ref(), &execution_plan.backend_plan) {
                    (Some(source), BackendPlanIR::Fdm(plan)) =>
                        same_headless_frozen_grid(&source.source_grid, headless_frozen_grid(plan)?),
                    (Some(_), _) => false,
                    (None, _) => true,
                };
                let preserves_frozen_source = frozen_grid_matches
                    && !matches!(action, ResolvedScriptStageAction::LoadState { .. })
                    && continuation_magnetization.as_deref().is_some_and(|previous| {
                        previous.len() == synthetic_outcome.magnetization.len()
                            && previous.iter().flatten().zip(synthetic_outcome.magnetization.iter().flatten())
                                .all(|(left, right)| left.to_bits() == right.to_bits())
                    });
                if !preserves_frozen_source {
                    headless_frozen_continuation = None;
                }
                replace_continuation_after_synthetic_stage(
                    &mut continuation_magnetization,
                    &mut continuation_source,
                    &mut continuation_fem_mesh_payload,
                    &mut continuation_completion,
                    &mut continuation_stage_source,
                    &mut continuation_accepted_fields,
                    &mut continuation_certified_fields,
                    &mut continuation_relax_handoff,
                    synthetic_outcome.magnetization,
                    matches!(action, ResolvedScriptStageAction::ChangeDevice { .. }),
                );
            }
            if matches!(
                action,
                ResolvedScriptStageAction::LoadState {
                    artifact_name: Some(_),
                    state_path: None,
                    ..
                }
            ) {
                continuation_source = restored_saved_state_source;
            }
            live_workspace.push_log("success", synthetic_outcome.message);
            eprintln!(
                "[fullmag] stage {}/{} ({}) completed (synthetic/mesh)",
                stage_index + 1,
                stage_count,
                stage.entrypoint_kind
            );
            live_workspace.push_log(
                "success",
                format!(
                    "Stage {}/{} ({}) completed",
                    stage_index + 1,
                    stage_count,
                    stage.entrypoint_kind
                ),
            );
            continue;
        }

        let torque_mode = torque_display_mode(&stage.ir);
        let stage_progress_label = format!(
            "stage {}/{} ({})",
            stage_index + 1,
            stage_count,
            stage.entrypoint_kind
        );
        let mut stage_heartbeat = use_live_callback.then(|| {
            StageProgressHeartbeat::spawn(
                stage_initial_update,
                live_workspace.clone(),
                run_id.clone(),
                session_id.clone(),
                artifact_dir.clone(),
                stage_progress_label.clone(),
                stage_progress_label.clone(),
                torque_mode,
            )
        });
        publish_frozen_spins_runtime_status_for_execution_plan(&live_workspace, &execution_plan)?;
        let headless_frozen_context = if headless_frozen_lifecycle_required {
            if let BackendPlanIR::Fdm(target) = &execution_plan.backend_plan {
                let runtime = fullmag_runner::resolve_planned_runtime_engine(&stage.ir, &execution_plan)
                    .map_err(|error| anyhow!(error.message))?;
                if runtime.engine_id != "fdm_cpu_reference" {
                    bail!("headless frozen continuation requires the explicit FDM CPU reference realization");
                }
                let target_grid = headless_frozen_grid(target)?;
                let (previous, child, source_stage, source_plan) = match headless_frozen_continuation.as_ref() {
                    Some(source) => {
                        if !same_headless_frozen_grid(&source.source_grid, target_grid) {
                            bail!("headless frozen continuation changed its resolved topology without a qualified lifecycle transfer");
                        }
                        let previous_m = continuation_magnetization.as_deref()
                            .context("headless frozen lifecycle lost its physical state input")?;
                        if previous_m.len() != target.initial_magnetization.len()
                            || previous_m.iter().flatten().zip(target.initial_magnetization.iter().flatten())
                                .any(|(left, right)| left.to_bits() != right.to_bits())
                        {
                            bail!("headless frozen continuation materialized a different state input");
                        }
                        (
                            source.lifecycle.frozen_activation_set.clone(),
                            source.lifecycle.frozen_spins.clone(),
                            Some(source.source_stage_id.clone()),
                            source.source_plan.as_ref(),
                        )
                    },
                    None if !headless_has_physical_predecessor => {
                        // Configuration-only synthetic actions can materialize
                        // authored M before the first solve. They are not a
                        // physical predecessor and cannot introduce a new M.
                        if let Some(authored_m) = continuation_magnetization.as_deref() {
                            if authored_m.len() != target.initial_magnetization.len()
                                || authored_m.iter().flatten().zip(target.initial_magnetization.iter().flatten())
                                    .any(|(left, right)| left.to_bits() != right.to_bits())
                            {
                                bail!("fresh authored root changed its state before frozen admission");
                            }
                        }
                        (fullmag_runner::constraints::FrozenSpinsActivationSet::default(), None, None, None)
                    },
                    None => bail!("headless frozen continuation has an M-only predecessor without a complete lifecycle binding"),
                };
                Some(fullmag_runner::constraints::FrozenStageContextV1::prepare_stage_entry(
                    previous, child, source_stage, current_stage_id.clone(),
                    target.frozen_spins.as_ref(), source_plan != target.frozen_spins.as_ref(),
                ).map_err(|error| anyhow!(error.message))?)
            } else {
                if headless_frozen_continuation.is_some() {
                    bail!("headless frozen continuation cannot cross into a different backend without a qualified lifecycle transfer");
                }
                None
            }
        } else { None };
        let mut stage_result = match if use_live_callback {
            if supports_dynamic_live_preview(&execution_plan.backend_plan) {
                let mut live_cadence = LiveProgressCadence::default();
                let display_selection = || display_selection_handle.display_selection_snapshot();
                let interrupt_signal = display_selection_handle.running_interrupt_signal();
                fullmag_runner::run_planned_problem_with_live_preview_interruptible_with_initial_snapshot_and_hysteresis_stage_id_and_fem_mesh_identity_and_autosave_root_and_frozen_stage_context(
                    &stage.ir,
                    &execution_plan,
                    stage_fem_mesh_asset.as_ref().map(|asset| &asset.identity),
                    stage.until_seconds,
                    &current_stage_artifact_dir,
                    &artifact_dir,
                    field_every_n,
                    &display_selection,
                    Some(interrupt_signal.as_ref()),
                    !args.headless && !preview_3d_disabled,
                    Some(&current_stage_id),
                    headless_frozen_context.as_ref().map(|context| (
                        context,
                        headless_frozen_continuation.as_ref().and_then(|source| source.source_plan.as_ref()),
                    )),
                    |update| {
                        let callback_start = solver_profile_callback_start(&live_workspace);
                        let _callback_nvtx = nvtx_range::Range::new(b"fem.host.callback\0");
                        let finished = update.finished && is_session_final_stage;
                        let mut adjusted = offset_step_update(
                            update,
                            step_offset,
                            runner_time_offset,
                            finished,
                        );
                        if let Some(heartbeat) = stage_heartbeat.as_mut() {
                            heartbeat.record(&mut adjusted);
                        }
                        drain_solver_profile_commands(&display_selection_handle, &live_workspace);
                        let profile_record = begin_solver_profile_step_with_orchestration(
                            &live_workspace,
                            &mut adjusted.stats,
                            callback_start,
                        );
                        if is_control_checkpoint_only(&adjusted) {
                            if live_cadence.should_publish(&adjusted) {
                                adjusted = publish_live_step_update(
                                    &live_workspace,
                                    &run_id,
                                    &session_id,
                                    &artifact_dir,
                                    adjusted,
                                    false,
                                );
                            }
                            if let Some(action) = display_selection_handle.process_running_control()
                            {
                                finish_solver_profile_step_with_orchestration(
                                    &live_workspace,
                                    callback_start,
                                    profile_record,
                                );
                                return action;
                            }
                            finish_solver_profile_step_with_orchestration(
                                &live_workspace,
                                callback_start,
                                profile_record,
                            );
                            return fullmag_runner::StepAction::Continue;
                        }
                        if live_cadence.should_log(&adjusted) {
                            eprintln!(
                                "{}",
                                format_stage_progress_line(
                                    &stage_progress_label,
                                    &adjusted.stats,
                                    torque_mode,
                                    None,
                                    adjusted.hysteresis_field_m_t,
                                )
                            );
                        }

                        if live_cadence.should_publish(&adjusted) {
                            adjusted = publish_live_step_update(
                                &live_workspace,
                                &run_id,
                                &session_id,
                                &artifact_dir,
                                adjusted,
                                true,
                            );
                        }
                        if let Some(action) = display_selection_handle.process_running_control() {
                            finish_solver_profile_step_with_orchestration(
                                &live_workspace,
                                callback_start,
                                profile_record,
                            );
                            return action;
                        }
                        finish_solver_profile_step_with_orchestration(
                            &live_workspace,
                            callback_start,
                            profile_record,
                        );
                        fullmag_runner::StepAction::Continue
                    },
                )
            } else {
                let mut live_cadence = LiveProgressCadence::default();
                fullmag_runner::run_planned_problem_with_callback_and_hysteresis_stage_id_and_relax_handoff(
                    &stage.ir,
                    &execution_plan,
                    stage.until_seconds,
                    &current_stage_artifact_dir,
                    field_every_n,
                    Some(&current_stage_id),
                    relax_handoff.as_ref(),
                    |update| {
                        let callback_start = solver_profile_callback_start(&live_workspace);
                        let _callback_nvtx = nvtx_range::Range::new(b"fem.host.callback\0");
                        let finished = update.finished && is_session_final_stage;
                        let mut adjusted =
                            offset_step_update(update, step_offset, runner_time_offset, finished);
                        if let Some(heartbeat) = stage_heartbeat.as_mut() {
                            heartbeat.record(&mut adjusted);
                        }
                        drain_solver_profile_commands(&display_selection_handle, &live_workspace);
                        let profile_record = begin_solver_profile_step_with_orchestration(
                            &live_workspace,
                            &mut adjusted.stats,
                            callback_start,
                        );
                        if live_cadence.should_log(&adjusted) {
                            eprintln!(
                                "{}",
                                format_stage_progress_line(
                                    &stage_progress_label,
                                    &adjusted.stats,
                                    torque_mode,
                                    None,
                                    adjusted.hysteresis_field_m_t,
                                )
                            );
                        }

                        if live_cadence.should_publish(&adjusted) {
                            adjusted = publish_live_step_update(
                                &live_workspace,
                                &run_id,
                                &session_id,
                                &artifact_dir,
                                adjusted,
                                true,
                            );
                        }
                        finish_solver_profile_step_with_orchestration(
                            &live_workspace,
                            callback_start,
                            profile_record,
                        );
                        fullmag_runner::StepAction::Continue
                    },
                )
            }
        } else {
            fullmag_runner::run_planned_problem_with_hysteresis_stage_id(
                &stage.ir,
                &execution_plan,
                stage.until_seconds,
                &current_stage_artifact_dir,
                Some(&current_stage_id),
            )
        } {
            Ok(result) => result,
            Err(error) => {
                if let Some(mut heartbeat) = stage_heartbeat.take() {
                    heartbeat.finish();
                }
                let failed_at_unix_ms = unix_time_millis()?;
                let mut snapshot = live_workspace.snapshot();
                let failed_runtime = session_runtime_selection_for_problem(
                    &stage.ir,
                    Some(&execution_plan),
                    field_every_n,
                    backend_target_name(final_requested_backend),
                    execution_mode_name(final_execution_mode),
                    execution_precision_name(final_precision),
                );
                snapshot.session = build_session_manifest(
                    &session_id,
                    &run_id,
                    "failed",
                    interactive_requested,
                    &script_path,
                    &final_problem_name,
                    &failed_runtime,
                    &artifact_dir,
                    started_at_unix_ms,
                    failed_at_unix_ms,
                    plan_summary_json(&current_plan_summary),
                );
                snapshot.metadata =
                    Some(current_live_metadata(&stage.ir, &execution_plan, "failed"));
                snapshot.mesh_workspace = current_mesh_workspace(
                    &stage.ir,
                    &execution_plan,
                    "failed",
                    current_mesh_quality.as_ref(),
                    &current_mesh_history,
                );
                snapshot.run = run_manifest_from_steps(
                    &run_id,
                    &session_id,
                    "failed",
                    &artifact_dir,
                    &aggregated_steps,
                );
                mark_live_stage_execution_failed(&mut snapshot.stage_execution, failed_at_unix_ms);
                set_live_state_status(&mut snapshot.live_state, "failed", Some(true));
                live_workspace.replace(snapshot);
                live_workspace.push_log("error", format!("Stage execution failed: {}", error));
                return Err(anyhow!(error.to_string()));
            }
        };

        let adaptive_followup_ran = maybe_execute_adaptive_relaxation_followup_passes(
            &mut stage,
            &mut execution_plan,
            &mut stage_result,
            &mut stage_fem_mesh_asset,
            &live_workspace,
            stage_index,
            stage_count,
            &run_id,
            &session_id,
            &artifact_dir,
            &current_stage_artifact_dir,
            field_every_n,
            step_offset,
            &mut current_mesh_quality,
            &mut current_mesh_history,
            &mut current_fem_mesh_override,
            &mut current_fem_hmax_override,
            &mut current_adaptive_runtime_state,
        )?;
        if adaptive_followup_ran {
            current_plan_summary = stage
                .ir
                .plan_for(args.backend.map(BackendTarget::from))
                .map_err(join_errors)?;
            execution_plan =
                fullmag_plan::plan(&stage.ir).map_err(|error| anyhow!(error.to_string()))?;
        }
        force_record_solver_profile_finalization(
            &live_workspace,
            &stage_result,
            step_offset,
            runner_time_offset,
        );

        if !use_live_callback {
            let frozen_spins_checkpoint =
                frozen_spins_checkpoint_from_stage_artifacts(&current_stage_artifact_dir)?;
            let grid = match &execution_plan.backend_plan {
                BackendPlanIR::Fdm(fdm) => {
                    [fdm.grid.cells[0], fdm.grid.cells[1], fdm.grid.cells[2]]
                }
                BackendPlanIR::FdmMultilayer(fdm) => [
                    fdm.common_cells[0],
                    fdm.common_cells[1],
                    fdm.common_cells[2],
                ],
                BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)
                | BackendPlanIR::AntennaFieldOnly(_)
                | BackendPlanIR::AntennaExternalLeadInspection(_)
                | BackendPlanIR::Fem(_)
                | BackendPlanIR::FemEigen(_)
                | BackendPlanIR::FemFrequencyResponse(_) => [0, 0, 0],
            };
            let fem_mesh_generation_id = stage_fem_mesh_asset
                .as_ref()
                .map(|asset| asset.identity.generation_id().to_string());
            let mut live_cadence = LiveProgressCadence::default();
            for (index, stats) in stage_result.steps.iter().enumerate() {
                let is_final_step = index + 1 == stage_result.steps.len();
                let update = fullmag_runner::StepUpdate {
                    coupled_checkpoint: is_final_step
                        .then(|| frozen_spins_checkpoint.clone())
                        .flatten(),
                    stats: offset_step_stats(std::slice::from_ref(stats), step_offset, runner_time_offset)
                        .into_iter()
                        .next()
                        .expect("single step should offset"),
                    grid,
                    fem_mesh_generation_id: fem_mesh_generation_id.clone(),
                    magnetization: if is_final_step
                        && is_session_final_stage
                        && matches!(&execution_plan.backend_plan, BackendPlanIR::Fdm(_))
                    {
                        Some(flatten_magnetization(&stage_result.final_magnetization))
                    } else {
                        None
                    },
                    preview_field: None,
                    cached_preview_fields: None,
                    hysteresis_field_m_t: None,
                    hysteresis_point_index: None,
                    hysteresis_settle_step_index: None,
                    hysteresis_settle_step_kind: None,
                    hysteresis_settle_step_method: None,
                    scalar_row_due: true,
                    terminal_field_snapshot: false,
                    finished: is_final_step && is_session_final_stage,
                    magnetization_carrier: None,
                };
                if live_cadence.should_publish(&update) {
                    live_workspace.update(|state| {
                        state.session.status = if update.finished {
                            "completed".to_string()
                        } else {
                            "running".to_string()
                        };
                        state.run = running_run_manifest_from_update(
                            &run_id,
                            &session_id,
                            &artifact_dir,
                            &update,
                        );
                        state.live_state = live_state_manifest_from_update(update.clone());
                        set_latest_scalar_row_if_due(state, &update);
                    });
                }
            }
        }

        let stage_failed = stage_result.status == fullmag_runner::RunStatus::Failed
            || stage_result
                .completion
                .as_ref()
                .is_some_and(|completion| completion.status == "failed");
        if let Some(final_update) = final_stage_step_update(
            &execution_plan.backend_plan,
            stage_fem_mesh_asset
                .as_ref()
                .map(|asset| asset.identity.generation_id().to_string()),
            &stage_result.steps,
            &stage_result.final_magnetization,
            step_offset,
            runner_time_offset,
            is_session_final_stage && !stage_failed,
            frozen_spins_checkpoint_from_stage_artifacts(&current_stage_artifact_dir)?,
        ) {
            live_workspace.update(|state| {
                // The terminal solver payload must use the same ingest path as ordinary live
                // callbacks; otherwise the latest-step view changes while latest_fields.m
                // remains at source_step=0.
                let _ = apply_terminal_live_step_update_to_workspace_state(
                    state,
                    &run_id,
                    &session_id,
                    &artifact_dir,
                    final_update,
                );
            });
            live_workspace.force_publish_latest_scalar_row();
        }

        headless_has_physical_predecessor = true;
        // The runner has completed its normal writer drain and artifact owner.
        // Capture only the terminal accepted lifecycle, before replacing M.
        if let Some(context) = headless_frozen_context.as_ref() {
            if stage_result.status == fullmag_runner::RunStatus::Completed && !stage_failed {
                let BackendPlanIR::Fdm(plan) = &execution_plan.backend_plan else {
                    bail!("headless frozen terminal has no FDM source plan");
                };
                headless_frozen_continuation = Some(read_headless_frozen_terminal(
                    &current_stage_artifact_dir, plan, &stage_result, context, &current_stage_id,
                )?);
            } else {
                headless_frozen_continuation = None;
            }
        }
        let offset_steps = offset_step_stats(&stage_result.steps, step_offset, runner_time_offset);
        let completed_step = offset_steps.last().map(|last| last.step);
        if let Some(last) = offset_steps.last() {
            step_offset = last.step;
            time_offset = last.time;
        }
        aggregated_steps.extend(offset_steps);
        let next_continuation_magnetization = stage_result.final_magnetization.clone();
        let next_continuation_completion = stage_result.completion.clone();
        let native_equilibrium_artifact_paths = match &execution_plan.backend_plan {
            BackendPlanIR::Fem(plan) => Some(
                fullmag_runner::CertifiedFemEquilibriumFields::artifact_paths_for_material(
                    &plan.material,
                ),
            ),
            _ => None,
        };
        let native_accepted_equilibrium_artifact_path = match &execution_plan.backend_plan {
            BackendPlanIR::Fem(plan) => Some(
                fullmag_runner::CertifiedFemEquilibriumFields::accepted_artifact_path_for_material(
                    &plan.material,
                ),
            ),
            _ => None,
        };
        let next_continuation_accepted_fields =
            if matches!(&stage.ir.study, fullmag_ir::StudyIR::Relaxation { .. })
                && matches!(&execution_plan.backend_plan, BackendPlanIR::Fem(_))
                && stage_result.completion.as_ref().is_some_and(|completion| {
                    completion.status == "completed" && completion.converged
                })
            {
                let path = current_stage_artifact_dir.join(
                    native_accepted_equilibrium_artifact_path
                        .expect("FEM relaxation plan was checked"),
                );
                let bytes = fs::read(&path).with_context(|| {
                    format!(
                        "accepted native FEM relaxation did not publish accepted fields {}",
                        path.display()
                    )
                })?;
                Some(
                    serde_json::from_slice(&bytes)
                        .with_context(|| format!("failed to decode {}", path.display()))?,
                )
            } else {
                None
            };
        let next_continuation_certified_fields =
            if matches!(&stage.ir.study, fullmag_ir::StudyIR::Relaxation { .. })
                && matches!(&execution_plan.backend_plan, BackendPlanIR::Fem(_))
                && stage_result.completion.as_ref().is_some_and(|completion| {
                    completion.status == "completed" && completion.converged
                })
            {
                let path = current_stage_artifact_dir.join(
                    native_equilibrium_artifact_paths.expect("FEM relaxation plan was checked").0,
                );
                let bytes = fs::read(&path).with_context(|| {
                    format!(
                        "certified native FEM relaxation did not publish {}",
                        path.display()
                    )
                })?;
                Some(
                    serde_json::from_slice(&bytes)
                        .with_context(|| format!("failed to decode {}", path.display()))?,
                )
            } else {
                None
            };
        let next_continuation_recomputed_certificate =
            if matches!(&stage.ir.study, fullmag_ir::StudyIR::Relaxation { .. })
                && matches!(&execution_plan.backend_plan, BackendPlanIR::Fem(_))
                && stage_result.completion.as_ref().is_some_and(|completion| {
                    completion.status == "completed" && completion.converged
                })
            {
                let path = current_stage_artifact_dir.join(
                    native_equilibrium_artifact_paths.expect("FEM relaxation plan was checked").1,
                );
                let bytes = fs::read(&path).with_context(|| {
                    format!(
                        "recomputed native FEM relaxation did not publish {}",
                        path.display()
                    )
                })?;
                Some(
                    serde_json::from_slice(&bytes)
                        .with_context(|| format!("failed to decode {}", path.display()))?,
                )
            } else {
                None
            };
        let next_continuation_stage_source = ContinuationStageSource {
            run_id: run_id.clone(),
            stage_id: current_stage_id.clone(),
            stage_kind: stage.entrypoint_kind.clone(),
            is_relaxation: matches!(&stage.ir.study, fullmag_ir::StudyIR::Relaxation { .. }),
        };
        let next_continuation_fem_mesh_payload =
            fem_mesh_payload_from_backend_plan(&execution_plan.backend_plan);
        let next_relax_handoff = match (
            next_continuation_completion.as_ref(),
            next_continuation_fem_mesh_payload.as_ref(),
            next_continuation_accepted_fields.as_ref(),
            next_continuation_certified_fields.as_ref(),
            next_continuation_recomputed_certificate.as_ref(),
        ) {
            (
                Some(completion),
                Some(source_mesh),
                Some(accepted_fields),
                Some(certified_fields),
                Some(recomputed_certificate),
            ) => accepted_relax_handoff_from_completed_stage_with_exact_artifacts(
                &execution_plan.backend_plan,
                &next_continuation_stage_source,
                source_mesh,
                completion,
                &next_continuation_magnetization,
                &current_stage_artifact_dir,
                accepted_fields,
                certified_fields,
                recomputed_certificate,
            )?,
            _ => None,
        };
        let accepted_equilibrium_artifact_refs = if let (
            Some(receipt), Some(certificate), BackendPlanIR::Fem(plan),
        ) = (next_relax_handoff.as_ref(), next_continuation_recomputed_certificate.as_ref(), &execution_plan.backend_plan) {
            let engine = fullmag_runner::resolve_planned_runtime_engine(&stage.ir, &execution_plan)
                .map_err(|error| anyhow!("accepted equilibrium execution owner: {}", error.message))?;
            if stage_result.status == fullmag_runner::RunStatus::Completed && !stage_failed
                && engine.engine_id == "fem_cpu_native" && plan.precision == fullmag_ir::ExecutionPrecision::Double && plan.fe_order == 1 {
                let authored_stage_id = stage.ir.problem_meta.runtime_metadata.get("active_stage_id")
                    .and_then(serde_json::Value::as_str).filter(|id| !id.trim().is_empty()).unwrap_or(&current_stage_id);
                let artifacts = fullmag_runner::accepted_antenna_equilibrium_artifacts(plan, receipt, certificate, &engine.engine_id, authored_stage_id)
                    .map_err(|error| anyhow!("accepted equilibrium producer: {}", error.message))?;
                fullmag_runner::publish_accepted_antenna_equilibrium(&artifact_dir, &artifacts)
                    .map_err(|error| anyhow!("publish accepted equilibrium: {}", error.message))?
            } else { Vec::new() }
        } else { Vec::new() };
        continuation_magnetization = Some(next_continuation_magnetization);
        continuation_completion = next_continuation_completion;
        continuation_accepted_fields = next_continuation_accepted_fields;
        continuation_certified_fields = next_continuation_certified_fields;
        continuation_stage_source = Some(next_continuation_stage_source);
        continuation_fem_mesh_payload = next_continuation_fem_mesh_payload;
        continuation_relax_handoff = next_relax_handoff;
        continuation_source = Some(continuation_source_from_backend_plan(
            &execution_plan.backend_plan,
        ));

        // If the stage was cancelled (user clicked Stop) or paused, skip
        // remaining scripted stages so that the interactive command loop can
        // take over.  Without this, pressing Stop during fm.relax() would
        // merely cancel the relax and immediately start the next fm.run().
        if stage_result.status == fullmag_runner::RunStatus::Cancelled
            || stage_result.status == fullmag_runner::RunStatus::Paused
        {
            let interrupted_at_unix_ms = unix_time_millis()?;
            let interrupted_status = if stage_result.status == fullmag_runner::RunStatus::Cancelled
            {
                "cancelled"
            } else {
                "paused"
            };
            if stage_result.status == fullmag_runner::RunStatus::Paused {
                let stage_command = crate::types::SessionCommand {
                    seq: 0,
                    command_id: start_solver_command_id
                        .clone()
                        .unwrap_or_else(|| format!("{}_stage_{}", run_id, stage_index + 1)),
                    kind: match &stage.ir.study {
                        fullmag_ir::StudyIR::Relaxation { .. } => "relax".to_string(),
                        _ => "run".to_string(),
                    },
                    created_at_unix_ms: stage_started_at_unix_ms,
                    target: Some(crate::types::RuntimeCommandTarget::StageIndex {
                        stage_index: stage_index as u32,
                    }),
                    reason: Some("scripted_stage_pause".to_string()),
                    precondition: None,
                    client_intent_id: None,
                    requested_at_unix_ms: Some(millis_to_u64(stage_started_at_unix_ms)),
                    until_seconds: Some(stage.until_seconds),
                    max_steps: None,
                    torque_tolerance: None,
                    energy_tolerance: None,
                    integrator: None,
                    fixed_timestep: None,
                    max_error: None,
                    solver_policy: None,
                    relax_algorithm: None,
                    relax_alpha: None,
                    mesh_options: None,
                    mesh_target: None,
                    mesh_reason: None,
                    state_path: None,
                    state_format: None,
                    state_dataset: None,
                    state_sample_index: None,
                    display_selection: None,
                    preview_config: None,
                    stages: None,
                    profile: None,
                    frozen_spins_runtime_plan_binding: None,
                };
                let elapsed_seconds = elapsed_stage_seconds(
                    &stage_result,
                    stage_start_time_s,
                    stage_time_frame,
                )?;
                paused_stage = build_resumable_interactive_command(
                    &stage_command,
                    &stage_result,
                    elapsed_seconds,
                )
                    .map(|command| PausedInteractiveStage {
                        command,
                        source_kind: stage.entrypoint_kind.clone(),
                        checkpoint_ref: None,
                        checkpoint_resume_error: checkpoint_resume_error_for_backend_plan(
                            &execution_plan.backend_plan,
                        ),
                        waveform_origin_time_s: stage
                            .ir
                            .problem_meta
                            .runtime_metadata
                            .get("stage_waveform_origin_time_s")
                            .and_then(serde_json::Value::as_f64)
                            .unwrap_or(stage_start_time_s),
                        requires_exact_waveform_clock: has_time_dependent_stage_drive(&stage.ir),
                    });
            }
            live_workspace.update(|state| {
                let previous_stage_execution = state.stage_execution.clone();
                let mut next_stage_execution = scripted_stage_execution_state(
                    stage_count,
                    stage_index,
                    &stage.entrypoint_kind,
                    interrupted_status,
                    start_solver_command_id.as_deref(),
                    Some(stage_started_at_unix_ms),
                    Some(interrupted_at_unix_ms),
                    Some(current_stage_artifact_dir.display().to_string()),
                    if stage_result.status == fullmag_runner::RunStatus::Cancelled {
                        Some(fullmag_ir::StageStopReason::UserCancelled)
                    } else {
                        None
                    },
                    stage.incoming_transition.as_ref(),
                );
                preserve_terminal_stage_history(
                    &mut next_stage_execution,
                    previous_stage_execution.as_ref(),
                );
                attach_stage_antenna_solve_identity(
                    &mut next_stage_execution,
                    stage_index,
                    stage.action.as_ref(),
                );
                attach_stage_fem_mesh_identity(
                    &mut next_stage_execution,
                    stage_index,
                    stage_fem_mesh_asset.as_ref(),
                );
                state.stage_execution = Some(next_stage_execution);
            });
            live_workspace.push_log(
                "system",
                format!(
                    "Stage {}/{} ({}) {} by user — skipping remaining scripted stages",
                    stage_index + 1,
                    stage_count,
                    stage.entrypoint_kind,
                    if stage_result.status == fullmag_runner::RunStatus::Cancelled {
                        "stopped"
                    } else {
                        "paused"
                    },
                ),
            );
            eprintln!(
                "stage {}/{} ({}) {} — skipping {} remaining scripted stage(s)",
                stage_index + 1,
                stage_count,
                stage.entrypoint_kind,
                if stage_result.status == fullmag_runner::RunStatus::Cancelled {
                    "cancelled"
                } else {
                    "paused"
                },
                stage_count - stage_index - 1,
            );
            break;
        }

        let stage_status = if stage_failed { "failed" } else { "completed" };
        {
            let final_step = stage_result.steps.last();
            eprintln!(
                "[fullmag] stage {}/{} ({}) {} — samples={}  final_step={}  t={:.4e}  max_torque[T]={:.4e}  stop: {}",
                stage_index + 1,
                stage_count,
                stage.entrypoint_kind,
                stage_status,
                stage_result.steps.len(),
                final_step.map(|s| s.step).unwrap_or(0),
                final_step.map(|s| s.time).unwrap_or(0.0),
                final_step.map(|s| s.max_torque_T).unwrap_or(0.0),
                format_stop_reason(stage_result.completion.as_ref()),
            );
        }
        live_workspace.push_log(
            if stage_failed { "error" } else { "success" },
            format!(
                "Stage {}/{} ({}) {}",
                stage_index + 1,
                stage_count,
                stage.entrypoint_kind,
                stage_status
            ),
        );
        let completed_at_unix_ms = unix_time_millis()?;
        live_workspace.update(|state| {
            let previous_stage_execution = state.stage_execution.clone();
            let mut next_stage_execution = scripted_stage_execution_state_with_completion(
                stage_count,
                stage_index,
                &stage.entrypoint_kind,
                stage_status,
                start_solver_command_id.as_deref(),
                Some(stage_started_at_unix_ms),
                Some(completed_at_unix_ms),
                Some(current_stage_artifact_dir.display().to_string()),
                stage_result.completion.as_ref(),
                stage.incoming_transition.as_ref(),
            );
            attach_scripted_stage_solver_steps(
                &mut next_stage_execution,
                stage_index,
                stage_application_boundary.as_ref(),
                completed_step,
            );
            preserve_terminal_stage_history(
                &mut next_stage_execution,
                previous_stage_execution.as_ref(),
            );
            preserve_completed_parallel_execution(
                &mut next_stage_execution,
                previous_stage_execution.as_ref(),
                stage_index,
            );
            attach_stage_antenna_solve_identity(
                &mut next_stage_execution,
                stage_index,
                stage.action.as_ref(),
            );
            attach_stage_fem_mesh_identity(
                &mut next_stage_execution,
                stage_index,
                stage_fem_mesh_asset.as_ref(),
            );
            if interactive_requested && is_session_final_stage && !stage_failed {
                publish_scripted_stages_awaiting_command(&mut next_stage_execution);
            }
            if let Some(record) = next_stage_execution.stages.get_mut(stage_index) {
                for reference in &accepted_equilibrium_artifact_refs {
                    push_unique_artifact_ref(&mut record.artifact_refs, reference.clone());
                }
            }
            state.stage_execution = Some(next_stage_execution);
            if stage_failed {
                state.session.status = "failed".to_string();
                state.run.status = "failed".to_string();
                set_live_state_status(&mut state.live_state, "failed", Some(true));
            }
        });
        if stage_failed {
            let failure_detail = format_stop_reason(stage_result.completion.as_ref());
            let message = format!(
                "Stage {}/{} ({}) failed: {}",
                stage_index + 1,
                stage_count,
                stage.entrypoint_kind,
                failure_detail,
            );
            live_workspace.push_log("error", message.clone());
            eprintln!("[fullmag] {}", message);
            return Err(anyhow!(message));
        }
    }

    if interactive_requested {
        let awaiting_at_unix_ms = unix_time_millis()?;
        if paused_stage.is_none() {
            resolve_active_antenna_stage_outputs(
                &mut interactive_template_ir,
                &published_antenna_outputs,
            )?;
        }
        apply_current_fem_overrides(
            &mut interactive_template_ir,
            current_fem_mesh_override.as_ref(),
            current_fem_hmax_override,
            current_adaptive_runtime_state.as_ref(),
        );

        // Build session context for interactive command loop
        let mut ctx = crate::runtime_supervisor::InteractiveSessionContext {
            session_id: session_id.clone(),
            run_id: run_id.clone(),
            interactive_requested,
            script_path: script_path.clone(),
            final_problem_name: final_problem_name.clone(),
            runtime_selection: crate::runtime_supervisor::runtime_selection_from_manifest(
                &live_workspace.snapshot().session,
            ),
            artifact_dir: artifact_dir.clone(),
            workspace_dir: workspace_dir.clone(),
            started_at_unix_ms,
            field_every_n,
        };

        if paused_stage.is_none() {
            live_workspace.update(|state| {
                if let Some(execution) = state.stage_execution.as_mut() {
                    publish_scripted_stages_awaiting_command(execution);
                }
                state.session = ctx.build_session(
                    "awaiting_command",
                    &plan_summary_json(&current_plan_summary),
                    awaiting_at_unix_ms,
                );
                state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                set_live_state_status(&mut state.live_state, "awaiting_command", Some(false));
            });
            live_workspace.push_log(
                "system",
                "Scripted stages finished — workspace is awaiting interactive commands",
            );
        } else {
            live_workspace.update(|state| {
                state.session = ctx.build_session(
                    "paused",
                    &plan_summary_json(&current_plan_summary),
                    awaiting_at_unix_ms,
                );
                state.run = ctx.build_run("paused", &aggregated_steps);
                set_live_state_status(&mut state.live_state, "paused", Some(false));
            });
        }
        eprintln!("interactive workspace ready");
        eprintln!("- workspace_id: {}", session_id);
        eprintln!("- queue: submit commands through the control room or API");

        let mut interactive_runtime_host = InteractiveRuntimeHost::new(
            display_selection_handle.clone(),
            interactive_template_ir.clone(),
            &initial_execution_plan.backend_plan,
        );
        if paused_stage.is_some() {
            interactive_runtime_host
                .enter_paused(continuation_magnetization.clone(), &live_workspace);
        } else {
            interactive_runtime_host
                .enter_awaiting_command(continuation_magnetization.clone(), &live_workspace);
        }

        let mut interactive_stage_index = stage_count;
        // ── Sequence runner state ──
        // When a `run_sequence` command is active, this holds the remaining stages.
        // Each completed/skipped stage pops from the front. Break aborts the whole sequence.
        let mut active_sequence: Option<ActiveSequenceState> = None;
        loop {
            if display_selection_handle.owner_session_lost() {
                live_workspace.push_log(
                    "warning",
                    "Attached runtime owner session was replaced — closing workspace",
                );
                break;
            }
            if paused_stage.is_some() {
                match interactive_runtime_host.take_running_interrupt() {
                    Some(crate::interactive_runtime_host::InteractiveStageInterrupt::Break) => {
                        paused_stage = None;
                        let discarded_at_unix_ms = unix_time_millis().unwrap_or(0);
                        let discarded_stage_execution = discard_active_paused_stage_execution(
                            &mut active_sequence,
                            discarded_at_unix_ms,
                        );
                        live_workspace.update(|state| {
                            state.session = ctx.build_session(
                                "awaiting_command",
                                &plan_summary_json(&current_plan_summary),
                                discarded_at_unix_ms,
                            );
                            state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                            set_live_state_status(
                                &mut state.live_state,
                                "awaiting_command",
                                Some(false),
                            );
                            state.stage_execution = discarded_stage_execution;
                        });
                        interactive_runtime_host.enter_awaiting_command(
                            continuation_magnetization.clone(),
                            &live_workspace,
                        );
                        live_workspace.push_log(
                            "system",
                            "Paused stage discarded — workspace is awaiting the next command",
                        );
                        continue;
                    }
                    Some(crate::interactive_runtime_host::InteractiveStageInterrupt::Skip) => {
                        paused_stage = None;
                        let skipped_at_unix_ms = unix_time_millis().unwrap_or(0);
                        let skipped_stage_execution = finish_active_paused_stage_execution(
                            &mut active_sequence,
                            "skipped",
                            skipped_at_unix_ms,
                        );
                        live_workspace.update(|state| {
                            state.session = ctx.build_session(
                                "awaiting_command",
                                &plan_summary_json(&current_plan_summary),
                                skipped_at_unix_ms,
                            );
                            state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                            set_live_state_status(
                                &mut state.live_state,
                                "awaiting_command",
                                Some(false),
                            );
                            state.stage_execution = skipped_stage_execution;
                        });
                        interactive_runtime_host.enter_awaiting_command(
                            continuation_magnetization.clone(),
                            &live_workspace,
                        );
                        live_workspace.push_log(
                            "system",
                            "Paused stage skipped — workspace is awaiting the next command",
                        );
                        continue;
                    }
                    Some(crate::interactive_runtime_host::InteractiveStageInterrupt::Close) => {
                        break;
                    }
                    Some(crate::interactive_runtime_host::InteractiveStageInterrupt::Pause) => {
                        live_workspace.push_log(
                            "system",
                            "Interactive workspace is already paused — use resume or stop",
                        );
                        continue;
                    }
                    None => {}
                }
            }

            let Some(command) =
                interactive_runtime_host.wait_next_command_coalesced(Duration::from_millis(250))
            else {
                if display_selection_handle.owner_session_lost() {
                    live_workspace.push_log(
                        "warning",
                        "Attached runtime owner session was replaced — closing workspace",
                    );
                    break;
                }
                continue;
            };

            let mut frozen_replan_resume_label = None;
            let command = if command.kind == "apply_frozen_spins" {
                if let Some(error) = paused_stage
                    .as_ref()
                    .and_then(|paused| paused.checkpoint_resume_error.as_deref())
                {
                    live_workspace.push_command_log(
                        &command.command_id,
                        "error",
                        format!("Frozen Spins paused-stage resume rejected: {error}"),
                    );
                    continue;
                }
                if let Some(paused) = paused_stage.take() {
                    let resumed = match bind_frozen_spins_replan_to_paused_command(
                        paused.command,
                        &command,
                    ) {
                        Ok(resumed) => resumed,
                        Err(error) => {
                            live_workspace.push_log(
                                "error",
                                format!(
                                    "Frozen Spins hot-apply command {} was rejected: {}",
                                    command.command_id, error
                                ),
                            );
                            continue;
                        }
                    };
                    frozen_replan_resume_label =
                        Some(format!("Frozen Spins hot-apply ({})", paused.source_kind));
                    live_workspace.push_log(
                        "system",
                        format!(
                            "Applying Frozen Spins revision at accepted-step boundary and resuming {}",
                            paused.source_kind
                        ),
                    );
                    resumed
                } else {
                    match problem_with_frozen_spins_runtime_plan_binding(
                        &interactive_template_ir,
                        &command,
                        frozen_spins_applied_scene_revision,
                    ) {
                        Ok(Some((candidate, source_scene_revision))) => {
                            if let Err(error) = validate_ir(&candidate) {
                                live_workspace.push_log(
                                    "error",
                                    format!(
                                        "Frozen Spins revision {source_scene_revision} failed canonical IR validation: {error}"
                                    ),
                                );
                                continue;
                            }
                            interactive_template_ir = candidate;
                            frozen_spins_applied_scene_revision = Some(source_scene_revision);
                            interactive_runtime_host
                                .replace_base_problem(interactive_template_ir.clone());
                            live_workspace.push_log(
                                "system",
                                format!(
                                    "Applied Frozen Spins scene revision {source_scene_revision} to the idle runtime template"
                                ),
                            );
                        }
                        Ok(None) => {}
                        Err(error) => live_workspace.push_log(
                            "error",
                            format!(
                                "Frozen Spins idle runtime-plan binding rejected for command {}: {}",
                                command.command_id, error
                            ),
                        ),
                    }
                    continue;
                }
            } else {
                command
            };

            if interactive_runtime_host.handle_display_sync(&command, &live_workspace) {
                continue;
            }

            if command.kind == "set_solver_profile" {
                apply_solver_profile_command(&live_workspace, &command);
                continue;
            }

            if command.kind == "compute_fields" {
                eprintln!("[fullmag] compute_fields requested — refreshing field snapshots");
                live_workspace.push_log(
                    "system",
                    "Compute fields requested — evaluating current magnetization",
                );
                let live_magnetization = live_workspace.latest_magnetization_vectors();
                let compute_magnetization = live_magnetization
                    .as_deref()
                    .or(continuation_magnetization.as_deref());
                match interactive_runtime_host
                    .compute_current_fields(compute_magnetization, &live_workspace)
                {
                    Ok(()) => live_workspace.push_command_log(
                        &command.command_id,
                        "success",
                        "Field snapshots computed for the current magnetization",
                    ),
                    Err(error) => live_workspace
                        .push_command_log(&command.command_id, "error", format!("Compute fields failed: {}", error)),
                }
                continue;
            }

            if command.kind == "compute_energies" {
                eprintln!("[fullmag] compute_energies requested — evaluating current energies");
                live_workspace.push_log(
                    "system",
                    "Compute energies requested — evaluating current magnetization",
                );
                let live_magnetization = live_workspace.latest_magnetization_vectors();
                let compute_magnetization = live_magnetization
                    .as_deref()
                    .or(continuation_magnetization.as_deref());
                match interactive_runtime_host
                    .compute_current_energies(compute_magnetization, &live_workspace)
                {
                    Ok(()) => live_workspace
                        .push_command_log(&command.command_id, "success", "Energies computed for the current magnetization"),
                    Err(error) => live_workspace
                        .push_command_log(&command.command_id, "error", format!("Compute energies failed: {}", error)),
                }
                continue;
            }

            // Parse into typed command for control protocol dispatch
            let typed_cmd = crate::command_bridge::classify_command(&command);

            if matches!(typed_cmd, Some(fullmag_runner::LiveControlCommand::Pause)) {
                if paused_stage.is_some() {
                    live_workspace.push_log(
                        "system",
                        "Interactive workspace is already paused — use resume or stop",
                    );
                } else {
                    live_workspace.push_log(
                        "system",
                        "Pause is only available while the solver is running",
                    );
                }
                continue;
            }

            if matches!(typed_cmd, Some(fullmag_runner::LiveControlCommand::Break)) {
                if paused_stage.take().is_some() {
                    let discarded_at_unix_ms = unix_time_millis().unwrap_or(0);
                    let discarded_stage_execution = discard_active_paused_stage_execution(
                        &mut active_sequence,
                        discarded_at_unix_ms,
                    );
                    live_workspace.update(|state| {
                        state.session = ctx.build_session(
                            "awaiting_command",
                            &plan_summary_json(&current_plan_summary),
                            discarded_at_unix_ms,
                        );
                        state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                        set_live_state_status(
                            &mut state.live_state,
                            "awaiting_command",
                            Some(false),
                        );
                        state.stage_execution = discarded_stage_execution;
                    });
                    interactive_runtime_host.enter_awaiting_command(
                        continuation_magnetization.clone(),
                        &live_workspace,
                    );
                    live_workspace.push_log(
                        "system",
                        "Paused stage discarded — workspace is awaiting the next command",
                    );
                } else {
                    live_workspace.push_log(
                        "system",
                        "Stop is only available while the solver is running or paused",
                    );
                }
                continue;
            }

            if matches!(typed_cmd, Some(fullmag_runner::LiveControlCommand::Close)) {
                break;
            }

            if matches!(typed_cmd, Some(fullmag_runner::LiveControlCommand::Resume)) {
                if let Some(error) = paused_stage
                    .as_ref()
                    .and_then(|paused| paused.checkpoint_resume_error.as_deref())
                {
                    live_workspace.push_command_log(
                        &command.command_id,
                        "error",
                        format!("Checkpoint resume rejected: {error}"),
                    );
                    continue;
                }
            }
            if matches!(typed_cmd, Some(fullmag_runner::LiveControlCommand::Resume))
                && paused_stage
                    .as_ref()
                    .is_some_and(|paused| paused.requires_exact_waveform_clock)
            {
                live_workspace.push_log(
                    "error",
                    "Resuming a time-dependent drive requires restoring its original waveform clock; stop this paused stage instead",
                );
                continue;
            }

            let (command, resume_label_hint, resumed_waveform_origin_time_s) =
                if matches!(typed_cmd, Some(fullmag_runner::LiveControlCommand::Resume)) {
                    let Some(paused) = paused_stage.take() else {
                        live_workspace.push_log(
                            "warning",
                            "Resume requested, but there is no paused interactive stage",
                        );
                        continue;
                    };
                    live_workspace.push_log(
                        "system",
                        format!("Resuming paused interactive {} stage", paused.source_kind),
                    );
                    if let Some(checkpoint_ref) = paused.checkpoint_ref.as_deref() {
                        if let Some(sequence) = active_sequence.as_mut() {
                            sequence.mark_current_resume_from_checkpoint(checkpoint_ref);
                        }
                    }
                    (
                        paused.command,
                        Some(format!("resume ({})", paused.source_kind)),
                        Some(paused.waveform_origin_time_s),
                    )
                } else {
                    (command, frozen_replan_resume_label, None)
                };
            let frozen_spins_explicit_reactivation = resume_label_hint
                .as_deref()
                .is_some_and(|label| label.starts_with("Frozen Spins hot-apply"));

            if command.kind == "load_state" {
                if paused_stage.is_some() {
                    live_workspace.push_command_log(
                        &command.command_id,
                        "warning",
                        "Failed to load workspace state: load-state is disabled while a stage is paused. Stop it first or resume it.",
                    );
                    continue;
                }
                let Some(state_path) = command.state_path.as_deref() else {
                    live_workspace.push_command_log(&command.command_id, "error", "Failed to load workspace state: missing state_path");
                    continue;
                };
                match read_magnetization_state(
                    Path::new(state_path),
                    command.state_format.as_deref(),
                    command.state_dataset.as_deref(),
                    command.state_sample_index,
                ) {
                    Ok(loaded_state) => {
                        if let Err(error) = interactive_runtime_host
                            .load_state(loaded_state.values.clone(), &live_workspace)
                        {
                            live_workspace.push_command_log(
                                &command.command_id,
                                "error",
                                format!("Failed to load workspace state: {}", error),
                            );
                            continue;
                        }
                        replace_continuation_after_synthetic_stage(
                            &mut continuation_magnetization,
                            &mut continuation_source,
                            &mut continuation_fem_mesh_payload,
                            &mut continuation_completion,
                            &mut continuation_stage_source,
                            &mut continuation_accepted_fields,
                            &mut continuation_certified_fields,
                            &mut continuation_relax_handoff,
                            loaded_state.values,
                            false,
                        );
                        live_workspace.push_command_log(
                            &command.command_id,
                            "success",
                            format!(
                                "Loaded workspace state from {} ({} vectors)",
                                state_path, loaded_state.vector_count
                            ),
                        );
                    }
                    Err(error) => {
                        live_workspace.push_command_log(
                            &command.command_id,
                            "error",
                            format!("Failed to load workspace state: {}", error),
                        );
                    }
                }
                continue;
            }

            if paused_stage.is_some()
                && matches!(
                    typed_cmd,
                    Some(fullmag_runner::LiveControlCommand::Run { .. })
                        | Some(fullmag_runner::LiveControlCommand::Relax { .. })
                        | Some(fullmag_runner::LiveControlCommand::RunSequence { .. })
                )
            {
                paused_stage = None;
                live_workspace.push_log(
                    "warning",
                    "Discarding paused stage and starting a new interactive command",
                );
                live_workspace.update(|state| {
                    set_live_state_status(&mut state.live_state, "awaiting_command", Some(false));
                });
                interactive_runtime_host
                    .enter_awaiting_command(continuation_magnetization.clone(), &live_workspace);
            }

            if matches!(command.kind.as_str(), "remesh" | "fdm_grid_refresh") {
                let mut remesh_problem = interactive_template_ir.clone();
                apply_current_fem_overrides(
                    &mut remesh_problem,
                    current_fem_mesh_override.as_ref(),
                    current_fem_hmax_override,
                    current_adaptive_runtime_state.as_ref(),
                );
                let mut remesh_stages = vec![ResolvedScriptStage::solver(
                    remesh_problem,
                    0.0,
                    "interactive_remesh",
                )];
                let mut remesh_stage_plans = Vec::new();
                if let Some(summary) = execute_manual_interactive_remesh(
                    &command,
                    &mut remesh_stages,
                    &mut remesh_stage_plans,
                    "awaiting_command",
                    &live_workspace,
                    &mut current_mesh_quality,
                    &mut current_mesh_history,
                    &mut current_fem_mesh_override,
                    &mut current_fem_hmax_override,
                    &current_adaptive_runtime_state,
                    &mut continuation_magnetization,
                    &mut continuation_source,
                    &mut continuation_completion,
                    Some(&mut interactive_runtime_host),
                    args.backend.map(BackendTarget::from),
                ) {
                    interactive_template_ir = remesh_stages.remove(0).ir;
                    current_plan_summary = summary;
                    drop(continuation_relax_handoff.take());
                    // The remesh invalidates all cached equilibrium field evidence.
                    continuation_fem_mesh_payload = None;
                    continuation_completion = None;
                    continuation_stage_source = None;
                    continuation_accepted_fields = None;
                    continuation_certified_fields = None;
                    interactive_runtime_host.enter_awaiting_command(None, &live_workspace);
                }
                continue;
            }

            // ── Handle run_sequence: set up sequence state and convert first stage ──
            if command.kind == "run_sequence" {
                if let Some(stages) = command.stages.clone() {
                    if stages.is_empty() {
                        live_workspace
                            .push_log("warning", "run_sequence received with empty stages list");
                        continue;
                    }
                    let total = stages.len();
                    live_workspace.push_log(
                        "system",
                        format!("Starting execution sequence with {} stage(s)", total),
                    );
                    active_sequence = Some(ActiveSequenceState::new(stages));
                } else {
                    live_workspace
                        .push_log("error", "run_sequence command is missing stages payload");
                    continue;
                }
            }

            // ── Handle skip_stage when idle (no running segment) ──
            if matches!(
                typed_cmd,
                Some(fullmag_runner::LiveControlCommand::SkipStage)
            ) {
                if let Some(sequence) = active_sequence.as_mut() {
                    if !sequence.remaining_stages.is_empty() {
                        let skipped_label = sequence.remaining_stages[0].label();
                        sequence.remaining_stages.remove(0);
                        let skipped_at_unix_ms =
                            unix_time_millis().unwrap_or(command.created_at_unix_ms);
                        let skipped_completion = user_cancelled_stage_completion("skipped");
                        sequence.mark_current(
                            "skipped",
                            Some(&skipped_completion),
                            Some(skipped_at_unix_ms),
                            None,
                        );
                        live_workspace.push_log(
                            "system",
                            format!(
                                "Skipped stage {}/{} ({}) while idle",
                                sequence.current_stage_1based,
                                sequence.total_stages(),
                                skipped_label,
                            ),
                        );
                        sequence.advance();
                    }
                    if sequence.remaining_stages.is_empty() {
                        live_workspace.push_log(
                            "success",
                            "Execution sequence completed (all stages skipped)",
                        );
                        live_workspace.update(|state| {
                            state.stage_execution =
                                Some(sequence.completed_stage_execution("awaiting_command"));
                        });
                        active_sequence = None;
                        continue;
                    }
                } else {
                    live_workspace.push_log("warning", "Skip requested but no active sequence");
                    continue;
                }
            }

            // ── If an active sequence has pending stages, pop the next one as the command ──
            let (command, command_kind_label) = if let Some(sequence) = active_sequence.as_mut() {
                if !sequence.remaining_stages.is_empty() && command.kind == "run_sequence" {
                    let stage_def = sequence.remaining_stages.remove(0);
                    let stage_label = stage_def.label().to_string();
                    let synthetic_cmd = sequence_stage_to_session_command(
                        &stage_def,
                        &command.command_id,
                        sequence.current_stage_1based,
                    );
                    let label = format!(
                        "sequence {}/{}: {}",
                        sequence.current_stage_1based,
                        sequence.total_stages(),
                        stage_label
                    );
                    (synthetic_cmd, label)
                } else {
                    let kind = resume_label_hint.unwrap_or_else(|| command.kind.clone());
                    (command, kind)
                }
            } else {
                let kind = resume_label_hint.unwrap_or_else(|| command.kind.clone());
                (command, kind)
            };

            match problem_with_frozen_spins_runtime_plan_binding(
                &interactive_template_ir,
                &command,
                frozen_spins_applied_scene_revision,
            ) {
                Ok(Some((candidate, source_scene_revision))) => {
                    if let Err(error) = validate_ir(&candidate) {
                        live_workspace.push_log(
                            "error",
                            format!(
                                "Frozen Spins revision {source_scene_revision} failed canonical IR validation: {error}"
                            ),
                        );
                        continue;
                    }
                    interactive_template_ir = candidate;
                    frozen_spins_applied_scene_revision = Some(source_scene_revision);
                    interactive_runtime_host.replace_base_problem(interactive_template_ir.clone());
                    live_workspace.push_log(
                        "system",
                        format!(
                            "Applied Frozen Spins scene revision {source_scene_revision} at the next runtime-plan boundary for command {}",
                            command.command_id
                        ),
                    );
                }
                Ok(None) => {}
                Err(error) => {
                    eprintln!(
                        "[fullmag] frozen spins runtime plan binding rejected for command '{}': {}",
                        command.command_id, error
                    );
                    live_workspace.push_log(
                        "error",
                        format!(
                            "Frozen Spins runtime-plan binding rejected for command {}: {}",
                            command.command_id, error
                        ),
                    );
                    continue;
                }
            }

            let Some(mut stage) =
                (match build_interactive_command_stage(&interactive_template_ir, &command) {
                    Ok(stage) => stage,
                    Err(error) => {
                        eprintln!(
                            "[fullmag] interactive command '{}' rejected: {}",
                            command.kind, error
                        );
                        live_workspace.push_log(
                            "error",
                            format!(
                                "Interactive command '{}' is not supported here: {}",
                                command.kind, error
                            ),
                        );
                        continue;
                    }
                })
            else {
                break;
            };
            if let Err(error) =
                resolve_active_antenna_stage_outputs(&mut stage.ir, &published_antenna_outputs)
            {
                live_workspace.push_command_log(
                    &command.command_id,
                    "error",
                    format!(
                        "Interactive command '{}' failed antenna stage-output resolution: {}",
                        command.kind, error
                    ),
                );
                continue;
            }
            if active_sequence.is_none()
                && matches!(command.kind.as_str(), "run" | "relax" | "solve")
            {
                active_sequence = Some(ActiveSequenceState::single_current());
            }

            apply_current_fem_overrides(
                &mut stage.ir,
                current_fem_mesh_override.as_ref(),
                current_fem_hmax_override,
                current_adaptive_runtime_state.as_ref(),
            );
            attach_region_realization_revisions(&mut stage.ir, command.precondition.as_ref());
            if let Some(previous_final_magnetization) = continuation_magnetization.as_deref() {
                ensure_frequency_response_relaxed_continuation_is_qualified(
                    &stage,
                    continuation_completion.as_ref(),
                )?;
                if let Some(source) = continuation_source.as_ref() {
                    match resample_continuation_if_cross_backend(
                        previous_final_magnetization,
                        source,
                        &stage.ir,
                    ) {
                        Ok(Some(transfer)) => {
                            eprintln!(
                                "[fullmag] {} state transfer: {}/{} {} interpolated, {} fallback/outside",
                                transfer.label,
                                transfer.n_located,
                                transfer.n_total,
                                transfer.unit_label,
                                transfer.n_outside
                            );
                            live_workspace.push_log(
                                "info",
                                format!(
                                    "State transfer ({}): {}/{} {} interpolated from FEM mesh",
                                    transfer.label,
                                    transfer.n_located,
                                    transfer.n_total,
                                    transfer.unit_label
                                ),
                            );
                            apply_continuation_initial_state(&mut stage.ir, &transfer.values)?;
                        }
                        Ok(None) => {
                            apply_continuation_initial_state(
                                &mut stage.ir,
                                previous_final_magnetization,
                            )?;
                        }
                        Err(e) => {
                            eprintln!("[fullmag] magnetization state transfer failed: {}", e);
                            bail!("magnetization state transfer failed: {}", e);
                        }
                    }
                } else {
                    apply_continuation_initial_state(&mut stage.ir, previous_final_magnetization)?;
                }
            }
            let stage_start_time_s = time_offset;
            stage.ir.problem_meta.runtime_metadata.insert(
                "stage_start_time_s".to_string(),
                serde_json::json!(stage_start_time_s),
            );
            if let Some(origin_time_s) = resumed_waveform_origin_time_s {
                stage.ir.problem_meta.runtime_metadata.insert(
                    "stage_waveform_origin_time_s".to_string(),
                    serde_json::json!(origin_time_s),
                );
            } else {
                stage
                    .ir
                    .problem_meta
                    .runtime_metadata
                    .remove("stage_waveform_origin_time_s");
            }
            validate_ir(&stage.ir)?;
            current_plan_summary = stage
                .ir
                .plan_for(args.backend.map(BackendTarget::from))
                .map_err(join_errors)?;
            let mut execution_plan =
                fullmag_plan::plan(&stage.ir).map_err(|error| anyhow!(error.to_string()))?;
            ctx.runtime_selection = session_runtime_selection_for_problem(
                &stage.ir,
                Some(&execution_plan),
                field_every_n,
                backend_target_name(stage.ir.backend_policy.requested_backend),
                execution_mode_name(stage.ir.validation_profile.execution_mode),
                execution_precision_name(stage.ir.backend_policy.execution_precision),
            );
            attach_solved_antenna_drive_bases(&stage.ir, &mut execution_plan, &artifact_dir)?;
            let stage_time_frame = fullmag_runner::stage_step_time_frame(&stage.ir, &execution_plan)
                .map_err(|error| anyhow!(error.message))?;
            let runner_time_offset = match stage_time_frame {
                fullmag_runner::StageStepTimeFrame::StageLocal => stage_start_time_s,
                fullmag_runner::StageStepTimeFrame::Absolute => 0.0,
            };
            if !antenna_external_lead_inspection::is_carrier(&execution_plan) {
                emit_initial_state_warnings(Some(&live_workspace), &stage.ir, &execution_plan)?;
            }
            let use_live_callback = matches!(
                &execution_plan.backend_plan,
                BackendPlanIR::Fdm(_)
                    | BackendPlanIR::FdmMultilayer(_)
                    | BackendPlanIR::Fem(_)
                    | BackendPlanIR::FemEigen(_)
                    | BackendPlanIR::FemFrequencyResponse(_)
            );
            let current_stage_artifact_dir = stage_artifact_dir(
                &workspace_dir,
                &artifact_dir,
                interactive_stage_index,
                interactive_stage_index + 2,
                &stage.entrypoint_kind,
            );
            let current_stage_id = format!("stage-{interactive_stage_index:03}");
            // Preserve the actual orchestration identity at the producer
            // boundary.  Interactive FEM eigen sweeps use the same exact
            // relaxation sidecar contract as scripted stages; never let the
            // runner infer these values from the consuming modal stage.
            stage.ir.problem_meta.runtime_metadata.insert(
                "producer_run_id".to_string(),
                serde_json::Value::String(run_id.clone()),
            );
            stage.ir.problem_meta.runtime_metadata.insert(
                "producer_stage_id".to_string(),
                serde_json::Value::String(current_stage_id.clone()),
            );
            stage.ir.problem_meta.runtime_metadata.insert(
                "producer_stage_kind".to_string(),
                serde_json::Value::String(stage.entrypoint_kind.clone()),
            );
            fs::create_dir_all(&current_stage_artifact_dir).with_context(|| {
                format!(
                    "failed to create interactive stage artifact dir {}",
                    current_stage_artifact_dir.display()
                )
            })?;
            if output_paths.is_sibling_zarr_bundle {
                initialize_zarr_group(
                    &current_stage_artifact_dir,
                    serde_json::json!({
                        "fullmag_role": "interactive_stage_artifacts",
                        "stage_index": interactive_stage_index,
                        "entrypoint_kind": stage.entrypoint_kind,
                    }),
                )?;
                initialize_zarr_group(
                    &current_stage_artifact_dir.join("fields"),
                    serde_json::json!({"fullmag_role": "sampled_fields"}),
                )?;
            }
            write_sampling_resolution_stage_record(
                &current_stage_artifact_dir,
                stage
                    .ir
                    .problem_meta
                    .runtime_metadata
                    .get("sampling_resolution"),
            )?;
            let running_at_unix_ms = unix_time_millis()?;
            let application_boundary = CommandApplicationBoundary::new(
                &run_id,
                &command.command_id,
                step_offset,
                time_offset,
            );
            let stage_fem_mesh_asset = fullmag_runner::StageFemMeshAsset::build_from_backend_plan(
                &execution_plan.backend_plan,
            );
            let stage_initial_update = offset_step_update(
                initial_step_update(
                    &execution_plan.backend_plan,
                    stage_fem_mesh_asset
                        .as_ref()
                        .map(|asset| asset.identity.generation_id().to_string()),
                ),
                step_offset,
                time_offset,
                false,
            );
            if let Some(sequence) = active_sequence.as_mut() {
                sequence.mark_current_started(
                    &command.command_id,
                    running_at_unix_ms,
                    Some(current_stage_artifact_dir.display().to_string()),
                    Some(&application_boundary),
                );
                sequence.mark_current_fem_mesh_identity(stage_fem_mesh_asset.as_ref());
            }
            live_workspace.push_log(
                "system",
                format!("Executing interactive command: {}", command_kind_label),
            );
            interactive_runtime_host.mark_running();
            if let Some(sequence) = active_sequence.as_mut() {
                sequence.mark_current_materialized_kind(&stage.entrypoint_kind);
            }
            live_workspace.update(|state| {
                state.session = ctx.build_session(
                    "running",
                    &plan_summary_json(&current_plan_summary),
                    running_at_unix_ms,
                );
                state.run = ctx.build_run("running", &aggregated_steps);
                state.metadata = Some(current_live_metadata(&stage.ir, &execution_plan, "running"));
                state.mesh_workspace = current_mesh_workspace(
                    &stage.ir,
                    &execution_plan,
                    "running",
                    current_mesh_quality.as_ref(),
                    &current_mesh_history,
                );
                state.stage_execution = active_sequence.as_ref().map(|sequence| {
                    sequence.stage_execution(Some(&stage.entrypoint_kind), "running")
                });
                state.live_state = live_state_manifest_from_update(stage_initial_update.clone());
                clear_cached_preview_fields(state);
                if antenna_external_lead_inspection::is_carrier(&execution_plan) {
                    antenna_external_lead_inspection::clear_magnetic_snapshot(state);
                }
            });

            let torque_mode = torque_display_mode(&stage.ir);
            let interactive_progress_label = format!("interactive {}", stage.entrypoint_kind);
            let mut stage_heartbeat = use_live_callback.then(|| {
                StageProgressHeartbeat::spawn(
                    stage_initial_update,
                    live_workspace.clone(),
                    run_id.clone(),
                    session_id.clone(),
                    artifact_dir.clone(),
                    interactive_progress_label.clone(),
                    format!("interactive command {}", command_kind_label),
                    torque_mode,
                )
            });
            let stage_result = match if use_live_callback {
                let running_control = interactive_runtime_host.control();
                if supports_dynamic_live_preview(&execution_plan.backend_plan) {
                    let mut live_cadence = LiveProgressCadence::default();
                    let display_selection = || running_control.display_selection_snapshot();
                    let interrupt_signal = running_control.running_interrupt_signal();
                    let mut on_step = |update| {
                        let callback_start = solver_profile_callback_start(&live_workspace);
                        let _callback_nvtx = nvtx_range::Range::new(b"fem.host.callback\0");
                        let mut adjusted =
                            offset_step_update(update, step_offset, runner_time_offset, false);
                        if let Some(heartbeat) = stage_heartbeat.as_mut() {
                            heartbeat.record(&mut adjusted);
                        }
                        drain_solver_profile_commands(&running_control, &live_workspace);
                        let profile_record = begin_solver_profile_step_with_orchestration(
                            &live_workspace,
                            &mut adjusted.stats,
                            callback_start,
                        );
                        if is_control_checkpoint_only(&adjusted) {
                            if live_cadence.should_publish(&adjusted) {
                                adjusted = publish_live_step_update(
                                    &live_workspace,
                                    &run_id,
                                    &session_id,
                                    &artifact_dir,
                                    adjusted,
                                    false,
                                );
                            }
                            if let Some(action) = running_control.process_running_control() {
                                finish_solver_profile_step_with_orchestration(
                                    &live_workspace,
                                    callback_start,
                                    profile_record,
                                );
                                return action;
                            }
                            finish_solver_profile_step_with_orchestration(
                                &live_workspace,
                                callback_start,
                                profile_record,
                            );
                            return fullmag_runner::StepAction::Continue;
                        }
                        if live_cadence.should_log(&adjusted) {
                            eprintln!(
                                "{}",
                                format_stage_progress_line(
                                    &interactive_progress_label,
                                    &adjusted.stats,
                                    torque_mode,
                                    None,
                                    adjusted.hysteresis_field_m_t,
                                )
                            );
                        }

                        if live_cadence.should_publish(&adjusted) {
                            adjusted = publish_live_step_update(
                                &live_workspace,
                                &run_id,
                                &session_id,
                                &artifact_dir,
                                adjusted,
                                true,
                            );
                        }

                        if let Some(action) = running_control.process_running_control() {
                            finish_solver_profile_step_with_orchestration(
                                &live_workspace,
                                callback_start,
                                profile_record,
                            );
                            return action;
                        }
                        finish_solver_profile_step_with_orchestration(
                            &live_workspace,
                            callback_start,
                            profile_record,
                        );
                        fullmag_runner::StepAction::Continue
                    };

                    let hysteresis_study = matches!(&stage.ir.study, StudyIR::Hysteresis { .. });
                    if !hysteresis_study
                        && matches!(
                            &execution_plan.backend_plan,
                            BackendPlanIR::Fdm(_) | BackendPlanIR::Fem(_)
                        )
                    {
                        if let Err(error) = interactive_runtime_host.ensure_runtime_for_problem(
                            &stage.ir,
                            &execution_plan,
                            stage_fem_mesh_asset.as_ref(),
                            field_every_n,
                            continuation_magnetization.as_deref(),
                            frozen_spins_explicit_reactivation,
                            &live_workspace,
                        ) {
                            eprintln!("interactive preview runtime warning: {}", error);
                            live_workspace.push_log(
                                "warn",
                                format!(
                                    "Falling back to one-shot interactive runner path: {}",
                                    error
                                ),
                            );
                        }
                    }

                    if hysteresis_study {
                        fullmag_runner::run_planned_problem_with_live_preview_interruptible_with_initial_snapshot_and_hysteresis_stage_id_and_fem_mesh_identity(
                            &stage.ir,
                            &execution_plan,
                            stage_fem_mesh_asset.as_ref().map(|asset| &asset.identity),
                            stage.until_seconds,
                            &current_stage_artifact_dir,
                            field_every_n,
                            &display_selection,
                            Some(interrupt_signal.as_ref()),
                            !preview_3d_disabled,
                            Some(&current_stage_id),
                            &mut on_step,
                        )
                    } else if let Some(runtime) = interactive_runtime_host.runtime_mut() {
                        fullmag_runner::run_planned_problem_with_interactive_runtime_live_preview_interruptible(
                            runtime,
                            &stage.ir,
                            &execution_plan,
                            stage.until_seconds,
                            &current_stage_artifact_dir,
                            field_every_n,
                            &display_selection,
                            Some(interrupt_signal.as_ref()),
                            &mut on_step,
                        )
                    } else {
                        fullmag_runner::run_planned_problem_with_live_preview_interruptible_with_initial_snapshot_and_hysteresis_stage_id_and_fem_mesh_identity(
                            &stage.ir,
                            &execution_plan,
                            stage_fem_mesh_asset.as_ref().map(|asset| &asset.identity),
                            stage.until_seconds,
                            &current_stage_artifact_dir,
                            field_every_n,
                            &display_selection,
                            Some(interrupt_signal.as_ref()),
                            !preview_3d_disabled,
                            Some(&current_stage_id),
                            &mut on_step,
                        )
                    }
                } else {
                    let mut live_cadence = LiveProgressCadence::default();
                    fullmag_runner::run_planned_problem_with_callback_and_hysteresis_stage_id(
                        &stage.ir,
                        &execution_plan,
                        stage.until_seconds,
                        &current_stage_artifact_dir,
                        field_every_n,
                        Some(&current_stage_id),
                        |update| {
                            let callback_start = solver_profile_callback_start(&live_workspace);
                            let _callback_nvtx = nvtx_range::Range::new(b"fem.host.callback\0");
                            let mut adjusted =
                                offset_step_update(update, step_offset, runner_time_offset, false);
                            if let Some(heartbeat) = stage_heartbeat.as_mut() {
                                heartbeat.record(&mut adjusted);
                            }
                            drain_solver_profile_commands(&running_control, &live_workspace);
                            let profile_record = begin_solver_profile_step_with_orchestration(
                                &live_workspace,
                                &mut adjusted.stats,
                                callback_start,
                            );
                            if live_cadence.should_log(&adjusted) {
                                eprintln!(
                                    "{}",
                                    format_stage_progress_line(
                                        &interactive_progress_label,
                                        &adjusted.stats,
                                        torque_mode,
                                        None,
                                        adjusted.hysteresis_field_m_t,
                                    )
                                );
                            }

                            if live_cadence.should_publish(&adjusted) {
                                adjusted = publish_live_step_update(
                                    &live_workspace,
                                    &run_id,
                                    &session_id,
                                    &artifact_dir,
                                    adjusted,
                                    true,
                                );
                            }

                            if let Some(action) = running_control.process_running_control() {
                                finish_solver_profile_step_with_orchestration(
                                    &live_workspace,
                                    callback_start,
                                    profile_record,
                                );
                                return action;
                            }
                            finish_solver_profile_step_with_orchestration(
                                &live_workspace,
                                callback_start,
                                profile_record,
                            );
                            fullmag_runner::StepAction::Continue
                        },
                    )
                }
            } else {
                fullmag_runner::run_planned_problem_with_hysteresis_stage_id(
                    &stage.ir,
                    &execution_plan,
                    stage.until_seconds,
                    &current_stage_artifact_dir,
                    Some(&current_stage_id),
                )
            } {
                Ok(result) => result,
                Err(error) => {
                    if let Some(mut heartbeat) = stage_heartbeat.take() {
                        heartbeat.finish();
                    }
                    let failed_ready_at_unix_ms = unix_time_millis().unwrap_or(awaiting_at_unix_ms);
                    let backend_error_completion = fullmag_ir::StageCompletionIR {
                        status: "failed".to_string(),
                        converged: false,
                        reason: Some(fullmag_ir::StageStopReason::BackendError),
                        metric: None,
                        metric_name: None,
                        metric_value: None,
                        threshold: None,
                    };
                    let failed_stage_execution = active_sequence.as_mut().map(|sequence| {
                        sequence.mark_current(
                            "failed",
                            Some(&backend_error_completion),
                            Some(failed_ready_at_unix_ms),
                            Some(current_stage_artifact_dir.display().to_string()),
                        );
                        sequence.stage_execution(Some(&stage.entrypoint_kind), "failed")
                    });
                    if let Some(sequence) = active_sequence.as_ref() {
                        let stage_message = format!(
                            "Stage {}/{} ({}) failed",
                            sequence.current_stage_1based,
                            sequence.total_stages(),
                            stage.entrypoint_kind
                        );
                        eprintln!("[fullmag] {}", stage_message);
                        live_workspace.push_log("error", stage_message);
                    }
                    if active_sequence.is_some() {
                        live_workspace
                            .push_log("warning", "Execution sequence halted on failed stage");
                        active_sequence = None;
                    }
                    live_workspace.update(|state| {
                        state.session = ctx.build_session(
                            "awaiting_command",
                            &plan_summary_json(&current_plan_summary),
                            failed_ready_at_unix_ms,
                        );
                        state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                        set_live_state_status(
                            &mut state.live_state,
                            "awaiting_command",
                            Some(false),
                        );
                        state.stage_execution = failed_stage_execution.clone();
                    });
                    interactive_runtime_host.enter_awaiting_command(
                        continuation_magnetization.clone(),
                        &live_workspace,
                    );
                    eprintln!("interactive command failed: {}", error);
                    paused_stage = None;
                    live_workspace.push_log(
                        "error",
                        format!(
                            "Interactive command {} failed: {}",
                            command_kind_label, error
                        ),
                    );
                    continue;
                }
            };
            if let Some(mut heartbeat) = stage_heartbeat.take() {
                heartbeat.finish();
            }
            if let Some(mut heartbeat) = stage_heartbeat.take() {
                heartbeat.finish();
            }
            force_record_solver_profile_finalization(
                &live_workspace,
                &stage_result,
                step_offset,
                runner_time_offset,
            );

            // Handle mid-stage pause (first-class RunStatus::Paused from runner)
            if stage_result.status == fullmag_runner::RunStatus::Paused {
                let offset_steps = offset_step_stats(&stage_result.steps, step_offset, runner_time_offset);
                if let Some(last) = offset_steps.last() {
                    step_offset = last.step;
                    time_offset = last.time;
                }
                let last_offset_step = offset_steps.last().cloned();
                aggregated_steps.extend(offset_steps);
                continuation_magnetization = Some(stage_result.final_magnetization.clone());
                continuation_completion = stage_result.completion.clone();
                continuation_source = Some(continuation_source_from_backend_plan(
                    &execution_plan.backend_plan,
                ));
                interactive_stage_index += 1;

                let paused_at_unix_ms = unix_time_millis()?;
                let elapsed_seconds = elapsed_stage_seconds(
                    &stage_result,
                    stage_start_time_s,
                    stage_time_frame,
                )?;
                let resumable_command =
                    build_resumable_interactive_command(&command, &stage_result, elapsed_seconds);
                if let Some(resumable_command) = resumable_command {
                    let pause_checkpoint = match capture_pause_checkpoint(
                        &run_id,
                        last_offset_step.as_ref(),
                        &stage_result.final_magnetization,
                        &execution_plan.backend_plan,
                        &current_stage_artifact_dir,
                    ) {
                        Ok(capture) => Some(capture),
                        Err(error) => {
                            live_workspace.push_log(
                                "error",
                                format!("Failed to capture pause checkpoint: {error}"),
                            );
                            None
                        }
                    };
                    if let Some(sequence) = active_sequence.as_mut() {
                        sequence.mark_current(
                            "paused",
                            None,
                            None,
                            Some(current_stage_artifact_dir.display().to_string()),
                        );
                        if let Some(capture) = pause_checkpoint.as_ref() {
                            sequence.mark_current_checkpoint_preserved(
                                &capture.checkpoint.checkpoint_id,
                                Some(capture.checkpoint.common_state_ref.clone()),
                            );
                        }
                    }
                    paused_stage = Some(PausedInteractiveStage {
                        command: resumable_command,
                        source_kind: command.kind.clone(),
                        checkpoint_ref: pause_checkpoint
                            .as_ref()
                            .map(|capture| capture.checkpoint.checkpoint_id.clone()),
                        checkpoint_resume_error: checkpoint_resume_error_for_backend_plan(
                            &execution_plan.backend_plan,
                        ),
                        waveform_origin_time_s: stage
                            .ir
                            .problem_meta
                            .runtime_metadata
                            .get("stage_waveform_origin_time_s")
                            .and_then(serde_json::Value::as_f64)
                            .unwrap_or(stage_start_time_s),
                        requires_exact_waveform_clock: has_time_dependent_stage_drive(&stage.ir),
                    });
                    live_workspace.update(|state| {
                        state.session = ctx.build_session(
                            "paused",
                            &plan_summary_json(&current_plan_summary),
                            paused_at_unix_ms,
                        );
                        state.run = ctx.build_run("paused", &aggregated_steps);
                        set_live_state_status(&mut state.live_state, "paused", Some(false));
                        state.stage_execution = active_sequence.as_ref().map(|sequence| {
                            sequence.stage_execution(Some(&stage.entrypoint_kind), "paused")
                        });
                    });
                    interactive_runtime_host
                        .enter_paused(continuation_magnetization.clone(), &live_workspace);
                    eprintln!("interactive command {} paused by user", command_kind_label);
                    live_workspace.push_log(
                        "system",
                        format!(
                            "Interactive command {} paused — {}",
                            command_kind_label,
                            if paused_stage
                                .as_ref()
                                .is_some_and(|paused| paused.checkpoint_resume_error.is_some())
                            {
                                "exact checkpoint resume is unsupported; stop this stage to start a new run"
                            } else {
                                "use resume to continue"
                            },
                        ),
                    );
                } else {
                    paused_stage = None;
                    live_workspace.update(|state| {
                        state.session = ctx.build_session(
                            "awaiting_command",
                            &plan_summary_json(&current_plan_summary),
                            paused_at_unix_ms,
                        );
                        state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                        set_live_state_status(
                            &mut state.live_state,
                            "awaiting_command",
                            Some(false),
                        );
                    });
                    interactive_runtime_host.enter_awaiting_command(
                        continuation_magnetization.clone(),
                        &live_workspace,
                    );
                    live_workspace.push_log(
                        "system",
                        format!(
                            "Interactive command {} reached its target before pause completed",
                            command_kind_label,
                        ),
                    );
                }
                continue;
            }

            // Handle mid-stage cancellation (break/close — still uses take_running_interrupt)
            if stage_result.status == fullmag_runner::RunStatus::Cancelled {
                let offset_steps = offset_step_stats(&stage_result.steps, step_offset, runner_time_offset);
                if let Some(last) = offset_steps.last() {
                    step_offset = last.step;
                    time_offset = last.time;
                }
                aggregated_steps.extend(offset_steps);
                continuation_magnetization = Some(stage_result.final_magnetization.clone());
                continuation_completion = stage_result.completion.clone();
                continuation_source = Some(continuation_source_from_backend_plan(
                    &execution_plan.backend_plan,
                ));
                interactive_stage_index += 1;

                let cancelled_at_unix_ms = unix_time_millis()?;
                match interactive_runtime_host
                    .take_running_interrupt()
                    .unwrap_or(crate::interactive_runtime_host::InteractiveStageInterrupt::Break)
                {
                    crate::interactive_runtime_host::InteractiveStageInterrupt::Pause => {
                        // Legacy fallback: if the runner somehow returned Cancelled
                        // but the host recorded a Pause interrupt, treat it as pause.
                        // This path should not occur after the Phase 4 wiring.
                        paused_stage = None;
                        live_workspace.update(|state| {
                            state.session = ctx.build_session(
                                "awaiting_command",
                                &plan_summary_json(&current_plan_summary),
                                cancelled_at_unix_ms,
                            );
                            state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                            set_live_state_status(
                                &mut state.live_state,
                                "awaiting_command",
                                Some(false),
                            );
                        });
                        interactive_runtime_host.enter_awaiting_command(
                            continuation_magnetization.clone(),
                            &live_workspace,
                        );
                        live_workspace.push_log(
                            "warning",
                            "Unexpected pause-as-cancel fallback — entered awaiting_command",
                        );
                        continue;
                    }
                    crate::interactive_runtime_host::InteractiveStageInterrupt::Break => {
                        paused_stage = None;
                        if let Some(sequence) = active_sequence.as_mut() {
                            let cancelled_completion = user_cancelled_stage_completion("cancelled");
                            sequence.mark_current(
                                "cancelled",
                                Some(&cancelled_completion),
                                Some(cancelled_at_unix_ms),
                                Some(current_stage_artifact_dir.display().to_string()),
                            );
                        }
                        // Abort active sequence if any
                        let aborted_sequence = active_sequence.take();
                        if aborted_sequence.is_some() {
                            live_workspace
                                .push_log("warning", "Execution sequence aborted by user");
                        }
                        live_workspace.update(|state| {
                            state.session = ctx.build_session(
                                "awaiting_command",
                                &plan_summary_json(&current_plan_summary),
                                cancelled_at_unix_ms,
                            );
                            state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                            set_live_state_status(
                                &mut state.live_state,
                                "awaiting_command",
                                Some(false),
                            );
                            state.stage_execution = aborted_sequence.as_ref().map(|sequence| {
                                sequence.completed_stage_execution("awaiting_command")
                            });
                        });
                        interactive_runtime_host.enter_awaiting_command(
                            continuation_magnetization.clone(),
                            &live_workspace,
                        );
                        eprintln!(
                            "interactive command {} cancelled by user",
                            command_kind_label
                        );
                        live_workspace.push_log(
                            "warning",
                            format!(
                                "Interactive command {} cancelled — partial results preserved",
                                command_kind_label,
                            ),
                        );
                        continue;
                    }
                    crate::interactive_runtime_host::InteractiveStageInterrupt::Close => {
                        live_workspace.push_log(
                            "system",
                            format!(
                                "Interactive command {} interrupted — closing workspace",
                                command_kind_label,
                            ),
                        );
                        break;
                    }
                    crate::interactive_runtime_host::InteractiveStageInterrupt::Skip => {
                        // Skip = interrupt current stage but continue sequence
                        if let Some(sequence) = active_sequence.as_ref() {
                            let stage_message = format!(
                                "Stage {}/{} skipped",
                                sequence.current_stage_1based,
                                sequence.total_stages()
                            );
                            eprintln!("[fullmag] {}", stage_message);
                            live_workspace.push_log("warning", stage_message);
                        }
                        live_workspace.push_log(
                            "system",
                            format!(
                                "Interactive command {} skipped — advancing to next stage",
                                command_kind_label,
                            ),
                        );
                        if let Some(sequence) = active_sequence.as_mut() {
                            let skipped_completion = user_cancelled_stage_completion("skipped");
                            sequence.mark_current(
                                "skipped",
                                Some(&skipped_completion),
                                Some(cancelled_at_unix_ms),
                                Some(current_stage_artifact_dir.display().to_string()),
                            );
                            sequence.advance();
                            if !sequence.remaining_stages.is_empty() {
                                let next_stage = sequence.remaining_stages.remove(0);
                                let stage_label = next_stage.label().to_string();
                                live_workspace.push_log(
                                    "system",
                                    format!(
                                        "Sequence: advancing to stage {}/{} ({})",
                                        sequence.current_stage_1based,
                                        sequence.total_stages(),
                                        stage_label
                                    ),
                                );
                                let synthetic_cmd = sequence_stage_to_session_command(
                                    &next_stage,
                                    &format!("seq_{}", session_id),
                                    sequence.current_stage_1based,
                                );
                                live_workspace.update(|state| {
                                    state.stage_execution = Some(
                                        sequence.stage_execution(Some(&stage_label), "running"),
                                    );
                                });
                                interactive_runtime_host.push_command_front(synthetic_cmd);
                                paused_stage = None;
                                continue;
                            } else {
                                live_workspace.push_log(
                                    "success",
                                    format!(
                                        "Execution sequence completed ({} stages)",
                                        sequence.total_stages()
                                    ),
                                );
                                live_workspace.update(|state| {
                                    state.stage_execution = Some(
                                        sequence.completed_stage_execution("awaiting_command"),
                                    );
                                });
                                active_sequence = None;
                            }
                        }
                        // No more stages or no sequence → awaiting_command
                        paused_stage = None;
                        live_workspace.update(|state| {
                            state.session = ctx.build_session(
                                "awaiting_command",
                                &plan_summary_json(&current_plan_summary),
                                cancelled_at_unix_ms,
                            );
                            state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                            set_live_state_status(
                                &mut state.live_state,
                                "awaiting_command",
                                Some(false),
                            );
                        });
                        interactive_runtime_host.enter_awaiting_command(
                            continuation_magnetization.clone(),
                            &live_workspace,
                        );
                        continue;
                    }
                }
            }

            if !use_live_callback {
                let frozen_spins_checkpoint =
                    frozen_spins_checkpoint_from_stage_artifacts(&current_stage_artifact_dir)?;
                let grid = match &execution_plan.backend_plan {
                    BackendPlanIR::Fdm(fdm) => {
                        [fdm.grid.cells[0], fdm.grid.cells[1], fdm.grid.cells[2]]
                    }
                    BackendPlanIR::FdmMultilayer(fdm) => [
                        fdm.common_cells[0],
                        fdm.common_cells[1],
                        fdm.common_cells[2],
                    ],
                    BackendPlanIR::AntennaRetainedCurrentFieldInspection(_) | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)
                    | BackendPlanIR::AntennaFieldOnly(_)
                    | BackendPlanIR::AntennaExternalLeadInspection(_)
                    | BackendPlanIR::Fem(_)
                    | BackendPlanIR::FemEigen(_)
                    | BackendPlanIR::FemFrequencyResponse(_) => [0, 0, 0],
                };
                let fem_mesh_generation_id = stage_fem_mesh_asset
                    .as_ref()
                    .map(|asset| asset.identity.generation_id().to_string());
                let mut live_cadence = LiveProgressCadence::default();
                for (index, stats) in stage_result.steps.iter().enumerate() {
                    let is_final_step = index + 1 == stage_result.steps.len();
                    let update = fullmag_runner::StepUpdate {
                        coupled_checkpoint: is_final_step
                            .then(|| frozen_spins_checkpoint.clone())
                            .flatten(),
                        stats: offset_step_stats(
                            std::slice::from_ref(stats),
                            step_offset,
                            runner_time_offset,
                        )
                        .into_iter()
                        .next()
                        .expect("single step should offset"),
                        grid,
                        fem_mesh_generation_id: fem_mesh_generation_id.clone(),
                        magnetization: None,
                        preview_field: None,
                        cached_preview_fields: None,
                        hysteresis_field_m_t: None,
                        hysteresis_point_index: None,
                        hysteresis_settle_step_index: None,
                        hysteresis_settle_step_kind: None,
                        hysteresis_settle_step_method: None,
                        scalar_row_due: true,
                        terminal_field_snapshot: false,
                        finished: false,
                        magnetization_carrier: None,
                    };
                    if live_cadence.should_publish(&update) {
                        live_workspace.update(|state| {
                            state.session.status = "running".to_string();
                            state.run = running_run_manifest_from_update(
                                &run_id,
                                &session_id,
                                &artifact_dir,
                                &update,
                            );
                            state.live_state = live_state_manifest_from_update(update.clone());
                            set_latest_scalar_row_if_due(state, &update);
                        });
                    }
                }
            }

            if let Some(final_update) = final_stage_step_update(
                &execution_plan.backend_plan,
                stage_fem_mesh_asset
                    .as_ref()
                    .map(|asset| asset.identity.generation_id().to_string()),
                &stage_result.steps,
                &stage_result.final_magnetization,
                step_offset,
                runner_time_offset,
                false,
                frozen_spins_checkpoint_from_stage_artifacts(&current_stage_artifact_dir)?,
            ) {
                live_workspace.update(|state| {
                    state.session.status = if final_update.finished {
                        "completed".to_string()
                    } else {
                        "running".to_string()
                    };
                    state.run = running_run_manifest_from_update(
                        &run_id,
                        &session_id,
                        &artifact_dir,
                        &final_update,
                    );
                    state.live_state = live_state_manifest_from_update(final_update.clone());
                    set_latest_scalar_row_for_terminal_update(state, &final_update);
                });
                live_workspace.force_publish_latest_scalar_row();
            }

            let offset_steps = offset_step_stats(&stage_result.steps, step_offset, runner_time_offset);
            let completed_step = offset_steps.last().map(|last| last.step);
            if let Some(last) = offset_steps.last() {
                step_offset = last.step;
                time_offset = last.time;
            }
            aggregated_steps.extend(offset_steps);
            continuation_completion = stage_result.completion.clone();
            continuation_magnetization = Some(stage_result.final_magnetization);
            continuation_source = Some(continuation_source_from_backend_plan(
                &execution_plan.backend_plan,
            ));
            interactive_stage_index += 1;

            let ready_at_unix_ms = unix_time_millis()?;
            live_workspace.push_log(
                "success",
                format!("Interactive command {} completed", command_kind_label),
            );
            if let Some(sequence) = active_sequence.as_ref() {
                let stage_message = format!(
                    "Stage {}/{} ({}) completed",
                    sequence.current_stage_1based,
                    sequence.total_stages(),
                    stage.entrypoint_kind
                );
                {
                    let final_step = stage_result.steps.last();
                    eprintln!(
                        "[fullmag] {} — samples={}  final_step={}  t={:.4e}  max_torque[T]={:.4e}  stop: {}",
                        stage_message,
                        stage_result.steps.len(),
                        final_step.map(|s| s.step).unwrap_or(0),
                        final_step.map(|s| s.time).unwrap_or(0.0),
                        final_step.map(|s| s.max_torque_T).unwrap_or(0.0),
                        format_stop_reason(stage_result.completion.as_ref()),
                    );
                }
                live_workspace.push_log("success", stage_message);
            }

            // ── Sequence continuation: if there are more stages, advance ──
            if let Some(sequence) = active_sequence.as_mut() {
                let current_stage_index = sequence.current_stage_index();
                if let Some(record) = sequence.stages.get_mut(current_stage_index) {
                    record.completed_step = completed_step;
                }
                sequence.mark_current(
                    "completed",
                    stage_result.completion.as_ref(),
                    Some(ready_at_unix_ms),
                    Some(current_stage_artifact_dir.display().to_string()),
                );
                sequence.advance();
                if !sequence.remaining_stages.is_empty() {
                    let next_stage = sequence.remaining_stages.remove(0);
                    let stage_label = next_stage.label().to_string();
                    live_workspace.push_log(
                        "system",
                        format!(
                            "Sequence: advancing to stage {}/{} ({})",
                            sequence.current_stage_1based,
                            sequence.total_stages(),
                            stage_label
                        ),
                    );
                    // Push synthetic command to internal queue front so the loop picks it up next
                    let synthetic_cmd = sequence_stage_to_session_command(
                        &next_stage,
                        &format!("seq_{}", session_id),
                        sequence.current_stage_1based,
                    );
                    live_workspace.update(|state| {
                        state.stage_execution =
                            Some(sequence.stage_execution(Some(&stage_label), "running"));
                    });
                    interactive_runtime_host.push_command_front(synthetic_cmd);
                    // Keep running status — don't enter_awaiting_command
                    paused_stage = None;
                    continue;
                } else {
                    live_workspace.push_log(
                        "success",
                        format!(
                            "Execution sequence completed ({} stages)",
                            sequence.total_stages()
                        ),
                    );
                    live_workspace.update(|state| {
                        state.stage_execution =
                            Some(sequence.completed_stage_execution("awaiting_command"));
                    });
                    active_sequence = None;
                }
            }

            live_workspace.update(|state| {
                state.session = ctx.build_session(
                    "awaiting_command",
                    &plan_summary_json(&current_plan_summary),
                    ready_at_unix_ms,
                );
                state.run = ctx.build_run("awaiting_command", &aggregated_steps);
                set_live_state_status(&mut state.live_state, "awaiting_command", Some(false));
                if state.stage_execution.is_none() {
                    state.stage_execution = None;
                }
            });
            interactive_runtime_host
                .enter_awaiting_command(continuation_magnetization.clone(), &live_workspace);
            paused_stage = None;
        }
        final_session_runtime = ctx.runtime_selection.clone();
        interactive_runtime_host.mark_closed(&live_workspace);
        if display_selection_handle.owner_session_lost() {
            return Ok(());
        }
        live_workspace.update(|state| {
            set_live_state_status(&mut state.live_state, "completed", Some(true));
        });
    }

    let finished_at_unix_ms = unix_time_millis()?;
    let final_status = if scripted_cancelled && !interactive_requested {
        fullmag_runner::RunStatus::Cancelled
    } else {
        fullmag_runner::RunStatus::Completed
    };

    // If this was a FEM eigen run, read the spectrum artifact from disk so we
    // can include the mode count and lowest frequency in the summary printout.
    let (eigen_mode_count, eigen_lowest_frequency_hz) = {
        let spectrum_path = artifact_dir.join("eigen").join("spectrum.json");
        if let Ok(bytes) = std::fs::read(&spectrum_path) {
            if let Ok(value) = serde_json::from_slice::<serde_json::Value>(&bytes) {
                let modes = value["modes"].as_array();
                let count = modes.map(|m| m.len());
                let lowest = modes
                    .and_then(|m| m.first())
                    .and_then(|m| m.get("frequency_hz"))
                    .and_then(|f| f.as_f64());
                (count, lowest)
            } else {
                (None, None)
            }
        } else {
            (None, None)
        }
    };

    let summary = ScriptRunSummary {
        session_id: session_id.clone(),
        run_id: run_id.clone(),
        script_path: script_path.display().to_string(),
        problem_name: final_problem_name.clone(),
        status: format!("{:?}", final_status).to_lowercase(),
        backend: backend_target_name(final_requested_backend).to_string(),
        mode: execution_mode_name(final_execution_mode).to_string(),
        precision: execution_precision_name(final_precision).to_string(),
        requested_execution: RequestedExecutionProvenance {
            backend: final_session_runtime.requested_backend.clone(),
            device: requested_execution_device(&final_session_runtime),
            precision: final_session_runtime.requested_precision.clone(),
            mode: final_session_runtime.requested_mode.clone(),
            fallback_policy: if final_session_runtime.requested_mode == "strict" {
                "forbidden".to_string()
            } else {
                "allowed".to_string()
            },
        },
        total_steps: aggregated_steps
            .last()
            .map(|step| step.step as usize)
            .unwrap_or(0),
        final_time: aggregated_steps.last().map(|step| step.time),
        final_e_ex: aggregated_steps.last().map(|step| step.e_ex),
        final_e_demag: aggregated_steps.last().map(|step| step.e_demag),
        final_e_ext: aggregated_steps.last().map(|step| step.e_ext),
        final_e_ani: aggregated_steps.last().map(|step| step.e_ani),
        final_e_dmi: aggregated_steps.last().map(|step| step.e_dmi),
        final_e_rotated_dmi: aggregated_steps.last().map(|step| step.e_rotated_dmi),
        final_e_total: aggregated_steps.last().map(|step| step.e_total),
        wall_time_ns: aggregated_steps.last().map(|step| step.wall_time_ns),
        backend_create_wall_time_ns: aggregated_steps
            .iter()
            .map(|step| step.backend_create_wall_time_ns)
            .find(|duration| *duration > 0),
        first_accepted_step_demag_solver_apply_wall_time_ns: aggregated_steps
            .iter()
            .map(|step| step.demag_solver_apply_wall_time_ns)
            .find(|duration| *duration > 0),
        exchange_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.exchange_wall_time_ns),
        demag_wall_time_ns: aggregated_steps.last().map(|step| step.demag_wall_time_ns),
        demag_assemble_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_assemble_wall_time_ns),
        demag_solve_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_solve_wall_time_ns),
        demag_solver_setup_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_solver_setup_wall_time_ns),
        demag_solver_apply_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_solver_apply_wall_time_ns),
        demag_hypre_wait_in_enqueue_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_hypre_wait_in_enqueue_wall_time_ns),
        demag_hypre_host_api_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_hypre_host_api_wall_time_ns),
        demag_hypre_device_elapsed_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_hypre_device_elapsed_time_ns),
        demag_hypre_wait_out_enqueue_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_hypre_wait_out_enqueue_wall_time_ns),
        demag_hypre_event_wait_count: aggregated_steps
            .last()
            .map(|step| step.demag_hypre_event_wait_count),
        demag_hypre_timed_solve_count: aggregated_steps
            .last()
            .map(|step| step.demag_hypre_timed_solve_count),
        demag_recover_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_recover_wall_time_ns),
        demag_energy_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.demag_energy_wall_time_ns),
        rhs_wall_time_ns: aggregated_steps.last().map(|step| step.rhs_wall_time_ns),
        extra_energy_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.extra_energy_wall_time_ns),
        snapshot_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.snapshot_wall_time_ns),
        relaxation_preconditioner_wall_time_ns: aggregated_steps
            .last()
            .map(|step| step.relaxation_preconditioner_wall_time_ns),
        relaxation_preconditioner_cache_hits: aggregated_steps
            .last()
            .map(|step| step.relaxation_preconditioner_cache_hits),
        relaxation_preconditioner_cache_misses: aggregated_steps
            .last()
            .map(|step| step.relaxation_preconditioner_cache_misses),
        rhs_evals: aggregated_steps.last().map(|step| step.rhs_evals),
        total_rhs_evals: cumulative_rhs_evals(&aggregated_steps),
        demag_solves: aggregated_steps.last().map(|step| step.demag_solves),
        eigen_mode_count,
        eigen_lowest_frequency_hz,
        artifact_dir: artifact_dir.display().to_string(),
        workspace_dir: workspace_dir.display().to_string(),
    };

    live_workspace.update(|state| {
        if let Some(execution) = state.stage_execution.as_mut() {
            *execution = stage_execution_from_records(
                &execution.stages,
                None,
                None,
                &summary.status,
            );
        }
        state.session = build_session_manifest(
            &session_id,
            &run_id,
            &summary.status,
            interactive_requested,
            &script_path,
            &summary.problem_name,
            &final_session_runtime,
            &artifact_dir,
            started_at_unix_ms,
            finished_at_unix_ms,
            plan_summary_json(&current_plan_summary),
        );
        state.run = run_manifest_from_steps(
            &run_id,
            &session_id,
            &summary.status,
            &artifact_dir,
            &aggregated_steps,
        );
        state.latest_scalar_row = aggregated_steps.last().map(|step| CurrentLiveScalarRow {
            kind: step.kind.clone(),
            solver_progress: step.solver_progress.clone(),
            step: step.step,
            time: step.time,
            solver_dt: step.dt,
            error_estimate: step.error_estimate,
            max_error: step.max_error,
            dt_suggested: step.dt_suggested,
            rejected_attempts: step.rejected_attempts,
            pseudo_time_s: step.pseudo_time_s,
            active_runtime_s: Some(step.wall_time_ns as f64 * 1.0e-9),
            mx: step.mx,
            my: step.my,
            mz: step.mz,
            e_ex: step.e_ex,
            e_demag: step.e_demag,
            e_ext: step.e_ext,
            e_ani: step.e_ani,
            e_dmi: step.e_dmi,
            e_rotated_dmi: step.e_rotated_dmi,
            e_total: step.e_total,
            max_dm_dt: step.max_dm_dt,
            max_h_eff: step.max_h_eff,
            max_h_demag: step.max_h_demag,
            max_torque_Apm: step.max_torque_Apm,
            max_torque_T: step.max_torque_T,
            per_object_scalars: step.per_object_scalars.clone(),
            table_expressions: Vec::new(),
        });
        set_live_state_status(&mut state.live_state, &summary.status, Some(true));
    });
    let summary_level = if matches!(final_status, fullmag_runner::RunStatus::Cancelled) {
        "warning"
    } else {
        "success"
    };
    let summary_verb = if matches!(final_status, fullmag_runner::RunStatus::Cancelled) {
        "cancelled"
    } else {
        "completed"
    };
    live_workspace.push_log(
        summary_level,
        format!(
            "Workspace {summary_verb} — {} steps, final time {}",
            summary.total_steps,
            summary
                .final_time
                .map(|time| format!("{:.4e} s", time))
                .unwrap_or_else(|| "0 s".to_string())
        ),
    );

    // The asynchronous publisher must acknowledge this terminal snapshot
    // before the CLI exits. A failed publication preserves numerical results
    // and private scratch instead of reporting successful live completion.
    live_workspace
        .publish_terminal_and_wait(std::time::Duration::from_secs(30))
        .context("terminal live publication failed; scientific artifacts are retained")?;

    if args.json {
        println!("{}", serde_json::to_string_pretty(&summary)?);
    } else {
        print_script_summary(&summary);
    }
    storage_lease.finish(true)?;

    Ok(())
}

pub(crate) fn prepare_live_workspace_for_ui(
    script: &Path,
    backend: Option<BackendArg>,
    mode: Option<ModeArg>,
    precision: Option<PrecisionArg>,
) -> Result<(String, LocalLiveWorkspace)> {
    let started_at_unix_ms = unix_time_millis()?;
    let script_path = script
        .canonicalize()
        .with_context(|| format!("failed to resolve script path {}", script.display()))?;
    check_script_syntax_via_python(&script_path)?;

    let requested_backend_name = backend
        .map(|value| value.to_possible_value().unwrap().get_name().to_string())
        .unwrap_or_else(|| "auto".to_string());
    let requested_mode_name = mode
        .map(|value| value.to_possible_value().unwrap().get_name().to_string())
        .unwrap_or_else(|| "strict".to_string());
    let requested_precision_name = precision
        .map(|value| value.to_possible_value().unwrap().get_name().to_string())
        .unwrap_or_else(|| "double".to_string());

    let session_id = format!("session-{}-{}", started_at_unix_ms, std::process::id());
    let run_id = format!("run-{}", session_id);
    let workspace_dir = runtime_state_root(&repo_root())
        .join("local-live")
        .join("history")
        .join(&session_id);
    let artifact_dir = workspace_dir.join("artifacts");

    fs::create_dir_all(&workspace_dir)
        .with_context(|| format!("failed to create workspace dir {}", workspace_dir.display()))?;

    let current_live_publisher = CurrentLivePublisher::spawn(&session_id);
    let bootstrapping_runtime = requested_runtime_selection(
        &requested_backend_name,
        false,
        "auto",
        &requested_precision_name,
        &requested_mode_name,
        None,
    );
    let bootstrapping_session_manifest = build_session_manifest(
        &session_id,
        &run_id,
        "bootstrapping",
        true,
        &script_path,
        script_path
            .file_stem()
            .and_then(|stem| stem.to_str())
            .unwrap_or("fullmag_script"),
        &bootstrapping_runtime,
        &artifact_dir,
        started_at_unix_ms,
        started_at_unix_ms,
        serde_json::json!({ "status": "bootstrapping", "launch_mode": "ui" }),
    );
    let bootstrapping_run_manifest =
        build_run_manifest(&run_id, &session_id, "bootstrapping", &artifact_dir);
    let bootstrap_live_state_manifest = bootstrap_live_state("bootstrapping");
    let simulation_preparation = new_simulation_preparation(
        format!("preparation-{session_id}"),
        u64::try_from(started_at_unix_ms).context("preparation start timestamp exceeds u64")?,
    )?;
    let live_workspace = LocalLiveWorkspace::new(
        LocalLiveWorkspaceState {
            session: bootstrapping_session_manifest,
            run: bootstrapping_run_manifest,
            live_state: bootstrap_live_state_manifest,
            fem_mesh: None,
            metadata: None,
            mesh_workspace: None,
            stage_execution: None,
            simulation_preparation: Some(simulation_preparation),
            latest_scalar_row: None,
            latest_fields: CurrentLiveLatestFields::default(),
            replace_latest_fields: false,
            field_generation: None,
            preview_fields: CurrentLivePreviewFieldCache::default(),
            pending_preview_fields: CurrentLivePreviewFieldCache::default(),
            superseded_pending_preview_fields: Vec::new(),
            clear_preview_cache: false,
            preview_cache_revision: 0,
            engine_log: Vec::new(),
            solver_profile: fullmag_runner::SolverProfileState::default(),
            published_fem_mesh_generation_id: None,
        },
        current_live_publisher,
    );
    live_workspace.push_log(
        "system",
        format!(
            "Workspace prepared for {}",
            script_path
                .file_name()
                .and_then(|file_name| file_name.to_str())
                .unwrap_or("script.py")
        ),
    );
    live_workspace.push_log(
        "info",
        format!(
            "Requested backend: {} · mode: {} · precision: {}",
            requested_backend_name, requested_mode_name, requested_precision_name
        ),
    );
    mark_ui_shell_preparation_ready(&live_workspace)?;
    Ok((session_id, live_workspace))
}

#[cfg(test)]
mod tests {
    use super::{
        accepted_relax_handoff_for_eigen_stage, accepted_relax_handoff_from_completed_stage,
        adaptive_remesh_backend_legality_reason, adaptive_remesh_legality_reason,
        apply_current_fem_overrides, apply_initial_magnetization_state_override,
        apply_live_step_update_to_workspace_state, apply_remeshed_problem_snapshot_to_stages,
        apply_scene_discretization_patch, apply_stage_heartbeat_progress,
        update_antenna_live_stage_progress,
        apply_terminal_live_step_update_to_workspace_state,
        attach_initial_magnetization_state_override_metadata,
        attach_region_realization_revisions,
        attach_stage_fem_mesh_identity,
        antenna_stage_output_catalog_path,
        classify_wait_for_solve_command,
        continuation_source_from_backend_plan,
        cumulative_rhs_evals,
        current_fdm_mesh_workspace,
        default_domain_region_markers,
        deferred_mesh_failure_stage,
        attach_solved_antenna_drive_bases,
        attach_scripted_stage_solver_steps,
        discard_active_paused_stage_execution,
        ensure_frequency_response_relaxed_continuation_is_qualified, execute_synthetic_stage,
        fail_owned_preparation_stage, fem_gpu_memory_preflight_message,
        fem_interactive_dense_ram_estimate, fem_live_mesh_payload_and_initial_magnetization,
        fem_mesh_payload_from_backend_plan, format_stage_heartbeat_message,
        format_stage_progress_line, has_heavy_live_payload,
        initial_live_state_manifest_from_backend_plan, initial_magnetization_state_override,
        initial_step_update, interactive_session_should_stay_alive,
        mark_live_stage_execution_failed, mark_ui_shell_preparation_ready,
        mesh_build_pipeline_status_json,
        mesh_source_scene_revision, offset_step_update, own_preparation_boundary_failure,
        plan_materialized_stage_snapshot, prepare_remesh_stage_transaction,
        preserve_terminal_stage_history, project_script_export_failure,
        relative_artifact_ref,
        replace_continuation_after_synthetic_stage,
        requested_execution_device_for_overrides,
        publish_scripted_stages_awaiting_command,
        resolve_adaptive_convergence_metric, resolve_preview_field_every_n,
        resolve_rayon_cpu_threads, resolved_shared_domain_object_region_markers,
        run_active_preparation_operation, run_owned_preparation_stage,
        run_script_preparation_preflight, run_solver_initialization,
        run_solver_initialization_safety_check, scripted_stage_execution_state,
        scripted_stage_execution_state_with_completion, set_latest_scalar_row_if_due,
        shared_domain_object_region_mesh_specs, stage_allows_sampled_continuation_initial_state,
        step_update_has_frequency_response_progress, step_update_has_parallel_execution_progress,
        parallel_execution_telemetry_from_progress, user_cancelled_stage_completion,
        validate_periodic_remesh_candidate, wait_for_failed_preparation_close,
        wait_for_solve_prompt, wait_for_solve_should_block, wait_for_solve_supported,
        write_antenna_stage_output_catalog_ready, write_antenna_stage_output_catalog_terminal,
        write_antenna_stage_output_catalog_with_hook,
        write_sampling_resolution_stage_record, ActiveSequenceState, CommandApplicationBoundary,
        ContinuationStageSource,
        LiveProgressCadence, LoadedInitialMagnetizationState, RuntimeCommandPrecondition,
        SceneProblemPatch, StageProgressHeartbeat, WaitForSolveCommandAction,
        FEM_FREQUENCY_RESPONSE_PROGRESS_KEY, LIVE_PROGRESS_PUBLISH_INTERVAL,
    };
    use crate::live_workspace::{CurrentLivePublisher, LocalLiveWorkspace};
    use crate::simulation_preparation::{
        PreparationStageId, PreparationStageStatus, PreparationStatus, SimulationPreparationState,
    };
    use crate::types::PythonProgressEvent;
    use std::path::Path;

    #[test]
    fn elapsed_stage_time_uses_the_reported_clock_frame() {
        let mut result = fullmag_runner::RunResult {
            status: fullmag_runner::RunStatus::Completed,
            steps: vec![fullmag_runner::StepStats {
                time: 10.4,
                ..fullmag_runner::StepStats::default()
            }],
            final_magnetization: Vec::new(),
            completion: None,
        };
        assert!((super::elapsed_stage_seconds(
            &result,
            10.0,
            fullmag_runner::StageStepTimeFrame::Absolute,
        )
        .unwrap()
            - 0.4)
            .abs()
            < 1e-12);
        result.steps[0].time = 0.4;
        assert!((super::elapsed_stage_seconds(
            &result,
            10.0,
            fullmag_runner::StageStepTimeFrame::StageLocal,
        )
        .unwrap()
            - 0.4)
            .abs()
            < 1e-12);
    }

    fn set_fem_eigen_progress(
        stats: &mut fullmag_runner::StepStats,
        metrics: std::collections::HashMap<String, f64>,
    ) {
        stats.kind = fullmag_quantities::StepDataKind::SolverProgress;
        stats.solver_progress = Some(fullmag_quantities::SolverProgress::FemEigen { metrics });
    }

    #[test]
    fn fdm_override_wins_over_fem_override_in_summary_device() {
        let runtime =
            super::requested_runtime_selection("fdm", true, "cpu", "double", "strict", None);
        assert_eq!(
            requested_execution_device_for_overrides(&runtime, Some("cpu"), Some("gpu")),
            "gpu"
        );
    }

    #[test]
    fn auto_rayon_threads_are_bounded_before_native_mesh_resolution() {
        assert_eq!(
            resolve_rayon_cpu_threads(40, Some("auto"), None, None),
            (16, true)
        );
        assert_eq!(
            resolve_rayon_cpu_threads(8, Some("auto"), None, None),
            (8, true)
        );
        assert_eq!(
            resolve_rayon_cpu_threads(40, Some("auto"), None, Some("12")),
            (12, true)
        );
        assert_eq!(
            resolve_rayon_cpu_threads(40, Some("auto"), Some("4"), None),
            (16, true)
        );
        assert_eq!(
            resolve_rayon_cpu_threads(40, None, Some("12"), None),
            (12, false)
        );
    }

    #[test]
    fn adaptive_followup_callback_and_heartbeat_clone_sites_stay_profiled() {
        let source = include_str!("orchestrator.rs");
        let production = source
            .split("#[cfg(test)]")
            .next()
            .expect("production orchestrator source");
        let adaptive = source
            .split("fn maybe_execute_adaptive_relaxation_followup_passes")
            .nth(1)
            .and_then(|tail| tail.split("pub(crate) fn build_session_manifest").next())
            .expect("adaptive follow-up implementation");
        assert!(adaptive.contains("solver_profile_callback_start(live_workspace)"));
        assert!(adaptive.contains("live_workspace.update_profiled"));
        assert!(adaptive.contains("begin_solver_profile_step_with_orchestration"));
        assert!(adaptive.contains("finish_solver_profile_step_with_orchestration"));
        assert_eq!(
            production.matches("stage_initial_update.clone()").count(),
            0
        );
        assert_eq!(
            production.matches("snapshot.latest_update.clone()").count(),
            0
        );
        assert!(production.contains("StageHeartbeatProgress::new(&initial_update)"));
        assert!(!adaptive.contains("offset_step_update(\n                &initial_step_update"));
        assert!(adaptive
            .contains("StageProgressHeartbeat::spawn(\n            adaptive_initial_update"));
    }

    #[test]
    fn continuation_source_classification_is_centralized_and_fail_closed() {
        let source = include_str!("orchestrator.rs");
        let production = source
            .rsplit_once("\n#[cfg(test)]\nmod tests {")
            .map(|(production, _)| production)
            .expect("production source");
        assert_eq!(
            production
                .matches("continuation_source_from_backend_plan(")
                .count(),
            5,
            "every stage-result continuation source must use the canonical classifier"
        );
        assert!(
            !production.contains("_ => ContinuationSource::Fdm"),
            "wildcard source classification aliases FEM eigen/frequency and unsupported backends to FDM"
        );
    }

    #[test]
    fn fem_equilibrium_certificates_are_only_required_for_native_fem_relaxation() {
        let source = include_str!("orchestrator.rs");
        let production = source
            .rsplit_once("\n#[cfg(test)]\nmod tests {")
            .map(|(production, _)| production)
            .expect("production source");
        let certified_block = production
            .split("let next_continuation_certified_fields =")
            .nth(1)
            .and_then(|tail| {
                tail.split("let next_continuation_recomputed_certificate =")
                    .next()
            })
            .expect("certified FEM equilibrium field handoff block");
        let recomputed_block = production
            .split("let next_continuation_recomputed_certificate =")
            .nth(1)
            .and_then(|tail| tail.split("let next_continuation_stage_source =").next())
            .expect("recomputed FEM linearization certificate handoff block");
        for block in [certified_block, recomputed_block] {
            assert!(
                block.contains("execution_plan.backend_plan")
                    && block.contains("BackendPlanIR::Fem(_)")
            );
        }
    }

    #[test]
    fn adaptive_shared_domain_followup_uses_a_fail_closed_legality_gate() {
        let source = include_str!("orchestrator.rs");
        let production = source
            .rsplit_once("\n#[cfg(test)]\nmod tests {")
            .map(|(production, _)| production)
            .expect("production source");
        assert!(
            production.contains(
                "adaptive_remesh_backend_legality_reason(&execution_plan.backend_plan)"
            ),
            "adaptive follow-up must reject SharedDomainMeshWithAir before the generic remesher can overlap the magnetic body and airbox"
        );
        assert_eq!(
            adaptive_remesh_backend_legality_reason(&tiny_shared_domain_fem_plan()),
            Some("adaptive_shared_domain_remesh_requires_dedicated_remesher")
        );
    }

    #[test]
    fn task4_step_update_offset_and_heartbeat_are_lightweight_by_contract() {
        let step_utils = include_str!("step_utils.rs");
        assert!(
            step_utils.contains(
                "pub(crate) fn offset_step_update(\n    mut update: fullmag_runner::StepUpdate,"
            ),
            "offset_step_update must consume StepUpdate so callback payload ownership can move"
        );
        assert!(
            !step_utils.contains("let mut adjusted = update.clone();"),
            "offsetting must not deep-clone the step payload"
        );

        let heartbeat = include_str!("stage_heartbeat.rs");
        let heartbeat_fields = heartbeat
            .split("struct StageHeartbeatProgress {")
            .nth(1)
            .and_then(|source| source.split_once('}'))
            .map(|(fields, _)| fields)
            .expect("StageHeartbeatProgress fields");
        assert!(heartbeat_fields.contains("stats: fullmag_runner::StepStats"));
        for forbidden in [
            "StepUpdate",
            "magnetization",
            "preview_field",
            "cached_preview_fields",
            "FemMeshPayload",
        ] {
            assert!(
                !heartbeat_fields.contains(forbidden),
                "heartbeat state must not retain heavy field `{forbidden}`"
            );
        }
    }

    #[test]
    fn remesh_paths_keep_one_authoritative_stage_mesh_asset() {
        let source = include_str!("orchestrator.rs");
        let production = source;
        assert!(production.contains("initial_fem_mesh_asset = Some(remeshed_mesh_asset)"));
        let adaptive = production
            .split("fn maybe_execute_adaptive_relaxation_followup_passes")
            .nth(1)
            .and_then(|tail| tail.split("pub(crate) fn build_session_manifest").next())
            .expect("adaptive follow-up implementation");
        assert!(adaptive.contains("stage_fem_mesh_asset: &mut Option<"));
        assert!(adaptive.contains("run_planned_problem_with_callback_and_fem_mesh_identity"));
        assert!(!adaptive.contains("run_problem_with_callback("));
        assert!(adaptive.contains("*stage_fem_mesh_asset = Some(remeshed_mesh_asset)"));
    }

    #[test]
    fn mesh_source_scene_revision_reads_geometry_realization_contract() {
        assert_eq!(
            mesh_source_scene_revision(&serde_json::json!({
                "geometry_realization": {"source_scene_revision": 46}
            })),
            Some(46)
        );
        assert_eq!(
            mesh_source_scene_revision(&serde_json::json!({
                "source_scene_revision": 47
            })),
            Some(47)
        );
        assert_eq!(mesh_source_scene_revision(&serde_json::json!({})), None);
    }

    #[test]
    fn adaptive_mesh_rejects_eigenfrequency_without_an_eigen_estimator() {
        assert_eq!(
            resolve_adaptive_convergence_metric("energy_delta"),
            Ok("energy_delta")
        );
        assert_eq!(
            resolve_adaptive_convergence_metric("eigenfrequency_delta"),
            Err("unsupported_mesh_adaptivity_criterion")
        );
        assert_eq!(
            resolve_adaptive_convergence_metric("not-a-criterion"),
            Err("unsupported_mesh_adaptivity_criterion")
        );
    }

    #[test]
    fn attach_region_realization_revisions_persists_complete_consumed_tuple() {
        let mut problem = ProblemIR::bootstrap_example();
        attach_region_realization_revisions(
            &mut problem,
            Some(&RuntimeCommandPrecondition {
                region_topology_revision: Some(11),
                region_membership_revision: Some(12),
                region_coefficients_revision: Some(13),
                region_initial_state_revision: Some(14),
                ..RuntimeCommandPrecondition::default()
            }),
        );

        assert_eq!(
            problem.problem_meta.runtime_metadata["region_realization_revisions"],
            serde_json::json!({
                "complete": true,
                "topology": 11,
                "membership": 12,
                "coefficients": 13,
                "initial_state": 14,
            })
        );
    }

    #[test]
    fn attach_region_realization_revisions_marks_partial_tuple_incomplete() {
        let mut problem = ProblemIR::bootstrap_example();
        attach_region_realization_revisions(
            &mut problem,
            Some(&RuntimeCommandPrecondition {
                region_membership_revision: Some(12),
                ..RuntimeCommandPrecondition::default()
            }),
        );

        assert_eq!(
            problem.problem_meta.runtime_metadata["region_realization_revisions"],
            serde_json::json!({
                "complete": false,
                "topology": null,
                "membership": 12,
                "coefficients": null,
                "initial_state": null,
            })
        );
    }

    #[test]
    fn cumulative_rhs_evals_sums_all_step_records() {
        let steps = vec![
            fullmag_runner::StepStats {
                rhs_evals: 3,
                ..fullmag_runner::StepStats::default()
            },
            fullmag_runner::StepStats {
                rhs_evals: 9,
                ..fullmag_runner::StepStats::default()
            },
        ];

        assert_eq!(cumulative_rhs_evals(&steps), 12);
    }

    #[test]
    fn solved_antenna_drive_attachment_rejects_invalid_projection_before_fdm_materialization() {
        let mut problem = ProblemIR::bootstrap_example();
        problem.solved_antenna_drives = vec![serde_json::from_value(serde_json::json!({
            "id": "drive_1",
            "name": "Drive 1",
            "projection_ref": "projection_1",
            "port_mode_id": "port_1",
            "peak_current_a": 1.0,
            "waveform": {"kind": "constant"},
            "time_origin": "absolute",
            "activation": {"kind": "all_time_evolution"}
        }))
        .expect("fixture drive should deserialize")];
        let mut plan = fullmag_ir::ExecutionPlanIR {
            common: fullmag_ir::CommonPlanMeta {
                ir_version: "test".into(),
                requested_backend: fullmag_ir::BackendTarget::Fdm,
                resolved_backend: fullmag_ir::BackendTarget::Fdm,
                execution_mode: fullmag_ir::ExecutionMode::Strict,
                material_field_plans: Vec::new(),
            },
            backend_plan: BackendPlanIR::Fdm(fullmag_ir::FdmPlanIR::default()),
            output_plan: fullmag_ir::OutputPlanIR {
                outputs: Vec::new(),
            },
            provenance: fullmag_ir::ProvenancePlanIR::default(),
        };

        if let BackendPlanIR::Fdm(fdm) = &mut plan.backend_plan {
            fdm.time_stage.study_kind = fullmag_ir::StudyKindIR::TimeEvolution;
        }

        let error = attach_solved_antenna_drive_bases(
            &problem,
            &mut plan,
            Path::new("antenna-test-artifacts"),
        )
        .expect_err("FDM solved-antenna attachment must fail closed on invalid projection");
        assert!(error.to_string().contains(
            "solved_antenna_drives[0] has an invalid projection, port mode, or peak current"
        ));
    }

    #[test]
    fn solved_antenna_attachment_skips_inactive_future_stage_without_asset() {
        let mut problem = ProblemIR::bootstrap_example();
        let (dynamics, sampling) = match &problem.study {
            StudyIR::TimeEvolution { dynamics, sampling } => (dynamics.clone(), sampling.clone()),
            _ => unreachable!("bootstrap fixture is a time-evolution study"),
        };
        problem.study = StudyIR::Relaxation {
            algorithm: fullmag_ir::RelaxationAlgorithmIR::LlgOverdamped,
            dynamics: Some(dynamics),
            stop: fullmag_ir::RelaxStopIR {
                torque_tolerance_apm: Some(1.0),
                energy_tolerance_j: None,
                max_steps: Some(10),
                max_relaxation_time_s: None,
            },
            sampling,
        };
        problem
            .problem_meta
            .runtime_metadata
            .insert("active_stage_id".into(), serde_json::json!("relax"));
        problem.solved_antenna_drives = vec![serde_json::from_value(serde_json::json!({
            "id": "drive_1",
            "name": "Drive 1",
            "projection_ref": "projection_1",
            "port_mode_id": "port_1",
            "peak_current_a": 1.0,
            "waveform": {"kind": "sinusoidal", "frequency_hz": 1e9, "phase_rad": 0.0, "offset": 0.0},
            "time_origin": "stage_local",
            "activation": {"kind": "stage_ids", "stage_ids": ["run"]}
        }))
        .expect("fixture drive should deserialize")];
        let mut plan = fullmag_ir::ExecutionPlanIR {
            common: fullmag_ir::CommonPlanMeta {
                ir_version: "test".into(),
                requested_backend: fullmag_ir::BackendTarget::Fdm,
                resolved_backend: fullmag_ir::BackendTarget::Fdm,
                execution_mode: fullmag_ir::ExecutionMode::Strict,
                material_field_plans: Vec::new(),
            },
            backend_plan: BackendPlanIR::Fdm(fullmag_ir::FdmPlanIR::default()),
            output_plan: fullmag_ir::OutputPlanIR {
                outputs: Vec::new(),
            },
            provenance: fullmag_ir::ProvenancePlanIR::default(),
        };

        if let BackendPlanIR::Fdm(fdm) = &mut plan.backend_plan {
            fdm.time_stage.study_kind = fullmag_ir::StudyKindIR::Relaxation;
            fdm.time_stage.active_stage_id = Some("relax".into());
            fdm.solved_antenna_drive_bases
                .push(fullmag_ir::ResolvedSolvedAntennaDriveBasisIR {
                    drive: problem.solved_antenna_drives[0].clone(),
                    solution_id: "previous_solution".into(),
                    source_object_id: "previous_antenna".into(),
                    field_xyz_apm_per_a: vec![[1.0, 0.0, 0.0]],
                    projection_signature: "previous_projection".into(),
                });
        }

        attach_solved_antenna_drive_bases(&problem, &mut plan, Path::new("antenna-test-artifacts"))
            .expect("an inactive future drive must not load its unpublished asset");
        assert!(matches!(
            plan.backend_plan,
            BackendPlanIR::Fdm(ref fdm) if fdm.solved_antenna_drive_bases.is_empty()
        ));
        if let BackendPlanIR::Fdm(fdm) = &mut plan.backend_plan {
            fdm.time_stage.study_kind = fullmag_ir::StudyKindIR::TimeEvolution;
        }
        let error = attach_solved_antenna_drive_bases(
            &problem,
            &mut plan,
            Path::new("antenna-test-artifacts"),
        )
        .expect_err("a mismatched stage must not silently omit the antenna drive");
        assert!(error.to_string().contains("activation context differs"));
    }

    #[test]
    fn symbolic_antenna_reference_resolves_only_from_a_prior_matching_port() {
        let mut problem = ProblemIR::bootstrap_example();
        problem.antenna_target_projections = vec![serde_json::from_value(serde_json::json!({
            "id": "projection_1",
            "solution": {"kind": "stage_output", "stage_id": "solve_1", "output_id": "basis"},
            "target": {"kind": "global"},
            "output_id": "projected"
        }))
        .unwrap()];
        problem.solved_antenna_drives = vec![serde_json::from_value(serde_json::json!({
            "id": "drive_1",
            "name": "Drive 1",
            "projection_ref": "projection_1",
            "port_mode_id": "port_1",
            "peak_current_a": 1.0,
            "waveform": {"kind": "constant"},
            "time_origin": "absolute",
            "activation": {"kind": "all_time_evolution"}
        }))
        .unwrap()];
        let reference = fullmag_ir::AntennaFieldSolutionRefIR {
            stage_id: "solve_1".into(),
            output_id: "basis".into(),
            asset_id: "asset-1".into(),
            content_digest: "sha256:valid".into(),
        };
        let mut wrong_port = std::collections::BTreeMap::new();
        wrong_port.insert(("solve_1".into(), "basis".into(), "port_2".into()), reference.clone());
        assert!(super::resolve_active_antenna_stage_outputs(&mut problem, &wrong_port)
            .unwrap_err()
            .to_string()
            .contains("requires prior ready stage output"));
        assert!(problem.antenna_target_projections[0].solution.published().is_none());

        let mut published = std::collections::BTreeMap::new();
        published.insert(("solve_1".into(), "basis".into(), "port_1".into()), reference.clone());
        let mut partially_resolvable = problem.clone();
        let mut second_projection = partially_resolvable.antenna_target_projections[0].clone();
        second_projection.id = "projection_2".into();
        second_projection.solution = serde_json::from_value(serde_json::json!({
            "kind": "stage_output", "stage_id": "solve_2", "output_id": "basis"
        }))
        .unwrap();
        partially_resolvable.antenna_target_projections.push(second_projection);
        let mut second_drive = partially_resolvable.solved_antenna_drives[0].clone();
        second_drive.id = "drive_2".into();
        second_drive.projection_ref = "projection_2".into();
        partially_resolvable.solved_antenna_drives.push(second_drive);
        assert!(super::resolve_active_antenna_stage_outputs(&mut partially_resolvable, &published)
            .is_err());
        assert!(partially_resolvable
            .antenna_target_projections
            .iter()
            .all(|projection| projection.solution.published().is_none()));
        super::resolve_active_antenna_stage_outputs(&mut problem, &published).unwrap();
        assert_eq!(problem.antenna_target_projections[0].solution.published(), Some(&reference));

        let mut conflicting = problem.clone();
        let mut second_drive = conflicting.solved_antenna_drives[0].clone();
        second_drive.id = "drive_2".into();
        second_drive.port_mode_id = "port_2".into();
        conflicting.solved_antenna_drives.push(second_drive);
        assert!(super::resolve_active_antenna_stage_outputs(&mut conflicting, &published)
            .unwrap_err()
            .to_string()
            .contains("different ports"));
    }

    #[test]
    fn solved_antenna_reference_respects_both_solve_relax_run_orders() {
        let mut run = ProblemIR::bootstrap_example();
        run.problem_meta.runtime_metadata.insert(
            "active_stage_id".into(),
            serde_json::json!("run"),
        );
        run.antenna_target_projections = vec![serde_json::from_value(serde_json::json!({
            "id": "projection_1",
            "solution": {"kind": "stage_output", "stage_id": "solve_1", "output_id": "basis"},
            "target": {"kind": "global"},
            "output_id": "projected"
        }))
        .unwrap()];
        run.solved_antenna_drives = vec![serde_json::from_value(serde_json::json!({
            "id": "drive_1",
            "name": "Drive 1",
            "projection_ref": "projection_1",
            "port_mode_id": "port_1",
            "peak_current_a": 1.0,
            "waveform": {"kind": "sinusoidal", "frequency_hz": 1e9, "phase_rad": 0.0, "offset": 0.0},
            "time_origin": "stage_local",
            "activation": {"kind": "all_time_evolution"}
        }))
        .unwrap()];
        let mut relax = run.clone();
        let (dynamics, sampling) = match &relax.study {
            StudyIR::TimeEvolution { dynamics, sampling } => (dynamics.clone(), sampling.clone()),
            _ => unreachable!("bootstrap fixture is a time-evolution study"),
        };
        relax.study = StudyIR::Relaxation {
            algorithm: fullmag_ir::RelaxationAlgorithmIR::LlgOverdamped,
            dynamics: Some(dynamics),
            stop: fullmag_ir::RelaxStopIR {
                torque_tolerance_apm: Some(1.0),
                energy_tolerance_j: None,
                max_steps: Some(10),
                max_relaxation_time_s: None,
            },
            sampling,
        };
        relax.problem_meta.runtime_metadata.insert(
            "active_stage_id".into(),
            serde_json::json!("relax"),
        );
        let reference = fullmag_ir::AntennaFieldSolutionRefIR {
            stage_id: "solve_1".into(),
            output_id: "basis".into(),
            asset_id: "asset-1".into(),
            content_digest: "sha256:valid".into(),
        };
        let mut published = std::collections::BTreeMap::new();
        for solve_before_relax in [true, false] {
            let mut current_relax = relax.clone();
            if solve_before_relax {
                published.insert(
                    ("solve_1".into(), "basis".into(), "port_1".into()),
                    reference.clone(),
                );
            } else {
                published.clear();
            }
            super::resolve_active_antenna_stage_outputs(&mut current_relax, &published)
                .expect("Relax must not require or consume a solved RF basis");
            assert!(current_relax.antenna_target_projections[0]
                .solution
                .published()
                .is_none());

            let mut current_run = run.clone();
            if !solve_before_relax {
                assert!(super::resolve_active_antenna_stage_outputs(&mut current_run, &published)
                    .unwrap_err()
                    .to_string()
                    .contains("requires prior ready stage output"));
                published.insert(
                    ("solve_1".into(), "basis".into(), "port_1".into()),
                    reference.clone(),
                );
            }
            super::resolve_active_antenna_stage_outputs(&mut current_run, &published)
                .expect("Run must resolve the previously published antenna basis");
            assert_eq!(
                current_run.antenna_target_projections[0].solution.published(),
                Some(&reference)
            );
        }
    }

    #[test]
    fn symbolic_antenna_spectrum_requires_a_prior_ready_output() {
        let mut problem = ProblemIR::bootstrap_example();
        problem.antenna_field_solve_stages = vec![serde_json::from_value(serde_json::json!({
            "id": "solve_1",
            "source_object_id": "antenna_1",
            "current_transport_id": "transport_1",
            "port_mode_ids": ["port_1"],
            "conservative_current_view_ref": "transport_1:rt0",
            "model": "quasistatic_conduction_biot_savart3d",
            "oersted_realization": "direct_tetra_quadrature",
            "conductor_mesh_policy": "full_3d",
            "field_sampling_domain": {"kind": "global"},
            "target_refs": [{"kind": "global"}],
            "solver_policy": "direct",
            "outputs": [{"id": "basis", "quantity": "H_ant_basis"}]
        }))
        .unwrap()];
        problem.antenna_spectrum_requests = vec![serde_json::from_value(serde_json::json!({
            "id": "source_k",
            "solution_ref": {"kind": "stage_output", "stage_id": "solve_1", "output_id": "basis"},
            "target": {"kind": "global"},
            "transform": "spatial_fft",
            "sampling_plane": {
                "origin_m": [0.0, 0.0, 0.0],
                "axis_u": [1.0, 0.0, 0.0],
                "axis_v": [0.0, 1.0, 0.0],
                "extent_u_m": 1.0,
                "extent_v_m": 1.0,
                "sample_count_u": 4,
                "sample_count_v": 4,
                "interpolation": "fem_element",
                "outside_policy": "zero"
            },
            "window": "rectangular",
            "normalization": "unitary_discrete",
            "component": "x",
            "output_id": "spectrum"
        }))
        .unwrap()];
        let reference = fullmag_ir::AntennaFieldSolutionRefIR {
            stage_id: "solve_1".into(),
            output_id: "basis".into(),
            asset_id: "asset-1".into(),
            content_digest: "sha256:valid".into(),
        };
        let missing = std::collections::BTreeMap::new();
        assert!(super::resolve_antenna_spectrum_stage_outputs(&mut problem, &missing)
            .unwrap_err()
            .to_string()
            .contains("requires prior ready stage output"));
        assert!(problem.antenna_spectrum_requests[0].solution_ref.published().is_none());
        let published = std::collections::BTreeMap::from([(
            ("solve_1".into(), "basis".into(), "port_1".into()),
            reference.clone(),
        )]);
        let mut partially_resolvable = problem.clone();
        let mut second_request = partially_resolvable.antenna_spectrum_requests[0].clone();
        second_request.id = "source_k_2".into();
        second_request.solution_ref = serde_json::from_value(serde_json::json!({
            "kind": "stage_output", "stage_id": "solve_2", "output_id": "basis"
        }))
        .unwrap();
        partially_resolvable.antenna_spectrum_requests.push(second_request);
        assert!(super::resolve_antenna_spectrum_stage_outputs(&mut partially_resolvable, &published)
            .is_err());
        assert!(partially_resolvable
            .antenna_spectrum_requests
            .iter()
            .all(|request| request.solution_ref.published().is_none()));
        super::resolve_antenna_spectrum_stage_outputs(&mut problem, &published).unwrap();
        assert_eq!(problem.antenna_spectrum_requests[0].solution_ref.published(), Some(&reference));
    }

    #[test]
    fn shared_domain_remesh_specs_bind_regions_to_current_owner_geometry() {
        let mut problem = ProblemIR::bootstrap_example();
        problem.geometry.entries = vec![GeometryEntryIR::Box {
            name: "film_geometry".to_string(),
            size: [1.0, 1.0, 1.0],
        }];
        problem.regions = vec![RegionIR {
            name: "film_region".to_string(),
            geometry: "film_geometry".to_string(),
        }];
        problem.magnets = vec![MagnetIR {
            object_id: Some("film".to_string()),
            name: "film".to_string(),
            region: "film_region".to_string(),
            material: "mat".to_string(),
            absorbing_boundary: None,
            initial_magnetization: Some(InitialMagnetizationIR::Uniform {
                value: [1.0, 0.0, 0.0],
            }),
        }];
        problem.object_regions = vec![ObjectRegionIR {
            region_id: "film:core".to_string(),
            owner_object: "film".to_string(),
            name: "core".to_string(),
            shape: RegionShapeIR::Box {
                size: [0.5, 0.5, 0.5],
                center: [0.0, 0.0, 0.0],
            },
            frame: RegionFrameIR::Object,
            enabled: true,
            priority: 0,
            mesh_policy: None,
            material_overrides: Vec::new(),
            texture_override: None,
            realization_policy: RegionRealizationPolicyIR::Conformal,
            material_transition: None,
        }];

        let specs = shared_domain_object_region_mesh_specs(&problem)
            .expect("remesh specs should resolve owner geometry");
        assert_eq!(specs.len(), 1);
        assert_eq!(specs[0]["region_id"], "film:core");
        assert_eq!(specs[0]["owner_geometry_name"], "film_geometry");
    }

    #[test]
    fn shared_domain_remesh_markers_require_exact_current_conformal_coverage() {
        let mut problem = ProblemIR::bootstrap_example();
        problem.object_regions = vec![ObjectRegionIR {
            region_id: "film:core".to_string(),
            owner_object: "film".to_string(),
            name: "core".to_string(),
            shape: RegionShapeIR::Box {
                size: [1.0, 1.0, 1.0],
                center: [0.0, 0.0, 0.0],
            },
            frame: RegionFrameIR::Object,
            enabled: true,
            priority: 0,
            mesh_policy: None,
            material_overrides: Vec::new(),
            texture_override: None,
            realization_policy: RegionRealizationPolicyIR::Conformal,
            material_transition: None,
        }];
        let valid = vec![fullmag_ir::FemDomainRegionMarkerIR {
            geometry_name: "film:core".to_string(),
            marker: 2,
        }];
        assert_eq!(
            resolved_shared_domain_object_region_markers(&problem, &valid).unwrap(),
            valid
        );
        let stale = vec![fullmag_ir::FemDomainRegionMarkerIR {
            geometry_name: "old:core".to_string(),
            marker: 2,
        }];
        assert!(resolved_shared_domain_object_region_markers(&problem, &stale).is_err());
    }

    #[test]
    fn adaptive_remesh_fails_closed_for_uncertified_conformal_regions() {
        let mut problem = ProblemIR::bootstrap_example();
        problem.object_regions = vec![ObjectRegionIR {
            region_id: "owner:core".to_string(),
            owner_object: "owner".to_string(),
            name: "core".to_string(),
            shape: RegionShapeIR::Box {
                size: [1.0, 1.0, 1.0],
                center: [0.0, 0.0, 0.0],
            },
            frame: RegionFrameIR::Object,
            enabled: true,
            priority: 0,
            mesh_policy: None,
            material_overrides: Vec::new(),
            texture_override: None,
            realization_policy: RegionRealizationPolicyIR::Conformal,
            material_transition: None,
        }];
        assert_eq!(
            adaptive_remesh_legality_reason(&problem),
            Some("adaptive_region_remesh_not_certified")
        );
    }

    #[test]
    fn periodic_remesh_rejects_candidate_without_fresh_pairs() {
        let previous = MeshIR {
            mesh_name: "previous".to_string(),
            nodes: Vec::new(),
            cells: fullmag_ir::FemConnectivityIR::from_tet4(Vec::new()),
            element_markers: Vec::new(),
            facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(Vec::new()),
            boundary_markers: Vec::new(),
            periodic_boundary_pairs: vec![fullmag_ir::MeshPeriodicBoundaryPairIR {
                pair_id: "x".to_string(),
                source_marker: None,
                destination_marker: None,
                marker_a: 1,
                marker_b: 2,
                translation: Some([1.0, 0.0, 0.0]),
                tolerance: Some(1.0e-9),
                axis_hint: Some("x".to_string()),
                orientation: None,
                pairing_policy: None,
            }],
            periodic_node_pairs: vec![fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x".to_string(),
                node_a: 0,
                node_b: 1,
            }],
            per_domain_quality: std::collections::HashMap::new(),
        };
        let candidate = MeshIR {
            mesh_name: "candidate".to_string(),
            nodes: Vec::new(),
            cells: fullmag_ir::FemConnectivityIR::from_tet4(Vec::new()),
            element_markers: Vec::new(),
            facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(Vec::new()),
            boundary_markers: Vec::new(),
            periodic_boundary_pairs: Vec::new(),
            periodic_node_pairs: Vec::new(),
            per_domain_quality: std::collections::HashMap::new(),
        };

        let error = validate_periodic_remesh_candidate(&previous, &candidate)
            .expect_err("periodic remesh must not publish a candidate without recertified pairs");
        assert!(error
            .to_string()
            .contains("periodic_remesh_requires_recertification"));
    }

    #[test]
    fn remesh_transaction_keeps_sources_unchanged_when_candidate_validation_fails() {
        let stages = vec![ResolvedScriptStage::solver(
            ProblemIR::bootstrap_example(),
            0.0,
            "test",
        )];
        let plans = Vec::new();
        let stages_before = stages.clone();
        let plans_before = plans.clone();
        let candidate = MeshIR {
            mesh_name: "candidate".to_string(),
            nodes: vec![
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 0.0, 1.0],
            ],
            cells: fullmag_ir::FemConnectivityIR::from_tet4(vec![[0, 1, 2, 3]]),
            element_markers: vec![1],
            facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(vec![[0, 1, 2]]),
            boundary_markers: vec![1],
            periodic_boundary_pairs: Vec::new(),
            periodic_node_pairs: Vec::new(),
            per_domain_quality: Default::default(),
        };

        let error = prepare_remesh_stage_transaction(
            &stages,
            &plans,
            None,
            &candidate,
            1.0,
            true,
            &[],
            &[],
            None,
            None,
            Some(42),
        )
        .expect_err("a shared-domain candidate without a domain asset must fail before commit");

        assert!(error
            .to_string()
            .contains("shared-domain remesh produced no fem_domain_mesh_asset"));
        assert_eq!(stages[0].ir, stages_before[0].ir);
        assert_eq!(plans, plans_before);

        let initial_plan =
            fullmag_plan::plan(&stages[0].ir).expect("bootstrap problem should plan");
        let prepared = prepare_remesh_stage_transaction(
            &stages,
            &[initial_plan],
            None,
            &candidate,
            1.0,
            false,
            &[],
            &[],
            None,
            None,
            Some(42),
        )
        .expect("valid candidate should prepare without publishing");
        assert_eq!(
            prepared.stages[0].ir.problem_meta.runtime_metadata["mesh_source_scene_revision"],
            serde_json::json!(42),
        );
        assert_eq!(
            prepared.stage_execution_plans[0],
            fullmag_plan::plan(&prepared.stages[0].ir)
                .expect("candidate plan must reflect the updated stage snapshot"),
        );
        assert_eq!(stages[0].ir, stages_before[0].ir);
        assert_eq!(plans, plans_before);
    }

    #[test]
    fn synthetic_sampling_configuration_can_be_preplanned_before_run_resolution() {
        let mut problem = ProblemIR::bootstrap_example();
        problem.study.sampling_mut().outputs = vec![fullmag_ir::OutputIR::FieldAuto {
            name: "m".to_string(),
            sample_period_policy: fullmag_ir::SamplingPeriodPolicyIR::AutoSincCutoff {
                nyquist_guard_factor: fullmag_ir::AUTO_SINC_NYQUIST_GUARD_FACTOR,
            },
        }];
        let stage = ResolvedScriptStage::synthetic(
            problem,
            "study_pipeline_autosave",
            ResolvedScriptStageAction::Autosave {
                enabled: true,
                quantity: Some("m".to_string()),
                output: None,
            },
        );

        let plan = plan_materialized_stage_snapshot(&stage)
            .expect("synthetic configuration must preplan without resolving Run-only sampling");

        assert!(matches!(plan.backend_plan, BackendPlanIR::Fdm(_)));
        assert!(matches!(
            stage.ir.study.sampling().outputs.as_slice(),
            [fullmag_ir::OutputIR::FieldAuto { .. }]
        ));
    }

    use crate::args::ScriptCli;
    use crate::live_workspace::bootstrap_live_state;
    use crate::types::{
        CurrentLiveLatestFields, CurrentLivePreviewFieldCache, CurrentLiveStageExecutionRecord,
        CurrentLiveStageExecutionState, ResolvedScriptStage, ResolvedScriptStageAction,
        RunManifest, SessionManifest, StageTransitionKind, StageTransitionMetadata,
        StageTransitionReason, StageTransitionUiPresentation,
    };
    use fullmag_ir::{
        BackendPlanIR, BackendPolicyIR, BackendTarget, DiscretizationHintsIR, DynamicsIR,
        EigenDampingPolicyIR, EigenOperatorConfigIR, EigenOperatorIR, EquilibriumSourceIR,
        ExchangeBoundaryCondition, ExecutionMode, ExecutionPrecision, FdmMaterialIR, FdmPlanIR,
        FemDomainMeshAssetIR, FemDomainMeshModeIR, FemObjectSegmentIR, FemPlanIR,
        FrequencyExcitationIR, FrequencyResponseNormalizationIR, FrequencySweepIR,
        GeometryAssetsIR, GeometryEntryIR, GeometryIR, GridDimensions, InitialMagnetizationIR,
        IntegratorChoice, MagnetIR, MagnetostaticBoundaryConditionIR, MaterialIR, MeshIR,
        ObjectRegionIR, ProblemIR, ProblemMeta, RegionFrameIR, RegionIR, RegionRealizationPolicyIR,
        RegionShapeIR, SamplingIR, SpinWaveBoundaryConditionIR, StudyIR, ValidationProfileIR,
    };
    use fullmag_runner::{LivePreviewField, SequenceStage, StepStats, StepUpdate};
    use std::collections::BTreeMap;
    use std::fs;
    use std::path::PathBuf;
    use std::time::Duration;
    use std::time::{Instant, SystemTime, UNIX_EPOCH};

    fn test_step_update(step: u64) -> StepUpdate {
        StepUpdate {
            coupled_checkpoint: None,
            stats: StepStats {
                step,
                ..StepStats::default()
            },
            grid: [1, 1, 1],
            fem_mesh_generation_id: None,
            magnetization: None,
            preview_field: None,
            cached_preview_fields: None,
            hysteresis_field_m_t: None,
            hysteresis_point_index: None,
            hysteresis_settle_step_index: None,
            hysteresis_settle_step_kind: None,
            hysteresis_settle_step_method: None,
            scalar_row_due: false,
            terminal_field_snapshot: false,
            finished: false,
            magnetization_carrier: None,
        }
    }

    #[test]
    fn adaptive_parallel_progress_decodes_typed_admission_telemetry() {
        let mut progress = std::collections::HashMap::new();
        progress.insert("parallel_telemetry_available".into(), 1.0);
        progress.insert("parallel_active_workers".into(), 2.0);
        progress.insert("parallel_admission_desired_workers".into(), 3.0);
        progress.insert("parallel_admission_pending_samples".into(), 5.0);
        progress.insert("parallel_admission_worker_limit".into(), 4.0);
        progress.insert("parallel_cpu_target_percent".into(), 90.0);
        progress.insert("parallel_memory_target_percent".into(), 80.0);
        progress.insert("parallel_cpu_busy_percent".into(), 62.5);
        progress.insert("parallel_cpu_available_cores".into(), 4.0);
        progress.insert("parallel_memory_reserve_bytes_lo".into(), 1_073_741_824.0);
        progress.insert("parallel_memory_reserve_bytes_hi".into(), 0.0);
        progress.insert("parallel_sampled_at_unix_ms_lo".into(), 3_350_608_227.0);
        progress.insert("parallel_sampled_at_unix_ms_hi".into(), 414.0);
        progress.insert("parallel_cpu_target_kind:soft_admission_target".into(), 1.0);
        progress.insert("parallel_admission_reason:waiting_cpu_headroom_for_probe".into(), 1.0);
        progress.insert("parallel_admission_reason:waiting_memory_headroom_for_probe".into(), 1.0);
        assert!(parallel_execution_telemetry_from_progress(&progress).is_none());
        progress.remove("parallel_admission_reason:waiting_memory_headroom_for_probe");

        let decoded = parallel_execution_telemetry_from_progress(&progress)
            .expect("complete adaptive telemetry should decode");
        assert_eq!(decoded.active_workers, 2);
        assert_eq!(decoded.admission_desired_workers, 3);
        assert_eq!(decoded.admission_worker_limit, Some(4));
        assert_eq!(decoded.memory_reserve_bytes, 1_073_741_824);
        assert_eq!(decoded.cpu_target_kind, "soft_admission_target");
        assert_eq!(decoded.admission_reason, "waiting_cpu_headroom_for_probe");
        assert_eq!(decoded.cpu_busy_percent, Some(62.5));
        assert_eq!(decoded.cpu_available_cores, Some(4.0));

        progress.remove("parallel_cpu_available_cores");
        let historical = parallel_execution_telemetry_from_progress(&progress)
            .expect("telemetry without legacy CPU capacity remains decodable");
        assert_eq!(historical.cpu_available_cores, None);
    }

    #[test]
    fn failed_stage_clears_previous_parallel_admission_sample() {
        let mut stage_execution = Some(CurrentLiveStageExecutionState {
            total_stages: 1,
            completed_stage_indexes: Vec::new(),
            stages: vec![CurrentLiveStageExecutionRecord {
                status: "running".to_string(),
                parallel_execution: Some(fullmag_runner::LiveParallelExecutionTelemetry {
                    sampled_at_unix_ms: 10,
                    active_workers: 2,
                    admission_desired_workers: 2,
                    admission_worker_limit: Some(4),
                    admission_pending_samples: 1,
                    resolved_workers: None,
                    cpu_target_percent: 90.0,
                    memory_target_percent: 80.0,
                    memory_reserve_bytes: 1_073_741_824,
                    cpu_target_kind: "soft_admission_target".to_string(),
                    cpu_busy_percent: Some(50.0),
                    allocated_cpu_cores: Some(2.0),
                    cpu_available_cores: Some(4.0),
                    memory_limit_bytes: Some(8 * 1024 * 1024 * 1024),
                    memory_available_bytes: Some(4 * 1024 * 1024 * 1024),
                    worker_peak_cpu_cores: Some(1.0),
                    worker_peak_rss_bytes: Some(512 * 1024 * 1024),
                    admission_reason: "calibrating_first_sample".to_string(),
                    terminal: false,
                }),
                ..CurrentLiveStageExecutionRecord::default()
            }],
            stage_statuses: vec!["running".to_string()],
            active_stage_index: Some(0),
            active_stage_kind: Some("eigenmodes".to_string()),
            runtime_state: "running".to_string(),
        });

        mark_live_stage_execution_failed(&mut stage_execution, 20);
        let failed = stage_execution.expect("failed stage state should remain published");
        assert_eq!(failed.runtime_state, "failed");
        assert_eq!(failed.active_stage_index, None);
        assert_eq!(failed.stages[0].status, "failed");
        assert_eq!(failed.stages[0].completed_at_unix_ms, Some(20));
        assert_eq!(failed.stages[0].parallel_execution, None);
    }

    fn test_preview_field(quantity: &str, revision: u64, z: f64) -> LivePreviewField {
        LivePreviewField {
            config_revision: revision,
            source_step: 0,
            source_time_seconds: None,
            source_revision: revision,
            materialized_at_unix_ms: 0,
            materialization_wall_time_ns: 0,
            quantity: quantity.to_string(),
            unit: "A/m".to_string(),
            spatial_kind: "mesh".to_string(),
            quantity_domain: "vector".to_string(),
            preview_grid: [1, 1, 1],
            original_grid: [1, 1, 1],
            vector_field_values: vec![0.0, 0.0, z],
            x_chosen_size: 1,
            y_chosen_size: 1,
            applied_x_chosen_size: 1,
            applied_y_chosen_size: 1,
            applied_layer_stride: 1,
            auto_downscaled: false,
            auto_downscale_message: None,
            active_mask: None,
        }
    }

    fn test_workspace_state() -> crate::live_workspace::LocalLiveWorkspaceState {
        crate::live_workspace::LocalLiveWorkspaceState {
            fem_mesh: None,
            session: SessionManifest {
                session_id: "session-test".to_string(),
                run_id: "run-test".to_string(),
                status: "bootstrapping".to_string(),
                interactive_session_requested: true,
                script_path: "examples/test.py".to_string(),
                problem_name: "test".to_string(),
                requested_backend: "fem".to_string(),
                explicit_selection: true,
                authored_requested_device: "cpu".to_string(),
                requested_device: "cpu".to_string(),
                requested_precision: "double".to_string(),
                requested_mode: "strict".to_string(),
                requested_cpu_threads: None,
                execution_mode: "strict".to_string(),
                precision: "double".to_string(),
                resolved_backend: Some("fem".to_string()),
                resolved_device: Some("cpu".to_string()),
                resolved_precision: Some("double".to_string()),
                resolved_mode: Some("strict".to_string()),
                resolved_runtime_family: None,
                resolved_engine_id: None,
                resolved_worker: None,
                resolved_cpu_threads: None,
                resolved_fallback: None,
                fem_crossover_decision: None,
                artifact_dir: "/tmp/artifacts".to_string(),
                started_at_unix_ms: 0,
                finished_at_unix_ms: 0,
                plan_summary: serde_json::json!({}),
            },
            run: RunManifest {
                run_id: "run-test".to_string(),
                session_id: "session-test".to_string(),
                status: "bootstrapping".to_string(),
                total_steps: 0,
                final_time: None,
                final_e_ex: None,
                final_e_demag: None,
                final_e_ext: None,
                final_e_ani: None,
                final_e_dmi: None,
                final_e_rotated_dmi: None,
                final_e_total: None,
                artifact_dir: "/tmp/artifacts".to_string(),
            },
            live_state: bootstrap_live_state("bootstrapping"),
            metadata: None,
            mesh_workspace: None,
            stage_execution: None,
            simulation_preparation: None,
            latest_scalar_row: None,
            latest_fields: CurrentLiveLatestFields::default(),
            replace_latest_fields: false,
            field_generation: None,
            preview_fields: CurrentLivePreviewFieldCache::default(),
            pending_preview_fields: CurrentLivePreviewFieldCache::default(),
            superseded_pending_preview_fields: Vec::new(),
            clear_preview_cache: false,
            preview_cache_revision: 0,
            engine_log: Vec::new(),
            solver_profile: fullmag_runner::SolverProfileState::default(),
            published_fem_mesh_generation_id: None,
        }
    }

    fn preparation_workspace(active_stage: PreparationStageId) -> LocalLiveWorkspace {
        let mut state = test_workspace_state();
        let mut preparation = SimulationPreparationState::new("prep-orchestration", 1_000);
        preparation
            .begin_stage(active_stage, 1_000, "Preparing simulation")
            .expect("test stage should start");
        state.simulation_preparation = Some(preparation);
        LocalLiveWorkspace::new(
            state,
            CurrentLivePublisher::spawn_with_test_sink("prep-orchestration-test", |_, _| Ok(())),
        )
    }

    fn assert_owned_preparation_failure(
        workspace: &LocalLiveWorkspace,
        stage_id: PreparationStageId,
        error_code: &str,
        safe_summary: &str,
        raw_error: &str,
    ) {
        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        assert_eq!(preparation.status, PreparationStatus::Failed);
        let failure = preparation.failure.as_ref().expect("owned failure");
        assert_eq!(failure.stage_id, stage_id);
        assert_eq!(failure.error_code, error_code);
        assert_eq!(failure.summary, safe_summary);
        assert!(preparation
            .log_tail
            .iter()
            .all(|entry| !entry.message.contains(raw_error)));
    }

    #[test]
    fn script_preflight_emits_validation_then_planning_before_domain_preparation() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let calls = std::cell::RefCell::new(Vec::new());

        run_script_preparation_preflight(
            &workspace,
            || {
                calls.borrow_mut().push("validation");
                Ok(())
            },
            || {
                calls.borrow_mut().push("planning");
                Ok(())
            },
        )
        .expect("preflight should succeed");

        assert_eq!(calls.into_inner(), vec!["validation", "planning"]);
        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        assert_eq!(
            preparation.active_stage_id,
            Some(PreparationStageId::DomainPreparation)
        );
        assert_eq!(
            preparation
                .stages
                .iter()
                .find(|stage| stage.id == PreparationStageId::Validation)
                .expect("validation stage")
                .status,
            PreparationStageStatus::Completed
        );
        assert_eq!(
            preparation
                .stages
                .iter()
                .find(|stage| stage.id == PreparationStageId::Planning)
                .expect("planning stage")
                .status,
            PreparationStageStatus::Completed
        );
    }

    #[test]
    fn validation_failure_is_owned_before_propagation() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "sampling.table_autosave.every_steps is only valid for relaxation studies";

        let error = run_script_preparation_preflight(
            &workspace,
            || Err::<(), _>(anyhow::anyhow!(raw_error)),
            || panic!("planning must not run after validation failure"),
        )
        .expect_err("validation should fail");

        assert!(error.to_string().contains(raw_error));
        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        let failure = preparation.failure.as_ref().expect("owned failure");
        assert_eq!(failure.stage_id, PreparationStageId::Validation);
        assert_eq!(failure.error_code, "validation_failed");
        assert_eq!(failure.summary, raw_error);
        assert!(failure
            .diagnostics_correlation_id
            .as_deref()
            .is_some_and(|value| value.starts_with("preparation-validation-")));
        assert!(preparation.log_tail.iter().any(|entry| {
            entry.level == crate::simulation_preparation::PreparationLogLevel::Error
                && entry.message == raw_error
        }));
    }

    #[test]
    fn validation_failure_keeps_unsafe_details_out_of_public_preparation() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "validator leaked /private/model/path\nsecret-token";

        run_script_preparation_preflight(
            &workspace,
            || Err::<(), _>(anyhow::anyhow!(raw_error)),
            || panic!("planning must not run after validation failure"),
        )
        .expect_err("validation should fail");

        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::Validation,
            "validation_failed",
            "Simulation validation failed",
            raw_error,
        );
    }

    #[test]
    fn planner_failure_is_owned_before_propagation() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "planner leaked backend internals";

        let error = run_script_preparation_preflight(
            &workspace,
            || Ok(()),
            || Err(anyhow::anyhow!(raw_error)),
        )
        .expect_err("planning should fail");

        assert!(error.to_string().contains(raw_error));
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::Planning,
            "planning_failed",
            "Simulation planning failed",
            raw_error,
        );
    }

    #[test]
    fn phase_one_thread_creation_failure_is_owned_before_propagation() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "phase-one thread failure leaked /private/model.py";
        let error = own_preparation_boundary_failure::<()>(
            &workspace,
            "script_materialization_thread_start_failed",
            "Python script materialization could not start",
            Err(anyhow::anyhow!(raw_error)),
        )
        .expect_err("thread creation failure must propagate");

        assert_eq!(error.to_string(), raw_error);
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::ScriptMaterialization,
            "script_materialization_thread_start_failed",
            "Python script materialization could not start",
            raw_error,
        );
    }

    #[test]
    fn control_room_bootstrap_failure_is_owned_before_propagation() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "control-room bootstrap leaked token secret-token";
        let error = own_preparation_boundary_failure::<()>(
            &workspace,
            "control_room_bootstrap_failed",
            "Control Room bootstrap failed",
            Err(anyhow::anyhow!(raw_error)),
        )
        .expect_err("control-room bootstrap failure must propagate");

        assert_eq!(error.to_string(), raw_error);
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::ScriptMaterialization,
            "control_room_bootstrap_failed",
            "Control Room bootstrap failed",
            raw_error,
        );
    }

    #[test]
    fn terminal_preparation_failure_waits_for_explicit_close_and_remains_served() {
        let workspace = preparation_workspace(PreparationStageId::Validation);
        fail_owned_preparation_stage(
            &workspace,
            PreparationStageId::Validation,
            "validation_failed",
            "Simulation validation failed",
        )
        .expect("test preparation should fail");
        let mut commands = vec!["run", "close"].into_iter();
        let mut received = Vec::new();

        wait_for_failed_preparation_close(&workspace, || {
            let kind = commands.next()?;
            received.push(kind);
            serde_json::from_value(serde_json::json!({
                "command_id": format!("cmd-{kind}"),
                "kind": kind,
                "created_at_unix_ms": 0,
            }))
            .ok()
        });

        assert_eq!(received, vec!["run", "close"]);
        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("terminal preparation must remain served until close");
        assert_eq!(preparation.status, PreparationStatus::Failed);
        assert_eq!(
            preparation.failure.expect("failure provenance").error_code,
            "validation_failed"
        );
    }

    #[test]
    fn successful_preparation_does_not_enter_failure_close_wait() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);

        wait_for_failed_preparation_close(&workspace, || {
            panic!("nonfailed preparation must not wait for a close command")
        });
    }

    #[test]
    fn fallback_helper_error_boundary_projects_terminal_mesh_failure_in_order() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "mesher stderr leaked /private/model/mesh.msh";

        crate::live_workspace::apply_python_progress_event(
            &workspace,
            PythonProgressEvent::Structured {
                kind: "mesh_build_failed".to_string(),
                payload: serde_json::json!({
                    "phase": "postprocessing",
                    "message": "Shared-domain mesh build failed",
                    "error": raw_error,
                }),
            },
        );
        let deferred = workspace.snapshot();
        assert_eq!(
            deferred
                .simulation_preparation
                .as_ref()
                .and_then(|preparation| preparation.active_stage_id),
            Some(PreparationStageId::ScriptMaterialization)
        );
        assert_eq!(
            deferred
                .mesh_workspace
                .as_ref()
                .and_then(|resource| resource.get("last_build_error")),
            Some(&serde_json::json!(raw_error))
        );

        let error = project_script_export_failure(&workspace, false, anyhow::anyhow!(raw_error))
            .expect("fallback projection should preserve the original helper error");

        assert_eq!(error.to_string(), raw_error);
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::MeshPostprocessing,
            "mesh_build_failed",
            "Shared-domain mesh build failed",
            raw_error,
        );
        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        let script_materialization = preparation
            .stages
            .iter()
            .find(|stage| stage.id == PreparationStageId::ScriptMaterialization)
            .expect("script materialization stage");
        assert_eq!(
            script_materialization.status,
            PreparationStageStatus::Completed
        );
        assert_eq!(script_materialization.duration_ms, None);
        assert_eq!(
            script_materialization.detail,
            "Script materialization reached mesh generation before failure; timing unavailable"
        );
        for stage_id in [PreparationStageId::Validation, PreparationStageId::Planning] {
            let stage = preparation
                .stages
                .iter()
                .find(|stage| stage.id == stage_id)
                .expect("skipped incomplete-IR stage");
            assert_eq!(
                stage.status,
                PreparationStageStatus::Skipped,
                "a complete materialized IR was unavailable"
            );
            assert_eq!(
                stage.detail,
                "Skipped because a complete materialized IR was unavailable after mesh generation failure"
            );
        }
        for stage_id in [
            PreparationStageId::DomainPreparation,
            PreparationStageId::Meshing,
        ] {
            let stage = preparation
                .stages
                .iter()
                .find(|stage| stage.id == stage_id)
                .expect("projected mesh predecessor");
            assert_eq!(stage.status, PreparationStageStatus::Completed);
            assert_eq!(stage.duration_ms, None);
            assert!(stage.detail.contains("timing unavailable"));
        }
        let failed_postprocessing = preparation
            .stages
            .iter()
            .find(|stage| stage.id == PreparationStageId::MeshPostprocessing)
            .expect("projected failure owner");
        assert_eq!(failed_postprocessing.status, PreparationStageStatus::Failed);
        assert_eq!(failed_postprocessing.completed_at_unix_ms, None);
        assert_eq!(failed_postprocessing.duration_ms, None);
        assert!(preparation
            .log_tail
            .iter()
            .all(|entry| !entry.message.contains(raw_error)));
    }

    #[test]
    fn helper_error_without_authoritative_mesh_failure_remains_script_owned() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "python helper exited before mesh generation";

        let error = project_script_export_failure(&workspace, false, anyhow::anyhow!(raw_error))
            .expect("generic materialization failure should preserve the original error");

        assert_eq!(error.to_string(), raw_error);
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::ScriptMaterialization,
            "materialization_failed",
            "Simulation materialization failed",
            raw_error,
        );
        assert_eq!(
            workspace
                .snapshot()
                .simulation_preparation
                .expect("preparation state")
                .failure
                .expect("owned failure")
                .detail
                .as_deref(),
            Some(raw_error)
        );
    }

    #[test]
    fn authored_mixed_p1_preflight_failure_is_owned_by_planning_with_diagnostics() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = concat!(
            "ValueError: fem_mixed_p1_scope_rejected: phase=authored_preflight;",
            " failed_predicates=[unsupported_uniaxial_anisotropy]"
        );

        assert!(super::project_authoritative_authored_preflight_failure(
            &workspace,
            &anyhow::anyhow!(raw_error),
        )
        .expect("authored capability failure should project"),);

        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        for (stage_id, expected_status) in [
            (
                PreparationStageId::ScriptMaterialization,
                PreparationStageStatus::Completed,
            ),
            (
                PreparationStageId::Validation,
                PreparationStageStatus::Skipped,
            ),
            (PreparationStageId::Planning, PreparationStageStatus::Failed),
        ] {
            let stage = preparation
                .stages
                .iter()
                .find(|stage| stage.id == stage_id)
                .expect("projected preflight stage");
            assert_eq!(stage.status, expected_status);
        }
        let failure = preparation.failure.as_ref().expect("owned failure");
        assert_eq!(failure.error_code, "fem_mixed_p1_scope_rejected");
        assert_eq!(
            failure.summary,
            "Simulation planning rejected unsupported mixed-P1 capability"
        );
        assert_eq!(failure.detail.as_deref(), Some(raw_error));
        assert!(failure
            .diagnostics_correlation_id
            .as_deref()
            .is_some_and(|value| value.starts_with("preparation-planning-")));
        assert!(preparation.log_tail.iter().all(|entry| {
            entry.message
                != "Lightweight script preflight was unavailable; using full materialization"
        }));
    }

    #[test]
    fn generic_materialization_failure_preserves_safe_root_cause_detail() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "python helper failed: FDM universe membership is unavailable";

        let error = run_active_preparation_operation(
            &workspace,
            "script_materialization_failed",
            "Simulation materialization failed",
            || Err::<(), _>(anyhow::anyhow!(raw_error)),
        )
        .expect_err("materialization should fail");

        assert_eq!(error.to_string(), raw_error);
        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        let failure = preparation.failure.as_ref().expect("owned failure");
        assert_eq!(failure.summary, "Simulation materialization failed");
        assert_eq!(failure.detail.as_deref(), Some(raw_error));
        assert!(preparation
            .log_tail
            .iter()
            .all(|entry| !entry.message.contains(raw_error)));
    }

    #[test]
    fn generic_materialization_failure_selects_safe_cause_from_wrapped_error() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "python helper failed: FDM universe membership is unavailable";
        let wrapped_error =
            anyhow::anyhow!(raw_error).context("failed to export ProblemIR from /private/model.py");

        run_active_preparation_operation(
            &workspace,
            "script_materialization_failed",
            "Simulation materialization failed",
            || Err::<(), _>(wrapped_error),
        )
        .expect_err("materialization should fail");

        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        let failure = preparation.failure.as_ref().expect("owned failure");
        assert_eq!(failure.detail.as_deref(), Some(raw_error));
        assert!(preparation
            .log_tail
            .iter()
            .all(|entry| !entry.message.contains(raw_error)));
    }

    #[test]
    fn generic_materialization_failure_sanitizes_multiline_root_cause_detail() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "Traceback (most recent call last):\nValueError: FDM membership unavailable at /private/model.py:42";

        run_active_preparation_operation(
            &workspace,
            "script_materialization_failed",
            "Simulation materialization failed",
            || Err::<(), _>(anyhow::anyhow!(raw_error)),
        )
        .expect_err("materialization should fail");

        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        let failure = preparation.failure.as_ref().expect("owned failure");
        assert_eq!(
            failure.detail.as_deref(),
            Some("ValueError: FDM membership unavailable at <path>")
        );
        assert!(preparation
            .log_tail
            .iter()
            .all(|entry| !entry.message.contains("/private/model.py")));
    }

    #[test]
    fn generic_materialization_failure_redacts_unsafe_root_cause_detail() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "python helper failed /private/model.py\nsecret-token";

        run_active_preparation_operation(
            &workspace,
            "script_materialization_failed",
            "Simulation materialization failed",
            || Err::<(), _>(anyhow::anyhow!(raw_error)),
        )
        .expect_err("materialization should fail");

        let failure = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state")
            .failure
            .expect("owned failure");
        assert_eq!(failure.summary, "Simulation materialization failed");
        assert_eq!(failure.detail, None);
    }

    #[test]
    fn deferred_mesh_failure_rejects_missing_phase() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "missing-phase mesher failure";
        crate::live_workspace::apply_python_progress_event(
            &workspace,
            PythonProgressEvent::Structured {
                kind: "mesh_build_failed".to_string(),
                payload: serde_json::json!({
                    "error": raw_error,
                    "message": "Shared-domain mesh build failed"
                }),
            },
        );
        let snapshot = workspace.snapshot();

        assert_eq!(
            deferred_mesh_failure_stage(snapshot.mesh_workspace.as_ref()),
            None
        );
        let error = project_script_export_failure(&workspace, false, anyhow::anyhow!(raw_error))
            .expect("missing phase should remain a generic helper failure");
        assert_eq!(error.to_string(), raw_error);
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::ScriptMaterialization,
            "materialization_failed",
            "Simulation materialization failed",
            raw_error,
        );
    }

    #[test]
    fn deferred_mesh_failure_rejects_unknown_phase() {
        let workspace = preparation_workspace(PreparationStageId::ScriptMaterialization);
        let raw_error = "unknown-phase mesher failure";
        crate::live_workspace::apply_python_progress_event(
            &workspace,
            PythonProgressEvent::Structured {
                kind: "mesh_build_failed".to_string(),
                payload: serde_json::json!({
                    "phase": "finalizing",
                    "error": raw_error,
                    "message": "Shared-domain mesh build failed"
                }),
            },
        );
        let snapshot = workspace.snapshot();

        assert_eq!(
            deferred_mesh_failure_stage(snapshot.mesh_workspace.as_ref()),
            None
        );
        let error = project_script_export_failure(&workspace, false, anyhow::anyhow!(raw_error))
            .expect("unknown phase should remain a generic helper failure");
        assert_eq!(error.to_string(), raw_error);
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::ScriptMaterialization,
            "materialization_failed",
            "Simulation materialization failed",
            raw_error,
        );
    }

    #[test]
    fn deferred_mesh_failure_accepts_recognized_phase() {
        for (phase, stage_id) in [
            ("preparing_domain", PreparationStageId::DomainPreparation),
            ("meshing", PreparationStageId::Meshing),
            ("postprocessing", PreparationStageId::MeshPostprocessing),
        ] {
            let workspace = serde_json::json!({
                "last_build_error": "raw mesher failure",
                "last_build_summary": {
                    "build_id": "mesh:last-good",
                    "status": "completed"
                },
                "last_build_attempt": {
                    "phase": phase,
                    "message": "Shared-domain mesh build failed"
                }
            });

            assert_eq!(
                deferred_mesh_failure_stage(Some(&workspace)),
                Some(stage_id)
            );

            let legacy_workspace = serde_json::json!({
                "last_build_error": "raw mesher failure",
                "last_build_summary": {
                    "phase": phase,
                    "message": "Shared-domain mesh build failed"
                }
            });
            assert_eq!(
                deferred_mesh_failure_stage(Some(&legacy_workspace)),
                Some(stage_id),
                "legacy failure summaries remain readable"
            );
        }
    }

    #[test]
    fn materialized_validation_safety_failure_is_owned_by_solver_initialization() {
        let workspace = preparation_workspace(PreparationStageId::MeshPostprocessing);
        let raw_error = "materialized validator leaked /private/model/path";

        let error = run_solver_initialization(&workspace, false, || {
            run_solver_initialization_safety_check(
                &workspace,
                "Checking fully materialized runtime validity",
                "solver_initialization_materialized_validation_failed",
                "Fully materialized runtime validation failed during solver initialization",
                || Err::<(), _>(anyhow::anyhow!(raw_error)),
            )
        })
        .expect_err("materialized validation should fail");

        assert!(error.to_string().contains(raw_error));
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::SolverInitialization,
            "solver_initialization_materialized_validation_failed",
            "Fully materialized runtime validation failed during solver initialization",
            raw_error,
        );
        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        let failure = preparation.failure.as_ref().expect("owned failure");
        assert_eq!(
            failure.detail.as_deref(),
            Some("materialized validator leaked <path>")
        );
        assert!(failure
            .diagnostics_correlation_id
            .as_deref()
            .is_some_and(|value| value.starts_with("preparation-solver_initialization-")));
        assert!(preparation.log_tail.iter().any(|entry| {
            entry.stage_id == PreparationStageId::SolverInitialization
                && entry.message == "Checking fully materialized runtime validity"
        }));
        assert!(preparation
            .stages
            .iter()
            .filter(|stage| {
                matches!(
                    stage.id,
                    PreparationStageId::Validation | PreparationStageId::Planning
                )
            })
            .all(|stage| stage.status != PreparationStageStatus::Failed));
    }

    #[test]
    fn materialized_planning_safety_failure_is_owned_by_solver_initialization() {
        let workspace = preparation_workspace(PreparationStageId::MeshPostprocessing);
        let raw_error = "materialized planner leaked backend internals";

        let error = run_solver_initialization(&workspace, false, || {
            run_solver_initialization_safety_check(
                &workspace,
                "Checking the fully materialized execution plan",
                "solver_initialization_materialized_planning_failed",
                "Fully materialized execution planning failed during solver initialization",
                || Err::<(), _>(anyhow::anyhow!(raw_error)),
            )
        })
        .expect_err("materialized planning should fail");

        assert!(error.to_string().contains(raw_error));
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::SolverInitialization,
            "solver_initialization_materialized_planning_failed",
            "Fully materialized execution planning failed during solver initialization",
            raw_error,
        );
        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        let failure = preparation.failure.as_ref().expect("owned failure");
        assert_eq!(
            failure.detail.as_deref(),
            Some("materialized planner leaked backend internals")
        );
        assert!(failure
            .diagnostics_correlation_id
            .as_deref()
            .is_some_and(|value| value.starts_with("preparation-solver_initialization-")));
        assert!(preparation.log_tail.iter().any(|entry| {
            entry.stage_id == PreparationStageId::SolverInitialization
                && entry.message == "Checking the fully materialized execution plan"
        }));
        assert!(preparation
            .stages
            .iter()
            .filter(|stage| {
                matches!(
                    stage.id,
                    PreparationStageId::Validation | PreparationStageId::Planning
                )
            })
            .all(|stage| stage.status != PreparationStageStatus::Failed));
    }

    #[test]
    fn solver_construction_failure_is_owned_before_propagation() {
        let workspace = preparation_workspace(PreparationStageId::MeshPostprocessing);
        let raw_error = "solver constructor leaked native path";

        let error = run_owned_preparation_stage(
            &workspace,
            PreparationStageId::SolverInitialization,
            "Initializing the solver",
            "Solver initialized",
            false,
            "solver_initialization_failed",
            "Solver initialization failed",
            false,
            || Err::<(), _>(anyhow::anyhow!(raw_error)),
        )
        .expect_err("solver construction should fail");

        assert!(error.to_string().contains(raw_error));
        assert_owned_preparation_failure(
            &workspace,
            PreparationStageId::SolverInitialization,
            "solver_initialization_failed",
            "Solver initialization failed",
            raw_error,
        );
    }

    #[test]
    fn workspace_only_preparation_skips_solver_initialization() {
        let workspace = preparation_workspace(PreparationStageId::MeshPostprocessing);

        run_solver_initialization(&workspace, true, || Ok(()))
            .expect("workspace resource validation should succeed");

        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        assert_eq!(
            preparation
                .stages
                .iter()
                .find(|stage| stage.id == PreparationStageId::SolverInitialization)
                .expect("solver initialization stage")
                .status,
            PreparationStageStatus::Skipped
        );
    }

    #[test]
    fn ui_shell_launch_skips_simulation_only_stages_before_ready() {
        let workspace = preparation_workspace(PreparationStageId::RuntimeStartup);

        mark_ui_shell_preparation_ready(&workspace).expect("UI shell should become ready");

        let preparation = workspace
            .snapshot()
            .simulation_preparation
            .expect("preparation state");
        assert_eq!(preparation.status, PreparationStatus::Ready);
        for stage_id in [
            PreparationStageId::ScriptMaterialization,
            PreparationStageId::Validation,
            PreparationStageId::Planning,
            PreparationStageId::DomainPreparation,
            PreparationStageId::Meshing,
            PreparationStageId::MeshPostprocessing,
            PreparationStageId::SolverInitialization,
        ] {
            assert_eq!(
                preparation
                    .stages
                    .iter()
                    .find(|stage| stage.id == stage_id)
                    .expect("canonical stage")
                    .status,
                PreparationStageStatus::Skipped
            );
        }
        for stage_id in [
            PreparationStageId::RuntimeStartup,
            PreparationStageId::ScriptMaterialization,
            PreparationStageId::Validation,
            PreparationStageId::Planning,
            PreparationStageId::DomainPreparation,
            PreparationStageId::Meshing,
            PreparationStageId::MeshPostprocessing,
            PreparationStageId::SolverInitialization,
            PreparationStageId::Ready,
        ] {
            assert!(preparation
                .log_tail
                .iter()
                .any(|entry| entry.stage_id == stage_id));
        }
    }

    #[test]
    fn live_step_update_applies_hysteresis_progress_to_active_stage() {
        let mut state = test_workspace_state();
        state.stage_execution = Some(CurrentLiveStageExecutionState {
            total_stages: 2,
            completed_stage_indexes: vec![0],
            stages: vec![
                CurrentLiveStageExecutionRecord {
                    status: "completed".to_string(),
                    ..CurrentLiveStageExecutionRecord::default()
                },
                CurrentLiveStageExecutionRecord {
                    status: "running".to_string(),
                    ..CurrentLiveStageExecutionRecord::default()
                },
            ],
            stage_statuses: vec!["completed".to_string(), "running".to_string()],
            active_stage_index: Some(1),
            active_stage_kind: Some("hysteresis".to_string()),
            runtime_state: "running".to_string(),
        });
        let mut update = test_step_update(0);
        update.hysteresis_field_m_t = Some(25.0);
        update.hysteresis_point_index = Some(4);
        update.hysteresis_settle_step_index = Some(1);
        update.hysteresis_settle_step_kind = Some("minimize".to_string());
        update.hysteresis_settle_step_method = Some("projected_gradient_bb".to_string());

        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            update,
            false,
        );

        let stages = &state.stage_execution.as_ref().unwrap().stages;
        assert_eq!(stages[0].current_field_m_t, None);
        assert_eq!(stages[1].current_field_m_t, Some(25.0));
        assert_eq!(stages[1].current_point_index, Some(4));
        assert_eq!(stages[1].current_settle_step_index, Some(1));
        assert_eq!(
            stages[1].current_settle_step_kind.as_deref(),
            Some("minimize")
        );
        assert_eq!(
            stages[1].current_settle_step_method.as_deref(),
            Some("projected_gradient_bb")
        );
    }

    #[test]
    fn live_step_update_applies_fem_eigen_progress_to_active_stage() {
        let mut state = test_workspace_state();
        state.stage_execution = Some(CurrentLiveStageExecutionState {
            total_stages: 1,
            completed_stage_indexes: vec![],
            stages: vec![CurrentLiveStageExecutionRecord {
                status: "running".to_string(),
                ..CurrentLiveStageExecutionRecord::default()
            }],
            stage_statuses: vec!["running".to_string()],
            active_stage_index: Some(0),
            active_stage_kind: Some("flat_eigenmodes".to_string()),
            runtime_state: "running".to_string(),
        });
        let mut progress = std::collections::HashMap::new();
        progress.insert("percent".to_string(), 48.0);
        progress.insert(
            "phase_kind:solving_native_frequency_window_base".to_string(),
            1.0,
        );
        progress.insert(
            "solver_kind:slepc_multi_shift_invert_production_cpu_dense".to_string(),
            1.0,
        );
        progress.insert("active_nodes".to_string(), 1931.0);
        progress.insert("effective_dof".to_string(), 3862.0);
        progress.insert("requested_modes".to_string(), 20.0);
        progress.insert("computed_modes".to_string(), 4.0);
        progress.insert("iteration".to_string(), 37.0);
        progress.insert("max_iterations".to_string(), 5000.0);
        progress.insert("residual".to_string(), 1.2e-5);
        progress.insert("window_phase_base".to_string(), 1.0);
        progress.insert("current_subwindow".to_string(), 3.0);
        progress.insert("total_subwindows".to_string(), 16.0);
        progress.insert("subwindow_elapsed_seconds".to_string(), 2.5);
        progress.insert("window_elapsed_seconds".to_string(), 8.0);
        let mut update = test_step_update(37);
        set_fem_eigen_progress(&mut update.stats, progress);

        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            update,
            false,
        );

        let stage = &state.stage_execution.as_ref().unwrap().stages[0];
        assert_eq!(stage.progress_percent, Some(48.0));
        assert_eq!(
            stage.progress_label.as_deref(),
            Some("solving native frequency window base")
        );
        let detail = stage.progress_detail.as_deref().unwrap_or_default();
        assert!(detail.contains("solver=slepc_multi_shift_invert_production_cpu_dense"));
        assert!(detail.contains("effective_dof=3862"));
        assert!(detail.contains("iteration=37/5000"));
        assert!(detail.contains("residual=1.200e-5"));
        assert!(detail.contains("window_phase=base"));
        assert!(detail.contains("subwindow=3/16"));
        assert!(detail.contains("subwindow_s=2.5"));
        assert!(detail.contains("window_s=8.0"));
        assert!(stage.last_progress_unix_ms.is_some());
    }

    #[test]
    fn modal_progress_does_not_replace_physical_scalar_history_or_run_energy() {
        let mut state = test_workspace_state();
        let mut measured = test_step_update(3);
        measured.stats.e_total = -1.25e-18;
        state.latest_scalar_row = Some(crate::live_workspace::scalar_row_from_stats(
            &measured.stats,
        ));
        let mut modal = test_step_update(4);
        set_fem_eigen_progress(
            &mut modal.stats,
            std::collections::HashMap::from([("progress_fraction".into(), 0.5)]),
        );
        let modal_live_state = crate::step_utils::live_state_manifest_from_update(modal.clone());
        assert_eq!(
            modal_live_state.latest_step.kind,
            fullmag_quantities::StepDataKind::SolverProgress
        );
        assert!(matches!(
            modal_live_state.latest_step.solver_progress,
            Some(fullmag_quantities::SolverProgress::FemEigen { .. })
        ));
        assert!(modal_live_state.latest_step.per_object_scalars.is_empty());
        modal.finished = true;
        crate::live_workspace::set_latest_scalar_row_for_terminal_update(&mut state, &modal);
        assert_eq!(state.latest_scalar_row.as_ref().unwrap().e_total, -1.25e-18);
        assert_eq!(state.latest_scalar_row.as_ref().unwrap().step, 3);
        let run = crate::step_utils::running_run_manifest_from_update(
            "run",
            "session",
            PathBuf::from("/tmp/artifacts").as_path(),
            &modal,
        );
        assert_eq!(run.final_e_total, None);
        assert_eq!(run.final_time, None);
        assert_eq!(run.total_steps, 0);
        let physical = crate::step_utils::running_run_manifest_from_update(
            "run",
            "session",
            PathBuf::from("/tmp/artifacts").as_path(),
            &measured,
        );
        assert_eq!(physical.final_e_total, Some(-1.25e-18));
    }

    #[test]
    fn eigen_progress_after_physical_magnetization_serializes_an_api_acceptable_frame() {
        let mut state = test_workspace_state();
        let mut initial_physical = test_step_update(3);
        initial_physical.magnetization = Some(vec![1.0, 0.0, 0.0]);
        state.live_state = crate::step_utils::live_state_manifest_from_update(
            initial_physical.clone(),
        );
        let mut initial_field = initial_physical;
        assert!(super::ingest_magnetization_field_from_update(
            &mut state,
            &mut initial_field
        ));

        let thin_physical = test_step_update(4);
        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            thin_physical,
            false,
        );
        assert!(state.live_state.latest_step.is_physical_observation());
        assert_eq!(
            state.live_state.latest_step.magnetization,
            Some(vec![1.0, 0.0, 0.0]),
            "physical-to-physical thin updates retain magnetization"
        );

        let mut progress = test_step_update(5);
        set_fem_eigen_progress(
            &mut progress.stats,
            std::collections::HashMap::from([("progress_fraction".into(), 0.5)]),
        );
        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            progress,
            false,
        );

        let latest_step = &state.live_state.latest_step;
        assert!(!latest_step.is_physical_observation());
        assert_eq!(
            latest_step.kind,
            fullmag_quantities::StepDataKind::SolverProgress
        );
        assert!(matches!(
            latest_step.solver_progress.as_ref(),
            Some(fullmag_quantities::SolverProgress::FemEigen { .. })
        ));
        assert!(latest_step.magnetization.is_none());
        assert_eq!(
            state.latest_fields.0["m"]["values"],
            serde_json::json!([1.0, 0.0, 0.0]),
            "the previously accepted field remains independently cached"
        );

        let api_live_state = serde_json::to_value(&state.live_state)
            .expect("CLI live state should serialize to the API frame shape");
        let api_step = &api_live_state["latest_step"];
        assert_eq!(api_step["kind"], serde_json::json!("solver_progress"));
        assert_eq!(
            api_step["solver_progress"]["kind"],
            serde_json::json!("fem_eigen")
        );
        assert!(api_step["magnetization"].is_null());
        assert_eq!(api_step["per_object_scalars"], serde_json::json!({}));
        assert_eq!(api_step["field_materialization_states"], serde_json::json!([]));
        assert!(api_step["preview_field"].is_null());
    }

    #[test]
    fn nonphysical_or_contradictory_magnetization_is_not_promoted_to_latest_fields() {
        let cases = [
            (
                fullmag_quantities::StepDataKind::LegacyUnclassified,
                None,
            ),
            (
                fullmag_quantities::StepDataKind::SolverProgress,
                Some(fullmag_quantities::SolverProgress::FemEigen {
                    metrics: std::collections::HashMap::from([("progress_fraction".into(), 0.5)]),
                }),
            ),
            (
                fullmag_quantities::StepDataKind::PhysicalObservation,
                Some(fullmag_quantities::SolverProgress::FemEigen {
                    metrics: std::collections::HashMap::from([("progress_fraction".into(), 0.5)]),
                }),
            ),
        ];

        for (kind, solver_progress) in cases {
            let mut state = test_workspace_state();
            let mut update = test_step_update(5);
            update.stats.kind = kind;
            update.stats.solver_progress = solver_progress;
            update.magnetization = Some(vec![1.0, 0.0, 0.0]);

            assert!(!super::ingest_magnetization_field_from_update(
                &mut state,
                &mut update
            ));
            assert!(state.latest_fields.0.get("m").is_none());
            assert!(update.magnetization.is_some());
        }
    }

    #[test]
    fn modal_solver_identity_never_infers_dense_from_missing_or_ambiguous_flags() {
        let mut progress = std::collections::HashMap::new();
        assert_eq!(super::fem_eigen_progress_solver(&progress), "unknown");
        for kind in [
            "slepc_multi_shift_invert_production_cpu_dense",
            "gpu_modal_device_krylov",
            "cpu_full_2x2_symmetric",
        ] {
            progress.clear();
            progress.insert(format!("solver_kind:{kind}"), 1.0);
            assert_eq!(super::fem_eigen_progress_solver(&progress), kind);
        }
        progress.insert("solver_kind:other".into(), 1.0);
        assert_eq!(super::fem_eigen_progress_solver(&progress), "unknown");
    }

    #[test]
    fn terminal_stage_line_includes_fem_eigen_window_progress() {
        let mut progress = std::collections::HashMap::new();
        progress.insert(
            "solver_kind:slepc_multi_shift_invert_production_cpu_dense".to_string(),
            1.0,
        );
        progress.insert("window_phase_refinement".to_string(), 1.0);
        progress.insert("current_subwindow".to_string(), 17.0);
        progress.insert("total_subwindows".to_string(), 34.0);
        progress.insert("subwindow_elapsed_seconds".to_string(), 4.25);
        progress.insert("window_elapsed_seconds".to_string(), 71.5);
        progress.insert("residual".to_string(), 2.0e-9);
        let stats = fullmag_runner::StepStats {
            kind: fullmag_quantities::StepDataKind::SolverProgress,
            solver_progress: Some(fullmag_quantities::SolverProgress::FemEigen {
                metrics: progress,
            }),
            step: 17,
            ..fullmag_runner::StepStats::default()
        };

        let line = format_stage_progress_line(
            "stage 2/2 (flat_eigenmodes)",
            &stats,
            None,
            Some(Duration::from_secs(5)),
            None,
        );

        for forbidden in ["|H_eff|", "max_torque", "E_total", "m_avg", " t=", " dt="] {
            assert!(!line.contains(forbidden), "{line}");
        }
        assert!(line.contains("solver=slepc_multi_shift_invert_production_cpu_dense"));
        assert!(line.contains("modal window phase=refinement"), "{line}");
        assert!(line.contains("subwindow=17/34"), "{line}");
        assert!(line.contains("subwindow_s=4.2"), "{line}");
        assert!(line.contains("window_s=71.5"), "{line}");
        assert!(line.contains("relres=2.000e-9"), "{line}");
    }

    fn tagged_ksp_progress_for_cli() -> std::collections::HashMap<String, f64> {
        let mut progress = std::collections::HashMap::new();
        for (key, value) in [
            ("window_phase_refinement", 1.0),
            ("iteration", 17.0),
            ("max_iterations", 300.0),
            ("current_subwindow", 23.0),
            ("total_subwindows", 50.0),
            ("linear_iteration", 12.0),
            ("linear_residual_norm", 4.5e-8),
            ("linear_solver_role:poisson", 1.0),
            ("linear_ksp_type:gmres", 1.0),
            ("residual_source:ksp_norm", 1.0),
            ("residual", 5.0e-2),
        ] {
            progress.insert(key.to_string(), value);
        }
        progress
    }

    #[test]
    fn terminal_stage_line_formats_tagged_ksp_without_relative_residual() {
        let stats = fullmag_runner::StepStats {
            kind: fullmag_quantities::StepDataKind::SolverProgress,
            solver_progress: Some(fullmag_quantities::SolverProgress::FemEigen {
                metrics: tagged_ksp_progress_for_cli(),
            }),
            step: 17,
            ..fullmag_runner::StepStats::default()
        };

        let line = format_stage_progress_line(
            "stage 2/2 (flat_eigenmodes)",
            &stats,
            None,
            Some(Duration::from_secs(5)),
            None,
        );

        assert!(line.contains("iteration=17/300"), "{line}");
        assert!(line.contains("subwindow=23/50"), "{line}");
        assert!(line.contains("linear_iteration=12"), "{line}");
        assert!(line.contains("ksp_norm=4.500e-8"), "{line}");
        assert!(line.contains("linear_solver_role=poisson"), "{line}");
        assert!(line.contains("linear_ksp_type=gmres"), "{line}");
        assert_eq!(line.matches("ksp_norm=").count(), 1, "{line}");
        assert!(!line.contains("relres="), "{line}");
        assert!(!line.contains("residual=5.000e-2"), "{line}");
    }

    #[test]
    fn appended_fem_eigen_progress_formats_tagged_ksp_diagnostics() {
        let stats = fullmag_runner::StepStats {
            kind: fullmag_quantities::StepDataKind::SolverProgress,
            solver_progress: Some(fullmag_quantities::SolverProgress::FemEigen {
                metrics: tagged_ksp_progress_for_cli(),
            }),
            ..fullmag_runner::StepStats::default()
        };
        let mut line = "stage".to_string();

        super::append_fem_eigen_step_progress(&mut line, &stats);

        assert!(line.contains("subwindow=23/50"), "{line}");
        assert!(line.contains("linear_iteration=12"), "{line}");
        assert!(line.contains("ksp_norm=4.500e-8"), "{line}");
        assert!(line.contains("linear_solver_role=poisson"), "{line}");
        assert!(line.contains("linear_ksp_type=gmres"), "{line}");
        assert!(!line.contains("relres="), "{line}");
        assert!(!line.contains("residual=5.000e-2"), "{line}");
    }

    #[test]
    fn stage_heartbeat_does_not_overwrite_solver_progress_detail() {
        let mut stage = CurrentLiveStageExecutionRecord {
            progress_percent: Some(48.0),
            progress_label: Some("solving sparse LOBPCG".to_string()),
            progress_detail: Some(
                "solving sparse LOBPCG; solver=cpu_sparse_lobpcg; effective_dof=3862; iteration=37/5000; residual=1.200e-5"
                    .to_string(),
            ),
            last_progress_unix_ms: Some(1_781_531_277_401),
            ..CurrentLiveStageExecutionRecord::default()
        };

        apply_stage_heartbeat_progress(&mut stage, Duration::from_secs(396));

        assert_eq!(stage.progress_percent, Some(48.0));
        assert_eq!(
            stage.progress_label.as_deref(),
            Some("solving sparse LOBPCG")
        );
        assert!(stage
            .progress_detail
            .as_deref()
            .is_some_and(|detail| detail.contains("iteration=37/5000")));
        assert_eq!(stage.last_progress_unix_ms, Some(1_781_531_277_401));
    }

    #[test]
    fn antenna_live_progress_updates_only_the_active_running_stage() {
        let mut execution = scripted_stage_execution_state(
            2,
            0,
            "antenna_field_solve",
            "running",
            None,
            None,
            None,
            None,
            None,
            None,
        );
        assert!(update_antenna_live_stage_progress(
            &mut execution,
            0,
            fullmag_runner::AntennaFieldStageStatus::Meshing,
            Some("reused planned mesh".into()),
            123,
        ));
        assert_eq!(execution.stages[0].progress_label.as_deref(), Some("mesh reused"));
        assert_eq!(execution.stages[0].progress_detail.as_deref(), Some("reused planned mesh"));
        assert_eq!(execution.stages[0].progress_percent, None);
        assert_eq!(execution.stages[0].last_progress_unix_ms, Some(123));
        assert!(!update_antenna_live_stage_progress(
            &mut execution,
            1,
            fullmag_runner::AntennaFieldStageStatus::EvaluatingField,
            None,
            124,
        ));
        execution.stages[0].status = "completed".into();
        assert!(!update_antenna_live_stage_progress(
            &mut execution,
            0,
            fullmag_runner::AntennaFieldStageStatus::ProjectingTargets,
            None,
            125,
        ));
        assert_eq!(execution.stages[0].last_progress_unix_ms, Some(123));
    }

    #[test]
    fn frequency_response_progress_updates_stage_execution() {
        let mut state = test_workspace_state();
        state.stage_execution = Some(CurrentLiveStageExecutionState {
            total_stages: 1,
            completed_stage_indexes: Vec::new(),
            stages: vec![CurrentLiveStageExecutionRecord {
                status: "running".to_string(),
                ..CurrentLiveStageExecutionRecord::default()
            }],
            stage_statuses: vec!["running".to_string()],
            active_stage_index: Some(0),
            active_stage_kind: Some("flat_frequency_response".to_string()),
            runtime_state: "running".to_string(),
        });
        let mut progress = std::collections::HashMap::new();
        progress.insert("percent".to_string(), 25.0);
        progress.insert("completed_frequency_count".to_string(), 1.0);
        progress.insert("total_frequency_count".to_string(), 4.0);
        progress.insert("frequency_hz".to_string(), 2.75e9);
        progress.insert("frequency_min_hz".to_string(), 2.0e9);
        progress.insert("frequency_max_hz".to_string(), 5.0e9);
        progress.insert("iteration".to_string(), 384.0);
        progress.insert("relative_residual_l2_norm".to_string(), 8.5e-4);
        let mut update = test_step_update(1);
        update
            .stats
            .per_object_scalars
            .insert("fem_frequency_response_progress".to_string(), progress);

        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            update,
            false,
        );

        let stage = &state.stage_execution.as_ref().unwrap().stages[0];
        assert_eq!(stage.progress_percent, Some(25.0));
        assert_eq!(
            stage.progress_label.as_deref(),
            Some("solving frequency point")
        );
        let detail = stage.progress_detail.as_deref().unwrap_or_default();
        assert!(detail.contains("frequency point 1/4"));
        assert!(detail.contains("range=2.000000-5.000000 GHz"));
        assert!(detail.contains("f=2.750000 GHz"));
        assert!(detail.contains("GMRES iteration=384"));
        assert!(detail.contains("relative residual=8.500e-4"));
        assert!(stage.last_progress_unix_ms.is_some());
    }

    #[test]
    fn frequency_response_progress_survives_generic_live_update() {
        let mut state = test_workspace_state();
        state.stage_execution = Some(CurrentLiveStageExecutionState {
            total_stages: 1,
            completed_stage_indexes: Vec::new(),
            stages: vec![CurrentLiveStageExecutionRecord {
                status: "running".to_string(),
                ..CurrentLiveStageExecutionRecord::default()
            }],
            stage_statuses: vec!["running".to_string()],
            active_stage_index: Some(0),
            active_stage_kind: Some("flat_frequency_response".to_string()),
            runtime_state: "running".to_string(),
        });
        let mut progress = std::collections::HashMap::new();
        progress.insert("percent".to_string(), 14.0);
        progress.insert("frequency_index".to_string(), 1.0);
        progress.insert("completed_frequency_count".to_string(), 1.0);
        progress.insert("total_frequency_count".to_string(), 7.0);
        progress.insert("frequency_hz".to_string(), 3.0e9);
        progress.insert("frequency_min_hz".to_string(), 2.0e9);
        progress.insert("frequency_max_hz".to_string(), 5.0e9);
        progress.insert("iteration".to_string(), 64.0);
        progress.insert("max_iterations_for_frequency".to_string(), 256.0);
        progress.insert("current_frequency_solve_fraction".to_string(), 0.25);
        progress.insert("relative_residual_l2_norm".to_string(), 7.5e-3);
        progress.insert("demag_periodic_airbox_k0".to_string(), 1.0);
        let mut progress_update = test_step_update(257);
        progress_update
            .stats
            .per_object_scalars
            .insert("fem_frequency_response_progress".to_string(), progress);

        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            progress_update,
            false,
        );

        let generic_update = test_step_update(258);
        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            generic_update,
            false,
        );

        let stage = &state.stage_execution.as_ref().unwrap().stages[0];
        assert_eq!(stage.progress_percent, Some(14.0));
        assert_eq!(
            stage.progress_label.as_deref(),
            Some("solving frequency point")
        );
        let detail = stage.progress_detail.as_deref().unwrap_or_default();
        assert!(detail.contains("demag=periodic_airbox_k0"));
        assert!(detail.contains("range=2.000000-5.000000 GHz"));
        assert!(detail.contains("frequency point 2/7"));
        assert!(detail.contains("GMRES iteration=64"));
    }

    #[test]
    fn terminal_step_progress_includes_average_magnetization_components() {
        let stats = fullmag_runner::StepStats {
            step: 12,
            time: 2.5e-12,
            dt: 1.0e-14,
            mx: 0.125,
            my: -0.25,
            mz: 0.875,
            max_torque_T: 2.0e-6,
            e_total: -3.0e-19,
            max_h_eff: 1.2e5,
            wall_time_ns: 4_000_000,
            ..fullmag_runner::StepStats::default()
        };
        let expected = "m_avg=(mx=1.2500e-1 my=-2.5000e-1 mz=8.7500e-1)";

        let regular_line =
            format_stage_progress_line("stage 1/1 (relax)", &stats, None, None, None);
        let heartbeat_line = format_stage_progress_line(
            "stage 1/1 (relax)",
            &stats,
            None,
            Some(Duration::from_secs(2)),
            None,
        );

        assert!(regular_line.contains(expected), "{regular_line}");
        assert!(heartbeat_line.contains(expected), "{heartbeat_line}");
    }

    #[test]
    fn frequency_response_progress_is_visible_in_terminal_stage_line() {
        let mut progress = std::collections::HashMap::new();
        progress.insert("percent".to_string(), 14.0);
        progress.insert("frequency_index".to_string(), 1.0);
        progress.insert("completed_frequency_count".to_string(), 1.0);
        progress.insert("total_frequency_count".to_string(), 7.0);
        progress.insert("frequency_hz".to_string(), 3.0e9);
        progress.insert("frequency_min_hz".to_string(), 2.0e9);
        progress.insert("frequency_max_hz".to_string(), 5.0e9);
        progress.insert("iteration".to_string(), 64.0);
        progress.insert("max_iterations_for_frequency".to_string(), 256.0);
        progress.insert("current_frequency_solve_fraction".to_string(), 0.25);
        progress.insert("relative_residual_l2_norm".to_string(), 7.5e-3);
        progress.insert("demag_periodic_airbox_k0".to_string(), 1.0);
        let mut per_object_scalars = std::collections::HashMap::new();
        per_object_scalars.insert("fem_frequency_response_progress".to_string(), progress);
        let stats = fullmag_runner::StepStats {
            step: 257,
            max_h_eff: 1.0,
            per_object_scalars,
            ..fullmag_runner::StepStats::default()
        };

        let line = format_stage_progress_line(
            "stage 3/3 (flat_frequency_response)",
            &stats,
            None,
            Some(Duration::from_secs(8)),
            None,
        );

        assert!(line.contains("frequency sweep"));
        assert!(line.contains("freq[demag=periodic_airbox_k0 solution 2/7"));
        assert!(line.contains("[##--------------]"));
        assert!(line.contains("14%"));
        assert!(line.contains("range=2.000000-5.000000GHz"));
        assert!(line.contains("f=3.000000 GHz"));
        assert!(line.contains("GMRES=64/256"));
        assert!(line.contains("solve=25%"));
        assert!(line.contains("relres=7.500e-3"));
        assert!(line.contains("heartbeat idle=8.0s"));
        assert!(!line.contains("max_torque"));
        assert!(!line.contains("E_total"));
    }

    #[test]
    fn frequency_response_progress_is_visible_in_heartbeat_engine_log_message() {
        let mut progress = std::collections::HashMap::new();
        progress.insert("percent".to_string(), 14.0);
        progress.insert("frequency_index".to_string(), 1.0);
        progress.insert("completed_frequency_count".to_string(), 1.0);
        progress.insert("total_frequency_count".to_string(), 7.0);
        progress.insert("frequency_hz".to_string(), 3.0e9);
        progress.insert("frequency_min_hz".to_string(), 2.0e9);
        progress.insert("frequency_max_hz".to_string(), 5.0e9);
        progress.insert("iteration".to_string(), 64.0);
        progress.insert("max_iterations_for_frequency".to_string(), 256.0);
        progress.insert("current_frequency_solve_fraction".to_string(), 0.25);
        progress.insert("relative_residual_l2_norm".to_string(), 7.5e-3);
        progress.insert("demag_periodic_airbox_k0".to_string(), 1.0);
        let mut per_object_scalars = std::collections::HashMap::new();
        per_object_scalars.insert("fem_frequency_response_progress".to_string(), progress);
        let update = fullmag_runner::StepUpdate {
            coupled_checkpoint: None,
            stats: fullmag_runner::StepStats {
                step: 257,
                max_h_eff: 1.0,
                per_object_scalars,
                ..fullmag_runner::StepStats::default()
            },
            grid: [0, 0, 0],
            fem_mesh_generation_id: Some("test-generation".to_string()),
            magnetization: None,
            preview_field: None,
            cached_preview_fields: None,
            hysteresis_field_m_t: None,
            hysteresis_point_index: None,
            hysteresis_settle_step_index: None,
            hysteresis_settle_step_kind: None,
            hysteresis_settle_step_method: None,
            scalar_row_due: false,
            terminal_field_snapshot: false,
            finished: false,
            magnetization_carrier: None,
        };

        let message = format_stage_heartbeat_message(
            "Frequency response 3",
            &update.stats,
            Duration::from_secs(8),
        );

        assert!(message.contains("Frequency response 3"));
        assert!(message.contains("waiting 8.0s for the next solver update"));
        assert!(message.contains("freq[demag=periodic_airbox_k0 solution 2/7"));
        assert!(message.contains("[##--------------]"));
        assert!(message.contains("14%"));
        assert!(message.contains("GMRES=64/256"));
        assert!(message.contains("solve=25%"));
        assert!(message.contains("relres=7.500e-3"));
    }

    #[test]
    fn initial_frequency_response_progress_is_visible_in_terminal_heartbeat_line() {
        let mut progress = std::collections::HashMap::new();
        progress.insert("percent".to_string(), 0.0);
        progress.insert("frequency_index".to_string(), 0.0);
        progress.insert("completed_frequency_count".to_string(), 0.0);
        progress.insert("total_frequency_count".to_string(), 7.0);
        progress.insert("frequency_hz".to_string(), 2.0e9);
        progress.insert("frequency_min_hz".to_string(), 2.0e9);
        progress.insert("frequency_max_hz".to_string(), 5.0e9);
        progress.insert("demag_periodic_airbox_k0".to_string(), 1.0);
        let mut per_object_scalars = std::collections::HashMap::new();
        per_object_scalars.insert("fem_frequency_response_progress".to_string(), progress);
        let stats = fullmag_runner::StepStats {
            step: 257,
            max_h_eff: 1.0,
            per_object_scalars,
            ..fullmag_runner::StepStats::default()
        };

        let line = format_stage_progress_line(
            "stage 3/3 (flat_frequency_response)",
            &stats,
            None,
            Some(Duration::from_secs(8)),
            None,
        );

        assert!(line.contains("heartbeat"));
        assert!(line.contains("frequency sweep"));
        assert!(line.contains("freq[demag=periodic_airbox_k0 solution 1/7"));
        assert!(line.contains("[----------------]"));
        assert!(line.contains("0%"));
        assert!(line.contains("range=2.000000-5.000000GHz"));
        assert!(line.contains("f=2.000000 GHz"));
        assert!(!line.contains("max_torque"));
        assert!(!line.contains("E_total"));
    }

    #[test]
    fn stage_heartbeat_initializes_progress_when_solver_has_not_reported() {
        let mut stage = CurrentLiveStageExecutionRecord::default();

        apply_stage_heartbeat_progress(&mut stage, Duration::from_millis(8_500));

        assert_eq!(stage.progress_percent, Some(35.0));
        assert_eq!(stage.progress_label.as_deref(), Some("solving"));
        assert_eq!(
            stage.progress_detail.as_deref(),
            Some("heartbeat 8.5s since last solver update")
        );
        assert!(stage.last_progress_unix_ms.is_some());
    }

    #[test]
    fn scripted_frequency_domain_stages_use_live_callback_heartbeat() {
        let source = include_str!("orchestrator.rs");

        let fem_eigen_live_callback_matches =
            source.matches("| BackendPlanIR::FemEigen(_)").count();
        let frequency_response_live_callback_matches = source
            .matches("| BackendPlanIR::FemFrequencyResponse(_)")
            .count();
        assert!(
            fem_eigen_live_callback_matches >= 2,
            "FEM eigensolve scripted and interactive stages must stay on the live callback path so stage execution receives heartbeat progress while no step telemetry exists"
        );
        assert!(
            frequency_response_live_callback_matches >= 2,
            "FEM frequency-response scripted and interactive stages must stay on the live callback path so solver progress callbacks reach stage execution"
        );
    }

    #[test]
    fn stage_heartbeat_applies_lightweight_progress_without_full_live_ingest() {
        let source = include_str!("orchestrator.rs");
        let heartbeat_block = source
            .split("let heartbeat_message =")
            .nth(1)
            .and_then(|tail| tail.split("upsert_engine_log_tail(").next())
            .expect("heartbeat publish block should stay visible to the contract test");

        assert!(
            heartbeat_block.contains("progress.apply_to_live_step("),
            "heartbeat publishing must update scalar progress through its lightweight state"
        );
        assert!(!heartbeat_block.contains("apply_live_step_update_to_workspace_state("));
    }

    #[test]
    fn synthetic_scripted_stages_publish_terminal_stage_execution() {
        let source = include_str!("orchestrator.rs");

        assert!(
            source.contains("let synthetic_completed_at_unix_ms = unix_time_millis()?;"),
            "synthetic stages must capture a completion timestamp before they skip the common solver-stage finalization path"
        );
        assert!(
            source.contains("state.stage_execution = Some(scripted_stage_execution_state(\n                    stage_count,\n                    stage_index,\n                    &stage.entrypoint_kind,\n                    \"completed\","),
            "synthetic stages must publish completed stage_execution before continuing to the next scripted stage"
        );
    }

    #[test]
    fn hysteresis_study_uses_canonical_live_runner_not_persistent_runtime() {
        let source = include_str!("orchestrator.rs");

        assert!(
            source.contains(
                "let hysteresis_study = matches!(&stage.ir.study, StudyIR::Hysteresis { .. });"
            ),
            "interactive execution must identify hysteresis studies before runtime selection"
        );
        assert!(
            source.contains("if hysteresis_study {\n                        fullmag_runner::run_planned_problem_with_live_preview_interruptible_with_initial_snapshot"),
            "hysteresis studies must use the canonical hysteresis runner with live preview"
        );
        assert!(
            source.contains("} else if let Some(runtime) = interactive_runtime_host.runtime_mut()"),
            "persistent interactive runtime must remain a non-hysteresis execution path"
        );
    }

    #[test]
    fn disable_preview_3d_disables_runner_preview_inputs() {
        let source = include_str!("orchestrator.rs");

        assert!(
            source.contains(
                "let preview_3d_disabled = crate::live_workspace::feature_flags().disable_preview_3d;"
            ),
            "orchestrator must resolve the preview-disabled benchmark flag once"
        );
        assert!(
            source.contains("resolve_preview_field_every_n(\n        preview_3d_disabled"),
            "preview-disabled benchmark mode must disable heavy payload cadence"
        );
        assert!(
            source.contains("!args.headless && !preview_3d_disabled")
                && source.contains("!preview_3d_disabled"),
            "preview-disabled benchmark mode must also disable initial 3D preview snapshots"
        );
    }

    #[test]
    fn preview_matrix_cadence_override_is_positive_and_explicit() {
        assert_eq!(
            resolve_preview_field_every_n(false, "fem", Some("25")).unwrap(),
            25
        );
        assert_eq!(
            resolve_preview_field_every_n(false, "fem", None).unwrap(),
            10
        );
        assert_eq!(
            resolve_preview_field_every_n(false, "fdm", None).unwrap(),
            50
        );
        assert_eq!(
            resolve_preview_field_every_n(true, "fem", Some("25")).unwrap(),
            u64::MAX
        );
        assert!(resolve_preview_field_every_n(false, "fem", Some("0")).is_err());
        assert!(resolve_preview_field_every_n(false, "fem", Some("not-a-number")).is_err());
    }

    #[test]
    fn interactive_compute_reuses_materialized_execution_plan_snapshot() {
        let source = include_str!("orchestrator.rs");

        assert!(
            source.contains(".zip(stage_execution_plans.into_iter())"),
            "interactive stage execution must carry the materialized plan beside each stage"
        );
        assert!(
            source.contains("let materialized_stage_ir = stage.ir.clone();")
                && source.contains("if stage.ir == materialized_stage_ir")
                && source.contains("materialized_execution_plan"),
            "interactive compute must reuse the materialized plan when the stage IR did not change"
        );
        assert!(
            source.contains(
                "fullmag_runner::run_planned_problem_with_live_preview_interruptible_with_initial_snapshot"
            ) && source.contains("fullmag_runner::run_planned_problem_with_callback")
                && source.contains("fullmag_runner::run_planned_problem(")
                && source.contains(
                    "fullmag_runner::run_planned_problem_with_interactive_runtime_live_preview_interruptible"
                ),
            "interactive compute must call plan-aware runner APIs instead of re-planning on compute"
        );
        assert!(
            source.contains("interactive_runtime_host.ensure_runtime_for_problem(")
                && source.contains("&execution_plan,"),
            "persistent interactive runtime setup must receive the current materialized execution plan"
        );
        assert!(
            source.contains("refresh_materialized_stage_execution_plans(")
                && source.contains("execute_manual_interactive_remesh(")
                && source.contains("&mut stages,")
                && source.contains("&mut stage_execution_plans,"),
            "interactive remesh must mutate both stage IR snapshots and materialized execution plans"
        );
        assert!(
            source.contains("interactive_template_ir = remesh_stages.remove(0).ir;")
                && source.contains(
                    "Some(&mut interactive_runtime_host)"
                ),
            "post-script interactive remesh must update the base problem used by later run/relax commands"
        );
        let remesh_source = include_str!("orchestrator/manual_remesh.rs");
        assert!(
            remesh_source.contains("*continuation = None;")
                && remesh_source.contains("*continuation_source = None;")
                && remesh_source.contains("*continuation_completion = None;"),
            "interactive remesh must not let old-mesh continuation magnetization override the refreshed solver mesh"
        );
        assert!(
            source.contains("resolve_planned_runtime_engine(problem, plan)")
                && source.contains("resolve_planned_runtime_capabilities(problem, plan)"),
            "live metadata must resolve runtime information from the materialized plan"
        );
    }

    #[test]
    fn production_interactive_route_threads_authoritative_fem_mesh_asset() {
        let orchestrator = include_str!("orchestrator.rs");
        let host = include_str!("interactive_runtime_host.rs");
        let runner = include_str!("../../fullmag-runner/src/lib.rs");

        assert!(orchestrator.contains(
            "ensure_runtime_for_problem(\n                            &stage.ir,\n                            &execution_plan,\n                            stage_fem_mesh_asset.as_ref(),\n                            field_every_n,"
        ));
        assert!(host.contains("stage_fem_mesh_asset: Option<&fullmag_runner::StageFemMeshAsset>"));
        assert!(host.contains(
            "create_planned_interactive_runtime_with_stage_fem_mesh_asset_and_preview_cadence("
        ));
        assert!(
            runner.contains(
                "pub fn create_planned_interactive_runtime_with_stage_fem_mesh_asset_and_preview_cadence("
            )
        );
    }

    #[test]
    fn continue_in_place_stage_does_not_allow_sampled_continuation_initial_state() {
        let mut stage =
            ResolvedScriptStage::solver(tiny_problem_with_shared_domain_asset(), 1e-12, "flat_run");
        stage.incoming_transition = Some(StageTransitionMetadata::continue_in_place());

        assert!(
            !stage_allows_sampled_continuation_initial_state(&stage),
            "continue_in_place must preserve runtime state instead of injecting final_magnetization into ProblemIR"
        );
    }

    #[test]
    fn fem_gpu_preflight_reports_available_vram() {
        let status = fullmag_runner::NativeFemGpuStatus {
            built_with_mfem_stack: true,
            built_with_cuda_runtime: true,
            built_with_ceed: true,
            reason_cpu: "native FEM CPU fixture".to_owned(),
            cpu_available: true,
            available: true,
            visible_cuda_device_count: 1,
            requested_gpu_index: -1,
            resolved_gpu_index: 0,
            memory_free_bytes: 18_000_000_000,
            memory_total_bytes: 24_000_000_000,
            reason_gpu: "native FEM GPU backend is available".to_string(),
        };

        let (level, message) = fem_gpu_memory_preflight_message(8_400_000_000, &status);

        assert_eq!(level, "info");
        assert_eq!(
            message,
            "GPU VRAM: 18.0 GB / 24.0 GB free on CUDA device 0 · Est. FEM memory: 8.4 GB"
        );
    }

    #[test]
    fn fem_gpu_preflight_reports_native_availability_reason() {
        let status = fullmag_runner::NativeFemGpuStatus {
            built_with_mfem_stack: true,
            built_with_cuda_runtime: true,
            built_with_ceed: true,
            reason_cpu: "native FEM CPU fixture".to_owned(),
            cpu_available: false,
            available: false,
            visible_cuda_device_count: 0,
            requested_gpu_index: -1,
            resolved_gpu_index: -1,
            memory_free_bytes: 0,
            memory_total_bytes: 0,
            reason_gpu: "cudaGetDeviceCount failed for fullmag_fem: CUDA driver version is insufficient for CUDA runtime version".to_string(),
        };

        let (level, message) = fem_gpu_memory_preflight_message(8_400_000_000, &status);

        assert_eq!(level, "warn");
        assert_eq!(
            message,
            "GPU requested, but native FEM GPU is unavailable: cudaGetDeviceCount failed for fullmag_fem: CUDA driver version is insufficient for CUDA runtime version · visible CUDA devices: 0"
        );
    }

    #[test]
    fn fem_interactive_dense_ram_estimate_skips_poisson_airbox_demag() {
        let mut plan = match tiny_fem_plan() {
            BackendPlanIR::Fem(plan) => plan,
            _ => unreachable!("test helper returns a FEM plan"),
        };
        plan.demag_realization = Some(fullmag_ir::ResolvedFemDemagIR::PoissonRobin);

        assert_eq!(fem_interactive_dense_ram_estimate(&plan), None);
    }

    #[test]
    fn fem_interactive_dense_ram_estimate_keeps_legacy_dense_demag_guard() {
        let plan = match tiny_fem_plan() {
            BackendPlanIR::Fem(plan) => plan,
            _ => unreachable!("test helper returns a FEM plan"),
        };

        assert!(fem_interactive_dense_ram_estimate(&plan).is_some());
    }

    #[test]
    fn mesh_build_pipeline_status_publishes_active_gmsh_progress() {
        let phases = mesh_build_pipeline_status_json(
            Some("meshing"),
            false,
            None,
            Some(75),
            Some("generating 3D mesh"),
            Some(420),
            &[("queued".to_string(), 12)],
            None,
        );
        let phases = phases
            .as_array()
            .expect("pipeline status should be an array");
        let meshing = phases
            .iter()
            .find(|phase| phase.get("id").and_then(|value| value.as_str()) == Some("meshing"))
            .expect("meshing phase should be present");

        assert_eq!(meshing["progress_percent"], 75);
        assert_eq!(meshing["progress_label"], "generating 3D mesh");
        assert_eq!(meshing["duration_ms"], 420);
        assert_eq!(phases[0]["duration_ms"], 12);
        assert_eq!(
            phases
                .iter()
                .filter(|phase| phase.get("progress_percent").is_some())
                .count(),
            1
        );
    }

    #[test]
    fn mesh_build_overlay_keeps_last_successful_artifact_during_new_attempt() {
        let last_success = serde_json::json!({
            "build_id": "mesh:previous-success",
            "status": "completed",
            "source_scene_revision": 12
        });
        let airbox_target = serde_json::json!({ "hmax": "5e-9" });
        let per_object_targets = serde_json::json!({
            "film": { "hmax": "2e-9" }
        });
        let mut workspace = serde_json::json!({
            "last_build_summary": last_success,
            "effective_airbox_target": airbox_target,
            "effective_per_object_targets": per_object_targets,
            "last_build_error": "an earlier build failed"
        });
        let mut overlay = super::CurrentMeshBuildOverlay {
            active_build: Some(serde_json::json!({ "build_id": "mesh:next-attempt" })),
            effective_airbox_target: None,
            effective_per_object_targets: None,
            last_build_summary: None,
            last_build_error: None,
            active_phase: Some("meshing".to_string()),
            progress_percent: None,
            progress_label: None,
            attempt_index: None,
            algorithm_3d: None,
            attempt_status: None,
            attempt_failure_reason: None,
            next_algorithm_3d: None,
            progress_kind: None,
            last_recoverable_attempt: None,
            phase_started_at: Instant::now(),
            phase_durations_ms: Vec::new(),
            failed: false,
        };

        super::overlay_mesh_workspace(&mut workspace, &overlay);

        assert_eq!(
            workspace["last_build_summary"]["build_id"],
            "mesh:previous-success"
        );
        assert_eq!(workspace["effective_airbox_target"], airbox_target);
        assert_eq!(
            workspace["effective_per_object_targets"],
            per_object_targets
        );
        assert!(workspace["last_build_error"].is_null());
        assert_eq!(workspace["active_build"]["build_id"], "mesh:next-attempt");

        overlay.active_build = None;
        overlay.effective_airbox_target = Some(serde_json::Value::Null);
        overlay.effective_per_object_targets = Some(serde_json::Value::Null);
        overlay.last_build_summary = Some(serde_json::json!({
            "build_id": "mesh:next-success",
            "status": "completed"
        }));
        super::overlay_mesh_workspace(&mut workspace, &overlay);

        assert_eq!(
            workspace["last_build_summary"]["build_id"],
            "mesh:next-success"
        );
        assert!(workspace["effective_airbox_target"].is_null());
        assert!(workspace["effective_per_object_targets"].is_null());
    }

    #[test]
    fn manual_remesh_attempt_survives_indeterminate_heartbeats_and_retry() {
        let mut overlay = super::CurrentMeshBuildOverlay {
            active_build: Some(serde_json::json!({"target": "study_domain"})),
            effective_airbox_target: None,
            effective_per_object_targets: None,
            last_build_summary: None,
            last_build_error: None,
            active_phase: Some("meshing".to_string()),
            progress_percent: Some(75),
            progress_label: Some("legacy heuristic".to_string()),
            attempt_index: None,
            algorithm_3d: None,
            attempt_status: None,
            attempt_failure_reason: None,
            next_algorithm_3d: None,
            progress_kind: None,
            last_recoverable_attempt: None,
            phase_started_at: Instant::now(),
            phase_durations_ms: Vec::new(),
            failed: false,
        };

        assert!(super::update_mesh_attempt_overlay_from_payload(
            &mut overlay,
            "mesh_build_phase",
            &serde_json::json!({
                "phase": "meshing",
                "attempt_index": 1,
                "algorithm_3d": "Delaunay",
                "attempt_status": "active",
                "progress_label": "Attempt 1 — Delaunay — progress indeterminate",
            }),
        ));
        super::update_mesh_overlay_from_terminal_progress(
            &mut overlay,
            super::RemeshTerminalProgress {
                percent: None,
                label: "generating 3D mesh",
            },
        );
        assert_eq!(overlay.progress_percent, None);
        assert_eq!(
            overlay.progress_label.as_deref(),
            Some("Attempt 1 — Delaunay — generating 3D mesh")
        );

        assert!(super::update_mesh_attempt_overlay_from_payload(
            &mut overlay,
            "mesh_build_phase",
            &serde_json::json!({
                "phase": "meshing",
                "attempt_index": 1,
                "algorithm_3d": "Delaunay",
                "attempt_status": "failed_recoverable",
                "attempt_failure_reason": "degenerate tetra volume",
                "next_algorithm_3d": "Frontal",
                "progress_kind": "indeterminate",
                "progress_label": "Attempt 1 — Delaunay — failed; retrying",
            }),
        ));
        assert!(super::update_mesh_attempt_overlay_from_payload(
            &mut overlay,
            "mesh_build_phase",
            &serde_json::json!({
                "phase": "meshing",
                "attempt_index": 2,
                "algorithm_3d": "Frontal",
                "attempt_status": "active",
                "progress_label": "Attempt 2 — Frontal — progress indeterminate",
            }),
        ));
        super::update_mesh_overlay_from_terminal_progress(
            &mut overlay,
            super::RemeshTerminalProgress {
                percent: None,
                label: "generating 3D mesh",
            },
        );

        assert_eq!(overlay.attempt_index, Some(2));
        assert_eq!(overlay.algorithm_3d.as_deref(), Some("Frontal"));
        assert_eq!(overlay.attempt_status.as_deref(), Some("active"));
        assert_eq!(
            overlay.last_recoverable_attempt.as_ref().unwrap()["attempt_failure_reason"],
            "degenerate tetra volume"
        );
        assert_eq!(
            overlay.last_recoverable_attempt.as_ref().unwrap()["next_algorithm_3d"],
            "Frontal"
        );
        assert_eq!(overlay.progress_percent, None);
        assert_eq!(
            overlay.progress_label.as_deref(),
            Some("Attempt 2 — Frontal — generating 3D mesh")
        );
        let mut workspace = serde_json::json!({});
        super::overlay_mesh_workspace(&mut workspace, &overlay);
        let meshing = workspace["mesh_pipeline_status"]
            .as_array()
            .and_then(|phases| phases.iter().find(|phase| phase["id"] == "meshing"))
            .expect("meshing phase");
        assert_eq!(meshing["attempt_index"], 2);
        assert_eq!(meshing["algorithm_3d"], "Frontal");
        assert_eq!(meshing["attempt_status"], "active");
        assert_eq!(
            workspace["active_build"]["last_recoverable_attempt"]["attempt_failure_reason"],
            "degenerate tetra volume"
        );
        assert!(meshing.get("progress_percent").is_none());
    }

    #[test]
    fn heavy_live_payload_forces_publish_without_waiting_for_heartbeat() {
        let mut cadence = LiveProgressCadence::default();
        let baseline = test_step_update(2);
        assert!(cadence.should_publish(&baseline));

        let mut heavy = test_step_update(3);
        heavy.preview_field = Some(LivePreviewField {
            config_revision: 1,
            source_step: 0,
            source_time_seconds: None,
            source_revision: 1,
            materialized_at_unix_ms: 0,
            materialization_wall_time_ns: 0,
            quantity: "m".to_string(),
            unit: "A/m".to_string(),
            spatial_kind: "grid".to_string(),
            quantity_domain: "vector".to_string(),
            preview_grid: [1, 1, 1],
            original_grid: [1, 1, 1],
            vector_field_values: vec![0.0, 0.0, 1.0],
            x_chosen_size: 1,
            y_chosen_size: 1,
            applied_x_chosen_size: 1,
            applied_y_chosen_size: 1,
            applied_layer_stride: 1,
            auto_downscaled: false,
            auto_downscale_message: None,
            active_mask: None,
        });

        assert!(has_heavy_live_payload(&heavy));
        assert!(cadence.should_publish(&heavy));
    }

    #[test]
    fn frequency_response_progress_forces_publish_and_log_without_heavy_payload() {
        let mut cadence = LiveProgressCadence::default();
        cadence.last_publish_at = Some(Instant::now());
        cadence.last_log_at = Some(Instant::now());
        let mut progress = std::collections::HashMap::new();
        progress.insert("percent".to_string(), 14.0);
        progress.insert("frequency_index".to_string(), 1.0);
        progress.insert("completed_frequency_count".to_string(), 1.0);
        progress.insert("total_frequency_count".to_string(), 7.0);
        progress.insert("frequency_hz".to_string(), 3.0e9);
        let mut update = test_step_update(257);
        update
            .stats
            .per_object_scalars
            .insert(FEM_FREQUENCY_RESPONSE_PROGRESS_KEY.to_string(), progress);

        assert!(!has_heavy_live_payload(&update));
        assert!(step_update_has_frequency_response_progress(&update));
        assert!(cadence.should_publish(&update));
        assert!(cadence.should_log(&update));
    }

    #[test]
    fn parallel_admission_progress_forces_publish_without_waiting_for_heartbeat() {
        let mut cadence = LiveProgressCadence::default();
        cadence.last_publish_at = Some(Instant::now());
        let mut progress = std::collections::HashMap::new();
        progress.insert("parallel_telemetry_available".to_string(), 1.0);
        let mut update = test_step_update(257);
        set_fem_eigen_progress(&mut update.stats, progress);

        assert!(!has_heavy_live_payload(&update));
        assert!(step_update_has_parallel_execution_progress(&update));
        assert!(cadence.should_publish(&update));
    }

    #[test]
    fn heartbeat_publish_triggers_after_wall_clock_interval() {
        let mut cadence = LiveProgressCadence::default();
        let update = test_step_update(2);
        cadence.last_publish_at = Some(Instant::now());
        assert!(!cadence.should_publish(&update));

        cadence.last_publish_at = Some(Instant::now() - LIVE_PROGRESS_PUBLISH_INTERVAL);
        assert!(cadence.should_publish(&update));
    }

    #[test]
    fn publish_live_step_update_tracks_preview_cache_from_runner_updates() {
        let mut state = test_workspace_state();
        let mut update = test_step_update(12);
        update.preview_field = Some(test_preview_field("m", 3, 1.0));
        update.cached_preview_fields = Some(vec![
            test_preview_field("m", 3, 1.0),
            test_preview_field("h_eff", 3, 2.0),
        ]);

        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            update,
            true,
        );

        assert_eq!(state.live_state.latest_step.step, 12);
        assert!(state.live_state.latest_step.preview_field.is_none());
        assert!(state.preview_fields.is_empty());
        assert!(state.latest_fields.is_empty());
        assert_eq!(state.pending_preview_fields.to_vec().len(), 2);
        assert_eq!(
            state.latest_scalar_row.as_ref().map(|row| row.step),
            Some(12)
        );
        let delta = state.publish_delta();
        assert_eq!(delta.preview_fields.as_ref().map(Vec::len), Some(2));
        assert_eq!(state.preview_fields.to_vec().len(), 2);
    }

    #[test]
    fn terminal_scripted_update_bypasses_table_autosave_period() {
        let mut state = test_workspace_state();
        state.metadata = Some(serde_json::json!({
            "table_autosave": { "sample_period_s": 1.0 }
        }));
        let mut previous = test_step_update(4);
        previous.stats.time = 0.25;
        previous.stats.mx = 1.0;
        set_latest_scalar_row_if_due(&mut state, &previous);

        let mut terminal = test_step_update(5);
        terminal.stats.time = 0.5;
        terminal.stats.mx = 0.0;
        terminal.stats.my = 1.0;
        terminal.stats.e_total = 7.0;
        terminal.finished = false;

        let _ = apply_terminal_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            terminal,
        );

        let row = state.latest_scalar_row.expect("terminal scalar row");
        assert_eq!(row.step, 5);
        assert_eq!(row.time, 0.5);
        assert_eq!([row.mx, row.my, row.mz], [0.0, 1.0, 0.0]);
        assert_eq!(row.e_total, 7.0);
    }

    #[test]
    fn synthetic_final_magnetization_is_published_with_step_provenance() {
        let mut state = test_workspace_state();
        state.latest_fields.insert(
            "m".to_string(),
            serde_json::json!({
                "quantity": "m",
                "unit": "1",
                "values": [1.0, 0.0, 0.0],
                "source_step": 0,
                "source_revision": 1,
            }),
        );
        let mut update = test_step_update(342);
        update.grid = [128, 32, 1];
        update.magnetization = Some(vec![0.0, 1.0, 0.0]);

        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            update,
            true,
        );

        let field = state
            .latest_fields
            .0
            .get("m")
            .expect("magnetization must be published as a latest field");
        assert_eq!(field["source_step"], serde_json::json!(342));
        assert_eq!(field["source_revision"], serde_json::json!(342));
        assert_eq!(
            field["layout"]["grid_cells"],
            serde_json::json!([128, 32, 1])
        );
        assert_eq!(field["values"], serde_json::json!([0.0, 1.0, 0.0]));
    }

    #[test]
    fn terminal_fdm_fields_replace_the_previous_generation_and_preserve_grid_m() {
        let mut state = test_workspace_state();
        state.latest_fields.insert(
            "H_dmi".to_string(),
            serde_json::json!({
                "quantity": "H_dmi",
                "values": [[1.0, 0.0, 0.0]],
                "layout": { "grid_cells": [2, 1, 1], "spatial_kind": "grid" }
            }),
        );
        let mut terminal = test_step_update(12);
        terminal.grid = [2, 1, 1];
        terminal.finished = true;
        terminal.magnetization = Some(vec![0.0, 0.0, 1.0, 0.0, 1.0, 0.0]);
        let mut m = test_preview_field("m", 12, 1.0);
        m.spatial_kind = "grid".to_string();
        m.preview_grid = [2, 1, 1];
        m.original_grid = [2, 1, 1];
        m.vector_field_values = vec![0.0, 0.0, 1.0, 0.0, 1.0, 0.0];
        let mut h_eff = test_preview_field("H_eff", 12, 2.0);
        h_eff.spatial_kind = "grid".to_string();
        h_eff.preview_grid = [2, 1, 1];
        h_eff.original_grid = [2, 1, 1];
        h_eff.vector_field_values = vec![0.0, 0.0, 2.0, 0.0, 0.0, 2.0];
        let mut eden_demag = test_preview_field("eden_demag", 12, 3.0);
        eden_demag.unit = "J/m³".to_string();
        eden_demag.spatial_kind = "grid".to_string();
        eden_demag.quantity_domain = "magnetic_only".to_string();
        eden_demag.preview_grid = [2, 1, 1];
        eden_demag.original_grid = [2, 1, 1];
        eden_demag.vector_field_values = vec![3.0, 4.0];
        terminal.stats.time = 1.2e-12;
        terminal.cached_preview_fields = Some(vec![m, h_eff, eden_demag]);

        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            terminal,
            true,
        );

        assert!(state.latest_fields.0.get("H_dmi").is_none());
        assert_eq!(
            state.latest_fields.0["m"]["layout"]["spatial_kind"],
            serde_json::json!("grid")
        );
        assert_eq!(
            state.latest_fields.0["eden_demag"]["source_step"],
            serde_json::json!(12)
        );
        assert_eq!(
            state.latest_fields.0["eden_demag"]["source_time_seconds"],
            serde_json::json!(1.2e-12)
        );
        assert_eq!(
            state.latest_fields.0["eden_demag"]["unit"],
            serde_json::json!("J/m³")
        );
        let payload =
            serde_json::to_value(state.publish_delta()).expect("terminal payload serializes");
        assert_eq!(payload["replace_latest_fields"], serde_json::json!(true));
        assert_eq!(
            payload["field_generation"]["run_id"],
            serde_json::json!("run-test")
        );
        assert!(payload["field_generation"]["sequence"]
            .as_u64()
            .is_some_and(|sequence| sequence > 0));
    }

    #[test]
    fn interactive_terminal_field_snapshot_keeps_generation_while_run_awaits_command() {
        let mut state = test_workspace_state();
        let mut terminal = test_step_update(12);
        terminal.grid = [2, 1, 2];
        terminal.finished = false;
        let mut eden_demag = test_preview_field("eden_demag", 12, 3.0);
        eden_demag.unit = "J/m³".to_string();
        eden_demag.spatial_kind = "grid".to_string();
        eden_demag.quantity_domain = "magnetic_only".to_string();
        eden_demag.preview_grid = [2, 1, 2];
        eden_demag.original_grid = [2, 1, 2];
        eden_demag.vector_field_values = vec![3.0, 4.0, 30.0, 40.0];
        eden_demag.materialized_at_unix_ms = 17;
        let mut eden_total = eden_demag.clone();
        eden_total.quantity = "eden_total".to_string();
        eden_total.vector_field_values = vec![7.0, 8.0, 70.0, 80.0];
        let mut mat_ms = eden_demag.clone();
        mat_ms.quantity = "mat_ms".to_string();
        mat_ms.unit = "A/m".to_string();
        mat_ms.vector_field_values = vec![9.0, 10.0, 90.0, 100.0];
        let mut e_total = eden_demag.clone();
        e_total.quantity = "e_total".to_string();
        e_total.unit = "J".to_string();
        e_total.preview_grid = [1, 1, 1];
        e_total.vector_field_values = vec![11.0];
        terminal.stats.time = 2.5e-12;
        terminal.cached_preview_fields = Some(vec![eden_demag, eden_total, mat_ms, e_total]);
        terminal.terminal_field_snapshot = true;

        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            terminal,
            true,
        );

        assert_eq!(state.session.status, "running");
        assert_eq!(
            state.latest_fields.0["eden_demag"]["source_step"],
            serde_json::json!(12)
        );
        assert_eq!(
            state.latest_fields.0["eden_demag"]["source_time_seconds"],
            serde_json::json!(2.5e-12)
        );
        assert_eq!(
            state.latest_fields.0["eden_demag"]["layout"]["grid_cells"],
            serde_json::json!([2, 1, 2])
        );
        assert_eq!(
            state.latest_fields.0["eden_demag"]["values"],
            serde_json::json!([3.0, 4.0, 30.0, 40.0])
        );
        assert_eq!(
            state.latest_fields.0["eden_total"]["values"],
            serde_json::json!([7.0, 8.0, 70.0, 80.0])
        );
        assert_eq!(
            state.latest_fields.0["mat_ms"]["values"],
            serde_json::json!([9.0, 10.0, 90.0, 100.0])
        );
        assert!(state.latest_fields.0.get("e_total").is_none());
        assert!(state.field_generation.is_some());
        assert!(state.replace_latest_fields);
    }

    #[test]
    fn async_materialized_field_batches_merge_without_terminal_replacement() {
        let mut state = test_workspace_state();
        state.latest_fields.insert(
            "m".to_string(),
            serde_json::json!({
                "quantity": "m",
                "values": [[1.0, 0.0, 0.0]],
                "layout": { "grid_cells": [1, 1, 1], "spatial_kind": "mesh" }
            }),
        );

        let mut first = test_step_update(12);
        let mut h_demag = test_preview_field("H_demag", 12, 2.0);
        h_demag.quantity_domain = "magnetic_only".to_string();
        h_demag.materialized_at_unix_ms = 17;
        first.cached_preview_fields = Some(vec![h_demag]);
        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            first,
            true,
        );

        assert!(state.latest_fields.0.contains_key("m"));
        assert!(state
            .pending_preview_fields
            .to_vec()
            .iter()
            .any(|field| field.quantity == "H_demag"));
        assert!(!state.replace_latest_fields);
        assert!(state.field_generation.is_none());
        assert!(!state.clear_preview_cache);

        let mut second = test_step_update(12);
        let mut h_ex = test_preview_field("H_ex", 13, 3.0);
        h_ex.quantity_domain = "magnetic_only".to_string();
        h_ex.materialized_at_unix_ms = 18;
        second.cached_preview_fields = Some(vec![h_ex]);
        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            second,
            true,
        );

        assert!(state.latest_fields.0.contains_key("m"));
        let pending_quantities = state
            .pending_preview_fields
            .to_vec()
            .into_iter()
            .map(|field| field.quantity)
            .collect::<std::collections::BTreeSet<_>>();
        assert!(pending_quantities.contains("H_demag"));
        assert!(pending_quantities.contains("H_ex"));
        assert!(!state.replace_latest_fields);
        assert!(state.field_generation.is_none());
        assert!(!state.clear_preview_cache);
    }

    #[test]
    fn interactive_terminal_field_snapshot_does_not_promote_an_ambiguous_scalar_plane() {
        let mut state = test_workspace_state();
        let mut terminal = test_step_update(12);
        terminal.grid = [2, 1, 2];
        terminal.finished = false;
        let mut eden_demag = test_preview_field("eden_demag", 12, 3.0);
        eden_demag.unit = "J/m³".to_string();
        eden_demag.spatial_kind = "grid".to_string();
        eden_demag.quantity_domain = "magnetic_only".to_string();
        eden_demag.preview_grid = [2, 1, 1];
        eden_demag.original_grid = [2, 1, 2];
        eden_demag.vector_field_values = vec![3.0, 4.0];
        eden_demag.materialized_at_unix_ms = 17;
        terminal.cached_preview_fields = Some(vec![eden_demag]);
        terminal.terminal_field_snapshot = true;

        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            terminal,
            true,
        );

        assert!(state.latest_fields.0.get("eden_demag").is_none());
        assert!(state.field_generation.is_some());
        assert!(state.replace_latest_fields);
    }

    #[test]
    fn publish_live_step_update_preserves_previous_magnetization_when_payload_is_thin() {
        let mut state = test_workspace_state();
        state.live_state.latest_step.magnetization = Some(vec![1.0, 0.0, 0.0]);

        let update = test_step_update(13);
        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            update,
            true,
        );

        assert_eq!(
            state.live_state.latest_step.magnetization,
            Some(vec![1.0, 0.0, 0.0])
        );
    }

    #[test]
    fn production_ingest_preserves_large_retained_magnetization_by_pointer() {
        let mut state = test_workspace_state();
        state.live_state.latest_step.magnetization = Some(vec![1.0; 3_000_000]);
        let retained_ptr = state
            .live_state
            .latest_step
            .magnetization
            .as_ref()
            .unwrap()
            .as_ptr();
        let publisher = crate::live_workspace::CurrentLivePublisher::spawn_with_test_sink(
            "production-retained-magnetization-ingest",
            |_, _| Ok(()),
        );
        let workspace = crate::live_workspace::LocalLiveWorkspace::new(state, publisher);
        let mut callback_durations = Vec::new();

        for step in 1..=5 {
            let update = test_step_update(step);
            let mut observed_ptr = std::ptr::null();
            let started = Instant::now();
            workspace.update_profiled(|state| {
                let _ = apply_live_step_update_to_workspace_state(
                    state,
                    "run-test",
                    "session-test",
                    PathBuf::from("/tmp/artifacts").as_path(),
                    update,
                    false,
                );
                observed_ptr = state
                    .live_state
                    .latest_step
                    .magnetization
                    .as_ref()
                    .unwrap()
                    .as_ptr();
            });
            callback_durations.push(started.elapsed());
            assert_eq!(
                observed_ptr, retained_ptr,
                "thin ingest must preserve Vec ownership"
            );
        }

        callback_durations.sort_unstable();
        assert!(callback_durations[callback_durations.len() - 1] < Duration::from_millis(10));
    }

    #[test]
    fn production_ingest_moves_large_preview_into_single_pending_owner() {
        let publisher = crate::live_workspace::CurrentLivePublisher::spawn_with_test_sink(
            "production-preview-ingest",
            |_, _| Ok(()),
        );
        let workspace =
            crate::live_workspace::LocalLiveWorkspace::new(test_workspace_state(), publisher);
        let mut callback_durations = Vec::new();

        for step in 1..=5 {
            let mut preview = test_preview_field("h_eff", step, 2.0);
            preview.vector_field_values = vec![step as f64; 3_000_000];
            let input_ptr = preview.vector_field_values.as_ptr();
            let mut update = test_step_update(step);
            update.preview_field = Some(preview);
            let mut observed_ptr = std::ptr::null();
            let started = Instant::now();
            workspace.update_profiled(|state| {
                let _ = apply_live_step_update_to_workspace_state(
                    state,
                    "run-test",
                    "session-test",
                    PathBuf::from("/tmp/artifacts").as_path(),
                    update,
                    false,
                );
                observed_ptr = state
                    .pending_preview_fields
                    .vector_values_ptr("h_eff")
                    .unwrap();
                assert_ne!(
                    state.preview_fields.vector_values_ptr("h_eff"),
                    Some(input_ptr),
                    "the current preview must not be cloned into the persistent cache in callback"
                );
                assert!(state.latest_fields.is_empty());
            });
            callback_durations.push(started.elapsed());
            assert_eq!(
                observed_ptr, input_ptr,
                "preview Vec must move into pending cache"
            );
        }

        callback_durations.sort_unstable();
        assert!(callback_durations[callback_durations.len() - 1] < Duration::from_millis(10));
    }

    #[test]
    fn publish_live_step_update_does_not_shadow_fresh_m_preview_with_previous_magnetization() {
        let mut state = test_workspace_state();
        state.live_state.latest_step.magnetization = Some(vec![1.0, 0.0, 0.0]);

        let mut update = test_step_update(14);
        update.preview_field = Some(test_preview_field("m", 2, -1.0));
        let _ = apply_live_step_update_to_workspace_state(
            &mut state,
            "run-test",
            "session-test",
            PathBuf::from("/tmp/artifacts").as_path(),
            update,
            true,
        );

        assert_eq!(state.live_state.latest_step.magnetization, None);
        let delta = state.publish_delta();
        assert_eq!(
            delta
                .preview_fields
                .as_ref()
                .and_then(|fields| fields.first())
                .map(|field| field.vector_field_values.as_slice()),
            Some(&[0.0, 0.0, -1.0][..])
        );
    }

    fn tiny_fdm_plan() -> BackendPlanIR {
        BackendPlanIR::Fdm(FdmPlanIR {
            grid: GridDimensions { cells: [1, 1, 1] },
            cell_size: [5e-9, 5e-9, 5e-9],
            region_mask: vec![0],
            active_mask: None,
            initial_magnetization: vec![[1.0, 0.0, 0.0]],
            material: FdmMaterialIR {
                name: "Py".to_string(),
                saturation_magnetisation: 800e3,
                exchange_stiffness: 13e-12,
                damping: 0.5,
                ..Default::default()
            },
            enable_exchange: true,
            enable_demag: false,
            external_field: None,
            gyromagnetic_ratio: 2.211e5,
            precision: ExecutionPrecision::Double,
            exchange_bc: ExchangeBoundaryCondition::Neumann,
            integrator: Some(IntegratorChoice::Heun),
            fixed_timestep: Some(1e-13),
            adaptive_timestep: None,
            relaxation: None,
            boundary_correction: None,
            boundary_geometry: None,
            current_density: None,
            stt_degree: None,
            stt_beta: None,
            stt_spin_polarization: None,
            stt_lambda: None,
            stt_epsilon_prime: None,
            stt_thickness: None,
            stt_fixed_layer_position: None,
            has_oersted_cylinder: false,
            oersted_current: None,
            oersted_radius: None,
            oersted_center: None,
            oersted_axis: None,
            oersted_field_xyz: None,
            oersted_time_dep_kind: 0,
            oersted_time_dep_freq: 0.0,
            oersted_time_dep_phase: 0.0,
            oersted_time_dep_offset: 0.0,
            oersted_time_dep_t_on: 0.0,
            oersted_time_dep_t_off: 0.0,
            oersted_realization: None,
            temperature: None,
            interfacial_dmi: None,
            bulk_dmi: None,
            inter_region_exchange: vec![],
            region_owner: Vec::new(),
            ..Default::default()
        })
    }

    #[test]
    fn fdm_grid_refresh_workspace_exposes_new_generation_and_mask_contract() {
        let BackendPlanIR::Fdm(mut plan) = tiny_fdm_plan() else {
            panic!("test fixture must be an FDM plan");
        };
        plan.region_mask = vec![1];
        let workspace = current_fdm_mesh_workspace(&plan, "awaiting_command", &[]);

        assert_eq!(
            workspace["mesh_summary"]["cells"],
            serde_json::json!([1, 1, 1])
        );
        assert_eq!(
            workspace["mesh_summary"]["cell_size_m"],
            serde_json::json!([5e-9, 5e-9, 5e-9])
        );
        assert_eq!(
            workspace["mesh_summary"]["generation_id"],
            "fdm:fdm-grid-1x1x1"
        );
        assert_eq!(workspace["mesh_summary"]["active_cells"], 1);
        assert_eq!(workspace["mesh_capabilities"]["has_structured_grid"], true);
        assert_eq!(workspace["mesh_capabilities"]["has_membership_mask"], true);
        assert_eq!(workspace["mesh_capabilities"]["supports_grid_replan"], true);
    }

    #[test]
    fn fdm_grid_refresh_patch_normalizes_policy_and_runtime_selection() {
        let mut problem = ProblemIR::bootstrap_example();
        let geometry_before = problem.geometry.clone();
        let materials_before = problem.materials.clone();
        let magnets_before = problem.magnets.clone();
        let regions_before = problem.regions.clone();
        let object_regions_before = problem.object_regions.clone();
        let patch = SceneProblemPatch {
            geometry_entries: Vec::new(),
            magnets: Vec::new(),
            materials: Vec::new(),
            regions: Vec::new(),
            object_regions: Vec::new(),
            universe: None,
            fdm: Some(serde_json::json!({
                "default_cell": [1e-9, 2e-9, 3e-9],
                "per_object_grid": {
                    "magnet": {"cell": [4e-9, 5e-9, 6e-9]}
                },
                "demag": {"strategy": "auto", "mode": "auto", "explain": true}
            })),
            runtime_selection: Some(serde_json::json!({
                "backend": "fdm",
                "device": "gpu",
                "precision": "double"
            })),
        };

        apply_scene_discretization_patch(&mut problem, &patch)
            .expect("FDM discretization patch should be valid");

        assert_eq!(problem.backend_policy.requested_backend, BackendTarget::Fdm);
        assert_eq!(problem.geometry, geometry_before);
        assert_eq!(problem.materials, materials_before);
        assert_eq!(problem.magnets, magnets_before);
        assert_eq!(problem.regions, regions_before);
        assert_eq!(problem.object_regions, object_regions_before);
        let hints = problem
            .backend_policy
            .discretization_hints
            .as_ref()
            .and_then(|hints| hints.fdm.as_ref())
            .expect("FDM hints should be materialized");
        assert_eq!(hints.cell, [1e-9, 2e-9, 3e-9]);
        assert_eq!(hints.default_cell, Some([1e-9, 2e-9, 3e-9]));
        assert_eq!(
            hints
                .per_magnet
                .as_ref()
                .and_then(|entries| entries.get("magnet"))
                .map(|entry| entry.cell),
            Some([4e-9, 5e-9, 6e-9])
        );
        assert_eq!(
            hints.demag.as_ref().map(|demag| demag.fft_backend.as_str()),
            Some("auto")
        );
        assert_eq!(
            problem.problem_meta.runtime_metadata["runtime_selection"]["device"],
            "gpu"
        );
    }

    fn tiny_fem_plan() -> BackendPlanIR {
        BackendPlanIR::Fem(FemPlanIR {
            mesh_name: "tiny".to_string(),
            mesh_source: None,
            mesh: MeshIR {
                mesh_name: "tiny".to_string(),
                nodes: vec![
                    [0.0, 0.0, 0.0],
                    [1.0, 0.0, 0.0],
                    [0.0, 1.0, 0.0],
                    [0.0, 0.0, 1.0],
                ],
                cells: fullmag_ir::FemConnectivityIR::from_tet4(vec![[0, 1, 2, 3]]),
                element_markers: vec![1],
                facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(vec![[0, 1, 2]]),
                boundary_markers: vec![1],
                periodic_boundary_pairs: Vec::new(),
                periodic_node_pairs: Vec::new(),
                per_domain_quality: Default::default(),
            },
            object_segments: Vec::new(),
            mesh_parts: Vec::new(),
            mesh_build_report: None,
            domain_mesh_mode: fullmag_ir::FemDomainMeshModeIR::MergedMagneticMesh,
            domain_frame: None,
            fe_order: 1,
            hmax: 1.0,
            initial_magnetization: vec![[0.0, 0.0, 1.0]; 4],
            frozen_spins: None,
            material: MaterialIR {
                name: "Py".to_string(),
                saturation_magnetisation: 800e3,
                exchange_stiffness: 13e-12,
                damping: 0.5,
                uniaxial_anisotropy: None,
                anisotropy_axis: None,
                uniaxial_anisotropy_k2: None,
                cubic_anisotropy_kc1: None,
                cubic_anisotropy_kc2: None,
                cubic_anisotropy_kc3: None,
                cubic_anisotropy_axis1: None,
                cubic_anisotropy_axis2: None,
                ms_field: None,
                a_field: None,
                alpha_field: None,
                ku_field: None,
                ku2_field: None,
                kc1_field: None,
                kc2_field: None,
                kc3_field: None,
                interfacial_dmi: None,
                bulk_dmi: None,
                dind_field: None,
                dbulk_field: None,
            },
            anisotropy_axis_field: None,
            ms_element_field: None,
            a_element_field: None,
            region_materials: Vec::new(),
            enable_exchange: true,
            enable_demag: true,
            external_field: None,
            antenna_zeeman_masks: Vec::new(),
            solved_antenna_drive_bases: Vec::new(),
            field_drives: Vec::new(),
            field_drive_geometry_masks: Vec::new(),
            time_stage: Default::default(),
            current_modules: vec![],
            charge_transport_plans: vec![],
            spin_transport_plans: vec![],
            gyromagnetic_ratio: 2.211e5,
            precision: ExecutionPrecision::Double,
            exchange_bc: ExchangeBoundaryCondition::Neumann,
            integrator: Some(IntegratorChoice::Heun),
            fixed_timestep: Some(1e-13),
            adaptive_timestep: None,
            relaxation: None,
            field_refresh: None,
            demag_realization: None,
            air_box_config: None,
            interfacial_dmi: None,
            rotated_interfacial_dmi: None,
            bulk_dmi: None,
            dmi_interface_normal: None,
            dind_field: None,
            dbulk_field: None,
            temperature: None,
            current_density: None,
            stt_degree: None,
            stt_beta: None,
            spin_torque_contract: None,
            stt_spin_polarization: None,
            stt_lambda: None,
            stt_epsilon_prime: None,
            stt_thickness: None,
            stt_fixed_layer_position: None,
            has_oersted_cylinder: false,
            oersted_current: None,
            oersted_radius: None,
            oersted_center: None,
            oersted_axis: None,
            oersted_field_xyz: None,
            oersted_time_dep_kind: 0,
            oersted_time_dep_freq: 0.0,
            oersted_time_dep_phase: 0.0,
            oersted_time_dep_offset: 0.0,
            oersted_time_dep_t_on: 0.0,
            oersted_time_dep_t_off: 0.0,
            magnetoelastic: None,
            mechanics: None,
            demag_solver_policy: None,
            thermal_seed_config: None,
            oersted_realization: None,
            gpu_device_index: None,
            mfem_device_string: None,
            use_consistent_mass: None,
        })
    }

    fn tiny_shared_domain_fem_plan() -> BackendPlanIR {
        BackendPlanIR::Fem(FemPlanIR {
            mesh_name: "shared".to_string(),
            mesh_source: None,
            mesh: MeshIR {
                mesh_name: "shared".to_string(),
                nodes: vec![
                    [0.0, 0.0, 0.0],
                    [1.0, 0.0, 0.0],
                    [0.0, 1.0, 0.0],
                    [0.0, 0.0, 1.0],
                    [2.0, 0.0, 0.0],
                    [2.0, 1.0, 0.0],
                    [2.0, 0.0, 1.0],
                    [3.0, 0.0, 0.0],
                ],
                cells: fullmag_ir::FemConnectivityIR::from_tet4(vec![[0, 1, 2, 3], [4, 5, 6, 7]]),
                element_markers: vec![1, 2],
                facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(vec![[0, 1, 2], [4, 5, 6]]),
                boundary_markers: vec![1, 2],
                periodic_boundary_pairs: Vec::new(),
                periodic_node_pairs: Vec::new(),
                per_domain_quality: Default::default(),
            },
            object_segments: vec![
                FemObjectSegmentIR {
                    object_id: "left".to_string(),
                    geometry_id: Some("left_geom".to_string()),
                    node_start: 0,
                    node_count: 4,
                    element_start: 0,
                    element_count: 1,
                    boundary_face_start: 0,
                    boundary_face_count: 1,
                },
                FemObjectSegmentIR {
                    object_id: "right".to_string(),
                    geometry_id: Some("right_geom".to_string()),
                    node_start: 4,
                    node_count: 4,
                    element_start: 1,
                    element_count: 1,
                    boundary_face_start: 1,
                    boundary_face_count: 1,
                },
            ],
            mesh_parts: Vec::new(),
            mesh_build_report: None,
            domain_mesh_mode: FemDomainMeshModeIR::SharedDomainMeshWithAir,
            domain_frame: None,
            fe_order: 1,
            hmax: 1.0,
            initial_magnetization: vec![[0.0, 0.0, 1.0]; 8],
            frozen_spins: None,
            material: MaterialIR {
                name: "Py".to_string(),
                saturation_magnetisation: 800e3,
                exchange_stiffness: 13e-12,
                damping: 0.5,
                uniaxial_anisotropy: None,
                anisotropy_axis: None,
                uniaxial_anisotropy_k2: None,
                cubic_anisotropy_kc1: None,
                cubic_anisotropy_kc2: None,
                cubic_anisotropy_kc3: None,
                cubic_anisotropy_axis1: None,
                cubic_anisotropy_axis2: None,
                ms_field: None,
                a_field: None,
                alpha_field: None,
                ku_field: None,
                ku2_field: None,
                kc1_field: None,
                kc2_field: None,
                kc3_field: None,
                interfacial_dmi: None,
                bulk_dmi: None,
                dind_field: None,
                dbulk_field: None,
            },
            anisotropy_axis_field: None,
            ms_element_field: None,
            a_element_field: None,
            region_materials: Vec::new(),
            enable_exchange: true,
            enable_demag: true,
            external_field: None,
            antenna_zeeman_masks: Vec::new(),
            solved_antenna_drive_bases: Vec::new(),
            field_drives: Vec::new(),
            field_drive_geometry_masks: Vec::new(),
            time_stage: Default::default(),
            current_modules: vec![],
            charge_transport_plans: vec![],
            spin_transport_plans: vec![],
            gyromagnetic_ratio: 2.211e5,
            precision: ExecutionPrecision::Double,
            exchange_bc: ExchangeBoundaryCondition::Neumann,
            integrator: Some(IntegratorChoice::Heun),
            fixed_timestep: Some(1e-13),
            adaptive_timestep: None,
            relaxation: None,
            field_refresh: None,
            demag_realization: None,
            air_box_config: None,
            interfacial_dmi: None,
            rotated_interfacial_dmi: None,
            bulk_dmi: None,
            dmi_interface_normal: None,
            dind_field: None,
            dbulk_field: None,
            temperature: None,
            current_density: None,
            stt_degree: None,
            stt_beta: None,
            spin_torque_contract: None,
            stt_spin_polarization: None,
            stt_lambda: None,
            stt_epsilon_prime: None,
            stt_thickness: None,
            stt_fixed_layer_position: None,
            has_oersted_cylinder: false,
            oersted_current: None,
            oersted_radius: None,
            oersted_center: None,
            oersted_axis: None,
            oersted_field_xyz: None,
            oersted_time_dep_kind: 0,
            oersted_time_dep_freq: 0.0,
            oersted_time_dep_phase: 0.0,
            oersted_time_dep_offset: 0.0,
            oersted_time_dep_t_on: 0.0,
            oersted_time_dep_t_off: 0.0,
            magnetoelastic: None,
            mechanics: None,
            demag_solver_policy: None,
            thermal_seed_config: None,
            oersted_realization: None,
            gpu_device_index: None,
            mfem_device_string: None,
            use_consistent_mass: None,
        })
    }

    fn tiny_problem_with_shared_domain_asset() -> ProblemIR {
        ProblemIR {
            spin_transport_modules: Vec::new(),
            selections: Vec::new(),
            magnetization_constraints: Vec::new(),
            ir_version: "test-ir".to_string(),
            problem_meta: ProblemMeta {
                name: "shared-domain-test".to_string(),
                description: None,
                script_language: "python".to_string(),
                script_source: None,
                script_api_version: "0".to_string(),
                serializer_version: "0".to_string(),
                entrypoint_kind: "test".to_string(),
                source_hash: None,
                runtime_metadata: BTreeMap::new(),
                backend_revision: None,
                seeds: Vec::new(),
            },
            geometry: GeometryIR {
                entries: vec![
                    GeometryEntryIR::Box {
                        name: "left".to_string(),
                        size: [1.0, 1.0, 1.0],
                    },
                    GeometryEntryIR::Box {
                        name: "right".to_string(),
                        size: [1.0, 1.0, 1.0],
                    },
                ],
            },
            geometry_assets: Some(GeometryAssetsIR {
                fdm_grid_assets: Vec::new(),
                fem_mesh_assets: Vec::new(),
                fem_domain_mesh_asset: Some(FemDomainMeshAssetIR {
                    mesh_source: None,
                    mesh: Some(MeshIR {
                        mesh_name: "old_shared".to_string(),
                        nodes: vec![[0.0, 0.0, 0.0]],
                        cells: fullmag_ir::FemConnectivityIR::from_tet4(Vec::new()),
                        element_markers: Vec::new(),
                        facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(Vec::new()),
                        boundary_markers: Vec::new(),
                        periodic_boundary_pairs: Vec::new(),
                        periodic_node_pairs: Vec::new(),
                        per_domain_quality: Default::default(),
                    }),
                    region_markers: Vec::new(),
                    object_region_markers: Vec::new(),
                    build_report: None,
                }),
            }),
            regions: Vec::new(),
            materials: Vec::new(),
            magnets: Vec::new(),
            energy_terms: Vec::new(),
            study: StudyIR::TimeEvolution {
                dynamics: DynamicsIR::Llg {
                    gyromagnetic_ratio: 2.211e5,
                    integrator: "heun".to_string(),
                    fixed_timestep: Some(1e-13),
                    adaptive_timestep: None,
                    field_refresh: None,
                    mechanics: None,
                },
                sampling: SamplingIR {
                    table_autosave: None,
                    stage_autosave: None,
                    outputs: Vec::new(),
                },
            },
            backend_policy: BackendPolicyIR {
                requested_backend: BackendTarget::Fem,
                execution_precision: ExecutionPrecision::Double,
                fdm_precision_policy: None,
                discretization_hints: Some(DiscretizationHintsIR {
                    fdm: None,
                    fem: None,
                    hybrid: None,
                }),
            },
            validation_profile: ValidationProfileIR {
                execution_mode: ExecutionMode::Strict,
            },
            planar_monitors: Vec::new(),
            field_drives: Vec::new(),
            current_modules: Vec::new(),
            antenna_port_modes: Vec::new(),
            antenna_field_solve_stages: Vec::new(),
            antenna_target_projections: Vec::new(),
            solved_antenna_drives: Vec::new(),
            antenna_spectrum_requests: Vec::new(),
            spin_torque_modules: Vec::new(),
            physics_graph: None,
            excitation_analysis: None,
            current_density: None,
            stt_degree: None,
            stt_beta: None,
            stt_spin_polarization: None,
            stt_lambda: None,
            stt_epsilon_prime: None,
            stt_thickness: None,
            stt_fixed_layer_position: None,
            temperature: None,
            elastic_materials: Vec::new(),
            elastic_bodies: Vec::new(),
            magnetostriction_laws: Vec::new(),
            mechanical_bcs: Vec::new(),
            mechanical_loads: Vec::new(),
            air_box_policy: None,
            pbc: None,
            mesh_semantics: None,
            couplings: Vec::new(),
            material_parameter_fields: Vec::new(),
            object_regions: Vec::new(),
        }
    }

    fn frequency_response_relaxed_stage() -> ResolvedScriptStage {
        let mut problem = tiny_problem_with_shared_domain_asset();
        problem.study = StudyIR::FrequencyResponse {
            dynamics: DynamicsIR::Llg {
                gyromagnetic_ratio: 2.211e5,
                integrator: "heun".to_string(),
                fixed_timestep: Some(1e-13),
                adaptive_timestep: None,
                field_refresh: None,
                mechanics: None,
            },
            operator: EigenOperatorConfigIR {
                kind: EigenOperatorIR::Full2x2,
                include_demag: true,
            },
            equilibrium: EquilibriumSourceIR::RelaxedInitialState,
            k_sampling: None,
            normalization: FrequencyResponseNormalizationIR::UnitMaxAmplitude,
            damping_policy: EigenDampingPolicyIR::Include,
            spin_wave_bc: SpinWaveBoundaryConditionIR::default(),
            magnetostatic_bc: MagnetostaticBoundaryConditionIR::PeriodicAirboxK0,
            excitation: FrequencyExcitationIR {
                field_au_per_m: [1.0, 0.0, 0.0],
                phase_rad: 0.0,
            },
            frequencies_hz: FrequencySweepIR {
                values_hz: vec![2.0e9],
            },
            solver_policy: None,
            sampling: SamplingIR {
                table_autosave: None,
                stage_autosave: None,
                outputs: Vec::new(),
            },
        };
        ResolvedScriptStage::solver(problem, 0.0, "flat_frequency_response")
    }

    fn stage_completion(reason: fullmag_ir::StageStopReason) -> fullmag_ir::StageCompletionIR {
        let converged = matches!(
            reason,
            fullmag_ir::StageStopReason::Torque
                | fullmag_ir::StageStopReason::Energy
                | fullmag_ir::StageStopReason::Gradient
        );
        fullmag_ir::StageCompletionIR {
            status: "completed".to_string(),
            converged,
            reason: Some(reason),
            metric: Some(fullmag_ir::StageMetricKind::MaxTorqueApm),
            metric_name: Some("max_torque_apm".to_string()),
            metric_value: Some(6.7e-5),
            threshold: Some(1.0e-4),
        }
    }

    fn certified_fields(node_count: usize) -> fullmag_runner::CertifiedFemEquilibriumFields {
        let zeros = vec![[0.0, 0.0, 0.0]; node_count];
        fullmag_runner::CertifiedFemEquilibriumFields::from_fields(
            zeros.clone(),
            zeros.clone(),
            zeros.clone(),
            zeros,
            vec![0.0; node_count],
        )
        .expect("certified field fixture")
    }

    fn recomputed_certificate(
        plan: &fullmag_ir::FemPlanIR,
        mesh: &fullmag_runner::FemMeshPayload,
        m0: &[[f64; 3]],
        fields: &fullmag_runner::CertifiedFemEquilibriumFields,
    ) -> fullmag_runner::RecomputedFemLinearizationCertificateV1 {
        let [material, physics, boundary] =
            fullmag_runner::fem_relax_equilibrium_identity_signatures(plan)
                .expect("equilibrium identity fixture");
        let mut certificate = fullmag_runner::RecomputedFemLinearizationCertificateV1 {
            schema_version: "RecomputedFemLinearizationCertificate.v1".to_string(),
            status: "matched".to_string(),
            recompute_provider: "native_fem_final_state_refresh.v1".to_string(),
            node_count: m0.len(),
            equilibrium_content_sha256: fullmag_runner::recomputed_fem_equilibrium_content_sha256(
                m0,
            ),
            mesh_topology_sha256: fullmag_runner::fem_mesh_topology_fingerprint(mesh),
            equilibrium_material_signature: material,
            equilibrium_static_physics_signature: physics,
            equilibrium_boundary_signature: boundary,
            accepted_fields_content_sha256: fields.content_sha256.clone(),
            recomputed_fields_content_sha256: fields.content_sha256.clone(),
            max_h_ex_difference_a_per_m: 0.0,
            max_h_demag_difference_a_per_m: 0.0,
            max_h_ext_difference_a_per_m: 0.0,
            max_h_anisotropy_difference_a_per_m: None,
            max_h_eff_difference_a_per_m: 0.0,
            max_phi_difference_a: 0.0,
            field_absolute_tolerance_a_per_m: 1.0e-6,
            field_relative_tolerance: 1.0e-8,
            phi_absolute_tolerance_a: 1.0e-12,
            content_sha256: String::new(),
        };
        certificate.content_sha256 =
            fullmag_runner::recomputed_fem_linearization_certificate_sha256(&certificate)
                .expect("certificate digest fixture");
        certificate
    }

    #[test]
    fn frequency_response_rejects_max_steps_relaxation_continuation() {
        let stage = frequency_response_relaxed_stage();
        let completion = stage_completion(fullmag_ir::StageStopReason::MaxSteps);
        let error =
            ensure_frequency_response_relaxed_continuation_is_qualified(&stage, Some(&completion))
                .expect_err("max_steps relax continuation must not feed frequency response");
        let message = error.to_string();

        assert!(message.contains("equilibrium_source='relax'"));
        assert!(message.contains("MaxSteps"));
        assert!(message.contains("refusing to linearize"));
    }

    #[test]
    fn frequency_response_accepts_torque_relaxation_continuation() {
        let stage = frequency_response_relaxed_stage();
        let completion = stage_completion(fullmag_ir::StageStopReason::Torque);

        ensure_frequency_response_relaxed_continuation_is_qualified(&stage, Some(&completion))
            .expect("torque-qualified relax continuation should feed frequency response");
    }

    #[test]
    fn frequency_response_rejects_incoherent_converged_completion() {
        let stage = frequency_response_relaxed_stage();
        let mut completion = stage_completion(fullmag_ir::StageStopReason::MaxSteps);
        completion.converged = true;

        let error =
            ensure_frequency_response_relaxed_continuation_is_qualified(&stage, Some(&completion))
                .expect_err("completed+converged max_steps must not qualify equilibrium");

        assert!(error.to_string().contains("refusing to linearize"));
    }

    #[test]
    fn active_sequence_records_the_exact_application_boundary_and_segment() {
        let mut sequence = ActiveSequenceState::single_current();
        let boundary = CommandApplicationBoundary::new("run-7", "cmd-hot-apply", 42, 2.5e-12);

        sequence.mark_current_started("cmd-hot-apply", 1_700_000_000_000, None, Some(&boundary));
        sequence.mark_current("completed", None, Some(1_700_000_001_000), None);

        let stage = sequence
            .completed_stage_execution("awaiting_command")
            .stages
            .into_iter()
            .next()
            .expect("stage record should be present");
        assert_eq!(stage.applied_step, Some(42));
        assert_eq!(stage.applied_time_seconds, Some(2.5e-12));
        assert_eq!(
            stage.segment_id.as_deref(),
            Some("segment:run-7:cmd-hot-apply:42:3d85fd7fe1796495")
        );
    }

    #[test]
    fn active_sequence_tracks_pause_checkpoint_and_resume_ref() {
        let mut sequence = ActiveSequenceState::new(vec![SequenceStage::Run {
            until_seconds: 1e-9,
            max_steps: Some(100),
        }]);

        sequence.mark_current_started("cmd-stage-0", 1_700_000_000_000, None, None);
        sequence.mark_current(
            "paused",
            None,
            None,
            Some("artifacts/stage-000".to_string()),
        );
        sequence.mark_current_checkpoint_preserved(
            "cp-000042",
            Some("runs/run-1/checkpoints/cp-000042/common_state.json".to_string()),
        );
        sequence.mark_current_resume_from_checkpoint("cp-000042");
        sequence.mark_current_started("cmd-stage-0", 1_700_000_001_000, None, None);

        let stage = sequence
            .stage_execution(Some("run"), "running")
            .stages
            .into_iter()
            .next()
            .expect("stage record should be present");
        assert_eq!(stage.status, "running");
        assert_eq!(stage.checkpoint_ref.as_deref(), Some("cp-000042"));
        assert_eq!(
            stage.resume_from_checkpoint_ref.as_deref(),
            Some("cp-000042")
        );
        assert_eq!(stage.state_transition.as_deref(), Some("restored"));
        assert!(stage
            .artifact_refs
            .iter()
            .any(|artifact_ref| artifact_ref.ends_with("common_state.json")));
    }

    #[test]
    fn active_sequence_marks_idle_skip_and_keeps_next_stage_active() {
        let mut sequence = ActiveSequenceState::new(vec![
            SequenceStage::Run {
                until_seconds: 1e-9,
                max_steps: Some(100),
            },
            SequenceStage::Run {
                until_seconds: 2e-9,
                max_steps: Some(200),
            },
        ]);

        let skipped = sequence.remaining_stages.remove(0);
        assert_eq!(skipped.label(), "run");
        let skipped_completion = user_cancelled_stage_completion("skipped");
        sequence.mark_current(
            "skipped",
            Some(&skipped_completion),
            Some(1_700_000_000_000),
            None,
        );
        sequence.advance();

        let execution = sequence.stage_execution(Some("run"), "awaiting_command");
        assert_eq!(execution.runtime_state, "awaiting_command");
        assert_eq!(execution.completed_stage_indexes, vec![0]);
        assert_eq!(execution.active_stage_index, Some(1));
        assert_eq!(execution.stages[0].status, "skipped");
        assert_eq!(
            execution.stages[0].completed_at_unix_ms,
            Some(1_700_000_000_000)
        );
        assert_eq!(
            execution.stages[0].reason,
            Some(fullmag_ir::StageStopReason::UserCancelled)
        );
        assert_eq!(execution.stages[1].status, "awaiting_command");
    }

    #[test]
    fn active_sequence_preserves_materialized_stage_kind_after_completion() {
        let mut sequence = ActiveSequenceState::new(vec![SequenceStage::Run {
            until_seconds: 1e-9,
            max_steps: Some(100),
        }]);

        sequence.mark_current_materialized_kind("flat_hysteresis");
        sequence.mark_current_started("cmd-stage-0", 1_700_000_000_000, None, None);
        sequence.mark_current("completed", None, Some(1_700_000_001_000), None);

        let execution = sequence.completed_stage_execution("awaiting_command");
        assert_eq!(execution.stages[0].kind.as_deref(), Some("flat_hysteresis"));
        assert_eq!(execution.stages[0].status, "completed");
    }

    #[test]
    fn scripted_inspection_stage_has_runtime_identity_and_terminal_artifact_ref() {
        for (status, reason) in [
            ("completed", None),
            ("failed", Some(fullmag_ir::StageStopReason::BackendError)),
            ("cancelled", Some(fullmag_ir::StageStopReason::UserCancelled)),
        ] {
            let reference = "antenna/external_lead_stage_outputs/stage-001/antenna_external_lead_stage_output.v1.json";
            let completion = fullmag_ir::StageCompletionIR {
                status: status.into(), converged: false, reason,
                metric: None, metric_name: None, metric_value: None, threshold: None,
            };
            let execution = scripted_stage_execution_state_with_completion(
                3, 1, "study_pipeline_antenna_field_solve", status, None,
                Some(1), Some(2), Some(reference.into()), Some(&completion), None,
            );
            assert_eq!(execution.stages[1].stage_id.as_deref(), Some("stage-001"));
            assert_eq!(execution.stages[1].status, status);
            assert_eq!(execution.stages[1].reason, reason);
            assert_eq!(execution.stages[1].artifact_refs, vec![reference.to_string()]);
            assert_eq!(execution.stages[0].stage_id.as_deref(), Some("stage-000"));
            assert_eq!(execution.stages[2].stage_id.as_deref(), Some("stage-002"));
            assert!(!execution.stages[1].converged);
        }
    }

    #[test]
    fn antenna_manifest_reference_accepts_canonical_path_and_operator_root_alias() {
        let storage = std::path::PathBuf::from(std::env::var_os("FULLMAG_PROJECT_STORAGE_ROOT")
            .expect("manifest reference test requires resolver-owned storage"));
        assert!(storage.is_absolute());
        let root = storage.join("tmp").join(format!("antenna-manifest-ref-{}", uuid::Uuid::new_v4().simple()));
        fs::create_dir_all(root.join("operator-root-alias")).unwrap();
        let path = root.join("manifest.v1.json");
        fs::write(&path, b"{}").unwrap();
        let canonical = fs::canonicalize(&path).unwrap();
        assert_eq!(relative_artifact_ref(&root, &canonical).unwrap(), "manifest.v1.json");
        let alias = root.join("operator-root-alias").join("..");
        assert_eq!(relative_artifact_ref(&alias, &canonical).unwrap(), "manifest.v1.json");
        assert!(relative_artifact_ref(&root, &root).is_err());
        fs::remove_file(path).unwrap();
        fs::remove_dir(root.join("operator-root-alias")).unwrap();
        fs::remove_dir(root).unwrap();
    }

    #[test]
    fn scripted_stage_execution_preserves_stage_kind_after_completion() {
        let execution = scripted_stage_execution_state(
            1,
            0,
            "flat_hysteresis",
            "completed",
            Some("cmd-stage-0"),
            Some(1_700_000_000_000),
            Some(1_700_000_001_000),
            Some("artifacts/stage-000".to_string()),
            None,
            None,
        );

        assert_eq!(execution.active_stage_index, None);
        assert_eq!(
            execution.active_stage_kind.as_deref(),
            Some("flat_hysteresis")
        );
        assert_eq!(execution.stages[0].kind.as_deref(), Some("flat_hysteresis"));
        assert_eq!(execution.stages[0].status, "completed");
    }

    #[test]
    fn completed_scripted_stages_keep_interactive_owner_awaiting_commands() {
        let mut execution = scripted_stage_execution_state(
            1,
            0,
            "flat_run",
            "completed",
            Some("cmd-solve"),
            Some(1_700_000_000_000),
            Some(1_700_000_001_000),
            Some("artifacts/stage-000".to_string()),
            Some(fullmag_ir::StageStopReason::MaxPhysicalTime),
            None,
        );
        let boundary = CommandApplicationBoundary::new("run-1", "cmd-solve", 0, 0.0);
        attach_scripted_stage_solver_steps(&mut execution, 0, Some(&boundary), Some(10));
        assert_eq!(execution.stages[0].applied_step, Some(0));
        assert_eq!(execution.stages[0].completed_step, Some(10));
        assert_eq!(execution.stages[0].segment_id, Some(boundary.segment_id));
        let terminal_history = serde_json::to_value(&execution.stages).unwrap();

        publish_scripted_stages_awaiting_command(&mut execution);

        assert_eq!(execution.runtime_state, "awaiting_command");
        assert_eq!(execution.active_stage_index, None);
        assert_eq!(execution.active_stage_kind, None);
        assert_eq!(execution.completed_stage_indexes, vec![0]);
        assert_eq!(execution.stage_statuses, vec!["completed"]);
        assert_eq!(serde_json::to_value(&execution.stages).unwrap(), terminal_history);

        // A later explicit close must publish terminal ownership, not idle ownership.
        execution = super::stage_execution_from_records(&execution.stages, None, None, "completed");
        assert_eq!(execution.runtime_state, "completed");
        assert_eq!(serde_json::to_value(&execution.stages).unwrap(), terminal_history);
    }

    #[test]
    fn scripted_stage_execution_does_not_mark_pipeline_completed_between_stages() {
        let execution = scripted_stage_execution_state(
            2,
            0,
            "flat_relax",
            "completed",
            Some("cmd-stage-0"),
            Some(1_700_000_000_000),
            Some(1_700_000_001_000),
            Some("artifacts/stage-000".to_string()),
            Some(fullmag_ir::StageStopReason::MaxSteps),
            None,
        );

        assert_eq!(execution.runtime_state, "materializing");
        assert_eq!(execution.active_stage_index, None);
        assert_eq!(execution.active_stage_kind, None);
        assert_eq!(execution.completed_stage_indexes, vec![0]);
        assert_eq!(execution.stage_statuses, vec!["completed", "pending"]);
        assert_eq!(execution.stages[0].kind.as_deref(), Some("flat_relax"));
        assert_eq!(execution.stages[0].status, "completed");
        assert_eq!(
            execution.stages[0].reason,
            Some(fullmag_ir::StageStopReason::MaxSteps)
        );
        assert_eq!(execution.stages[1].status, "pending");
    }

    #[test]
    fn scripted_stage_execution_preserves_previous_relaxation_completion() {
        let completion = stage_completion(fullmag_ir::StageStopReason::Torque);
        let first_stage = scripted_stage_execution_state_with_completion(
            2,
            0,
            "flat_relax",
            "completed",
            Some("cmd-stage-0"),
            Some(1_700_000_000_000),
            Some(1_700_000_001_000),
            Some("artifacts/stage-000".to_string()),
            Some(&completion),
            None,
        );
        let mut second_stage = scripted_stage_execution_state(
            2,
            1,
            "flat_save_state",
            "completed",
            None,
            Some(1_700_000_001_001),
            Some(1_700_000_001_002),
            Some("artifacts/stage-001".to_string()),
            None,
            None,
        );

        preserve_terminal_stage_history(&mut second_stage, Some(&first_stage));

        assert!(second_stage.stages[0].converged);
        assert_eq!(
            second_stage.stages[0].reason,
            Some(fullmag_ir::StageStopReason::Torque)
        );
        assert_eq!(second_stage.stages[0].metric_value, Some(6.7e-5));
    }

    #[test]
    fn discarding_paused_active_sequence_publishes_awaiting_command() {
        let mut active_sequence = Some(ActiveSequenceState::single_current());
        let sequence = active_sequence
            .as_mut()
            .expect("active sequence should be present");
        sequence.mark_current_started("cmd-solve", 1_700_000_000_000, None, None);
        sequence.mark_current("paused", None, None, None);

        let execution =
            discard_active_paused_stage_execution(&mut active_sequence, 1_700_000_001_000)
                .expect("discarding a paused sequence should publish terminal stage execution");

        assert!(active_sequence.is_none());
        assert_eq!(execution.runtime_state, "awaiting_command");
        assert_eq!(execution.active_stage_index, None);
        assert_eq!(execution.completed_stage_indexes, Vec::<usize>::new());
        assert_eq!(execution.stages[0].status, "cancelled");
        assert_eq!(
            execution.stages[0].completed_at_unix_ms,
            Some(1_700_000_001_000)
        );
        assert_eq!(
            execution.stages[0].reason,
            Some(fullmag_ir::StageStopReason::UserCancelled)
        );
    }

    #[test]
    fn scripted_stage_execution_records_user_cancel_reason() {
        let execution = scripted_stage_execution_state(
            1,
            0,
            "run",
            "cancelled",
            Some("cmd-stage-0"),
            Some(1_700_000_000_000),
            Some(1_700_000_001_000),
            Some("artifacts/stage-000".to_string()),
            Some(fullmag_ir::StageStopReason::UserCancelled),
            None,
        );

        let stage = execution.stages.first().expect("stage should exist");
        assert_eq!(stage.status, "cancelled");
        assert_eq!(
            stage.reason,
            Some(fullmag_ir::StageStopReason::UserCancelled)
        );
        assert_eq!(stage.command_id.as_deref(), Some("cmd-stage-0"));
    }

    #[test]
    fn scripted_stage_execution_publishes_continue_in_place_transition_metadata() {
        let transition = StageTransitionMetadata::continue_in_place();
        let execution = scripted_stage_execution_state(
            2,
            1,
            "relax",
            "running",
            Some("cmd-stage-1"),
            Some(1_700_000_000_000),
            None,
            Some("artifacts/stage-001".to_string()),
            None,
            Some(&transition),
        );

        let stage = execution.stages.get(1).expect("stage should exist");
        assert_eq!(stage.state_transition.as_deref(), Some("continues"));
        assert_eq!(
            stage.state_transition_kind,
            Some(StageTransitionKind::ContinueInPlace)
        );
        assert_eq!(
            stage.state_transition_reason,
            Some(StageTransitionReason::SameRuntimeContext)
        );
        assert_eq!(
            stage.state_transition_ui_presentation,
            Some(StageTransitionUiPresentation::SmoothArrow)
        );
        assert_eq!(stage.state_transfer_operator_kind, None);
    }

    fn temp_test_dir(label: &str) -> PathBuf {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos();
        let dir = std::env::temp_dir().join(format!(
            "fullmag-cli-{}-{}-{}",
            label,
            std::process::id(),
            unique
        ));
        fs::create_dir_all(&dir).expect("temp dir should be creatable");
        dir
    }

    #[test]
    fn antenna_spectrum_batch_rejects_later_invalid_output_before_publication() {
        let duplicate = super::validate_antenna_spectrum_output_ids([
            ("first", "field"),
            ("second", "field"),
        ])
        .unwrap_err();
        assert!(duplicate.to_string().contains("declared more than once"));

        let unsafe_id = super::validate_antenna_spectrum_output_ids([
            ("first", "field"),
            ("second", "../outside"),
        ])
        .unwrap_err();
        assert!(unsafe_id.to_string().contains("second"));
        assert!(unsafe_id.to_string().contains("unsafe output_id"));
    }

    #[test]
    fn antenna_spectrum_publication_is_atomic_and_content_addressed() {
        let root = temp_test_dir("antenna-spectrum-publication");
        let artifacts = vec![
            fullmag_runner::AuxiliaryArtifact {
                relative_path: "antenna/source_spectra/field/k_u_rad_per_m.f64le".into(),
                bytes: vec![1, 2, 3],
            },
            fullmag_runner::AuxiliaryArtifact {
                relative_path: "antenna/source_spectra/field/spectrum.v2.json".into(),
                bytes: br#"{"content_digest":"sha256:test"}"#.to_vec(),
            },
        ];
        let error =
            super::publish_antenna_spectrum_artifacts_atomically(&root, "../outside", &artifacts, None)
                .expect_err("output ids must not escape the artifact directory");
        assert!(error.to_string().contains("one safe path component"));

        super::publish_antenna_spectrum_artifacts_atomically(&root, "field", &artifacts, None)
            .expect("first spectrum publication should succeed");
        let output_dir = root.join("antenna/source_spectra/field");
        assert_eq!(
            fs::read(output_dir.join("k_u_rad_per_m.f64le")).unwrap(),
            vec![1, 2, 3]
        );
        assert_eq!(
            fs::read(output_dir.join("spectrum.v2.json")).unwrap(),
            br#"{"content_digest":"sha256:test"}"#
        );
        assert!(fs::read_dir(root.join("antenna/source_spectra"))
            .unwrap()
            .filter_map(Result::ok)
            .all(|entry| !entry.file_name().to_string_lossy().contains("staging")));

        super::publish_antenna_spectrum_artifacts_atomically(&root, "field", &artifacts, None)
            .expect("identical spectrum publication should be reused");

        let mut conflicting = artifacts.clone();
        conflicting[0].bytes = vec![9, 9, 9];
        let error =
            super::publish_antenna_spectrum_artifacts_atomically(&root, "field", &conflicting, None)
                .expect_err("different content must not overwrite an existing result");
        assert!(error.to_string().contains("different content"));
        assert_eq!(
            fs::read(output_dir.join("k_u_rad_per_m.f64le")).unwrap(),
            vec![1, 2, 3]
        );

        fs::write(output_dir.join("unexpected.tmp"), b"stray")
            .expect("test should create an unexpected file");
        let error =
            super::publish_antenna_spectrum_artifacts_atomically(&root, "field", &artifacts, None)
                .expect_err("unexpected files must invalidate an existing publication");
        assert!(error.to_string().contains("different published file set"));
        fs::remove_file(output_dir.join("unexpected.tmp")).unwrap();

        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn antenna_spectrum_reuse_streams_large_payload_and_rejects_late_corruption() {
        let root = temp_test_dir("antenna-spectrum-large-reuse");
        let payload = vec![7_u8; 128 * 1024 + 1];
        let artifacts = vec![
            fullmag_runner::AuxiliaryArtifact {
                relative_path: "antenna/source_spectra/field/power.f64le".into(),
                bytes: payload.clone(),
            },
            fullmag_runner::AuxiliaryArtifact {
                relative_path: "antenna/source_spectra/field/spectrum.v2.json".into(),
                bytes: br#"{"content_digest":"sha256:test"}"#.to_vec(),
            },
        ];
        super::publish_antenna_spectrum_artifacts_atomically(&root, "field", &artifacts, None)
            .unwrap();
        super::publish_antenna_spectrum_artifacts_atomically(&root, "field", &artifacts, None)
            .expect("identical multi-block payload should be reused");

        let path = root.join("antenna/source_spectra/field/power.f64le");
        let mut corrupted = payload;
        corrupted[128 * 1024] ^= 1;
        fs::write(&path, corrupted).unwrap();
        let error = super::publish_antenna_spectrum_artifacts_atomically(
            &root, "field", &artifacts, None,
        ).unwrap_err();
        assert!(error.to_string().contains("different content"));
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn antenna_spectrum_publication_race_reuses_only_identical_output() {
        let artifacts = vec![fullmag_runner::AuxiliaryArtifact {
            relative_path: "antenna/source_spectra/field/spectrum.v2.json".into(),
            bytes: br#"{"content_digest":"sha256:first"}"#.to_vec(),
        }];
        let root = temp_test_dir("antenna-spectrum-publication-race");
        let winner = || {
            super::publish_antenna_spectrum_artifacts_atomically(&root, "field", &artifacts, None)
        };
        super::publish_antenna_spectrum_artifacts_atomically_with_hook(
            &root,
            "field",
            &artifacts,
            None,
            Some(&winner),
        )
        .expect("losing writer must reuse a complete identical output");
        assert!(fs::read_dir(root.join("antenna/source_spectra"))
            .unwrap()
            .filter_map(Result::ok)
            .all(|entry| !entry.file_name().to_string_lossy().contains("staging")));
        let _ = fs::remove_dir_all(root);

        let root = temp_test_dir("antenna-spectrum-publication-race-conflict");
        let mut conflicting = artifacts.clone();
        conflicting[0].bytes = br#"{"content_digest":"sha256:other"}"#.to_vec();
        let winner = || {
            super::publish_antenna_spectrum_artifacts_atomically(&root, "field", &conflicting, None)
        };
        let error = super::publish_antenna_spectrum_artifacts_atomically_with_hook(
            &root,
            "field",
            &artifacts,
            None,
            Some(&winner),
        )
        .expect_err("losing writer must reject a different immutable output");
        assert!(error.to_string().contains("different content"));
        assert_eq!(
            fs::read(root.join("antenna/source_spectra/field/spectrum.v2.json")).unwrap(),
            conflicting[0].bytes
        );
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn antenna_spectrum_publication_rejects_corrupted_staging_bytes() {
        let root = temp_test_dir("antenna-spectrum-staging-integrity");
        let artifacts = vec![
            fullmag_runner::AuxiliaryArtifact {
                relative_path: "antenna/source_spectra/field/power.f64le".into(),
                bytes: vec![1, 2, 3, 4],
            },
            fullmag_runner::AuxiliaryArtifact {
                relative_path: "antenna/source_spectra/field/spectrum.v2.json".into(),
                bytes: br#"{"content_digest":"sha256:test"}"#.to_vec(),
            },
        ];
        let corrupt_staging = || {
            let staging_dir = fs::read_dir(root.join("antenna/source_spectra"))
                .unwrap()
                .filter_map(Result::ok)
                .find(|entry| entry.file_name().to_string_lossy().contains("staging"))
                .unwrap()
                .path();
            fs::write(staging_dir.join("power.f64le"), [9, 9, 9, 9]).unwrap();
            Ok(())
        };
        let error = super::publish_antenna_spectrum_artifacts_atomically_with_hook(
            &root,
            "field",
            &artifacts,
            None,
            Some(&corrupt_staging),
        )
        .expect_err("corrupted staged bytes must not become a ready output");
        assert!(error.to_string().contains("differs from generated content"));
        assert!(!root.join("antenna/source_spectra/field").exists());
        assert!(fs::read_dir(root.join("antenna/source_spectra"))
            .unwrap()
            .filter_map(Result::ok)
            .all(|entry| !entry.file_name().to_string_lossy().contains("staging")));
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn cancelled_antenna_spectrum_leaves_no_published_output() {
        let root = temp_test_dir("cancelled-antenna-spectrum");
        let artifacts = vec![fullmag_runner::AuxiliaryArtifact {
            relative_path: "antenna/source_spectra/field/spectrum.v2.json".into(),
            bytes: br#"{"content_digest":"sha256:test"}"#.to_vec(),
        }];
        let interrupted = std::sync::atomic::AtomicBool::new(true);
        let error = super::publish_antenna_spectrum_artifacts_atomically(
            &root,
            "field",
            &artifacts,
            Some(&interrupted),
        )
        .expect_err("cancelled spectrum publication must not become visible");
        assert!(error.to_string().contains("cancelled before publication"));
        let spectrum_root = root.join("antenna/source_spectra");
        assert!(!spectrum_root.join("field").exists());
        if spectrum_root.exists() {
            assert!(fs::read_dir(&spectrum_root)
                .unwrap()
                .filter_map(Result::ok)
                .all(|entry| !entry.file_name().to_string_lossy().contains("staging")));
        }
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn cancellation_at_spectrum_rename_boundary_keeps_manifest_private() {
        use std::sync::atomic::{AtomicBool, Ordering};

        let root = temp_test_dir("cancelled-antenna-spectrum-rename");
        let artifacts = vec![fullmag_runner::AuxiliaryArtifact {
            relative_path: "antenna/source_spectra/field/spectrum.v2.json".into(),
            bytes: br#"{"content_digest":"sha256:test"}"#.to_vec(),
        }];
        let interrupted = AtomicBool::new(false);
        let cancel_at_boundary = || {
            interrupted.store(true, Ordering::Release);
            Ok(())
        };
        let error = super::publish_antenna_spectrum_artifacts_atomically_with_hook(
            &root,
            "field",
            &artifacts,
            Some(&interrupted),
            Some(&cancel_at_boundary),
        )
        .expect_err("cancellation before rename must keep the manifest private");
        assert!(error.to_string().contains("cancelled before publication"));
        let spectrum_root = root.join("antenna/source_spectra");
        assert!(!spectrum_root.join("field").exists());
        assert!(fs::read_dir(&spectrum_root)
            .unwrap()
            .filter_map(Result::ok)
            .all(|entry| !entry.file_name().to_string_lossy().contains("staging")));
        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn wait_for_solve_is_supported_for_fdm_and_fem() {
        assert!(wait_for_solve_supported(&tiny_fdm_plan()));
        assert!(wait_for_solve_supported(&tiny_fem_plan()));
    }

    #[test]
    fn wait_for_solve_does_not_block_headless_runs() {
        assert!(wait_for_solve_should_block(true, true, false));
        assert!(!wait_for_solve_should_block(true, true, true));
        assert!(!wait_for_solve_should_block(true, false, false));
        assert!(!wait_for_solve_should_block(false, true, false));
    }

    #[test]
    fn wait_for_solve_applies_frozen_spins_binding_before_building_the_initial_stage() {
        let source = include_str!("orchestrator.rs");
        let branch = source
            .split("WaitForSolveCommandAction::StartSolver => {")
            .nth(1)
            .expect("wait-for-solve start branch")
            .split("WaitForSolveCommandAction::Remesh => {")
            .next()
            .expect("wait-for-solve start branch body");
        let binding_index = branch
            .find("problem_with_frozen_spins_runtime_plan_binding(")
            .expect("initial solver command must consume the Frozen Spins binding");
        let stage_index = branch
            .find("build_initial_interactive_command_stage(")
            .expect("initial solver command must build a stage");

        assert!(
            binding_index < stage_index,
            "Frozen Spins must update canonical IR before the initial execution plan is built"
        );
        assert!(
            branch.contains("frozen_spins_applied_scene_revision = Some(source_scene_revision)")
        );
    }

    #[test]
    fn scripted_solver_publishes_frozen_spins_certificate_before_one_shot_execution() {
        let source = include_str!("orchestrator.rs");
        let execution = source
            .split("let mut stage_heartbeat = use_live_callback.then(|| {")
            .nth(1)
            .expect("scripted stage execution block")
            .split("let stage_failed =")
            .next()
            .expect("scripted stage execution body");
        let certificate_index = execution
            .find("publish_frozen_spins_runtime_status_for_execution_plan(")
            .expect("scripted execution must publish the runner-owned certificate");
        let run_index = execution
            .find("run_planned_problem_with_live_preview_interruptible")
            .expect("scripted execution must invoke the one-shot runner");

        assert!(
            certificate_index < run_index,
            "Frozen Spins activation status must be published before the first solver step"
        );
    }

    #[test]
    fn headless_mode_does_not_keep_interactive_session_alive() {
        assert!(interactive_session_should_stay_alive(false, true, false));
        assert!(interactive_session_should_stay_alive(true, false, false));
        assert!(!interactive_session_should_stay_alive(false, true, true));
        assert!(!interactive_session_should_stay_alive(true, true, true));
    }

    #[test]
    fn wait_for_solve_prompt_mentions_mesh_only_for_fem() {
        assert!(
            wait_for_solve_prompt(&tiny_fem_plan()).contains("adjust mesh"),
            "FEM wait message should mention mesh refinement"
        );
        assert!(
            !wait_for_solve_prompt(&tiny_fdm_plan()).contains("adjust mesh"),
            "FDM wait message should stay generic"
        );
    }

    #[test]
    fn wait_for_solve_command_classification_handles_compute_fields_and_run() {
        assert_eq!(
            classify_wait_for_solve_command("compute_fields"),
            WaitForSolveCommandAction::RefreshFields
        );
        assert_eq!(
            classify_wait_for_solve_command("set_solver_profile"),
            WaitForSolveCommandAction::ConfigureProfiler
        );
        assert_eq!(
            classify_wait_for_solve_command("run"),
            WaitForSolveCommandAction::StartSolver
        );
        assert_eq!(
            classify_wait_for_solve_command("solve"),
            WaitForSolveCommandAction::StartSolver
        );
        assert_eq!(
            classify_wait_for_solve_command("compute"),
            WaitForSolveCommandAction::StartSolver
        );
        assert_eq!(
            classify_wait_for_solve_command("relax"),
            WaitForSolveCommandAction::StartSolver
        );
        assert_eq!(
            classify_wait_for_solve_command("display_sync"),
            WaitForSolveCommandAction::Ignore
        );
    }

    #[test]
    fn compute_fields_refresh_uses_field_materialization_quantities() {
        let source = include_str!("orchestrator.rs");
        let function_body = source
            .split("fn refresh_problem_preview_state(")
            .nth(1)
            .and_then(|rest| rest.split("fn refresh_problem_energy_state(").next())
            .expect("refresh_problem_preview_state should be present");

        assert!(
            function_body.contains("field_materialization_quantity_ids()"),
            "compute_fields must materialize spatial scalar quantities such as eden_total"
        );
        assert!(
            !function_body.contains("cached_preview_quantity_ids()"),
            "compute_fields must not use the vector-only preview cache quantity list"
        );
    }

    #[test]
    fn compute_fields_refresh_publishes_auxiliary_carriers() {
        let source = include_str!("orchestrator.rs");
        let function_body = source
            .split("fn refresh_problem_preview_state(")
            .nth(1)
            .and_then(|rest| rest.split("fn refresh_problem_energy_state(").next())
            .expect("refresh_problem_preview_state should be present");

        assert!(function_body.contains("snapshot_planned_problem_vector_field_batch"));
        assert!(function_body.contains("replace_auxiliary_artifacts"));
        assert!(function_body.contains("full_field_materialization_request"));
    }

    #[test]
    fn display_sync_refresh_stays_bounded_to_the_preview_request() {
        let source = include_str!("orchestrator.rs");
        let display_sync_arm = source
            .split("\"display_sync\" => {")
            .nth(1)
            .and_then(|rest| rest.split("\"load_state\" => {").next())
            .expect("display_sync command arm should be present");

        assert!(display_sync_arm.contains("ProblemPreviewRefreshMode::PreviewOnly"));
        assert!(!display_sync_arm.contains("ProblemPreviewRefreshMode::MaterializeFields"));
        assert!(!display_sync_arm.contains("full_field_materialization_request"));
    }

    #[test]
    fn compute_current_energies_command_classifies_as_energy_refresh_not_solver_start() {
        assert_eq!(
            classify_wait_for_solve_command("compute_energies"),
            WaitForSolveCommandAction::RefreshEnergies
        );
    }

    #[test]
    fn fem_mesh_payload_preserves_exact_segments_for_shared_domain_plan() {
        let payload = fem_mesh_payload_from_backend_plan(&tiny_shared_domain_fem_plan())
            .expect("shared-domain FEM backend plan should yield a mesh payload");

        assert_eq!(payload.object_segments.len(), 2);
        assert_eq!(payload.element_markers, vec![1, 2]);
        assert_eq!(payload.boundary_markers, vec![1, 2]);
        assert_eq!(payload.object_segments[0].object_id, "left");
        assert_eq!(payload.object_segments[0].element_count, 1);
        assert_eq!(payload.object_segments[1].object_id, "right");
        assert_eq!(payload.object_segments[1].boundary_face_count, 1);
    }

    #[test]
    fn scripted_relax_to_single_k_builds_typed_handoff_only_from_accepted_completion() {
        let BackendPlanIR::Fem(source) = tiny_fem_plan() else {
            unreachable!()
        };
        let source_backend = BackendPlanIR::Fem(source.clone());
        let source_mesh = fullmag_runner::FemMeshPayload::from(&source);
        let m0 = source.initial_magnetization.clone();
        let fields = certified_fields(source_mesh.nodes.len());
        let recomputed = recomputed_certificate(&source, &source_mesh, &m0, &fields);
        let target = fullmag_ir::FemEigenPlanIR {
            mesh_name: source.mesh_name,
            mesh_source: source.mesh_source,
            mesh: source.mesh,
            object_segments: source.object_segments,
            mesh_parts: source.mesh_parts,
            mesh_build_report: source.mesh_build_report,
            domain_mesh_mode: source.domain_mesh_mode,
            domain_frame: source.domain_frame,
            fe_order: source.fe_order,
            hmax: source.hmax,
            equilibrium_magnetization: m0.clone(),
            material: source.material,
            operator: fullmag_ir::EigenOperatorConfigIR {
                kind: fullmag_ir::EigenOperatorIR::Full2x2,
                include_demag: true,
            },
            count: 2,
            target: fullmag_ir::EigenTargetIR::Lowest,
            equilibrium: fullmag_ir::EquilibriumSourceIR::RelaxedInitialState,
            k_sampling: Some(fullmag_ir::KSamplingIR::Single {
                k_vector: [0.0, 0.0, 0.0],
            }),
            bias_field_samples: Vec::new(),
            normalization: fullmag_ir::EigenNormalizationIR::UnitL2,
            damping_policy: fullmag_ir::EigenDampingPolicyIR::Ignore,
            enable_exchange: source.enable_exchange,
            enable_demag: source.enable_demag,
            interfacial_dmi: source.interfacial_dmi,
            dmi_interface_normal: source.dmi_interface_normal,
            bulk_dmi: source.bulk_dmi,
            external_field: source.external_field,
            gyromagnetic_ratio: source.gyromagnetic_ratio,
            precision: source.precision,
            exchange_bc: source.exchange_bc,
            spin_wave_bc: fullmag_ir::SpinWaveBoundaryConditionIR::default(),
            demag_realization: None,
            air_box_config: None,
            mode_tracking: None,
            dispersion_validation: None,
            k0_kittel_validation: None,
            solver_policy: None,
        };
        let backend = BackendPlanIR::FemEigen(target);
        let completion = stage_completion(fullmag_ir::StageStopReason::Torque);
        let source_stage = ContinuationStageSource {
            run_id: "run-test".to_string(),
            stage_id: "stage-000".to_string(),
            stage_kind: "flat_relax".to_string(),
            is_relaxation: true,
        };
        let handoff = accepted_relax_handoff_from_completed_stage(
            &source_backend,
            &source_stage,
            &source_mesh,
            &completion,
            &m0,
            &fields,
            &fields,
            &recomputed,
        )
        .expect("accepted relax output should create a typed handoff");
        assert!(handoff.is_some());
        let handoff = handoff.expect("accepted Relax must publish handoff v3 immediately");
        assert!(
            accepted_relax_handoff_for_eigen_stage(&backend, Some(&m0), Some(&handoff))
                .expect("Eigen should consume the prepared handoff")
                .is_some()
        );

        let mut tampered_accepted_fields = fields.clone();
        tampered_accepted_fields.h_eff_a_per_m[0][0] += 1.0;
        let error = accepted_relax_handoff_from_completed_stage(
            &source_backend,
            &source_stage,
            &source_mesh,
            &completion,
            &m0,
            &tampered_accepted_fields,
            &fields,
            &recomputed,
        )
        .expect_err("a digest-stale accepted endpoint must fail closed");
        assert!(error
            .to_string()
            .contains("certified_fields_invalid"));

        let mut tampered_recompute = recomputed.clone();
        tampered_recompute.max_h_demag_difference_a_per_m = 1.0;
        let error = accepted_relax_handoff_from_completed_stage(
            &source_backend,
            &source_stage,
            &source_mesh,
            &completion,
            &m0,
            &fields,
            &fields,
            &tampered_recompute,
        )
        .expect_err("a digest-stale recompute certificate must fail closed");
        assert!(error.to_string().contains("content digest mismatch"));

        let mut mismatched_equilibrium = recomputed.clone();
        mismatched_equilibrium.equilibrium_content_sha256 = format!("sha256:{}", "a".repeat(64));
        mismatched_equilibrium.content_sha256 =
            fullmag_runner::recomputed_fem_linearization_certificate_sha256(
                &mismatched_equilibrium,
            )
            .expect("equilibrium-mismatch certificate digest");
        let error = accepted_relax_handoff_from_completed_stage(
            &source_backend,
            &source_stage,
            &source_mesh,
            &completion,
            &m0,
            &fields,
            &fields,
            &mismatched_equilibrium,
        )
        .expect_err("a certificate for a different equilibrium must fail closed");
        assert!(error.to_string().contains("equilibrium digest mismatch"));

        let mut mismatched_mesh = recomputed.clone();
        mismatched_mesh.mesh_topology_sha256 = format!("sha256:{}", "b".repeat(64));
        mismatched_mesh.content_sha256 =
            fullmag_runner::recomputed_fem_linearization_certificate_sha256(&mismatched_mesh)
                .expect("mesh-mismatch certificate digest");
        let error = accepted_relax_handoff_from_completed_stage(
            &source_backend,
            &source_stage,
            &source_mesh,
            &completion,
            &m0,
            &fields,
            &fields,
            &mismatched_mesh,
        )
        .expect_err("a certificate for a different mesh must fail closed");
        assert!(error.to_string().contains("mesh topology digest mismatch"));

        let mut mismatched_fields = recomputed.clone();
        mismatched_fields.recomputed_fields_content_sha256 = format!("sha256:{}", "c".repeat(64));
        mismatched_fields.content_sha256 =
            fullmag_runner::recomputed_fem_linearization_certificate_sha256(&mismatched_fields)
                .expect("field-mismatch certificate digest");
        let error = accepted_relax_handoff_from_completed_stage(
            &source_backend,
            &source_stage,
            &source_mesh,
            &completion,
            &m0,
            &fields,
            &fields,
            &mismatched_fields,
        )
        .expect_err("a certificate for different recomputed fields must fail closed");
        assert!(error
            .to_string()
            .contains("recomputed field digest mismatch"));

        let artifact_dir = temp_test_dir("relax-save-eigen-handoff");
        let save_action = ResolvedScriptStageAction::SaveState {
            artifact_name: "equilibrium".to_string(),
            format: Some("json".to_string()),
            dataset: None,
        };
        let save_outcome = execute_synthetic_stage(
            &save_action,
            &artifact_dir,
            &artifact_dir.join("stage_save"),
            &source_backend,
            Some(&m0),
        )
        .expect("intermediate save_state stage should execute");
        let mut continuation_magnetization = Some(m0.clone());
        let mut continuation_source = Some(continuation_source_from_backend_plan(&source_backend));
        let mut continuation_fem_mesh_payload = Some(source_mesh.clone());
        let mut continuation_completion = Some(completion.clone());
        let mut continuation_stage_source = Some(source_stage.clone());
        let mut continuation_accepted_fields = Some(fields.clone());
        let mut continuation_certified_fields = Some(fields.clone());
        let mut continuation_relax_handoff = Some(handoff.clone());

        replace_continuation_after_synthetic_stage(
            &mut continuation_magnetization,
            &mut continuation_source,
            &mut continuation_fem_mesh_payload,
            &mut continuation_completion,
            &mut continuation_stage_source,
            &mut continuation_accepted_fields,
            &mut continuation_certified_fields,
            &mut continuation_relax_handoff,
            save_outcome.magnetization,
            false,
        );

        assert_eq!(continuation_magnetization.as_deref(), Some(m0.as_slice()));
        assert!(continuation_source.is_none());
        assert!(continuation_fem_mesh_payload.is_none());
        assert!(continuation_completion.is_none());
        assert!(continuation_stage_source.is_none());
        assert!(continuation_accepted_fields.is_none());
        assert!(continuation_certified_fields.is_none());
        assert!(continuation_relax_handoff.is_none());
        let error = accepted_relax_handoff_for_eigen_stage(
            &backend,
            continuation_magnetization.as_deref(),
            continuation_relax_handoff.as_ref(),
        )
        .expect_err("save_state must invalidate the preceding relaxation handoff");
        assert!(error
            .to_string()
            .contains("missing the accepted Relax handoff v3"));

        let mut continuation_magnetization = Some(m0.clone());
        let mut continuation_source = Some(continuation_source_from_backend_plan(&source_backend));
        let mut continuation_fem_mesh_payload = Some(source_mesh.clone());
        let mut continuation_completion = Some(completion.clone());
        let mut continuation_stage_source = Some(source_stage.clone());
        let mut continuation_accepted_fields = Some(fields.clone());
        let mut continuation_certified_fields = Some(fields.clone());
        let mut continuation_relax_handoff = Some(handoff.clone());
        replace_continuation_after_synthetic_stage(
            &mut continuation_magnetization,
            &mut continuation_source,
            &mut continuation_fem_mesh_payload,
            &mut continuation_completion,
            &mut continuation_stage_source,
            &mut continuation_accepted_fields,
            &mut continuation_certified_fields,
            &mut continuation_relax_handoff,
            m0.clone(),
            true,
        );
        assert!(
            continuation_source.is_some(),
            "change_device must preserve the typed continuation source"
        );
        assert!(continuation_accepted_fields.is_some());
        assert!(accepted_relax_handoff_for_eigen_stage(
            &backend,
            continuation_magnetization.as_deref(),
            continuation_relax_handoff.as_ref(),
        )
        .expect("change_device must preserve the certified relaxation handoff")
        .is_some());
        let _ = fs::remove_dir_all(&artifact_dir);

        let mut rejected = completion;
        rejected.converged = false;
        let error = accepted_relax_handoff_from_completed_stage(
            &source_backend,
            &source_stage,
            &source_mesh,
            &rejected,
            &m0,
            &fields,
            &fields,
            &recomputed,
        )
        .expect_err("unaccepted relax output must fail closed before the runner");
        assert!(error.to_string().contains("completion_not_accepted"));

        let non_relax_source = ContinuationStageSource {
            stage_kind: "flat_run".to_string(),
            is_relaxation: false,
            ..source_stage
        };
        assert!(accepted_relax_handoff_from_completed_stage(
            &source_backend,
            &non_relax_source,
            &source_mesh,
            &stage_completion(fullmag_ir::StageStopReason::Torque),
            &m0,
            &fields,
            &fields,
            &recomputed,
        )
        .expect("a non-relaxation stage should invalidate rather than create a handoff")
        .is_none());
    }

    #[test]
    fn profiled_step_update_clone_carries_only_mesh_generation_and_clone_count() {
        let mut update = test_step_update(7);
        update.fem_mesh_generation_id = Some("mesh-gen-1".to_string());

        let adjusted = offset_step_update(update, 10, 2.0, true);

        assert_eq!(adjusted.stats.step, 17);
        assert_eq!(adjusted.stats.time, 2.0);
        assert_eq!(adjusted.stats.step_update_deep_clone_count, 0);
        assert_eq!(adjusted.stats.mesh_payload_wall_time_ns, 0);
        assert_eq!(
            adjusted.fem_mesh_generation_id.as_deref(),
            Some("mesh-gen-1")
        );
        assert!(adjusted.finished);
    }

    #[test]
    fn fem_stage_mesh_payload_is_built_once_until_generation_changes() {
        let plan = tiny_shared_domain_fem_plan();
        let stage_mesh = fem_mesh_payload_from_backend_plan(&plan)
            .expect("shared-domain plan should produce a FEM stage mesh");
        let stage_generation = stage_mesh.generation_id.clone();
        for step in 1..=12 {
            let mut update = test_step_update(step);
            update.fem_mesh_generation_id = stage_generation.clone();
            let adjusted = offset_step_update(update, 0, 0.0, false);
            assert_eq!(adjusted.fem_mesh_generation_id, stage_generation);
            assert_eq!(adjusted.stats.step_update_deep_clone_count, 0);
        }

        let mut remeshed_plan = plan.clone();
        let BackendPlanIR::Fem(remeshed_fem) = &mut remeshed_plan else {
            unreachable!("fixture is FEM")
        };
        remeshed_fem.mesh.nodes[7][0] += 0.25;
        let remeshed = fem_mesh_payload_from_backend_plan(&remeshed_plan)
            .expect("remesh should produce a replacement FEM stage mesh");
        assert_ne!(remeshed.generation_id, stage_mesh.generation_id);
    }

    #[test]
    fn heartbeat_snapshot_retains_only_lightweight_progress() {
        let initial = test_step_update(0);
        let snapshot = std::sync::Arc::new(std::sync::Mutex::new(
            crate::stage_heartbeat::StageHeartbeatProgress::new(&initial),
        ));
        let mut heartbeat = StageProgressHeartbeat {
            snapshot: std::sync::Arc::clone(&snapshot),
            stop_tx: None,
            join_handle: None,
        };
        let mut adjusted = offset_step_update(test_step_update(1), 0, 0.0, false);
        assert_eq!(adjusted.stats.step_update_deep_clone_count, 0);
        heartbeat.record(&mut adjusted);
        assert_eq!(adjusted.stats.step_update_deep_clone_count, 0);
        assert_eq!(
            snapshot.lock().unwrap().stats.step_update_deep_clone_count,
            0
        );
    }

    #[test]
    fn lightweight_heartbeat_preserves_heavy_live_field_identity() {
        let mut state = test_workspace_state();
        state.live_state.latest_step.grid = [17, 19, 23];
        state.live_state.latest_step.fem_mesh_generation_id = Some("mesh-gen-stable".to_string());
        state.live_state.latest_step.magnetization = Some(vec![1.0, 0.0, 0.0]);
        state.live_state.latest_step.preview_field = Some(test_preview_field("h_eff", 1, 2.0));
        let mut update = test_step_update(9);
        update.stats.e_total = 42.0;
        update.stats.e_rotated_dmi = 17.0;
        let progress = crate::stage_heartbeat::StageHeartbeatProgress::new(&update);

        progress.apply_to_live_step(&mut state.live_state.latest_step);

        assert_eq!(state.live_state.latest_step.step, 9);
        assert_eq!(state.live_state.latest_step.e_rotated_dmi, 17.0);
        assert_eq!(state.live_state.latest_step.e_total, 42.0);
        assert_eq!(state.live_state.latest_step.grid, [17, 19, 23]);
        assert_eq!(
            state
                .live_state
                .latest_step
                .fem_mesh_generation_id
                .as_deref(),
            Some("mesh-gen-stable")
        );
        assert_eq!(
            state.live_state.latest_step.magnetization.as_deref(),
            Some([1.0, 0.0, 0.0].as_slice())
        );
        assert!(state.live_state.latest_step.preview_field.is_some());
    }

    #[test]
    fn fem_live_mesh_payload_carries_matching_initial_magnetization() {
        let (payload, initial_magnetization) =
            fem_live_mesh_payload_and_initial_magnetization(&tiny_shared_domain_fem_plan())
                .expect("shared-domain FEM backend plan should yield a live mesh payload");

        assert_eq!(payload.nodes.len(), initial_magnetization.len());
        assert_eq!(payload.object_segments.len(), 2);
    }

    #[test]
    fn stage_execution_records_full_fem_mesh_identity() {
        let asset = fullmag_runner::StageFemMeshAsset::build_from_backend_plan(&tiny_fem_plan())
            .expect("FEM stage mesh asset");
        let expected_generation_id = asset.identity.generation_id().to_string();
        let expected_topology_fingerprint =
            fullmag_runner::fem_mesh_topology_fingerprint(&asset.payload);

        let mut scripted = scripted_stage_execution_state(
            1,
            0,
            "relax",
            "running",
            Some("cmd-scripted"),
            Some(1_700_000_000_000),
            None,
            None,
            None,
            None,
        );
        attach_stage_fem_mesh_identity(&mut scripted, 0, Some(&asset));
        assert_eq!(
            scripted.stages[0].mesh_generation_id.as_deref(),
            Some(expected_generation_id.as_str())
        );
        assert_eq!(
            scripted.stages[0].mesh_topology_fingerprint.as_deref(),
            Some(expected_topology_fingerprint.as_str())
        );
        assert_eq!(scripted.stages[0].mesh_revision, None);

        let mut interactive = ActiveSequenceState::single_current();
        interactive.mark_current_started("cmd-interactive", 1_700_000_000_000, None, None);
        interactive.mark_current_fem_mesh_identity(Some(&asset));
        let interactive_execution = interactive.stage_execution(Some("relax"), "running");
        assert_eq!(
            interactive_execution.stages[0]
                .mesh_generation_id
                .as_deref(),
            Some(expected_generation_id.as_str())
        );
        assert_eq!(
            interactive_execution.stages[0]
                .mesh_topology_fingerprint
                .as_deref(),
            Some(expected_topology_fingerprint.as_str())
        );
        assert_eq!(interactive_execution.stages[0].mesh_revision, None);
    }

    #[test]
    fn initial_live_state_publishes_shared_domain_fem_mesh_before_solver_start() {
        let plan = tiny_shared_domain_fem_plan();
        let asset = fullmag_runner::StageFemMeshAsset::build_from_backend_plan(&plan)
            .expect("shared-domain FEM asset");
        let update = initial_step_update(&plan, Some(asset.identity.generation_id().to_string()));

        let (live_state, _) = initial_live_state_manifest_from_backend_plan(
            &update,
            &plan,
            Some(asset.payload),
            None,
        )
        .expect("initial FEM live state should carry shared-domain mesh");

        let generation_id = live_state.latest_step.fem_mesh_generation_id.as_deref();
        assert!(
            generation_id.is_some(),
            "FEM mesh generation should be referenced before compute"
        );
        let node_count = fem_mesh_payload_from_backend_plan(&plan)
            .expect("shared-domain plan should produce a stage mesh")
            .nodes
            .len();
        assert_eq!(
            live_state
                .latest_step
                .magnetization
                .as_ref()
                .map(|values| values.len()),
            Some(node_count * 3)
        );
    }

    #[test]
    fn initial_live_state_uses_loaded_initial_magnetization_override() {
        let plan = tiny_shared_domain_fem_plan();
        let asset = fullmag_runner::StageFemMeshAsset::build_from_backend_plan(&plan)
            .expect("shared-domain FEM asset");
        let update = initial_step_update(&plan, Some(asset.identity.generation_id().to_string()));
        let override_m = vec![
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
            [1.0, 0.0, 0.0],
            [-1.0, 0.0, 0.0],
            [0.0, -1.0, 0.0],
            [0.0, 0.0, -1.0],
            [0.5, 0.5, 0.0],
            [0.0, 0.5, 0.5],
        ];

        let (live_state, _) = initial_live_state_manifest_from_backend_plan(
            &update,
            &plan,
            Some(asset.payload),
            Some(&override_m),
        )
        .expect("initial FEM live state should accept matching override");

        assert_eq!(
            live_state.latest_step.magnetization.as_deref(),
            Some(
                &[
                    0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, -1.0, 0.0, 0.0, 0.0, -1.0, 0.0,
                    0.0, 0.0, -1.0, 0.5, 0.5, 0.0, 0.0, 0.5, 0.5
                ][..]
            )
        );
    }

    #[test]
    fn initial_magnetization_state_override_records_runtime_provenance() {
        let dir = temp_test_dir("initial-m-state-provenance");
        let state_path = dir.join("m_repeated_unit.json");
        fs::write(
            &state_path,
            serde_json::json!({
                "kind": "magnetization_state",
                "observable": "m",
                "format": "json",
                "vector_count": 2,
                "values": [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]],
            })
            .to_string(),
        )
        .expect("state fixture should be writable");
        let args = ScriptCli {
            script: PathBuf::from(
                "examples/fem_periodic_antidot_relax_exchange_coupled_supercell_3x3.py",
            ),
            interactive: false,
            backend: None,
            mode: None,
            precision: None,
            output_dir: None,
            temp_dir: None,
            data_format: None,
            temp_cleanup: None,
            existing_output: None,
            initial_magnetization_state: Some(state_path.clone()),
            initial_magnetization_state_format: Some("json".to_string()),
            initial_magnetization_state_dataset: None,
            initial_magnetization_state_sample_index: None,
            session_root: PathBuf::from(".fullmag/local-live/history"),
            headless: true,
            dev: false,
            json: true,
            web_port: None,
            ui: None,
            api_port: None,
            wait_for_solve: false,
            expect_script_sha256: None,
            receipt: None,
            launched_by: None,
            python: None,
        };

        let loaded =
            initial_magnetization_state_override(&args).expect("override state should load");

        assert_eq!(loaded.as_ref().map(|state| state.values.len()), Some(2));
        let provenance = loaded
            .as_ref()
            .map(|state| state.provenance.clone())
            .expect("loaded override should carry provenance");
        assert_eq!(provenance["kind"], "initial_magnetization_state_override");
        assert_eq!(provenance["source_path"], state_path.display().to_string());
        assert_eq!(provenance["format"], "json");
        assert_eq!(provenance["vector_count"], 2);

        let mut problem = ProblemIR::bootstrap_example();
        attach_initial_magnetization_state_override_metadata(&mut problem, Some(&provenance));
        assert_eq!(
            problem.problem_meta.runtime_metadata["initial_magnetization_state_override"],
            provenance
        );
    }

    #[test]
    fn initial_magnetization_state_override_updates_problem_initial_state() {
        let values = vec![[0.0, 1.0, 0.0], [0.0, 0.0, 1.0]];
        let provenance = serde_json::json!({
            "kind": "initial_magnetization_state_override",
            "source_path": "states/m_repeated_unit.json",
            "format": "json",
            "dataset": null,
            "sample_index": null,
            "vector_count": values.len(),
        });
        let state = LoadedInitialMagnetizationState {
            values: values.clone(),
            provenance: provenance.clone(),
        };
        let mut problem = ProblemIR::bootstrap_example();

        apply_initial_magnetization_state_override(&mut problem, Some(&state))
            .expect("override should update problem initial state");

        let initial = problem.magnets[0]
            .initial_magnetization
            .as_ref()
            .expect("override should set sampled initial magnetization");
        match initial {
            InitialMagnetizationIR::SampledField { values: sampled } => {
                assert_eq!(sampled, &values);
            }
            other => panic!("expected sampled initial magnetization, got {other:?}"),
        }
        assert_eq!(
            problem.problem_meta.runtime_metadata["initial_magnetization_state_override"],
            provenance
        );
    }

    #[test]
    fn default_domain_region_markers_follow_geometry_order() {
        let markers = default_domain_region_markers(&[
            GeometryEntryIR::Box {
                name: "left".to_string(),
                size: [1.0, 1.0, 1.0],
            },
            GeometryEntryIR::Box {
                name: "right".to_string(),
                size: [1.0, 1.0, 1.0],
            },
        ]);

        assert_eq!(markers.len(), 2);
        assert_eq!(markers[0].geometry_name, "left");
        assert_eq!(markers[0].marker, 1);
        assert_eq!(markers[1].geometry_name, "right");
        assert_eq!(markers[1].marker, 2);
    }

    fn test_material(name: &str) -> MaterialIR {
        MaterialIR {
            name: name.to_string(),
            saturation_magnetisation: 800e3,
            exchange_stiffness: 13e-12,
            damping: 0.5,
            uniaxial_anisotropy: None,
            anisotropy_axis: None,
            uniaxial_anisotropy_k2: None,
            cubic_anisotropy_kc1: None,
            cubic_anisotropy_kc2: None,
            cubic_anisotropy_kc3: None,
            cubic_anisotropy_axis1: None,
            cubic_anisotropy_axis2: None,
            ms_field: None,
            a_field: None,
            alpha_field: None,
            ku_field: None,
            ku2_field: None,
            kc1_field: None,
            kc2_field: None,
            kc3_field: None,
            interfacial_dmi: None,
            bulk_dmi: None,
            dind_field: None,
            dbulk_field: None,
        }
    }

    #[test]
    fn remeshed_problem_snapshot_applies_scene_patch_to_solver_stage() {
        let mut stages = vec![ResolvedScriptStage::solver(
            tiny_problem_with_shared_domain_asset(),
            1.0,
            "relax",
        )];
        let scene_patch = SceneProblemPatch {
            geometry_entries: vec![
                GeometryEntryIR::Box {
                    name: "left".to_string(),
                    size: [1.0, 1.0, 1.0],
                },
                GeometryEntryIR::Box {
                    name: "right".to_string(),
                    size: [2.0, 1.0, 1.0],
                },
            ],
            regions: vec![
                RegionIR {
                    name: "left_region".to_string(),
                    geometry: "left".to_string(),
                },
                RegionIR {
                    name: "right_region".to_string(),
                    geometry: "right".to_string(),
                },
            ],
            materials: vec![test_material("mat_left"), test_material("mat_right")],
            object_regions: Vec::new(),
            magnets: vec![
                MagnetIR {
                    object_id: Some("left_magnet".to_string()),
                    name: "left_magnet".to_string(),
                    region: "left_region".to_string(),
                    material: "mat_left".to_string(),
                    absorbing_boundary: None,
                    initial_magnetization: Some(InitialMagnetizationIR::Uniform {
                        value: [1.0, 0.0, 0.0],
                    }),
                },
                MagnetIR {
                    object_id: Some("right_magnet".to_string()),
                    name: "right_magnet".to_string(),
                    region: "right_region".to_string(),
                    material: "mat_right".to_string(),
                    absorbing_boundary: None,
                    initial_magnetization: Some(InitialMagnetizationIR::Uniform {
                        value: [0.0, 1.0, 0.0],
                    }),
                },
            ],
            universe: Some(serde_json::json!({
                "kind": "box",
                "extent": [4.0, 2.0, 2.0]
            })),
            fdm: None,
            runtime_selection: None,
        };
        let new_mesh = MeshIR {
            mesh_name: "study_domain_after_ui_patch".to_string(),
            nodes: vec![
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 0.0, 1.0],
                [2.0, 0.0, 0.0],
            ],
            cells: fullmag_ir::FemConnectivityIR::from_tet4(vec![[0, 1, 2, 3]]),
            element_markers: vec![1],
            facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(vec![[0, 1, 2]]),
            boundary_markers: vec![1],
            periodic_boundary_pairs: Vec::new(),
            periodic_node_pairs: Vec::new(),
            per_domain_quality: Default::default(),
        };

        apply_remeshed_problem_snapshot_to_stages(
            &mut stages,
            Some(&scene_patch),
            &new_mesh,
            3.5,
            true,
            &[],
            &[],
            None,
        )
        .expect("scene remesh snapshot should update solver stage");

        let problem = &stages[0].ir;
        assert_eq!(problem.geometry.entries.len(), 2);
        assert_eq!(problem.geometry.entries[1].name(), "right");
        assert_eq!(problem.regions.len(), 2);
        assert_eq!(problem.materials.len(), 2);
        assert_eq!(problem.magnets.len(), 2);
        assert_eq!(
            problem
                .problem_meta
                .runtime_metadata
                .get("study_universe")
                .and_then(|value| value.get("kind"))
                .and_then(|value| value.as_str()),
            Some("box")
        );
        let domain_asset = problem
            .geometry_assets
            .as_ref()
            .and_then(|assets| assets.fem_domain_mesh_asset.as_ref())
            .expect("shared-domain solver stage should retain a domain mesh asset");
        assert_eq!(domain_asset.mesh.as_ref(), Some(&new_mesh));
        assert_eq!(domain_asset.region_markers.len(), 2);
        assert_eq!(domain_asset.region_markers[0].geometry_name, "left");
        assert_eq!(domain_asset.region_markers[1].geometry_name, "right");
        assert_eq!(
            problem
                .backend_policy
                .discretization_hints
                .as_ref()
                .and_then(|hints| hints.fem.as_ref())
                .map(|hints| hints.hmax),
            Some(3.5)
        );
    }

    #[test]
    fn fem_overrides_update_shared_domain_asset_instead_of_object_mesh_assets() {
        let mut problem = tiny_problem_with_shared_domain_asset();
        let new_mesh = MeshIR {
            mesh_name: "study_domain".to_string(),
            nodes: vec![
                [0.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 0.0, 1.0],
            ],
            cells: fullmag_ir::FemConnectivityIR::from_tet4(vec![[0, 1, 2, 3]]),
            element_markers: vec![1],
            facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(vec![[0, 1, 2]]),
            boundary_markers: vec![7],
            periodic_boundary_pairs: Vec::new(),
            periodic_node_pairs: Vec::new(),
            per_domain_quality: Default::default(),
        };

        apply_current_fem_overrides(&mut problem, Some(&new_mesh), Some(2.5), None);

        let assets = problem
            .geometry_assets
            .as_ref()
            .expect("problem should retain geometry assets");
        let domain_asset = assets
            .fem_domain_mesh_asset
            .as_ref()
            .expect("shared-domain asset should still be present");
        assert_eq!(domain_asset.mesh.as_ref(), Some(&new_mesh));
        assert_eq!(domain_asset.region_markers.len(), 2);
        assert_eq!(domain_asset.region_markers[0].geometry_name, "left");
        assert_eq!(domain_asset.region_markers[1].geometry_name, "right");
        assert_eq!(
            problem
                .backend_policy
                .discretization_hints
                .as_ref()
                .and_then(|hints| hints.fem.as_ref())
                .map(|hints| hints.hmax),
            Some(2.5)
        );
    }

    #[test]
    fn synthetic_stage_actions_round_trip_json_state_artifacts() {
        let artifact_dir = temp_test_dir("synthetic-stage");
        let backend_plan = tiny_fdm_plan();
        let current = vec![[0.0, 1.0, 0.0]];

        let save_stage_dir = artifact_dir.join("stage_save");
        let save_outcome = execute_synthetic_stage(
            &ResolvedScriptStageAction::SaveState {
                artifact_name: "state_snapshot".to_string(),
                format: Some("json".to_string()),
                dataset: None,
            },
            &artifact_dir,
            &save_stage_dir,
            &backend_plan,
            Some(current.as_slice()),
        )
        .expect("save_state should succeed");
        let saved_path = artifact_dir.join("states").join("state_snapshot.json");
        assert!(saved_path.is_file());
        assert_eq!(save_outcome.magnetization, current);
        assert!(save_stage_dir.join("synthetic_stage.json").is_file());

        let load_stage_dir = artifact_dir.join("stage_load");
        let load_outcome = execute_synthetic_stage(
            &ResolvedScriptStageAction::LoadState {
                artifact_name: Some("state_snapshot".to_string()),
                state_path: None,
                format: Some("json".to_string()),
                dataset: None,
                sample_index: None,
            },
            &artifact_dir,
            &load_stage_dir,
            &backend_plan,
            None,
        )
        .expect("load_state should succeed");
        assert_eq!(load_outcome.magnetization, current);
        assert!(load_stage_dir.join("synthetic_stage.json").is_file());

        let export_stage_dir = artifact_dir.join("stage_export");
        let export_outcome = execute_synthetic_stage(
            &ResolvedScriptStageAction::Export {
                artifact_name: Some("magnetization_export".to_string()),
                quantity: "magnetization".to_string(),
                format: "json".to_string(),
                dataset: None,
            },
            &artifact_dir,
            &export_stage_dir,
            &backend_plan,
            Some(current.as_slice()),
        )
        .expect("export should succeed");
        let exported_path = artifact_dir
            .join("exports")
            .join("magnetization_export.json");
        assert!(exported_path.is_file());
        assert_eq!(export_outcome.magnetization, current);
        assert!(export_stage_dir.join("synthetic_stage.json").is_file());

        let remove_stage_dir = artifact_dir.join("stage_remove_drive");
        let remove_outcome = execute_synthetic_stage(
            &ResolvedScriptStageAction::RemoveFieldDrive {
                drive_id: "antenna".to_string(),
            },
            &artifact_dir,
            &remove_stage_dir,
            &backend_plan,
            Some(current.as_slice()),
        )
        .expect("remove_field_drive should succeed");
        assert_eq!(remove_outcome.magnetization, current);
        assert_eq!(
            remove_outcome.message,
            "Removed regional field drive antenna"
        );
        let removal: serde_json::Value = serde_json::from_slice(
            &fs::read(remove_stage_dir.join("synthetic_stage.json"))
                .expect("removal stage record should exist"),
        )
        .expect("removal stage record should be JSON");
        assert_eq!(removal["kind"], "remove_field_drive");
        assert_eq!(removal["drive_id"], "antenna");
        assert_eq!(removal["vector_count"], 1);

        let _ = fs::remove_dir_all(&artifact_dir);
    }

    #[test]
    fn auto_sampling_stage_record_preserves_planner_resolution() {
        let stage_dir = temp_test_dir("auto-sampling-stage-record");
        let resolution = serde_json::json!({
            "requested_policy": {"kind": "auto_sinc_cutoff", "nyquist_guard_factor": 1.3},
            "sample_period_s": 7.692307692307691e-11,
            "maximum_cutoff_hz": 5.0e9,
            "nyquist_guard_factor": 1.3,
            "target_nyquist_hz": 6.5e9,
            "sampling_frequency_hz": 13.0e9,
            "source_drive_ids": ["drive-5"],
            "target_stage_id": "excite"
        });

        write_sampling_resolution_stage_record(&stage_dir, Some(&resolution))
            .expect("sampling stage record should write");

        let record: serde_json::Value = serde_json::from_slice(
            &fs::read(stage_dir.join("sampling_stage_record.v1.json"))
                .expect("sampling stage record should be readable"),
        )
        .expect("sampling stage record should be JSON");
        assert_eq!(record["schema_version"], "sampling_stage_record.v1");
        assert_eq!(record["sampling_resolution"], resolution);
        let _ = fs::remove_dir_all(stage_dir);
    }

    // Synthetic non-direct lifecycle fixture; not a scientific field-solve result.
    fn write_valid_antenna_catalog_asset(
        artifact_dir: &Path,
    ) -> (fullmag_ir::AntennaFieldSolutionRefIR, PathBuf) {
        use sha2::{Digest, Sha256};
        let directory = artifact_dir.join("antenna/field_solutions/basis/afs-test");
        fs::create_dir_all(&directory).unwrap();
        let binary_ref = |relative: &str, values: &[f64], layout: &str, unit: &str| {
            let bytes = values.iter().flat_map(|value| value.to_le_bytes()).collect::<Vec<_>>();
            let path = directory.join(relative);
            fs::create_dir_all(path.parent().unwrap()).unwrap();
            fs::write(path, &bytes).unwrap();
            serde_json::json!({
                "path": format!("antenna/field_solutions/basis/{relative}"),
                "sha256": format!("{:x}", Sha256::digest(&bytes)),
                "scalar_type": "float64_le", "layout": layout, "unit": unit,
                "value_count": values.len(),
            })
        };
        let mut manifest = serde_json::json!({
            "schema_version": "antenna_field_solution.v1", "status": "ready",
            "asset_id": "afs-test", "solution_id": "basis", "stage_id": "solve_antenna",
            "source_object_id": "antenna", "current_transport_id": "charge",
            "geometry_revision": "fixture-geometry", "material_revision": "fixture-material",
            "mesh_digest": "fixture-mesh", "gauge_policy": "dirichlet_reference",
            "solver_policy": {}, "requested_execution": {"device": "cpu"},
            "resolved_execution": {"device": "cpu", "precision": "double"},
            "signatures": {
                "current_solution_signature": format!("sha256:{}", "1".repeat(64)),
                "field_solution_signature": format!("sha256:{}", "2".repeat(64)),
                "target_projection_signatures": {},
            },
            "conductor_positions": binary_ref("conductor_positions.f64le", &[0.0; 3], "node_xyz_interleaved", "m"),
            "sample_positions": binary_ref("sample_positions.f64le", &[1.0, 0.0, 0.0], "sample_xyz_interleaved", "m"),
            "bases": [{
                "port_mode_id": "port_1", "measured_positive_terminal_current_a": 1.0,
                "normalization_current_a": 1.0, "normalization_scale": 1.0,
                "current_balance_certificate_digest": "fixture-balance",
                "oersted_operator_version": fullmag_ir::ANTENNA_VECTOR_POTENTIAL_OPERATOR_VERSION,
                "quadrature_diagnostics": {"operator_version": fullmag_ir::ANTENNA_VECTOR_POTENTIAL_OPERATOR_VERSION},
                "electric_potential_per_ampere": binary_ref("port_1/V_per_A.f64le", &[1.0], "node_scalar", "V/A"),
                "current_density_per_ampere": binary_ref("port_1/J_per_A.f64le", &[1.0, 0.0, 0.0], "sample_xyz_interleaved", "A/m^2/A"),
                "magnetic_field_per_ampere": binary_ref("port_1/H_per_A.f64le", &[2.0, 0.0, 0.0], "sample_xyz_interleaved", "A/m/A"),
            }],
        });
        let digest = format!("sha256:{:x}", Sha256::digest(serde_json::to_vec(&manifest).unwrap()));
        manifest["content_digest"] = serde_json::json!(&digest);
        let manifest_path = directory.join("manifest.v1.json");
        fs::write(&manifest_path, serde_json::to_vec(&manifest).unwrap()).unwrap();
        (fullmag_ir::AntennaFieldSolutionRefIR {
            stage_id: "solve_antenna".into(), output_id: "basis".into(),
            asset_id: "afs-test".into(), content_digest: digest,
        }, manifest_path)
    }

    #[test]
    fn antenna_stage_output_catalog_is_idempotent_and_fail_closed() {
        let artifact_dir = temp_test_dir("antenna-stage-output-catalog");
        let cancelled_stage_dir = artifact_dir.join("cancelled");

        write_antenna_stage_output_catalog_terminal(
            &cancelled_stage_dir,
            "solve_antenna",
            "basis",
            "port_1",
            "cancelled",
            "interrupt_requested",
        )
        .expect("cancelled antenna catalog should write");
        let cancelled_path = antenna_stage_output_catalog_path(&cancelled_stage_dir);
        let cancelled: serde_json::Value = serde_json::from_slice(
            &fs::read(&cancelled_path).expect("cancelled antenna catalog should exist"),
        )
        .expect("cancelled antenna catalog should be JSON");
        assert_eq!(cancelled["schema_version"], "stage_output_catalog.v1");
        assert_eq!(cancelled["status"], "cancelled");
        assert!(cancelled["outputs"].as_array().is_some_and(Vec::is_empty));

        write_antenna_stage_output_catalog_terminal(
            &cancelled_stage_dir,
            "solve_antenna",
            "basis",
            "port_1",
            "cancelled",
            "interrupt_requested",
        )
        .expect("identical catalogue bytes should be idempotent");
        assert!(write_antenna_stage_output_catalog_terminal(
            &cancelled_stage_dir,
            "solve_antenna",
            "basis",
            "port_1",
            "failed",
            "different terminal state",
        )
        .is_err());

        let ready_stage_dir = artifact_dir.join("ready");
        let (reference, manifest_path) = write_valid_antenna_catalog_asset(&artifact_dir);
        write_antenna_stage_output_catalog_ready(
            &ready_stage_dir,
            &artifact_dir,
            "solve_antenna",
            "port_1",
            &reference,
            &manifest_path,
            &["H_ant_basis".into()],
            false,
            None,
        )
        .expect("ready antenna catalog should write");
        let ready: serde_json::Value = serde_json::from_slice(
            &fs::read(antenna_stage_output_catalog_path(&ready_stage_dir))
                .expect("ready antenna catalog should exist"),
        )
        .expect("ready antenna catalog should be JSON");
        assert_eq!(ready["status"], "ready");
        assert_eq!(ready["outputs"][0]["solution_ref"], serde_json::json!(&reference));
        assert!(super::read_ready_antenna_stage_outputs(
            &antenna_stage_output_catalog_path(&cancelled_stage_dir),
            &artifact_dir,
            "solve_antenna",
            "port_1",
        )
        .is_err());
        assert!(super::read_ready_antenna_stage_outputs(
            &antenna_stage_output_catalog_path(&ready_stage_dir),
            &artifact_dir,
            "solve_antenna",
            "port_2",
        )
        .is_err());
        assert_eq!(super::read_ready_antenna_stage_outputs(
            &antenna_stage_output_catalog_path(&ready_stage_dir),
            &artifact_dir,
            "solve_antenna",
            "port_1",
        ).unwrap(), vec![reference.clone()]);
        let manifest_bytes = fs::read(&manifest_path).unwrap();
        fs::write(&manifest_path, b"test manifest").unwrap();
        let invalid_asset = super::read_ready_antenna_stage_outputs(
            &antenna_stage_output_catalog_path(&ready_stage_dir),
            &artifact_dir,
            "solve_antenna",
            "port_1",
        ).expect_err("an existing dummy manifest is not a verified ready asset");
        assert!(invalid_asset.to_string().contains("verify antenna stage output catalog asset"));
        fs::write(&manifest_path, manifest_bytes).unwrap();
        let mut duplicated = ready.clone();
        duplicated["outputs"].as_array_mut().unwrap().push(ready["outputs"][0].clone());
        let duplicate_path = artifact_dir.join("duplicate-stage-output-catalog.json");
        fs::write(&duplicate_path, serde_json::to_vec(&duplicated).unwrap()).unwrap();
        let duplicate = super::read_ready_antenna_stage_outputs(
            &duplicate_path,
            &artifact_dir,
            "solve_antenna",
            "port_1",
        ).expect_err("second output with the same ID must be rejected after the valid first asset");
        assert!(duplicate.to_string().contains("contains an incompatible reference"));
        let mut wrong_kind = ready.clone();
        wrong_kind["stage_kind"] = serde_json::json!("antenna_source_spectrum");
        let wrong_kind_path = artifact_dir.join("wrong-stage-kind-catalog.json");
        fs::write(&wrong_kind_path, serde_json::to_vec(&wrong_kind).unwrap()).unwrap();
        assert!(super::read_ready_antenna_stage_outputs(
            &wrong_kind_path,
            &artifact_dir,
            "solve_antenna",
            "port_1",
        )
        .is_err());
        let mut wrong_quantity = ready.clone();
        wrong_quantity["outputs"][0]["quantity_ids"] = serde_json::json!(["H_ant"]);
        let wrong_quantity_path = artifact_dir.join("wrong-quantity-catalog.json");
        fs::write(&wrong_quantity_path, serde_json::to_vec(&wrong_quantity).unwrap()).unwrap();
        assert!(super::read_ready_antenna_stage_outputs(
            &wrong_quantity_path,
            &artifact_dir,
            "solve_antenna",
            "port_1",
        )
        .is_err());
        let mut missing_manifest = ready.clone();
        missing_manifest["outputs"][0]["manifest_ref"] = serde_json::json!("missing/manifest.v1.json");
        let missing_path = artifact_dir.join("missing-manifest-catalog.json");
        fs::write(&missing_path, serde_json::to_vec(&missing_manifest).unwrap()).unwrap();
        assert!(super::read_ready_antenna_stage_outputs(
            &missing_path,
            &artifact_dir,
            "solve_antenna",
            "port_1",
        )
        .is_err());
        let unrelated_manifest_path = artifact_dir.join("unrelated/manifest.v1.json");
        fs::create_dir_all(unrelated_manifest_path.parent().unwrap()).unwrap();
        fs::write(&unrelated_manifest_path, b"other asset").unwrap();
        let mut unrelated_manifest = ready.clone();
        unrelated_manifest["outputs"][0]["manifest_ref"] =
            serde_json::json!("unrelated/manifest.v1.json");
        let unrelated_path = artifact_dir.join("unrelated-manifest-catalog.json");
        fs::write(&unrelated_path, serde_json::to_vec(&unrelated_manifest).unwrap()).unwrap();
        assert!(super::read_ready_antenna_stage_outputs(
            &unrelated_path,
            &artifact_dir,
            "solve_antenna",
            "port_1",
        )
        .is_err());
        let mut escaped_manifest = ready.clone();
        escaped_manifest["outputs"][0]["manifest_ref"] = serde_json::json!("../manifest.v1.json");
        let escaped_path = artifact_dir.join("escaped-manifest-catalog.json");
        fs::write(&escaped_path, serde_json::to_vec(&escaped_manifest).unwrap()).unwrap();
        assert!(super::read_ready_antenna_stage_outputs(
            &escaped_path,
            &artifact_dir,
            "solve_antenna",
            "port_1",
        )
        .is_err());
        assert_eq!(
            ready["outputs"][0]["manifest_ref"],
            "antenna/field_solutions/basis/afs-test/manifest.v1.json"
        );

        let scoped_root = artifact_dir.join("scoped");
        fs::create_dir_all(&scoped_root).unwrap();
        let invalid_stage_dir = artifact_dir.join("invalid-ready");
        assert!(write_antenna_stage_output_catalog_ready(
            &invalid_stage_dir,
            &scoped_root,
            "solve_antenna",
            "port_1",
            &reference,
            &manifest_path,
            &["H_ant_basis".into()],
            false,
            None,
        )
        .is_err());
        assert!(!antenna_stage_output_catalog_path(&invalid_stage_dir).exists());

        let noncanonical_manifest = artifact_dir.join(
            "antenna/../antenna/field_solutions/basis/afs-test/manifest.v1.json",
        );
        assert!(write_antenna_stage_output_catalog_ready(
            &invalid_stage_dir,
            &artifact_dir,
            "solve_antenna",
            "port_1",
            &reference,
            &noncanonical_manifest,
            &["H_ant_basis".into()],
            false,
            None,
        )
        .is_err());
        assert!(!antenna_stage_output_catalog_path(&invalid_stage_dir).exists());

        let _ = fs::remove_dir_all(artifact_dir);
    }

    #[test]
    fn antenna_stage_output_catalog_cleans_private_temp_on_pre_rename_cancel() {
        let artifact_dir = temp_test_dir("antenna-stage-output-catalog-cancel");
        let stage_dir = artifact_dir.join("stage");
        let cancel = || -> anyhow::Result<()> { Err(anyhow::anyhow!("interrupt_requested")) };

        let error = write_antenna_stage_output_catalog_with_hook(
            &stage_dir,
            &serde_json::json!({
                "schema_version": "stage_output_catalog.v1",
                "status": "ready",
                "outputs": []
            }),
            Some(&cancel),
        )
        .expect_err("pre-rename cancellation must reject publication");
        assert!(error.to_string().contains("interrupt_requested"));
        assert!(!antenna_stage_output_catalog_path(&stage_dir).exists());
        let remaining = fs::read_dir(&stage_dir)
            .expect("stage directory should remain readable")
            .collect::<std::result::Result<Vec<_>, _>>()
            .expect("stage directory entries should be readable");
        assert!(remaining.is_empty(), "private temp files must be cleaned");

        let _ = fs::remove_dir_all(artifact_dir);
    }

    #[test]
    fn antenna_stage_output_catalog_does_not_replace_concurrent_publication() {
        let artifact_dir = temp_test_dir("antenna-stage-output-catalog-race");
        let payload = serde_json::json!({"status": "ready"});
        let conflicting = serde_json::json!({"status": "failed"});
        let conflicting_bytes = serde_json::to_vec_pretty(&conflicting).unwrap();
        let identical_bytes = serde_json::to_vec_pretty(&payload).unwrap();

        let conflicting_dir = artifact_dir.join("conflicting");
        let conflicting_path = antenna_stage_output_catalog_path(&conflicting_dir);
        let competing_writer = || -> anyhow::Result<()> {
            fs::write(&conflicting_path, &conflicting_bytes)?;
            Ok(())
        };
        assert!(write_antenna_stage_output_catalog_with_hook(
            &conflicting_dir,
            &payload,
            Some(&competing_writer),
        )
        .is_err());
        assert_eq!(fs::read(&conflicting_path).unwrap(), conflicting_bytes);
        assert_eq!(fs::read_dir(&conflicting_dir).unwrap().count(), 1);

        let identical_dir = artifact_dir.join("identical");
        let identical_path = antenna_stage_output_catalog_path(&identical_dir);
        let matching_writer = || -> anyhow::Result<()> {
            fs::write(&identical_path, &identical_bytes)?;
            Ok(())
        };
        write_antenna_stage_output_catalog_with_hook(
            &identical_dir,
            &payload,
            Some(&matching_writer),
        )
        .expect("identical concurrent publication should be reused");
        assert_eq!(fs::read(&identical_path).unwrap(), identical_bytes);
        assert_eq!(fs::read_dir(&identical_dir).unwrap().count(), 1);

        let _ = fs::remove_dir_all(artifact_dir);
    }

    #[test]
    fn ready_antenna_catalog_rejects_cancel_before_new_or_reused_publication() {
        let artifact_dir = temp_test_dir("antenna-ready-catalog-cancel");
        let reference = fullmag_ir::AntennaFieldSolutionRefIR {
            stage_id: "solve_antenna".into(),
            output_id: "basis".into(),
            asset_id: "afs-test".into(),
            content_digest: "sha256:test".into(),
        };
        let manifest_path =
            artifact_dir.join("antenna/field_solutions/basis/afs-test/manifest.v1.json");
        let interrupted = std::sync::atomic::AtomicBool::new(true);
        let write_ready = |stage_dir: &Path, signal: Option<&std::sync::atomic::AtomicBool>| {
            write_antenna_stage_output_catalog_ready(
                stage_dir,
                &artifact_dir,
                "solve_antenna",
                "port_1",
                &reference,
                &manifest_path,
                &["H_ant_basis".into()],
                false,
                signal,
            )
        };
        let new_stage_dir = artifact_dir.join("new");
        assert!(write_ready(&new_stage_dir, Some(&interrupted))
            .unwrap_err()
            .to_string()
            .contains("interrupt_requested"));
        assert!(!antenna_stage_output_catalog_path(&new_stage_dir).exists());

        let reused_stage_dir = artifact_dir.join("reused");
        write_ready(&reused_stage_dir, None).unwrap();
        assert!(write_ready(&reused_stage_dir, Some(&interrupted))
            .unwrap_err()
            .to_string()
            .contains("interrupt_requested"));
        let _ = fs::remove_dir_all(artifact_dir);
    }

    #[test]
    fn active_sequence_preserves_completed_relaxation_metric_and_identity() {
        let mut state = ActiveSequenceState::single_current();
        state.mark_current_started("cmd-relax", 1_700_000_000_000, None, None);
        let completion = fullmag_ir::StageCompletionIR {
            status: "completed".into(),
            converged: true,
            reason: Some(fullmag_ir::StageStopReason::Torque),
            metric: Some(fullmag_ir::StageMetricKind::MaxTorqueApm),
            metric_name: Some("max_torque_apm".into()),
            metric_value: Some(75.0),
            threshold: Some(80.0),
        };
        state.mark_current(
            "completed",
            Some(&completion),
            Some(1_700_000_001_000),
            None,
        );
        let execution = state.completed_stage_execution("completed");

        assert_eq!(execution.completed_stage_indexes, vec![0]);
        assert_eq!(execution.stages[0].status, "completed");
        assert_eq!(execution.stages[0].stage_id.as_deref(), Some("stage-000"));
        assert_eq!(
            execution.stages[0].metric_name.as_deref(),
            Some("max_torque_apm")
        );
        assert_eq!(execution.stages[0].metric_value, Some(75.0));
        assert_eq!(execution.stages[0].threshold, Some(80.0));
    }
}

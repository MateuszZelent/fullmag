//! Recover a current typed task claim from its durable catalog and lease.
use anyhow::{bail, Context, Result};
use fullmag_application::{
    AttemptId, LeaseToken, OwnershipEpoch, ResourceBudget, ResourceKind, ResourceLease, RunId,
    TaskClaim, TaskId, TaskLifecycle, TaskRecord,
};
use fullmag_ir::ExecutionDevice;
use fullmag_session::{
    FmsResourceBudget, FmsResourceKind, FmsResourceLease, FmsResourceLeaseState, FmsTaskLifecycle,
    FmsTaskReadiness, SessionStore, FMS_RESOURCE_LEASE_SCHEMA,
};

/// Durably admit a claimed application task before publishing its worker
/// coordinator or process. Replaying the same claim repairs an interrupted
/// catalog/lease projection without creating a new attempt.

/// A scheduler admission candidate went stale between the queue snapshot and
/// the durable admission (for example the task was cancelled meanwhile). It is
/// transient: no durable state was written and the next pass re-reads the queue.
#[derive(Debug)]
pub struct StaleTaskAdmissionCandidate;

impl std::fmt::Display for StaleTaskAdmissionCandidate {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("stale scheduler admission candidate")
    }
}

impl std::error::Error for StaleTaskAdmissionCandidate {}

pub fn commit_claimed_task_admission(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
) -> Result<fullmag_session::TaskAdmissionCommitDisposition> {
    commit_claimed_task_admission_with(store, task, claim, None, |lease, dependencies| {
        let _writer = store.write_transaction()?;
        dependencies.require_locked(store)?;
        store.commit_task_admission(lease).map(Some)
    })?
    .context("local task admission unexpectedly returned no disposition")
}

pub(crate) fn commit_claimed_task_admission_from_snapshot(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
    accepted: &crate::study::AcceptedStudySnapshot,
) -> Result<fullmag_session::TaskAdmissionCommitDisposition> {
    commit_claimed_task_admission_with(
        store,
        task,
        claim,
        Some(accepted),
        |lease, dependencies| {
            let _writer = store.write_transaction()?;
            dependencies.require_locked(store)?;
            store.commit_task_admission(lease).map(Some)
        },
    )?
    .context("local task admission unexpectedly returned no disposition")
}

/// Admit through the shared physical-host ledger when the caller has resolved
/// an explicit host policy/allocation. The ledger owns the host-before-store
/// transaction and retains reservations after an unknown publication outcome.
/// This does not infer UUIDs from offer IDs or enable unsupported concurrency.
pub fn commit_claimed_task_admission_with_host(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
    ledger: &fullmag_session::host_resource_ledger::HostResourceLedger,
    request: &fullmag_session::host_resource_ledger::HostReservationRequest,
    inputs: &std::collections::BTreeMap<String, fullmag_application::ResolvedInput>,
) -> Result<fullmag_session::TaskAdmissionCommitDisposition> {
    commit_claimed_task_admission_with_host_inner(
        store, task, claim, ledger, request, inputs, None,
    )?
    .context("host task admission unexpectedly returned no disposition")
}

pub(crate) fn try_commit_claimed_task_admission_with_host_from_snapshot(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
    ledger: &fullmag_session::host_resource_ledger::HostResourceLedger,
    request: &fullmag_session::host_resource_ledger::HostReservationRequest,
    inputs: &std::collections::BTreeMap<String, fullmag_application::ResolvedInput>,
    accepted: &crate::study::AcceptedStudySnapshot,
) -> Result<Option<fullmag_session::TaskAdmissionCommitDisposition>> {
    try_commit_claimed_task_admission_with_host_inner(
        store, task, claim, ledger, request, inputs, Some(accepted),
    )
}

fn commit_claimed_task_admission_with_host_inner(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
    ledger: &fullmag_session::host_resource_ledger::HostResourceLedger,
    request: &fullmag_session::host_resource_ledger::HostReservationRequest,
    inputs: &std::collections::BTreeMap<String, fullmag_application::ResolvedInput>,
    accepted: Option<&crate::study::AcceptedStudySnapshot>,
) -> Result<Option<fullmag_session::TaskAdmissionCommitDisposition>> {
    let inputs = capture_admission_inputs(inputs, None)?;
    commit_claimed_task_admission_with(store, task, claim, accepted, |lease, dependencies| {
        let lease = attach_host_launch_binding(ledger, lease)?;
        ledger
            .commit_task_admission_checked(request, store, &lease, &inputs, || {
                dependencies.require_locked(store)
            })
            .map(Some)
    })
}

/// Capacity contention leaves the ready task queued without publishing a local
/// claim. Unknown publication, invalid state and fencing failures remain errors.
pub fn try_commit_claimed_task_admission_with_host(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
    ledger: &fullmag_session::host_resource_ledger::HostResourceLedger,
    request: &fullmag_session::host_resource_ledger::HostReservationRequest,
    inputs: &std::collections::BTreeMap<String, fullmag_application::ResolvedInput>,
) -> Result<Option<fullmag_session::TaskAdmissionCommitDisposition>> {
    try_commit_claimed_task_admission_with_host_inner(
        store, task, claim, ledger, request, inputs, None,
    )
}

fn try_commit_claimed_task_admission_with_host_inner(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
    ledger: &fullmag_session::host_resource_ledger::HostResourceLedger,
    request: &fullmag_session::host_resource_ledger::HostReservationRequest,
    inputs: &std::collections::BTreeMap<String, fullmag_application::ResolvedInput>,
    accepted: Option<&crate::study::AcceptedStudySnapshot>,
) -> Result<Option<fullmag_session::TaskAdmissionCommitDisposition>> {
    let inputs = capture_admission_inputs(inputs, None)?;
    commit_claimed_task_admission_with(store, task, claim, accepted, |lease, dependencies| {
        let lease = attach_host_launch_binding(ledger, lease)?;
        ledger.try_commit_task_admission_checked(request, store, &lease, &inputs, || {
            dependencies.require_locked(store)
        })
    })
}

fn attach_host_launch_binding(
    ledger: &fullmag_session::host_resource_ledger::HostResourceLedger,
    lease: &FmsResourceLease,
) -> Result<FmsResourceLease> {
    let mut lease = lease.clone();
    lease.host_launch_binding = Some(crate::retry_store_writer_busy(|| {
        ledger.worker_launch_binding()
    })?);
    Ok(lease)
}

/// The same admission transaction owns physical inputs and prepared frozen history.
pub(crate) fn commit_claimed_task_admission_with_frozen_context(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
    inputs: &std::collections::BTreeMap<String, fullmag_application::ResolvedInput>,
    frozen: Option<&fullmag_application::FrozenStageContextRefV1>,
    accepted: &crate::study::AcceptedStudySnapshot,
) -> Result<Option<fullmag_session::TaskAdmissionCommitDisposition>> {
    let snapshot = capture_admission_inputs(inputs, frozen)?;
    commit_claimed_task_admission_with(store, task, claim, Some(accepted), |lease, dependencies| {
        let _writer = store.write_transaction()?;
        dependencies.require_locked(store)?;
        store.commit_task_admission_with_inputs(lease, &Some(snapshot)).map(Some)
    })
}

pub(crate) fn try_commit_claimed_task_admission_with_host_and_frozen_context(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
    ledger: &fullmag_session::host_resource_ledger::HostResourceLedger,
    request: &fullmag_session::host_resource_ledger::HostReservationRequest,
    inputs: &std::collections::BTreeMap<String, fullmag_application::ResolvedInput>,
    frozen: Option<&fullmag_application::FrozenStageContextRefV1>,
    accepted: &crate::study::AcceptedStudySnapshot,
) -> Result<Option<fullmag_session::TaskAdmissionCommitDisposition>> {
    let snapshot = capture_admission_inputs(inputs, frozen)?;
    commit_claimed_task_admission_with(store, task, claim, Some(accepted), |lease, dependencies| {
        let lease = attach_host_launch_binding(ledger, lease)?;
        ledger.try_commit_task_admission_checked(request, store, &lease, &snapshot, || {
            dependencies.require_locked(store)
        })
    })
}

fn capture_admission_inputs(
    inputs: &std::collections::BTreeMap<String, fullmag_application::ResolvedInput>,
    frozen: Option<&fullmag_application::FrozenStageContextRefV1>,
) -> Result<fullmag_session::FmsResolvedInputsSnapshot> {
    for input in inputs.values() {
        input.validate().map_err(|error| anyhow::anyhow!(error))?;
    }
    match frozen {
        Some(binding) => {
            binding.validate()?;
            fullmag_session::FmsResolvedInputsSnapshot::new_with_frozen_stage_context(
                serde_json::to_value(inputs)?, serde_json::to_value(binding)?)
        }
        None => fullmag_session::FmsResolvedInputsSnapshot::new(serde_json::to_value(inputs)?),
    }
}

fn commit_claimed_task_admission_with<'a>(
    store: &SessionStore,
    task: &TaskRecord,
    claim: &TaskClaim,
    accepted_snapshot: Option<&'a crate::study::AcceptedStudySnapshot>,
    admit: impl FnOnce(
        &FmsResourceLease,
        &crate::study_completion::PreparedTaskDependencies<'a>,
    ) -> Result<Option<fullmag_session::TaskAdmissionCommitDisposition>>,
) -> Result<Option<fullmag_session::TaskAdmissionCommitDisposition>> {
    task.fence(claim)
        .context("application task does not own the supplied claim")?;
    if task.run_id != claim.run_id
        || task.task_id != claim.task_id
        || task.lifecycle != TaskLifecycle::Preparing
        || task.attempt_id.as_ref() != Some(&claim.attempt_id)
        || task.ownership_epoch != Some(claim.ownership_epoch)
        || claim.lease.heartbeat_sequence != 0
    {
        bail!("task admission requires the exact fresh preparing claim");
    }

    let catalog = store
        .read_run_catalog(claim.run_id.as_str())?
        .context("task admission requires a durable run catalog")?;
    let durable_task = catalog
        .tasks
        .iter()
        .find(|entry| entry.task_id == claim.task_id.as_str())
        .context("task admission target is missing from the durable run catalog")?;
    if durable_task.input_fingerprint != task.input_fingerprint
        || !matches!(durable_task.readiness, FmsTaskReadiness::Ready)
    {
        bail!("application task differs from the durable ready task");
    }
    let dependencies = match accepted_snapshot {
        Some(accepted) => crate::study_completion::prepare_task_dependencies_from_snapshot(
            store,
            &claim.run_id,
            claim.task_id.as_str(),
            accepted,
        )?,
        None => crate::study_completion::prepare_task_dependencies(
            store,
            &claim.run_id,
            claim.task_id.as_str(),
        )?,
    };
    validate_claimed_task_resource(claim, &dependencies)?;
    let retry_queue_epoch = durable_task.ownership_epoch.is_some_and(|prior_epoch| {
        prior_epoch
            .checked_add(1)
            .is_some_and(|next_epoch| next_epoch == claim.ownership_epoch.value())
    });
    let retry_queue_authorized = if retry_queue_epoch {
        let matching_decisions = store
            .list_retry_decisions(claim.run_id.as_str())?
            .into_iter()
            .filter(|decision| {
                decision.task_id == claim.task_id.as_str()
                    && Some(decision.ownership_epoch) == durable_task.ownership_epoch
                    && decision.action == fullmag_session::FmsRetryAction::Retry
            })
            .count();
        if matching_decisions > 1 {
            bail!("multiple retry decisions authorize the same queued task epoch");
        }
        matching_decisions == 1
    } else {
        false
    };
    let is_unclaimed_queue = durable_task.lifecycle == FmsTaskLifecycle::Queued
        && durable_task.attempt_id.is_none()
        && (durable_task.ownership_epoch.is_none() || retry_queue_authorized)
        && durable_task.resource_id.is_none();
    let is_exact_replay = durable_task.lifecycle == FmsTaskLifecycle::Preparing
        && durable_task.attempt_id.as_deref() == Some(claim.attempt_id.as_str())
        && durable_task.ownership_epoch == Some(claim.ownership_epoch.value())
        && durable_task.resource_id.as_deref() == Some(claim.lease.resource_id.as_str());
    if !is_unclaimed_queue && !is_exact_replay {
        // The scheduler built this claim from an earlier snapshot; the task
        // changed since (e.g. it was cancelled). Nothing was written yet, so
        // the candidate is re-evaluated in the next scheduling pass.
        return Err(anyhow::Error::new(StaleTaskAdmissionCandidate)
            .context("durable task is neither queued nor owned by this admission claim"));
    }

    let kind = match claim.lease.kind {
        ResourceKind::Cpu => FmsResourceKind::Cpu,
        ResourceKind::Gpu => FmsResourceKind::Gpu,
        ResourceKind::Storage => FmsResourceKind::Storage,
        ResourceKind::Meshing => FmsResourceKind::Meshing,
    };
    let now = chrono::Utc::now();
    let lease = FmsResourceLease {
        schema_version: FMS_RESOURCE_LEASE_SCHEMA.into(),
        resource_id: claim.lease.resource_id.clone(),
        kind,
        budget: FmsResourceBudget {
            cpu_millis: claim.lease.budget.cpu_millis,
            memory_bytes: claim.lease.budget.memory_bytes,
            gpu_memory_bytes: claim.lease.budget.gpu_memory_bytes,
            storage_bytes: claim.lease.budget.storage_bytes,
        },
        run_id: claim.run_id.as_str().into(),
        task_id: claim.task_id.as_str().into(),
        attempt_id: claim.attempt_id.as_str().into(),
        ownership_epoch: claim.ownership_epoch.value(),
        lease_token: claim.lease.lease_token.as_str().into(),
        state: FmsResourceLeaseState::Active,
        acquired_at: now,
        heartbeat_at: now,
        heartbeat_sequence: claim.lease.heartbeat_sequence,
        released_at: None,
        host_launch_binding: None,
    };
    let Some(disposition) = admit(&lease, &dependencies)? else {
        return Ok(None);
    };
    let persisted_claim = load_current_task_claim(store, &claim.run_id, claim.task_id.as_str())?;
    if persisted_claim != *claim {
        bail!("durable admission recovered a claim different from the application claim");
    }
    Ok(Some(disposition))
}

/// Confirm the claimed resource realizes both the immutable RunSpec device
/// request and any concrete FEM eigen device already resolved by the planner.
/// The durable lease records the selected device for `auto`; explicit requests
/// can never cross CPU/GPU lanes at admission.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum ClaimedTaskResourceCompatibility {
    Compatible,
    Incompatible(String),
}

pub(crate) fn claimed_task_resource_compatibility(
    store: &SessionStore,
    claim: &TaskClaim,
) -> Result<ClaimedTaskResourceCompatibility> {
    let intent = store
        .read_run_intent(claim.run_id.as_str())?
        .context("accepted task admission requires its immutable run intent")?;
    let specification: fullmag_application::RunSpecification =
        serde_json::from_value(intent.specification.clone())
            .context("accepted task run intent specification is not typed")?;
    if specification.run_id != claim.run_id {
        bail!("accepted task claim run differs from the immutable RunSpec");
    }
    let accepted = crate::load_accepted_study_snapshot(
        store,
        &claim.run_id,
        &specification.snapshot.project_id,
    )?;
    if accepted.run.intent != intent {
        bail!("accepted task run intent changed while loading its study snapshot");
    }
    claimed_task_resource_compatibility_for_snapshot(claim, &specification, &accepted)
}

pub(crate) fn claimed_task_resource_compatibility_from_snapshot(
    store: &SessionStore,
    claim: &TaskClaim,
    accepted: &crate::study::AcceptedStudySnapshot,
) -> Result<ClaimedTaskResourceCompatibility> {
    crate::study::require_current_accepted_study_intent(store, accepted)?;
    claimed_task_resource_compatibility_for_snapshot(claim, &accepted.run.specification, accepted)
}

fn claimed_task_resource_compatibility_for_snapshot(
    claim: &TaskClaim,
    specification: &fullmag_application::RunSpecification,
    accepted: &crate::study::AcceptedStudySnapshot,
) -> Result<ClaimedTaskResourceCompatibility> {
    if specification.run_id != claim.run_id {
        bail!("accepted task claim run differs from the immutable RunSpec");
    }
    let mut matching_step = None;
    for step in &accepted.study.steps {
        if fullmag_session::task_id_for_study_step(claim.run_id.as_str(), &step.step_id)?
            == claim.task_id.as_str()
        {
            if matching_step.is_some() {
                bail!("accepted task claim identifies multiple study steps");
            }
            matching_step = Some(step);
        }
    }
    let study_step = matching_step.context("accepted task claim identifies no study step")?;
    let execution_step = accepted
        .lowered
        .steps
        .iter()
        .find(|step| step.step_id == study_step.step_id)
        .context("accepted task claim has no lowered execution step")?;
    if !study_step.enabled
        || !execution_step.enabled
        || !matches!(
            &execution_step.status,
            fullmag_plan::StudyStepLoweringStatus::Planned
        )
    {
        bail!("accepted task claim targets a disabled or unplanned study step");
    }
    let planned_device = execution_step
        .execution_plan
        .as_ref()
        .and_then(|plan| plan.provenance.fem_eigen_execution_resolution.as_ref())
        .map(|resolution| resolution.resolved_device);
    let catalog_entry = accepted
        .catalog
        .entries()
        .iter()
        .find(|entry| entry.step_id() == study_step.step_id)
        .context("accepted task claim has no immutable ProblemIR")?;
    let task_request = specification
        .requested_execution
        .for_problem(catalog_entry.problem())
        .map_err(|error| {
            anyhow::anyhow!(
                "accepted task `{}` execution request is invalid: {error}",
                study_step.step_id
            )
        })?;
    if matches!(study_step.kind, fullmag_authoring::StudyStepKind::RetainedCurrentFieldInspection { .. }) {
        if task_request.backend != "fem" || task_request.device != "cpu"
            || task_request.precision != "double" || task_request.mode != "strict"
            || claim.lease.kind != ResourceKind::Cpu || claim.lease.budget.gpu_memory_bytes != 0
            || !matches!(execution_step.execution_plan.as_ref().map(|plan| &plan.backend_plan),
                Some(fullmag_ir::BackendPlanIR::AntennaRetainedCurrentFieldInspection(_)
                    | fullmag_ir::BackendPlanIR::AntennaRetainedPreparationFieldInspection(_)
                    | fullmag_ir::BackendPlanIR::AntennaRetainedDirectFieldInspection(_))) {
            return Ok(ClaimedTaskResourceCompatibility::Incompatible(
                "retained-current H-only requires its own FEM CPU double strict plan and CPU lease without GPU memory".into()));
        }
        crate::study_inspection::inspection_bundle_budget(claim)?;
    }
    if matches!(study_step.kind, fullmag_authoring::StudyStepKind::ClosedLoopInspection { .. }) {
        if claim.lease.kind != ResourceKind::Cpu {
            return Ok(ClaimedTaskResourceCompatibility::Incompatible("inspection realizes auto only on a CPU resource".into()));
        }
        crate::study_inspection::inspection_bundle_budget(claim)?;
    }
    let compatibility = solver_resource_compatibility(
        &task_request.device,
        &claim.lease.kind,
        &claim.lease.budget,
        planned_device,
    )?;
    if compatibility == ClaimedTaskResourceCompatibility::Compatible {
        if let Some(required) = task_request.minimum_resources.as_ref() {
            if !resource_budget_meets_requested_minimum(required, &claim.lease.budget) {
                return Ok(ClaimedTaskResourceCompatibility::Incompatible(format!(
                    "claimed resource budget does not meet the minimum resources for study step `{}`",
                    study_step.step_id
                )));
            }
        }
    }
    Ok(compatibility)
}

fn resource_budget_meets_requested_minimum(
    required: &fullmag_application::RequestedResourceBudget,
    offered: &ResourceBudget,
) -> bool {
    offered.cpu_millis >= required.cpu_millis
        && offered.memory_bytes >= required.memory_bytes
        && offered.gpu_memory_bytes >= required.gpu_memory_bytes
        && offered.storage_bytes >= required.storage_bytes
}

fn validate_claimed_task_resource(
    claim: &TaskClaim,
    dependencies: &crate::study_completion::PreparedTaskDependencies<'_>,
) -> Result<()> {
    if !dependencies.has_run_intent() {
        bail!("accepted task admission requires its immutable run intent");
    }
    let accepted = dependencies
        .accepted_study()
        .context("accepted run has no immutable study object")?;
    match claimed_task_resource_compatibility_for_snapshot(
        claim,
        &accepted.run.specification,
        accepted,
    )? {
        ClaimedTaskResourceCompatibility::Compatible => Ok(()),
        ClaimedTaskResourceCompatibility::Incompatible(reason) => bail!(reason),
    }
}

fn solver_resource_compatibility(
    requested_device: &str,
    resource_kind: &ResourceKind,
    resource_budget: &ResourceBudget,
    planned_device: Option<ExecutionDevice>,
) -> Result<ClaimedTaskResourceCompatibility> {
    let (offered_device, offered_name) = match resource_kind {
        ResourceKind::Cpu => (ExecutionDevice::Cpu, "cpu"),
        ResourceKind::Gpu => (ExecutionDevice::Gpu, "gpu"),
        ResourceKind::Storage | ResourceKind::Meshing => {
            return Ok(ClaimedTaskResourceCompatibility::Incompatible(
                "study solver task requires a CPU or GPU resource lease".into(),
            ));
        }
    };
    if let Some(reason) = invalid_solver_resource_budget(resource_kind, resource_budget) {
        return Ok(ClaimedTaskResourceCompatibility::Incompatible(reason));
    }
    if requested_device != "auto" && requested_device != offered_name {
        return Ok(ClaimedTaskResourceCompatibility::Incompatible(format!(
            "claimed {offered_name} resource does not match explicit RunSpec device `{requested_device}`"
        )));
    }
    if let Some(planned_device) = planned_device {
        if planned_device == ExecutionDevice::Auto {
            bail!("accepted execution plan did not resolve its FEM eigen device");
        }
        if planned_device != offered_device {
            return Ok(ClaimedTaskResourceCompatibility::Incompatible(format!(
                "claimed {offered_name} resource does not match the planner-resolved FEM eigen device `{planned_device:?}`"
            )));
        }
    }
    Ok(ClaimedTaskResourceCompatibility::Compatible)
}

fn invalid_solver_resource_budget(
    resource_kind: &ResourceKind,
    budget: &ResourceBudget,
) -> Option<String> {
    if budget.cpu_millis == 0 {
        return Some("solver resource budget requires positive cpu_millis".into());
    }
    if budget.memory_bytes == 0 {
        return Some("solver resource budget requires positive memory_bytes".into());
    }
    match resource_kind {
        ResourceKind::Cpu if budget.gpu_memory_bytes != 0 => {
            return Some("CPU solver resource budget requires zero gpu_memory_bytes".into());
        }
        ResourceKind::Gpu if budget.gpu_memory_bytes == 0 => {
            return Some("GPU solver resource budget requires positive gpu_memory_bytes".into());
        }
        _ => {}
    }
    if budget.storage_bytes == 0 {
        return Some("solver resource budget requires positive storage_bytes".into());
    }
    None
}

#[cfg(test)]
mod tests {
    use super::{
        resource_budget_meets_requested_minimum, solver_resource_compatibility,
        ClaimedTaskResourceCompatibility,
    };
    use fullmag_application::{RequestedResourceBudget, ResourceBudget, ResourceKind};

    fn budget(
        cpu_millis: u64,
        memory_bytes: u64,
        gpu_memory_bytes: u64,
        storage_bytes: u64,
    ) -> ResourceBudget {
        ResourceBudget {
            cpu_millis,
            memory_bytes,
            gpu_memory_bytes,
            storage_bytes,
        }
    }

    fn assert_incompatible(kind: ResourceKind, budget: ResourceBudget, expected: &str) {
        let result = solver_resource_compatibility("auto", &kind, &budget, None).unwrap();
        let ClaimedTaskResourceCompatibility::Incompatible(reason) = result else {
            panic!("invalid solver resource budget was accepted");
        };
        assert!(reason.contains(expected), "unexpected reason: {reason}");
    }

    #[test]
    fn solver_resource_budget_requires_complete_cpu_capacity() {
        assert_incompatible(ResourceKind::Cpu, budget(0, 1, 0, 1), "cpu_millis");
        assert_incompatible(ResourceKind::Cpu, budget(100, 0, 0, 1), "memory_bytes");
        assert_incompatible(ResourceKind::Cpu, budget(100, 1, 1, 1), "gpu_memory_bytes");
        assert_incompatible(ResourceKind::Cpu, budget(100, 1, 0, 0), "storage_bytes");
        assert_eq!(
            solver_resource_compatibility("auto", &ResourceKind::Cpu, &budget(100, 1, 0, 1), None,)
                .unwrap(),
            ClaimedTaskResourceCompatibility::Compatible
        );
    }

    #[test]
    fn solver_resource_budget_requires_complete_gpu_capacity() {
        assert_incompatible(ResourceKind::Gpu, budget(0, 1, 1, 1), "cpu_millis");
        assert_incompatible(ResourceKind::Gpu, budget(100, 0, 1, 1), "memory_bytes");
        assert_incompatible(ResourceKind::Gpu, budget(100, 1, 0, 1), "gpu_memory_bytes");
        assert_incompatible(ResourceKind::Gpu, budget(100, 1, 1, 0), "storage_bytes");
        assert_eq!(
            solver_resource_compatibility("auto", &ResourceKind::Gpu, &budget(100, 1, 1, 1), None,)
                .unwrap(),
            ClaimedTaskResourceCompatibility::Compatible
        );
    }

    #[test]
    fn direct_admission_checks_every_per_step_resource_minimum() {
        let required = RequestedResourceBudget {
            cpu_millis: 500,
            memory_bytes: 2_000,
            gpu_memory_bytes: 8_000,
            storage_bytes: 4_000,
        };
        assert!(resource_budget_meets_requested_minimum(
            &required,
            &budget(500, 2_000, 8_000, 4_000)
        ));
        assert!(!resource_budget_meets_requested_minimum(
            &required,
            &budget(499, 2_000, 8_000, 4_000)
        ));
        assert!(!resource_budget_meets_requested_minimum(
            &required,
            &budget(500, 1_999, 8_000, 4_000)
        ));
        assert!(!resource_budget_meets_requested_minimum(
            &required,
            &budget(500, 2_000, 7_999, 4_000)
        ));
        assert!(!resource_budget_meets_requested_minimum(
            &required,
            &budget(500, 2_000, 8_000, 3_999)
        ));
    }
}

#[cfg(test)]
mod host_binding_tests {
    use super::attach_host_launch_binding;
    use chrono::Utc;
    use fullmag_ir::compute_resources::ComputeParallelismIR;
    use fullmag_session::compute_node_snapshot::EnforcementStatus;
    use fullmag_session::host_resource_ledger::{
        HostReservationIdentity, HostReservationOwner, HostReservationRequest, HostResourceLedger,
        HostResourceLedgerPolicy, HostRuntimeReadiness, HOST_RESOURCE_LEDGER_POLICY_SCHEMA_V2,
        HOST_RUNTIME_READINESS_SCHEMA_V1,
    };
    use fullmag_session::{
        FmsResolvedInputsSnapshot, FmsResourceBudget, FmsResourceKind, FmsResourceLease,
        FmsResourceLeaseState, SessionStore, FMS_RESOURCE_LEASE_SCHEMA,
    };
    use std::collections::{BTreeMap, BTreeSet};

    #[test]
    fn fresh_v2_host_claim_receives_the_canonical_runtime_generation_binding() {
        let directory = tempfile::tempdir().unwrap();
        let gpu_uuid = "GPU-00000000-0000-4000-8000-000000000001";
        let policy = HostResourceLedgerPolicy {
            schema_version: HOST_RESOURCE_LEDGER_POLICY_SCHEMA_V2.into(),
            host_id: "host-1".into(),
            topology_sha256: "a".repeat(64),
            revision: 1,
            owner_epoch: 1,
            total_budget: FmsResourceBudget {
                cpu_millis: 1000,
                memory_bytes: 1024,
                gpu_memory_bytes: 0,
                storage_bytes: 1024,
            },
            gpu_vram_bytes_by_uuid: BTreeMap::from([(gpu_uuid.into(), 4096)]),
            allowed_cpu_ids: BTreeSet::new(),
        };
        let readiness = HostRuntimeReadiness {
            schema_version: HOST_RUNTIME_READINESS_SCHEMA_V1.into(),
            status: "ready".into(),
            source_kind: "native_fem_gpu_abi".into(),
            source_snapshot_sha256: "b".repeat(64),
            runtime_identity_sha256: "c".repeat(64),
            capabilities: vec!["fem.gpu".into()],
            gpu_runtime_compatibility: BTreeMap::from([(gpu_uuid.into(), vec!["fem.gpu".into()])]),
            gpu_visibility: EnforcementStatus::Supported,
            inventory_sha256: Some(policy.topology_sha256.clone()),
            capabilities_sha256: Some("d".repeat(64)),
        };
        let ledger = HostResourceLedger::initialize_with_readiness(
            directory.path().join("host"),
            policy.clone(),
            readiness,
        )
        .unwrap();
        let now = Utc::now();
        let lease = FmsResourceLease {
            schema_version: FMS_RESOURCE_LEASE_SCHEMA.into(),
            resource_id: "compute.cpu".into(),
            kind: FmsResourceKind::Cpu,
            budget: FmsResourceBudget {
                cpu_millis: 100,
                memory_bytes: 1,
                gpu_memory_bytes: 0,
                storage_bytes: 1,
            },
            run_id: "run-1".into(),
            task_id: "task-1".into(),
            attempt_id: "attempt-1".into(),
            ownership_epoch: 1,
            lease_token: "lease-1".into(),
            state: FmsResourceLeaseState::Active,
            acquired_at: now,
            heartbeat_at: now,
            heartbeat_sequence: 0,
            released_at: None,
            host_launch_binding: None,
        };

        let store = SessionStore::open(directory.path().join("store")).unwrap();
        let generation = ledger.read_runtime_generation_sha256().unwrap();
        let request = HostReservationRequest {
            identity: HostReservationIdentity {
                store_id: HostResourceLedger::store_id(store.root()).unwrap(),
                run_id: lease.run_id.clone(),
                task_id: lease.task_id.clone(),
                resource_id: lease.resource_id.clone(),
                owner: HostReservationOwner::Solver {
                    attempt_id: lease.attempt_id.clone(),
                    ownership_epoch: lease.ownership_epoch,
                },
                lease_token: lease.lease_token.clone(),
            },
            expected_host_id: policy.host_id.clone(),
            expected_policy_revision: policy.revision,
            expected_owner_epoch: policy.owner_epoch,
            runtime_generation_sha256: Some(generation),
            expected_compute_node_owner_id: None,
            expected_compute_node_owner_epoch: None,
            expected_topology_sha256: policy.topology_sha256.clone(),
            budget: lease.budget.clone(),
            exclusive_gpu_uuids: BTreeSet::new(),
            gpu_vram_bytes_by_uuid: BTreeMap::new(),
            cpu_ids: BTreeSet::new(),
            expected_node_policy_revision: 1,
            scheduling_priority: 0,
            parallelism: ComputeParallelismIR::SingleProcess,
        };
        let inputs = FmsResolvedInputsSnapshot::new(serde_json::json!({})).unwrap();
        let missing = ledger
            .try_commit_task_admission(&request, &store, &lease, &inputs)
            .unwrap_err();
        assert!(
            format!("{missing:#}")
                .contains("host request and durable task claim is missing its host launch binding"),
            "strict v2 guard must reject an unbound fresh claim: {missing:#}"
        );

        let bound = attach_host_launch_binding(&ledger, &lease).unwrap();
        let after_binding = ledger
            .try_commit_task_admission(&request, &store, &bound, &inputs)
            .unwrap_err();
        assert!(
            format!("{after_binding:#}")
                .contains("v4 host admission requires a pinned compute-node owner"),
            "bound claim must pass the host-binding guard before the next v2 fence: {after_binding:#}"
        );
        let binding = bound.host_launch_binding.unwrap();
        assert_eq!(
            binding.runtime_generation_sha256,
            Some(ledger.read_runtime_generation_sha256().unwrap())
        );
        assert_eq!(binding.ledger_root, directory.path().join("host"));
    }
}

/// Reconstruct the current claim only when the run catalog and its active
/// resource lease agree on task, attempt, epoch, resource, and readiness.
/// This is a read-only recovery boundary; it does not create or renew a lease.
pub fn load_current_task_claim(
    store: &SessionStore,
    run_id: &RunId,
    task_id: &str,
) -> Result<TaskClaim> {
    let catalog = store
        .read_run_catalog(run_id.as_str())?
        .context("task claim recovery requires a durable run catalog")?;
    let task = catalog
        .tasks
        .iter()
        .find(|task| task.task_id == task_id)
        .context("task claim recovery task is missing from the durable run catalog")?;
    if !matches!(&task.readiness, FmsTaskReadiness::Ready)
        || !matches!(
            task.lifecycle,
            FmsTaskLifecycle::Preparing | FmsTaskLifecycle::Running | FmsTaskLifecycle::Stopping
        )
    {
        bail!("task is not ready under an active durable claim");
    }
    let attempt_id = task
        .attempt_id
        .as_deref()
        .context("claimed task has no durable attempt id")?;
    let ownership_epoch = task
        .ownership_epoch
        .context("claimed task has no durable ownership epoch")?;
    let resource_id = task
        .resource_id
        .as_deref()
        .context("claimed task has no durable resource assignment")?;
    let durable_lease = store
        .read_active_resource_lease_for_task(run_id.as_str(), task_id)?
        .context("claimed task has no active durable resource lease")?;
    if durable_lease.run_id != run_id.as_str()
        || durable_lease.task_id != task_id
        || durable_lease.attempt_id != attempt_id
        || durable_lease.ownership_epoch != ownership_epoch
        || durable_lease.resource_id != resource_id
    {
        bail!("durable resource lease differs from the task claim in the run catalog");
    }

    let kind = match durable_lease.kind {
        FmsResourceKind::Cpu => ResourceKind::Cpu,
        FmsResourceKind::Gpu => ResourceKind::Gpu,
        FmsResourceKind::Storage => ResourceKind::Storage,
        FmsResourceKind::Meshing => ResourceKind::Meshing,
    };
    let claim = TaskClaim {
        run_id: run_id.clone(),
        task_id: TaskId::parse(task_id).context("invalid durable task id")?,
        attempt_id: AttemptId::parse(attempt_id).context("invalid durable attempt id")?,
        ownership_epoch: OwnershipEpoch::new(ownership_epoch)
            .context("invalid durable ownership epoch")?,
        lease: ResourceLease {
            resource_id: durable_lease.resource_id.clone(),
            kind,
            budget: ResourceBudget {
                cpu_millis: durable_lease.budget.cpu_millis,
                memory_bytes: durable_lease.budget.memory_bytes,
                gpu_memory_bytes: durable_lease.budget.gpu_memory_bytes,
                storage_bytes: durable_lease.budget.storage_bytes,
            },
            lease_token: LeaseToken::parse(durable_lease.lease_token.clone())
                .context("invalid durable lease token")?,
            heartbeat_sequence: durable_lease.heartbeat_sequence,
        },
    };
    store.require_active_resource_lease(
        run_id.as_str(),
        task_id,
        claim.attempt_id.as_str(),
        claim.ownership_epoch.value(),
        claim.lease.resource_id.as_str(),
        claim.lease.lease_token.as_str(),
        claim.lease.heartbeat_sequence,
    )?;
    Ok(claim)
}

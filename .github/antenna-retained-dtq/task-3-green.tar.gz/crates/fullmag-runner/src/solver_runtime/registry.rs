//! Runtime-registry engine resolution for backend dispatch.

use fullmag_ir::{BackendPlanIR, ExecutionPlanIR, FdmPlanIR, FemPlanIR, ProblemIR};

use crate::fem::eigen_execution_resolution::{FemEigenExecutionLane, PlannedFemEigenExecution};
use crate::runtime_registry::RuntimeRegistry;
use crate::solver_runtime::diagnostics::runtime_fallback;
use crate::solver_runtime::engine::{
    fem_engine_id, DispatchEngine, DispatchEngineResolution, FdmEngine, FemEngine,
};
use crate::solver_runtime::fem_crossover::resolve_auto_fem_plan_device;
use crate::solver_runtime::fem_selection::{
    has_antenna_field_source, resolve_fem_engine_for_plan_with_trail, resolve_fem_engine_with_trail,
};
use crate::solver_runtime::selection::{
    apply_runtime_gpu_index, effective_fem_device_request, public_fdm_gpu_charge_device_request,
    requested_registry_device_for_fdm, require_public_fdm_gpu_charge_runtime_selection,
    resolve_fdm_engine_for_plan_with_trail, resolve_fdm_engine_with_trail,
    resolve_registry_runtime_for_backend, runtime_fem_order, runtime_precision,
};
use crate::types::RunError;

fn reconcile_pinned_fem_crossover_decision(
    mut decision: Option<crate::types::FemCrossoverDecision>,
    resolved_device: &str,
    fallback: Option<&crate::types::ResolvedFallback>,
) -> Option<crate::types::FemCrossoverDecision> {
    if let Some(decision) = decision.as_mut() {
        decision.resolved = resolved_device.to_string();
        if let Some(fallback) = fallback {
            decision.reason = fallback.reason.clone();
        }
    }
    decision
}

pub(crate) fn resolve_fdm_engine_with_registry(
    problem: &ProblemIR,
    registry: &RuntimeRegistry,
    _explicit_selection: bool,
    plan: Option<&FdmPlanIR>,
) -> Result<DispatchEngineResolution, RunError> {
    apply_runtime_gpu_index(problem, "fdm");
    let requested_device = requested_registry_device_for_fdm(problem);
    let guard_requested_device = public_fdm_gpu_charge_device_request(problem);
    let requested_precision = runtime_precision(problem).to_string();
    let resolved = resolve_registry_runtime_for_backend(
        registry,
        "fdm",
        &requested_device,
        &requested_precision,
    )
    .ok_or_else(|| RunError {
        message: format!(
            "no advertised FDM runtime matches device={} precision={}",
            requested_device, requested_precision
        ),
    })?;

    let engine = match resolved.device.as_str() {
        "gpu" => FdmEngine::CudaFdm,
        _ => FdmEngine::CpuReference,
    };
    let fallback = resolved.fallback;
    let guarded_resolution = crate::solver_runtime::engine::EngineResolution {
        engine,
        fallback: fallback.clone(),
    };
    require_public_fdm_gpu_charge_runtime_selection(
        plan.is_some_and(|plan| !plan.fdm_gpu_charge_transports.is_empty()),
        &guard_requested_device,
        &guarded_resolution,
    )?;

    Ok(DispatchEngineResolution {
        engine: DispatchEngine::Fdm(engine),
        fallback,
        runtime_family: Some(resolved.runtime_family),
        worker: Some(resolved.worker),
        resolved_backend: "fdm".to_string(),
        resolved_device: resolved.device,
        resolved_precision: requested_precision,
        fem_crossover_decision: None,
    })
}

pub(crate) fn resolve_fem_engine_with_registry(
    problem: &ProblemIR,
    registry: &RuntimeRegistry,
    _explicit_selection: bool,
    plan: Option<&FemPlanIR>,
    preview_enabled: bool,
) -> Result<DispatchEngineResolution, RunError> {
    apply_runtime_gpu_index(problem, "fem");
    let requested_device = effective_fem_device_request(problem);
    let forced_device = requested_device != "auto";
    let fem_crossover_decision = plan
        .filter(|_| !forced_device)
        .map(|plan| resolve_auto_fem_plan_device(plan, preview_enabled));
    let requested_precision = runtime_precision(problem).to_string();
    let resolved = resolve_registry_runtime_for_backend(
        registry,
        "fem",
        &requested_device,
        &requested_precision,
    )
    .ok_or_else(|| RunError {
        message: format!(
            "no advertised FEM runtime matches device={} precision={}",
            requested_device, requested_precision
        ),
    })?;

    let engine = match resolved.device.as_str() {
        "gpu" => FemEngine::NativeGpu,
        _ => FemEngine::CpuNative,
    };
    let mut fallback = resolved.fallback;

    if engine == FemEngine::NativeGpu {
        if has_antenna_field_source(problem) {
            if forced_device {
                return Err(RunError {
                    message:
                        "FEM GPU execution was requested, but native FEM GPU currently does not support antenna_field_source current_modules (fallback_reason=current_modules_force_cpu)"
                            .to_string(),
                });
            }
            let cpu_resolved =
                resolve_registry_runtime_for_backend(registry, "fem", "cpu", &requested_precision)
                    .ok_or_else(|| {
                        RunError {
                message: "FEM GPU runtime cannot fall back because no CPU FEM runtime is advertised"
                    .to_string(),
            }
                    })?;
            let message = "FEM engine falling back to MFEM/libCEED/hypre CPU FEM — native FEM GPU does not support antenna_field_source current_modules (fallback_reason=current_modules_force_cpu)".to_string();
            fallback = Some(runtime_fallback(
                fem_engine_id(FemEngine::NativeGpu),
                fem_engine_id(FemEngine::CpuNative),
                "current_modules_force_cpu",
                message,
            ));
            let fem_crossover_decision = reconcile_pinned_fem_crossover_decision(
                fem_crossover_decision,
                "cpu",
                fallback.as_ref(),
            );
            return Ok(DispatchEngineResolution {
                engine: DispatchEngine::Fem(FemEngine::CpuNative),
                fallback,
                runtime_family: Some(cpu_resolved.runtime_family),
                worker: Some(cpu_resolved.worker),
                resolved_backend: "fem".to_string(),
                resolved_device: "cpu".to_string(),
                resolved_precision: requested_precision,
                fem_crossover_decision,
            });
        }

        let fe_order = runtime_fem_order(problem);
        if fe_order != 1 {
            if forced_device {
                return Err(RunError {
                    message: format!(
                        "native FEM GPU execution was requested, but the current native backend supports fe_order=1 only (requested order={}, fallback_reason=fem_gpu_fe_order_unsupported)",
                        fe_order
                    ),
                });
            }
            let cpu_resolved =
                resolve_registry_runtime_for_backend(registry, "fem", "cpu", &requested_precision)
                    .ok_or_else(|| {
                        RunError {
                message: "FEM GPU runtime cannot fall back because no CPU FEM runtime is advertised"
                    .to_string(),
            }
                    })?;
            let message = format!(
                "native FEM GPU backend currently supports fe_order=1 only; falling back to MFEM/libCEED/hypre CPU FEM for requested fe_order={} (fallback_reason=fem_gpu_fe_order_unsupported)",
                fe_order
            );
            fallback = Some(runtime_fallback(
                fem_engine_id(FemEngine::NativeGpu),
                fem_engine_id(FemEngine::CpuNative),
                "fem_gpu_fe_order_unsupported",
                message,
            ));
            let fem_crossover_decision = reconcile_pinned_fem_crossover_decision(
                fem_crossover_decision,
                "cpu",
                fallback.as_ref(),
            );
            return Ok(DispatchEngineResolution {
                engine: DispatchEngine::Fem(FemEngine::CpuNative),
                fallback,
                runtime_family: Some(cpu_resolved.runtime_family),
                worker: Some(cpu_resolved.worker),
                resolved_backend: "fem".to_string(),
                resolved_device: "cpu".to_string(),
                resolved_precision: requested_precision,
                fem_crossover_decision,
            });
        }

        if let Some(fem_plan) = plan {
            if !forced_device {
                let decision = fem_crossover_decision
                    .as_ref()
                    .expect("auto FEM plan must produce a crossover decision");
                if decision.resolved == "cpu" {
                    let cpu_resolved = resolve_registry_runtime_for_backend(
                        registry,
                        "fem",
                        "cpu",
                        &requested_precision,
                    )
                    .ok_or_else(|| RunError {
                        message: "FEM GPU runtime cannot fall back because no CPU FEM runtime is advertised"
                            .to_string(),
                    })?;
                    let message = format!(
                        "FEM auto-device policy resolved {} nodes to CPU ({})",
                        fem_plan.mesh.nodes.len(),
                        decision.reason
                    );
                    fallback = Some(runtime_fallback(
                        fem_engine_id(FemEngine::NativeGpu),
                        fem_engine_id(FemEngine::CpuNative),
                        &decision.reason,
                        message,
                    ));
                    let fem_crossover_decision = reconcile_pinned_fem_crossover_decision(
                        fem_crossover_decision,
                        "cpu",
                        fallback.as_ref(),
                    );
                    return Ok(DispatchEngineResolution {
                        engine: DispatchEngine::Fem(FemEngine::CpuNative),
                        fallback,
                        runtime_family: Some(cpu_resolved.runtime_family),
                        worker: Some(cpu_resolved.worker),
                        resolved_backend: "fem".to_string(),
                        resolved_device: "cpu".to_string(),
                        resolved_precision: requested_precision,
                        fem_crossover_decision,
                    });
                }
            }
        }
    }

    let fem_crossover_decision = reconcile_pinned_fem_crossover_decision(
        fem_crossover_decision,
        &resolved.device,
        fallback.as_ref(),
    );
    Ok(DispatchEngineResolution {
        engine: DispatchEngine::Fem(engine),
        fallback,
        runtime_family: Some(resolved.runtime_family),
        worker: Some(resolved.worker),
        resolved_backend: "fem".to_string(),
        resolved_device: resolved.device,
        resolved_precision: requested_precision,
        fem_crossover_decision,
    })
}

fn planned_fem_eigen_dispatch_resolution(
    execution: PlannedFemEigenExecution<'_>,
    registry: Option<&RuntimeRegistry>,
) -> Result<DispatchEngineResolution, RunError> {
    let resolution = execution.resolution().ok_or_else(|| RunError {
        message: "planned_fem_eigen_resolution_missing_at_session_boundary".to_string(),
    })?;
    let (engine, device) = match execution.lane() {
        FemEigenExecutionLane::Cpu => (FemEngine::CpuNative, "cpu"),
        FemEigenExecutionLane::Gpu => (FemEngine::NativeGpu, "gpu"),
    };
    let precision = match resolution.resolved_precision {
        fullmag_ir::ExecutionPrecision::Double => "double",
        fullmag_ir::ExecutionPrecision::Single => "single",
    };
    let runtime = registry
        .map(|registry| {
            registry.resolve("fem", device, precision).ok_or_else(|| RunError {
                message: format!(
                    "planned_fem_eigen_runtime_unavailable: resolved_engine={} device={device} precision={precision}",
                    execution.engine_id()
                ),
            })
        })
        .transpose()?;
    Ok(DispatchEngineResolution {
        engine: DispatchEngine::Fem(engine),
        fallback: resolution.fallback_reason.as_ref().map(|reason| {
            runtime_fallback(
                "auto",
                execution.engine_id(),
                reason,
                format!(
                    "FEM eigen planner resolved auto execution to {} ({})",
                    execution.engine_id(),
                    resolution.selection_reason
                ),
            )
        }),
        runtime_family: runtime
            .as_ref()
            .map(|runtime| runtime.runtime_family.clone()),
        worker: runtime.map(|runtime| runtime.worker),
        resolved_backend: "fem".to_string(),
        resolved_device: device.to_string(),
        resolved_precision: precision.to_string(),
        fem_crossover_decision: None,
    })
}

pub(crate) fn resolve_antenna_inspection_runtime(
    inspection: &fullmag_ir::AntennaExternalLeadInspectionBackendPlanIR,
    registry: Option<&RuntimeRegistry>,
) -> Result<DispatchEngineResolution, RunError> {
    crate::antenna_external_lead_solution::validate_execution(&inspection.requested_execution)?;
    let runtime = registry
        .map(|registry| {
            registry.resolve("fem", "cpu", "double").ok_or_else(|| RunError {
                message: "antenna inspection requires an advertised FEM CPU double runtime; no GPU or magnetic fallback".into(),
            })
        })
        .transpose()?;
    if registry.is_none() && !crate::native_fem::is_cpu_available() {
        return Err(RunError {
            message: "antenna inspection requires native FEM CPU availability; no legacy or magnetic fallback".into(),
        });
    }
    Ok(DispatchEngineResolution {
        engine: DispatchEngine::Fem(FemEngine::CpuNative),
        fallback: None,
        runtime_family: runtime
            .as_ref()
            .map(|runtime| runtime.runtime_family.clone()),
        worker: runtime.map(|runtime| runtime.worker),
        resolved_backend: "fem".into(),
        resolved_device: "cpu".into(),
        resolved_precision: "double".into(),
        fem_crossover_decision: None,
    })
}

pub(crate) fn resolve_with_registry(
    problem: &ProblemIR,
    plan: &ExecutionPlanIR,
    registry: Option<&RuntimeRegistry>,
    explicit_selection: bool,
    preview_enabled: bool,
) -> Result<DispatchEngineResolution, RunError> {
    match registry {
        Some(registry) => match &plan.backend_plan {
            BackendPlanIR::AntennaFieldOnly(_)
            | BackendPlanIR::AntennaRetainedCurrentFieldInspection(_)
            | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => Err(crate::field_only_plan_not_executable_as_llg()),
            BackendPlanIR::Fdm(fdm) => {
                resolve_fdm_engine_with_registry(problem, registry, explicit_selection, Some(fdm))
            }
            BackendPlanIR::FdmMultilayer(_) => {
                resolve_fdm_engine_with_registry(problem, registry, explicit_selection, None)
            }
            BackendPlanIR::Fem(fem) => resolve_fem_engine_with_registry(
                problem,
                registry,
                explicit_selection,
                Some(fem),
                preview_enabled,
            ),
            BackendPlanIR::FemEigen(fem) => {
                match crate::fem::eigen_execution_resolution::resolve_planned_fem_eigen_execution(
                    plan, fem,
                )? {
                    Some(execution) => {
                        planned_fem_eigen_dispatch_resolution(execution, Some(registry))
                    }
                    None => resolve_fem_engine_with_registry(
                        problem,
                        registry,
                        explicit_selection,
                        None,
                        false,
                    ),
                }
            }
            BackendPlanIR::FemFrequencyResponse(_) => {
                resolve_fem_engine_with_registry(problem, registry, explicit_selection, None, false)
            }
            BackendPlanIR::AntennaExternalLeadInspection(inspection) => {
                resolve_antenna_inspection_runtime(inspection, Some(registry))
            }
        },
        None => match &plan.backend_plan {
            BackendPlanIR::AntennaFieldOnly(_)
            | BackendPlanIR::AntennaRetainedCurrentFieldInspection(_)
            | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => Err(crate::field_only_plan_not_executable_as_llg()),
            BackendPlanIR::Fdm(fdm) => {
                let resolution = resolve_fdm_engine_for_plan_with_trail(problem, fdm)?;
                Ok(DispatchEngineResolution {
                    engine: DispatchEngine::Fdm(resolution.engine),
                    fallback: resolution.fallback,
                    runtime_family: None,
                    worker: None,
                    resolved_backend: "fdm".to_string(),
                    resolved_device: match resolution.engine {
                        FdmEngine::CudaFdm => "gpu".to_string(),
                        FdmEngine::CpuReference => "cpu".to_string(),
                    },
                    resolved_precision: runtime_precision(problem).to_string(),
                    fem_crossover_decision: None,
                })
            }
            BackendPlanIR::FdmMultilayer(_) => {
                let resolution = resolve_fdm_engine_with_trail(problem)?;
                Ok(DispatchEngineResolution {
                    engine: DispatchEngine::Fdm(resolution.engine),
                    fallback: resolution.fallback,
                    runtime_family: None,
                    worker: None,
                    resolved_backend: "fdm".to_string(),
                    resolved_device: match resolution.engine {
                        FdmEngine::CudaFdm => "gpu".to_string(),
                        FdmEngine::CpuReference => "cpu".to_string(),
                    },
                    resolved_precision: runtime_precision(problem).to_string(),
                    fem_crossover_decision: None,
                })
            }
            BackendPlanIR::Fem(fem) => {
                let resolution =
                    resolve_fem_engine_for_plan_with_trail(problem, fem, preview_enabled)?;
                Ok(DispatchEngineResolution {
                    engine: DispatchEngine::Fem(resolution.engine),
                    fallback: resolution.fallback,
                    runtime_family: None,
                    worker: None,
                    resolved_backend: "fem".to_string(),
                    resolved_device: match resolution.engine {
                        FemEngine::NativeGpu => "gpu".to_string(),
                        FemEngine::CpuNative => "cpu".to_string(),
                    },
                    resolved_precision: runtime_precision(problem).to_string(),
                    fem_crossover_decision: resolution.fem_crossover_decision,
                })
            }
            BackendPlanIR::FemEigen(fem) => {
                match crate::fem::eigen_execution_resolution::resolve_planned_fem_eigen_execution(
                    plan, fem,
                )? {
                    Some(execution) => planned_fem_eigen_dispatch_resolution(execution, None),
                    None => {
                        let resolution = resolve_fem_engine_with_trail(problem)?;
                        Ok(DispatchEngineResolution {
                            engine: DispatchEngine::Fem(resolution.engine),
                            fallback: resolution.fallback,
                            runtime_family: None,
                            worker: None,
                            resolved_backend: "fem".to_string(),
                            resolved_device: match resolution.engine {
                                FemEngine::NativeGpu => "gpu".to_string(),
                                FemEngine::CpuNative => "cpu".to_string(),
                            },
                            resolved_precision: runtime_precision(problem).to_string(),
                            fem_crossover_decision: None,
                        })
                    }
                }
            }
            BackendPlanIR::FemFrequencyResponse(_) => {
                let resolution = resolve_fem_engine_with_trail(problem)?;
                Ok(DispatchEngineResolution {
                    engine: DispatchEngine::Fem(resolution.engine),
                    fallback: resolution.fallback,
                    runtime_family: None,
                    worker: None,
                    resolved_backend: "fem".to_string(),
                    resolved_device: match resolution.engine {
                        FemEngine::NativeGpu => "gpu".to_string(),
                        FemEngine::CpuNative => "cpu".to_string(),
                    },
                    resolved_precision: runtime_precision(problem).to_string(),
                    fem_crossover_decision: None,
                })
            }
            BackendPlanIR::AntennaExternalLeadInspection(inspection) => {
                resolve_antenna_inspection_runtime(inspection, None)
            }
        },
    }
}

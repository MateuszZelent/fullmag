//! Artifact writing: metadata, scalars CSV, field snapshots.

use crate::artifact_pipeline::ArtifactPipelineSummary;
use crate::dispatch::{
    effective_fem_device_request, normalized_runtime_element_markers,
    requested_registry_device_for_fdm, runtime_device, runtime_precision,
};
use fullmag_ir::BackendPlanIR;
use fullmag_quantities::fem_state_field::FemP1MagnetizationFieldSemantics;
use sha2::{Digest, Sha256};

use crate::types::{
    ExecutedRun, ExecutionRequestProvenance, FemCpuRelaxationAlgorithmPolicyMetadata,
    FemCpuRelaxationDemagPolicyMetadata, FemCpuRelaxationDemagTimingsNs,
    FemCpuRelaxationEnergyTerms, FemCpuRelaxationQualificationMetadata,
    FemGpuRelaxationAlgorithmPolicyMetadata, FemGpuRelaxationDevicePolicyMetadata,
    FemGpuRelaxationQualificationMetadata, FinalExecutionResolutionProvenance, StepStats,
};

use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::fs;
use std::io::{BufWriter, Error, ErrorKind, Write};
use std::path::Path;

const MU0_H_PER_M: f64 = 1.256_637_062_12e-6;

pub(crate) const SOLVER_DIAGNOSTIC_TRACE_ARTIFACT: &str = "solver/accepted_steps.v1.json";
pub(crate) const PHYSICS_GRAPH_PROVENANCE_ARTIFACT: &str =
    "physics/physics_graph_provenance.v1.json";

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
struct SolverDiagnosticTraceArtifact {
    schema_version: String,
    steps: Vec<StepStats>,
}

/// Materialize the validated semantic graph at the artifact boundary.
///
/// This is deliberately separate from `ExecutionProvenance`: the latter is a
/// long-lived compatibility struct with many constructors, while this graph
/// certificate is an additive, schema-versioned projection of the exact
/// ProblemIR graph and the lane resolution used for the run.  The additive
/// `realization` member carries the concrete topology certificate; the
/// marker/mask IDs in the legacy module records remain semantic identities and
/// must not be read as element/cell coordinates.
fn physics_graph_provenance_artifact(
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
    executed: Option<&ExecutedRun>,
) -> std::io::Result<Option<crate::types::AuxiliaryArtifact>> {
    if problem.physics_graph.is_none() {
        return Ok(None);
    }
    let mut payload = if let Some(provenance) = plan.provenance.physics_graph.clone() {
        provenance
    } else {
        fullmag_plan::physics_graph_runtime_provenance(problem, &plan.backend_plan)
            .map_err(|reasons| Error::new(ErrorKind::InvalidData, reasons.join("; ")))?
            .ok_or_else(|| {
                Error::new(
                    ErrorKind::InvalidData,
                    "physics_graph runtime provenance could not be resolved",
                )
            })?
    };
    let observed_module_ids = executed
        .map(|run| observed_physics_graph_module_ids(&run.provenance))
        .unwrap_or_default();
    payload.realization = fullmag_plan::physics_graph_realization_provenance(
        problem,
        &plan.backend_plan,
        &observed_module_ids,
    )
    .map_err(|reasons| Error::new(ErrorKind::InvalidData, reasons.join("; ")))?;
    let bytes = serde_json::to_vec_pretty(&payload).map_err(|error| {
        Error::new(
            ErrorKind::InvalidData,
            format!("physics graph provenance cannot be serialized: {error}"),
        )
    })?;
    Ok(Some(crate::types::AuxiliaryArtifact {
        relative_path: PHYSICS_GRAPH_PROVENANCE_ARTIFACT.to_string(),
        bytes,
    }))
}

/// Return only exact module IDs backed by an execution observation. Legacy
/// kind-only observations are intentionally ignored. Authored-graph
/// validation remains fail-closed in `physics_graph_realization_provenance`.
fn observed_physics_graph_module_ids(
    provenance: &crate::types::ExecutionProvenance,
) -> Vec<String> {
    provenance
        .executed_physics_module_ids
        .iter()
        .cloned()
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect()
}

/// Preserve the accepted-step trace across the execution/artifact boundary.
/// `RunResult.steps` is an output trace and may be sparse; this auxiliary
/// artifact is consumed by `write_artifacts` when producing solver CSVs.
pub(crate) fn solver_diagnostic_trace_artifact(
    steps: Vec<StepStats>,
) -> Option<crate::types::AuxiliaryArtifact> {
    if steps.is_empty() {
        return None;
    }
    let payload = SolverDiagnosticTraceArtifact {
        schema_version: "LLG-TD-ACCEPTED-TRACE-V1".to_string(),
        steps,
    };
    Some(crate::types::AuxiliaryArtifact {
        relative_path: SOLVER_DIAGNOSTIC_TRACE_ARTIFACT.to_string(),
        bytes: serde_json::to_vec(&payload).expect("solver diagnostic trace must serialize"),
    })
}

fn solver_diagnostic_steps(executed: &ExecutedRun) -> Option<Vec<StepStats>> {
    executed
        .auxiliary_artifacts
        .iter()
        .find(|artifact| artifact.relative_path == SOLVER_DIAGNOSTIC_TRACE_ARTIFACT)
        .and_then(|artifact| {
            serde_json::from_slice::<SolverDiagnosticTraceArtifact>(&artifact.bytes)
                .ok()
                .filter(|trace| trace.schema_version == "LLG-TD-ACCEPTED-TRACE-V1")
                .map(|trace| trace.steps)
        })
}

#[cfg(test)]
fn execution_provenance_json(
    plan: &fullmag_ir::ExecutionPlanIR,
    execution_provenance: &crate::types::ExecutionProvenance,
) -> std::io::Result<serde_json::Value> {
    validate_execution_provenance_for_artifacts(plan, execution_provenance)?;
    let mut value =
        serde_json::to_value(execution_provenance).expect("ExecutionProvenance must serialize");
    if let Some(transfer) = fdm_multilayer_transfer_realization(plan, execution_provenance) {
        value
            .as_object_mut()
            .expect("ExecutionProvenance must serialize to an object")
            .insert("fdm_multilayer_transfer".to_string(), transfer);
    }
    Ok(value)
}

fn validate_execution_provenance_for_artifacts(
    plan: &fullmag_ir::ExecutionPlanIR,
    execution_provenance: &crate::types::ExecutionProvenance,
) -> std::io::Result<()> {
    if plan.common.execution_mode == fullmag_ir::ExecutionMode::Strict
        && execution_provenance.execution_engine == "fem_native_gpu"
        && (execution_provenance.mfem_version.is_none()
            || execution_provenance.hypre_version.is_none())
    {
        return Err(Error::new(
            ErrorKind::Other,
            "strict native FEM GPU artifacts require MFEM and HYPRE versions from the loaded runtime",
        ));
    }
    Ok(())
}

#[derive(serde::Serialize)]
struct MetadataExecutionProvenance<'a> {
    #[serde(flatten)]
    execution: &'a crate::types::ExecutionProvenance,
    #[serde(skip_serializing_if = "Option::is_none")]
    fdm_multilayer_transfer: Option<&'a serde_json::Value>,
    execution_resolution: &'a FinalExecutionResolutionProvenance,
    #[serde(skip_serializing_if = "Option::is_none")]
    physics_graph: Option<&'a serde_json::Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    thermal: Option<&'a serde_json::Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    spin_torque: Option<&'a serde_json::Value>,
}

struct RunMetadata<'a> {
    problem: &'a fullmag_ir::ProblemIR,
    plan: &'a fullmag_ir::ExecutionPlanIR,
    requested_execution: &'a serde_json::Value,
    field_context: &'a FieldArtifactContext,
    mesh: &'a serde_json::Value,
    region_realization_revisions: &'a serde_json::Value,
    periodic_antidot_relaxation: &'a serde_json::Value,
    execution_provenance: &'a MetadataExecutionProvenance<'a>,
    runtime_threading: &'a serde_json::Value,
    demag_runtime: &'a serde_json::Value,
    fem_cpu_relaxation_qualification: &'a serde_json::Value,
    fem_gpu_relaxation_qualification: &'a serde_json::Value,
    executed: &'a ExecutedRun,
    accepted_solver_steps: usize,
    artifact_pipeline: &'a serde_json::Value,
    material_field_assets: &'a [serde_json::Value],
    sampling_resolution: Option<&'a serde_json::Value>,
}

impl serde::Serialize for RunMetadata<'_> {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeMap;

        let mut map = serializer.serialize_map(Some(26))?;
        map.serialize_entry("problem_name", &self.problem.problem_meta.name)?;
        map.serialize_entry("ir_version", &self.problem.ir_version)?;
        map.serialize_entry("source_hash", &self.problem.problem_meta.source_hash)?;
        map.serialize_entry("problem_meta", &self.problem.problem_meta)?;
        map.serialize_entry("pbc", &self.problem.pbc)?;
        map.serialize_entry("execution_plan", self.plan)?;
        map.serialize_entry("requested_execution", self.requested_execution)?;
        map.serialize_entry("artifact_layout", &self.field_context.layout)?;
        map.serialize_entry("mesh", self.mesh)?;
        map.serialize_entry(
            "region_realization_revisions",
            self.region_realization_revisions,
        )?;
        map.serialize_entry(
            "periodic_antidot_relaxation",
            self.periodic_antidot_relaxation,
        )?;
        map.serialize_entry("execution_provenance", self.execution_provenance)?;
        map.serialize_entry("runtime_threading", self.runtime_threading)?;
        map.serialize_entry("demag_runtime", self.demag_runtime)?;
        map.serialize_entry(
            "fem_cpu_relaxation_qualification",
            self.fem_cpu_relaxation_qualification,
        )?;
        map.serialize_entry(
            "fem_gpu_relaxation_qualification",
            self.fem_gpu_relaxation_qualification,
        )?;
        map.serialize_entry("engine_version", env!("CARGO_PKG_VERSION"))?;
        map.serialize_entry("build_identity", &build_identity_json())?;
        map.serialize_entry("status", &self.executed.result.status)?;
        map.serialize_entry("completion", &self.executed.result.completion)?;
        map.serialize_entry("scalar_rows", &self.executed.result.steps.len())?;
        map.serialize_entry("accepted_solver_steps", &self.accepted_solver_steps)?;
        map.serialize_entry("field_snapshots", &self.executed.field_snapshot_count)?;
        map.serialize_entry("artifact_pipeline", self.artifact_pipeline)?;
        map.serialize_entry("material_field_assets", self.material_field_assets)?;
        if let Some(sampling_resolution) = self.sampling_resolution {
            map.serialize_entry("sampling_resolution", sampling_resolution)?;
        }
        map.end()
    }
}

fn serialize_run_metadata(metadata: &RunMetadata<'_>) -> std::io::Result<Vec<u8>> {
    let mut bytes = Vec::new();
    serde_json::to_writer_pretty(&mut bytes, metadata).map_err(|error| {
        Error::new(
            ErrorKind::InvalidData,
            format!("serializing run metadata: {error}"),
        )
    })?;
    Ok(bytes)
}

fn fdm_multilayer_transfer_realization(
    plan: &fullmag_ir::ExecutionPlanIR,
    execution_provenance: &crate::types::ExecutionProvenance,
) -> Option<serde_json::Value> {
    let fullmag_ir::BackendPlanIR::FdmMultilayer(fdm) = &plan.backend_plan else {
        return None;
    };
    let realization = match execution_provenance.execution_engine.as_str() {
        "cpu_reference_multilayer" => "volume_weighted_overlap_adjoint",
        // The native CUDA push/pull lane currently has a different pull map;
        // keep it explicit so an oracle cannot silently assume CPU semantics.
        "cuda_assisted_multilayer" | "cuda_native_multilayer_single_grid" => "runtime_specific",
        _ => "unknown",
    };
    Some(serde_json::json!({
        "schema_version": "fdm_multilayer_transfer_realization.v1",
        "realization": realization,
        "layers": fdm.layers.iter().map(|layer| serde_json::json!({
            "magnet_name": layer.magnet_name,
            "transfer_kind": layer.transfer_kind,
        })).collect::<Vec<_>>(),
    }))
}

pub(crate) fn artifact_provenance_json(
    context: &FieldArtifactContext,
    provenance: &crate::types::ExecutionProvenance,
) -> serde_json::Value {
    let mut value = serde_json::to_value(provenance).expect("ExecutionProvenance must serialize");
    let object = value
        .as_object_mut()
        .expect("ExecutionProvenance must serialize to an object");
    object.insert(
        "problem_name".to_string(),
        serde_json::Value::String(context.problem_name.clone()),
    );
    object.insert(
        "ir_version".to_string(),
        serde_json::Value::String(context.ir_version.clone()),
    );
    object.insert(
        "source_hash".to_string(),
        serde_json::to_value(&context.source_hash).expect("source hash must serialize"),
    );
    object.insert(
        "execution_mode".to_string(),
        serde_json::to_value(context.execution_mode).expect("execution mode must serialize"),
    );
    object.insert("build_identity".to_string(), build_identity_json());
    if let Some(resolution) = context.execution_resolution.as_ref() {
        object.insert(
            "execution_resolution".to_string(),
            serde_json::to_value(resolution)
                .expect("FinalExecutionResolutionProvenance must serialize"),
        );
    }
    value
}

pub(crate) fn build_identity_json() -> serde_json::Value {
    let identity = fullmag_build_info::identity();
    serde_json::json!({
        "built_at_utc": identity.built_at_utc,
        "git_commit": identity.git_commit,
        "worktree_state": identity.worktree_state,
        "source_snapshot_sha256": identity.source_snapshot_sha256,
    })
}

/// Materialize the typed producer sidecar from the exact payload bytes that
/// are about to be written.  The runner does not invent a run identity: the
/// execution owner must provide `producer_run_id` and `producer_stage_id` in
/// the problem runtime metadata. Public standalone entry points allocate this
/// binding before dispatch; orchestrated calls retain their supplied identity.
/// Direct artifact writers without it receive no verified replay sidecar.
fn fem_relaxation_producer_provenance_artifact(
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
    executed: &ExecutedRun,
) -> std::io::Result<Option<crate::types::AuxiliaryArtifact>> {
    let fullmag_ir::BackendPlanIR::Fem(source_plan) = &plan.backend_plan else {
        return Ok(None);
    };
    if source_plan.relaxation.is_none()
        || !matches!(executed.result.status, crate::types::RunStatus::Completed)
    {
        return Ok(None);
    }
    let runtime_metadata = &problem.problem_meta.runtime_metadata;
    let Some(source_run_id) = runtime_metadata
        .get("producer_run_id")
        .and_then(serde_json::Value::as_str)
        .filter(|value| !value.trim().is_empty())
    else {
        return Ok(None);
    };
    let Some(source_stage_id) = runtime_metadata
        .get("producer_stage_id")
        .and_then(serde_json::Value::as_str)
        .filter(|value| !value.trim().is_empty())
    else {
        return Ok(None);
    };
    let Some(source_stage_kind) = runtime_metadata
        .get("producer_stage_kind")
        .and_then(serde_json::Value::as_str)
        .filter(|value| !value.trim().is_empty())
    else {
        return Ok(None);
    };

    let accepted_path = crate::types::CertifiedFemEquilibriumFields::accepted_artifact_path_for_material(
        &source_plan.material,
    );
    let (certified_path, recomputed_path) =
        crate::types::CertifiedFemEquilibriumFields::artifact_paths_for_material(
            &source_plan.material,
        );
    let exact_bytes = |path: &str, label: &str| -> std::io::Result<&[u8]> {
        let mut matches = executed
            .auxiliary_artifacts
            .iter()
            .filter(|artifact| artifact.relative_path == path);
        let Some(artifact) = matches.next() else {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!(
                    "FEM relaxation producer sidecar missing exact {label} payload {path}"
                ),
            ));
        };
        if matches.next().is_some() {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!("FEM relaxation producer sidecar has duplicate {label} payload {path}"),
            ));
        }
        Ok(artifact.bytes.as_slice())
    };
    const UNAVAILABLE_PATH: &str = "equilibrium/certification_unavailable.v1.json";
    if let Err(unavailable) =
        crate::fem::equilibrium_identity::validate_supported_relax_source(source_plan)
    {
        // Ordinary accepted-state publication has a wider physics scope than
        // certified modal replay. Preserve that explicit distinction instead
        // of requiring nonexistent modal certificates for a legal endpoint.
        let marker: serde_json::Value = serde_json::from_slice(exact_bytes(
            UNAVAILABLE_PATH, "certification availability",
        )?)
        .map_err(|error| Error::new(ErrorKind::InvalidData, error))?;
        let (step, time) = executed.result.steps.last()
            .map_or((0, 0.0), |stats| (stats.step, stats.time));
        let expected = serde_json::json!({
            "schema_version": "fullmag.fem_equilibrium_certification_unavailable.v1",
            "reason": unavailable.message,
            "accepted_step": step,
            "time_seconds": time,
            "state_role": "time_domain_observation_only",
        });
        if marker != expected || executed.auxiliary_artifacts.iter().any(|artifact| {
            [accepted_path, certified_path, recomputed_path,
             crate::fem::eigen_equilibrium_contract::FEM_RELAXATION_PRODUCER_PROVENANCE_RELATIVE_PATH]
                .contains(&artifact.relative_path.as_str())
        }) {
            return Err(Error::new(ErrorKind::InvalidData,
                "FEM relaxation certification availability conflicts with its source scope or accepted endpoint"));
        }
        return Ok(None);
    }
    if executed.auxiliary_artifacts.iter().any(|artifact| artifact.relative_path == UNAVAILABLE_PATH) {
        return Err(Error::new(ErrorKind::InvalidData,
            "certifiable FEM relaxation unexpectedly declares certification unavailable"));
    }
    let accepted_bytes = exact_bytes(accepted_path, "accepted fields")?;
    let certified_bytes = exact_bytes(certified_path, "certified fields")?;
    let recomputed_bytes = exact_bytes(recomputed_path, "recomputed certificate")?;
    let provenance = crate::fem::eigen_equilibrium_contract::
        fem_relaxation_producer_provenance_from_exact_artifacts(
            source_run_id,
            source_stage_id,
            source_stage_kind,
            source_plan,
            &executed.result.final_magnetization,
            build_identity_json(),
            accepted_path,
            accepted_bytes,
            certified_path,
            certified_bytes,
            recomputed_path,
            recomputed_bytes,
        )
        .map_err(|error| Error::new(ErrorKind::InvalidData, error.message))?;
    let bytes = serde_json::to_vec_pretty(&provenance).map_err(|error| {
        Error::new(
            ErrorKind::InvalidData,
            format!("serializing FEM relaxation producer provenance: {error}"),
        )
    })?;
    Ok(Some(crate::types::AuxiliaryArtifact {
        relative_path: crate::fem::eigen_equilibrium_contract::
            FEM_RELAXATION_PRODUCER_PROVENANCE_RELATIVE_PATH
            .to_string(),
        bytes,
    }))
}

fn runtime_threading_summary(problem: &fullmag_ir::ProblemIR) -> serde_json::Value {
    let resolved_cpu_threads = u32::try_from(crate::configured_cpu_threads(problem)).ok();
    serde_json::json!({
        "requested_cpu_threads": crate::requested_cpu_threads(problem),
        "resolved_cpu_threads": resolved_cpu_threads,
        "requested_fem_omp_threads": serde_json::Value::Null,
        "effective_fem_omp_threads": serde_json::Value::Null,
    })
}

fn region_realization_revisions_metadata(problem: &fullmag_ir::ProblemIR) -> serde_json::Value {
    problem
        .problem_meta
        .runtime_metadata
        .get("region_realization_revisions")
        .cloned()
        .unwrap_or(serde_json::Value::Null)
}

fn requested_execution_metadata(problem: &fullmag_ir::ProblemIR) -> serde_json::Value {
    let authored = authored_execution_request(problem);
    serde_json::json!({
        "backend": authored.backend,
        "device": authored.device,
        "precision": authored.precision,
        "mode": authored.mode,
        "fallback_policy": if authored.mode == "strict" { "forbidden" } else { "allowed" },
    })
}

fn execution_mode_name(mode: fullmag_ir::ExecutionMode) -> &'static str {
    match mode {
        fullmag_ir::ExecutionMode::Strict => "strict",
        fullmag_ir::ExecutionMode::Extended => "extended",
        fullmag_ir::ExecutionMode::Hybrid => "hybrid",
    }
}

fn execution_precision_name(precision: fullmag_ir::ExecutionPrecision) -> &'static str {
    match precision {
        fullmag_ir::ExecutionPrecision::Single => "single",
        fullmag_ir::ExecutionPrecision::Double => "double",
    }
}

fn normalize_execution_device(device: &str) -> String {
    device.replace("cuda", "gpu")
}

fn authored_execution_request(problem: &fullmag_ir::ProblemIR) -> ExecutionRequestProvenance {
    ExecutionRequestProvenance {
        backend: problem
            .backend_policy
            .requested_backend
            .as_str()
            .to_string(),
        device: normalize_execution_device(runtime_device(problem).unwrap_or("auto")),
        precision: execution_precision_name(problem.backend_policy.execution_precision).to_string(),
        mode: execution_mode_name(problem.validation_profile.execution_mode).to_string(),
    }
}

fn retained_field_execution_request(execution: &fullmag_ir::RequestedTransportExecutionIR) -> ExecutionRequestProvenance {
    ExecutionRequestProvenance {
        backend: execution.discretization.as_str().to_string(),
        device: match execution.device {
            fullmag_ir::ExecutionDevice::Auto => "auto",
            fullmag_ir::ExecutionDevice::Cpu => "cpu",
            fullmag_ir::ExecutionDevice::Gpu => "gpu",
        }.to_string(),
        precision: execution_precision_name(execution.precision).to_string(),
        mode: execution_mode_name(execution.execution_mode).to_string(),
    }
}

fn effective_execution_request(
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
) -> ExecutionRequestProvenance {
    let device = match &plan.backend_plan {
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(inspection) => {
            return retained_field_execution_request(&inspection.requested_execution);
        }
        BackendPlanIR::AntennaRetainedDirectFieldInspection(inspection) => {
            return retained_field_execution_request(&inspection.requested_execution);
        }
        BackendPlanIR::AntennaRetainedPreparationFieldInspection(inspection) => {
            return retained_field_execution_request(&inspection.requested_execution);
        }
        BackendPlanIR::AntennaFieldOnly(_) => {
            normalize_execution_device(runtime_device(problem).unwrap_or("auto"))
        }
        BackendPlanIR::AntennaExternalLeadInspection(inspection) => {
            match inspection.requested_execution.device {
                fullmag_ir::ExecutionDevice::Auto => "auto".to_string(),
                fullmag_ir::ExecutionDevice::Cpu => "cpu".to_string(),
                fullmag_ir::ExecutionDevice::Gpu => "gpu".to_string(),
            }
        }
        BackendPlanIR::Fdm(_) | BackendPlanIR::FdmMultilayer(_) => {
            requested_registry_device_for_fdm(problem)
        }
        BackendPlanIR::Fem(_)
        | BackendPlanIR::FemEigen(_)
        | BackendPlanIR::FemFrequencyResponse(_) => {
            let authored_device =
                normalize_execution_device(runtime_device(problem).unwrap_or("auto"));
            if problem.validation_profile.execution_mode == fullmag_ir::ExecutionMode::Strict
                && authored_device != "auto"
            {
                authored_device
            } else {
                effective_fem_device_request(problem)
            }
        }
    };
    ExecutionRequestProvenance {
        backend: plan.common.requested_backend.as_str().to_string(),
        device: normalize_execution_device(&device),
        precision: runtime_precision(problem).to_string(),
        mode: execution_mode_name(plan.common.execution_mode).to_string(),
    }
}

fn canonical_engine_identity(engine: &str) -> &str {
    match engine {
        "cpu_reference" | "fdm_cpu_reference" => {
            crate::solver_runtime::engine::fdm_engine_id(
                crate::solver_runtime::engine::FdmEngine::CpuReference,
            )
        }
        "cuda_fdm" | "fdm_cuda" => crate::solver_runtime::engine::fdm_engine_id(
            crate::solver_runtime::engine::FdmEngine::CudaFdm,
        ),
        other => other,
    }
}

fn actual_engine_backend_and_device(engine: &str) -> std::io::Result<(&'static str, &'static str)> {
    let resolved = match canonical_engine_identity(engine) {
        "fdm_cpu_reference" | "cpu_reference_multilayer" => ("fdm", "cpu"),
        "fdm_cuda"
        | "cuda_fdm_charge_only"
        | "cuda_assisted_multilayer"
        | "cuda_native_multilayer_convolution"
        | "cuda_native_multilayer_single_grid"
        | "cuda_native_multilayer_demag_v2"
        | "fdm_gpu_native" => ("fdm", "gpu"),
        "fem_native_gpu" | "fem_eigen_native_gpu" => ("fem", "gpu"),
        "fem_cpu_native"
        | "fem_eigen_cpu_baseline"
        | "native_fem_cpu"
        | "native_fem.frequency_domain.production_cpu"
        | "runner.frequency_response_test"
        | "runner.dense_block_real_validation" => ("fem", "cpu"),
        _ => {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!("final execution provenance has unknown execution_engine '{engine}'"),
            ));
        }
    };
    Ok(resolved)
}

fn validate_direct_minimizer_realization(
    plan: &fullmag_ir::ExecutionPlanIR,
    provenance: &crate::types::ExecutionProvenance,
    resolved_device: &str,
) -> std::io::Result<()> {
    let relaxation = match &plan.backend_plan {
        BackendPlanIR::Fdm(fdm) => fdm.relaxation.as_ref(),
        BackendPlanIR::FdmMultilayer(fdm) => fdm.relaxation.as_ref(),
        BackendPlanIR::Fem(fem) => fem.relaxation.as_ref(),
        _ => None,
    };
    let Some(control) = relaxation else {
        return Ok(());
    };
    if !matches!(
        control.algorithm,
        fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb
            | fullmag_ir::RelaxationAlgorithmIR::NonlinearCg
            | fullmag_ir::RelaxationAlgorithmIR::TangentPlaneImplicit
    ) {
        return Ok(());
    }

    let expected_algorithm = control.algorithm.as_str();
    if provenance.requested_energy_minimizer.as_deref() != Some(expected_algorithm)
        || provenance.resolved_energy_minimizer.as_deref() != Some(expected_algorithm)
    {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "final direct-minimizer provenance mismatch: plan algorithm={expected_algorithm}, requested={:?}, resolved={:?}",
                provenance.requested_energy_minimizer,
                provenance.resolved_energy_minimizer
            ),
        ));
    }

    let expected_realization = match &plan.backend_plan {
        BackendPlanIR::FdmMultilayer(_) if resolved_device == "cpu"
            && control.algorithm == fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb => {
            Some("cpu_reference_multilayer_projected_gradient_bb")
        }
        BackendPlanIR::FdmMultilayer(_) if resolved_device == "gpu"
            && control.algorithm == fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb => {
            crate::relaxation::native_direct_minimizer_realization(control.algorithm, true)
        }
        BackendPlanIR::Fdm(_) if resolved_device == "cpu" => {
            Some(crate::relaxation::expected_cpu_direct_minimizer_realization(
                provenance.fdm_cpu_state_layout.as_ref(),
            ))
        }
        BackendPlanIR::Fdm(_) if resolved_device == "gpu" => {
            Some(crate::relaxation::CUDA_FDM_HOST_DIRECT_MINIMIZER_REALIZATION)
        }
        BackendPlanIR::Fem(_) => {
            crate::relaxation::native_direct_minimizer_realization(
                control.algorithm,
                resolved_device == "gpu",
            )
        }
        _ => None,
    }
    .ok_or_else(|| {
        Error::new(
            ErrorKind::InvalidData,
            format!(
                "no direct-minimizer realization is defined for algorithm={expected_algorithm} device={resolved_device}"
            ),
        )
    })?;

    if provenance.energy_minimizer_realization.as_deref() != Some(expected_realization) {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "final direct-minimizer realization mismatch: engine={} algorithm={} expected={} actual={:?}",
                provenance.execution_engine,
                expected_algorithm,
                expected_realization,
                provenance.energy_minimizer_realization
            ),
        ));
    }
    Ok(())
}

fn final_execution_resolution_provenance(
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
    provenance: &crate::types::ExecutionProvenance,
) -> std::io::Result<FinalExecutionResolutionProvenance> {
    let authored_request = authored_execution_request(problem);
    let effective_request = effective_execution_request(problem, plan);
    let (resolved_backend, resolved_device) =
        actual_engine_backend_and_device(&provenance.execution_engine)?;
    let resolved_precision = provenance.precision.as_str();
    if !matches!(resolved_precision, "single" | "double") {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!("final execution provenance has invalid precision '{resolved_precision}'"),
        ));
    }
    let planned_backend = plan.common.resolved_backend.as_str();
    if resolved_backend != planned_backend {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "resolved backend mismatch: plan={planned_backend} actual_engine={} actual_backend={resolved_backend}",
                provenance.execution_engine
            ),
        ));
    }
    if effective_request.backend != "auto" && effective_request.backend != resolved_backend {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "forced backend mismatch: effective={} resolved={resolved_backend}",
                effective_request.backend
            ),
        ));
    }
    if effective_request.device != "auto" && effective_request.device != resolved_device {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "forced device mismatch: effective={} resolved={resolved_device}",
                effective_request.device
            ),
        ));
    }
    if authored_request.mode == "strict"
        && authored_request.device != "auto"
        && authored_request.device != resolved_device
    {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "forced device mismatch: authored strict={} resolved={resolved_device}",
                authored_request.device
            ),
        ));
    }
    if effective_request.precision != resolved_precision {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "execution precision mismatch: effective={} resolved={resolved_precision}",
                effective_request.precision
            ),
        ));
    }

    let fallback = provenance.resolved_fallback.as_ref();
    if fallback.is_some_and(|entry| !entry.occurred) {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "resolved_fallback is present but occurred=false",
        ));
    }
    let fallback_occurred = fallback.is_some_and(|entry| entry.occurred);
    if plan.common.execution_mode == fullmag_ir::ExecutionMode::Strict && fallback_occurred {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "strict execution metadata cannot contain a resolved fallback",
        ));
    }
    let fallback_reason = fallback.map(|entry| entry.reason.clone());
    if fallback_reason.as_deref().is_some_and(str::is_empty) {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "resolved fallback must contain a non-empty reason",
        ));
    }
    if let Some(entry) = fallback {
        if canonical_engine_identity(&entry.original_engine)
            == canonical_engine_identity(&entry.fallback_engine)
        {
            return Err(Error::new(
                ErrorKind::InvalidData,
                "resolved fallback original_engine and fallback_engine must differ",
            ));
        }
        if canonical_engine_identity(&entry.fallback_engine)
            != canonical_engine_identity(&provenance.execution_engine)
        {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!(
                    "resolved fallback engine mismatch: fallback={} actual={}",
                    entry.fallback_engine, provenance.execution_engine
                ),
            ));
        }
        actual_engine_backend_and_device(&entry.fallback_engine)?;
    }

    validate_direct_minimizer_realization(plan, provenance, resolved_device)?;

    let resolved_execution = ExecutionRequestProvenance {
        backend: resolved_backend.to_string(),
        device: resolved_device.to_string(),
        precision: resolved_precision.to_string(),
        mode: execution_mode_name(plan.common.execution_mode).to_string(),
    };
    let resolution_mode = if fallback_occurred {
        "fallback"
    } else if authored_request != effective_request {
        "override"
    } else if effective_request.backend == "auto" || effective_request.device == "auto" {
        "automatic"
    } else {
        "exact"
    };

    Ok(FinalExecutionResolutionProvenance {
        authored_request,
        effective_request,
        resolved_execution,
        resolution_mode: resolution_mode.to_string(),
        fallback_occurred,
        fallback_reason,
    })
}

fn count_periodic_pairs_by_id<T>(
    pairs: &[T],
    pair_id: impl Fn(&T) -> &str,
) -> BTreeMap<String, usize> {
    let mut counts = BTreeMap::new();
    for pair in pairs {
        *counts.entry(pair_id(pair).to_string()).or_insert(0) += 1;
    }
    counts
}

fn mesh_runtime_metadata(plan: &fullmag_ir::ExecutionPlanIR) -> serde_json::Value {
    match &plan.backend_plan {
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(inspection) => {
            retained_current_field_layout(inspection)
        }
        BackendPlanIR::AntennaRetainedDirectFieldInspection(inspection) => {
            retained_direct_field_layout(inspection)
        }
        BackendPlanIR::AntennaRetainedPreparationFieldInspection(inspection) => {
            retained_preparation_field_layout(inspection)
        }
        BackendPlanIR::AntennaFieldOnly(antenna) => serde_json::json!({
            "backend": "antenna_field_only",
            "stage_id": antenna.stage_id,
            "port_mode_id": antenna.port_mode_id,
            "source_object_id": antenna.source_object_id,
            "source_mesh_name": antenna.source_mesh.mesh_name,
            "source_topology_fingerprint": antenna.source_mesh.topology_fingerprint_v6(),
            "source_node_count": antenna.source_mesh.nodes.len(),
            "source_element_count": antenna.source_mesh.cell_count(),
            "field_sampling": antenna.field_sampling,
            "magnetic_state_present": false,
        }),
        BackendPlanIR::Fdm(fdm) => serde_json::json!({
            "backend": "fdm",
            "requested_periodicity": fdm.periodicity,
            "resolved_demag_boundary": fdm
                .periodicity
                .as_ref()
                .and_then(|pbc| pbc.resolve_demag_boundary(fdm.enable_demag).ok()),
            "resolved_periodic_images": fdm
                .resolved_periodic_images,
            "region_legend": fdm.grid_certificate.as_ref().map(|certificate| &certificate.region_legend),
            "region_legend_fingerprint": fdm
                .grid_certificate
                .as_ref()
                .and_then(|certificate| certificate.region_legend_fingerprint.as_deref()),
            "grid_cells": fdm.grid.cells,
        }),
        BackendPlanIR::FdmMultilayer(fdm) => serde_json::json!({
            "backend": "fdm_multilayer",
            "requested_periodicity": fdm.periodicity,
            "resolved_demag_boundary": fdm
                .periodicity
                .as_ref()
                .and_then(|pbc| pbc.resolve_demag_boundary(fdm.enable_demag).ok()),
            "resolved_periodic_images": fdm
                .resolved_periodic_images,
            "region_legend": fdm.grid_certificate.as_ref().map(|certificate| &certificate.region_legend),
            "region_legend_fingerprint": fdm
                .grid_certificate
                .as_ref()
                .and_then(|certificate| certificate.region_legend_fingerprint.as_deref()),
            "transfer_boundary_policy": fdm
                .periodicity
                .as_ref()
                .map(|pbc| {
                    pbc.axes.map(|axis| match axis {
                        fullmag_ir::AxisBoundary::Periodic => "periodic",
                        fullmag_ir::AxisBoundary::Open => "open",
                    })
                })
                .unwrap_or(["open"; 3]),
            "periodic_axes": fdm
                .periodicity
                .as_ref()
                .map(|pbc| {
                    pbc.axes.map(|axis| matches!(axis, fullmag_ir::AxisBoundary::Periodic))
                })
                .unwrap_or([false; 3]),
            "target_grid_fingerprint": fdm.grid_certificate.as_ref().map(|certificate| &certificate.grid_fingerprint),
            "transfer_provenance": fdm.layers.iter().filter_map(|layer| {
                let active_cells = layer
                    .native_active_mask
                    .as_ref()
                    .map(|mask| mask.iter().filter(|is_active| **is_active).count() as u64)
                    .unwrap_or_else(|| {
                        u64::from(layer.native_grid[0])
                            * u64::from(layer.native_grid[1])
                            * u64::from(layer.native_grid[2])
                    });
                let certificate = fullmag_ir::FdmGridCertificateIR::new(
                    layer.native_origin,
                    layer.native_grid,
                    layer.native_cell_size,
                    active_cells,
                    1,
                )
                .ok()?;
                Some(serde_json::json!({
                    "magnet_name": layer.magnet_name,
                    "transfer_kind": layer.transfer_kind,
                    "source_grid_fingerprint": certificate.grid_fingerprint,
                    "target_grid_fingerprint": fdm.grid_certificate.as_ref().map(|value| value.grid_fingerprint.clone()),
                    "periodic_axes": fdm.periodicity.as_ref().map(|pbc| pbc.axes.map(|axis| matches!(axis, fullmag_ir::AxisBoundary::Periodic))).unwrap_or([false; 3]),
                }))
            }).collect::<Vec<_>>(),
            "grid_cells": fdm.common_cells,
        }),
        BackendPlanIR::Fem(fem) => serde_json::json!({
            "mesh_name": fem.mesh.mesh_name,
            "mesh_generation_id": solver_mesh_signature(&fem.mesh),
            "topology_fingerprint": fem.mesh.topology_fingerprint_v6(),
            "node_count": fem.mesh.nodes.len(),
            "element_count": fem.mesh.cell_count(),
            "boundary_face_count": fem.mesh.facet_count(),
            "periodic_boundary_pair_count": fem.mesh.periodic_boundary_pairs.len(),
            "periodic_node_pair_count": fem.mesh.periodic_node_pairs.len(),
            "periodic_boundary_pair_counts_by_id": count_periodic_pairs_by_id(
                &fem.mesh.periodic_boundary_pairs,
                |pair| pair.pair_id.as_str(),
            ),
            "periodic_node_pair_counts_by_id": count_periodic_pairs_by_id(
                &fem.mesh.periodic_node_pairs,
                |pair| pair.pair_id.as_str(),
            ),
            "mesh_build_report": fem.mesh_build_report,
        }),
        BackendPlanIR::FemEigen(fem) => serde_json::json!({
            "mesh_name": fem.mesh.mesh_name,
            "mesh_generation_id": solver_mesh_signature(&fem.mesh),
            "topology_fingerprint": fem.mesh.topology_fingerprint_v6(),
            "node_count": fem.mesh.nodes.len(),
            "element_count": fem.mesh.cell_count(),
            "boundary_face_count": fem.mesh.facet_count(),
            "periodic_boundary_pair_count": fem.mesh.periodic_boundary_pairs.len(),
            "periodic_node_pair_count": fem.mesh.periodic_node_pairs.len(),
            "periodic_boundary_pair_counts_by_id": count_periodic_pairs_by_id(
                &fem.mesh.periodic_boundary_pairs,
                |pair| pair.pair_id.as_str(),
            ),
            "periodic_node_pair_counts_by_id": count_periodic_pairs_by_id(
                &fem.mesh.periodic_node_pairs,
                |pair| pair.pair_id.as_str(),
            ),
            "mesh_build_report": fem.mesh_build_report,
        }),
        BackendPlanIR::AntennaExternalLeadInspection(inspection) => serde_json::json!({
            "scope": "antenna_external_lead_inspection",
            "mesh_name": inspection.input.combined_mesh.mesh_name,
            "topology_fingerprint": inspection.input.combined_mesh.topology_fingerprint_v6(),
            "node_count": inspection.input.combined_mesh.nodes.len(),
            "element_count": inspection.input.combined_mesh.cell_count(),
            "field_sampling_topology_digest": inspection.input.field_sampling.topology_digest,
        }),
        BackendPlanIR::FemFrequencyResponse(fem) => serde_json::json!({
            "mesh_name": fem.mesh.mesh_name,
            "mesh_generation_id": solver_mesh_signature(&fem.mesh),
            "topology_fingerprint": fem.mesh.topology_fingerprint_v6(),
            "node_count": fem.mesh.nodes.len(),
            "element_count": fem.mesh.cell_count(),
            "boundary_face_count": fem.mesh.facet_count(),
            "periodic_boundary_pair_count": fem.mesh.periodic_boundary_pairs.len(),
            "periodic_node_pair_count": fem.mesh.periodic_node_pairs.len(),
            "periodic_boundary_pair_counts_by_id": count_periodic_pairs_by_id(
                &fem.mesh.periodic_boundary_pairs,
                |pair| pair.pair_id.as_str(),
            ),
            "periodic_node_pair_counts_by_id": count_periodic_pairs_by_id(
                &fem.mesh.periodic_node_pairs,
                |pair| pair.pair_id.as_str(),
            ),
            "mesh_build_report": fem.mesh_build_report,
        }),
    }
}

fn provenance_with_runtime_threading(
    problem: &fullmag_ir::ProblemIR,
    provenance: &crate::types::ExecutionProvenance,
    steps: &[StepStats],
) -> crate::types::ExecutionProvenance {
    let mut enriched = provenance.clone();
    enriched.requested_cpu_threads = crate::requested_cpu_threads(problem);
    enriched.resolved_cpu_threads = u32::try_from(crate::configured_cpu_threads(problem)).ok();
    // Populate FEM OMP thread provenance from the first step that has non-zero
    // thread info (reported by the native C++ backend via FFI).
    if enriched.requested_fem_omp_threads.is_none() {
        if let Some(first) = steps.first() {
            if first.requested_fem_omp_threads > 0 {
                enriched.requested_fem_omp_threads = Some(first.requested_fem_omp_threads as u32);
            }
            if first.effective_fem_omp_threads > 0 {
                enriched.effective_fem_omp_threads = Some(first.effective_fem_omp_threads as u32);
            }
        }
    }
    enriched
}

fn thermal_execution_provenance(
    plan: &fullmag_ir::ExecutionPlanIR,
    steps: &[StepStats],
    provenance: &crate::types::ExecutionProvenance,
) -> Option<serde_json::Value> {
    let (seed, is_fdm) = match &plan.backend_plan {
        BackendPlanIR::Fem(fem) => (fem.thermal_seed_config.as_ref()?, false),
        BackendPlanIR::Fdm(fdm) => (fdm.thermal_seed_config.as_ref()?, true),
        _ => return None,
    };
    let resolved_seed = if is_fdm {
        provenance.random_seed.or(seed.seed)
    } else {
        seed.seed
    };
    let resolved_policy = if is_fdm && resolved_seed.is_some() {
        fullmag_ir::SeedPolicy::Fixed
    } else {
        seed.policy
    };
    Some(serde_json::json!({
        "requested_seed_policy": seed.policy,
        "resolved_seed_policy": resolved_policy,
        "resolved_seed": resolved_seed,
        "accepted_interval_index": steps.len(),
    }))
}

fn fem_spin_torque_provenance(
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
    execution: &crate::types::ExecutionProvenance,
) -> Option<serde_json::Value> {
    let BackendPlanIR::Fem(fem) = &plan.backend_plan else {
        return None;
    };
    let contract = fem.spin_torque_contract.as_ref()?;
    let (authored_class, authored_id) = problem
        .spin_torque_modules
        .iter()
        .find_map(|module| match module {
            fullmag_ir::SpinTorqueModuleIR::Slonczewski { id, .. }
                if contract.formula_version.starts_with("slonczewski.") =>
            {
                Some(("SlonczewskiSTT", id.as_deref()))
            }
            fullmag_ir::SpinTorqueModuleIR::ZhangLi { id, .. }
                if contract.formula_version.starts_with("zhang_li.") =>
            {
                Some(("ZhangLiSTT", id.as_deref()))
            }
            _ => None,
        })
        .unwrap_or(("legacy_flat_stt", None));
    let canonical_class = if contract.formula_version.starts_with("slonczewski.") {
        "SlonczewskiSTT"
    } else if contract.formula_version.starts_with("zhang_li.") {
        "ZhangLiSTT"
    } else {
        "unknown"
    };
    let active_node_count = contract
        .active_node_mask
        .as_ref()
        .map(|mask| mask.iter().filter(|active| **active).count());
    let active_element_count = contract
        .active_element_mask
        .as_ref()
        .map(|mask| mask.iter().filter(|active| **active).count());

    Some(serde_json::json!({
        "schema_version": "spin_torque_provenance.v1",
        "artifact_path": "physics/spin_torque_provenance.v1.json",
        "authored_class": authored_class,
        "authored_id": authored_id,
        "canonical_class": canonical_class,
        "formula_version": contract.formula_version,
        "operator_version": contract.operator_version,
        "realization_version": contract.realization_version,
        "target": contract.target,
        "current_convention": "conventional_charge_current",
        "current_density_unit": "A/m^2",
        "current_density": fem.current_density,
        "degree": fem.stt_degree,
        "beta": fem.stt_beta,
        "spin_polarization": fem.stt_spin_polarization,
        "lambda_asymmetry": fem.stt_lambda,
        "epsilon_prime": fem.stt_epsilon_prime,
        "free_layer_thickness_m": fem.stt_thickness,
        "free_layer_thickness_unit": "m",
        "stack_normal": contract.stack_normal,
        "lande_g": contract.lande_g,
        "active_node_count": active_node_count,
        "total_node_count": fem.mesh.nodes.len(),
        "active_element_count": active_element_count,
        "total_element_count": fem.mesh.cell_count(),
        "material": {
            "saturation_magnetisation_A_per_m": fem.material.saturation_magnetisation,
            "gilbert_damping": fem.material.damping,
        },
        "resolved_execution_engine": execution.execution_engine,
        "resolved_precision": execution.precision,
        "resolved_fallback": execution.resolved_fallback,
    }))
}

fn demag_amg_profile_metadata(
    preconditioner: &str,
    stats: Option<&StepStats>,
) -> serde_json::Value {
    if preconditioner != "AMG" {
        return serde_json::Value::Null;
    }
    let Some(stats) = stats else {
        return serde_json::Value::Null;
    };
    serde_json::json!({
        "provider": "mfem_hypre_boomeramg",
        "relax_type": stats.demag_amg_relax_type,
        "coarsening": stats.demag_amg_coarsening,
        "interpolation": stats.demag_amg_interpolation,
        "aggressive_coarsening": stats.demag_amg_aggressive_coarsening,
        "strength_threshold": stats.demag_amg_strength_threshold_is_set
            .then_some(stats.demag_amg_strength_threshold),
        "max_levels": stats.demag_amg_max_levels_is_set
            .then_some(stats.demag_amg_max_levels),
    })
}

fn demag_runtime_metadata(
    plan: &fullmag_ir::ExecutionPlanIR,
    provenance: &crate::types::ExecutionProvenance,
    steps: &[StepStats],
) -> serde_json::Value {
    match &plan.backend_plan {
        BackendPlanIR::Fem(fem) => {
            if !fem.enable_demag {
                return serde_json::Value::Null;
            }

            let requested_policy = fem.demag_solver_policy.as_ref();
            let policy = requested_policy.cloned().unwrap_or_default();
            let resolved_policy = provenance.fem_poisson_demag.as_ref();
            let policy_source = if requested_policy.is_some() {
                "explicit"
            } else {
                "resolved_default"
            };
            let resolved_demag = fem
                .demag_realization
                .unwrap_or(fullmag_ir::ResolvedFemDemagIR::PoissonRobin);
            let periodic_poisson_reduction_enabled =
                resolved_demag.is_poisson() && !fem.mesh.periodic_node_pairs.is_empty();
            let periodic_boundary_markers_excluded_from_robin =
                periodic_poisson_reduction_enabled && !fem.mesh.periodic_boundary_pairs.is_empty();
            let magnetostatic_boundary_model = if periodic_poisson_reduction_enabled {
                "periodic_airbox_k0"
            } else {
                match resolved_demag {
                    fullmag_ir::ResolvedFemDemagIR::PoissonDirichlet => "open_airbox_dirichlet",
                    fullmag_ir::ResolvedFemDemagIR::PoissonRobin => "open_airbox_robin",
                    fullmag_ir::ResolvedFemDemagIR::FredkinKoehler => "fredkin_koehler",
                    fullmag_ir::ResolvedFemDemagIR::Bem => "bem",
                    fullmag_ir::ResolvedFemDemagIR::Fmm => "fmm",
                }
            };
            let poisson_operator = if periodic_poisson_reduction_enabled {
                Some("pbc_reduced_poisson")
            } else if resolved_demag.is_poisson() {
                Some("full_poisson")
            } else {
                None
            };
            let last = steps.last();
            let boundary_variant = match resolved_demag {
                fullmag_ir::ResolvedFemDemagIR::PoissonDirichlet => Some("dirichlet"),
                fullmag_ir::ResolvedFemDemagIR::PoissonRobin => Some("robin"),
                _ => None,
            };
            let timings_ns = last.map(|entry| {
                serde_json::json!({
                    "assemble": entry.demag_assemble_wall_time_ns,
                    "solve": entry.demag_solve_wall_time_ns,
                    "solver_setup": entry.demag_solver_setup_wall_time_ns,
                    "solver_apply": entry.demag_solver_apply_wall_time_ns,
                    "hypre_wait_in_enqueue": entry.demag_hypre_wait_in_enqueue_wall_time_ns,
                    "hypre_host_api": entry.demag_hypre_host_api_wall_time_ns,
                    "hypre_device_elapsed": entry.demag_hypre_device_elapsed_time_ns,
                    "hypre_wait_out_enqueue": entry.demag_hypre_wait_out_enqueue_wall_time_ns,
                    "hypre_event_wait_count": entry.demag_hypre_event_wait_count,
                    "hypre_timed_solve_count": entry.demag_hypre_timed_solve_count,
                    "recover": entry.demag_recover_wall_time_ns,
                    "energy": entry.demag_energy_wall_time_ns,
                    "total": entry.demag_wall_time_ns,
                })
            });
            let linear_solver =
                resolved_policy.map_or(policy.solver, |entry| entry.linear_solver.clone());
            let preconditioner =
                resolved_policy.map_or(policy.preconditioner, |entry| entry.preconditioner.clone());
            let relative_tolerance = resolved_policy.map_or(policy.rtol, |entry| entry.rtol);
            let max_iterations =
                resolved_policy.map_or(policy.max_iterations, |entry| entry.max_iterations);
            let amg_profile = demag_amg_profile_metadata(&preconditioner, last);
            let (runtime_solver, runtime_preconditioner) = if matches!(
                provenance.fem_demag_operator_mode.as_deref(),
                Some("device_hypre_poisson") | Some("device_hypre_fem_bem")
            ) {
                let solver = match linear_solver.as_str() {
                    "CG" => Some("HyprePCG"),
                    "GMRES" => Some("HypreGMRES"),
                    _ => None,
                };
                let preconditioner = match preconditioner.as_str() {
                    "AMG" => Some("HypreBoomerAMG"),
                    "JACOBI" => Some("HypreDiagScale"),
                    "NONE" => Some("HypreIdentity"),
                    _ => None,
                };
                (solver, preconditioner)
            } else {
                (None, None)
            };

            let mut metadata = serde_json::json!({
                "model": resolved_demag.model_name(),
                "magnetostatic_boundary_model": magnetostatic_boundary_model,
                "boundary_variant": boundary_variant,
                "poisson_operator": poisson_operator,
                "periodic_reduction": {
                    "enabled": periodic_poisson_reduction_enabled,
                    "method": if periodic_poisson_reduction_enabled { Some("P^T A P") } else { None },
                    "node_pair_count": fem.mesh.periodic_node_pairs.len(),
                    "boundary_pair_count": fem.mesh.periodic_boundary_pairs.len(),
                    "node_pair_counts_by_id": count_periodic_pairs_by_id(
                        &fem.mesh.periodic_node_pairs,
                        |pair| pair.pair_id.as_str(),
                    ),
                    "boundary_pair_counts_by_id": count_periodic_pairs_by_id(
                        &fem.mesh.periodic_boundary_pairs,
                        |pair| pair.pair_id.as_str(),
                    ),
                    "periodic_boundary_markers_excluded_from_robin": periodic_boundary_markers_excluded_from_robin,
                },
                "linear_solver": linear_solver,
                "preconditioner": preconditioner,
                "runtime_solver": runtime_solver,
                "runtime_preconditioner": runtime_preconditioner,
                "amg_profile": amg_profile,
                "relative_tolerance": relative_tolerance,
                "absolute_tolerance": policy.atol,
                "max_iterations": max_iterations,
                "print_level": policy.print_level,
                "policy_source": policy_source,
                "requested_linear_solver": requested_policy.map(|entry| entry.solver.clone()),
                "requested_preconditioner": requested_policy.map(|entry| entry.preconditioner.clone()),
                "requested_relative_tolerance": requested_policy.map(|entry| entry.rtol),
                "requested_absolute_tolerance": requested_policy.and_then(|entry| entry.atol),
                "requested_max_iterations": requested_policy.map(|entry| entry.max_iterations),
                "requested_print_level": requested_policy.map(|entry| entry.print_level),
                "actual_iterations": last.map(|entry| entry.poisson_iterations),
                "final_residual_norm": last.map(|entry| entry.poisson_final_residual),
                "solver_setup_reused": last.map(|entry| entry.demag_solver_setup_reused),
                "timings_ns": timings_ns,
                "mfem_device": provenance.mfem_device,
                "hypre_version": provenance.hypre_version,
                "fem_assembly_mode": provenance.fem_assembly_mode,
                "requested_fem_omp_threads": provenance.requested_fem_omp_threads,
                "effective_fem_omp_threads": provenance.effective_fem_omp_threads,
                "bem_operator": provenance.fem_bem_demag,
                "airbox_factor": fem.air_box_config.as_ref().map(|cfg| cfg.factor),
                "robin_beta_mode": fem
                    .air_box_config
                    .as_ref()
                    .and_then(|cfg| cfg.robin_beta_mode.clone()),
                "robin_beta_factor": fem
                    .air_box_config
                    .as_ref()
                    .and_then(|cfg| cfg.robin_beta_factor),
            });
            if provenance.execution_engine == "fem_cpu_native" {
                if let Some(coupling) = provenance.cpu_fixed_coupling.as_ref()
                    .or_else(|| last.and_then(|stats| stats.cpu_fixed_coupling.as_ref()))
                {
                    metadata["cpu_fixed_coupling"] = serde_json::json!(coupling);
                }
            }
            metadata
        }
        _ => serde_json::Value::Null,
    }
}

fn fem_cpu_relaxation_qualification_metadata(
    plan: &fullmag_ir::ExecutionPlanIR,
    provenance: &crate::types::ExecutionProvenance,
    demag_runtime: &serde_json::Value,
    executed: &ExecutedRun,
) -> serde_json::Value {
    let BackendPlanIR::Fem(fem) = &plan.backend_plan else {
        return serde_json::Value::Null;
    };
    if provenance.execution_engine != "fem_cpu_native" {
        return serde_json::Value::Null;
    }

    let Some(last) = executed.result.steps.last() else {
        return serde_json::Value::Null;
    };
    let completion = executed.result.completion.as_ref();

    let metadata = FemCpuRelaxationQualificationMetadata {
        schema_version: "fem_cpu_relaxation_qualification.v1".to_string(),
        benchmark_gate_version: "fem_cpu_no_pbc_adaptive.v1".to_string(),
        physics_terms: fem_physics_terms(fem),
        solver_mesh_signature: solver_mesh_signature(&fem.mesh),
        demag_policy: FemCpuRelaxationDemagPolicyMetadata {
            model: json_string(demag_runtime, "model"),
            boundary_variant: json_string(demag_runtime, "boundary_variant"),
            linear_solver: json_string(demag_runtime, "linear_solver"),
            preconditioner: json_string(demag_runtime, "preconditioner"),
            relative_tolerance: json_f64(demag_runtime, "relative_tolerance"),
            absolute_tolerance: json_f64(demag_runtime, "absolute_tolerance"),
            max_iterations: json_u32(demag_runtime, "max_iterations"),
            print_level: json_i32(demag_runtime, "print_level"),
            actual_iterations: json_u32(demag_runtime, "actual_iterations"),
            final_residual_norm: json_f64(demag_runtime, "final_residual_norm"),
            solver_setup_reused: json_bool(demag_runtime, "solver_setup_reused"),
            timings_ns: demag_timings_ns(demag_runtime),
        },
        algorithm_policy: fem_cpu_relaxation_algorithm_policy_metadata(fem, provenance),
        assembly_mode: provenance.fem_assembly_mode.clone(),
        relaxation_algorithm: fem
            .relaxation
            .as_ref()
            .map(|control| control.algorithm.as_str().to_string()),
        converged: completion.is_some_and(|entry| entry.converged),
        stop_reason: completion
            .and_then(|entry| entry.reason.as_ref())
            .map(stage_stop_reason_as_str)
            .map(str::to_string),
        stop_metric_kind: completion.and_then(|entry| entry.metric),
        stop_metric_unit: completion
            .and_then(|entry| entry.metric_unit())
            .map(str::to_string),
        stop_metric_name: completion.and_then(|entry| entry.metric_name.clone()),
        stop_metric_value: completion.and_then(|entry| entry.metric_value),
        stop_threshold: completion.and_then(|entry| entry.threshold),
        final_energy_terms_j: FemCpuRelaxationEnergyTerms {
            e_ex: last.e_ex,
            e_demag: last.e_demag,
            e_ext: last.e_ext,
            e_drive: last.e_drive,
            e_ani: last.e_ani,
            e_dmi: last.e_dmi,
            e_total: last.e_total,
        },
        final_torque_apm: last.max_torque_Apm,
        final_torque_t: last.max_torque_T,
        norm_defect: magnetization_norm_defect_for_fem_plan(
            fem,
            &executed.result.final_magnetization,
        ),
        executed_steps: last.step,
    };
    serde_json::to_value(metadata).unwrap_or(serde_json::Value::Null)
}

fn fem_cpu_relaxation_algorithm_policy_metadata(
    fem: &fullmag_ir::FemPlanIR,
    provenance: &crate::types::ExecutionProvenance,
) -> Option<FemCpuRelaxationAlgorithmPolicyMetadata> {
    let control = fem.relaxation.as_ref()?;
    let derivative_contract = fem_energy_weighted_armijo_contract(control, provenance);
    let gpu_status = provenance.fem_gpu_qualification_status.clone();
    match control.algorithm {
        fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb => {
            Some(FemCpuRelaxationAlgorithmPolicyMetadata {
                realization: provenance.energy_minimizer_realization.clone(),
                time_integrator: None,
                precession_policy: None,
                rhs_policy: None,
                metric: derivative_contract.map(|contract| contract.metric.to_string()),
                gradient_metric: derivative_contract
                    .map(|contract| contract.gradient_metric.to_string()),
                gradient_units: derivative_contract
                    .map(|contract| contract.gradient_units.to_string()),
                search_direction_units: derivative_contract
                    .map(|contract| contract.search_direction_units.to_string()),
                line_search_step_units: derivative_contract
                    .map(|contract| contract.line_search_step_units.to_string()),
                armijo_slope_units: derivative_contract
                    .map(|contract| contract.armijo_slope_units.to_string()),
                armijo_decrement_units: derivative_contract
                    .map(|contract| contract.armijo_decrement_units.to_string()),
                armijo_derivative_units: derivative_contract
                    .map(|contract| contract.armijo_derivative_units.to_string()),
                line_search: Some("native_armijo_backtracking_bb1_bb2".to_string()),
                preconditioner: Some("exchange_plus_mass_tangent_gradient".to_string()),
                linear_solver_policy: Some(
                    "serial MFEM CG production default; HyprePCG/BoomerAMG explicit opt-in"
                        .to_string(),
                ),
                tangent_operator: None,
                direction_update: None,
                step_update: Some("alternating_bb1_bb2".to_string()),
                gpu_status,
            })
        }
        fullmag_ir::RelaxationAlgorithmIR::NonlinearCg => {
            Some(FemCpuRelaxationAlgorithmPolicyMetadata {
                realization: provenance.energy_minimizer_realization.clone(),
                time_integrator: None,
                precession_policy: None,
                rhs_policy: None,
                metric: derivative_contract.map(|contract| contract.metric.to_string()),
                gradient_metric: derivative_contract
                    .map(|contract| contract.gradient_metric.to_string()),
                gradient_units: derivative_contract
                    .map(|contract| contract.gradient_units.to_string()),
                search_direction_units: derivative_contract
                    .map(|contract| contract.search_direction_units.to_string()),
                line_search_step_units: derivative_contract
                    .map(|contract| contract.line_search_step_units.to_string()),
                armijo_slope_units: derivative_contract
                    .map(|contract| contract.armijo_slope_units.to_string()),
                armijo_decrement_units: derivative_contract
                    .map(|contract| contract.armijo_decrement_units.to_string()),
                armijo_derivative_units: derivative_contract
                    .map(|contract| contract.armijo_derivative_units.to_string()),
                line_search: Some("native_armijo_backtracking_pr_plus_restart".to_string()),
                preconditioner: Some("exchange_plus_mass_tangent_gradient".to_string()),
                linear_solver_policy: Some(
                    "serial MFEM CG production default; HyprePCG/BoomerAMG explicit opt-in"
                        .to_string(),
                ),
                tangent_operator: None,
                direction_update: Some("polak_ribiere_plus_projected_restart".to_string()),
                step_update: None,
                gpu_status,
            })
        }
        fullmag_ir::RelaxationAlgorithmIR::TangentPlaneImplicit => {
            Some(FemCpuRelaxationAlgorithmPolicyMetadata {
                realization: provenance.energy_minimizer_realization.clone(),
                time_integrator: None,
                precession_policy: None,
                rhs_policy: None,
                metric: derivative_contract.map(|contract| contract.metric.to_string()),
                gradient_metric: derivative_contract
                    .map(|contract| contract.gradient_metric.to_string()),
                gradient_units: derivative_contract
                    .map(|contract| contract.gradient_units.to_string()),
                search_direction_units: derivative_contract
                    .map(|contract| contract.search_direction_units.to_string()),
                line_search_step_units: derivative_contract
                    .map(|contract| contract.line_search_step_units.to_string()),
                armijo_slope_units: derivative_contract
                    .map(|contract| contract.armijo_slope_units.to_string()),
                armijo_decrement_units: derivative_contract
                    .map(|contract| contract.armijo_decrement_units.to_string()),
                armijo_derivative_units: derivative_contract
                    .map(|contract| contract.armijo_derivative_units.to_string()),
                line_search: Some("native_armijo_backtracking".to_string()),
                preconditioner: Some(
                    "native_tangent_plane_linear_solve_preconditioner".to_string(),
                ),
                linear_solver_policy: Some(
                    "MFEM/Hypre Krylov solver with non-SPD fallback for indefinite terms"
                        .to_string(),
                ),
                tangent_operator: Some(
                    "mass_exchange_local_anisotropy_zeeman_dmi_demag_linear_response".to_string(),
                ),
                direction_update: None,
                step_update: None,
                gpu_status,
            })
        }
        fullmag_ir::RelaxationAlgorithmIR::LlgOverdamped => {
            Some(FemCpuRelaxationAlgorithmPolicyMetadata {
                realization: provenance.energy_minimizer_realization.clone().or_else(|| {
                    Some(crate::relaxation::NATIVE_LLG_TIME_INTEGRATOR_REALIZATION.to_string())
                }),
                time_integrator: provenance.resolved_integrator.clone(),
                precession_policy: Some("disabled_pure_damping".to_string()),
                rhs_policy: Some("llg_overdamped_rhs".to_string()),
                metric: None,
                gradient_metric: None,
                gradient_units: None,
                search_direction_units: None,
                line_search_step_units: None,
                armijo_slope_units: None,
                armijo_decrement_units: None,
                armijo_derivative_units: None,
                line_search: None,
                preconditioner: None,
                linear_solver_policy: None,
                tangent_operator: None,
                direction_update: None,
                step_update: None,
                gpu_status,
            })
        }
    }
}

#[derive(Clone, Copy)]
struct FemEnergyWeightedArmijoContract {
    metric: &'static str,
    gradient_metric: &'static str,
    gradient_units: &'static str,
    search_direction_units: &'static str,
    line_search_step_units: &'static str,
    armijo_slope_units: &'static str,
    armijo_decrement_units: &'static str,
    armijo_derivative_units: &'static str,
}

fn fem_energy_weighted_armijo_contract(
    control: &fullmag_ir::RelaxationControlIR,
    provenance: &crate::types::ExecutionProvenance,
) -> Option<FemEnergyWeightedArmijoContract> {
    if !matches!(
        control.algorithm,
        fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb
            | fullmag_ir::RelaxationAlgorithmIR::NonlinearCg
            | fullmag_ir::RelaxationAlgorithmIR::TangentPlaneImplicit
    ) || provenance.resolved_energy_minimizer.as_deref() != Some(control.algorithm.as_str())
        || provenance.energy_minimizer_realization.as_deref()
            != crate::relaxation::native_direct_minimizer_realization(
                control.algorithm,
                provenance.execution_engine == "fem_native_gpu",
            )
    {
        return None;
    }
    Some(FemEnergyWeightedArmijoContract {
        metric: "mu0_ms_fem_lumped_volume",
        gradient_metric: "mu0_ms_fem_lumped_volume",
        gradient_units: "A/m",
        search_direction_units: "A/m",
        line_search_step_units: "m/A",
        armijo_slope_units: "J A/m",
        armijo_decrement_units: "J",
        armijo_derivative_units: "J",
    })
}

fn fem_gpu_relaxation_qualification_metadata(
    plan: &fullmag_ir::ExecutionPlanIR,
    provenance: &crate::types::ExecutionProvenance,
    executed: &ExecutedRun,
) -> serde_json::Value {
    let BackendPlanIR::Fem(fem) = &plan.backend_plan else {
        return serde_json::Value::Null;
    };
    if provenance.execution_engine != "fem_native_gpu" {
        return serde_json::Value::Null;
    }
    let Some(control) = fem.relaxation.as_ref() else {
        return serde_json::Value::Null;
    };
    let derivative_contract = fem_energy_weighted_armijo_contract(control, provenance);
    let (
        realization,
        time_integrator,
        precession_policy,
        rhs_policy,
        metric,
        gradient_policy,
        line_search,
        direction_update,
        step_update,
    ) = match control.algorithm {
        fullmag_ir::RelaxationAlgorithmIR::LlgOverdamped => (
            provenance.energy_minimizer_realization.clone().or_else(|| {
                Some(crate::relaxation::NATIVE_LLG_TIME_INTEGRATOR_REALIZATION.to_string())
            }),
            provenance.resolved_integrator.clone(),
            Some("disabled_pure_damping".to_string()),
            Some("llg_overdamped_rhs".to_string()),
            None,
            None,
            None,
            None,
            None,
        ),
        fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb => (
            provenance.energy_minimizer_realization.clone(),
            None,
            None,
            None,
            derivative_contract.map(|contract| contract.metric.to_string()),
            Some("device_tangent_gradient".to_string()),
            Some("native_armijo_backtracking_bb1_bb2".to_string()),
            None,
            Some("alternating_bb1_bb2".to_string()),
        ),
        fullmag_ir::RelaxationAlgorithmIR::NonlinearCg => (
            provenance.energy_minimizer_realization.clone(),
            None,
            None,
            None,
            derivative_contract.map(|contract| contract.metric.to_string()),
            Some("device_tangent_gradient".to_string()),
            Some("native_armijo_backtracking_pr_plus_restart".to_string()),
            Some("polak_ribiere_plus_projected_restart".to_string()),
            None,
        ),
        _ => return serde_json::Value::Null,
    };
    let Some(last) = executed.result.steps.last() else {
        return serde_json::Value::Null;
    };
    let completion = executed.result.completion.as_ref();

    let metadata = FemGpuRelaxationQualificationMetadata {
        schema_version: "fem_gpu_relaxation_qualification.v1".to_string(),
        relaxation_algorithm: Some(control.algorithm.as_str().to_string()),
        algorithm_policy: FemGpuRelaxationAlgorithmPolicyMetadata {
            realization,
            time_integrator,
            precession_policy,
            rhs_policy,
            metric,
            gradient_metric: derivative_contract
                .map(|contract| contract.gradient_metric.to_string()),
            gradient_units: derivative_contract.map(|contract| contract.gradient_units.to_string()),
            search_direction_units: derivative_contract
                .map(|contract| contract.search_direction_units.to_string()),
            line_search_step_units: derivative_contract
                .map(|contract| contract.line_search_step_units.to_string()),
            armijo_slope_units: derivative_contract
                .map(|contract| contract.armijo_slope_units.to_string()),
            armijo_decrement_units: derivative_contract
                .map(|contract| contract.armijo_decrement_units.to_string()),
            armijo_derivative_units: derivative_contract
                .map(|contract| contract.armijo_derivative_units.to_string()),
            gradient_policy,
            line_search,
            direction_update,
            step_update,
        },
        device_policy: FemGpuRelaxationDevicePolicyMetadata {
            execution_mode: provenance.fem_execution_mode.clone(),
            qualification_status: provenance.fem_gpu_qualification_status.clone(),
            data_residency: provenance.fem_data_residency.clone(),
            exchange_operator_mode: provenance.fem_exchange_operator_mode.clone(),
            demag_operator_mode: provenance.fem_demag_operator_mode.clone(),
            uses_cuda_kernels: provenance.uses_cuda_kernels,
            uses_gpu_poisson: provenance.uses_gpu_poisson,
            hot_loop_exchange_host_sync_count: provenance.hot_loop_exchange_host_sync_count,
            hot_loop_compute_host_sync_count: provenance.hot_loop_compute_host_sync_count,
            hot_loop_control_scalar_host_sync_count: provenance
                .hot_loop_control_scalar_host_sync_count,
        },
        converged: completion.is_some_and(|entry| entry.converged),
        stop_reason: completion
            .and_then(|entry| entry.reason.as_ref())
            .map(stage_stop_reason_as_str)
            .map(str::to_string),
        stop_metric_kind: completion.and_then(|entry| entry.metric),
        stop_metric_unit: completion
            .and_then(|entry| entry.metric_unit())
            .map(str::to_string),
        stop_metric_name: completion.and_then(|entry| entry.metric_name.clone()),
        stop_metric_value: completion.and_then(|entry| entry.metric_value),
        stop_threshold: completion.and_then(|entry| entry.threshold),
        final_energy_terms_j: FemCpuRelaxationEnergyTerms {
            e_ex: last.e_ex,
            e_demag: last.e_demag,
            e_ext: last.e_ext,
            e_drive: last.e_drive,
            e_ani: last.e_ani,
            e_dmi: last.e_dmi,
            e_total: last.e_total,
        },
        final_torque_apm: last.max_torque_Apm,
        final_torque_t: last.max_torque_T,
        norm_defect: magnetization_norm_defect_for_fem_plan(
            fem,
            &executed.result.final_magnetization,
        ),
        executed_steps: last.step,
    };
    serde_json::to_value(metadata).unwrap_or(serde_json::Value::Null)
}

fn json_string(value: &serde_json::Value, key: &str) -> Option<String> {
    value
        .get(key)
        .and_then(serde_json::Value::as_str)
        .map(str::to_string)
}

fn json_f64(value: &serde_json::Value, key: &str) -> Option<f64> {
    value.get(key).and_then(serde_json::Value::as_f64)
}

fn json_u32(value: &serde_json::Value, key: &str) -> Option<u32> {
    value
        .get(key)
        .and_then(serde_json::Value::as_u64)
        .and_then(|raw| u32::try_from(raw).ok())
}

fn json_i32(value: &serde_json::Value, key: &str) -> Option<i32> {
    value
        .get(key)
        .and_then(serde_json::Value::as_i64)
        .and_then(|raw| i32::try_from(raw).ok())
}

fn json_bool(value: &serde_json::Value, key: &str) -> Option<bool> {
    value.get(key).and_then(serde_json::Value::as_bool)
}

fn demag_timings_ns(value: &serde_json::Value) -> Option<FemCpuRelaxationDemagTimingsNs> {
    let timings = value.get("timings_ns")?;
    Some(FemCpuRelaxationDemagTimingsNs {
        assemble: timings.get("assemble")?.as_u64()?,
        solve: timings.get("solve")?.as_u64()?,
        solver_setup: timings.get("solver_setup")?.as_u64()?,
        solver_apply: timings.get("solver_apply")?.as_u64()?,
        recover: timings.get("recover")?.as_u64()?,
        energy: timings.get("energy")?.as_u64()?,
        total: timings.get("total")?.as_u64()?,
    })
}

fn stage_stop_reason_as_str(reason: &fullmag_ir::StageStopReason) -> &'static str {
    match reason {
        fullmag_ir::StageStopReason::Torque => "torque",
        fullmag_ir::StageStopReason::Energy => "energy",
        fullmag_ir::StageStopReason::MaxSteps => "max_steps",
        fullmag_ir::StageStopReason::MaxPseudotime => "max_pseudotime",
        fullmag_ir::StageStopReason::MaxPhysicalTime => "max_physical_time",
        fullmag_ir::StageStopReason::UserCancelled => "user_cancelled",
        fullmag_ir::StageStopReason::BackendError => "backend_error",
        fullmag_ir::StageStopReason::Gradient => "gradient",
    }
}

fn fem_physics_terms(fem: &fullmag_ir::FemPlanIR) -> Vec<String> {
    let mut terms = Vec::new();
    if fem.enable_exchange {
        terms.push("exchange".to_string());
    }
    if fem.enable_demag {
        terms.push("demag".to_string());
    }
    if fem.material.uniaxial_anisotropy.is_some() {
        terms.push("anisotropy_uniaxial".to_string());
    }
    if fem.material.cubic_anisotropy_kc1.is_some()
        || fem.material.cubic_anisotropy_kc2.is_some()
        || fem.material.cubic_anisotropy_kc3.is_some()
    {
        terms.push("anisotropy_cubic".to_string());
    }
    terms
}

pub(crate) fn solver_mesh_signature(mesh: &fullmag_ir::MeshIR) -> String {
    let payload = serde_json::json!({
        "nodes": mesh.nodes,
        "cells": mesh.cells,
        "element_markers": mesh.element_markers,
        "facets": mesh.facets,
        "boundary_markers": mesh.boundary_markers,
        "periodic_boundary_pairs": mesh.periodic_boundary_pairs,
        "periodic_node_pairs": mesh.periodic_node_pairs,
    });
    let encoded = serde_json::to_vec(&payload).unwrap_or_default();
    let digest = Sha256::digest(encoded);
    digest.iter().map(|byte| format!("{:02x}", byte)).collect()
}

fn magnetization_norm_defect_for_fem_plan(fem: &fullmag_ir::FemPlanIR, values: &[[f64; 3]]) -> f64 {
    let magnetic_nodes = fem
        .mesh_parts
        .iter()
        .filter(|part| part.role == fullmag_ir::FemMeshPartRole::MagneticObject)
        .flat_map(|part| fem_part_magnetic_node_indices_for_norm_defect(fem, part))
        .collect::<BTreeSet<_>>();
    if magnetic_nodes.is_empty() {
        return magnetization_norm_defect(values.iter());
    }
    magnetization_norm_defect(
        magnetic_nodes
            .into_iter()
            .filter_map(|index| values.get(index)),
    )
}

fn fem_part_magnetic_node_indices_for_norm_defect(
    fem: &fullmag_ir::FemPlanIR,
    part: &fullmag_ir::FemMeshPartIR,
) -> Vec<usize> {
    let mut nodes = BTreeSet::new();
    nodes.extend(part.node_indices.iter().map(|index| *index as usize));

    if nodes.is_empty() {
        if let fullmag_ir::FemMeshPartSelector::NodeRange { start, count } = &part.node_selector {
            let start = *start as usize;
            let end = start
                .saturating_add(*count as usize)
                .min(fem.mesh.nodes.len());
            nodes.extend(start..end);
        }
    }

    nodes
        .into_iter()
        .filter(|index| *index < fem.mesh.nodes.len())
        .collect()
}

fn magnetization_norm_defect<'a>(values: impl Iterator<Item = &'a [f64; 3]>) -> f64 {
    values
        .map(|m| {
            let norm = (m[0] * m[0] + m[1] * m[1] + m[2] * m[2]).sqrt();
            (norm - 1.0).abs()
        })
        .fold(0.0, f64::max)
}

#[derive(Debug, Clone)]
pub(crate) struct FieldArtifactContext {
    pub problem_name: String,
    pub ir_version: String,
    pub source_hash: Option<String>,
    pub execution_mode: fullmag_ir::ExecutionMode,
    pub layout: serde_json::Value,
    pub magnetization_field_semantics: Result<Option<FemP1MagnetizationFieldSemantics>, String>,
    pub execution_resolution: Option<FinalExecutionResolutionProvenance>,
}

pub(crate) fn build_field_context(
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
) -> FieldArtifactContext {
    let magnetization_field_semantics = fem_p1_magnetization_field_semantics(plan);
    FieldArtifactContext {
        problem_name: problem.problem_meta.name.clone(),
        ir_version: problem.ir_version.clone(),
        source_hash: problem.problem_meta.source_hash.clone(),
        execution_mode: plan.common.execution_mode,
        layout: field_layout(plan),
        magnetization_field_semantics,
        execution_resolution: None,
    }
}

/// Build the typed producer envelope for the serial FEM H1/P1 magnetization
/// field.  The envelope is intentionally limited to the ordinary FEM plan:
/// eigen, frequency-response, FDM, and higher-order FEM plans remain
/// unqualified until their own field producers provide an equivalent
/// contract.
pub fn fem_p1_magnetization_field_semantics(
    plan: &fullmag_ir::ExecutionPlanIR,
) -> Result<Option<FemP1MagnetizationFieldSemantics>, String> {
    let BackendPlanIR::Fem(fem) = &plan.backend_plan else {
        return Ok(None);
    };
    if fem.fe_order != 1 {
        return Ok(None);
    }

    // The preview adapter has compatibility handling for incomplete markers;
    // a quantitative producer must supply the same validated runtime mesh.
    fullmag_ir::validate_mesh_for_execution(&fem.mesh)
        .map_err(|errors| errors.join("; "))?;
    let normalized_markers = normalized_runtime_element_markers(fem)
        .map_err(|error| error.message)?;
    let active_node_mask = crate::preview::mesh_quantity_active_mask_with_element_markers(
        "m",
        &fem.mesh,
        &normalized_markers,
    )
    .ok_or_else(|| "FEM magnetization active support is unavailable".to_string())?;
    // Preserve the accepted source mesh identity; runtime marker normalization
    // only supplies the support mask used by this artifact.
    let topology_fingerprint = fem.mesh.topology_fingerprint_v6();
    FemP1MagnetizationFieldSemantics::new(
        &topology_fingerprint,
        fem.mesh.nodes.len(),
        active_node_mask,
    )
    .map(Some)
    .map_err(|error| error.to_string())
}

fn collect_streamed_provenance_files(
    directory: &Path,
    files: &mut Vec<std::path::PathBuf>,
) -> std::io::Result<()> {
    if !directory.is_dir() {
        return Ok(());
    }
    for entry in fs::read_dir(directory)? {
        let path = entry?.path();
        if path.is_dir() {
            collect_streamed_provenance_files(&path, files)?;
            continue;
        }
        let is_zarr_attributes = path.file_name().and_then(|name| name.to_str()) == Some(".zattrs");
        if is_zarr_attributes
            || path.extension().and_then(|extension| extension.to_str()) == Some("json")
        {
            files.push(path);
        }
    }
    Ok(())
}

/// Complete provenance for field artifacts written by the asynchronous
/// pipeline before the final execution resolution was known.
pub(crate) fn finalize_streamed_artifact_provenance(
    output_dir: &Path,
    resolution: &FinalExecutionResolutionProvenance,
) -> std::io::Result<()> {
    let fields_dir = output_dir.join("fields");
    let mut files = Vec::new();
    collect_streamed_provenance_files(&fields_dir, &mut files)?;
    finalize_provenance_files(&files, resolution, false)
}

/// Finalize metadata emitted by a stage-autosave writer.  Unlike regular
/// streamed field output, autosave metadata is spread across the root
/// `.zattrs`, stage manifests, continuous-index metadata, and field metadata;
/// every JSON metadata object in that tree therefore receives the same final
/// execution resolution.
pub(crate) fn finalize_stage_autosave_provenance(
    autosave_root: &Path,
    resolution: &FinalExecutionResolutionProvenance,
) -> std::io::Result<()> {
    let mut files = Vec::new();
    collect_streamed_provenance_files(autosave_root, &mut files)?;
    finalize_provenance_files(&files, resolution, true)
}

fn finalize_provenance_files(
    files: &[std::path::PathBuf],
    resolution: &FinalExecutionResolutionProvenance,
    require_metadata_provenance: bool,
) -> std::io::Result<()> {
    let serialized_resolution = serde_json::to_value(resolution)
        .expect("FinalExecutionResolutionProvenance must serialize");
    for path in files {
        let bytes = fs::read(&path)?;
        let mut value: serde_json::Value = serde_json::from_slice(&bytes).map_err(|error| {
            Error::new(
                ErrorKind::InvalidData,
                format!(
                    "streamed field artifact '{}' is invalid JSON: {error}",
                    path.display()
                ),
            )
        })?;
        let mut changed = false;
        if require_metadata_provenance {
            let object = value.as_object_mut().ok_or_else(|| {
                Error::new(
                    ErrorKind::InvalidData,
                    format!(
                        "stage-autosave metadata '{}' must be a JSON object",
                        path.display()
                    ),
                )
            })?;
            let provenance = object
                .entry("provenance".to_string())
                .or_insert_with(|| serde_json::json!({}));
            let provenance = provenance.as_object_mut().ok_or_else(|| {
                Error::new(
                    ErrorKind::InvalidData,
                    format!(
                        "stage-autosave metadata '{}' has non-object provenance",
                        path.display()
                    ),
                )
            })?;
            provenance.insert(
                "execution_resolution".to_string(),
                serialized_resolution.clone(),
            );
            changed = true;
        } else if let Some(provenance) = value
            .get_mut("provenance")
            .and_then(|value| value.as_object_mut())
        {
            provenance.insert(
                "execution_resolution".to_string(),
                serialized_resolution.clone(),
            );
            changed = true;
        }
        if value
            .get("schema_version")
            .and_then(serde_json::Value::as_str)
            == Some("fdm_multilayer_field_manifest.v1")
        {
            value
                .as_object_mut()
                .expect("multilayer manifest must be an object")
                .insert(
                    "provenance".to_string(),
                    serde_json::json!({
                        "execution_resolution": serialized_resolution.clone(),
                    }),
                );
            changed = true;
        }
        if changed {
            fs::write(path, serde_json::to_vec_pretty(&value)?)?;
        }
    }
    Ok(())
}

fn frequency_publication_owner(
    problem: &fullmag_ir::ProblemIR,
) -> std::io::Result<Option<crate::artifact_generation::PublicationOwner>> {
    let metadata = &problem.problem_meta.runtime_metadata;
    let owner_value = |key: &str| {
        metadata
            .get(key)
            .and_then(serde_json::Value::as_str)
            .filter(|value| !value.trim().is_empty())
    };
    match (
        owner_value("producer_run_id"),
        owner_value("producer_stage_id"),
        owner_value("producer_stage_kind"),
    ) {
        (Some(run_id), Some(stage_id), Some(stage_kind)) => {
            Ok(Some(crate::artifact_generation::PublicationOwner {
                run_id: run_id.into(),
                stage_id: stage_id.into(),
                stage_kind: stage_kind.into(),
            }))
        }
        (None, None, None)
            if [
                "producer_run_id",
                "producer_stage_id",
                "producer_stage_kind",
            ]
            .iter()
            .all(|key| !metadata.contains_key(*key)) =>
        {
            Ok(None)
        }
        _ => Err(Error::new(
            ErrorKind::InvalidData,
            "incomplete frequency-domain publication owner",
        )),
    }
}

fn validate_immutable_generation_references(
    member_bytes: &[(String, Vec<u8>)],
) -> std::io::Result<()> {
    let member_paths = member_bytes
        .iter()
        .map(|(path, _)| path.as_str())
        .collect::<BTreeSet<_>>();
    let member_payload = |relative: &str| {
        member_bytes
            .iter()
            .find(|(path, _)| path == relative)
            .map(|(_, bytes)| bytes.as_slice())
    };
    let require_member = |relative: &str, context: &str| -> std::io::Result<()> {
        if relative.trim().is_empty() || !member_paths.contains(relative) {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!("{context} references missing immutable generation member '{relative}'"),
            ));
        }
        Ok(())
    };
    let require_safe_store_path = |relative: &str, context: &str| -> std::io::Result<()> {
        if relative.trim().is_empty()
            || relative.starts_with('/')
            || relative.contains('\\')
            || relative
                .split('/')
                .any(|component| component.is_empty() || matches!(component, "." | ".."))
        {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!("{context} is not a canonical relative store path: '{relative}'"),
            ));
        }
        Ok(())
    };

    let metadata_bytes = member_payload("metadata.json").ok_or_else(|| {
        Error::new(
            ErrorKind::InvalidData,
            "immutable FEM eigen publication is missing metadata.json",
        )
    })?;
    let metadata: serde_json::Value = serde_json::from_slice(metadata_bytes).map_err(|error| {
        Error::new(
            ErrorKind::InvalidData,
            format!("immutable FEM eigen metadata is invalid JSON: {error}"),
        )
    })?;
    let assets = metadata
        .get("material_field_assets")
        .and_then(serde_json::Value::as_array)
        .ok_or_else(|| {
            Error::new(
                ErrorKind::InvalidData,
                "immutable FEM eigen metadata is missing material_field_assets",
            )
        })?;
    for (index, asset) in assets.iter().enumerate() {
        let asset = asset.as_object().ok_or_else(|| {
            Error::new(
                ErrorKind::InvalidData,
                format!("metadata.material_field_assets[{index}] must be an object"),
            )
        })?;
        match asset.get("artifact_path") {
            None | Some(serde_json::Value::Null) => {}
            Some(serde_json::Value::String(relative)) => {
                require_member(relative, &format!("metadata.material_field_assets[{index}]"))?;
            }
            Some(_) => {
                return Err(Error::new(
                    ErrorKind::InvalidData,
                    format!(
                        "metadata.material_field_assets[{index}].artifact_path must be a path or null"
                    ),
                ));
            }
        }
    }

    if let Some(manifest_bytes) = member_payload("frequency_domain/manifest.v1.json") {
        let manifest: serde_json::Value =
            serde_json::from_slice(manifest_bytes).map_err(|error| {
                Error::new(
                    ErrorKind::InvalidData,
                    format!("immutable frequency-domain manifest is invalid JSON: {error}"),
                )
            })?;
        let artifacts = manifest
            .get("artifacts")
            .and_then(serde_json::Value::as_object)
            .ok_or_else(|| {
                Error::new(
                    ErrorKind::InvalidData,
                    "immutable frequency-domain manifest is missing artifacts object",
                )
            })?;
        let zarr_store_path = match artifacts.get("mode_field_zarr_store_path") {
            None | Some(serde_json::Value::Null) => None,
            Some(serde_json::Value::String(relative)) => {
                require_safe_store_path(relative, "manifest.artifacts.mode_field_zarr_store_path")?;
                Some(relative.as_str())
            }
            Some(_) => {
                return Err(Error::new(
                    ErrorKind::InvalidData,
                    "manifest.artifacts.mode_field_zarr_store_path must be a directory path or null",
                ));
            }
        };
        for (name, value) in artifacts {
            if name == "mode_field_zarr_store_path" {
                // This field identifies a Zarr directory, not a single member.
                // Its concrete closure is checked below against the supplied bytes.
                continue;
            }
            if name.ends_with("_path") {
                match value {
                    serde_json::Value::Null => {}
                    serde_json::Value::String(relative) => {
                        require_member(relative, &format!("manifest.artifacts.{name}"))?;
                    }
                    _ => {
                        return Err(Error::new(
                            ErrorKind::InvalidData,
                            format!("manifest.artifacts.{name} must be a path or null"),
                        ));
                    }
                }
            } else if name.ends_with("_paths") {
                match value {
                    serde_json::Value::Null => {}
                    serde_json::Value::Array(paths) => {
                        for (index, path) in paths.iter().enumerate() {
                            let relative = path.as_str().ok_or_else(|| {
                                Error::new(
                                    ErrorKind::InvalidData,
                                    format!("manifest.artifacts.{name}[{index}] must be a path"),
                                )
                            })?;
                            require_member(
                                relative,
                                &format!("manifest.artifacts.{name}[{index}]"),
                            )?;
                        }
                    }
                    _ => {
                        return Err(Error::new(
                            ErrorKind::InvalidData,
                            format!("manifest.artifacts.{name} must be a path list or null"),
                        ));
                    }
                }
            }
        }

        if let Some(store_path) = zarr_store_path {
            for suffix in [".zgroup", ".zattrs"] {
                let relative = format!("{store_path}/{suffix}");
                require_member(
                    &relative,
                    "manifest.artifacts.mode_field_zarr_store_path",
                )?;
            }
            let mode_metadata_paths = artifacts
                .get("mode_metadata_paths")
                .and_then(serde_json::Value::as_array)
                .ok_or_else(|| {
                    Error::new(
                        ErrorKind::InvalidData,
                        "Zarr mode-field store requires manifest.artifacts.mode_metadata_paths",
                    )
                })?;
            let store_prefix = format!("{store_path}/");
            for (index, mode_path) in mode_metadata_paths.iter().enumerate() {
                let mode_path = mode_path.as_str().ok_or_else(|| {
                    Error::new(
                        ErrorKind::InvalidData,
                        format!("manifest.artifacts.mode_metadata_paths[{index}] must be a path"),
                    )
                })?;
                let mode_bytes = member_payload(mode_path).ok_or_else(|| {
                    Error::new(
                        ErrorKind::InvalidData,
                        format!("mode metadata member '{mode_path}' disappeared from generation"),
                    )
                })?;
                let mode: serde_json::Value = serde_json::from_slice(mode_bytes).map_err(|error| {
                    Error::new(
                        ErrorKind::InvalidData,
                        format!("immutable mode metadata '{mode_path}' is invalid JSON: {error}"),
                    )
                })?;
                if mode.get("storage_format").and_then(serde_json::Value::as_str) != Some("zarr")
                    || mode.get("zarr_store_path").and_then(serde_json::Value::as_str)
                        != Some(store_path)
                {
                    return Err(Error::new(
                        ErrorKind::InvalidData,
                        format!("mode metadata '{mode_path}' does not bind to the manifest Zarr store"),
                    ));
                }
                let array_path = mode
                    .get("zarr_array_path")
                    .and_then(serde_json::Value::as_str)
                    .ok_or_else(|| {
                        Error::new(
                            ErrorKind::InvalidData,
                            format!("mode metadata '{mode_path}' is missing zarr_array_path"),
                        )
                    })?;
                let array_relative = array_path.strip_prefix(&store_prefix).ok_or_else(|| {
                    Error::new(
                        ErrorKind::InvalidData,
                        format!("mode metadata '{mode_path}' array path is outside its Zarr store"),
                    )
                })?;
                let array_components = array_relative.split('/').collect::<Vec<_>>();
                if array_components.is_empty()
                    || array_components
                        .iter()
                        .any(|component| component.is_empty() || matches!(*component, "." | "..") || component.contains('\\'))
                {
                    return Err(Error::new(
                        ErrorKind::InvalidData,
                        format!("mode metadata '{mode_path}' has a non-canonical Zarr array path"),
                    ));
                }
                let mut group_path = store_path.to_string();
                for component in array_components.iter().take(array_components.len() - 1) {
                    group_path.push('/');
                    group_path.push_str(component);
                    require_member(
                        &format!("{group_path}/.zgroup"),
                        &format!("mode metadata '{mode_path}' Zarr group"),
                    )?;
                }
                for suffix in [".zarray", ".zattrs"] {
                    let relative = format!("{array_path}/{suffix}");
                    require_member(&relative, &format!("mode metadata '{mode_path}'"))?;
                }
                let chunk_path = mode
                    .get("zarr_chunk_path")
                    .and_then(serde_json::Value::as_str)
                    .ok_or_else(|| {
                        Error::new(
                            ErrorKind::InvalidData,
                            format!("mode metadata '{mode_path}' is missing zarr_chunk_path"),
                        )
                    })?;
                if !chunk_path.starts_with(&format!("{array_path}/")) {
                    return Err(Error::new(
                        ErrorKind::InvalidData,
                        format!("mode metadata '{mode_path}' chunk path is outside its Zarr array"),
                    ));
                }
                require_member(chunk_path, &format!("mode metadata '{mode_path}'"))?;
                let compatibility_path = mode
                    .get("compatibility_binary_payload_path")
                    .and_then(serde_json::Value::as_str)
                    .ok_or_else(|| {
                        Error::new(
                            ErrorKind::InvalidData,
                            format!("mode metadata '{mode_path}' is missing compatibility_binary_payload_path"),
                        )
                    })?;
                require_member(compatibility_path, &format!("mode metadata '{mode_path}'"))?;
            }
        }
    }
    Ok(())
}
pub(crate) fn write_artifacts(
    output_dir: &Path,
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
    executed: &ExecutedRun,
    streamed: Option<&ArtifactPipelineSummary>,
) -> std::io::Result<()> {
    // Serialize final writes before any member is changed. No stale lease is
    // automatically removed: recovery requires checking its active owner.
    let has_frequency_generation_artifacts = executed.auxiliary_artifacts.iter().any(|artifact| {
        artifact.relative_path.starts_with("eigen/") || artifact.relative_path.starts_with("response/")
    });
    let immutable_fem_eigen_publication = matches!(
        &plan.backend_plan,
        BackendPlanIR::FemEigen(_)
    ) && executed
        .auxiliary_artifacts
        .iter()
        .any(|artifact| artifact.relative_path.starts_with("eigen/"));
    let immutable_producer = if immutable_fem_eigen_publication {
        frequency_publication_owner(problem)?
    } else {
        None
    };
    let frequency_publication_lease = if has_frequency_generation_artifacts {
        if !immutable_fem_eigen_publication {
            // Other artifact producers remain on the mutable v1 path. Do not
            // let them shadow a v2 selector.
            crate::artifact_generation::ensure_legacy_publication_allowed(output_dir)?;
        }
        Some(crate::artifact_generation::PublicationLease::acquire(output_dir)?)
    } else {
        None
    };
    let diagnostic_steps = solver_diagnostic_steps(executed);
    let accepted_steps = diagnostic_steps
        .as_deref()
        .unwrap_or(&executed.result.steps);
    let sampling_resolution = problem
        .problem_meta
        .runtime_metadata
        .get("sampling_resolution");
    let mut field_context = build_field_context(problem, plan);
    let requested_execution = requested_execution_metadata(problem);
    let runtime_threading = runtime_threading_summary(problem);
    let execution_provenance =
        provenance_with_runtime_threading(problem, &executed.provenance, accepted_steps);
    let demag_runtime = demag_runtime_metadata(plan, &execution_provenance, accepted_steps);
    let fem_cpu_relaxation_qualification = fem_cpu_relaxation_qualification_metadata(
        plan,
        &execution_provenance,
        &demag_runtime,
        executed,
    );
    let fem_gpu_relaxation_qualification =
        fem_gpu_relaxation_qualification_metadata(plan, &execution_provenance, executed);
    let periodic_antidot_relaxation = problem
        .problem_meta
        .runtime_metadata
        .get("periodic_antidot_relaxation")
        .cloned()
        .unwrap_or(serde_json::Value::Null);
    let mesh_metadata = mesh_runtime_metadata(plan);
    let region_realization_revisions = region_realization_revisions_metadata(problem);
    let prepared_immutable_material_artifacts = if immutable_fem_eigen_publication {
        Some(build_material_field_artifacts(plan)?)
    } else {
        None
    };
    let material_field_assets = match prepared_immutable_material_artifacts.as_ref() {
        Some(prepared) => prepared.metadata_assets.clone(),
        None => write_material_field_artifacts(output_dir, plan)?,
    };
    validate_execution_provenance_for_artifacts(plan, &execution_provenance)?;
    let execution_resolution =
        final_execution_resolution_provenance(problem, plan, &execution_provenance)?;
    field_context.execution_resolution = Some(execution_resolution.clone());
    fs::create_dir_all(output_dir)?;
    finalize_streamed_artifact_provenance(output_dir, &execution_resolution)?;
    if let Some(autosave_root) = streamed.and_then(|summary| summary.autosave_root.as_deref()) {
        if autosave_root != output_dir {
            finalize_stage_autosave_provenance(autosave_root, &execution_resolution)?;
        }
    }
    write_sampling_resolution_artifact(output_dir, sampling_resolution)?;
    let physics_graph_artifact = physics_graph_provenance_artifact(problem, plan, Some(executed))?;
    let graph_provenance = physics_graph_artifact
        .as_ref()
        .map(|artifact| {
            serde_json::from_slice(&artifact.bytes).map_err(|error| {
                Error::new(
                    ErrorKind::InvalidData,
                    format!("physics graph provenance artifact is invalid JSON: {error}"),
                )
            })
        })
        .transpose()?;
    let thermal = thermal_execution_provenance(plan, accepted_steps, &execution_provenance);
    let spin_torque_provenance = fem_spin_torque_provenance(problem, plan, &execution_provenance);
    let fdm_multilayer_transfer = fdm_multilayer_transfer_realization(plan, &execution_provenance);
    let metadata_execution_provenance = MetadataExecutionProvenance {
        execution: &execution_provenance,
        fdm_multilayer_transfer: fdm_multilayer_transfer.as_ref(),
        execution_resolution: &execution_resolution,
        physics_graph: graph_provenance.as_ref(),
        thermal: thermal.as_ref(),
        spin_torque: spin_torque_provenance.as_ref(),
    };
    let artifact_pipeline = streamed.map_or(serde_json::Value::Null, |summary| {
        serde_json::json!({
            "scalar_rows_written": summary.scalar_rows_written,
            "field_snapshots_written": summary.field_snapshots_written,
            "writer_jobs_completed": summary.writer_jobs_completed,
            "artifact_writer_job_wall_time_ns": summary.artifact_writer_job_wall_time_ns,
            "scalar_row_writer_wall_time_ns": summary.scalar_row_writer_wall_time_ns,
            "field_snapshot_writer_wall_time_ns": summary.field_snapshot_writer_wall_time_ns,
            "native_field_snapshot_writer_wall_time_ns": summary.native_field_snapshot_writer_wall_time_ns,
        })
    });
    let metadata = RunMetadata {
        problem,
        plan,
        requested_execution: &requested_execution,
        field_context: &field_context,
        mesh: &mesh_metadata,
        region_realization_revisions: &region_realization_revisions,
        periodic_antidot_relaxation: &periodic_antidot_relaxation,
        execution_provenance: &metadata_execution_provenance,
        runtime_threading: &runtime_threading,
        demag_runtime: &demag_runtime,
        fem_cpu_relaxation_qualification: &fem_cpu_relaxation_qualification,
        fem_gpu_relaxation_qualification: &fem_gpu_relaxation_qualification,
        executed,
        accepted_solver_steps: accepted_steps.len(),
        artifact_pipeline: &artifact_pipeline,
        material_field_assets: &material_field_assets,
        sampling_resolution,
    };
    let metadata_path = output_dir.join("metadata.json");
    let metadata_bytes = serialize_run_metadata(&metadata)?;
    if !immutable_fem_eigen_publication {
        let mut metadata_file = BufWriter::new(fs::File::create(&metadata_path)?);
        metadata_file.write_all(&metadata_bytes)?;
        metadata_file.flush()?;
    }

    if let Some(spin_torque) = spin_torque_provenance {
        let path = output_dir.join("physics/spin_torque_provenance.v1.json");
        fs::create_dir_all(path.parent().expect("spin-torque artifact has parent"))?;
        fs::write(path, serde_json::to_vec_pretty(&spin_torque).unwrap())?;
    }

    if streamed.is_none_or(|summary| summary.scalar_rows_written == 0) {
        write_scalars_csv(&output_dir.join("scalars.csv"), &executed.result.steps)?;
    }
    write_table_autosave_artifacts(output_dir, problem, &executed.result.steps)?;
    if should_write_solver_diagnostics(plan, execution_provenance.timestep_policy.as_ref()) {
        write_solver_diagnostics_artifacts(
            output_dir,
            plan,
            execution_provenance.timestep_policy.as_ref(),
            accepted_steps,
        )?;
    }

    write_field_file(
        &output_dir.join("m_initial.json"),
        &field_context,
        &execution_provenance,
        "m",
        0,
        0.0,
        0.0,
        &executed.initial_magnetization,
    )?;

    let mut final_stats = accepted_steps.last().cloned().unwrap_or(StepStats {
        step: 0,
        time: 0.0,
        dt: 0.0,
        e_ex: 0.0,
        e_demag: 0.0,
        e_ext: 0.0,
        e_ani: 0.0,
        e_total: 0.0,
        max_dm_dt: 0.0,
        max_h_eff: 0.0,
        max_h_demag: 0.0,
        wall_time_ns: 0,
        ..StepStats::default()
    });
    let final_snapshot_receipt = final_native_snapshot_receipt(
        &field_context,
        executed,
        &mut final_stats,
    )?;
    let final_node_map = final_native_node_map(executed, final_snapshot_receipt.as_ref())?;
    write_field_file_with_native_snapshot(
        &output_dir.join("m_final.json"),
        &field_context,
        &execution_provenance,
        "m",
        final_stats.step,
        final_stats.time,
        final_stats.dt,
        &executed.result.final_magnetization,
        final_snapshot_receipt.as_ref(),
        final_node_map.as_ref(),
    )?;

    if streamed.is_none() {
        let fields_dir = output_dir.join("fields");
        let mut frames_index = crate::frames_index::FramesIndexWriter::new(output_dir, None);
        for snapshot in &executed.field_snapshots {
            write_field_snapshot_artifact(
                &fields_dir,
                &field_context,
                &execution_provenance,
                snapshot,
            )?;
            let relative =
                crate::frames_index::snapshot_relative_path(&snapshot.name, snapshot.step, true);
            let single_file = output_dir.join(&relative);
            let bytes = fs::metadata(&single_file).ok().map(|meta| meta.len());
            let path = if single_file.is_file() {
                relative
            } else {
                // Multilayer snapshots are one file per layer under the observable folder.
                format!("fields/{}", snapshot.name)
            };
            frames_index
                .record(&snapshot.name, snapshot.step, snapshot.time, path, bytes)
                .map_err(|error| std::io::Error::new(std::io::ErrorKind::Other, error))?;
        }
        frames_index
            .finish()
            .map_err(|error| std::io::Error::new(std::io::ErrorKind::Other, error))?;
    }

    let mut auxiliary_artifacts = executed.auxiliary_artifacts.clone();
    if let Some(producer_provenance) =
        fem_relaxation_producer_provenance_artifact(problem, plan, executed)?
    {
        if auxiliary_artifacts
            .iter()
            .any(|artifact| artifact.relative_path == producer_provenance.relative_path)
        {
            return Err(Error::new(
                ErrorKind::InvalidData,
                "duplicate FEM relaxation producer provenance sidecar",
            ));
        }
        auxiliary_artifacts.push(producer_provenance);
    }
    if matches!(
        &plan.backend_plan,
        fullmag_ir::BackendPlanIR::FdmMultilayer(_)
    ) {
        let observation_artifacts =
            crate::fdm::cpu::airbox_observation::materialize_airbox_observation(
                problem,
                match &plan.backend_plan {
                    fullmag_ir::BackendPlanIR::FdmMultilayer(multilayer) => multilayer,
                    _ => unreachable!("multilayer plan was checked above"),
                },
                executed,
            )
            .map_err(|error| {
                std::io::Error::new(
                    std::io::ErrorKind::InvalidData,
                    format!("FDM Airbox observation carrier: {error}"),
                )
            })?;
        auxiliary_artifacts.extend(observation_artifacts);
    }
    auxiliary_artifacts.extend(crate::fdm::artifacts::grid_certificate_artifacts(plan));
    auxiliary_artifacts.extend(crate::fdm::artifacts::pbc_provenance_artifacts(
        plan,
        &execution_provenance,
    ));
    auxiliary_artifacts.extend(crate::fdm::artifacts::transfer_provenance_artifacts(plan));
    let fdm_region_membership_artifacts = crate::fdm::artifacts::region_membership_artifacts(plan)
        .map_err(|error| std::io::Error::new(std::io::ErrorKind::InvalidData, error))?;
    auxiliary_artifacts.extend(fdm_region_membership_artifacts);
    if let Some(artifact) = physics_graph_artifact {
        auxiliary_artifacts.push(artifact);
    }
    if !immutable_fem_eigen_publication {
        for artifact in &auxiliary_artifacts {
            let artifact_path = output_dir.join(&artifact.relative_path);
            if let Some(parent) = artifact_path.parent() {
                fs::create_dir_all(parent)?;
            }
            fs::write(artifact_path, &artifact.bytes)?;
        }
    }

    let periodic_pairs_artifact = if should_write_plan_periodic_pairs_artifact(plan, executed) {
        if immutable_fem_eigen_publication {
            build_periodic_pairs_artifact(plan, problem_source_scene_revision(problem))?
        } else {
            write_periodic_pairs_artifact(
                output_dir,
                plan,
                problem_source_scene_revision(problem),
            )?;
            None
        }
    } else {
        None
    };
    let node_geometry_artifact = if immutable_fem_eigen_publication {
        build_fem_supercell_node_geometry_artifact(problem, plan)?
    } else {
        write_fem_supercell_node_geometry_artifact(output_dir, problem, plan)?;
        None
    };
    write_static_pbc_demag_seam_diagnostics_artifact(
        output_dir,
        problem,
        plan,
        executed,
        &final_stats,
    )?;

    write_prescribed_current_transport_artifacts(
        output_dir,
        problem,
        plan,
        &field_context,
        &execution_provenance,
    )?;

    if immutable_fem_eigen_publication {
        let lease = frequency_publication_lease.as_ref().ok_or_else(|| {
            Error::new(
                ErrorKind::InvalidData,
                "immutable FEM eigen publication is missing its writer lease",
            )
        })?;
        let mut member_bytes = auxiliary_artifacts
            .into_iter()
            .map(|artifact| (artifact.relative_path, artifact.bytes))
            .collect::<Vec<_>>();
        member_bytes.push(("metadata.json".to_string(), metadata_bytes));
        if let Some(prepared) = prepared_immutable_material_artifacts {
            member_bytes.extend(
                prepared
                    .files
                    .into_iter()
                    .map(|artifact| (artifact.relative_path, artifact.bytes)),
            );
        }
        if let Some(artifact) = periodic_pairs_artifact {
            member_bytes.push((artifact.relative_path, artifact.bytes));
        }
        if let Some(artifact) = node_geometry_artifact {
            member_bytes.push((artifact.relative_path, artifact.bytes));
        }
        validate_immutable_generation_references(&member_bytes)?;
        crate::artifact_generation::publish_immutable_with_lease(
            output_dir,
            immutable_producer,
            member_bytes,
            lease,
        )?;
    } else if auxiliary_artifacts.iter().any(|artifact| {
        artifact.relative_path.starts_with("eigen/")
            || artifact.relative_path.starts_with("response/")
    }) {
        let members = auxiliary_artifacts
            .iter()
            .map(|artifact| artifact.relative_path.clone())
            .collect::<BTreeSet<_>>();
        let mut members = members;
        members.insert("metadata.json".to_string());
        if should_write_plan_periodic_pairs_artifact(plan, executed) {
            members.insert("mesh/periodic_pairs.v1.json".to_string());
        }
        if matches!(&plan.backend_plan, BackendPlanIR::Fem(_))
            && problem.problem_meta.runtime_metadata.get("periodic_antidot_relaxation")
                .and_then(serde_json::Value::as_object)
                .is_some_and(|value| value.contains_key("supercell_repeat"))
        {
            members.insert("mesh/node_geometry.v1.json".to_string());
        }
        crate::artifact_generation::publish(
            output_dir,
            frequency_publication_owner(problem)?,
            members,
        )?;
    }

    Ok(())
}

fn should_write_solver_diagnostics(
    plan: &fullmag_ir::ExecutionPlanIR,
    timestep_policy: Option<&crate::types::TimestepPolicyProvenance>,
) -> bool {
    timestep_policy.is_some()
        || matches!(
            &plan.backend_plan,
            BackendPlanIR::Fem(fem)
                if fem.relaxation.as_ref().is_some_and(|control| matches!(
                    control.algorithm,
                    fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb
                        | fullmag_ir::RelaxationAlgorithmIR::NonlinearCg
                        | fullmag_ir::RelaxationAlgorithmIR::TangentPlaneImplicit
                ))
        )
}

fn fem_state_representation_name(
    value: fullmag_quantities::FemStateRepresentation,
) -> &'static str {
    match value {
        fullmag_quantities::FemStateRepresentation::LocalNodeAos => "local_node_aos",
    }
}

fn fem_material_field_location_name(
    value: fullmag_quantities::FemMaterialFieldLocation,
) -> &'static str {
    match value {
        fullmag_quantities::FemMaterialFieldLocation::Scalar => "scalar",
        fullmag_quantities::FemMaterialFieldLocation::NodalP1 => "nodal_p1",
        fullmag_quantities::FemMaterialFieldLocation::ElementDg0 => "element_dg0",
    }
}

fn write_solver_diagnostics_artifacts(
    output_dir: &Path,
    plan: &fullmag_ir::ExecutionPlanIR,
    timestep_policy: Option<&crate::types::TimestepPolicyProvenance>,
    steps: &[StepStats],
) -> std::io::Result<()> {
    let policy = match &plan.backend_plan {
        BackendPlanIR::Fem(fem) => serde_json::json!({
            "backend": "fem",
            "integrator": fem.integrator,
            "fixed_timestep": fem.fixed_timestep,
            "adaptive_timestep": fem.adaptive_timestep,
            "gyromagnetic_ratio": fem.gyromagnetic_ratio,
        }),
        BackendPlanIR::Fdm(fdm) => serde_json::json!({
            "backend": "fdm",
            "integrator": fdm.integrator,
            "fixed_timestep": fdm.fixed_timestep,
            "adaptive_timestep": fdm.adaptive_timestep,
            "gyromagnetic_ratio": fdm.gyromagnetic_ratio,
        }),
        _ => serde_json::json!({"backend": "not_time_domain"}),
    };
    let (requested_policy, resolved_policy, execution_identity) = timestep_policy.map_or_else(
        || (policy.clone(), policy, serde_json::Value::Null),
        |provenance| {
            (
                serde_json::to_value(&provenance.requested).unwrap(),
                serde_json::to_value(&provenance.resolved).unwrap(),
                serde_json::to_value(&provenance.execution_identity).unwrap(),
            )
        },
    );
    let timestep_qualification = execution_identity.clone();
    fs::write(
        output_dir.join("solver_config.json"),
        serde_json::to_string_pretty(&serde_json::json!({
            "schema_version": "LLG-TD-SOLVER-CONFIG-V1",
            "requested_policy": requested_policy,
            "resolved_policy": resolved_policy,
            "execution_identity": execution_identity,
        }))
        .unwrap(),
    )?;

    let mut attempts = fs::File::create(output_dir.join("solver_attempts.csv"))?;
    writeln!(attempts, "attempt,target_step,t_s,dt_attempt_s,eta,max_norm_defect,max_spin_rotation_rad,decision,reason,dt_next_s,demag_solves,demag_iterations,demag_residual,rhs_evals,estimator_order,adaptive_controller_policy_version,error_norm_type,active_node_count,active_measure,normalization_denominator,max_scaled_error,weighted_rms_error")?;
    for step in steps {
        for record in &step.solver_attempts {
            writeln!(
                attempts,
                "{},{},{:.17e},{:.17e},{:.17e},{},{},{},{},{:.17e},{},{},{:.17e},{},{},{},{},{},{},{},{},{}",
                record.attempt,
                record.target_step,
                record.time,
                record.dt_attempt,
                record.eta,
                record
                    .max_norm_defect
                    .map(|value| format!("{value:.17e}"))
                    .unwrap_or_default(),
                record
                    .max_spin_rotation
                    .map(|value| format!("{value:.17e}"))
                    .unwrap_or_default(),
                record.decision,
                record.reason,
                record.dt_next,
                record.demag_solves,
                record.demag_iterations,
                record.demag_residual,
                record.rhs_evals,
                record.estimator_order,
                record
                    .adaptive_controller_policy_version
                    .as_deref()
                    .unwrap_or_default(),
                record.error_norm_type.as_deref().unwrap_or_default(),
                record
                    .active_node_count
                    .map(|value| value.to_string())
                    .unwrap_or_default(),
                record
                    .active_measure
                    .map(|value| format!("{value:.17e}"))
                    .unwrap_or_default(),
                record
                    .normalization_denominator
                    .map(|value| format!("{value:.17e}"))
                    .unwrap_or_default(),
                record
                    .max_scaled_error
                    .map(|value| format!("{value:.17e}"))
                    .unwrap_or_default(),
                record
                    .weighted_rms_error
                    .map(|value| format!("{value:.17e}"))
                    .unwrap_or_default(),
            )?;
        }
    }

    let mut accepted = fs::File::create(output_dir.join("solver_steps.csv"))?;
    writeln!(accepted, "step,t_s,dt_s,error_estimate,max_error,dt_suggested_s,rejected_attempts,rhs_evals,demag_solves,demag_iterations,demag_residual,e_exchange_j,e_demag_j,e_zeeman_j,e_drive_j,e_anisotropy_j,e_dmi_j,e_total_j,max_rhs_per_s,max_torque_apm,accepted_energy_proof_available,accepted_energy_delta_j,accepted_energy_roundoff_bound_j,accepted_energy_delta_upper_j,armijo_increment_rhs_j,wall_time_ns,accepted,fem_representation_schema_version,fem_state_space,fem_ms_location,fem_a_location,fem_local_node_count,fem_true_node_count,fem_periodic_map_revision,fem_representation_copy_count,fem_gather_scatter_bytes,fem_invalid_space_assertion_count,fem_hot_loop_representation_copy_count,fem_hot_loop_gather_scatter_bytes")?;
    let mut previous_step = None;
    for step in steps {
        let accepted_step = previous_step
            .map(|previous| step.step > previous)
            .unwrap_or(step.step > 0);
        previous_step = Some(step.step);
        let representation = step.fem_representation_receipt.as_ref();
        writeln!(
            accepted,
            "{},{:.17e},{:.17e},{},{},{},{},{},{},{},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{:.17e},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}",
            step.step,
            step.time,
            step.dt,
            step.error_estimate.map(|value| format!("{value:.17e}")).unwrap_or_default(),
            step.max_error.map(|value| format!("{value:.17e}")).unwrap_or_default(),
            step.dt_suggested.map(|value| format!("{value:.17e}")).unwrap_or_default(),
            step.rejected_attempts,
            step.rhs_evals,
            step.demag_solves,
            step.poisson_iterations,
            step.poisson_final_residual,
            step.e_ex,
            step.e_demag,
            step.e_ext,
            step.e_drive,
            step.e_ani,
            step.e_dmi,
            step.e_total,
            step.max_rhs_norm_per_s.max(step.max_dm_dt),
            step.max_torque_Apm,
            step.accepted_energy_proof_available,
            step.accepted_energy_delta_j.map(|value| format!("{value:.17e}")).unwrap_or_default(),
            step.accepted_energy_roundoff_bound_j.map(|value| format!("{value:.17e}")).unwrap_or_default(),
            step.accepted_energy_delta_upper_j.map(|value| format!("{value:.17e}")).unwrap_or_default(),
            step.armijo_increment_rhs_j.map(|value| format!("{value:.17e}")).unwrap_or_default(),
            step.wall_time_ns,
            accepted_step,
            representation.map(|receipt| receipt.schema_version.to_string()).unwrap_or_default(),
            representation.map(|receipt| fem_state_representation_name(receipt.state_space)).unwrap_or_default(),
            representation.map(|receipt| fem_material_field_location_name(receipt.ms_location)).unwrap_or_default(),
            representation.map(|receipt| fem_material_field_location_name(receipt.a_location)).unwrap_or_default(),
            representation.map(|receipt| receipt.local_node_count.to_string()).unwrap_or_default(),
            representation.map(|receipt| receipt.true_node_count.to_string()).unwrap_or_default(),
            representation.map(|receipt| receipt.periodic_map_revision.to_string()).unwrap_or_default(),
            representation.map(|receipt| receipt.representation_copy_count.to_string()).unwrap_or_default(),
            representation.map(|receipt| receipt.gather_scatter_bytes.to_string()).unwrap_or_default(),
            representation.map(|receipt| receipt.invalid_space_assertion_count.to_string()).unwrap_or_default(),
            representation.map(|receipt| receipt.hot_loop_representation_copy_count.to_string()).unwrap_or_default(),
            representation.map(|receipt| receipt.hot_loop_gather_scatter_bytes.to_string()).unwrap_or_default(),
        )?;
    }

    fs::write(
        output_dir.join("qualification.json"),
        serde_json::to_string_pretty(&serde_json::json!({
            "schema_version": "LLG-TD-QUALIFICATION-V1",
            "status": "not_evaluated",
            "reason": "Scientific qualification is produced by the dedicated qualification gate; artifact creation alone is not evidence of validation.",
            "timestep_qualification": timestep_qualification,
            "accepted_steps": steps.len(),
            "attempt_records": steps.iter().map(|step| step.solver_attempts.len()).sum::<usize>(),
            "checks": [],
        })).unwrap(),
    )?;
    Ok(())
}

#[derive(Debug, Default)]
struct PreparedMaterialFieldArtifacts {
    metadata_assets: Vec<serde_json::Value>,
    files: Vec<crate::types::AuxiliaryArtifact>,
}

fn build_material_field_artifacts(
    plan: &fullmag_ir::ExecutionPlanIR,
) -> std::io::Result<PreparedMaterialFieldArtifacts> {
    match &plan.backend_plan {
        BackendPlanIR::Fem(fem) => build_fem_material_field_artifacts(plan, fem),
        BackendPlanIR::FemEigen(fem) => build_fem_eigen_material_field_artifacts(plan, fem),
        BackendPlanIR::FdmMultilayer(multilayer) => {
            build_fdm_multilayer_material_field_artifacts(multilayer)
        }
        _ => Ok(PreparedMaterialFieldArtifacts::default()),
    }
}

fn write_material_field_artifacts(
    output_dir: &Path,
    plan: &fullmag_ir::ExecutionPlanIR,
) -> std::io::Result<Vec<serde_json::Value>> {
    if let BackendPlanIR::FdmMultilayer(multilayer) = &plan.backend_plan {
        return write_fdm_multilayer_material_field_artifacts(output_dir, multilayer);
    }

    let prepared = build_material_field_artifacts(plan)?;
    write_artifact_bytes(output_dir, &prepared.files)?;
    Ok(prepared.metadata_assets)
}

fn write_artifact_bytes(
    output_dir: &Path,
    files: &[crate::types::AuxiliaryArtifact],
) -> std::io::Result<()> {
    for artifact in files {
        let full_path = output_dir.join(&artifact.relative_path);
        if let Some(parent) = full_path.parent() {
            fs::create_dir_all(parent)?;
        }
        fs::write(full_path, &artifact.bytes)?;
    }
    Ok(())
}

fn build_fem_material_field_artifacts(
    plan: &fullmag_ir::ExecutionPlanIR,
    fem: &fullmag_ir::FemPlanIR,
) -> std::io::Result<PreparedMaterialFieldArtifacts> {
    build_fem_material_field_artifacts_with_values(
        plan,
        &fem.mesh_name,
        &fem.mesh,
        |field_plan| fem_material_field_values(fem, field_plan),
    )
}

fn build_fem_eigen_material_field_artifacts(
    plan: &fullmag_ir::ExecutionPlanIR,
    fem: &fullmag_ir::FemEigenPlanIR,
) -> std::io::Result<PreparedMaterialFieldArtifacts> {
    build_fem_material_field_artifacts_with_values(
        plan,
        &fem.mesh_name,
        &fem.mesh,
        |field_plan| fem_eigen_material_field_values(fem, field_plan),
    )
}

fn build_fem_material_field_artifacts_with_values<'values>(
    plan: &fullmag_ir::ExecutionPlanIR,
    mesh_name: &str,
    mesh: &fullmag_ir::MeshIR,
    mut values_for: impl FnMut(
        &fullmag_ir::MaterialFieldPlan,
    ) -> Option<(&'values [f64], fullmag_ir::MaterialFieldLocationIR)>,
) -> std::io::Result<PreparedMaterialFieldArtifacts> {
    let mut prepared = PreparedMaterialFieldArtifacts::default();
    let mesh_generation_id = solver_mesh_signature(mesh);
    for field_plan in &plan.common.material_field_plans {
        let Some((values, location)) = values_for(field_plan) else {
            continue;
        };
        if values.is_empty() {
            continue;
        }

        let stats = material_field_statistics(values);
        let asset_id = material_field_asset_id(
            &field_plan.object_id,
            field_plan.parameter,
            field_plan.realization_location,
        );
        let artifact_path = format!("material-fields/{asset_id}.json");
        let asset = fullmag_ir::MaterialFieldAssetIR {
            asset_id: asset_id.clone(),
            artifact_path: Some(artifact_path.clone()),
            parameter: field_plan.parameter,
            owner_object_id: field_plan.object_id.clone(),
            source_region_id: None,
            mesh_id: mesh_name.to_string(),
            mesh_generation_id: mesh_generation_id.clone(),
            location,
            component_count: 1,
            unit: material_field_unit(field_plan.parameter).to_string(),
            values: values.to_vec(),
            min: stats.min,
            max: stats.max,
            mean: stats.mean,
            provenance: fullmag_ir::MaterialFieldProvenanceIR {
                source_kind: field_plan.source_kind,
                algorithm: field_plan
                    .realization_method
                    .clone()
                    .unwrap_or_else(|| "runtime_material_field_artifact".to_string()),
                timing_ms: 0.0,
            },
        };

        let bytes = serde_json::to_string_pretty(&asset).unwrap().into_bytes();

        let mut metadata_asset = serde_json::to_value(asset).map_err(|error| {
            Error::new(
                ErrorKind::InvalidData,
                format!("FEM material field metadata serialization failed: {error}"),
            )
        })?;
        metadata_asset
            .as_object_mut()
            .expect("MaterialFieldAssetIR serializes as an object")
            .insert("values".to_string(), serde_json::json!([]));
        prepared.metadata_assets.push(metadata_asset);
        prepared.files.push(crate::types::AuxiliaryArtifact {
            relative_path: artifact_path,
            bytes,
        });
    }

    Ok(prepared)
}

fn build_fdm_multilayer_material_field_artifacts(
    multilayer: &fullmag_ir::FdmMultilayerPlanIR,
) -> std::io::Result<PreparedMaterialFieldArtifacts> {
    let build_identity = build_identity_json();
    let mut prepared_files = Vec::<(String, serde_json::Value)>::new();
    let mut prepared = PreparedMaterialFieldArtifacts::default();
    let mut manifest_layers = Vec::with_capacity(multilayer.layers.len());
    let mut value_offset = 0usize;

    for layer in &multilayer.layers {
        let descriptor = fdm_multilayer_layer_artifact_descriptor(layer, value_offset)?;
        value_offset = value_offset
            .checked_add(multilayer_native_cell_count(layer)?)
            .ok_or_else(|| {
                Error::new(
                    ErrorKind::InvalidData,
                    "fdm_multilayer artifact value offsets overflow usize",
                )
            })?;

        let native_grid_fingerprint = descriptor["native_grid_fingerprint"]
            .as_str()
            .expect("validated native grid fingerprint")
            .to_string();
        let material_fields = descriptor["material_fields"]
            .as_object()
            .expect("material_fields descriptor");
        for (field_id, values, unit) in fdm_multilayer_material_values(layer) {
            let Some(values) = values else {
                continue;
            };
            let field_descriptor = material_fields
                .get(field_id)
                .expect("present material array has a descriptor");
            let relative_path = field_descriptor["artifact_path"]
                .as_str()
                .expect("material descriptor has artifact_path")
                .to_string();
            let payload = serde_json::json!({
                "schema_version": "fdm_multilayer_material_field.v1",
                "backend": "fdm_multilayer",
                "build_identity": build_identity,
                "layer_id": layer.layer_id,
                "object_id": layer.object_id,
                "magnet_name": layer.magnet_name,
                "native_grid": layer.native_grid,
                "native_origin": layer.native_origin,
                "native_cell_size": layer.native_cell_size,
                "native_grid_fingerprint": native_grid_fingerprint,
                "field_id": field_id,
                "unit": unit,
                "value_count": values.len(),
                "revision": field_descriptor["revision"],
                "generation_id": field_descriptor["generation_id"],
                "value_sha256": field_descriptor["value_sha256"],
                "values": values,
            });
            prepared_files.push((relative_path.clone(), payload));
            prepared.metadata_assets.push(serde_json::json!({
                "schema_version": "fdm_multilayer_material_field.v1",
                "backend": "fdm_multilayer",
                "build_identity": build_identity,
                "artifact_path": relative_path,
                "layer_id": layer.layer_id,
                "object_id": layer.object_id,
                "magnet_name": layer.magnet_name,
                "native_grid": layer.native_grid,
                "native_origin": layer.native_origin,
                "native_cell_size": layer.native_cell_size,
                "native_grid_fingerprint": native_grid_fingerprint,
                "field_id": field_id,
                "unit": unit,
                "value_count": values.len(),
                "revision": field_descriptor["revision"],
                "generation_id": field_descriptor["generation_id"],
                "value_sha256": field_descriptor["value_sha256"],
            }));
        }

        if let Some(mask) = fdm_multilayer_artifact_region_mask(layer)? {
            let membership_descriptor = &descriptor["native_region_mask"];
            let membership_path = membership_descriptor["artifact_path"]
                .as_str()
                .expect("membership descriptor has artifact_path")
                .to_string();
            prepared_files.push((
                membership_path,
                serde_json::json!({
                    "schema_version": "fdm_multilayer_region_membership.v1",
                    "backend": "fdm_multilayer",
                    "build_identity": build_identity,
                    "layer_id": layer.layer_id,
                    "object_id": layer.object_id,
                    "magnet_name": layer.magnet_name,
                    "native_grid": layer.native_grid,
                    "native_origin": layer.native_origin,
                    "native_cell_size": layer.native_cell_size,
                    "native_grid_fingerprint": native_grid_fingerprint,
                    "revision": membership_descriptor["revision"],
                    "generation_id": membership_descriptor["generation_id"],
                    "value_count": mask.len(),
                    "value_sha256": membership_descriptor["value_sha256"],
                    "legend_sha256": descriptor["native_region_legend"]["legend_sha256"],
                    "inactive_numeric_id": u32::MAX,
                    "unassigned_numeric_id": 0,
                    "native_region_mask": mask,
                    "native_region_legend": layer.native_region_legend.as_deref().unwrap_or(&[]),
                }),
            ));
        }

        manifest_layers.push(descriptor);
    }

    if prepared_files.is_empty() {
        return Ok(prepared);
    }

    let manifest_path = "material-fields/fdm-multilayer/manifest.json";
    let manifest = serde_json::json!({
        "schema_version": "fdm_multilayer_material_fields.v1",
        "backend": "fdm_multilayer",
        "build_identity": build_identity,
        "storage_layout": "per_layer_native_grid",
        "layer_count": manifest_layers.len(),
        "layers": manifest_layers,
    });
    prepared_files.push((manifest_path.to_string(), manifest));

    for (relative_path, payload) in prepared_files {
        prepared.files.push(crate::types::AuxiliaryArtifact {
            relative_path,
            bytes: serde_json::to_vec_pretty(&payload).unwrap(),
        });
    }

    Ok(prepared)
}

fn write_fdm_multilayer_material_field_artifacts(
    output_dir: &Path,
    multilayer: &fullmag_ir::FdmMultilayerPlanIR,
) -> std::io::Result<Vec<serde_json::Value>> {
    let prepared = build_fdm_multilayer_material_field_artifacts(multilayer)?;
    write_artifact_bytes(output_dir, &prepared.files)?;
    Ok(prepared.metadata_assets)
}

fn fdm_multilayer_layer_artifact_descriptor(
    layer: &fullmag_ir::FdmLayerPlanIR,
    value_offset: usize,
) -> std::io::Result<serde_json::Value> {
    if layer.layer_id.trim().is_empty()
        || layer.object_id.trim().is_empty()
        || layer.magnet_name.trim().is_empty()
    {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "fdm_multilayer artifact layer identity must be non-empty",
        ));
    }
    let total_cells = multilayer_native_cell_count(layer)?;
    if layer
        .native_cell_size
        .iter()
        .any(|value| !value.is_finite() || *value <= 0.0)
        || layer.native_origin.iter().any(|value| !value.is_finite())
    {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "fdm_multilayer layer '{}' has invalid native grid units or coordinates",
                layer.layer_id
            ),
        ));
    }
    if let Some(active_mask) = layer.native_active_mask.as_deref() {
        validate_multilayer_value_count(
            &layer.layer_id,
            "native_active_mask",
            active_mask.len(),
            total_cells,
        )?;
    }
    let active_cell_count = layer
        .native_active_mask
        .as_deref()
        .map(|mask| mask.iter().filter(|active| **active).count())
        .unwrap_or(total_cells);
    let native_grid_fingerprint = fullmag_ir::FdmGridCertificateIR::new_with_topology_tokens(
        layer.native_origin,
        layer.native_grid,
        layer.native_cell_size,
        active_cell_count as u64,
        1,
        layer.native_active_mask.as_deref(),
        layer.native_region_mask.as_deref().unwrap_or(&[]),
    )
    .map_err(|error| {
        Error::new(
            ErrorKind::InvalidData,
            format!(
                "fdm_multilayer layer '{}' cannot establish native grid fingerprint: {error}",
                layer.layer_id
            ),
        )
    })?
    .grid_fingerprint;
    let native_grid_fingerprint = format!("sha256:{native_grid_fingerprint}");

    let layer_directory = fdm_multilayer_layer_directory(&layer.layer_id);
    let mut material_fields = serde_json::Map::new();
    for (field_id, values, unit) in fdm_multilayer_material_values(layer) {
        let Some(values) = values else {
            continue;
        };
        validate_multilayer_material_unit(field_id, unit)?;
        validate_multilayer_value_count(&layer.layer_id, field_id, values.len(), total_cells)?;
        validate_multilayer_material_values(&layer.layer_id, field_id, values)?;
        let value_sha256 = hash_f64_values(values);
        let revision = 1u64;
        let generation_id = hash_json_value(&serde_json::json!({
            "schema_version": "fdm_multilayer_material_generation.v1",
            "layer_id": layer.layer_id,
            "object_id": layer.object_id,
            "native_grid_fingerprint": native_grid_fingerprint,
            "field_id": field_id,
            "unit": unit,
            "value_count": values.len(),
            "revision": revision,
            "value_sha256": value_sha256,
        }))?;
        material_fields.insert(
            field_id.to_string(),
            serde_json::json!({
                "available": true,
                "unit": unit,
                "value_count": values.len(),
                "revision": revision,
                "generation_id": generation_id,
                "value_sha256": value_sha256,
                "artifact_path": format!(
                    "material-fields/fdm-multilayer/{layer_directory}/{field_id}.json"
                ),
            }),
        );
    }

    let (native_region_mask, native_region_legend) = if let Some(mask) =
        fdm_multilayer_artifact_region_mask(layer)?
    {
        let legend = layer.native_region_legend.as_deref().ok_or_else(|| {
            Error::new(
                ErrorKind::InvalidData,
                format!(
                    "fdm_multilayer layer '{}' native_region_mask requires native_region_legend",
                    layer.layer_id
                ),
            )
        })?;
        validate_multilayer_region_legend(&layer.layer_id, &layer.object_id, &mask, legend)?;
        let value_sha256 = hash_u32_values(&mask);
        let legend_sha256 = hash_json_value(&serde_json::to_value(legend).map_err(|error| {
            Error::new(
                ErrorKind::InvalidData,
                format!("fdm_multilayer region legend serialization failed: {error}"),
            )
        })?)?;
        let revision = 1u64;
        let generation_id = hash_json_value(&serde_json::json!({
            "schema_version": "fdm_multilayer_membership_generation.v1",
            "layer_id": layer.layer_id,
            "object_id": layer.object_id,
            "native_grid_fingerprint": native_grid_fingerprint,
            "revision": revision,
            "value_sha256": value_sha256,
            "legend_sha256": legend_sha256,
        }))?;
        let artifact_path = format!(
            "material-fields/fdm-multilayer/{layer_directory}/native-region-membership.json"
        );
        (
            serde_json::json!({
                "available": true,
                "value_count": mask.len(),
                "revision": revision,
                "generation_id": generation_id,
                "value_sha256": value_sha256,
                "artifact_path": artifact_path,
            }),
            serde_json::json!({
                "available": true,
                "entry_count": legend.len(),
                "revision": revision,
                "generation_id": generation_id,
                "legend_sha256": legend_sha256,
                "artifact_path": artifact_path,
                "entries": legend,
            }),
        )
    } else {
        if layer
            .native_region_legend
            .as_deref()
            .is_some_and(|legend| !legend.is_empty())
        {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!(
                    "fdm_multilayer layer '{}' native_region_legend requires native_region_mask",
                    layer.layer_id
                ),
            ));
        }
        (
            serde_json::json!({"available": false}),
            serde_json::json!({"available": false}),
        )
    };

    Ok(serde_json::json!({
        "layer_id": layer.layer_id,
        "object_id": layer.object_id,
        "magnet_name": layer.magnet_name,
        "native_grid": layer.native_grid,
        "native_cell_size": layer.native_cell_size,
        "native_origin": layer.native_origin,
        "native_grid_fingerprint": native_grid_fingerprint,
        "convolution_grid": layer.convolution_grid,
        "convolution_cell_size": layer.convolution_cell_size,
        "convolution_origin": layer.convolution_origin,
        "transfer_kind": layer.transfer_kind,
        "total_cell_count": total_cells,
        "active_mask_present": layer.native_active_mask.is_some(),
        "active_cell_count": active_cell_count,
        "inactive_cell_count": total_cells.saturating_sub(active_cell_count),
        "value_offset": value_offset,
        "value_count": total_cells,
        "native_region_mask": native_region_mask,
        "native_region_legend": native_region_legend,
        "material_fields": material_fields,
    }))
}

fn fdm_multilayer_material_values(
    layer: &fullmag_ir::FdmLayerPlanIR,
) -> [(&'static str, Option<&[f64]>, &'static str); 3] {
    [
        ("mat_ms", layer.material.ms_field.as_deref(), "A/m"),
        ("mat_aex", layer.material.a_field.as_deref(), "J/m"),
        ("mat_alpha", layer.material.alpha_field.as_deref(), "1"),
    ]
}

fn fdm_multilayer_artifact_region_mask(
    layer: &fullmag_ir::FdmLayerPlanIR,
) -> std::io::Result<Option<Vec<u32>>> {
    let Some(region_mask) = layer.native_region_mask.as_deref() else {
        return Ok(None);
    };
    let total_cells = multilayer_native_cell_count(layer)?;
    validate_multilayer_value_count(
        &layer.layer_id,
        "native_region_mask",
        region_mask.len(),
        total_cells,
    )?;
    if region_mask.iter().any(|numeric_id| *numeric_id == u32::MAX) {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "fdm_multilayer layer '{}' raw native_region_mask reserves u32::MAX for artifact-only inactive cells",
                layer.layer_id
            ),
        ));
    }
    if let Some(active_mask) = layer.native_active_mask.as_deref() {
        if active_mask
            .iter()
            .zip(region_mask)
            .any(|(active, numeric_id)| !active && *numeric_id != 0)
        {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!(
                    "fdm_multilayer layer '{}' native_region_mask assigns a region to an inactive cell",
                    layer.layer_id
                ),
            ));
        }
    }
    let mask = match layer.native_active_mask.as_deref() {
        Some(active_mask) => active_mask
            .iter()
            .zip(region_mask)
            .map(|(active, numeric_id)| if *active { *numeric_id } else { u32::MAX })
            .collect(),
        None => region_mask.to_vec(),
    };
    Ok(Some(mask))
}

fn multilayer_native_cell_count(layer: &fullmag_ir::FdmLayerPlanIR) -> std::io::Result<usize> {
    layer.native_grid.iter().try_fold(1usize, |total, count| {
        if *count == 0 {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!(
                    "fdm_multilayer layer '{}' native_grid contains zero",
                    layer.layer_id
                ),
            ));
        }
        total.checked_mul(*count as usize).ok_or_else(|| {
            Error::new(
                ErrorKind::InvalidData,
                format!(
                    "fdm_multilayer layer '{}' native cell count overflows usize",
                    layer.layer_id
                ),
            )
        })
    })
}

fn validate_multilayer_value_count(
    layer_id: &str,
    field_id: &str,
    actual: usize,
    expected: usize,
) -> std::io::Result<()> {
    if actual != expected {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "fdm_multilayer layer '{layer_id}' {field_id} length {actual} does not match native cell count {expected}"
            ),
        ));
    }
    Ok(())
}

fn validate_multilayer_material_unit(field_id: &str, unit: &str) -> std::io::Result<()> {
    let expected = match field_id {
        "mat_ms" => "A/m",
        "mat_aex" => "J/m",
        "mat_alpha" => "1",
        _ => {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!("unsupported fdm_multilayer material field '{field_id}'"),
            ));
        }
    };
    if unit != expected {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "fdm_multilayer material field '{field_id}' unit '{unit}' does not match '{expected}'"
            ),
        ));
    }
    Ok(())
}

fn validate_multilayer_material_values(
    layer_id: &str,
    field_id: &str,
    values: &[f64],
) -> std::io::Result<()> {
    for (index, value) in values.iter().copied().enumerate() {
        let valid_domain = match field_id {
            "mat_ms" => value > 0.0,
            "mat_aex" | "mat_alpha" => value >= 0.0,
            _ => false,
        };
        if !value.is_finite() || !valid_domain {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!(
                    "fdm_multilayer layer '{layer_id}' {field_id}[{index}] is outside its finite physical domain"
                ),
            ));
        }
    }
    Ok(())
}

fn validate_multilayer_region_legend(
    layer_id: &str,
    object_id: &str,
    mask: &[u32],
    legend: &[fullmag_ir::FdmRegionLegendEntryIR],
) -> std::io::Result<()> {
    let mut ids = BTreeSet::new();
    for entry in legend {
        if entry.numeric_id == 0
            || entry.numeric_id == u32::MAX
            || entry.object_id != object_id
            || entry.region_id.trim().is_empty()
            || !ids.insert(entry.numeric_id)
        {
            return Err(Error::new(
                ErrorKind::InvalidData,
                format!("fdm_multilayer layer '{layer_id}' has an invalid native region legend"),
            ));
        }
    }
    if mask
        .iter()
        .copied()
        .filter(|numeric_id| !matches!(*numeric_id, 0 | u32::MAX))
        .any(|numeric_id| !ids.contains(&numeric_id))
    {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "fdm_multilayer layer '{layer_id}' native region mask references an unknown legend entry"
            ),
        ));
    }
    Ok(())
}

fn fdm_multilayer_layer_directory(layer_id: &str) -> String {
    let layer_id = layer_id.strip_prefix("layer:").unwrap_or(layer_id);
    format!("layer-{}", sanitize_layer_id(layer_id))
}

fn hash_f64_values(values: &[f64]) -> String {
    let mut hasher = Sha256::new();
    for value in values {
        hasher.update(value.to_le_bytes());
    }
    format!("sha256:{:x}", hasher.finalize())
}

fn hash_u32_values(values: &[u32]) -> String {
    let mut hasher = Sha256::new();
    for value in values {
        hasher.update(value.to_le_bytes());
    }
    format!("sha256:{:x}", hasher.finalize())
}

fn hash_json_value(value: &serde_json::Value) -> std::io::Result<String> {
    let payload = serde_json::to_vec(value).map_err(|error| {
        Error::new(
            ErrorKind::InvalidData,
            format!("fdm_multilayer artifact fingerprint serialization failed: {error}"),
        )
    })?;
    Ok(format!("sha256:{:x}", Sha256::digest(payload)))
}

fn build_fem_supercell_node_geometry_artifact(
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
) -> std::io::Result<Option<crate::types::AuxiliaryArtifact>> {
    let BackendPlanIR::Fem(fem) = &plan.backend_plan else {
        return Ok(None);
    };
    let Some(runtime_metadata) = problem
        .problem_meta
        .runtime_metadata
        .get("periodic_antidot_relaxation")
        .and_then(|value| value.as_object())
    else {
        return Ok(None);
    };
    if !runtime_metadata.contains_key("supercell_repeat") {
        return Ok(None);
    }

    let magnetic_node_mask = crate::preview::mesh_quantity_active_mask("m", &fem.mesh)
        .unwrap_or_else(|| vec![true; fem.mesh.nodes.len()]);
    let magnetic_node_count = magnetic_node_mask.iter().filter(|value| **value).count();
    let artifact = serde_json::json!({
        "schema_version": "fem_mesh_node_geometry.v1",
        "artifact_path": "mesh/node_geometry.v1.json",
        "mesh_name": fem.mesh.mesh_name,
        "node_count": fem.mesh.nodes.len(),
        "element_count": fem.mesh.cell_count(),
        "nodes_m": fem.mesh.nodes,
        "magnetic_node_mask": magnetic_node_mask,
        "magnetic_node_count": magnetic_node_count,
        "field_cell_alignment": {
            "m": "node_index",
            "H_demag": "node_index",
            "H_eff": "node_index",
            "demag_phi": "node_index"
        },
        "source": "ExecutionPlanIR.FemPlanIR.mesh.nodes",
    });
    let bytes = serde_json::to_vec_pretty(&artifact).unwrap();
    Ok(Some(crate::types::AuxiliaryArtifact {
        relative_path: "mesh/node_geometry.v1.json".to_string(),
        bytes,
    }))
}

fn write_fem_supercell_node_geometry_artifact(
    output_dir: &Path,
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
) -> std::io::Result<()> {
    if let Some(artifact) = build_fem_supercell_node_geometry_artifact(problem, plan)? {
        write_artifact_bytes(output_dir, &[artifact])?;
    }
    Ok(())
}

fn fem_material_field_values<'a>(
    fem: &'a fullmag_ir::FemPlanIR,
    field_plan: &fullmag_ir::MaterialFieldPlan,
) -> Option<(&'a [f64], fullmag_ir::MaterialFieldLocationIR)> {
    use fullmag_ir::MaterialFieldLocationIR::{Element, Node};
    use fullmag_ir::MaterialParameterNameIR::{Aex, Alpha, Ms};

    match (field_plan.parameter, field_plan.realization_location) {
        (Ms, Node) => fem
            .material
            .ms_field
            .as_deref()
            .map(|values| (values, Node)),
        (Aex, Node) => fem.material.a_field.as_deref().map(|values| (values, Node)),
        (Alpha, Node) => fem
            .material
            .alpha_field
            .as_deref()
            .map(|values| (values, Node)),
        (Ms, Element) => fem
            .ms_element_field
            .as_deref()
            .map(|values| (values, Element)),
        (Aex, Element) => fem
            .a_element_field
            .as_deref()
            .map(|values| (values, Element)),
        _ => None,
    }
}

fn fem_eigen_material_field_values<'a>(
    fem: &'a fullmag_ir::FemEigenPlanIR,
    field_plan: &fullmag_ir::MaterialFieldPlan,
) -> Option<(&'a [f64], fullmag_ir::MaterialFieldLocationIR)> {
    use fullmag_ir::MaterialFieldLocationIR::Node;
    use fullmag_ir::MaterialParameterNameIR::{Aex, Alpha, Ms};

    match (field_plan.parameter, field_plan.realization_location) {
        (Ms, Node) => fem.material.ms_field.as_deref().map(|values| (values, Node)),
        (Aex, Node) => fem.material.a_field.as_deref().map(|values| (values, Node)),
        (Alpha, Node) => fem.material.alpha_field.as_deref().map(|values| (values, Node)),
        _ => None,
    }
}

fn material_field_statistics(values: &[f64]) -> fullmag_ir::MaterialFieldStatisticsIR {
    let mut min = f64::INFINITY;
    let mut max = f64::NEG_INFINITY;
    let mut sum = 0.0;
    for value in values {
        min = min.min(*value);
        max = max.max(*value);
        sum += *value;
    }
    fullmag_ir::MaterialFieldStatisticsIR {
        sample_count: values.len(),
        min,
        max,
        mean: sum / values.len() as f64,
    }
}

fn material_field_asset_id(
    object_id: &str,
    parameter: fullmag_ir::MaterialParameterNameIR,
    location: fullmag_ir::MaterialFieldLocationIR,
) -> String {
    format!(
        "{}_{}_{}",
        sanitize_material_field_asset_component(object_id),
        material_field_parameter_id(parameter),
        material_field_location_id(location),
    )
}

fn sanitize_material_field_asset_component(value: &str) -> String {
    let mut sanitized = value
        .chars()
        .map(|ch| {
            if ch.is_ascii_alphanumeric() || ch == '-' || ch == '_' {
                ch.to_ascii_lowercase()
            } else {
                '_'
            }
        })
        .collect::<String>();
    while sanitized.contains("__") {
        sanitized = sanitized.replace("__", "_");
    }
    sanitized.trim_matches('_').to_string()
}

fn material_field_parameter_id(parameter: fullmag_ir::MaterialParameterNameIR) -> &'static str {
    match parameter {
        fullmag_ir::MaterialParameterNameIR::Ms => "ms",
        fullmag_ir::MaterialParameterNameIR::Aex => "aex",
        fullmag_ir::MaterialParameterNameIR::Alpha => "alpha",
        fullmag_ir::MaterialParameterNameIR::Ku1 => "ku1",
        fullmag_ir::MaterialParameterNameIR::Ku2 => "ku2",
        fullmag_ir::MaterialParameterNameIR::AnisotropyAxis => "anisotropy_axis",
        fullmag_ir::MaterialParameterNameIR::Kc1 => "kc1",
        fullmag_ir::MaterialParameterNameIR::Kc2 => "kc2",
        fullmag_ir::MaterialParameterNameIR::Kc3 => "kc3",
        fullmag_ir::MaterialParameterNameIR::Dind => "dind",
        fullmag_ir::MaterialParameterNameIR::Dbulk => "dbulk",
    }
}

fn should_write_plan_periodic_pairs_artifact(
    plan: &fullmag_ir::ExecutionPlanIR,
    executed: &ExecutedRun,
) -> bool {
    if matches!(plan.backend_plan, BackendPlanIR::FemEigen(_)) {
        return false;
    }
    if matches!(plan.backend_plan, BackendPlanIR::FemFrequencyResponse(_))
        && executed
            .provenance
            .execution_engine
            .starts_with("native_fem.frequency_domain.production_")
    {
        return false;
    }
    true
}

fn material_field_location_id(location: fullmag_ir::MaterialFieldLocationIR) -> &'static str {
    match location {
        fullmag_ir::MaterialFieldLocationIR::Cell => "cell",
        fullmag_ir::MaterialFieldLocationIR::Node => "node",
        fullmag_ir::MaterialFieldLocationIR::Element => "element",
        fullmag_ir::MaterialFieldLocationIR::Quadrature => "quadrature",
    }
}

fn material_field_unit(parameter: fullmag_ir::MaterialParameterNameIR) -> &'static str {
    match parameter {
        fullmag_ir::MaterialParameterNameIR::Ms => "A/m",
        fullmag_ir::MaterialParameterNameIR::Aex => "J/m",
        fullmag_ir::MaterialParameterNameIR::Alpha => "1",
        fullmag_ir::MaterialParameterNameIR::Ku1
        | fullmag_ir::MaterialParameterNameIR::Ku2
        | fullmag_ir::MaterialParameterNameIR::Kc1
        | fullmag_ir::MaterialParameterNameIR::Kc2
        | fullmag_ir::MaterialParameterNameIR::Kc3 => "J/m^3",
        fullmag_ir::MaterialParameterNameIR::AnisotropyAxis => "1",
        fullmag_ir::MaterialParameterNameIR::Dind | fullmag_ir::MaterialParameterNameIR::Dbulk => {
            "J/m^2"
        }
    }
}

fn problem_source_scene_revision(problem: &fullmag_ir::ProblemIR) -> Option<u64> {
    problem
        .problem_meta
        .runtime_metadata
        .get("mesh_source_scene_revision")
        .and_then(serde_json::Value::as_u64)
        .or_else(|| {
            problem
                .problem_meta
                .runtime_metadata
                .get("source_scene_revision")
                .and_then(serde_json::Value::as_u64)
        })
}

fn build_periodic_pairs_artifact(
    plan: &fullmag_ir::ExecutionPlanIR,
    source_scene_revision: Option<u64>,
) -> std::io::Result<Option<crate::types::AuxiliaryArtifact>> {
    let Some(mesh) = periodic_mesh(plan) else {
        return Ok(None);
    };
    if mesh.periodic_boundary_pairs.is_empty() {
        return Ok(None);
    }

    let mesh_topology_fingerprint = mesh.topology_fingerprint_v6();
    let (ms_element_field, a_element_field, ms_nodal_field, a_nodal_field) =
        periodic_material_fields(plan);
    let certificate = mesh
        .periodic_mesh_certificate_v6_with_material_and_nodal_fields(
            ms_element_field,
            a_element_field,
            ms_nodal_field,
            a_nodal_field,
        )
        .and_then(|certificate| validate_periodic_certificate_identity(mesh, certificate));
    let certificate_status = certificate
        .as_ref()
        .map(|certificate| certificate.certificate_status.as_str())
        .unwrap_or("rejected");
    let certificate_errors = certificate.as_ref().err().cloned().unwrap_or_default();

    let boundary_nodes_by_marker = mesh_boundary_nodes_by_marker(mesh);
    let node_pairs_by_id = mesh.periodic_node_pairs.iter().fold(
        HashMap::<String, Vec<&fullmag_ir::MeshPeriodicNodePairIR>>::new(),
        |mut acc, pair| {
            acc.entry(pair.pair_id.clone()).or_default().push(pair);
            acc
        },
    );
    let pairs = mesh
        .periodic_boundary_pairs
        .iter()
        .map(|boundary_pair| {
            let node_pairs = node_pairs_by_id
                .get(&boundary_pair.pair_id)
                .map(Vec::as_slice)
                .unwrap_or(&[]);
            let source_nodes = boundary_nodes_by_marker
                .get(&boundary_pair.marker_a)
                .cloned()
                .unwrap_or_default();
            let destination_nodes = boundary_nodes_by_marker
                .get(&boundary_pair.marker_b)
                .cloned()
                .unwrap_or_default();
            let paired_source_nodes = node_pairs
                .iter()
                .map(|pair| pair.node_a)
                .collect::<BTreeSet<_>>();
            let paired_destination_nodes = node_pairs
                .iter()
                .map(|pair| pair.node_b)
                .collect::<BTreeSet<_>>();
            let diagnostics = mesh_periodic_pair_residuals(mesh, boundary_pair, node_pairs);
            let (magnetic_node_pair_count, airbox_node_pair_count) =
                mesh_periodic_domain_node_pair_counts(mesh, node_pairs);
            let boundary_face_pairs = certificate
                .as_ref()
                .map(|certificate| {
                    certified_mesh_periodic_boundary_face_pairs(
                        certificate,
                        &boundary_pair.pair_id,
                        boundary_pair.translation,
                    )
                })
                .unwrap_or_default();
            let node_pair_payload = node_pairs
                .iter()
                .map(|pair| {
                    serde_json::json!({
                        "node_a": pair.node_a,
                        "node_b": pair.node_b,
                    })
                })
                .collect::<Vec<_>>();

            serde_json::json!({
                "pair_id": boundary_pair.pair_id.clone(),
                "source_marker": boundary_pair.source_marker.clone(),
                "destination_marker": boundary_pair.destination_marker.clone(),
                "marker_a": boundary_pair.marker_a,
                "marker_b": boundary_pair.marker_b,
                "expected_translation_m": boundary_pair.translation,
                "paired_node_count": node_pairs.len(),
                "domain_node_pair_counts": {
                    "magnetic": magnetic_node_pair_count,
                    "airbox": airbox_node_pair_count,
                },
                "unpaired_source_node_count": source_nodes.difference(&paired_source_nodes).count(),
                "unpaired_destination_node_count": destination_nodes.difference(&paired_destination_nodes).count(),
                "boundary_face_pairs": boundary_face_pairs,
                "node_pairs": node_pair_payload,
                "max_residual_m": diagnostics.max_residual_m,
                "rms_residual_m": diagnostics.rms_residual_m,
                "status": if certificate.is_err() {
                    "certificate_rejected"
                } else if boundary_face_pairs.is_empty() {
                    "face_pairs_missing"
                } else {
                    diagnostics.status.as_str()
                },
            })
        })
        .collect::<Vec<_>>();
    let pair_count = pairs.len();
    let paired_node_count = pairs
        .iter()
        .filter_map(|pair| {
            pair.get("paired_node_count")
                .and_then(serde_json::Value::as_u64)
        })
        .sum::<u64>();
    let max_translation_residual_m = pairs
        .iter()
        .filter_map(|pair| {
            pair.get("max_residual_m")
                .and_then(serde_json::Value::as_f64)
        })
        .fold(None, |acc: Option<f64>, value| {
            Some(acc.map_or(value, |current| current.max(value)))
        });
    let validation_status = if certificate.is_ok()
        && pairs
            .iter()
            .all(|pair| pair.get("status").and_then(serde_json::Value::as_str) == Some("valid"))
    {
        "ok"
    } else {
        "failed"
    };

    let payload = serde_json::json!({
        "schema_version": "periodic_pairs.v1",
        "artifact_path": "mesh/periodic_pairs.v1.json",
        "topology_fingerprint": mesh_topology_fingerprint,
        "mesh_generation_id": solver_mesh_signature(mesh),
        "source_scene_revision": source_scene_revision,
        "certificate_status": certificate_status,
        "certificate_fingerprint": certificate.as_ref().ok().and_then(|certificate| {
            serde_json::to_vec(certificate).ok().map(|payload| {
                let digest = sha2::Sha256::digest(payload);
                format!("sha256:{digest:x}")
            })
        }),
        "certificate": certificate
            .as_ref()
            .ok()
            .and_then(|certificate| serde_json::to_value(certificate).ok()),
        "certificate_errors": certificate_errors,
        "validation_status": validation_status,
        "pair_count": pair_count,
        "paired_node_count": paired_node_count,
        "max_translation_residual_m": max_translation_residual_m,
        "pairs": pairs,
    });
    Ok(Some(crate::types::AuxiliaryArtifact {
        relative_path: "mesh/periodic_pairs.v1.json".to_string(),
        bytes: serde_json::to_string_pretty(&payload).unwrap().into_bytes(),
    }))
}

fn write_periodic_pairs_artifact(
    output_dir: &Path,
    plan: &fullmag_ir::ExecutionPlanIR,
    source_scene_revision: Option<u64>,
) -> std::io::Result<()> {
    if let Some(artifact) = build_periodic_pairs_artifact(plan, source_scene_revision)? {
        write_artifact_bytes(output_dir, &[artifact])?;
    }
    Ok(())
}

fn validate_periodic_certificate_identity(
    mesh: &fullmag_ir::MeshIR,
    certificate: fullmag_ir::PeriodicMeshCertificateV6IR,
) -> Result<fullmag_ir::PeriodicMeshCertificateV6IR, Vec<String>> {
    let mesh_topology_fingerprint = mesh.topology_fingerprint_v6();
    if certificate.topology_fingerprint == mesh_topology_fingerprint {
        Ok(certificate)
    } else {
        Err(vec![format!(
            "periodic v6 certificate topology fingerprint {} does not match mesh {}",
            certificate.topology_fingerprint, mesh_topology_fingerprint
        )])
    }
}

fn static_pbc_demag_fem_plan<'a>(
    problem: &fullmag_ir::ProblemIR,
    plan: &'a fullmag_ir::ExecutionPlanIR,
) -> Option<&'a fullmag_ir::FemPlanIR> {
    let BackendPlanIR::Fem(fem) = &plan.backend_plan else {
        return None;
    };
    if !fem.enable_demag || fem.mesh.periodic_boundary_pairs.is_empty() {
        return None;
    }
    let pbc = problem.pbc.as_ref()?;
    if !pbc.has_any_periodic()
        || !matches!(
            pbc.demag,
            fullmag_ir::FdmDemagPeriodicityIR::PeriodicAirboxK0
        )
    {
        return None;
    }
    Some(fem)
}

fn write_static_pbc_demag_seam_diagnostics_artifact(
    output_dir: &Path,
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
    executed: &ExecutedRun,
    final_stats: &StepStats,
) -> std::io::Result<()> {
    let Some(fem) = static_pbc_demag_fem_plan(problem, plan) else {
        return Ok(());
    };

    let mut issues = Vec::<String>::new();
    let h_demag_snapshot = field_snapshot_at_step(executed, "H_demag", final_stats.step);
    let demag_phi_snapshot = field_snapshot_at_step(executed, "demag_phi", final_stats.step);
    let h_demag = h_demag_snapshot.and_then(|snapshot| match snapshot.vec3_values() {
        Ok(values) => Some(values),
        Err(error) => {
            issues.push(error);
            None
        }
    });
    let demag_phi = demag_phi_snapshot.and_then(|snapshot| match snapshot.vec3_values() {
        Ok(values) => Some(values),
        Err(error) => {
            issues.push(error);
            None
        }
    });
    if h_demag.is_none() {
        issues.push(format!(
            "missing H_demag field snapshot at final step {}",
            final_stats.step
        ));
    }
    if demag_phi.is_none() {
        issues.push(format!(
            "missing demag_phi field snapshot at final step {}",
            final_stats.step
        ));
    }
    if let Some(values) = &h_demag {
        if values.len() != fem.mesh.nodes.len() {
            issues.push(format!(
                "H_demag field snapshot length {} does not match FEM mesh node count {}",
                values.len(),
                fem.mesh.nodes.len()
            ));
        }
    }
    if let Some(values) = &demag_phi {
        if values.len() != fem.mesh.nodes.len() {
            issues.push(format!(
                "demag_phi field snapshot length {} does not match FEM mesh node count {}",
                values.len(),
                fem.mesh.nodes.len()
            ));
        }
    }

    let mut pair_diagnostics = Vec::new();
    if let (Some(h_demag), Some(demag_phi)) = (h_demag, demag_phi) {
        if h_demag.len() == fem.mesh.nodes.len() && demag_phi.len() == fem.mesh.nodes.len() {
            let node_pairs_by_id = fem.mesh.periodic_node_pairs.iter().fold(
                HashMap::<String, Vec<&fullmag_ir::MeshPeriodicNodePairIR>>::new(),
                |mut acc, pair| {
                    acc.entry(pair.pair_id.clone()).or_default().push(pair);
                    acc
                },
            );
            let (magnetic_nodes, _) = mesh_node_domain_sets(&fem.mesh);
            for boundary_pair in &fem.mesh.periodic_boundary_pairs {
                let node_pairs = node_pairs_by_id
                    .get(&boundary_pair.pair_id)
                    .map(Vec::as_slice)
                    .unwrap_or(&[]);
                let (diagnostics, pair_issues) = static_pbc_demag_pair_diagnostics(
                    fem,
                    &magnetic_nodes,
                    boundary_pair,
                    node_pairs,
                    &executed.result.final_magnetization,
                    &h_demag,
                    &demag_phi,
                );
                issues.extend(pair_issues);
                pair_diagnostics.push(diagnostics);
            }
        }
    }
    if pair_diagnostics.is_empty() {
        issues.push("no static PBC demag pair diagnostics could be evaluated".to_string());
    }

    let status = if issues.is_empty() { "ok" } else { "failed" };
    let payload = serde_json::json!({
        "schema_version": "fem_static_pbc_demag_seams.v1",
        "artifact_path": "diagnostics/fem_static_pbc_demag_seams.v1.json",
        "status": status,
        "step": final_stats.step,
        "time": final_stats.time,
        "solver_dt": final_stats.dt,
        "basis": "node_pairs_plus_boundary_face_integrals",
        "pair_diagnostics": pair_diagnostics,
        "issues": issues,
    });
    let artifact_path = output_dir
        .join("diagnostics")
        .join("fem_static_pbc_demag_seams.v1.json");
    if let Some(parent) = artifact_path.parent() {
        fs::create_dir_all(parent)?;
    }
    fs::write(
        artifact_path,
        serde_json::to_string_pretty(&payload).unwrap(),
    )?;

    Ok(())
}

fn field_snapshot_at_step<'a>(
    executed: &'a ExecutedRun,
    name: &str,
    step: u64,
) -> Option<&'a crate::types::FieldSnapshot> {
    executed
        .field_snapshots
        .iter()
        .rev()
        .find(|snapshot| snapshot.name == name && snapshot.step == step)
}

fn static_pbc_demag_pair_diagnostics(
    fem: &fullmag_ir::FemPlanIR,
    magnetic_nodes: &BTreeSet<u32>,
    boundary_pair: &fullmag_ir::MeshPeriodicBoundaryPairIR,
    node_pairs: &[&fullmag_ir::MeshPeriodicNodePairIR],
    magnetization: &[[f64; 3]],
    h_demag: &[[f64; 3]],
    demag_phi: &[[f64; 3]],
) -> (serde_json::Value, Vec<String>) {
    let mut issues = Vec::<String>::new();
    if node_pairs.is_empty() {
        issues.push(format!(
            "periodic boundary pair '{}' has no node pairs",
            boundary_pair.pair_id
        ));
    }
    let normal = periodic_pair_unit_normal(boundary_pair);
    if normal.is_none() {
        issues.push(format!(
            "periodic boundary pair '{}' has no usable translation or axis hint",
            boundary_pair.pair_id
        ));
    }

    let mut max_m_seam = 0.0f64;
    let mut max_h_seam = 0.0f64;
    let mut max_b_normal_flux = 0.0f64;
    let mut phi_deltas = Vec::<f64>::new();

    for pair in node_pairs {
        let node_a = pair.node_a as usize;
        let node_b = pair.node_b as usize;
        if node_a >= h_demag.len() || node_b >= h_demag.len() {
            issues.push(format!(
                "periodic boundary pair '{}' references H_demag node outside field length",
                boundary_pair.pair_id
            ));
            continue;
        }
        if node_a >= demag_phi.len() || node_b >= demag_phi.len() {
            issues.push(format!(
                "periodic boundary pair '{}' references demag_phi node outside field length",
                boundary_pair.pair_id
            ));
            continue;
        }

        let node_a_magnetic = magnetic_nodes.contains(&pair.node_a);
        let node_b_magnetic = magnetic_nodes.contains(&pair.node_b);
        if node_a_magnetic != node_b_magnetic {
            issues.push(format!(
                "periodic boundary pair '{}' maps magnetic and airbox nodes together",
                boundary_pair.pair_id
            ));
            continue;
        }
        if node_a_magnetic && (node_a >= magnetization.len() || node_b >= magnetization.len()) {
            issues.push(format!(
                "periodic boundary pair '{}' references magnetic node outside magnetization length",
                boundary_pair.pair_id
            ));
            continue;
        }

        if node_a_magnetic {
            max_m_seam = max_m_seam.max(vector_difference_norm(
                magnetization[node_a],
                magnetization[node_b],
            ));
        }
        max_h_seam = max_h_seam.max(vector_difference_norm(h_demag[node_a], h_demag[node_b]));
        phi_deltas.push(demag_phi[node_a][0] - demag_phi[node_b][0]);
        if let Some(normal) = normal {
            let b_a = demag_b_vector(fem, magnetic_nodes, node_a, magnetization, h_demag[node_a]);
            let b_b = demag_b_vector(fem, magnetic_nodes, node_b, magnetization, h_demag[node_b]);
            max_b_normal_flux =
                max_b_normal_flux.max(vector_dot(vector_subtract(b_a, b_b), normal).abs());
        }
    }

    let demag_phi_seam_max_after_offset = if phi_deltas.is_empty() {
        issues.push(format!(
            "periodic boundary pair '{}' has no phi deltas to gauge-fit",
            boundary_pair.pair_id
        ));
        0.0
    } else {
        let offset = phi_deltas.iter().sum::<f64>() / phi_deltas.len() as f64;
        phi_deltas
            .iter()
            .map(|delta| (delta - offset).abs())
            .fold(0.0f64, f64::max)
    };

    let face_pairs = mesh_periodic_boundary_face_index_pairs(&fem.mesh, boundary_pair);
    if face_pairs.is_empty() {
        issues.push(format!(
            "periodic boundary pair '{}' has no paired boundary faces for side-charge integral",
            boundary_pair.pair_id
        ));
    }
    let mut side_charge_sum = 0.0f64;
    for (source_face_index, destination_face_index) in &face_pairs {
        let Some(normal) = normal else {
            continue;
        };
        let source_normal = [-normal[0], -normal[1], -normal[2]];
        let Some(source_charge) = face_magnetic_charge_integral(
            fem,
            magnetic_nodes,
            *source_face_index,
            source_normal,
            magnetization,
        ) else {
            issues.push(format!(
                "periodic boundary pair '{}' has invalid source face {} for side-charge integral",
                boundary_pair.pair_id, source_face_index
            ));
            continue;
        };
        let Some(destination_charge) = face_magnetic_charge_integral(
            fem,
            magnetic_nodes,
            *destination_face_index,
            normal,
            magnetization,
        ) else {
            issues.push(format!(
                "periodic boundary pair '{}' has invalid destination face {} for side-charge integral",
                boundary_pair.pair_id, destination_face_index
            ));
            continue;
        };
        side_charge_sum += source_charge + destination_charge;
    }
    let side_charge_sum_abs = side_charge_sum.abs();
    let pair_status = if issues.is_empty() { "ok" } else { "failed" };

    (
        serde_json::json!({
            "pair_id": boundary_pair.pair_id,
            "status": pair_status,
            "paired_node_count": node_pairs.len(),
            "boundary_face_pair_count": face_pairs.len(),
            "m_seam_max": max_m_seam,
            "h_demag_seam_max_Apm": max_h_seam,
            "demag_phi_seam_max_after_offset_A": demag_phi_seam_max_after_offset,
            "b_normal_flux_seam_max_T": max_b_normal_flux,
            "side_magnetic_charge_sum_abs_Am": side_charge_sum_abs,
        }),
        issues,
    )
}

fn periodic_mesh(plan: &fullmag_ir::ExecutionPlanIR) -> Option<&fullmag_ir::MeshIR> {
    match &plan.backend_plan {
        BackendPlanIR::AntennaFieldOnly(_)
        | BackendPlanIR::AntennaRetainedCurrentFieldInspection(_)
        | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => None,
        BackendPlanIR::Fem(fem) => Some(&fem.mesh),
        BackendPlanIR::FemEigen(fem) => Some(&fem.mesh),
        BackendPlanIR::FemFrequencyResponse(fem) => Some(&fem.mesh),
        BackendPlanIR::Fdm(_)
        | BackendPlanIR::FdmMultilayer(_)
        | BackendPlanIR::AntennaExternalLeadInspection(_) => None,
    }
}

fn periodic_material_fields(
    plan: &fullmag_ir::ExecutionPlanIR,
) -> (
    Option<&[f64]>,
    Option<&[f64]>,
    Option<&[f64]>,
    Option<&[f64]>,
) {
    match &plan.backend_plan {
        BackendPlanIR::AntennaFieldOnly(_)
        | BackendPlanIR::AntennaRetainedCurrentFieldInspection(_)
        | BackendPlanIR::AntennaRetainedDirectFieldInspection(_) | BackendPlanIR::AntennaRetainedPreparationFieldInspection(_) => (None, None, None, None),
        BackendPlanIR::Fem(fem) => (
            fem.ms_element_field.as_deref(),
            fem.a_element_field.as_deref(),
            fem.material.ms_field.as_deref(),
            fem.material.a_field.as_deref(),
        ),
        BackendPlanIR::Fdm(_)
        | BackendPlanIR::FdmMultilayer(_)
        | BackendPlanIR::FemEigen(_)
        | BackendPlanIR::AntennaExternalLeadInspection(_)
        | BackendPlanIR::FemFrequencyResponse(_) => (None, None, None, None),
    }
}

#[derive(Debug, Clone)]
struct MeshPeriodicResidualDiagnostics {
    max_residual_m: Option<f64>,
    rms_residual_m: Option<f64>,
    status: String,
}

fn mesh_periodic_pair_residuals(
    mesh: &fullmag_ir::MeshIR,
    boundary_pair: &fullmag_ir::MeshPeriodicBoundaryPairIR,
    node_pairs: &[&fullmag_ir::MeshPeriodicNodePairIR],
) -> MeshPeriodicResidualDiagnostics {
    if node_pairs.is_empty() {
        return MeshPeriodicResidualDiagnostics {
            max_residual_m: None,
            rms_residual_m: None,
            status: "empty".to_string(),
        };
    }
    let Some(translation) = boundary_pair.translation else {
        return MeshPeriodicResidualDiagnostics {
            max_residual_m: None,
            rms_residual_m: None,
            status: "missing_translation".to_string(),
        };
    };

    let mut max_residual = 0.0f64;
    let mut sum_sq = 0.0f64;
    let mut valid_count = 0usize;
    for pair in node_pairs {
        let Some(src) = mesh.nodes.get(pair.node_a as usize) else {
            return MeshPeriodicResidualDiagnostics {
                max_residual_m: None,
                rms_residual_m: None,
                status: "invalid_node_reference".to_string(),
            };
        };
        let Some(dst) = mesh.nodes.get(pair.node_b as usize) else {
            return MeshPeriodicResidualDiagnostics {
                max_residual_m: None,
                rms_residual_m: None,
                status: "invalid_node_reference".to_string(),
            };
        };
        let residual = [
            dst[0] - src[0] - translation[0],
            dst[1] - src[1] - translation[1],
            dst[2] - src[2] - translation[2],
        ];
        let norm =
            (residual[0] * residual[0] + residual[1] * residual[1] + residual[2] * residual[2])
                .sqrt();
        max_residual = max_residual.max(norm);
        sum_sq += norm * norm;
        valid_count += 1;
    }
    let rms = (sum_sq / valid_count as f64).sqrt();
    let tolerance = boundary_pair.tolerance.unwrap_or(1e-9).max(0.0);
    let status = if max_residual > tolerance {
        "residual_exceeds_tolerance"
    } else {
        "valid"
    };

    MeshPeriodicResidualDiagnostics {
        max_residual_m: Some(max_residual),
        rms_residual_m: Some(rms),
        status: status.to_string(),
    }
}

fn mesh_boundary_nodes_by_marker(mesh: &fullmag_ir::MeshIR) -> HashMap<u32, BTreeSet<u32>> {
    let mut nodes_by_marker = HashMap::<u32, BTreeSet<u32>>::new();
    for facet in mesh.facets.iter() {
        let Some(marker) = mesh.boundary_markers.get(facet.ordinal).copied() else {
            continue;
        };
        let nodes = nodes_by_marker.entry(marker).or_default();
        nodes.extend(facet.nodes.iter().copied());
    }
    nodes_by_marker
}

fn mesh_node_domain_sets(mesh: &fullmag_ir::MeshIR) -> (BTreeSet<u32>, BTreeSet<u32>) {
    let mut magnetic_nodes = BTreeSet::new();
    let mut airbox_nodes = BTreeSet::new();
    for cell in mesh.cells.iter() {
        let marker = mesh.element_markers.get(cell.ordinal).copied().unwrap_or(1);
        let target = if marker == 0 {
            &mut airbox_nodes
        } else {
            &mut magnetic_nodes
        };
        target.extend(cell.nodes.iter().copied());
    }
    (magnetic_nodes, airbox_nodes)
}

fn mesh_periodic_domain_node_pair_counts(
    mesh: &fullmag_ir::MeshIR,
    node_pairs: &[&fullmag_ir::MeshPeriodicNodePairIR],
) -> (usize, usize) {
    let (magnetic_nodes, airbox_nodes) = mesh_node_domain_sets(mesh);
    let mut magnetic_count = 0usize;
    let mut airbox_count = 0usize;
    for pair in node_pairs {
        let node_a_is_magnetic = magnetic_nodes.contains(&pair.node_a);
        let node_b_is_magnetic = magnetic_nodes.contains(&pair.node_b);
        let node_a_is_airbox = airbox_nodes.contains(&pair.node_a);
        let node_b_is_airbox = airbox_nodes.contains(&pair.node_b);
        if node_a_is_magnetic && node_b_is_magnetic {
            magnetic_count += 1;
        } else if !node_a_is_magnetic
            && !node_b_is_magnetic
            && (node_a_is_airbox || node_b_is_airbox)
        {
            airbox_count += 1;
        }
    }
    (magnetic_count, airbox_count)
}

fn certified_mesh_periodic_boundary_face_pairs(
    certificate: &fullmag_ir::PeriodicMeshCertificateV6IR,
    pair_id: &str,
    translation: Option<[f64; 3]>,
) -> Vec<serde_json::Value> {
    certificate
        .axis_pairs
        .iter()
        .find(|axis| axis.pair_id == pair_id)
        .map(|axis| {
            axis.face_pairs
                .iter()
                .map(|face| {
                    serde_json::json!({
                        "face_a": face.face_a,
                        "face_b": face.face_b,
                        "vertex_pairs": face.vertex_pairs,
                        "translation_m": translation,
                        "translation_residual_m": face.translation_residual_max_m,
                        "area_residual_m2": face.area_residual_m2,
                        "normal_dot": face.normal_dot,
                        "source_marker": face.source_marker,
                        "destination_marker": face.destination_marker,
                        "source_element_markers": face.source_element_markers,
                        "destination_element_markers": face.destination_element_markers,
                        "orientation": if face.normal_dot <= -0.999 {
                            "opposed_normals"
                        } else {
                            "invalid"
                        },
                    })
                })
                .collect()
        })
        .unwrap_or_default()
}

#[cfg(test)]
fn mesh_periodic_boundary_face_pairs(
    mesh: &fullmag_ir::MeshIR,
    boundary_pair: &fullmag_ir::MeshPeriodicBoundaryPairIR,
) -> Vec<serde_json::Value> {
    let mut pairs = Vec::new();
    for (source_face_index, destination_face_index) in
        mesh_periodic_boundary_face_index_pairs(mesh, boundary_pair)
    {
        let normal_dot = mesh_boundary_face_unit_normal(mesh, source_face_index)
            .zip(mesh_boundary_face_unit_normal(mesh, destination_face_index))
            .map(|(source, destination)| vector_dot(source, destination));
        pairs.push(serde_json::json!({
            "face_a": source_face_index,
            "face_b": destination_face_index,
            "translation_m": boundary_pair.translation,
            "normal_dot": normal_dot,
            "orientation": if normal_dot.is_some_and(|dot| dot <= -0.999) {
                "opposed_normals"
            } else {
                "not_opposed"
            },
        }));
    }
    pairs
}

fn mesh_periodic_boundary_face_index_pairs(
    mesh: &fullmag_ir::MeshIR,
    boundary_pair: &fullmag_ir::MeshPeriodicBoundaryPairIR,
) -> Vec<(usize, usize)> {
    if boundary_pair.translation.is_none() {
        return Vec::new();
    }
    let source_faces = mesh_boundary_face_indices_by_marker(mesh, boundary_pair.marker_a);
    let destination_faces = mesh_boundary_face_indices_by_marker(mesh, boundary_pair.marker_b);
    let node_map = mesh
        .periodic_node_pairs
        .iter()
        .filter(|pair| pair.pair_id == boundary_pair.pair_id)
        .map(|pair| (pair.node_a, pair.node_b))
        .collect::<HashMap<_, _>>();
    let mut pairs = Vec::new();
    let mut used_destinations = BTreeSet::new();
    for source_face_index in source_faces {
        let Some(source_face) = mesh.facets.item_nodes(source_face_index) else {
            continue;
        };
        let Some(mapped_face) = source_face
            .iter()
            .map(|node| node_map.get(node).copied())
            .collect::<Option<Vec<_>>>()
        else {
            continue;
        };
        let mut expected = mapped_face;
        expected.sort_unstable();
        let Some(destination_face_index) = destination_faces.iter().copied().find(|index| {
            !used_destinations.contains(index)
                && mesh
                    .facets
                    .item_nodes(*index)
                    .map(|face| {
                        let mut actual = face.to_vec();
                        actual.sort_unstable();
                        actual == expected
                    })
                    .unwrap_or(false)
        }) else {
            continue;
        };
        used_destinations.insert(destination_face_index);
        pairs.push((source_face_index, destination_face_index));
    }
    pairs
}

fn mesh_boundary_face_indices_by_marker(mesh: &fullmag_ir::MeshIR, marker: u32) -> Vec<usize> {
    mesh.boundary_markers
        .iter()
        .enumerate()
        .filter_map(|(index, face_marker)| (*face_marker == marker).then_some(index))
        .collect()
}

fn mesh_boundary_face_area(mesh: &fullmag_ir::MeshIR, face_index: usize) -> Option<f64> {
    let face = mesh.facets.item_nodes(face_index)?;
    let &origin_index = face.first()?;
    let origin = mesh.nodes.get(origin_index as usize)?;
    face[1..].windows(2).try_fold(0.0, |area, edge| {
        let b = mesh.nodes.get(edge[0] as usize)?;
        let c = mesh.nodes.get(edge[1] as usize)?;
        let ab = [b[0] - origin[0], b[1] - origin[1], b[2] - origin[2]];
        let ac = [c[0] - origin[0], c[1] - origin[1], c[2] - origin[2]];
        let cross = [
            ab[1] * ac[2] - ab[2] * ac[1],
            ab[2] * ac[0] - ab[0] * ac[2],
            ab[0] * ac[1] - ab[1] * ac[0],
        ];
        Some(area + 0.5 * (cross[0] * cross[0] + cross[1] * cross[1] + cross[2] * cross[2]).sqrt())
    })
}

#[cfg(test)]
fn mesh_boundary_face_unit_normal(
    mesh: &fullmag_ir::MeshIR,
    face_index: usize,
) -> Option<[f64; 3]> {
    let face = mesh.facets.item_nodes(face_index)?;
    if face.len() != 3 {
        return None;
    }
    let a = mesh.nodes.get(face[0] as usize)?;
    let b = mesh.nodes.get(face[1] as usize)?;
    let c = mesh.nodes.get(face[2] as usize)?;
    let ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
    let ac = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    let cross = [
        ab[1] * ac[2] - ab[2] * ac[1],
        ab[2] * ac[0] - ab[0] * ac[2],
        ab[0] * ac[1] - ab[1] * ac[0],
    ];
    let norm = vector_norm(cross);
    (norm > f64::EPSILON).then_some([cross[0] / norm, cross[1] / norm, cross[2] / norm])
}

fn periodic_pair_unit_normal(
    boundary_pair: &fullmag_ir::MeshPeriodicBoundaryPairIR,
) -> Option<[f64; 3]> {
    if let Some(translation) = boundary_pair.translation {
        let norm = vector_norm(translation);
        if norm > f64::EPSILON {
            return Some([
                translation[0] / norm,
                translation[1] / norm,
                translation[2] / norm,
            ]);
        }
    }
    match boundary_pair.axis_hint.as_deref() {
        Some("x") => Some([1.0, 0.0, 0.0]),
        Some("y") => Some([0.0, 1.0, 0.0]),
        Some("z") => Some([0.0, 0.0, 1.0]),
        _ => None,
    }
}

fn vector_norm(value: [f64; 3]) -> f64 {
    (value[0] * value[0] + value[1] * value[1] + value[2] * value[2]).sqrt()
}

fn vector_difference_norm(a: [f64; 3], b: [f64; 3]) -> f64 {
    vector_norm(vector_subtract(a, b))
}

fn vector_subtract(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}

fn vector_dot(a: [f64; 3], b: [f64; 3]) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

fn material_ms_at(material: &fullmag_ir::MaterialIR, node_index: usize) -> f64 {
    material
        .ms_field
        .as_ref()
        .and_then(|values| values.get(node_index))
        .copied()
        .unwrap_or(material.saturation_magnetisation)
}

fn magnetization_vector_at(
    fem: &fullmag_ir::FemPlanIR,
    magnetic_nodes: &BTreeSet<u32>,
    node_index: usize,
    magnetization: &[[f64; 3]],
) -> Option<[f64; 3]> {
    if !magnetic_nodes.contains(&(node_index as u32)) {
        return Some([0.0, 0.0, 0.0]);
    }
    let m = magnetization.get(node_index)?;
    let ms = material_ms_at(&fem.material, node_index);
    Some([ms * m[0], ms * m[1], ms * m[2]])
}

fn demag_b_vector(
    fem: &fullmag_ir::FemPlanIR,
    magnetic_nodes: &BTreeSet<u32>,
    node_index: usize,
    magnetization: &[[f64; 3]],
    h_demag: [f64; 3],
) -> [f64; 3] {
    let magnetization = magnetization_vector_at(fem, magnetic_nodes, node_index, magnetization)
        .unwrap_or([0.0, 0.0, 0.0]);
    [
        MU0_H_PER_M * (h_demag[0] + magnetization[0]),
        MU0_H_PER_M * (h_demag[1] + magnetization[1]),
        MU0_H_PER_M * (h_demag[2] + magnetization[2]),
    ]
}

fn face_magnetic_charge_integral(
    fem: &fullmag_ir::FemPlanIR,
    magnetic_nodes: &BTreeSet<u32>,
    face_index: usize,
    normal: [f64; 3],
    magnetization: &[[f64; 3]],
) -> Option<f64> {
    let face = fem.mesh.facets.item_nodes(face_index)?;
    let area = mesh_boundary_face_area(&fem.mesh, face_index)?;
    let mut average_m_dot_n = 0.0f64;
    for node in face {
        let vector = magnetization_vector_at(fem, magnetic_nodes, *node as usize, magnetization)?;
        average_m_dot_n += vector_dot(vector, normal);
    }
    Some(area * average_m_dot_n / face.len() as f64)
}

fn artifacts_object_ids_match(a: &str, b: &str) -> bool {
    if a == b {
        return true;
    }
    let clean_a = a.strip_suffix("_geom").unwrap_or(a);
    let clean_b = b.strip_suffix("_geom").unwrap_or(b);
    clean_a == clean_b
}

fn fem_mesh_part_matches_segment(
    part: &fullmag_ir::FemMeshPartIR,
    segment: &fullmag_ir::FemObjectSegmentIR,
) -> bool {
    part.role == fullmag_ir::FemMeshPartRole::MagneticObject
        && (part
            .object_id
            .as_deref()
            .is_some_and(|id| artifacts_object_ids_match(id, &segment.object_id))
            || part
                .geometry_id
                .as_deref()
                .zip(segment.geometry_id.as_deref())
                .is_some_and(|(part_geometry, segment_geometry)| {
                    artifacts_object_ids_match(part_geometry, segment_geometry)
                })
            || artifacts_object_ids_match(&part.id, &segment.object_id))
}

fn fem_part_node_indices_for_artifact(
    fem: &fullmag_ir::FemPlanIR,
    part: &fullmag_ir::FemMeshPartIR,
) -> Vec<usize> {
    let mut nodes = BTreeSet::new();
    nodes.extend(part.node_indices.iter().map(|index| *index as usize));

    match &part.node_selector {
        fullmag_ir::FemMeshPartSelector::NodeRange { start, count }
            if part.node_indices.is_empty() =>
        {
            let start = *start as usize;
            let end = start
                .saturating_add(*count as usize)
                .min(fem.mesh.nodes.len());
            nodes.extend(start..end);
        }
        _ => {}
    }

    match &part.element_selector {
        fullmag_ir::FemMeshPartSelector::ElementRange { start, count } => {
            let start = *start as usize;
            let end = start
                .saturating_add(*count as usize)
                .min(fem.mesh.cell_count());
            for index in start..end {
                if let Some(cell_nodes) = fem.mesh.cells.item_nodes(index) {
                    nodes.extend(cell_nodes.iter().map(|index| *index as usize));
                }
            }
        }
        fullmag_ir::FemMeshPartSelector::ElementMarkerSet { markers } => {
            let markers = markers.iter().copied().collect::<BTreeSet<_>>();
            for cell in fem.mesh.cells.iter() {
                if fem
                    .mesh
                    .element_markers
                    .get(cell.ordinal)
                    .is_some_and(|marker| markers.contains(marker))
                {
                    nodes.extend(cell.nodes.iter().map(|index| *index as usize));
                }
            }
        }
        _ => {}
    }

    for face_index in &part.boundary_face_indices {
        if let Some(face) = fem.mesh.facets.item_nodes(*face_index as usize) {
            nodes.extend(face.iter().map(|index| *index as usize));
        }
    }
    match &part.boundary_face_selector {
        fullmag_ir::FemMeshPartSelector::BoundaryFaceRange { start, count }
            if part.boundary_face_indices.is_empty() =>
        {
            let start = *start as usize;
            let end = start
                .saturating_add(*count as usize)
                .min(fem.mesh.facet_count());
            for index in start..end {
                if let Some(face) = fem.mesh.facets.item_nodes(index) {
                    nodes.extend(face.iter().map(|index| *index as usize));
                }
            }
        }
        _ => {}
    }
    for global_ordinal in &part.facet_global_ordinals {
        if let Some(face_index) = fem
            .mesh
            .facets
            .global_ordinals
            .iter()
            .position(|candidate| candidate == global_ordinal)
        {
            if let Some(face) = fem.mesh.facets.item_nodes(face_index) {
                nodes.extend(face.iter().map(|index| *index as usize));
            }
        }
    }

    nodes
        .into_iter()
        .filter(|index| *index < fem.mesh.nodes.len())
        .collect()
}

fn fem_segment_node_indices_for_artifact(
    fem: &fullmag_ir::FemPlanIR,
    segment: &fullmag_ir::FemObjectSegmentIR,
) -> Vec<usize> {
    if let Some(part) = fem
        .mesh_parts
        .iter()
        .find(|part| fem_mesh_part_matches_segment(part, segment))
    {
        let node_indices = fem_part_node_indices_for_artifact(fem, part);
        if !node_indices.is_empty() {
            return node_indices;
        }
    }

    let start = segment.node_start as usize;
    let end = start
        .saturating_add(segment.node_count as usize)
        .min(fem.mesh.nodes.len());
    (start..end).collect()
}

fn write_prescribed_current_transport_artifacts(
    output_dir: &Path,
    problem: &fullmag_ir::ProblemIR,
    plan: &fullmag_ir::ExecutionPlanIR,
    context: &FieldArtifactContext,
    provenance: &crate::types::ExecutionProvenance,
) -> std::io::Result<()> {
    for module in &problem.current_modules {
        let fullmag_ir::CurrentModuleIR::CurrentTransport {
            name,
            model: fullmag_ir::CurrentTransportModelIR::PrescribedDensity,
            current_density: Some(current_density),
            solve_region,
            time_envelope,
            ..
        } = module
        else {
            continue;
        };

        let (values, coverage): (Vec<[f64; 3]>, &'static str) = match &plan.backend_plan {
            BackendPlanIR::Fdm(fdm) => {
                let total_cells = fdm.grid.cells[0] as usize
                    * fdm.grid.cells[1] as usize
                    * fdm.grid.cells[2] as usize;
                let values = match &fdm.active_mask {
                    Some(mask) => mask
                        .iter()
                        .map(|is_active| {
                            if *is_active {
                                *current_density
                            } else {
                                [0.0, 0.0, 0.0]
                            }
                        })
                        .collect(),
                    None => vec![*current_density; total_cells],
                };
                (values, "active_fdm_cells")
            }
            BackendPlanIR::Fem(fem) => {
                let mut values = vec![[0.0, 0.0, 0.0]; fem.mesh.nodes.len()];
                let mut matched_any_segment = false;
                let target_geometry = solve_region.as_deref().and_then(|region_name| {
                    resolve_current_transport_geometry(problem, region_name)
                });
                for segment in &fem.object_segments {
                    let matches_region = solve_region.as_deref().is_some_and(|region| {
                        artifacts_object_ids_match(&segment.object_id, region)
                    });
                    let matches_geometry = target_geometry.is_some_and(|geometry_name| {
                        segment
                            .geometry_id
                            .as_deref()
                            .map(|g_id| artifacts_object_ids_match(g_id, geometry_name))
                            .unwrap_or(false)
                    });
                    let matches = solve_region.is_none() || matches_region || matches_geometry;
                    if !matches {
                        continue;
                    }
                    matched_any_segment = true;
                    for index in fem_segment_node_indices_for_artifact(fem, segment) {
                        values[index] = *current_density;
                    }
                }
                if solve_region.is_none() || !matched_any_segment {
                    values.fill(*current_density);
                    (values, "full_fem_layout_uniform")
                } else {
                    (values, "solve_region_nodes")
                }
            }
            _ => continue,
        };
        let artifact_json = serde_json::json!({
            "kind": "current_transport",
            "module_name": name,
            "model": "prescribed_density",
            "unit": "A/m^2",
            "distribution": "uniform_prescribed",
            "coverage": coverage,
            "solve_region": solve_region,
            "time_envelope": time_envelope,
            "layout": context.layout.clone(),
            "provenance": artifact_provenance_json(context, provenance),
            "values": values,
        });
        let artifact_path = output_dir
            .join("current_transport")
            .join(format!("{name}.json"));
        if let Some(parent) = artifact_path.parent() {
            fs::create_dir_all(parent)?;
        }
        fs::write(
            artifact_path,
            serde_json::to_string_pretty(&artifact_json).unwrap(),
        )?;
    }

    Ok(())
}

fn resolve_current_transport_geometry<'a>(
    problem: &'a fullmag_ir::ProblemIR,
    solve_region: &str,
) -> Option<&'a str> {
    problem
        .regions
        .iter()
        .find(|region| region.name == solve_region)
        .map(|region| region.geometry.as_str())
        .or_else(|| {
            problem
                .geometry
                .entries
                .iter()
                .find(|entry| entry.name() == solve_region)
                .map(|entry| entry.name())
        })
}

pub(crate) fn write_scalars_csv(path: &Path, steps: &[StepStats]) -> std::io::Result<()> {
    let mut csv_file = fs::File::create(path)?;
    write_scalars_csv_header(&mut csv_file)?;
    for step in steps {
        write_scalar_row(&mut csv_file, step)?;
    }
    Ok(())
}

pub(crate) fn write_scalars_csv_header(writer: &mut impl Write) -> std::io::Result<()> {
    writeln!(
        writer,
        "step,time,solver_dt,mx,my,mz,E_ex,E_demag,E_ext,E_drive,E_ani,E_rotated_dmi,E_dmi,E_total,max_dm_dt,max_h_eff,max_h_demag,max_torque_Apm,max_torque_T"
    )
}

pub(crate) fn write_scalar_row(writer: &mut impl Write, step: &StepStats) -> std::io::Result<()> {
    writeln!(
        writer,
        "{},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e},{:.15e}",
        step.step,
        step.time,
        step.dt,
        step.mx,
        step.my,
        step.mz,
        step.e_ex,
        step.e_demag,
        step.e_ext,
        step.e_drive,
        step.e_ani,
        step.e_rotated_dmi,
        step.e_dmi,
        step.e_total,
        step.max_dm_dt,
        step.max_h_eff,
        step.max_h_demag,
        step.max_torque_Apm,
        step.max_torque_T
    )
}

fn write_table_autosave_artifacts(
    output_dir: &Path,
    problem: &fullmag_ir::ProblemIR,
    steps: &[StepStats],
) -> std::io::Result<()> {
    let Some(config_ir) = problem.study.sampling().table_autosave.as_ref() else {
        return Ok(());
    };
    let config = crate::table_autosave::TableAutosaveConfig::from_ir(config_ir)
        .map_err(|error| {
            Error::new(
                ErrorKind::InvalidInput,
                format!("invalid table_autosave config: {error}"),
            )
        })?
        .with_sampling_resolution(
            problem
                .problem_meta
                .runtime_metadata
                .get("sampling_resolution")
                .cloned(),
        );
    let mut store = crate::table_autosave::TableStore::new(config);
    for step in steps {
        store
            .append_if_due(step)
            .map_err(|error| Error::new(ErrorKind::InvalidInput, error))?;
    }
    if matches!(problem.study, fullmag_ir::StudyIR::Relaxation { .. }) {
        if let Some(final_step) = steps.last() {
            store
                .append_final_if_needed(final_step)
                .map_err(|error| Error::new(ErrorKind::InvalidInput, error))?;
        }
    }
    store.write_artifacts(output_dir)
}

fn write_sampling_resolution_artifact(
    output_dir: &Path,
    sampling_resolution: Option<&serde_json::Value>,
) -> std::io::Result<()> {
    let Some(sampling_resolution) = sampling_resolution else {
        return Ok(());
    };
    let sampling_dir = output_dir.join("sampling");
    fs::create_dir_all(&sampling_dir)?;
    fs::write(
        sampling_dir.join("sampling_resolution.v1.json"),
        serde_json::to_vec_pretty(&serde_json::json!({
            "schema_version": "sampling_resolution.v1",
            "sampling_resolution": sampling_resolution,
        }))?,
    )
}

fn final_native_snapshot_receipt(
    context: &FieldArtifactContext,
    executed: &ExecutedRun,
    stats: &mut StepStats,
) -> std::io::Result<
    Option<fullmag_quantities::fem_state_snapshot_receipt::FemLocalNodeSnapshotReceipt>,
> {
    use fullmag_quantities::fem_state_snapshot_receipt::{
        parse_fem_snapshot_receipt, FEM_FINAL_SNAPSHOT_RECEIPT_ARTIFACT,
    };
    let mut artifacts = executed
        .auxiliary_artifacts
        .iter()
        .filter(|artifact| artifact.relative_path == FEM_FINAL_SNAPSHOT_RECEIPT_ARTIFACT);
    let Some(artifact) = artifacts.next() else {
        return Ok(None);
    };
    if artifacts.next().is_some()
        || context
            .layout
            .get("backend")
            .and_then(serde_json::Value::as_str)
            != Some("fem")
        || !matches!(
            executed.provenance.execution_engine.as_str(),
            "fem_cpu_native" | "fem_native_gpu"
        )
    {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "ambiguous or nonnative final FEM snapshot receipt",
        ));
    }
    let receipt = parse_fem_snapshot_receipt(&artifact.bytes)
        .map_err(|message| Error::new(ErrorKind::InvalidData, message))?;
    receipt
        .validate_snapshot(
            receipt.snapshot_step,
            receipt.snapshot_time_s,
            receipt.snapshot_solver_dt_s,
            &executed.result.final_magnetization,
        )
        .map_err(|message| Error::new(ErrorKind::InvalidData, message))?;
    // A sampled diagnostic trace can omit the final endpoint. The receipt
    // captured with final m is the authority for this artifact's timestamp.
    stats.step = receipt.snapshot_step;
    stats.time = receipt.snapshot_time_s;
    stats.dt = receipt.snapshot_solver_dt_s;
    Ok(Some(receipt))
}
fn final_native_node_map(
    executed: &ExecutedRun,
    receipt: Option<&fullmag_quantities::fem_state_snapshot_receipt::FemLocalNodeSnapshotReceipt>,
) -> std::io::Result<Option<fullmag_quantities::fem_local_node_map::FemLocalNodeIndexMap>> {
    use fullmag_quantities::fem_local_node_map::{
        parse_fem_local_node_map, FEM_FINAL_NODE_MAP_ARTIFACT,
    };
    let mut artifacts = executed
        .auxiliary_artifacts
        .iter()
        .filter(|artifact| artifact.relative_path == FEM_FINAL_NODE_MAP_ARTIFACT);
    let map = artifacts
        .next()
        .map(|artifact| parse_fem_local_node_map(&artifact.bytes))
        .transpose()
        .map_err(|message| Error::new(ErrorKind::InvalidData, message))?;
    if artifacts.next().is_some() || (map.is_some() && receipt.is_none()) {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "ambiguous or unbound final FEM node map",
        ));
    }
    if let Some(receipt) = receipt {
        receipt
            .validate_node_map(map.as_ref())
            .map_err(|message| Error::new(ErrorKind::InvalidData, message))?;
    }
    Ok(map)
}

pub(crate) fn write_field_file(
    path: &Path,
    context: &FieldArtifactContext,
    provenance: &crate::types::ExecutionProvenance,
    observable: &str,
    step: u64,
    time: f64,
    solver_dt: f64,
    values: &[[f64; 3]],
) -> std::io::Result<()> {
    write_field_file_with_native_snapshot(path, context, provenance, observable, step, time, solver_dt, values, None, None)
}

#[allow(clippy::too_many_arguments)]
fn write_field_file_with_native_snapshot(
    path: &Path,
    context: &FieldArtifactContext,
    provenance: &crate::types::ExecutionProvenance,
    observable: &str,
    step: u64,
    time: f64,
    solver_dt: f64,
    values: &[[f64; 3]],
    snapshot_receipt: Option<
        &fullmag_quantities::fem_state_snapshot_receipt::FemLocalNodeSnapshotReceipt,
    >,
    node_map: Option<&fullmag_quantities::fem_local_node_map::FemLocalNodeIndexMap>,
) -> std::io::Result<()> {
    let mut layout = context.layout.clone();
    if observable == "m" {
        let semantics = context
            .magnetization_field_semantics
            .as_ref()
            .map_err(|error| {
                Error::new(
                    ErrorKind::InvalidData,
                    format!("FEM magnetization field semantics unavailable: {error}"),
                )
            })?;
        if let Some(semantics) = semantics {
            if values.len() != semantics.active_node_mask.len() {
                return Err(Error::new(
                    ErrorKind::InvalidData,
                    format!(
                        "FEM H1/P1 magnetization payload length {} does not match the declared node count {}",
                        values.len(),
                        semantics.active_node_mask.len()
                    ),
                ));
            }
            if values
                .iter()
                .flat_map(|value| value.iter())
                .any(|component| !component.is_finite())
            {
                return Err(Error::new(
                    ErrorKind::InvalidData,
                    "FEM H1/P1 magnetization payload contains a non-finite value",
                ));
            }
            let layout_object = layout.as_object_mut().ok_or_else(|| {
                Error::new(
                    ErrorKind::InvalidData,
                    "magnetization field layout is not a JSON object",
                )
            })?;
            let field_semantics = serde_json::to_value(semantics)
                .map_err(|error| Error::new(ErrorKind::InvalidData, error))?;
            layout_object.insert("field_semantics".to_string(), field_semantics);
        }
    }
    let mut field_json = serde_json::json!({
        "observable": observable,
        "unit": field_unit(observable),
        "step": step,
        "time": time,
        "solver_dt": solver_dt,
        "layout": layout,
        "provenance": artifact_provenance_json(context, provenance),
        "values": values,
    });
    if let Some(receipt) = snapshot_receipt {
        if observable != "m"
            || context
                .layout
                .get("backend")
                .and_then(serde_json::Value::as_str)
                != Some("fem")
            || !matches!(
                provenance.execution_engine.as_str(),
                "fem_cpu_native" | "fem_native_gpu"
            )
        {
            return Err(Error::new(
                ErrorKind::InvalidData,
                "native state receipt requires native FEM m output",
            ));
        }
        receipt
            .validate_snapshot(step, time, solver_dt, values)
            .map_err(|message| Error::new(ErrorKind::InvalidData, message))?;
        receipt
            .validate_node_map(node_map)
            .map_err(|message| Error::new(ErrorKind::InvalidData, message))?;
        field_json
            .as_object_mut()
            .expect("field artifact is an object")
            .insert(
                "native_state_snapshot".into(),
                serde_json::to_value(receipt)?,
            );
    }
    if let Some(map) = node_map {
        if snapshot_receipt.is_none() {
            return Err(Error::new(
                ErrorKind::InvalidData,
                "native node map requires snapshot receipt",
            ));
        }
        field_json
            .as_object_mut()
            .expect("field artifact is an object")
            .insert("native_node_map".into(), serde_json::to_value(map)?);
    }
    if observable == "m" {
        let layout = field_json.get("layout").ok_or_else(|| {
            Error::new(
                ErrorKind::InvalidData,
                "magnetization field layout is missing",
            )
        })?;
        let backend = layout
            .get("backend")
            .and_then(serde_json::Value::as_str)
            .map(str::to_owned)
            .ok_or_else(|| {
                Error::new(
                    ErrorKind::InvalidData,
                    "magnetization field layout has no backend identity",
                )
            })?;
        let layout_bytes = serde_json::to_vec(layout)
            .map_err(|error| Error::new(ErrorKind::InvalidData, error))?;
        let layout_sha256 = format!("{:x}", Sha256::digest(layout_bytes));
        field_json
            .as_object_mut()
            .expect("field artifact JSON is an object")
            .insert(
                "state_identity".into(),
                serde_json::json!({
                    "schema_version": "magnetization_state.v1",
                    "backend": backend,
                    "layout_sha256": layout_sha256,
                    "sample_count": values.len(),
                }),
            );
    }
    if node_map.is_some() {
        validate_mapped_state_byte_budget(
            &field_json,
            fullmag_quantities::fem_local_node_map::MAX_FEM_MAPPED_STATE_JSON_BYTES,
        )?;
    }
    fs::write(path, serde_json::to_string_pretty(&field_json).unwrap())
}

fn validate_mapped_state_byte_budget(
    value: &serde_json::Value,
    max_bytes: usize,
) -> std::io::Result<()> {
    struct Budget {
        used: usize,
        max_bytes: usize,
    }
    impl std::io::Write for Budget {
        fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
            if bytes.len() > self.max_bytes.saturating_sub(self.used) {
                return Err(Error::new(
                    ErrorKind::InvalidData,
                    "mapped native FEM state exceeds the shared source JSON budget",
                ));
            }
            self.used += bytes.len();
            Ok(bytes.len())
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    serde_json::to_writer_pretty(Budget { used: 0, max_bytes }, value)
        .map_err(|error| Error::new(ErrorKind::InvalidData, error))
}

#[derive(Debug, Clone)]
struct MultilayerFieldLayer {
    value_offset: usize,
    value_count: usize,
    manifest_entry: serde_json::Value,
    directory: String,
}

pub(crate) fn write_field_snapshot_artifact(
    fields_dir: &Path,
    context: &FieldArtifactContext,
    provenance: &crate::types::ExecutionProvenance,
    snapshot: &crate::types::FieldSnapshot,
) -> std::io::Result<()> {
    let observable_dir = fields_dir.join(&snapshot.name);
    fs::create_dir_all(&observable_dir)?;

    let Some(layers) = multilayer_field_layers(&context.layout)? else {
        let snapshot_path = observable_dir.join(format!("step_{:06}.json", snapshot.step));
        return write_canonical_field_snapshot_file(&snapshot_path, context, provenance, snapshot);
    };

    if snapshot.component_count != 3 {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "multilayer field snapshots require three components",
        ));
    }

    let expected_len = layers
        .iter()
        .map(|layer| layer.value_offset.saturating_add(layer.value_count))
        .max()
        .unwrap_or(0);
    if expected_len != snapshot.sample_count() {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "multilayer field snapshot '{}' has {} values, expected {} from artifact layout",
                snapshot.name,
                snapshot.sample_count(),
                expected_len
            ),
        ));
    }

    write_multilayer_field_manifest(&observable_dir, context, &snapshot.name, &layers)?;

    for layer in &layers {
        let layer_dir = observable_dir.join(&layer.directory);
        fs::create_dir_all(&layer_dir)?;
        let start = layer.value_offset * usize::from(snapshot.component_count);
        let end = start + layer.value_count * usize::from(snapshot.component_count);
        let snapshot_path = layer_dir.join(format!("step_{:06}.json", snapshot.step));
        write_layer_field_file(
            &snapshot_path,
            context,
            provenance,
            &snapshot.name,
            snapshot.step,
            snapshot.time,
            snapshot.solver_dt,
            snapshot.revision,
            layer,
            &snapshot.values[start..end],
        )?;
    }

    Ok(())
}

fn write_canonical_field_snapshot_file(
    path: &Path,
    context: &FieldArtifactContext,
    provenance: &crate::types::ExecutionProvenance,
    snapshot: &crate::types::FieldSnapshot,
) -> std::io::Result<()> {
    if snapshot.component_count == 0
        || snapshot.values.len() % usize::from(snapshot.component_count) != 0
        || snapshot.revision == 0
    {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!(
                "invalid canonical field snapshot '{}' shape or revision",
                snapshot.name
            ),
        ));
    }
    let values = if snapshot.component_count == 3 && snapshot.location == "sample" {
        serde_json::json!(snapshot
            .values
            .chunks_exact(3)
            .map(|value| [value[0], value[1], value[2]])
            .collect::<Vec<_>>())
    } else {
        serde_json::json!(snapshot.values)
    };
    let mut field_provenance = artifact_provenance_json(context, provenance);
    if !provenance.transport_modules.is_empty() {
        field_provenance["transport_modules"] = serde_json::json!(provenance.transport_modules);
    }
    if !provenance.executed_physics_module_ids.is_empty() {
        field_provenance["executed_physics_module_ids"] =
            serde_json::json!(provenance.executed_physics_module_ids);
    }
    let field_json = serde_json::json!({
        "observable": snapshot.name,
        "unit": field_unit(&snapshot.name),
        "step": snapshot.step,
        "time": snapshot.time,
        "solver_dt": snapshot.solver_dt,
        "component_count": snapshot.component_count,
        "component_order": snapshot.component_order,
        "location": snapshot.location,
        "scope": snapshot.scope,
        "revision": snapshot.revision,
        "layout": context.layout,
        "provenance": field_provenance,
        "values": values,
    });
    fs::write(path, serde_json::to_string_pretty(&field_json).unwrap())
}

fn multilayer_field_layers(
    layout: &serde_json::Value,
) -> std::io::Result<Option<Vec<MultilayerFieldLayer>>> {
    if layout.get("backend").and_then(serde_json::Value::as_str) != Some("fdm_multilayer") {
        return Ok(None);
    }
    if let Some(error) = layout
        .get("layout_error")
        .and_then(serde_json::Value::as_str)
    {
        return Err(Error::new(
            ErrorKind::InvalidData,
            format!("invalid fdm_multilayer artifact layout: {error}"),
        ));
    }
    let Some(raw_layers) = layout.get("layers").and_then(serde_json::Value::as_array) else {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "fdm_multilayer artifact layout is missing layers",
        ));
    };
    if raw_layers.is_empty() {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "fdm_multilayer artifact layout has no native layers",
        ));
    }

    let mut seen_ids = HashMap::<String, usize>::new();
    let layers = raw_layers
        .iter()
        .enumerate()
        .map(|(index, raw)| {
            let base_id = raw
                .get("magnet_name")
                .and_then(serde_json::Value::as_str)
                .filter(|value| !value.trim().is_empty())
                .map(str::to_string)
                .unwrap_or_else(|| format!("layer-{index}"));
            let count = seen_ids.entry(base_id.clone()).or_insert(0);
            *count += 1;
            let id = if *count == 1 {
                base_id
            } else {
                format!("{base_id}-{}", *count)
            };
            let directory = format!("layer-{}", sanitize_layer_id(&id));
            let value_offset = json_usize_field(raw, "value_offset")?;
            let value_count = json_usize_field(raw, "value_count")?;
            let manifest_entry = serde_json::json!({
                "id": id,
                "layer_id": raw.get("layer_id").cloned().unwrap_or(serde_json::Value::Null),
                "object_id": raw.get("object_id").cloned().unwrap_or(serde_json::Value::Null),
                "magnet_name": raw.get("magnet_name").cloned().unwrap_or(serde_json::Value::Null),
                "directory": directory,
                "file_pattern": format!("{directory}/step_{{step:06}}.json"),
                "native_grid": raw.get("native_grid").cloned().unwrap_or(serde_json::Value::Null),
                "native_cell_size": raw.get("native_cell_size").cloned().unwrap_or(serde_json::Value::Null),
                "native_origin": raw.get("native_origin").cloned().unwrap_or(serde_json::Value::Null),
                "native_grid_fingerprint": raw.get("native_grid_fingerprint").cloned().unwrap_or(serde_json::Value::Null),
                "native_region_mask": raw.get("native_region_mask").cloned().unwrap_or(serde_json::Value::Null),
                "native_region_legend": raw.get("native_region_legend").cloned().unwrap_or(serde_json::Value::Null),
                "material_fields": raw.get("material_fields").cloned().unwrap_or(serde_json::Value::Null),
                "convolution_grid": raw.get("convolution_grid").cloned().unwrap_or(serde_json::Value::Null),
                "convolution_cell_size": raw.get("convolution_cell_size").cloned().unwrap_or(serde_json::Value::Null),
                "transfer_kind": raw.get("transfer_kind").cloned().unwrap_or(serde_json::Value::Null),
                "active_mask_present": raw.get("active_mask_present").cloned().unwrap_or(serde_json::Value::Null),
                "active_cell_count": raw.get("active_cell_count").cloned().unwrap_or(serde_json::Value::Null),
                "inactive_cell_count": raw.get("inactive_cell_count").cloned().unwrap_or(serde_json::Value::Null),
                "value_offset": value_offset,
                "value_count": value_count,
                "vector_shape": [value_count, 3],
            });
            Ok(MultilayerFieldLayer {
                value_offset,
                value_count,
                manifest_entry,
                directory,
            })
        })
        .collect::<std::io::Result<Vec<_>>>()?;

    Ok(Some(layers))
}

fn write_multilayer_field_manifest(
    observable_dir: &Path,
    context: &FieldArtifactContext,
    observable: &str,
    layers: &[MultilayerFieldLayer],
) -> std::io::Result<()> {
    let manifest = serde_json::json!({
        "schema_version": "fdm_multilayer_field_manifest.v1",
        "observable": observable,
        "unit": field_unit(observable),
        "build_identity": build_identity_json(),
        "storage_layout": "per_layer_json",
        "component_order": ["x", "y", "z"],
        "layer_count": layers.len(),
        "layers": layers.iter().map(|layer| layer.manifest_entry.clone()).collect::<Vec<_>>(),
        "layout": context.layout.clone(),
        "provenance": context.execution_resolution.as_ref().map(|resolution| {
            serde_json::json!({
                "execution_resolution": resolution,
            })
        }),
    });
    fs::write(
        observable_dir.join("manifest.json"),
        serde_json::to_string_pretty(&manifest).unwrap(),
    )
}

fn write_layer_field_file(
    path: &Path,
    context: &FieldArtifactContext,
    provenance: &crate::types::ExecutionProvenance,
    observable: &str,
    step: u64,
    time: f64,
    solver_dt: f64,
    revision: u64,
    layer: &MultilayerFieldLayer,
    values: &[f64],
) -> std::io::Result<()> {
    if values.len() % 3 != 0 {
        return Err(Error::new(
            ErrorKind::InvalidData,
            "multilayer field snapshot values are not divisible by three",
        ));
    }
    let nested_values = values
        .chunks_exact(3)
        .map(|value| [value[0], value[1], value[2]])
        .collect::<Vec<_>>();
    let mut field_provenance = artifact_provenance_json(context, provenance);
    if !provenance.transport_modules.is_empty() {
        field_provenance["transport_modules"] = serde_json::json!(provenance.transport_modules);
    }
    let field_json = serde_json::json!({
        "observable": observable,
        "unit": field_unit(observable),
        "step": step,
        "time": time,
        "solver_dt": solver_dt,
        "component_count": 3,
        "component_order": "xyz",
        "location": "cell",
        "scope": "layer",
        "revision": revision,
        "layer": layer.manifest_entry.clone(),
        "layout": context.layout.clone(),
        "provenance": field_provenance,
        "values": nested_values,
    });
    fs::write(path, serde_json::to_string_pretty(&field_json).unwrap())
}

fn json_usize_field(value: &serde_json::Value, field: &str) -> std::io::Result<usize> {
    value
        .get(field)
        .and_then(serde_json::Value::as_u64)
        .and_then(|raw| usize::try_from(raw).ok())
        .ok_or_else(|| {
            Error::new(
                ErrorKind::InvalidData,
                format!("fdm_multilayer artifact layer is missing numeric {field}"),
            )
        })
}

fn sanitize_layer_id(id: &str) -> String {
    let sanitized = id
        .chars()
        .map(|ch| {
            if ch.is_ascii_alphanumeric() || matches!(ch, '-' | '_' | '.') {
                ch
            } else {
                '_'
            }
        })
        .collect::<String>();
    if sanitized.is_empty() {
        "unnamed".to_string()
    } else {
        sanitized
    }
}

fn retained_current_field_layout(
    inspection: &fullmag_ir::AntennaRetainedCurrentFieldPlanIR,
) -> serde_json::Value {
    retained_field_layout(&inspection.stage, &inspection.field_sampling,
        "antenna_retained_current_field_inspection")
}

fn retained_direct_field_layout(
    inspection: &fullmag_ir::AntennaRetainedDirectFieldPlanV2,
) -> serde_json::Value {
    let mut layout = retained_field_layout(&inspection.stage, &inspection.field_sampling,
        "antenna_retained_direct_field_inspection");
    layout["retained_source_preparation"] = serde_json::json!(inspection.preparation_asset);
    layout
}

fn retained_preparation_field_layout(
    inspection: &fullmag_ir::AntennaRetainedPreparationFieldPlanIR,
) -> serde_json::Value {
    let mut layout = retained_field_layout(&inspection.stage, &inspection.field_sampling,
        "antenna_retained_preparation_field_inspection");
    layout["retained_source_preparation"] = serde_json::json!(inspection.preparation_asset);
    layout
}

fn retained_field_layout(
    stage: &fullmag_ir::AntennaFieldSolveStageIR, sampling: &fullmag_ir::AntennaFieldSamplingPlanIR,
    backend: &str,
) -> serde_json::Value {
    serde_json::json!({
        "backend": backend,
        "stage_id": stage.id,
        "port_mode_ids": stage.port_mode_ids,
        "source_object_id": stage.source_object_id,
        "retained_current_source": stage.retained_current_source,
        "source_authorization": "unresolved",
        "source_mesh_name": null,
        "source_topology_fingerprint": null,
        "source_node_count": null,
        "source_element_count": null,
        "sampling_node_count": sampling.positions_xyz_m.len(),
        "sampling_element_count": sampling.cells.len(),
        "sampling_topology_digest": sampling.topology_digest,
        "field_sampling": {
            "domain": sampling.domain,
            "carrier_kind": sampling.carrier_kind,
            "location": sampling.location,
            "topology_digest": sampling.topology_digest,
        },
        "magnetic_state_present": false,
        "magnetization_state": "not_applicable",
    })
}

pub(crate) fn field_layout(plan: &fullmag_ir::ExecutionPlanIR) -> serde_json::Value {
    match &plan.backend_plan {
        BackendPlanIR::AntennaRetainedCurrentFieldInspection(inspection) => {
            retained_current_field_layout(inspection)
        }
        BackendPlanIR::AntennaRetainedDirectFieldInspection(inspection) => {
            retained_direct_field_layout(inspection)
        }
        BackendPlanIR::AntennaRetainedPreparationFieldInspection(inspection) => {
            retained_preparation_field_layout(inspection)
        }
        BackendPlanIR::AntennaFieldOnly(antenna) => serde_json::json!({
            "backend": "antenna_field_only",
            "stage_id": antenna.stage_id,
            "port_mode_id": antenna.port_mode_id,
            "source_object_id": antenna.source_object_id,
            "source_mesh_name": antenna.source_mesh.mesh_name,
            "source_topology_fingerprint": antenna.source_mesh.topology_fingerprint_v6(),
            "source_node_count": antenna.source_mesh.nodes.len(),
            "source_element_count": antenna.source_mesh.cell_count(),
            "field_sampling": antenna.field_sampling,
            "magnetic_state_present": false,
        }),
        BackendPlanIR::AntennaExternalLeadInspection(inspection) => serde_json::json!({
            "backend": "antenna_external_lead_inspection",
            "stage_id": inspection.input.stage.id,
            "port_mode_id": inspection.input.port.id,
            "output_id": inspection.output_id,
            "magnetization_state": "not_applicable",
            "conductor_topology_fingerprint": inspection.input.combined_mesh.topology_fingerprint_v6(),
            "sampling_topology_digest": inspection.input.field_sampling.topology_digest,
        }),
        BackendPlanIR::Fdm(fdm) => {
            let total_cells = fdm.grid.cells[0] as usize
                * fdm.grid.cells[1] as usize
                * fdm.grid.cells[2] as usize;
            let active_cell_count = fdm
                .active_mask
                .as_ref()
                .map(|mask| mask.iter().filter(|is_active| **is_active).count())
                .unwrap_or(total_cells);
            let inactive_cell_count = total_cells.saturating_sub(active_cell_count);
            serde_json::json!({
                "backend": "fdm",
                "origin_m": fdm.origin_m,
                "grid_cells": fdm.grid.cells,
                "cell_size": fdm.cell_size,
                "grid_fingerprint": fdm
                    .grid_certificate
                    .as_ref()
                    .map(|certificate| certificate.grid_fingerprint.clone()),
                "total_cell_count": total_cells,
                "active_mask_present": fdm.active_mask.is_some(),
                "active_mask": fdm.active_mask.as_ref().map(|mask| mask.as_slice()),
                "active_cell_count": active_cell_count,
                "inactive_cell_count": inactive_cell_count,
                "active_fraction": if total_cells > 0 {
                    active_cell_count as f64 / total_cells as f64
                } else {
                    0.0
                },
            })
        }
        BackendPlanIR::FdmMultilayer(ml) => {
            let mut value_offset = 0usize;
            let layers = ml
                .layers
                .iter()
                .map(|layer| {
                    let descriptor = fdm_multilayer_layer_artifact_descriptor(layer, value_offset)?;
                    value_offset = value_offset
                        .checked_add(multilayer_native_cell_count(layer)?)
                        .ok_or_else(|| {
                            Error::new(
                                ErrorKind::InvalidData,
                                "fdm_multilayer artifact value offsets overflow usize",
                            )
                        })?;
                    Ok(descriptor)
                })
                .collect::<std::io::Result<Vec<_>>>();
            match layers {
                Ok(layers) => serde_json::json!({
                    "backend": "fdm_multilayer",
                    "mode": ml.mode,
                    "common_cells": ml.common_cells,
                    "layer_count": ml.layers.len(),
                    "layers": layers,
                    "planner_summary": ml.planner_summary,
                }),
                Err(error) => serde_json::json!({
                    "backend": "fdm_multilayer",
                    "mode": ml.mode,
                    "common_cells": ml.common_cells,
                    "layer_count": ml.layers.len(),
                    "layers": [],
                    "layout_error": error.to_string(),
                    "planner_summary": ml.planner_summary,
                }),
            }
        }
        BackendPlanIR::Fem(fem) => serde_json::json!({
            "backend": "fem",
            "mesh_name": fem.mesh.mesh_name,
            "mesh_source": fem.mesh_source,
            "fe_order": fem.fe_order,
            "hmax": fem.hmax,
            "topology_fingerprint": fem.mesh.topology_fingerprint_v6(),
            "n_nodes": fem.mesh.nodes.len(),
            "n_elements": fem.mesh.cell_count(),
        }),
        BackendPlanIR::FemEigen(fem) => serde_json::json!({
            "backend": "fem_eigen",
            "mesh_name": fem.mesh.mesh_name,
            "mesh_source": fem.mesh_source,
            "fe_order": fem.fe_order,
            "hmax": fem.hmax,
            "topology_fingerprint": fem.mesh.topology_fingerprint_v6(),
            "n_nodes": fem.mesh.nodes.len(),
            "n_elements": fem.mesh.cell_count(),
            "mode_count": fem.count,
            "operator": fem.operator,
            "material": {
                "saturation_magnetisation": fem.material.saturation_magnetisation,
                "effective_magnetisation": fem.k0_kittel_validation.as_ref()
                    .and_then(|validation| validation.material.effective_magnetisation),
            },
            "k0_kittel_validation": fem.k0_kittel_validation,
        }),
        BackendPlanIR::FemFrequencyResponse(fem) => serde_json::json!({
            "backend": "fem_frequency_response",
            "mesh_name": fem.mesh.mesh_name,
            "mesh_source": fem.mesh_source,
            "fe_order": fem.fe_order,
            "hmax": fem.hmax,
            "topology_fingerprint": fem.mesh.topology_fingerprint_v6(),
            "n_nodes": fem.mesh.nodes.len(),
            "n_elements": fem.mesh.cell_count(),
            "frequency_count": fem.frequencies_hz.values_hz.len(),
            "operator": fem.operator,
        }),
    }
}

pub(crate) fn field_unit(observable: &str) -> &'static str {
    let base_observable = observable
        .split_once('.')
        .map_or(observable, |(base, _)| base);
    if observable == "m" {
        return "1";
    }
    if let Some(spec) = fullmag_quantities::quantity_spec(base_observable) {
        return spec.unit;
    }
    match base_observable {
        "H_OE" => "A/m",
        other => panic!("unsupported observable '{}'", other),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn retained_current_inspection_plan() -> ExecutionPlanIR {
        let mut wire: serde_json::Value = serde_json::from_str(include_str!(
            "../../../tests/fixtures/runtime/antenna-standalone-pipeline.json"
        )).unwrap();
        let ir = &mut wire["ir"];
        ir["study"]["selection"] = serde_json::json!({"stage_id":"inspect_antenna", "port_mode_id":"port"});
        ir["geometry_assets"]["fem_mesh_assets"].as_array_mut().unwrap()
            .retain(|asset| asset["geometry_name"] == "probe");
        let stage = &mut ir["antenna_field_solve_stages"][0];
        stage["retained_current_source"] = serde_json::json!({
            "kind":"published_inspection", "project_id":"project-source", "run_id":"run-source",
            "task_id":"task-source", "attempt_id":"attempt-source", "ownership_epoch":"1",
            "artifact_id":"artifact-source", "object_ref":"a".repeat(64)
        });
        stage["oersted_realization"] = "analytic_rt0_surface".into();
        stage["surface_field_policy"] = serde_json::json!({
            "policy_version":fullmag_ir::ANTENNA_SURFACE_FIELD_POLICY_VERSION,
            "limits":{"total":vec![1_000_000_u64;14], "per_target":vec![100_000_u64;14],
                "maximum_raw_integer_bits":8192, "maximum_reduced_fraction_bits":8192,
                "maximum_lifetime_peak_rss_bytes":268435456, "guard_interval_events":128,
                "maximum_total_seconds":600.0, "maximum_target_seconds":120.0},
            "tolerances":{"absolute_field_apm":1e-9,"relative_field":1e-5,"cancellation_floor_apm":1e-6,
                "scalar_relative_80":1e-45,"scalar_relative_120":1e-55,"angle_relative_80":1e-45,"angle_relative_120":1e-55,
                "binary_scalar_epsilon_factor":16.0,"binary_roundoff_epsilon_factor":64.0,
                "binary_cancellation_limit":1e8,"highprecision_cancellation_limit":1e40}
        });
        let problem = serde_json::from_value(ir.take()).unwrap();
        let inspection = fullmag_plan::plan_retained_current_field_inspection(&problem, "inspect_antenna", "port").unwrap();
        let mut plan = test_fem_execution_plan();
        plan.backend_plan = BackendPlanIR::AntennaRetainedCurrentFieldInspection(inspection);
        plan
    }

    fn retained_preparation_inspection_plan() -> ExecutionPlanIR {
        let mut plan = retained_current_inspection_plan();
        let BackendPlanIR::AntennaRetainedCurrentFieldInspection(current) = &plan.backend_plan else { unreachable!() };
        let asset = fullmag_ir::AntennaSourcePreparationAssetRefIR {
            asset_id: "script-file-preparation".into(), content_sha256: "b".repeat(64),
        };
        let mut stage = current.stage.clone();
        stage.retained_source_preparation = Some(asset.clone());
        plan.backend_plan = BackendPlanIR::AntennaRetainedPreparationFieldInspection(
            fullmag_ir::AntennaRetainedPreparationFieldPlanIR {
                schema_version: fullmag_ir::ANTENNA_RETAINED_PREPARATION_FIELD_PLAN_SCHEMA.into(),
                stage, field_sampling: current.field_sampling.clone(),
                requested_execution: current.requested_execution.clone(), preparation_asset: asset,
            });
        plan
    }

    #[test]
    fn retained_preparation_metadata_is_thin_nonmagnetic_and_preserves_execution() {
        let plan = retained_preparation_inspection_plan();
        let layout = field_layout(&plan);
        assert_eq!(mesh_runtime_metadata(&plan), layout);
        assert_eq!(layout["backend"], "antenna_retained_preparation_field_inspection");
        assert_eq!(layout["retained_source_preparation"]["asset_id"], "script-file-preparation");
        assert_eq!(layout["source_authorization"], "unresolved");
        assert_eq!(layout["magnetic_state_present"], false);
        for key in ["source_mesh_name", "source_topology_fingerprint", "source_node_count", "source_element_count"] {
            assert!(layout[key].is_null(), "{key}");
        }
        assert_eq!(layout["sampling_node_count"], 4);
        assert_eq!(layout["sampling_element_count"], 1);
        assert!(layout["field_sampling"].get("positions_xyz_m").is_none());
        assert!(layout["field_sampling"].get("cells").is_none());
        let mut unrelated_problem = fullmag_ir::ProblemIR::bootstrap_example();
        unrelated_problem.backend_policy.execution_precision = fullmag_ir::ExecutionPrecision::Single;
        unrelated_problem.validation_profile.execution_mode = ExecutionMode::Extended;
        let request = effective_execution_request(&unrelated_problem, &plan);
        assert_eq!((request.backend.as_str(), request.device.as_str(), request.precision.as_str(), request.mode.as_str()),
            ("fem", "cpu", "double", "strict"));
    }

    #[test]
    fn retained_inspection_metadata_never_substitutes_target_for_source() {
        let plan = retained_current_inspection_plan();
        let layout = field_layout(&plan);
        assert_eq!(mesh_runtime_metadata(&plan), layout);
        for key in ["source_mesh_name", "source_topology_fingerprint", "source_node_count", "source_element_count"] {
            assert!(layout[key].is_null(), "{key}");
        }
        assert_eq!(layout["source_authorization"], "unresolved");
        assert_eq!(layout["sampling_node_count"], 4);
        assert_eq!(layout["sampling_element_count"], 1);
        assert!(layout["field_sampling"].get("positions_xyz_m").is_none());
        assert!(layout["field_sampling"].get("cells").is_none());
        assert_eq!(layout["magnetic_state_present"], false);
        let mut unrelated_problem = fullmag_ir::ProblemIR::bootstrap_example();
        unrelated_problem.backend_policy.execution_precision = fullmag_ir::ExecutionPrecision::Single;
        unrelated_problem.validation_profile.execution_mode = ExecutionMode::Extended;
        let request = effective_execution_request(&unrelated_problem, &plan);
        assert_eq!(request.backend, "fem");
        assert_eq!(request.device, "cpu");
        assert_eq!(request.precision, "double");
        assert_eq!(request.mode, "strict");
    }

    #[test]
    fn retained_inspection_cannot_create_magnetic_runtime_state() {
        for plan in [retained_current_inspection_plan(), retained_preparation_inspection_plan()] {
            let problem = fullmag_ir::ProblemIR::bootstrap_example();
            for result in [
                crate::require_resolved_runtime_sampling(&problem, &plan),
                crate::study_magnetization_layout_for_plan(&plan).map(|_| ()),
                crate::resolve_planned_runtime_engine(&problem, &plan).map(|_| ()),
                crate::resolve_planned_runtime_capabilities(&problem, &plan).map(|_| ()),
                crate::dispatch::stage_step_time_frame(&problem, &plan).map(|_| ()),
            ] {
                assert!(result.unwrap_err().message.contains("field_only_plan_not_executable_as_llg"));
            }
            assert!(crate::types::StageFemMeshAsset::build_from_backend_plan(&plan.backend_plan).is_none());
            assert!(crate::types::FemStageExecutionContext::from_backend_plan(&plan.backend_plan).is_none());
            assert!(crate::frozen_spins_runtime_status_for_backend_plan(&plan.backend_plan).unwrap().is_none());
            let resolver = crate::observation::ObservationProviderResolver::from_backend_plan(&plan.backend_plan);
            assert!(!resolver.retains_idle_runtime());
            assert!(resolver.terminal_snapshot_quantity_ids().is_empty());
            assert_eq!(resolver.policy("m"), crate::observation::ObservationProviderPolicy::UnavailableAfterStage);
        }
    }

    #[test]
    fn scalar_csv_publishes_drive_energy_between_external_and_anisotropy() {
        let mut stats = StepStats::default();
        stats.e_ext = 2.0;
        stats.e_drive = 3.0;
        stats.e_ani = 5.0;

        let mut csv = Vec::new();
        write_scalars_csv_header(&mut csv).expect("scalar header should be writable");
        write_scalar_row(&mut csv, &stats).expect("scalar row should be writable");
        let text = String::from_utf8(csv).expect("scalar CSV should be UTF-8");
        let mut lines = text.lines();
        let header: Vec<_> = lines.next().expect("header line").split(',').collect();
        let row: Vec<_> = lines.next().expect("row line").split(',').collect();

        assert_eq!(header[9], "E_drive");
        assert_eq!(row[9], "3.000000000000000e0");
        assert_eq!(row.len(), header.len());
    }

    #[test]
    fn physics_graph_runtime_provenance_preserves_scope_dependencies_and_lane() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.backend_policy.requested_backend = fullmag_ir::BackendTarget::Auto;
        problem.physics_graph = Some(serde_json::json!({
            "schema_version": "physics_graph.v1",
            "scene_revision": 19,
            "modules": [
                {
                    "id": "current:film",
                    "kind": "current_transport",
                    "applies_to": [{"kind": "object", "object_id": "film"}],
                    "solve_domain": [{"object_id": "film"}],
                    "depends_on": [],
                    "activation": "active",
                    "authored_state": "authored",
                    "capability": "reference_executable",
                    "source_path": "/current_modules/0",
                    "family_payload": {}
                },
                {
                    "id": "spin:film",
                    "kind": "spin_transport",
                    "applies_to": [{"kind": "object", "object_id": "film"}],
                    "solve_domain": [{"object_id": "film"}],
                    "depends_on": ["current:film"],
                    "activation": "blocked",
                    "authored_state": "authored",
                    "capability": "semantic_only",
                    "source_path": "/spin_transports/0",
                    "family_payload": {"reason": "source not executed on this lane"}
                }
            ],
            "edges": []
        }));
        let plan = test_fem_execution_plan();

        let artifact = physics_graph_provenance_artifact(&problem, &plan, None)
            .expect("graph provenance must resolve")
            .expect("authored graph must emit a runtime artifact");
        let payload: serde_json::Value =
            serde_json::from_slice(&artifact.bytes).expect("artifact JSON");

        assert_eq!(artifact.relative_path, PHYSICS_GRAPH_PROVENANCE_ARTIFACT);
        assert_eq!(payload["schema_version"], "physics_graph.runtime.v1");
        assert_eq!(payload["scene_revision"], 19);
        assert!(payload["mesh_revision"]
            .as_u64()
            .is_some_and(|value| value != 0));
        assert!(payload["graph_sha256"]
            .as_str()
            .is_some_and(|value| value.len() == 64));
        assert_eq!(payload["requested_lane"], "auto");
        assert_eq!(payload["resolved_lane"], "fem");
        assert_eq!(
            payload["modules"][1]["depends_on"],
            serde_json::json!(["current:film"])
        );
        assert_eq!(payload["modules"][1]["scope"], "object:film");
        assert_eq!(payload["modules"][1]["status"], "blocked");
        assert!(payload["graph_sha256"]
            .as_str()
            .is_some_and(|value| value.len() == 64));
        assert_eq!(
            payload["realization"]["schema_version"],
            fullmag_ir::PHYSICS_GRAPH_REALIZATION_SCHEMA
        );
        assert_eq!(
            payload["realization"]["modules"]
                .as_array()
                .map(|values| values.len()),
            Some(2)
        );
    }

    #[test]
    fn backend_kind_observation_never_promotes_a_graph_module() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.physics_graph = Some(serde_json::json!({
            "schema_version": "physics_graph.v1",
            "scene_revision": 1,
            "modules": [
                {
                    "id": "torque:executed",
                    "kind": "spin_torque",
                    "activation": "active"
                },
                {
                    "id": "torque:inactive",
                    "kind": "spin_torque",
                    "activation": "inactive"
                },
                {
                    "id": "field:active",
                    "kind": "regional_field_drive",
                    "activation": "active"
                }
            ],
            "edges": []
        }));
        let provenance = ExecutionProvenance {
            executed_physics_kinds: vec!["spin_torque".to_string()],
            ..ExecutionProvenance::default()
        };

        assert!(observed_physics_graph_module_ids(&provenance).is_empty());
    }

    #[test]
    fn backend_kind_observation_fails_closed_when_multiple_active_modules_match() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.physics_graph = Some(serde_json::json!({
            "schema_version": "physics_graph.v1",
            "scene_revision": 1,
            "modules": [
                {
                    "id": "torque:first",
                    "kind": "spin_torque",
                    "activation": "active"
                },
                {
                    "id": "torque:second",
                    "kind": "spin_torque",
                    "activation": "active"
                }
            ],
            "edges": []
        }));
        let provenance = ExecutionProvenance {
            executed_physics_kinds: vec!["spin_torque".to_string()],
            ..ExecutionProvenance::default()
        };

        assert!(observed_physics_graph_module_ids(&provenance).is_empty());
    }

    #[test]
    fn exact_backend_observation_executes_only_one_of_two_same_kind_modules() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        fn torque_module(id: &str, current_density: [f64; 3]) -> fullmag_ir::SpinTorqueModuleIR {
            fullmag_ir::SpinTorqueModuleIR::ZhangLi {
                schema_version: Some("zhang_li_torque.v1".to_string()),
                id: Some(id.to_string()),
                target: Some(fullmag_ir::RegionRefIR {
                    object_id: "strip".to_string(),
                    region_id: None,
                }),
                formula_version: "zhang_li.mumax3.v1".to_string(),
                operator_version: Some("zl_mumax3_central_v1".to_string()),
                current_density: Some(current_density),
                current_source: None,
                degree: 1.0,
                beta: 0.05,
                lande_g: Some(2.0),
            }
        }
        problem.spin_torque_modules = vec![
            torque_module("torque:first", [1.0e12, 0.0, 0.0]),
            torque_module("torque:second", [0.0, 1.0e12, 0.0]),
        ];
        let first_family_payload = serde_json::to_value(&problem.spin_torque_modules[0])
            .expect("serialize first canonical typed torque record");
        let second_family_payload = serde_json::to_value(&problem.spin_torque_modules[1])
            .expect("serialize second canonical typed torque record");
        problem.physics_graph = Some(serde_json::json!({
            "schema_version": "physics_graph.v1",
            "scene_revision": 1,
            "modules": [
                {
                    "id": "torque:first",
                    "kind": "spin_torque",
                    "applies_to": [{"kind": "object", "object_id": "strip"}],
                    "solve_domain": [{"object_id": "strip"}],
                    "depends_on": [],
                    "activation": "active",
                    "authored_state": "authored",
                    "capability": "reference_executable",
                    "source_path": "/spin_torque_modules/0",
                    "family_payload": first_family_payload
                },
                {
                    "id": "torque:second",
                    "kind": "spin_torque",
                    "applies_to": [{"kind": "object", "object_id": "strip"}],
                    "solve_domain": [{"object_id": "strip"}],
                    "depends_on": [],
                    "activation": "active",
                    "authored_state": "authored",
                    "capability": "reference_executable",
                    "source_path": "/spin_torque_modules/1",
                    "family_payload": second_family_payload
                }
            ],
            "edges": []
        }));
        let mut plan = test_execution_plan(None);
        let BackendPlanIR::Fdm(fdm_plan) = &mut plan.backend_plan else {
            panic!("expected FDM plan");
        };
        // Give the object-scoped modules an identity in this fixture mask.
        let grid_certificate = fdm_plan
            .grid_certificate
            .take()
            .expect("artifact fixture grid certificate should exist");
        fdm_plan.grid_certificate =
            Some(grid_certificate.with_object_ids(vec!["strip".to_string()]));
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: vec![[1.0, 0.0, 0.0]; 8],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 8],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                executed_physics_module_ids: vec!["torque:first".to_string()],
                ..ExecutionProvenance::default()
            },
        };

        let artifact = physics_graph_provenance_artifact(&problem, &plan, Some(&executed))
            .expect("exact runtime observation must resolve")
            .expect("authored graph must emit an artifact");
        let payload: serde_json::Value =
            serde_json::from_slice(&artifact.bytes).expect("physics graph artifact JSON");

        assert!(
            payload["realization"].is_object(),
            "missing concrete realization in {payload:#}"
        );
        assert_eq!(
            payload["realization"]["executed_module_ids"],
            serde_json::json!(["torque:first"])
        );
        assert_eq!(payload["realization"]["modules"][0]["state"], "executed");
        assert_eq!(payload["realization"]["modules"][1]["state"], "resolved");
    }

    #[test]
    fn cancelled_fdm_before_first_evaluation_records_no_executed_module_id() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.spin_torque_modules = vec![fullmag_ir::SpinTorqueModuleIR::ZhangLi {
            schema_version: Some("zhang_li_torque.v1".to_string()),
            id: Some("torque:strip".to_string()),
            target: Some(fullmag_ir::RegionRefIR {
                object_id: "strip".to_string(),
                region_id: None,
            }),
            formula_version: "zhang_li.mumax3.v1".to_string(),
            operator_version: Some("zl_mumax3_central_v1".to_string()),
            current_density: Some([1.0e12, 0.0, 0.0]),
            current_source: None,
            degree: 1.0,
            beta: 0.05,
            lande_g: Some(2.0),
        }];
        let family_payload = serde_json::to_value(&problem.spin_torque_modules[0])
            .expect("serialize canonical typed torque payload");
        problem.physics_graph = Some(serde_json::json!({
            "schema_version": "physics_graph.v1",
            "scene_revision": 1,
            "modules": [{
                "id": "torque:strip",
                "kind": "spin_torque",
                "applies_to": [{"kind": "object", "object_id": "strip"}],
                "solve_domain": [{"object_id": "strip"}],
                "depends_on": [],
                "activation": "active",
                "authored_state": "authored",
                "capability": "reference_executable",
                "source_path": "/spin_torque_modules/0",
                "family_payload": family_payload
            }],
            "edges": []
        }));
        let _plan = fullmag_plan::plan(&problem).expect("exact graph-bearing FDM plan");
        let mut executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Cancelled,
                steps: Vec::new(),
                final_magnetization: Vec::new(),
                completion: None,
            },
            initial_magnetization: Vec::new(),
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "cpu_reference".to_string(),
                timestep_policy: Some(
                    crate::resolve_timestep_policy(
                        Some(fullmag_ir::IntegratorChoice::Heun),
                        Some(1.0e-13),
                        None,
                        crate::types::TimestepExecutionLane::fdm_cpu(),
                    )
                    .expect("fixed FDM policy"),
                ),
                ..ExecutionProvenance::default()
            },
        };

        crate::physics_graph_execution::attach_executed_module_ids(&problem, &mut executed)
            .expect("cancelled owner must validate graph IDs");

        assert!(executed.provenance.executed_physics_module_ids.is_empty());
    }

    #[test]
    fn strict_gpu_artifact_provenance_requires_loaded_mfem_version() {
        let plan = test_fem_execution_plan();
        let provenance = ExecutionProvenance {
            execution_engine: "fem_native_gpu".to_string(),
            ..ExecutionProvenance::default()
        };

        assert!(execution_provenance_json(&plan, &provenance).is_err());
    }

    #[test]
    fn field_and_current_artifact_provenance_preserves_optional_mfem_version() {
        let problem = fullmag_ir::ProblemIR::bootstrap_example();
        let plan = test_fem_execution_plan();
        let context = build_field_context(&problem, &plan);
        let mut provenance = ExecutionProvenance {
            execution_engine: "fem_native_gpu".to_string(),
            mfem_version: Some("4.9".to_string()),
            hypre_version: Some("3.1.0".to_string()),
            ..ExecutionProvenance::default()
        };

        assert_eq!(
            artifact_provenance_json(&context, &provenance)["mfem_version"],
            "4.9"
        );
        assert!(artifact_provenance_json(&context, &provenance)
            .as_object()
            .expect("artifact provenance must be an object")
            .contains_key("hypre_version"));

        provenance.mfem_version = None;
        assert!(!artifact_provenance_json(&context, &provenance)
            .as_object()
            .expect("artifact provenance must be an object")
            .contains_key("mfem_version"));
    }

    #[test]
    fn cpu_fixed_coupling_metadata_prefers_final_counters_and_handles_zero_steps() {
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else { panic!("FEM fixture"); };
        fem.enable_demag = true;
        let telemetry = crate::types::CpuFixedCouplingTelemetry {
            rhs: crate::types::CpuFixedTransferDiagnostics {
                state: "ready".into(), build_count: 1, reuse_count: 19, nnz: 31,
                persistent_bytes: 4096, setup_wall_time_ns: 77, reason: String::new(),
                setup_rss_baseline_bytes: 1000,
                setup_observed_peak_rss_bytes: 1900,
                setup_observed_peak_delta_bytes: 900,
                setup_estimated_peak_delta_bytes: 1500,
            },
            recovery: crate::types::CpuFixedTransferDiagnostics {
                state: "quadrature".into(), reason: "persistent cache budget exceeded".into(),
                ..Default::default()
            },
        };
        let mut stale = telemetry.clone();
        stale.rhs.reuse_count = 17;
        let steps = vec![StepStats {
            step: 2, time: 2.0e-14, cpu_fixed_coupling: Some(stale), ..Default::default()
        }];
        let mut provenance = ExecutionProvenance {
            execution_engine: "fem_cpu_native".into(),
            cpu_fixed_coupling: Some(telemetry.clone()),
            ..Default::default()
        };
        let metadata = demag_runtime_metadata(&plan, &provenance, &steps);
        assert_eq!(metadata["cpu_fixed_coupling"]["rhs"]["reuse_count"], 19);
        assert_eq!(metadata["cpu_fixed_coupling"]["rhs"]["setup_rss_baseline_bytes"], 1000);
        assert_eq!(metadata["cpu_fixed_coupling"]["rhs"]["setup_observed_peak_rss_bytes"], 1900);
        assert_eq!(metadata["cpu_fixed_coupling"]["rhs"]["setup_observed_peak_delta_bytes"], 900);
        assert_eq!(metadata["cpu_fixed_coupling"]["rhs"]["setup_estimated_peak_delta_bytes"], 1500);
        assert_eq!(metadata["cpu_fixed_coupling"]["recovery"]["reason"], telemetry.recovery.reason);
        let zero_steps = demag_runtime_metadata(&plan, &provenance, &[]);
        assert_eq!(zero_steps["cpu_fixed_coupling"], serde_json::json!(telemetry));
        assert_eq!(steps.len(), 1);
        assert_eq!(steps[0].step, 2);
        assert_eq!(steps[0].time, 2.0e-14);
        provenance.cpu_fixed_coupling = None;
        assert!(demag_runtime_metadata(&plan, &provenance, &[]).get("cpu_fixed_coupling").is_none());
        provenance.execution_engine = "fem_native_gpu".into();
        provenance.cpu_fixed_coupling = Some(telemetry);
        assert!(demag_runtime_metadata(&plan, &provenance, &steps).get("cpu_fixed_coupling").is_none());
    }

    #[test]
    fn gpu_demag_runtime_metadata_keeps_loaded_hypre_identity_and_provider_labels() {
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.enable_demag = true;
        fem.demag_realization = Some(fullmag_ir::ResolvedFemDemagIR::PoissonRobin);
        let provenance = ExecutionProvenance {
            execution_engine: "fem_native_gpu".to_string(),
            hypre_version: Some("3.1.0".to_string()),
            fem_demag_operator_mode: Some("device_hypre_poisson".to_string()),
            ..ExecutionProvenance::default()
        };

        let metadata = demag_runtime_metadata(&plan, &provenance, &[]);
        assert_eq!(metadata["hypre_version"], "3.1.0");
        assert_eq!(metadata["linear_solver"], "CG");
        assert_eq!(metadata["preconditioner"], "AMG");
        assert_eq!(metadata["runtime_solver"], "HyprePCG");
        assert_eq!(metadata["runtime_preconditioner"], "HypreBoomerAMG");
    }

    #[test]
    fn fem_bem_runtime_metadata_preserves_measured_operator_provenance() {
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.enable_demag = true;
        fem.demag_realization = Some(fullmag_ir::ResolvedFemDemagIR::FredkinKoehler);
        let provenance = ExecutionProvenance {
            fem_demag_operator_mode: Some("hierarchical_h2".to_string()),
            fem_bem_demag: Some(crate::types::FemBemDemagProvenance {
                operator_mode: "hierarchical_h2".to_string(),
                operator_fingerprint: "hierarchical_h2-test".to_string(),
                boundary_node_count: 128,
                boundary_triangle_count: 252,
                near_block_count: 32,
                far_block_count: 64,
                near_entry_count: 2048,
                far_row_count: 512,
                max_rank: 12,
                relative_error_estimate: 1.0e-7,
                resident_bytes: 1_048_576,
                device_bytes: 0,
                operator_build_count: 1,
                operator_upload_count: 0,
                apply_count: 4,
            }),
            ..ExecutionProvenance::default()
        };

        let metadata = demag_runtime_metadata(&plan, &provenance, &[]);
        assert_eq!(metadata["magnetostatic_boundary_model"], "fredkin_koehler");
        assert_eq!(metadata["bem_operator"]["operator_mode"], "hierarchical_h2");
        assert_eq!(metadata["bem_operator"]["boundary_triangle_count"], 252);
        assert_eq!(metadata["bem_operator"]["max_rank"], 12);
    }

    #[test]
    fn gpu_demag_runtime_metadata_maps_resolved_nondefault_hypre_provider_labels() {
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.enable_demag = true;
        fem.demag_realization = Some(fullmag_ir::ResolvedFemDemagIR::PoissonRobin);
        let provenance = ExecutionProvenance {
            execution_engine: "fem_native_gpu".to_string(),
            fem_demag_operator_mode: Some("device_hypre_poisson".to_string()),
            fem_poisson_demag: Some(crate::types::FemPoissonDemagProvenance {
                linear_solver: "GMRES".to_string(),
                preconditioner: "JACOBI".to_string(),
                ..Default::default()
            }),
            ..ExecutionProvenance::default()
        };

        let metadata = demag_runtime_metadata(&plan, &provenance, &[]);
        assert_eq!(metadata["linear_solver"], "GMRES");
        assert_eq!(metadata["preconditioner"], "JACOBI");
        assert_eq!(metadata["runtime_solver"], "HypreGMRES");
        assert_eq!(metadata["runtime_preconditioner"], "HypreDiagScale");
    }

    #[test]
    fn gpu_demag_runtime_metadata_maps_no_preconditioner_to_hypre_identity() {
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.enable_demag = true;
        fem.demag_realization = Some(fullmag_ir::ResolvedFemDemagIR::PoissonRobin);
        let provenance = ExecutionProvenance {
            execution_engine: "fem_native_gpu".to_string(),
            fem_demag_operator_mode: Some("device_hypre_poisson".to_string()),
            fem_poisson_demag: Some(crate::types::FemPoissonDemagProvenance {
                linear_solver: "CG".to_string(),
                preconditioner: "NONE".to_string(),
                ..Default::default()
            }),
            ..ExecutionProvenance::default()
        };

        let metadata = demag_runtime_metadata(&plan, &provenance, &[]);
        assert_eq!(metadata["runtime_solver"], "HyprePCG");
        assert_eq!(metadata["runtime_preconditioner"], "HypreIdentity");
    }

    #[test]
    fn artifact_node_selection_resolves_quad_interface_by_global_ordinal() {
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.mesh.nodes = vec![
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [1.0, 1.0, 0.0],
            [0.0, 1.0, 0.0],
        ];
        fem.mesh.facets = fullmag_ir::FemFacetConnectivityIR {
            types: vec![fullmag_ir::FemFacetTypeIR::Quad4],
            roles: vec![fullmag_ir::FemFacetRoleIR::MaterialInterface],
            offsets: vec![0, 4],
            nodes: vec![0, 1, 2, 3],
            global_ordinals: vec![700],
        };
        fem.mesh.boundary_markers = vec![27];
        let part = FemMeshPartIR {
            id: "part:interface:0:1".into(),
            label: "Air ↔ film".into(),
            role: FemMeshPartRole::Interface,
            object_id: Some("film".into()),
            geometry_id: Some("film".into()),
            material_id: None,
            element_selector: FemMeshPartSelector::ElementRange { start: 0, count: 0 },
            boundary_face_selector: FemMeshPartSelector::BoundaryFaceRange { start: 0, count: 0 },
            node_selector: FemMeshPartSelector::NodeRange { start: 0, count: 0 },
            boundary_face_indices: Vec::new(),
            node_indices: Vec::new(),
            facet_global_ordinals: vec![700],
            bounds_min: None,
            bounds_max: None,
            parent_id: None,
        };
        assert_eq!(
            fem_part_node_indices_for_artifact(fem, &part),
            vec![0, 1, 2, 3]
        );
    }
    use crate::types::{
        ExecutedRun, ExecutionProvenance, FieldSnapshot, ResolvedFallback, RunResult, RunStatus,
        SolverAttemptRecord,
    };
    use fullmag_ir::{
        BackendPlanIR, CommonPlanMeta, ExchangeBoundaryCondition, ExecutionMode, ExecutionPlanIR,
        ExecutionPrecision, FdmLayerPlanIR, FdmMaterialIR, FdmMultilayerPlanIR,
        FdmMultilayerSummaryIR, FdmPlanIR, FemDomainMeshModeIR, FemMeshPartIR, FemMeshPartRole,
        FemMeshPartSelector, FemObjectSegmentIR, FemPlanIR, GridDimensions, IntegratorChoice,
        MaterialFieldLocationIR, MaterialFieldPlan, MaterialFieldSourceKind,
        MaterialFieldStatisticsIR, MaterialIR, MaterialParameterNameIR, MeshIR, OutputPlanIR,
        ProvenancePlanIR,
    };
    use std::collections::HashMap;
    use std::fs;
    use std::sync::Mutex;
    use std::time::{SystemTime, UNIX_EPOCH};

    static FINAL_EXECUTION_ENV_LOCK: Mutex<()> = Mutex::new(());

    #[test]
    fn artifact_provenance_preserves_fem_gpu_execution_receipt_verbatim() {
        let context = FieldArtifactContext {
            problem_name: "fem-receipt".into(),
            ir_version: "v0".into(),
            source_hash: Some("source-bound".into()),
            execution_mode: ExecutionMode::Hybrid,
            layout: serde_json::json!({"backend": "fem"}),
            magnetization_field_semantics: Ok(None),
            execution_resolution: None,
        };
        let mut provenance = ExecutionProvenance::default();
        provenance.fem_gpu_execution_receipt = Some(crate::types::FemGpuExecutionReceipt {
            requested: "hybrid".into(),
            resolved: "hybrid_cpu_poisson".into(),
            executed: "cuda_fem_hybrid_cpu_poisson".into(),
            execution_class: crate::types::FemGpuExecutionClass::HybridCpuPoisson,
            device_ordinal: 0,
            precision: "double".into(),
            integrator: "heun".into(),
            required_operator_mask: 0x3ff,
            resolved_device_operator_mask: 0x1fb,
            resolved_host_operator_mask: 0x204,
            resolved_unknown_operator_mask: 0,
            executed_device_operator_mask: 0x1fb,
            executed_host_operator_mask: 0x204,
            executed_unknown_operator_mask: 0,
            fallback_count: 0,
            accepted_step_count: 1,
            rejected_attempt_count: 0,
            failed_attempt_count: 0,
            hot_loop_compute_h2d_bytes: 24,
            hot_loop_compute_d2h_bytes: 24,
            hot_loop_compute_host_sync_count: 2,
            accounting_valid: true,
        });

        let value = artifact_provenance_json(&context, &provenance);
        let receipt = &value["fem_gpu_execution_receipt"];
        assert_eq!(receipt["execution_class"], "hybrid_cpu_poisson");
        assert_eq!(receipt["executed_host_operator_mask"], 0x204);
        assert_eq!(receipt["hot_loop_compute_h2d_bytes"], 24);
        assert_eq!(receipt["hot_loop_compute_d2h_bytes"], 24);
        assert_eq!(receipt["hot_loop_compute_host_sync_count"], 2);
    }

    #[test]
    fn dmi_field_artifact_units_include_bulk_and_rotated_quantities() {
        assert_eq!(field_unit("H_dmi"), "A/m");
        assert_eq!(field_unit("H_dmi.x"), "A/m");
        assert_eq!(field_unit("H_dmi_bulk"), "A/m");
        assert_eq!(field_unit("H_dmi_bulk.z"), "A/m");
        assert_eq!(field_unit("H_rotated_dmi"), "A/m");
        assert_eq!(field_unit("H_rotated_dmi.y"), "A/m");
        assert_eq!(field_unit("eden_rotated_dmi"), "J/m³");
    }

    #[test]
    fn steady_transport_field_artifact_units_come_from_quantity_catalog() {
        assert_eq!(field_unit("V_electric"), "V");
        assert_eq!(field_unit("J_charge"), "A/m^2");
        assert_eq!(field_unit("spin_potential"), "V");
        assert_eq!(field_unit("spin_current_tensor"), "A/m^2");
        assert_eq!(field_unit("torque_stt"), "1/s");
    }

    #[test]
    fn legacy_sample_vector_artifact_keeps_nested_xyz_values() {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time")
            .as_nanos();
        let root = std::env::temp_dir().join(format!(
            "fullmag-legacy-vector-artifact-{}-{unique}",
            std::process::id()
        ));
        let context = FieldArtifactContext {
            problem_name: "legacy-fdm".into(),
            ir_version: "v0".into(),
            source_hash: None,
            execution_mode: ExecutionMode::Strict,
            layout: serde_json::json!({"backend": "fdm", "grid_cells": [2, 1, 1]}),
            magnetization_field_semantics: Ok(None),
            execution_resolution: None,
        };
        let snapshot = FieldSnapshot::new(
            "m",
            0,
            0.0,
            0.0,
            3,
            "xyz",
            "sample",
            "full",
            1,
            vec![1.0, 0.0, 0.0, 0.0, 1.0, 0.0],
        )
        .expect("valid vector snapshot");

        write_field_snapshot_artifact(&root, &context, &ExecutionProvenance::default(), &snapshot)
            .expect("write vector artifact");
        let payload: serde_json::Value = serde_json::from_slice(
            &fs::read(root.join("m/step_000000.json")).expect("read vector artifact"),
        )
        .expect("parse vector artifact");
        assert_eq!(
            payload["values"],
            serde_json::json!([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])
        );
        assert!(payload["provenance"].get("transport_modules").is_none());

        fs::remove_dir_all(root).expect("remove vector artifact fixture");
    }

    #[test]
    fn final_magnetization_artifact_uses_canonical_unit_one() {
        assert_eq!(field_unit("m"), "1");
    }

    #[test]
    fn regional_drive_field_artifact_uses_magnetic_field_units() {
        assert_eq!(field_unit("H_drive"), "A/m");
        assert_eq!(field_unit("H_drive.y"), "A/m");
    }

    fn test_execution_plan(active_mask: Option<Vec<bool>>) -> ExecutionPlanIR {
        let active_cells = active_mask.as_deref().map_or(8, |mask| {
            mask.iter().filter(|active| **active).count() as u64
        });
        ExecutionPlanIR {
            common: CommonPlanMeta {
                ir_version: "v0".to_string(),
                requested_backend: fullmag_ir::BackendTarget::Fdm,
                resolved_backend: fullmag_ir::BackendTarget::Fdm,
                execution_mode: ExecutionMode::Strict,
                material_field_plans: Vec::new(),
            },
            backend_plan: BackendPlanIR::Fdm(FdmPlanIR {
                grid: GridDimensions { cells: [4, 2, 1] },
                cell_size: [2e-9, 2e-9, 5e-9],
                grid_certificate: Some(
                    fullmag_ir::FdmGridCertificateIR::new_with_masks(
                        [0.0, 0.0, 0.0],
                        [4, 2, 1],
                        [2e-9, 2e-9, 5e-9],
                        active_cells,
                        8 * fullmag_plan::FDM_GRID_ESTIMATED_BYTES_PER_CELL,
                        active_mask.as_deref(),
                        &[0; 8],
                    )
                    .expect("artifact fixture grid certificate should be valid"),
                ),
                region_mask: vec![0; 8],
                active_mask,
                initial_magnetization: vec![[1.0, 0.0, 0.0]; 8],
                material: FdmMaterialIR {
                    name: "Py".to_string(),
                    saturation_magnetisation: 800e3,
                    exchange_stiffness: 13e-12,
                    damping: 0.02,
                    ..Default::default()
                },
                enable_exchange: true,
                enable_demag: true,
                fft: None,
                external_field: None,
                gyromagnetic_ratio: 2.211e5,
                precision: ExecutionPrecision::Double,
                precision_policy: fullmag_ir::FdmPrecisionPolicyIR::default(),
                exchange_bc: ExchangeBoundaryCondition::Neumann,
                integrator: Some(IntegratorChoice::Heun),
                fixed_timestep: Some(1e-13),
                adaptive_timestep: None,
                field_refresh: None,
                relaxation: None,
                boundary_correction: None,
                boundary_geometry: None,
                inter_region_exchange: vec![],
                region_owner: Vec::new(),
                current_density: None,
                stt_degree: None,
                stt_beta: None,
                stt_spin_polarization: None,
                stt_lambda: None,
                stt_epsilon_prime: None,
                stt_thickness: None,
                stt_fixed_layer_position: None,
                has_oersted_cylinder: false,
                oersted_current: None,
                oersted_radius: None,
                oersted_center: None,
                oersted_axis: None,
                static_external_field_xyz: None,
                oersted_field_xyz: None,
                oersted_time_dep_kind: 0,
                oersted_time_dep_freq: 0.0,
                oersted_time_dep_phase: 0.0,
                oersted_time_dep_offset: 0.0,
                oersted_time_dep_t_on: 0.0,
                oersted_time_dep_t_off: 0.0,
                oersted_realization: None,
                temperature: None,
                interfacial_dmi: None,
                bulk_dmi: None,
                ..Default::default()
            }),
            output_plan: OutputPlanIR {
                outputs: Vec::new(),
            },
            provenance: ProvenancePlanIR {
                notes: Vec::new(),
                integrator_resolution: None,
                fem_eigen_execution_resolution: None,
                physics_graph: None,
            },
        }
    }

    #[test]
    fn fdm_mesh_metadata_preserves_requested_and_resolved_pbc_demag() {
        let mut plan = test_execution_plan(None);
        let BackendPlanIR::Fdm(fdm) = &mut plan.backend_plan else {
            panic!("expected FDM plan");
        };
        fdm.periodicity = Some(fullmag_ir::FdmPeriodicityIR {
            axes: [
                fullmag_ir::AxisBoundary::Periodic,
                fullmag_ir::AxisBoundary::Open,
                fullmag_ir::AxisBoundary::Open,
            ],
            demag: fullmag_ir::FdmDemagPeriodicityIR::TruncatedImages,
            image_counts: Some([4, 0, 0]),
        });
        fdm.resolved_periodic_images = fdm.periodicity.as_ref().and_then(|pbc| {
            pbc.resolve_periodic_images(fdm.grid.cells, fdm.precision)
                .expect("test PBC workspace should resolve")
        });
        let metadata = mesh_runtime_metadata(&plan);
        assert_eq!(
            metadata["requested_periodicity"]["demag"],
            "truncated_images"
        );
        assert_eq!(
            metadata["resolved_demag_boundary"]["periodic_truncated_images"]["image_counts"],
            serde_json::json!([4, 0, 0])
        );
        assert_eq!(
            metadata["resolved_periodic_images"]["resolved_image_counts"],
            serde_json::json!([4, 0, 0])
        );
        assert_eq!(
            metadata["resolved_periodic_images"]["padded_counts"],
            serde_json::json!([4, 4, 2])
        );
    }

    #[test]
    fn auto_sampling_writes_versioned_resolution_artifact_without_recomputing_values() {
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-auto-sampling-artifact-{}",
            std::process::id()
        ));
        let resolution = serde_json::json!({
            "schema_version": "sampling_resolution.v1",
            "requested_policy": {"kind": "auto_sinc_cutoff", "nyquist_guard_factor": 1.3},
            "sample_period_s": 7.692307692307691e-11,
            "maximum_cutoff_hz": 5.0e9,
            "nyquist_guard_factor": 1.3,
            "target_nyquist_hz": 6.5e9,
            "sampling_frequency_hz": 13.0e9,
            "source_drive_ids": ["drive-5"],
            "target_stage_id": "excite"
        });

        write_sampling_resolution_artifact(&output_dir, Some(&resolution))
            .expect("sampling artifact should write");

        let artifact: serde_json::Value = serde_json::from_slice(
            &fs::read(output_dir.join("sampling/sampling_resolution.v1.json"))
                .expect("sampling artifact should be readable"),
        )
        .expect("sampling artifact should be JSON");
        assert_eq!(artifact["schema_version"], "sampling_resolution.v1");
        assert_eq!(artifact["sampling_resolution"], resolution);
        let _ = fs::remove_dir_all(output_dir);
    }

    #[test]
    fn fdm_pbc_provenance_artifact_round_trips_requested_and_resolved_contract() {
        let mut plan = test_execution_plan(None);
        let BackendPlanIR::Fdm(fdm) = &mut plan.backend_plan else {
            panic!("expected FDM plan");
        };
        fdm.periodicity = Some(fullmag_ir::FdmPeriodicityIR {
            axes: [
                fullmag_ir::AxisBoundary::Periodic,
                fullmag_ir::AxisBoundary::Open,
                fullmag_ir::AxisBoundary::Open,
            ],
            demag: fullmag_ir::FdmDemagPeriodicityIR::TruncatedImages,
            image_counts: Some([4, 0, 0]),
        });
        fdm.grid_certificate = Some(
            fullmag_ir::FdmGridCertificateIR::new(
                fdm.origin_m,
                fdm.grid.cells,
                fdm.cell_size,
                8,
                1024,
            )
            .expect("FDM grid certificate should be valid"),
        );
        fdm.resolved_periodic_images = fdm.periodicity.as_ref().and_then(|pbc| {
            pbc.resolve_periodic_images(fdm.grid.cells, fdm.precision)
                .expect("test PBC workspace should resolve")
        });
        let provenance = ExecutionProvenance {
            demag_operator_kind: Some("tensor_fft_newell".to_string()),
            fft_backend: Some("rustfft".to_string()),
            ..ExecutionProvenance::default()
        };
        let artifacts = crate::fdm::artifacts::pbc_provenance_artifacts(&plan, &provenance);
        assert_eq!(artifacts.len(), 1);
        assert_eq!(
            artifacts[0].relative_path,
            "mesh/fdm_pbc_provenance.v1.json"
        );
        let value: serde_json::Value = serde_json::from_slice(&artifacts[0].bytes)
            .expect("PBC provenance artifact should be JSON");
        assert_eq!(value["schema_version"], "fdm_pbc_provenance.v1");
        assert_eq!(
            value["requested_periodicity"]["axes"],
            serde_json::json!(["periodic", "open", "open"])
        );
        assert_eq!(
            value["resolved"]["origin_m"],
            serde_json::json!([0.0, 0.0, 0.0])
        );
        assert_eq!(value["resolved"]["counts"], serde_json::json!([4, 2, 1]));
        assert!(value["resolved"]["grid_fingerprint"].as_str().is_some());
        assert_eq!(
            value["resolved"]["period_m"],
            serde_json::json!([8e-9, 4e-9, 5e-9])
        );
        assert_eq!(
            value["resolved"]["padded_counts"],
            serde_json::json!([4, 4, 2])
        );
        assert_eq!(value["resolved"]["fft_backend"], "rustfft");
        assert_eq!(
            value["resolved"]["periodic_images"]["kernel"],
            "newell_truncated_images_fft"
        );
    }

    #[test]
    fn fdm_region_membership_artifact_persists_binary_mask_and_legend_identity() {
        let mut plan = test_execution_plan(None);
        let BackendPlanIR::Fdm(fdm) = &mut plan.backend_plan else {
            panic!("expected FDM plan");
        };
        fdm.origin_m = [1.0e-9, -3.0e-9, 7.0e-9];
        fdm.cell_size = [2.0e-9, 3.0e-9, 4.0e-9];
        fdm.region_mask = vec![0, 1, 2, 0, 0, 0, 0, 0];
        fdm.active_mask = Some(vec![false, true, true, false, false, true, false, false]);
        fdm.grid_certificate = Some(
            fullmag_ir::FdmGridCertificateIR::new_with_masks(
                fdm.origin_m,
                fdm.grid.cells,
                fdm.cell_size,
                3,
                1024,
                fdm.active_mask.as_deref(),
                &fdm.region_mask,
            )
            .expect("FDM region certificate should be valid")
            .with_object_ids(vec!["body".to_string()])
            .with_region_legend(vec![
                fullmag_ir::FdmRegionLegendEntryIR {
                    numeric_id: 1,
                    object_id: "body".to_string(),
                    region_id: "body:core".to_string(),
                    priority: 0,
                },
                fullmag_ir::FdmRegionLegendEntryIR {
                    numeric_id: 2,
                    object_id: "body".to_string(),
                    region_id: "body:shell".to_string(),
                    priority: -1,
                },
            ]),
        );

        let artifacts = crate::fdm::artifacts::region_membership_artifacts(&plan)
            .expect("membership artifacts should be produced");
        assert_eq!(artifacts.len(), 2);
        assert_eq!(
            artifacts[0].relative_path,
            "mesh/fdm_region_membership.v2.json"
        );
        assert_eq!(
            artifacts[1].relative_path,
            "mesh/fdm_region_membership.v2.bin"
        );
        let descriptor: serde_json::Value = serde_json::from_slice(&artifacts[0].bytes)
            .expect("membership descriptor should be JSON");
        assert_eq!(descriptor["schema_version"], "fdm_region_membership.v2");
        assert_eq!(
            descriptor["domain_generation_id"],
            descriptor["grid_fingerprint"]
        );
        assert_eq!(descriptor["object_ids"], serde_json::json!(["body"]));
        assert_eq!(descriptor["cell_count"], 8);
        assert_eq!(
            descriptor["magnetic_support"]["semantic_role"],
            "magnetic-support"
        );
        assert_eq!(
            descriptor["magnetic_support"]["grid_fingerprint"],
            descriptor["grid_fingerprint"]
        );
        assert_eq!(descriptor["magnetic_support"]["active_cell_count"], 3);
        assert_eq!(descriptor["magnetic_support"]["inactive_cell_count"], 5);
        assert_eq!(
            descriptor["magnetic_support"]["active_unassigned_cell_count"],
            1
        );
        for (actual, expected) in descriptor["magnetic_support"]["bounds_min_m"]
            .as_array()
            .unwrap()
            .iter()
            .zip([3e-9, -3e-9, 7e-9])
        {
            assert!((actual.as_f64().unwrap() - expected).abs() < 1e-20);
        }
        for (actual, expected) in descriptor["magnetic_support"]["bounds_max_m"]
            .as_array()
            .unwrap()
            .iter()
            .zip([7e-9, 3e-9, 11e-9])
        {
            assert!((actual.as_f64().unwrap() - expected).abs() < 1e-20);
        }
        assert_eq!(descriptor["region_legend"].as_array().unwrap().len(), 2);
        assert_eq!(&artifacts[1].bytes[..4], b"FMRM");
        assert_eq!(artifacts[1].bytes[4], 2);
        assert_eq!(
            u32::from_le_bytes(artifacts[1].bytes[64..68].try_into().unwrap()),
            u32::MAX,
            "inactive cells must remain distinguishable from active cells without an authored region"
        );
        assert_eq!(
            u32::from_le_bytes(artifacts[1].bytes[84..88].try_into().unwrap()),
            0,
            "active cells without an authored region must remain active-unassigned"
        );
        assert_eq!(
            artifacts[1].bytes.len(),
            64 + 8 * std::mem::size_of::<u32>()
        );
    }

    #[test]
    fn fem_mesh_metadata_preserves_shared_domain_build_report() {
        let mut plan = test_fem_execution_plan();
        let report: fullmag_ir::FemSharedDomainBuildReportIR =
            serde_json::from_value(serde_json::json!({
                "build_mode": "generated_shared_domain_mesh",
                "degraded": false,
                "authored_regions_count": 2,
                "realized_regions_count": 2
            }))
            .expect("minimal FEM build report should deserialize");
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("expected FEM plan");
        };
        fem.mesh_build_report = Some(report.clone());
        let expected_topology_fingerprint = fem.mesh.topology_fingerprint_v6();

        let metadata = mesh_runtime_metadata(&plan);
        assert_eq!(metadata["mesh_generation_id"].as_str().unwrap().len(), 64);
        assert_eq!(
            metadata["topology_fingerprint"],
            serde_json::Value::String(expected_topology_fingerprint)
        );
        assert!(metadata["topology_fingerprint"]
            .as_str()
            .is_some_and(|value| value.starts_with("sha256:")));
        assert_ne!(
            metadata["topology_fingerprint"],
            metadata["mesh_generation_id"],
            "canonical topology identity and solver-mesh generation identity are distinct contracts"
        );
        assert_eq!(
            metadata["mesh_build_report"],
            serde_json::to_value(report).unwrap()
        );
        assert_eq!(
            metadata["mesh_build_report"]["orphan_entities"],
            serde_json::json!([]),
        );
    }

    fn test_multilayer_execution_plan() -> ExecutionPlanIR {
        let layer_material = FdmMaterialIR {
            name: "Py".to_string(),
            saturation_magnetisation: 800e3,
            exchange_stiffness: 13e-12,
            damping: 0.02,
            ..Default::default()
        };
        ExecutionPlanIR {
            common: CommonPlanMeta {
                ir_version: "v0".to_string(),
                requested_backend: fullmag_ir::BackendTarget::Fdm,
                resolved_backend: fullmag_ir::BackendTarget::Fdm,
                execution_mode: ExecutionMode::Strict,
                material_field_plans: Vec::new(),
            },
            backend_plan: BackendPlanIR::FdmMultilayer(FdmMultilayerPlanIR {
                mode: "three_d".to_string(),
                common_cells: [2, 1, 2],
                requested_common_cell_size: None,
                grid_certificate: None,
                resolved_periodic_images: None,
                layers: vec![
                    FdmLayerPlanIR {
                        rotated_interfacial_dmi: None,
                        magnet_name: "bottom".to_string(),
                        layer_id: "layer:bottom".to_string(),
                        object_id: "bottom".to_string(),
                        native_grid: [2, 1, 1],
                        native_cell_size: [2e-9, 2e-9, 1e-9],
                        native_origin: [0.0, 0.0, 0.0],
                        native_active_mask: None,
                        native_region_mask: None,
                        native_region_legend: None,
                        initial_magnetization: vec![[1.0, 0.0, 0.0]; 2],
                        material: layer_material.clone(),
                        convolution_grid: [2, 1, 1],
                        convolution_cell_size: [2e-9, 2e-9, 1e-9],
                        convolution_origin: [0.0, 0.0, 0.0],
                        transfer_kind: "identity".to_string(),
                    },
                    FdmLayerPlanIR {
                        rotated_interfacial_dmi: None,
                        magnet_name: "top".to_string(),
                        layer_id: "layer:top".to_string(),
                        object_id: "top".to_string(),
                        native_grid: [2, 1, 1],
                        native_cell_size: [2e-9, 2e-9, 1e-9],
                        native_origin: [0.0, 0.0, 4e-9],
                        native_active_mask: Some(vec![true, false]),
                        native_region_mask: None,
                        native_region_legend: None,
                        initial_magnetization: vec![[0.0, 1.0, 0.0]; 2],
                        material: layer_material,
                        convolution_grid: [2, 1, 1],
                        convolution_cell_size: [2e-9, 2e-9, 1e-9],
                        convolution_origin: [0.0, 0.0, 4e-9],
                        transfer_kind: "identity".to_string(),
                    },
                ],
                frozen_spins: None,
                enable_exchange: true,
                enable_demag: true,
                fft: None,
                external_field: None,
                interfacial_dmi: None,
                rotated_interfacial_dmi: None,
                bulk_dmi: None,
                gyromagnetic_ratio: 2.211e5,
                precision: ExecutionPrecision::Double,
                precision_policy: fullmag_ir::FdmPrecisionPolicyIR::default(),
                exchange_bc: ExchangeBoundaryCondition::Neumann,
                periodicity: None,
                integrator: IntegratorChoice::Heun,
                fixed_timestep: Some(1e-13),
                field_refresh: None,
                relaxation: None,
                planner_summary: FdmMultilayerSummaryIR {
                    requested_strategy: "multilayer_convolution".to_string(),
                    selected_strategy: "multilayer_convolution".to_string(),
                    requested_mode: "three_d".to_string(),
                    resolved_mode: "three_d".to_string(),
                    eligibility: "eligible".to_string(),
                    estimated_pair_kernels: 4,
                    estimated_unique_kernels: 3,
                    estimated_kernel_bytes: 4096,
                    warnings: Vec::new(),
                },
            }),
            output_plan: OutputPlanIR {
                outputs: Vec::new(),
            },
            provenance: ProvenancePlanIR {
                notes: Vec::new(),
                integrator_resolution: None,
                fem_eigen_execution_resolution: None,
                physics_graph: None,
            },
        }
    }

    fn heterogeneous_multilayer_material_plan() -> ExecutionPlanIR {
        let mut plan = test_multilayer_execution_plan();
        let BackendPlanIR::FdmMultilayer(multilayer) = &mut plan.backend_plan else {
            panic!("expected multilayer FDM plan");
        };

        multilayer.layers[0].native_region_mask = Some(vec![1, 0]);
        multilayer.layers[0].native_region_legend =
            Some(vec![fullmag_ir::FdmRegionLegendEntryIR {
                numeric_id: 1,
                object_id: "bottom".to_string(),
                region_id: "edge".to_string(),
                priority: 3,
            }]);
        multilayer.layers[0].material.ms_field = Some(vec![700e3, 710e3]);
        multilayer.layers[0].material.a_field = Some(vec![11e-12, 12e-12]);
        multilayer.layers[0].material.alpha_field = Some(vec![0.01, 0.02]);

        let top = &mut multilayer.layers[1];
        top.native_grid = [3, 1, 1];
        top.native_active_mask = Some(vec![true, true, true]);
        top.native_region_mask = Some(vec![0, 7, 7]);
        top.native_region_legend = Some(vec![fullmag_ir::FdmRegionLegendEntryIR {
            numeric_id: 7,
            object_id: "top".to_string(),
            region_id: "edge".to_string(),
            priority: 5,
        }]);
        top.initial_magnetization = vec![[0.0, 1.0, 0.0]; 3];
        top.material.ms_field = Some(vec![810e3, 820e3, 830e3]);
        top.material.a_field = Some(vec![13e-12, 14e-12, 15e-12]);
        top.material.alpha_field = Some(vec![0.03, 0.04, 0.05]);

        plan
    }

    #[test]
    fn fdm_multilayer_layout_describes_native_identity_membership_and_material_fields() {
        let plan = heterogeneous_multilayer_material_plan();

        let layout = field_layout(&plan);
        let layers = layout["layers"].as_array().expect("layer descriptors");
        assert_eq!(layers.len(), 2);
        assert_eq!(layers[0]["layer_id"], "layer:bottom");
        assert_eq!(layers[0]["object_id"], "bottom");
        assert_eq!(layers[0]["magnet_name"], "bottom");
        assert_eq!(layers[0]["native_grid"], serde_json::json!([2, 1, 1]));
        assert!(layers[0]["native_grid_fingerprint"]
            .as_str()
            .is_some_and(|value| value.starts_with("sha256:") && value.len() == 71));
        assert_eq!(layers[0]["value_offset"], 0);
        assert_eq!(layers[0]["value_count"], 2);
        assert_eq!(layers[1]["layer_id"], "layer:top");
        assert_eq!(layers[1]["object_id"], "top");
        assert_eq!(layers[1]["native_grid"], serde_json::json!([3, 1, 1]));
        assert_eq!(layers[1]["value_offset"], 2);
        assert_eq!(layers[1]["value_count"], 3);
        assert_ne!(
            layers[0]["native_grid_fingerprint"],
            layers[1]["native_grid_fingerprint"]
        );

        assert_eq!(layers[0]["native_region_mask"]["available"], true);
        assert_eq!(layers[0]["native_region_mask"]["value_count"], 2);
        assert!(layers[0]["native_region_mask"]["value_sha256"]
            .as_str()
            .is_some_and(|value| value.starts_with("sha256:")));
        assert_eq!(layers[0]["native_region_legend"]["available"], true);
        assert_eq!(
            layers[0]["native_region_legend"]["entries"][0],
            serde_json::json!({
                "numeric_id": 1,
                "object_id": "bottom",
                "region_id": "edge",
                "priority": 3,
            })
        );
        assert_eq!(
            layers[1]["native_region_legend"]["entries"][0]["region_id"], "edge",
            "the same region_id remains bound to its layer-local object identity"
        );

        for (field_id, unit, count) in [
            ("mat_ms", "A/m", 2),
            ("mat_aex", "J/m", 2),
            ("mat_alpha", "1", 2),
        ] {
            let field = &layers[0]["material_fields"][field_id];
            assert_eq!(field["available"], true);
            assert_eq!(field["unit"], unit);
            assert_eq!(field["value_count"], count);
            assert_eq!(field["revision"], 1);
            assert!(field["generation_id"]
                .as_str()
                .is_some_and(|value| value.starts_with("sha256:")));
            assert!(field["value_sha256"]
                .as_str()
                .is_some_and(|value| value.starts_with("sha256:")));
        }
        assert_eq!(layers[1]["material_fields"]["mat_ms"]["value_count"], 3);
        assert_ne!(
            layers[0]["material_fields"]["mat_ms"]["value_sha256"],
            layers[1]["material_fields"]["mat_ms"]["value_sha256"]
        );
        assert!(layout.get("common_grid_material_fields").is_none());
    }

    #[test]
    fn fdm_multilayer_material_and_membership_artifacts_include_build_identity() {
        let plan = heterogeneous_multilayer_material_plan();
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fdm-multilayer-materials-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        let prepared = build_material_field_artifacts(&plan)
            .expect("multilayer material bundle should build without filesystem output");
        let prepared_paths = prepared
            .files
            .iter()
            .map(|artifact| artifact.relative_path.as_str())
            .collect::<BTreeSet<_>>();
        assert!(!output_dir.exists(), "pure preparation must not write files");
        assert_eq!(prepared.metadata_assets.len(), 6);
        for asset in &prepared.metadata_assets {
            let referenced_path = asset["artifact_path"]
                .as_str()
                .expect("metadata field asset should reference a member");
            assert!(prepared_paths.contains(referenced_path));
        }

        let assets = write_material_field_artifacts(&output_dir, &plan)
            .expect("multilayer material artifacts should be written");

        assert_eq!(assets, prepared.metadata_assets);
        for artifact in &prepared.files {
            assert_eq!(
                fs::read(output_dir.join(&artifact.relative_path))
                    .expect("legacy wrapper member should exist"),
                artifact.bytes,
                "legacy wrapper must write the exact bytes returned by the pure builder"
            );
        }
        assert_eq!(assets.len(), 6);
        assert!(assets
            .iter()
            .all(|asset| asset["backend"] == "fdm_multilayer"));
        assert!(assets
            .iter()
            .all(|asset| asset["build_identity"] == build_identity_json()));
        assert!(assets.iter().all(|asset| asset.get("values").is_none()));
        assert_eq!(
            assets
                .iter()
                .filter(|asset| asset["layer_id"] == "layer:bottom")
                .count(),
            3
        );
        assert_eq!(
            assets
                .iter()
                .filter(|asset| asset["layer_id"] == "layer:top")
                .count(),
            3
        );

        let manifest: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("material-fields/fdm-multilayer/manifest.json"))
                .expect("multilayer material manifest should exist"),
        )
        .expect("multilayer material manifest should parse");
        let manifest_artifact = prepared
            .files
            .iter()
            .find(|artifact| {
                artifact.relative_path == "material-fields/fdm-multilayer/manifest.json"
            })
            .expect("pure builder should include the referenced manifest");
        assert_eq!(
            fs::read(output_dir.join(&manifest_artifact.relative_path))
                .expect("legacy wrapper manifest should exist"),
            manifest_artifact.bytes,
            "legacy wrapper must write the exact manifest bytes returned by the pure builder"
        );
        assert_eq!(
            manifest["schema_version"],
            "fdm_multilayer_material_fields.v1"
        );
        assert_eq!(manifest["storage_layout"], "per_layer_native_grid");
        assert_eq!(manifest["layers"].as_array().map(Vec::len), Some(2));
        assert_eq!(manifest["build_identity"], build_identity_json());
        assert!(manifest.get("common_grid").is_none());
        for layer in manifest["layers"]
            .as_array()
            .expect("manifest layer descriptors")
        {
            let material_fields = layer["material_fields"]
                .as_object()
                .expect("layer material-field descriptors");
            for descriptor in material_fields.values() {
                if let Some(relative_path) = descriptor["artifact_path"].as_str() {
                    assert!(
                        prepared_paths.contains(relative_path),
                        "manifest material descriptor must resolve to a prepared member"
                    );
                }
            }
            if let Some(relative_path) = layer["native_region_mask"]["artifact_path"].as_str() {
                assert!(
                    prepared_paths.contains(relative_path),
                    "manifest membership descriptor must resolve to a prepared member"
                );
            }
        }

        let bottom_ms: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(
                output_dir.join("material-fields/fdm-multilayer/layer-bottom/mat_ms.json"),
            )
            .expect("bottom mat_ms payload should exist"),
        )
        .expect("bottom mat_ms payload should parse");
        assert_eq!(bottom_ms["layer_id"], "layer:bottom");
        assert_eq!(bottom_ms["object_id"], "bottom");
        assert_eq!(bottom_ms["native_grid"], serde_json::json!([2, 1, 1]));
        assert_eq!(bottom_ms["field_id"], "mat_ms");
        assert_eq!(bottom_ms["unit"], "A/m");
        assert_eq!(bottom_ms["value_count"], 2);
        assert_eq!(bottom_ms["values"], serde_json::json!([700e3, 710e3]));
        assert_eq!(bottom_ms["build_identity"], build_identity_json());

        let top_ms: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(
                output_dir.join("material-fields/fdm-multilayer/layer-top/mat_ms.json"),
            )
            .expect("top mat_ms payload should exist"),
        )
        .expect("top mat_ms payload should parse");
        assert_eq!(top_ms["layer_id"], "layer:top");
        assert_eq!(top_ms["native_grid"], serde_json::json!([3, 1, 1]));
        assert_eq!(top_ms["value_count"], 3);
        assert_eq!(top_ms["values"], serde_json::json!([810e3, 820e3, 830e3]));
        assert_eq!(top_ms["build_identity"], build_identity_json());
        assert_ne!(bottom_ms["value_sha256"], top_ms["value_sha256"]);

        let bottom_membership: serde_json::Value =
            serde_json::from_str(
                &fs::read_to_string(output_dir.join(
                    "material-fields/fdm-multilayer/layer-bottom/native-region-membership.json",
                ))
                .expect("bottom membership payload should exist"),
            )
            .expect("bottom membership payload should parse");
        assert_eq!(
            bottom_membership["native_region_mask"],
            serde_json::json!([1, 0])
        );
        assert_eq!(bottom_membership["build_identity"], build_identity_json());
        assert_eq!(
            bottom_membership["native_region_legend"][0]["object_id"],
            "bottom"
        );
        assert_eq!(
            bottom_membership["native_region_legend"][0]["region_id"],
            "edge"
        );

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn fdm_multilayer_material_artifacts_do_not_expand_scalar_fallbacks() {
        let plan = test_multilayer_execution_plan();
        let layout = field_layout(&plan);
        let layers = layout["layers"].as_array().expect("layer descriptors");
        assert!(layers.iter().all(|layer| {
            layer["material_fields"]
                .as_object()
                .is_some_and(|fields| fields.is_empty())
        }));

        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fdm-multilayer-no-scalar-fallback-{}-{}",
            std::process::id(),
            unique_suffix
        ));
        let assets = write_material_field_artifacts(&output_dir, &plan)
            .expect("missing arrays should remain unmaterialized");
        assert!(assets.is_empty());
        assert!(!output_dir
            .join("material-fields/fdm-multilayer/layer-bottom/mat_ms.json")
            .exists());
        if output_dir.exists() {
            fs::remove_dir_all(output_dir)
                .expect("temporary artifact directory should be removable");
        }
    }

    #[test]
    fn fdm_multilayer_material_artifacts_reject_wrong_lengths_and_nonfinite_values() {
        for case in ["wrong-length", "nonfinite"] {
            let mut plan = heterogeneous_multilayer_material_plan();
            let BackendPlanIR::FdmMultilayer(multilayer) = &mut plan.backend_plan else {
                panic!("expected multilayer FDM plan");
            };
            if case == "wrong-length" {
                multilayer.layers[0].material.ms_field = Some(vec![1.0]);
            } else {
                multilayer.layers[0].material.alpha_field = Some(vec![0.01, f64::NAN]);
            }
            let unique_suffix = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .expect("clock drift")
                .as_nanos();
            let output_dir = std::env::temp_dir().join(format!(
                "fullmag-artifacts-fdm-multilayer-invalid-{case}-{}-{}",
                std::process::id(),
                unique_suffix
            ));

            let error = write_material_field_artifacts(&output_dir, &plan)
                .expect_err("invalid material field must fail closed");

            assert_eq!(error.kind(), ErrorKind::InvalidData);
            assert!(error.to_string().contains("layer:bottom"));
            assert!(!output_dir
                .join("material-fields/fdm-multilayer/manifest.json")
                .exists());
            if output_dir.exists() {
                assert_eq!(
                    fs::read_dir(&output_dir)
                        .expect("invalid output directory should be readable")
                        .count(),
                    0,
                    "validation must complete before any multilayer material files are written"
                );
                fs::remove_dir_all(output_dir)
                    .expect("temporary artifact directory should be removable");
            }
        }
    }

    #[test]
    fn fdm_multilayer_native_grid_fingerprint_binds_active_mask_and_raw_membership() {
        let plan = heterogeneous_multilayer_material_plan();
        let BackendPlanIR::FdmMultilayer(multilayer) = &plan.backend_plan else {
            panic!("expected multilayer FDM plan");
        };
        let layer = &multilayer.layers[0];
        let active_count = layer
            .native_active_mask
            .as_deref()
            .map(|mask| mask.iter().filter(|active| **active).count())
            .unwrap_or(2);
        let expected = fullmag_ir::FdmGridCertificateIR::new_with_topology_tokens(
            layer.native_origin,
            layer.native_grid,
            layer.native_cell_size,
            active_count as u64,
            1,
            layer.native_active_mask.as_deref(),
            layer.native_region_mask.as_deref().unwrap(),
        )
        .expect("planner-native fingerprint")
        .grid_fingerprint;

        let layout = field_layout(&plan);
        assert_eq!(
            layout["layers"][0]["native_grid_fingerprint"],
            format!("sha256:{expected}")
        );
    }

    #[test]
    fn fdm_multilayer_invalid_layout_fails_closed_without_single_grid_field_fallback() {
        let mut plan = heterogeneous_multilayer_material_plan();
        let BackendPlanIR::FdmMultilayer(multilayer) = &mut plan.backend_plan else {
            panic!("expected multilayer FDM plan");
        };
        multilayer.layers[0].material.ms_field = Some(vec![700e3]);
        let context = build_field_context(&fullmag_ir::ProblemIR::bootstrap_example(), &plan);
        assert!(context.layout.get("layout_error").is_some());
        let snapshot = FieldSnapshot {
            name: "m".to_string(),
            step: 1,
            time: 1e-13,
            solver_dt: 1e-13,
            component_count: 3,
            component_order: "xyz".into(),
            location: "sample".into(),
            scope: "full".into(),
            revision: 1,
            values: FieldSnapshot::flatten_vec3(vec![[1.0, 0.0, 0.0]; 5]),
        };
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let fields_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fdm-multilayer-invalid-layout-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        let error = write_field_snapshot_artifact(
            &fields_dir,
            &context,
            &ExecutionProvenance::default(),
            &snapshot,
        )
        .expect_err("invalid multilayer layout must fail closed");

        assert_eq!(error.kind(), ErrorKind::InvalidData);
        assert!(!fields_dir.join("m/step_000001.json").exists());
        if fields_dir.exists() {
            fs::remove_dir_all(fields_dir)
                .expect("temporary artifact directory should be removable");
        }
    }

    #[test]
    fn fdm_multilayer_membership_artifacts_reject_regions_on_inactive_cells() {
        let mut plan = heterogeneous_multilayer_material_plan();
        let BackendPlanIR::FdmMultilayer(multilayer) = &mut plan.backend_plan else {
            panic!("expected multilayer FDM plan");
        };
        multilayer.layers[0].native_active_mask = Some(vec![true, false]);
        multilayer.layers[0].native_region_mask = Some(vec![1, 1]);
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fdm-multilayer-inactive-membership-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        let error = write_material_field_artifacts(&output_dir, &plan)
            .expect_err("inactive membership assignment must fail closed");

        assert_eq!(error.kind(), ErrorKind::InvalidData);
        assert!(error.to_string().contains("inactive cell"));
        assert!(!output_dir.exists());
    }

    #[test]
    fn fdm_multilayer_metadata_preserves_transfer_policy_and_grid_identity() {
        let mut plan = test_multilayer_execution_plan();
        let BackendPlanIR::FdmMultilayer(multilayer) = &mut plan.backend_plan else {
            panic!("expected multilayer FDM plan");
        };
        multilayer.periodicity = Some(fullmag_ir::FdmPeriodicityIR {
            axes: [
                fullmag_ir::AxisBoundary::Periodic,
                fullmag_ir::AxisBoundary::Open,
                fullmag_ir::AxisBoundary::Periodic,
            ],
            demag: fullmag_ir::FdmDemagPeriodicityIR::TruncatedImages,
            image_counts: Some([2, 0, 2]),
        });
        multilayer.grid_certificate = Some(
            fullmag_ir::FdmGridCertificateIR::new(
                [0.0, 0.0, 0.0],
                multilayer.common_cells,
                [2e-9, 2e-9, 1e-9],
                4,
                1024,
            )
            .expect("multilayer target grid certificate should be valid"),
        );

        let metadata = mesh_runtime_metadata(&plan);
        assert_eq!(
            metadata["transfer_boundary_policy"],
            serde_json::json!(["periodic", "open", "periodic"])
        );
        assert_eq!(
            metadata["periodic_axes"],
            serde_json::json!([true, false, true])
        );
        assert!(metadata["target_grid_fingerprint"].as_str().is_some());
        assert_eq!(metadata["transfer_provenance"].as_array().unwrap().len(), 2);
        assert!(
            metadata["transfer_provenance"][0]["source_grid_fingerprint"]
                .as_str()
                .is_some()
        );
    }

    #[test]
    fn fdm_multilayer_execution_provenance_records_transfer_realization() {
        let plan = test_multilayer_execution_plan();
        let provenance = ExecutionProvenance {
            execution_engine: "cpu_reference_multilayer".to_string(),
            ..ExecutionProvenance::default()
        };
        let value = execution_provenance_json(&plan, &provenance)
            .expect("multilayer transfer provenance should serialize");
        assert_eq!(
            value["fdm_multilayer_transfer"]["schema_version"],
            "fdm_multilayer_transfer_realization.v1"
        );
        assert_eq!(
            value["fdm_multilayer_transfer"]["realization"],
            "volume_weighted_overlap_adjoint"
        );
        assert_eq!(
            value["fdm_multilayer_transfer"]["layers"]
                .as_array()
                .unwrap()
                .len(),
            2
        );
    }

    #[test]
    fn fdm_multilayer_does_not_synthesize_a_single_grid_region_membership() {
        let plan = test_multilayer_execution_plan();

        let artifacts = crate::fdm::artifacts::region_membership_artifacts(&plan)
            .expect("multilayer membership policy should not fail artifact publication");

        assert!(artifacts.is_empty());
    }

    #[test]
    fn fdm_multilayer_mesh_provenance_artifacts_include_build_identity() {
        let mut plan = test_multilayer_execution_plan();
        let BackendPlanIR::FdmMultilayer(multilayer) = &mut plan.backend_plan else {
            panic!("expected multilayer FDM plan");
        };
        multilayer.periodicity = Some(fullmag_ir::FdmPeriodicityIR {
            axes: [
                fullmag_ir::AxisBoundary::Periodic,
                fullmag_ir::AxisBoundary::Open,
                fullmag_ir::AxisBoundary::Periodic,
            ],
            demag: fullmag_ir::FdmDemagPeriodicityIR::TruncatedImages,
            image_counts: Some([2, 0, 2]),
        });
        multilayer.grid_certificate = Some(
            fullmag_ir::FdmGridCertificateIR::new(
                [0.0, 0.0, 0.0],
                multilayer.common_cells,
                [2e-9, 2e-9, 1e-9],
                4,
                1024,
            )
            .expect("multilayer target grid certificate should be valid"),
        );

        let artifacts = crate::fdm::artifacts::transfer_provenance_artifacts(&plan);
        assert_eq!(artifacts.len(), 1);
        assert_eq!(
            artifacts[0].relative_path,
            "mesh/fdm_transfer_provenance.v1.json"
        );
        let value: serde_json::Value = serde_json::from_slice(&artifacts[0].bytes)
            .expect("transfer provenance artifact should be JSON");
        assert_eq!(value["schema_version"], "fdm_transfer_provenance.v1");
        assert_eq!(
            value["boundary_policy"],
            serde_json::json!(["periodic", "open", "periodic"])
        );
        assert_eq!(value["transfers"].as_array().unwrap().len(), 2);
        assert!(value["transfers"][0]["source_grid_fingerprint"]
            .as_str()
            .is_some());
        assert_eq!(
            value["transfers"][0]["target_grid_fingerprint"],
            value["target_grid_fingerprint"]
        );
        assert_eq!(value["build_identity"], build_identity_json());

        let grid_artifacts = crate::fdm::artifacts::grid_certificate_artifacts(&plan);
        assert_eq!(grid_artifacts.len(), 1);
        assert_eq!(
            grid_artifacts[0].relative_path,
            "mesh/fdm_grid_certificate.json"
        );
        let grid_value: serde_json::Value = serde_json::from_slice(&grid_artifacts[0].bytes)
            .expect("grid certificate artifact should be JSON");
        assert_eq!(grid_value["build_identity"], build_identity_json());

        let pbc_artifacts =
            crate::fdm::artifacts::pbc_provenance_artifacts(&plan, &ExecutionProvenance::default());
        assert_eq!(pbc_artifacts.len(), 1);
        assert_eq!(
            pbc_artifacts[0].relative_path,
            "mesh/fdm_pbc_provenance.v1.json"
        );
        let pbc_value: serde_json::Value = serde_json::from_slice(&pbc_artifacts[0].bytes)
            .expect("PBC provenance artifact should be JSON");
        assert_eq!(pbc_value["build_identity"], build_identity_json());
    }

    fn test_fem_execution_plan() -> ExecutionPlanIR {
        ExecutionPlanIR {
            common: CommonPlanMeta {
                ir_version: "v0".to_string(),
                requested_backend: fullmag_ir::BackendTarget::Fem,
                resolved_backend: fullmag_ir::BackendTarget::Fem,
                execution_mode: ExecutionMode::Strict,
                material_field_plans: Vec::new(),
            },
            backend_plan: BackendPlanIR::Fem(FemPlanIR {
                mesh_name: "unit_tet".to_string(),
                mesh_source: Some("meshes/unit_tet.msh".to_string()),
                mesh: MeshIR {
                    mesh_name: "unit_tet".to_string(),
                    nodes: vec![
                        [0.0, 0.0, 0.0],
                        [1.0, 0.0, 0.0],
                        [0.0, 1.0, 0.0],
                        [0.0, 0.0, 1.0],
                    ],
                    cells: fullmag_ir::FemConnectivityIR::from_tet4(vec![[0, 1, 2, 3]]),
                    element_markers: vec![1],
                    facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(vec![[0, 1, 2]]),
                    boundary_markers: vec![1],
                    periodic_boundary_pairs: Vec::new(),
                    periodic_node_pairs: Vec::new(),
                    per_domain_quality: HashMap::new(),
                },
                object_segments: vec![FemObjectSegmentIR {
                    object_id: "free".to_string(),
                    geometry_id: Some("pillar".to_string()),
                    node_start: 0,
                    node_count: 4,
                    element_start: 0,
                    element_count: 1,
                    boundary_face_start: 0,
                    boundary_face_count: 1,
                }],
                mesh_parts: Vec::new(),
                mesh_build_report: None,
                domain_mesh_mode: FemDomainMeshModeIR::MergedMagneticMesh,
                domain_frame: None,
                fe_order: 1,
                hmax: 0.4,
                initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                frozen_spins: None,
                material: MaterialIR {
                    name: "Py".to_string(),
                    saturation_magnetisation: 800e3,
                    exchange_stiffness: 13e-12,
                    damping: 0.02,
                    uniaxial_anisotropy: None,
                    anisotropy_axis: None,
                    uniaxial_anisotropy_k2: None,
                    cubic_anisotropy_kc1: None,
                    cubic_anisotropy_kc2: None,
                    cubic_anisotropy_kc3: None,
                    cubic_anisotropy_axis1: None,
                    cubic_anisotropy_axis2: None,
                    ms_field: None,
                    a_field: None,
                    alpha_field: None,
                    ku_field: None,
                    ku2_field: None,
                    kc1_field: None,
                    kc2_field: None,
                    kc3_field: None,
                    interfacial_dmi: None,
                    bulk_dmi: None,
                    dind_field: None,
                    dbulk_field: None,
                },
                anisotropy_axis_field: None,
                ms_element_field: None,
                a_element_field: None,
                region_materials: Vec::new(),
                enable_exchange: true,
                enable_demag: false,
                external_field: None,
                antenna_zeeman_masks: Vec::new(),
                solved_antenna_drive_bases: Vec::new(),
                field_drives: Vec::new(),
                field_drive_geometry_masks: Vec::new(),
                time_stage: Default::default(),
                current_modules: Vec::new(),
                charge_transport_plans: Vec::new(),
                spin_transport_plans: Vec::new(),
                gyromagnetic_ratio: 2.211e5,
                precision: ExecutionPrecision::Double,
                exchange_bc: ExchangeBoundaryCondition::Neumann,
                integrator: Some(IntegratorChoice::Heun),
                fixed_timestep: Some(1e-13),
                adaptive_timestep: None,
                field_refresh: None,
                relaxation: None,
                demag_realization: None,
                air_box_config: None,
                interfacial_dmi: None,
                rotated_interfacial_dmi: None,
                dmi_interface_normal: None,
                bulk_dmi: None,
                dind_field: None,
                dbulk_field: None,
                temperature: None,
                current_density: None,
                stt_degree: None,
                stt_beta: None,
                stt_spin_polarization: None,
                stt_lambda: None,
                stt_epsilon_prime: None,
                stt_thickness: None,
                stt_fixed_layer_position: None,
                spin_torque_contract: None,
                has_oersted_cylinder: false,
                oersted_current: None,
                oersted_radius: None,
                oersted_center: None,
                oersted_axis: None,
                oersted_field_xyz: None,
                oersted_time_dep_kind: 0,
                oersted_time_dep_freq: 0.0,
                oersted_time_dep_phase: 0.0,
                oersted_time_dep_offset: 0.0,
                oersted_time_dep_t_on: 0.0,
                oersted_time_dep_t_off: 0.0,
                magnetoelastic: None,
                mechanics: None,
                demag_solver_policy: None,
                thermal_seed_config: None,
                oersted_realization: None,
                gpu_device_index: None,
                mfem_device_string: None,
                use_consistent_mass: None,
            }),
            output_plan: OutputPlanIR {
                outputs: Vec::new(),
            },
            provenance: ProvenancePlanIR {
                notes: Vec::new(),
                integrator_resolution: None,
                fem_eigen_execution_resolution: None,
                physics_graph: None,
            },
        }
    }

    fn final_execution_test_run(provenance: ExecutionProvenance) -> ExecutedRun {
        ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 1,
                    e_total: -1.0,
                    max_torque_Apm: 0.0,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance,
        }
    }

    fn test_fem_eigen_execution_plan() -> ExecutionPlanIR {
        ExecutionPlanIR {
            common: CommonPlanMeta {
                ir_version: "v0".to_string(),
                requested_backend: fullmag_ir::BackendTarget::Fem,
                resolved_backend: fullmag_ir::BackendTarget::Fem,
                execution_mode: ExecutionMode::Strict,
                material_field_plans: vec![MaterialFieldPlan {
                    object_id: "free".to_string(),
                    parameter: MaterialParameterNameIR::Ms,
                    source_kind: MaterialFieldSourceKind::Override,
                    realization_location: MaterialFieldLocationIR::Node,
                    requires_sampling: false,
                    requires_mesh_revision: false,
                    warnings: Vec::new(),
                    realization_method: Some("immutable_generation_fixture".to_string()),
                    statistics: None,
                }],
            },
            backend_plan: BackendPlanIR::FemEigen(fullmag_ir::FemEigenPlanIR {
                mesh_name: "unit_tet".to_string(),
                mesh_source: Some("meshes/unit_tet.msh".to_string()),
                mesh: MeshIR {
                    mesh_name: "unit_tet".to_string(),
                    nodes: vec![
                        [0.0, 0.0, 0.0],
                        [1.0, 0.0, 0.0],
                        [0.0, 1.0, 0.0],
                        [0.0, 0.0, 1.0],
                    ],
                    cells: fullmag_ir::FemConnectivityIR::from_tet4(vec![[0, 1, 2, 3]]),
                    element_markers: vec![1],
                    facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(vec![[0, 1, 2]]),
                    boundary_markers: vec![1],
                    periodic_boundary_pairs: Vec::new(),
                    periodic_node_pairs: Vec::new(),
                    per_domain_quality: HashMap::new(),
                },
                object_segments: vec![FemObjectSegmentIR {
                    object_id: "free".to_string(),
                    geometry_id: Some("pillar".to_string()),
                    node_start: 0,
                    node_count: 4,
                    element_start: 0,
                    element_count: 1,
                    boundary_face_start: 0,
                    boundary_face_count: 1,
                }],
                mesh_parts: Vec::new(),
                mesh_build_report: None,
                domain_mesh_mode: FemDomainMeshModeIR::MergedMagneticMesh,
                domain_frame: None,
                fe_order: 1,
                hmax: 0.4,
                equilibrium_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                material: MaterialIR {
                    name: "Py".to_string(),
                    saturation_magnetisation: 800e3,
                    exchange_stiffness: 13e-12,
                    damping: 0.02,
                    uniaxial_anisotropy: None,
                    anisotropy_axis: None,
                    uniaxial_anisotropy_k2: None,
                    cubic_anisotropy_kc1: None,
                    cubic_anisotropy_kc2: None,
                    cubic_anisotropy_kc3: None,
                    cubic_anisotropy_axis1: None,
                    cubic_anisotropy_axis2: None,
                    ms_field: Some(vec![800e3; 4]),
                    a_field: None,
                    alpha_field: None,
                    ku_field: None,
                    ku2_field: None,
                    kc1_field: None,
                    kc2_field: None,
                    kc3_field: None,
                    interfacial_dmi: None,
                    bulk_dmi: None,
                    dind_field: None,
                    dbulk_field: None,
                },
                operator: fullmag_ir::EigenOperatorConfigIR {
                    kind: fullmag_ir::EigenOperatorIR::LinearizedLlg,
                    include_demag: false,
                },
                count: 2,
                target: fullmag_ir::EigenTargetIR::FrequencyWindow {
                    frequency_min_hz: 1.0e8,
                    frequency_max_hz: 5.0e9,
                },
                equilibrium: fullmag_ir::EquilibriumSourceIR::RelaxedInitialState,
                k_sampling: Some(fullmag_ir::KSamplingIR::Single {
                    k_vector: [0.0, 0.0, 0.0],
                }),
                bias_field_samples: Vec::new(),
                normalization: fullmag_ir::EigenNormalizationIR::UnitL2,
                damping_policy: fullmag_ir::EigenDampingPolicyIR::Include,
                enable_exchange: true,
                enable_demag: false,
                interfacial_dmi: None,
                dmi_interface_normal: None,
                bulk_dmi: None,
                external_field: None,
                gyromagnetic_ratio: 2.211e5,
                precision: ExecutionPrecision::Double,
                exchange_bc: ExchangeBoundaryCondition::Neumann,
                spin_wave_bc: fullmag_ir::SpinWaveBoundaryConditionIR::default(),
                demag_realization: None,
                air_box_config: None,
                mode_tracking: None,
                dispersion_validation: None,
                k0_kittel_validation: None,
                solver_policy: None,
            }),
            output_plan: OutputPlanIR {
                outputs: Vec::new(),
            },
            provenance: ProvenancePlanIR {
                notes: Vec::new(),
                integrator_resolution: None,
                fem_eigen_execution_resolution: None,
                physics_graph: None,
            },
        }
    }

    fn test_fem_eigen_generation_artifacts(spectrum: &[u8]) -> Vec<crate::types::AuxiliaryArtifact> {
        let store = "eigen/mode_fields.zarr";
        let array = "eigen/mode_fields.zarr/sample_0000/mode_0000/vector_xyz_complex";
        let chunk = format!("{array}/0.0.0");
        let compatibility = "eigen/mode_fields/sample_0000/mode_0000/vector.bin";
        let mode_metadata_path = "eigen/modes/sample_0000/mode_0000.json";
        let manifest = serde_json::json!({
            "schema_version": "frequency_domain_manifest.v1",
            "artifacts": {
                "solver_diagnostics_path": "eigen/diagnostics/solver.v1.json",
                "spectrum_v2_path": "eigen/spectrum.v2.json",
                "mode_field_zarr_store_path": store,
                "mode_metadata_paths": [mode_metadata_path],
            }
        });
        let mode_metadata = serde_json::json!({
            "storage_format": "zarr",
            "zarr_store_path": store,
            "zarr_array_path": array,
            "zarr_chunk_path": chunk,
            "compatibility_binary_payload_path": compatibility,
        });
        vec![
            crate::types::AuxiliaryArtifact {
                relative_path: "eigen/spectrum.json".to_string(),
                bytes: spectrum.to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: "eigen/spectrum.v2.json".to_string(),
                bytes: spectrum.to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: "eigen/diagnostics/solver.v1.json".to_string(),
                bytes: br#"{"status":"ready"}"#.to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: mode_metadata_path.to_string(),
                bytes: serde_json::to_vec(&mode_metadata).unwrap(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: format!("{store}/.zgroup"),
                bytes: br#"{"zarr_format":2}"#.to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: format!("{store}/.zattrs"),
                bytes: br#"{}"#.to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: format!("{store}/sample_0000/.zgroup"),
                bytes: br#"{"zarr_format":2}"#.to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: format!("{store}/sample_0000/mode_0000/.zgroup"),
                bytes: br#"{"zarr_format":2}"#.to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: format!("{array}/.zarray"),
                bytes: br#"{"zarr_format":2}"#.to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: format!("{array}/.zattrs"),
                bytes: br#"{}"#.to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: chunk,
                bytes: b"mode data chunk".to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: compatibility.to_string(),
                bytes: b"compatibility mode payload".to_vec(),
            },
            crate::types::AuxiliaryArtifact {
                relative_path: "frequency_domain/manifest.v1.json".to_string(),
                bytes: serde_json::to_vec_pretty(&manifest).unwrap(),
            },
        ]
    }
    fn assert_immutable_fem_eigen_references_resolve(
        output_dir: &Path,
        capture: &crate::artifact_generation::GenerationCapture,
    ) {
        assert!(capture.is_immutable());
        let metadata: serde_json::Value = serde_json::from_slice(
            &capture.read_member(output_dir, "metadata.json").unwrap(),
        )
        .unwrap();
        let material_assets = metadata["material_field_assets"]
            .as_array()
            .expect("metadata carries material field references");
        assert_eq!(material_assets.len(), 1);
        for asset in material_assets {
            let relative = asset["artifact_path"]
                .as_str()
                .expect("material asset has a path");
            assert!(capture.commit.content.members.contains_key(relative));
            let _: serde_json::Value =
                serde_json::from_slice(&capture.read_member(output_dir, relative).unwrap())
                    .expect("material field member resolves and parses");
        }

        let manifest: serde_json::Value = serde_json::from_slice(
            &capture
                .read_member(output_dir, "frequency_domain/manifest.v1.json")
                .unwrap(),
        )
        .unwrap();
        let artifacts = manifest["artifacts"]
            .as_object()
            .expect("manifest artifacts are an object");
        for (name, value) in artifacts {
            if name == "mode_field_zarr_store_path" {
                if let Some(store) = value.as_str() {
                    for suffix in [".zgroup", ".zattrs"] {
                        capture
                            .read_member(output_dir, &format!("{store}/{suffix}"))
                            .expect("Zarr directory resolves to its root metadata members");
                    }
                }
            } else if name.ends_with("_path") {
                if let Some(relative) = value.as_str() {
                    assert!(capture.commit.content.members.contains_key(relative));
                    capture.read_member(output_dir, relative).unwrap();
                }
            } else if name.ends_with("_paths") {
                if let Some(paths) = value.as_array() {
                    for relative in paths.iter().filter_map(serde_json::Value::as_str) {
                        assert!(capture.commit.content.members.contains_key(relative));
                        capture.read_member(output_dir, relative).unwrap();
                        if name == "mode_metadata_paths" {
                            let mode: serde_json::Value = serde_json::from_slice(
                                &capture.read_member(output_dir, relative).unwrap(),
                            )
                            .unwrap();
                            if let Some(array_path) = mode
                                .get("zarr_array_path")
                                .and_then(serde_json::Value::as_str)
                            {
                                let store = mode["zarr_store_path"].as_str().unwrap();
                                let relative = array_path
                                    .strip_prefix(&format!("{store}/"))
                                    .expect("mode array path is inside its store");
                                let components = relative.split('/').collect::<Vec<_>>();
                                let mut group = store.to_string();
                                for component in components.iter().take(components.len() - 1) {
                                    group.push('/');
                                    group.push_str(component);
                                    capture
                                        .read_member(output_dir, &format!("{group}/.zgroup"))
                                        .expect("Zarr parent group resolves");
                                }
                                for suffix in [".zarray", ".zattrs"] {
                                    capture
                                        .read_member(output_dir, &format!("{array_path}/{suffix}"))
                                        .expect("mode array descriptors resolve");
                                }
                            }
                            for field in ["zarr_chunk_path", "compatibility_binary_payload_path"] {
                                if let Some(path) = mode.get(field).and_then(serde_json::Value::as_str) {
                                    capture
                                        .read_member(output_dir, path)
                                        .expect("mode payload references resolve");
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    #[test]
    fn fem_eigen_writer_publishes_two_immutable_generations_and_preserves_legacy_root() {
        let suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-fem-eigen-v2-writer-{}-{suffix}",
            std::process::id()
        ));
        let sentinels = [
            ("metadata.json", b"legacy metadata sentinel".as_slice()),
            (
                "material-fields/free_ms_node.json",
                b"legacy material sentinel".as_slice(),
            ),
            ("eigen/spectrum.json", b"legacy eigen sentinel".as_slice()),
            (
                "frequency_domain/manifest.v1.json",
                b"legacy frequency manifest sentinel".as_slice(),
            ),
        ];
        for (relative, _) in sentinels {
            let path = output_dir.join(relative);
            fs::create_dir_all(path.parent().unwrap()).unwrap();
        }
        for (relative, bytes) in sentinels {
            fs::write(output_dir.join(relative), bytes).unwrap();
        }

        let mut problem = fem_execution_problem("cpu", ExecutionMode::Strict);
        for (key, value) in [
            ("producer_run_id", "writer-run"),
            ("producer_stage_id", "eigen-stage"),
            ("producer_stage_kind", "eigenmodes"),
        ] {
            problem
                .problem_meta
                .runtime_metadata
                .insert(key.to_string(), serde_json::json!(value));
        }
        let expected_owner = crate::artifact_generation::PublicationOwner {
            run_id: "writer-run".to_string(),
            stage_id: "eigen-stage".to_string(),
            stage_kind: "eigenmodes".to_string(),
        };
        let plan = test_fem_eigen_execution_plan();
        let provenance = ExecutionProvenance {
            execution_engine: "fem_eigen_cpu_baseline".to_string(),
            precision: "double".to_string(),
            ..ExecutionProvenance::default()
        };
        let summary = ArtifactPipelineSummary::default();
        let mut first_run = final_execution_test_run(provenance.clone());
        first_run.auxiliary_artifacts = test_fem_eigen_generation_artifacts(b"spectrum generation one");
        write_artifacts(&output_dir, &problem, &plan, &first_run, Some(&summary))
            .expect("first FEM eigen v2 publication should accept a streamed summary");

        let first_capture = crate::artifact_generation::capture(&output_dir)
            .unwrap()
            .expect("first immutable generation should be current");
        assert_immutable_fem_eigen_references_resolve(&output_dir, &first_capture);
        assert_eq!(first_capture.commit.content.producer.as_ref(), Some(&expected_owner));
        let first_generation_id = first_capture.commit.generation_id.clone();
        let first_member_bytes = first_capture
            .commit
            .content
            .members
            .keys()
            .map(|relative| {
                (
                    relative.clone(),
                    first_capture.read_member(&output_dir, relative).unwrap(),
                )
            })
            .collect::<Vec<_>>();
        for (relative, bytes) in &sentinels {
            assert_eq!(fs::read(output_dir.join(relative)).unwrap(), bytes.to_vec());
        }

        let mut second_run = final_execution_test_run(provenance.clone());
        second_run.auxiliary_artifacts =
            test_fem_eigen_generation_artifacts(b"spectrum generation two");
        write_artifacts(&output_dir, &problem, &plan, &second_run, Some(&summary))
            .expect("second FEM eigen v2 publication should advance the current pointer");

        let second_capture = crate::artifact_generation::capture(&output_dir)
            .unwrap()
            .expect("second immutable generation should be current");
        assert_ne!(second_capture.commit.generation_id, first_generation_id);
        assert_immutable_fem_eigen_references_resolve(&output_dir, &second_capture);
        assert_eq!(second_capture.commit.content.producer.as_ref(), Some(&expected_owner));
        assert_eq!(
            second_capture.read_member(&output_dir, "eigen/spectrum.json").unwrap(),
            b"spectrum generation two".to_vec()
        );

        let first_generation_name = first_generation_id
            .strip_prefix("sha256:")
            .expect("generation ID has canonical digest prefix");
        let first_generation_dir = output_dir
            .join("frequency_domain/generations")
            .join(first_generation_name);
        for (relative, bytes) in &first_member_bytes {
            assert_eq!(
                fs::read(first_generation_dir.join(relative)).unwrap(),
                *bytes,
                "old immutable member {relative} must remain byte-identical",
            );
        }

        for (relative, bytes) in sentinels {
            assert_eq!(fs::read(output_dir.join(relative)).unwrap(), bytes);
        }

        let pointer_path = output_dir.join(crate::artifact_generation::IMMUTABLE_COMMIT_PATH);
        let pointer_before_failure = fs::read(&pointer_path).unwrap();

        let mut invalid_owner_problem = problem.clone();
        invalid_owner_problem
            .problem_meta
            .runtime_metadata
            .remove("producer_stage_id");
        let mut invalid_owner_run = final_execution_test_run(provenance.clone());
        invalid_owner_run.auxiliary_artifacts =
            test_fem_eigen_generation_artifacts(b"spectrum with invalid owner");
        let owner_error = write_artifacts(
            &output_dir,
            &invalid_owner_problem,
            &plan,
            &invalid_owner_run,
            Some(&summary),
        )
        .expect_err("partial producer ownership must fail before publication");
        assert!(owner_error
            .to_string()
            .contains("incomplete frequency-domain publication owner"));
        assert_eq!(fs::read(&pointer_path).unwrap(), pointer_before_failure);
        assert_eq!(
            crate::artifact_generation::capture(&output_dir)
                .unwrap()
                .unwrap()
                .commit,
            second_capture.commit
        );
        for (relative, bytes) in &sentinels {
            assert_eq!(fs::read(output_dir.join(relative)).unwrap(), bytes.to_vec());
        }

        let mut failed_run = final_execution_test_run(provenance.clone());
        failed_run.auxiliary_artifacts =
            test_fem_eigen_generation_artifacts(b"spectrum rejected generation");
        failed_run
            .auxiliary_artifacts
            .push(crate::types::AuxiliaryArtifact {
                relative_path: "../outside.json".to_string(),
                bytes: b"must never be written".to_vec(),
            });
        let error = write_artifacts(&output_dir, &problem, &plan, &failed_run, Some(&summary))
            .expect_err("invalid member closure must fail before changing the current pointer");
        assert_eq!(error.kind(), ErrorKind::InvalidData);
        assert!(error.to_string().contains("generation member path"));
        assert_eq!(fs::read(&pointer_path).unwrap(), pointer_before_failure);
        assert_eq!(
            crate::artifact_generation::capture(&output_dir)
                .unwrap()
                .unwrap()
                .commit,
            second_capture.commit
        );
        for (relative, bytes) in sentinels {
            assert_eq!(fs::read(output_dir.join(relative)).unwrap(), bytes);
        }
        assert!(!output_dir
            .join(".frequency-domain-publication.lease")
            .exists());

        let mut missing_reference_run = final_execution_test_run(provenance);
        missing_reference_run.auxiliary_artifacts =
            test_fem_eigen_generation_artifacts(b"spectrum with missing reference");
        let manifest_artifact = missing_reference_run
            .auxiliary_artifacts
            .iter_mut()
            .find(|artifact| artifact.relative_path == "frequency_domain/manifest.v1.json")
            .expect("fixture has a frequency-domain manifest");
        let mut manifest: serde_json::Value =
            serde_json::from_slice(&manifest_artifact.bytes).unwrap();
        manifest["artifacts"]["solver_diagnostics_path"] =
            serde_json::json!("eigen/diagnostics/missing.v1.json");
        manifest_artifact.bytes = serde_json::to_vec_pretty(&manifest).unwrap();
        let missing_reference_error = write_artifacts(
            &output_dir,
            &problem,
            &plan,
            &missing_reference_run,
            Some(&summary),
        )
        .expect_err("a missing manifest member must fail before advancing the generation");
        assert_eq!(missing_reference_error.kind(), ErrorKind::InvalidData);
        assert!(missing_reference_error
            .to_string()
            .contains("manifest.artifacts.solver_diagnostics_path references missing immutable generation member 'eigen/diagnostics/missing.v1.json'"));
        assert_eq!(fs::read(&pointer_path).unwrap(), pointer_before_failure);
        assert_eq!(
            crate::artifact_generation::capture(&output_dir)
                .unwrap()
                .unwrap()
                .commit,
            second_capture.commit
        );
        for (relative, bytes) in sentinels {
            assert_eq!(fs::read(output_dir.join(relative)).unwrap(), bytes);
        }

        fs::remove_dir_all(output_dir).expect("temporary FEM eigen output should be removed");
    }

    #[test]
    fn final_native_snapshot_uses_captured_endpoint_and_rejects_corrupt_or_duplicate_proof() {
        use fullmag_quantities::fem_state_snapshot_receipt::{
            FemLocalNodeSnapshotReceipt, FEM_FINAL_SNAPSHOT_RECEIPT_ARTIFACT,
        };
        use fullmag_quantities::{
            FemMaterialFieldLocation, FemRepresentationReceipt, FemStateRepresentation,
        };
        let plan = test_fem_execution_plan();
        let context = FieldArtifactContext {
            problem_name: "native-final-state".into(),
            ir_version: "v0".into(),
            source_hash: None,
            execution_mode: ExecutionMode::Strict,
            layout: field_layout(&plan),
            magnetization_field_semantics: Ok(None),
            execution_resolution: None,
        };
        let mut executed = final_execution_test_run(ExecutionProvenance {
            execution_engine: "fem_cpu_native".into(),
            ..ExecutionProvenance::default()
        });
        let receipt = FemLocalNodeSnapshotReceipt::capture(
            9,
            0.9,
            0.1,
            &executed.result.final_magnetization,
            FemRepresentationReceipt {
                schema_version: 1,
                state_space: FemStateRepresentation::LocalNodeAos,
                ms_location: FemMaterialFieldLocation::Scalar,
                a_location: FemMaterialFieldLocation::Scalar,
                local_node_count: 4,
                true_node_count: 2,
                periodic_map_revision: 13,
                representation_copy_count: 0,
                gather_scatter_bytes: 0,
                invalid_space_assertion_count: 0,
                hot_loop_representation_copy_count: 0,
                hot_loop_gather_scatter_bytes: 0,
            },
        )
        .unwrap();
        executed
            .auxiliary_artifacts
            .push(crate::types::AuxiliaryArtifact {
                relative_path: FEM_FINAL_SNAPSHOT_RECEIPT_ARTIFACT.into(),
                bytes: serde_json::to_vec(&receipt).unwrap(),
            });
        let mut stats = executed.result.steps[0].clone();
        let captured = final_native_snapshot_receipt(&context, &executed, &mut stats).unwrap();
        assert_eq!((stats.step, stats.time, stats.dt), (9, 0.9, 0.1));
        assert!(context.layout.get("native_state_snapshot").is_none());
        assert_eq!(captured.unwrap(), receipt);
        {
            use fullmag_quantities::fem_local_node_map::{FemLocalNodeIndexMap, FEM_LOCAL_NODE_MAP_SCHEMA, FEM_FINAL_NODE_MAP_ARTIFACT};
            let map = FemLocalNodeIndexMap { schema_version: FEM_LOCAL_NODE_MAP_SCHEMA.into(), local_node_count: 4,
                mfem_local_dof_count: 4, mfem_true_dof_count: 4, core_periodic_class_count: 2,
                core_periodic_map_revision: 13, canonical_node_to_mfem_local_dof: vec![0,1,2,3],
                local_node_to_core_class: vec![0,1,0,1], core_class_representatives: vec![0,1] };
            let mut bound_receipt = receipt.clone();
            bound_receipt.native_node_map_sha256 = Some(map.content_sha256().unwrap());
            assert!(final_native_node_map(&executed, Some(&bound_receipt)).is_err());
            let mut mapped = executed.clone();
            mapped.auxiliary_artifacts.push(crate::types::AuxiliaryArtifact {
                relative_path: FEM_FINAL_NODE_MAP_ARTIFACT.into(), bytes: serde_json::to_vec(&map).unwrap(),
            });
            assert_eq!(final_native_node_map(&mapped, Some(&bound_receipt)).unwrap(), Some(map));
            assert!(final_native_node_map(&mapped, None).is_err());
            assert!(final_native_node_map(&mapped, Some(&receipt)).is_err());
            mapped.auxiliary_artifacts.push(mapped.auxiliary_artifacts.last().unwrap().clone());
            assert!(final_native_node_map(&mapped, Some(&bound_receipt)).is_err());
        }
        let mut invalid = executed.clone();
        invalid.result.final_magnetization[0][0] = 0.5;
        assert!(final_native_snapshot_receipt(&context, &invalid, &mut stats).is_err());
        invalid = executed.clone();
        invalid.provenance.execution_engine = "fem_cpu_baseline_internal".into();
        assert!(final_native_snapshot_receipt(&context, &invalid, &mut stats).is_err());
        invalid = executed.clone();
        invalid
            .auxiliary_artifacts
            .push(invalid.auxiliary_artifacts[0].clone());
        assert!(final_native_snapshot_receipt(&context, &invalid, &mut stats).is_err());
        invalid = executed.clone();
        invalid.auxiliary_artifacts.clear();
        let legacy = final_native_snapshot_receipt(&context, &invalid, &mut stats).unwrap();
        assert!(legacy.is_none());
    }

    #[test]
    fn mapped_source_budget_covers_values_map_and_metadata_together() {
        let value = serde_json::json!({ "values": [[1.0, 0.0, 0.0]],
            "native_node_map": { "canonical_node_to_mfem_local_dof": [0] },
            "state_identity": { "backend": "fem" } });
        let length = serde_json::to_vec_pretty(&value).unwrap().len();
        validate_mapped_state_byte_budget(&value, length).unwrap();
        assert!(validate_mapped_state_byte_budget(&value, length - 1).is_err());
        assert!(serde_json::to_vec_pretty(&value["values"]).unwrap().len() < length - 1);
        assert!(serde_json::to_vec_pretty(&value["native_node_map"]).unwrap().len() < length - 1);
    }

    fn write_final_execution_test_metadata(
        label: &str,
        problem: &fullmag_ir::ProblemIR,
        plan: &ExecutionPlanIR,
        provenance: ExecutionProvenance,
    ) -> std::io::Result<serde_json::Value> {
        let suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-final-execution-{label}-{}-{suffix}",
            std::process::id()
        ));
        let result = write_artifacts(
            &output_dir,
            problem,
            plan,
            &final_execution_test_run(provenance),
            None,
        )
        .and_then(|()| {
            let raw = fs::read_to_string(output_dir.join("metadata.json"))?;
            serde_json::from_str(&raw).map_err(|error| {
                Error::new(
                    ErrorKind::InvalidData,
                    format!("final execution metadata is invalid JSON: {error}"),
                )
            })
        });
        let _ = fs::remove_dir_all(&output_dir);
        result
    }

    #[test]
    fn write_artifacts_refuses_eigen_auxiliary_when_immutable_generation_marker_exists() {
        let suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-v1-writer-v2-marker-{}-{suffix}",
            std::process::id()
        ));
        fs::create_dir_all(output_dir.join("frequency_domain"))
            .expect("frequency-domain marker directory should be created");
        fs::create_dir_all(output_dir.join("eigen"))
            .expect("legacy eigen directory should be created");

        let marker_path = output_dir.join(crate::artifact_generation::IMMUTABLE_COMMIT_PATH);
        let marker_sentinel = b"malformed but present immutable generation marker";
        let metadata_path = output_dir.join("metadata.json");
        let metadata_sentinel = b"legacy metadata must remain byte-identical";
        let member_path = output_dir.join("eigen/spectrum.json");
        let member_sentinel = b"legacy eigen member must remain byte-identical";
        fs::write(&marker_path, marker_sentinel).expect("v2 marker should be seeded");
        fs::write(&metadata_path, metadata_sentinel).expect("legacy metadata should be seeded");
        fs::write(&member_path, member_sentinel).expect("legacy eigen member should be seeded");

        let problem = fullmag_ir::ProblemIR::bootstrap_example();
        let plan = test_fem_execution_plan();
        let mut executed = final_execution_test_run(ExecutionProvenance::default());
        executed
            .auxiliary_artifacts
            .push(crate::types::AuxiliaryArtifact {
                relative_path: "eigen/spectrum.json".to_string(),
                bytes: b"replacement spectrum from the v1 writer".to_vec(),
            });

        let error = write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect_err("legacy writer must refuse an existing immutable v2 marker");
        assert_eq!(error.kind(), ErrorKind::InvalidData);
        assert!(error
            .to_string()
            .contains("v1 publisher cannot shadow the current immutable v2 generation"));
        assert_eq!(fs::read(&marker_path).unwrap(), marker_sentinel.to_vec());
        assert_eq!(fs::read(&metadata_path).unwrap(), metadata_sentinel.to_vec());
        assert_eq!(fs::read(&member_path).unwrap(), member_sentinel.to_vec());
        assert!(!output_dir
            .join(".frequency-domain-publication.lease")
            .exists());

        fs::remove_dir_all(output_dir).expect("temporary writer fixture should be removed");
    }

    #[test]
    fn metadata_persists_authoritative_stage_completion() {
        let problem = fem_execution_problem("cpu", ExecutionMode::Strict);
        let plan = test_fem_execution_plan();
        let mut executed = final_execution_test_run(ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            ..ExecutionProvenance::default()
        });
        executed.result.completion = Some(fullmag_ir::StageCompletionIR {
            status: "completed".to_string(),
            converged: true,
            reason: Some(fullmag_ir::StageStopReason::Torque),
            metric: Some(fullmag_ir::StageMetricKind::MaxTorqueApm),
            metric_name: Some("max_torque_apm".to_string()),
            metric_value: Some(0.25),
            threshold: Some(1.0),
        });
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-authoritative-completion-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .expect("clock drift")
                .as_nanos()
        ));

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("artifact write should preserve completion");
        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata should exist"),
        )
        .expect("metadata should parse");

        assert_eq!(metadata["completion"]["status"], "completed");
        assert_eq!(metadata["completion"]["converged"], true);
        assert_eq!(metadata["completion"]["reason"], "torque");
        assert_eq!(metadata["completion"]["metric"], "max_torque_apm");
        fs::remove_dir_all(output_dir).expect("temporary completion artifacts should be removed");
    }

    fn write_final_execution_test_metadata_with_fem_policy(
        policy: &str,
        label: &str,
        problem: &fullmag_ir::ProblemIR,
        plan: &ExecutionPlanIR,
        provenance: ExecutionProvenance,
    ) -> std::io::Result<serde_json::Value> {
        with_fem_execution_policy(policy, || {
            write_final_execution_test_metadata(label, problem, plan, provenance)
        })
    }

    fn write_final_execution_test_metadata_without_fem_policy(
        label: &str,
        problem: &fullmag_ir::ProblemIR,
        plan: &ExecutionPlanIR,
        provenance: ExecutionProvenance,
    ) -> std::io::Result<serde_json::Value> {
        without_fem_execution_policy(|| {
            write_final_execution_test_metadata(label, problem, plan, provenance)
        })
    }

    fn with_fem_execution_policy<T>(policy: &str, action: impl FnOnce() -> T) -> T {
        let _guard = FINAL_EXECUTION_ENV_LOCK
            .lock()
            .expect("lock final execution test environment");
        let previous = std::env::var_os("FULLMAG_FEM_EXECUTION");
        unsafe {
            std::env::set_var("FULLMAG_FEM_EXECUTION", policy);
        }
        let result = action();
        unsafe {
            if let Some(previous) = previous {
                std::env::set_var("FULLMAG_FEM_EXECUTION", previous);
            } else {
                std::env::remove_var("FULLMAG_FEM_EXECUTION");
            }
        }
        result
    }

    fn without_fem_execution_policy<T>(action: impl FnOnce() -> T) -> T {
        let _guard = FINAL_EXECUTION_ENV_LOCK
            .lock()
            .expect("lock final execution test environment");
        let previous_execution = std::env::var_os("FULLMAG_FEM_EXECUTION");
        let previous_all_in_gpu = std::env::var_os("FULLMAG_FEM_ALL_IN_GPU");
        unsafe {
            std::env::remove_var("FULLMAG_FEM_EXECUTION");
            std::env::remove_var("FULLMAG_FEM_ALL_IN_GPU");
        }
        let result = action();
        unsafe {
            if let Some(previous) = previous_execution {
                std::env::set_var("FULLMAG_FEM_EXECUTION", previous);
            }
            if let Some(previous) = previous_all_in_gpu {
                std::env::set_var("FULLMAG_FEM_ALL_IN_GPU", previous);
            }
        }
        result
    }

    fn fem_execution_problem(device: &str, mode: ExecutionMode) -> fullmag_ir::ProblemIR {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.backend_policy.requested_backend = fullmag_ir::BackendTarget::Fem;
        problem.validation_profile.execution_mode = mode;
        problem.problem_meta.runtime_metadata.insert(
            "runtime_selection".to_string(),
            serde_json::json!({
                "device": device,
                "precision": "double",
            }),
        );
        problem
    }

    fn fdm_execution_problem(device: &str, mode: ExecutionMode) -> fullmag_ir::ProblemIR {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.backend_policy.requested_backend = fullmag_ir::BackendTarget::Fdm;
        problem.validation_profile.execution_mode = mode;
        problem.problem_meta.runtime_metadata.insert(
            "runtime_selection".to_string(),
            serde_json::json!({
                "device": device,
                "precision": "double",
            }),
        );
        problem
    }

    #[test]
    fn final_metadata_contains_no_fallback_cpu_execution_resolution() {
        let problem = fem_execution_problem("cpu", ExecutionMode::Extended);
        let mut plan = test_fem_execution_plan();
        plan.common.execution_mode = ExecutionMode::Extended;
        let provenance = ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            ..ExecutionProvenance::default()
        };
        let expected_provenance = execution_provenance_json(&plan, &provenance)
            .expect("legacy typed provenance projection must serialize");
        let metadata = write_final_execution_test_metadata_without_fem_policy(
            "cpu-exact",
            &problem,
            &plan,
            provenance,
        )
        .expect("CPU final metadata should be written");

        let mut actual_provenance = metadata["execution_provenance"].clone();
        let actual_provenance_object = actual_provenance
            .as_object_mut()
            .expect("metadata execution provenance must be an object");
        actual_provenance_object.remove("execution_resolution");
        actual_provenance_object.remove("resolved_cpu_threads");
        assert_eq!(actual_provenance, expected_provenance);

        let resolution = &metadata["execution_provenance"]["execution_resolution"];
        assert_eq!(resolution["authored_request"]["backend"], "fem");
        assert_eq!(resolution["authored_request"]["device"], "cpu");
        assert_eq!(resolution["effective_request"]["device"], "cpu");
        assert_eq!(resolution["resolved_execution"]["backend"], "fem");
        assert_eq!(resolution["resolved_execution"]["device"], "cpu");
        assert_eq!(resolution["resolution_mode"], "exact");
        assert_eq!(resolution["fallback_occurred"], false);
        assert!(resolution.get("fallback_reason").is_some());
        assert!(resolution["fallback_reason"].is_null());
        let typed: crate::types::FinalExecutionResolutionProvenance =
            serde_json::from_value(resolution.clone())
                .expect("final execution resolution must deserialize to its typed contract");
        assert_eq!(
            serde_json::to_value(typed).expect("typed final resolution must serialize"),
            *resolution
        );
    }

    #[test]
    fn final_metadata_contains_forced_gpu_execution_resolution_and_ncg_realization() {
        let problem = fem_execution_problem("gpu", ExecutionMode::Strict);
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::NonlinearCg,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(1),
                    max_relaxation_time_s: None,
                },
            });
        }
        let metadata = write_final_execution_test_metadata_without_fem_policy(
            "gpu-exact",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "fem_native_gpu".to_string(),
                precision: "double".to_string(),
                mfem_version: Some("4.8".to_string()),
                hypre_version: Some("2.32.0".to_string()),
                requested_energy_minimizer: Some("nonlinear_cg".to_string()),
                resolved_energy_minimizer: Some("nonlinear_cg".to_string()),
                energy_minimizer_realization: Some("native_cuda_nonlinear_cg".to_string()),
                ..ExecutionProvenance::default()
            },
        )
        .expect("forced GPU final metadata should be written");

        let resolution = &metadata["execution_provenance"]["execution_resolution"];
        assert_eq!(resolution["effective_request"]["device"], "gpu");
        assert_eq!(resolution["resolved_execution"]["device"], "gpu");
        assert_eq!(resolution["resolution_mode"], "exact");
        assert_eq!(resolution["fallback_occurred"], false);
        assert_eq!(
            metadata["execution_provenance"]["energy_minimizer_realization"],
            "native_cuda_nonlinear_cg"
        );
    }

    #[test]
    fn final_metadata_preserves_authored_request_and_managed_effective_override() {
        let mut problem = fem_execution_problem("cpu", ExecutionMode::Extended);
        problem.problem_meta.runtime_metadata.insert(
            "runtime_device_override".to_string(),
            serde_json::json!({
                "device": "gpu",
                "source": "managed_launcher",
            }),
        );
        let mut plan = test_fem_execution_plan();
        plan.common.execution_mode = ExecutionMode::Extended;
        let metadata = without_fem_execution_policy(|| {
            write_final_execution_test_metadata(
                "managed-gpu-override",
                &problem,
                &plan,
                ExecutionProvenance {
                    execution_engine: "fem_native_gpu".to_string(),
                    precision: "double".to_string(),
                    mfem_version: Some("4.8".to_string()),
                    hypre_version: Some("2.32.0".to_string()),
                    ..ExecutionProvenance::default()
                },
            )
        })
        .expect("managed GPU override final metadata should be written");

        let resolution = &metadata["execution_provenance"]["execution_resolution"];
        assert_eq!(resolution["authored_request"]["device"], "cpu");
        assert_eq!(resolution["effective_request"]["device"], "gpu");
        assert_eq!(resolution["resolved_execution"]["device"], "gpu");
        assert_eq!(resolution["resolution_mode"], "override");
        assert_eq!(resolution["fallback_occurred"], false);
        assert!(resolution["fallback_reason"].is_null());
    }

    #[test]
    fn final_metadata_contains_auto_gpu_to_cpu_fallback_resolution() {
        let problem = fem_execution_problem("auto", ExecutionMode::Extended);
        let mut plan = test_fem_execution_plan();
        plan.common.execution_mode = ExecutionMode::Extended;
        let metadata = write_final_execution_test_metadata_with_fem_policy(
            "auto",
            "auto-fallback",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                resolved_fallback: Some(ResolvedFallback {
                    occurred: true,
                    original_engine: "fem_native_gpu".to_string(),
                    fallback_engine: "fem_cpu_native".to_string(),
                    reason: "native_fem_gpu_unavailable".to_string(),
                    message: "GPU unavailable; selected CPU".to_string(),
                }),
                ..ExecutionProvenance::default()
            },
        )
        .expect("auto fallback metadata should be written");

        let resolution = &metadata["execution_provenance"]["execution_resolution"];
        assert_eq!(resolution["authored_request"]["device"], "auto");
        assert_eq!(resolution["effective_request"]["device"], "auto");
        assert_eq!(resolution["resolved_execution"]["device"], "cpu");
        assert_eq!(resolution["resolution_mode"], "fallback");
        assert_eq!(resolution["fallback_occurred"], true);
        assert_eq!(resolution["fallback_reason"], "native_fem_gpu_unavailable");
    }

    #[test]
    fn final_metadata_accepts_canonical_fdm_cpu_fallback_with_legacy_cpu_execution_id() {
        let problem = fdm_execution_problem("auto", ExecutionMode::Extended);
        let mut plan = test_execution_plan(None);
        plan.common.execution_mode = ExecutionMode::Extended;
        let metadata = write_final_execution_test_metadata_without_fem_policy(
            "fdm-cpu-alias-fallback",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "cpu_reference".to_string(),
                precision: "double".to_string(),
                resolved_fallback: Some(ResolvedFallback {
                    occurred: true,
                    original_engine: "cuda_fdm".to_string(),
                    fallback_engine: "fdm_cpu_reference".to_string(),
                    reason: "cuda_fdm_unavailable".to_string(),
                    message: "CUDA unavailable; selected CPU reference".to_string(),
                }),
                ..ExecutionProvenance::default()
            },
        )
        .expect("canonical CPU fallback and legacy CPU execution IDs should agree");

        let provenance = &metadata["execution_provenance"];
        assert_eq!(provenance["execution_engine"], "cpu_reference");
        assert_eq!(
            provenance["resolved_fallback"]["original_engine"],
            "cuda_fdm"
        );
        assert_eq!(
            provenance["resolved_fallback"]["fallback_engine"],
            "fdm_cpu_reference"
        );
        let resolution = &provenance["execution_resolution"];
        assert_eq!(resolution["resolved_execution"]["backend"], "fdm");
        assert_eq!(resolution["resolved_execution"]["device"], "cpu");
        assert_eq!(resolution["fallback_occurred"], true);
    }

    #[test]
    fn final_metadata_rejects_cpu_fallback_when_actual_engine_is_cuda_alias() {
        let problem = fdm_execution_problem("auto", ExecutionMode::Extended);
        let mut plan = test_execution_plan(None);
        plan.common.execution_mode = ExecutionMode::Extended;
        let error = write_final_execution_test_metadata_without_fem_policy(
            "fdm-cpu-fallback-actual-cuda",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "fdm_cuda".to_string(),
                precision: "double".to_string(),
                resolved_fallback: Some(ResolvedFallback {
                    occurred: true,
                    original_engine: "cuda_fdm".to_string(),
                    fallback_engine: "cpu_reference".to_string(),
                    reason: "test_cpu_fallback".to_string(),
                    message: "CPU fallback was declared".to_string(),
                }),
                ..ExecutionProvenance::default()
            },
        )
        .expect_err("CPU fallback metadata must reject an actual CUDA engine");
        assert!(error
            .to_string()
            .contains("resolved fallback engine mismatch"));
    }

    #[test]
    fn final_metadata_rejects_fallback_aliases_with_same_canonical_identity() {
        let problem = fdm_execution_problem("auto", ExecutionMode::Extended);
        let mut plan = test_execution_plan(None);
        plan.common.execution_mode = ExecutionMode::Extended;
        let error = write_final_execution_test_metadata_without_fem_policy(
            "fdm-same-canonical-fallback",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "cpu_reference".to_string(),
                precision: "double".to_string(),
                resolved_fallback: Some(ResolvedFallback {
                    occurred: true,
                    original_engine: "cpu_reference".to_string(),
                    fallback_engine: "fdm_cpu_reference".to_string(),
                    reason: "invalid_same_engine_fallback".to_string(),
                    message: "the aliases name one engine".to_string(),
                }),
                ..ExecutionProvenance::default()
            },
        )
        .expect_err("different FDM engine aliases must not hide a same-engine fallback");
        assert!(error
            .to_string()
            .contains("resolved fallback original_engine and fallback_engine must differ"));
    }

    #[test]
    fn final_metadata_rejects_unknown_execution_engine_id() {
        let problem = fdm_execution_problem("auto", ExecutionMode::Extended);
        let mut plan = test_execution_plan(None);
        plan.common.execution_mode = ExecutionMode::Extended;
        let error = write_final_execution_test_metadata_without_fem_policy(
            "fdm-unknown-engine",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "fdm_future_guess".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        )
        .expect_err("unknown engine identifiers must fail closed");
        assert!(error
            .to_string()
            .contains("unknown execution_engine 'fdm_future_guess'"));
    }

    #[test]
    fn final_metadata_keeps_strict_fallback_rejection_for_fdm_aliases() {
        let problem = fdm_execution_problem("auto", ExecutionMode::Strict);
        let plan = test_execution_plan(None);
        let error = write_final_execution_test_metadata_without_fem_policy(
            "fdm-strict-fallback-rejected",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "cpu_reference".to_string(),
                precision: "double".to_string(),
                resolved_fallback: Some(ResolvedFallback {
                    occurred: true,
                    original_engine: "cuda_fdm".to_string(),
                    fallback_engine: "fdm_cpu_reference".to_string(),
                    reason: "cuda_fdm_unavailable".to_string(),
                    message: "CUDA unavailable; selected CPU reference".to_string(),
                }),
                ..ExecutionProvenance::default()
            },
        )
        .expect_err("Strict execution must continue to reject every fallback");
        assert!(error
            .to_string()
            .contains("strict execution metadata cannot contain a resolved fallback"));
    }

    #[test]
    fn final_metadata_rejects_strict_forced_gpu_resolved_as_cpu() {
        let problem = fem_execution_problem("gpu", ExecutionMode::Strict);
        let plan = test_fem_execution_plan();
        let error = write_final_execution_test_metadata_without_fem_policy(
            "strict-gpu-mismatch",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        )
        .expect_err("strict forced GPU metadata must reject a CPU execution");

        assert!(error.to_string().contains("forced device mismatch"));
    }

    #[test]
    fn final_metadata_records_tpi_auto_to_cpu_resolution() {
        let problem = fem_execution_problem("auto", ExecutionMode::Extended);
        let mut plan = test_fem_execution_plan();
        plan.common.execution_mode = ExecutionMode::Extended;
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::TangentPlaneImplicit,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(1),
                    max_relaxation_time_s: None,
                },
            });
        }
        let metadata = write_final_execution_test_metadata_with_fem_policy(
            "auto",
            "tpi-auto-cpu",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                requested_energy_minimizer: Some("tangent_plane_implicit".to_string()),
                resolved_energy_minimizer: Some("tangent_plane_implicit".to_string()),
                energy_minimizer_realization: Some("native_mfem_tpi".to_string()),
                resolved_fallback: Some(ResolvedFallback {
                    occurred: true,
                    original_engine: "fem_native_gpu".to_string(),
                    fallback_engine: "fem_cpu_native".to_string(),
                    reason: "fem_gpu_relaxation_algorithm_cpu_only".to_string(),
                    message: "TPI is resolved to CPU/MFEM".to_string(),
                }),
                ..ExecutionProvenance::default()
            },
        )
        .expect("TPI auto fallback metadata should be written");

        let resolution = &metadata["execution_provenance"]["execution_resolution"];
        assert_eq!(resolution["effective_request"]["device"], "auto");
        assert_eq!(resolution["resolved_execution"]["device"], "cpu");
        assert_eq!(resolution["resolution_mode"], "fallback");
        assert_eq!(
            resolution["fallback_reason"],
            "fem_gpu_relaxation_algorithm_cpu_only"
        );
    }

    #[test]
    fn multilayer_bb_metadata_validates_algorithm_and_realization() {
        let mut plan = test_multilayer_execution_plan();
        let BackendPlanIR::FdmMultilayer(multilayer) = &mut plan.backend_plan else {
            panic!("expected multilayer test plan");
        };
        multilayer.relaxation = Some(fullmag_ir::RelaxationControlIR {
            algorithm: fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb,
            stop: fullmag_ir::RelaxStopIR {
                torque_tolerance_apm: Some(1e-3), energy_tolerance_j: None,
                max_steps: Some(1), max_relaxation_time_s: None,
            },
        });
        let mut provenance = ExecutionProvenance {
            execution_engine: "cpu_reference_multilayer".into(),
            requested_energy_minimizer: Some("projected_gradient_bb".into()),
            resolved_energy_minimizer: Some("projected_gradient_bb".into()),
            energy_minimizer_realization: Some("cpu_reference_multilayer_projected_gradient_bb".into()),
            ..ExecutionProvenance::default()
        };
        assert!(validate_direct_minimizer_realization(&plan, &provenance, "cpu").is_ok());
        provenance.energy_minimizer_realization = Some("native_cuda_pgbb".into());
        assert!(validate_direct_minimizer_realization(&plan, &provenance, "cpu").is_err());
        provenance.execution_engine = "cuda_native_multilayer_convolution".into();
        assert!(validate_direct_minimizer_realization(&plan, &provenance, "gpu").is_ok());
        provenance.requested_energy_minimizer = Some("nonlinear_cg".into());
        assert!(validate_direct_minimizer_realization(&plan, &provenance, "gpu").is_err());
    }

    #[test]
    fn final_metadata_rejects_pgbb_realization_for_wrong_engine() {
        let problem = fem_execution_problem("cpu", ExecutionMode::Extended);
        let mut plan = test_fem_execution_plan();
        plan.common.execution_mode = ExecutionMode::Extended;
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(1),
                    max_relaxation_time_s: None,
                },
            });
        }
        let error = write_final_execution_test_metadata_without_fem_policy(
            "pgbb-realization-mismatch",
            &problem,
            &plan,
            ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                requested_energy_minimizer: Some("projected_gradient_bb".to_string()),
                resolved_energy_minimizer: Some("projected_gradient_bb".to_string()),
                energy_minimizer_realization: Some("native_cuda_pgbb".to_string()),
                ..ExecutionProvenance::default()
            },
        )
        .expect_err("CPU PG-BB metadata must reject a CUDA realization ID");

        assert!(error.to_string().contains("realization mismatch"));
    }

    #[test]
    fn final_metadata_requires_cuda_fdm_host_direct_minimizer_realization() {
        let problem = fdm_execution_problem("gpu", ExecutionMode::Strict);
        let mut plan = test_execution_plan(None);
        if let BackendPlanIR::Fdm(fdm) = &mut plan.backend_plan {
            fdm.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::NonlinearCg,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(1),
                    max_relaxation_time_s: None,
                },
            });
        }
        let provenance = |realization: &str| ExecutionProvenance {
            execution_engine: "cuda_fdm".to_string(),
            precision: "double".to_string(),
            requested_energy_minimizer: Some("nonlinear_cg".to_string()),
            resolved_energy_minimizer: Some("nonlinear_cg".to_string()),
            energy_minimizer_realization: Some(realization.to_string()),
            ..ExecutionProvenance::default()
        };

        let metadata = write_final_execution_test_metadata_without_fem_policy(
            "cuda-fdm-ncg-realization",
            &problem,
            &plan,
            provenance(crate::relaxation::CUDA_FDM_HOST_DIRECT_MINIMIZER_REALIZATION),
        )
        .expect("CUDA FDM NCG metadata should accept the host-orchestrated realization");
        assert_eq!(
            metadata["execution_provenance"]["energy_minimizer_realization"],
            "cuda_fdm_host_tangent_gradient"
        );

        let error = write_final_execution_test_metadata_without_fem_policy(
            "cuda-fdm-ncg-native-realization",
            &problem,
            &plan,
            provenance("native_cuda_nonlinear_cg"),
        )
        .expect_err("CUDA FDM metadata must reject the FEM GPU native realization ID");
        assert!(error.to_string().contains("realization mismatch"));
    }

    fn test_periodic_fem_execution_plan() -> ExecutionPlanIR {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.mesh.periodic_boundary_pairs = vec![
                fullmag_ir::MeshPeriodicBoundaryPairIR {
                    pair_id: "x_faces".to_string(),
                    source_marker: None,
                    destination_marker: None,
                    marker_a: 1,
                    marker_b: 2,
                    translation: Some([1.0, 0.0, 0.0]),
                    tolerance: Some(1.0e-12),
                    axis_hint: Some("x".to_string()),
                    orientation: None,
                    pairing_policy: None,
                },
                fullmag_ir::MeshPeriodicBoundaryPairIR {
                    pair_id: "y_faces".to_string(),
                    source_marker: None,
                    destination_marker: None,
                    marker_a: 3,
                    marker_b: 4,
                    translation: Some([0.0, 1.0, 0.0]),
                    tolerance: Some(1.0e-12),
                    axis_hint: Some("y".to_string()),
                    orientation: None,
                    pairing_policy: None,
                },
            ];
            fem.mesh.periodic_node_pairs = vec![
                fullmag_ir::MeshPeriodicNodePairIR {
                    pair_id: "x_faces".to_string(),
                    node_a: 0,
                    node_b: 1,
                },
                fullmag_ir::MeshPeriodicNodePairIR {
                    pair_id: "y_faces".to_string(),
                    node_a: 0,
                    node_b: 2,
                },
            ];
        }
        plan
    }

    #[test]
    fn direct_fem_minimizers_require_solver_diagnostics_without_a_timestep_policy() {
        for algorithm in [
            fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb,
            fullmag_ir::RelaxationAlgorithmIR::NonlinearCg,
            fullmag_ir::RelaxationAlgorithmIR::TangentPlaneImplicit,
        ] {
            let mut plan = test_fem_execution_plan();
            let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
                panic!("test plan must use FEM");
            };
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: None,
                    energy_tolerance_j: None,
                    max_steps: Some(1),
                    max_relaxation_time_s: None,
                },
            });
            assert!(should_write_solver_diagnostics(&plan, None));
        }
    }

    #[test]
    fn solver_diagnostics_keep_attempts_separate_from_accepted_steps() {
        let root = std::env::temp_dir().join(format!(
            "fullmag-solver-diagnostics-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let replay_root = root.with_extension("replay");
        fs::create_dir_all(&root).unwrap();
        fs::create_dir_all(&replay_root).unwrap();
        let mut step = StepStats {
            step: 1,
            time: 2.0e-15,
            dt: 1.0e-15,
            accepted_energy_proof_available: true,
            accepted_energy_delta_j: Some(-2.0e-20),
            accepted_energy_roundoff_bound_j: Some(1.0e-21),
            accepted_energy_delta_upper_j: Some(-1.9e-20),
            armijo_increment_rhs_j: Some(-1.0e-20),
            error_estimate: Some(0.25),
            max_error: Some(1.0e-6),
            dt_suggested: Some(2.0e-15),
            rejected_attempts: 1,
            fem_representation_receipt: Some(fullmag_quantities::FemRepresentationReceipt {
                schema_version: 1,
                state_space: fullmag_quantities::FemStateRepresentation::LocalNodeAos,
                ms_location: fullmag_quantities::FemMaterialFieldLocation::Scalar,
                a_location: fullmag_quantities::FemMaterialFieldLocation::ElementDg0,
                local_node_count: 52,
                true_node_count: 52,
                periodic_map_revision: 0,
                representation_copy_count: 4,
                gather_scatter_bytes: 9_984,
                invalid_space_assertion_count: 0,
                hot_loop_representation_copy_count: 0,
                hot_loop_gather_scatter_bytes: 0,
            }),
            ..StepStats::default()
        };
        let rejected_attempt = SolverAttemptRecord {
            attempt: 0,
            adaptive_controller_policy_version: None,
            error_norm_type: Some("mass_weighted_rms".to_string()),
            active_node_count: Some(2),
            active_measure: Some(4.0),
            normalization_denominator: Some(4.0),
            max_scaled_error: Some(3.0),
            weighted_rms_error: Some(2.1213203435596424),
            target_step: 1,
            time: 0.0,
            dt_attempt: 4.0e-15,
            eta: 4.0,
            max_norm_defect: Some(2.0e-8),
            max_spin_rotation: Some(0.02),
            decision: "retry".to_string(),
            reason: "error_above_tolerance".to_string(),
            dt_next: 1.0e-15,
            demag_solves: 7,
            demag_iterations: 11,
            demag_residual: 1.0e-9,
            rhs_evals: 7,
            estimator_order: 4,
        };
        step.solver_attempts = vec![
            rejected_attempt.clone(),
            SolverAttemptRecord {
                attempt: 1,
                dt_attempt: 1.0e-15,
                eta: 0.25,
                decision: "accepted".to_string(),
                reason: "within_tolerance".to_string(),
                dt_next: 2.0e-15,
                ..rejected_attempt
            },
        ];
        let steps = vec![
            step,
            StepStats {
                step: 2,
                ..StepStats::default()
            },
        ];
        write_solver_diagnostics_artifacts(&root, &test_fem_execution_plan(), None, &steps)
            .unwrap();
        write_solver_diagnostics_artifacts(&replay_root, &test_fem_execution_plan(), None, &steps)
            .unwrap();
        let attempts = fs::read_to_string(root.join("solver_attempts.csv")).unwrap();
        let accepted = fs::read_to_string(root.join("solver_steps.csv")).unwrap();
        assert_eq!(
            attempts.lines().count(),
            3,
            "header plus one row per attempted step"
        );
        assert_eq!(
            accepted.lines().count(),
            3,
            "header plus one row per accepted step"
        );
        assert!(attempts.contains("error_above_tolerance"));
        let receipt_row = attempts
            .lines()
            .nth(1)
            .unwrap()
            .split(',')
            .collect::<Vec<_>>();
        assert_eq!(receipt_row.len(), 22);
        assert_eq!(receipt_row[16], "mass_weighted_rms");
        assert_eq!(receipt_row[17], "2");
        assert_eq!(receipt_row[18], format!("{:.17e}", 4.0));
        assert_eq!(receipt_row[19], format!("{:.17e}", 4.0));
        assert_eq!(receipt_row[20], format!("{:.17e}", 3.0));
        assert_eq!(receipt_row[21], format!("{:.17e}", 2.1213203435596424));
        let accepted_rows = accepted.lines().collect::<Vec<_>>();
        let proof = accepted_rows[1].split(',').collect::<Vec<_>>();
        assert_eq!(proof[20], "true");
        let delta: f64 = proof[21].parse().unwrap();
        let bound: f64 = proof[22].parse().unwrap();
        let upper: f64 = proof[23].parse().unwrap();
        let rhs: f64 = proof[24].parse().unwrap();
        assert_eq!(upper, delta + bound);
        assert!(upper <= rhs && rhs <= 0.0);
        assert_eq!(
            &proof[27..=38],
            [
                "1",
                "local_node_aos",
                "scalar",
                "element_dg0",
                "52",
                "52",
                "0",
                "4",
                "9984",
                "0",
                "0",
                "0",
            ]
        );
        let unavailable = accepted_rows[2].split(',').collect::<Vec<_>>();
        assert_eq!(unavailable[20], "false");
        assert!(unavailable[21..=24].iter().all(|value| value.is_empty()));
        assert!(unavailable[27..=38].iter().all(|value| value.is_empty()));
        let max_error: f64 = accepted
            .lines()
            .nth(1)
            .unwrap()
            .split(',')
            .nth(4)
            .unwrap()
            .parse()
            .unwrap();
        assert!((max_error - 1.0e-6).abs() < 1.0e-20);
        let qualification: serde_json::Value =
            serde_json::from_slice(&fs::read(root.join("qualification.json")).unwrap()).unwrap();
        assert_eq!(qualification["status"], "not_evaluated");
        for artifact in [
            "solver_config.json",
            "solver_attempts.csv",
            "solver_steps.csv",
            "qualification.json",
        ] {
            assert_eq!(
                fs::read(root.join(artifact)).unwrap(),
                fs::read(replay_root.join(artifact)).unwrap(),
                "solver diagnostics must replay byte-for-byte deterministically: {artifact}",
            );
        }
        fs::remove_dir_all(root).unwrap();
        fs::remove_dir_all(replay_root).unwrap();
    }

    #[test]
    fn accepted_solver_trace_roundtrips_independently_of_output_rows() {
        let mut accepted = StepStats {
            step: 7,
            time: 7.5e-12,
            dt: 2.5e-13,
            error_estimate: Some(0.25),
            rejected_attempts: 2,
            ..StepStats::default()
        };
        accepted.solver_attempts.push(SolverAttemptRecord {
            attempt: 0,
            adaptive_controller_policy_version: None,
            target_step: 7,
            time: 7.25e-12,
            dt_attempt: 1.0e-12,
            eta: 2.0,
            error_norm_type: None,
            active_node_count: None,
            active_measure: None,
            normalization_denominator: None,
            max_scaled_error: None,
            weighted_rms_error: None,
            decision: "retry".to_string(),
            reason: "error_above_tolerance".to_string(),
            dt_next: accepted.dt,
            max_norm_defect: None,
            max_spin_rotation: None,
            demag_solves: 0,
            demag_iterations: 0,
            demag_residual: 0.0,
            rhs_evals: 0,
            estimator_order: 4,
        });
        let artifact = solver_diagnostic_trace_artifact(vec![accepted.clone()])
            .expect("non-empty accepted trace must produce an artifact");
        assert_eq!(artifact.relative_path, SOLVER_DIAGNOSTIC_TRACE_ARTIFACT);
        let trace: SolverDiagnosticTraceArtifact =
            serde_json::from_slice(&artifact.bytes).expect("trace JSON must decode");
        assert_eq!(trace.schema_version, "LLG-TD-ACCEPTED-TRACE-V1");
        assert_eq!(trace.steps.len(), 1);
        assert_eq!(trace.steps[0].step, accepted.step);
        assert_eq!(trace.steps[0].solver_attempts.len(), 1);
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: Vec::new(),
                completion: None,
            },
            initial_magnetization: Vec::new(),
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: vec![artifact],
            provenance: ExecutionProvenance::default(),
        };
        let selected = solver_diagnostic_steps(&executed).expect("trace must be selected");
        assert_eq!(selected.len(), 1);
        assert_eq!(selected[0].step, accepted.step);
        assert!(solver_diagnostic_trace_artifact(Vec::new()).is_none());
    }

    #[test]
    fn solver_qualification_artifact_carries_fail_closed_registry_provenance() {
        let root = std::env::temp_dir().join(format!(
            "fullmag-llg-qualification-provenance-{}",
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        fs::create_dir_all(&root).unwrap();
        let policy = crate::resolve_timestep_policy(
            Some(IntegratorChoice::Rk45),
            Some(1.0e-15),
            None,
            crate::types::TimestepExecutionLane::fem_cpu(ExecutionPrecision::Double),
        )
        .unwrap();
        write_solver_diagnostics_artifacts(&root, &test_fem_execution_plan(), Some(&policy), &[])
            .unwrap();

        let qualification: serde_json::Value =
            serde_json::from_slice(&fs::read(root.join("qualification.json")).unwrap()).unwrap();
        let identity = &qualification["timestep_qualification"];
        assert_eq!(identity["validation_state"], "unvalidated");
        assert_eq!(
            identity["qualification_registry_version"],
            "fullmag.llg_timestep_qualification_registry.v1"
        );
        assert!(identity.get("qualification_artifact_sha256").is_none());
        assert!(identity.get("validated_scope").is_none());
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn metadata_execution_provenance_persists_resolved_fallback() {
        let mut problem = fem_execution_problem("auto", ExecutionMode::Extended);
        problem.problem_meta.runtime_metadata.insert(
            "region_realization_revisions".to_string(),
            serde_json::json!({
                "complete": true,
                "topology": 11,
                "membership": 12,
                "coefficients": 13,
                "initial_state": 14,
            }),
        );
        let mut plan = test_fem_execution_plan();
        plan.common.execution_mode = ExecutionMode::Extended;
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-resolved-fallback-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                resolved_fallback: Some(ResolvedFallback {
                    occurred: true,
                    original_engine: "fem_native_gpu".to_string(),
                    fallback_engine: "fem_cpu_native".to_string(),
                    reason: "native_fem_gpu_unavailable".to_string(),
                    message: "native FEM GPU unavailable in test".to_string(),
                }),
                fem_poisson_demag: Some(crate::types::FemPoissonDemagProvenance {
                    potential_order: Some(2),
                    potential_true_dof_count: Some(9876),
                    variational_energy_joules: Some(0.0),
                    recovered_field_energy_joules: Some(-3.5e-19),
                    ..Default::default()
                }),
                ..ExecutionProvenance::default()
            },
        };

        with_fem_execution_policy("auto", || {
            write_artifacts(&output_dir, &problem, &plan, &executed, None)
        })
        .expect("artifact write should preserve resolved fallback");

        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata should exist"),
        )
        .expect("metadata should parse");
        let fallback = &metadata["execution_provenance"]["resolved_fallback"];
        assert_eq!(fallback["occurred"], true);
        assert_eq!(fallback["original_engine"], "fem_native_gpu");
        assert_eq!(fallback["fallback_engine"], "fem_cpu_native");
        assert_eq!(fallback["reason"], "native_fem_gpu_unavailable");
        let demag = &metadata["execution_provenance"]["fem_poisson_demag"];
        assert_eq!(demag["potential_order"], 2);
        assert_eq!(demag["potential_true_dof_count"], 9876);
        assert_eq!(demag["variational_energy_joules"], 0.0);
        assert_eq!(demag["recovered_field_energy_joules"], -3.5e-19);
        assert!(
            metadata.get("sampling_resolution").is_none(),
            "explicit legacy runs must omit automatic sampling provenance"
        );
        assert_eq!(
            metadata["region_realization_revisions"],
            serde_json::json!({
                "complete": true,
                "topology": 11,
                "membership": 12,
                "coefficients": 13,
                "initial_state": 14,
            })
        );

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn metadata_and_auxiliary_file_persist_physics_graph_runtime_provenance() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.backend_policy.requested_backend = fullmag_ir::BackendTarget::Auto;
        problem.physics_graph = Some(serde_json::json!({
            "schema_version": "physics_graph.v1",
            "scene_revision": 23,
            "modules": [{
                "id": "current:film",
                "kind": "current_transport",
                "applies_to": [{"kind": "object", "object_id": "film"}],
                "solve_domain": [{"object_id": "film"}],
                "depends_on": [],
                "activation": "active",
                "authored_state": "authored",
                "capability": "reference_executable",
                "source_path": "/current_modules/0",
                "family_payload": {}
            }],
            "edges": []
        }));
        let plan = test_fem_execution_plan();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-physics-graph-provenance-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .expect("clock drift")
                .as_nanos()
        ));
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("graph provenance artifacts should be written");
        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata"),
        )
        .expect("metadata JSON");
        let metadata_graph = &metadata["execution_provenance"]["physics_graph"];
        assert_eq!(metadata_graph["schema_version"], "physics_graph.runtime.v1");
        assert_eq!(metadata_graph["scene_revision"], 23);
        assert!(metadata_graph["mesh_revision"]
            .as_u64()
            .is_some_and(|value| value != 0));
        assert!(metadata_graph["graph_sha256"]
            .as_str()
            .is_some_and(|value| value.len() == 64));
        assert_eq!(metadata_graph["requested_lane"], "auto");
        assert_eq!(metadata_graph["resolved_lane"], "fem");
        assert_eq!(metadata_graph["modules"][0]["module_id"], "current:film");
        assert_eq!(metadata_graph["modules"][0]["scope"], "object:film");
        assert_eq!(
            metadata_graph["modules"][0]["depends_on"],
            serde_json::json!([])
        );

        let artifact_path = output_dir.join(PHYSICS_GRAPH_PROVENANCE_ARTIFACT);
        let artifact: serde_json::Value =
            serde_json::from_slice(&fs::read(&artifact_path).expect("physics graph artifact file"))
                .expect("physics graph artifact JSON");
        assert_eq!(artifact, *metadata_graph);
        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn fem_canonical_stt_persists_complete_provenance_and_manifest() {
        let mut problem = fem_execution_problem("auto", ExecutionMode::Extended);
        problem.spin_torque_modules = vec![fullmag_ir::SpinTorqueModuleIR::Slonczewski {
            schema_version: Some("slonczewski_torque.v1".to_string()),
            id: Some("cpp".to_string()),
            target: Some(fullmag_ir::RegionRefIR {
                object_id: "free".to_string(),
                region_id: None,
            }),
            formula_version: "slonczewski.fullmag.v2".to_string(),
            current_density: Some([0.0, 0.0, -2.0e11]),
            current_source: None,
            degree: 0.55,
            spin_polarization: [0.0, 1.0, 0.0],
            stack_normal: Some([0.0, 0.0, 1.0]),
            lambda_asymmetry: 1.4,
            epsilon_prime: 0.03,
            free_layer_thickness_m: Some(1.5e-9),
            fixed_layer_position: None,
            realization: Some(fullmag_ir::SlonczewskiRealizationIR::ThinLayerHomogenized {
                realization_version: "slonczewski_thin_layer_homogenized.v1".to_string(),
            }),
        }];
        let mut plan = test_fem_execution_plan();
        plan.common.execution_mode = ExecutionMode::Extended;
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("FEM fixture")
        };
        fem.current_density = Some([0.0, 0.0, -2.0e11]);
        fem.stt_degree = Some(0.55);
        fem.stt_spin_polarization = Some([0.0, 1.0, 0.0]);
        fem.stt_lambda = Some(1.4);
        fem.stt_epsilon_prime = Some(0.03);
        fem.stt_thickness = Some(1.5e-9);
        fem.spin_torque_contract = Some(fullmag_ir::FemSpinTorquePlanIR {
            formula_version: "slonczewski.fullmag.v2".to_string(),
            operator_version: None,
            realization_version: Some("slonczewski_thin_layer_homogenized.v1".to_string()),
            target: Some(fullmag_ir::RegionRefIR {
                object_id: "free".to_string(),
                region_id: None,
            }),
            stack_normal: Some([0.0, 0.0, 1.0]),
            lande_g: None,
            active_node_mask: Some(vec![true, true, false, false]),
            active_element_mask: Some(vec![true]),
            sot_current_density: None,
            sot_xi_dl: None,
            sot_xi_fl: None,
            sot_sigma: None,
            sot_thickness: None,
            sot_envelope: None,
            sot_drive: None,
        });

        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fem-stt-provenance-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .expect("clock drift")
                .as_nanos()
        ));
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                resolved_fallback: Some(ResolvedFallback {
                    occurred: true,
                    original_engine: "fem_native_gpu".to_string(),
                    fallback_engine: "fem_cpu_native".to_string(),
                    reason: "fem_gpu_rk_plan_ineligible".to_string(),
                    message: "canonical FEM STT is CPU-only".to_string(),
                }),
                ..ExecutionProvenance::default()
            },
        };
        with_fem_execution_policy("auto", || {
            write_artifacts(&output_dir, &problem, &plan, &executed, None)
        })
        .expect("write artifacts");

        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata"),
        )
        .expect("metadata JSON");
        let provenance = &metadata["execution_provenance"]["spin_torque"];
        assert_eq!(provenance["schema_version"], "spin_torque_provenance.v1");
        assert_eq!(provenance["authored_class"], "SlonczewskiSTT");
        assert_eq!(provenance["canonical_class"], "SlonczewskiSTT");
        assert_eq!(provenance["formula_version"], "slonczewski.fullmag.v2");
        assert_eq!(
            provenance["realization_version"],
            "slonczewski_thin_layer_homogenized.v1"
        );
        assert_eq!(
            provenance["current_convention"],
            "conventional_charge_current"
        );
        assert_eq!(provenance["current_density_unit"], "A/m^2");
        assert_eq!(
            provenance["current_density"],
            serde_json::json!([0.0, 0.0, -2.0e11])
        );
        assert_eq!(provenance["target"]["object_id"], "free");
        assert_eq!(
            provenance["stack_normal"],
            serde_json::json!([0.0, 0.0, 1.0])
        );
        assert_eq!(provenance["active_node_count"], 2);
        assert_eq!(provenance["active_element_count"], 1);
        assert_eq!(provenance["resolved_execution_engine"], "fem_cpu_native");
        assert_eq!(provenance["resolved_precision"], "double");
        assert_eq!(
            provenance["resolved_fallback"]["reason"],
            "fem_gpu_rk_plan_ineligible"
        );
        let manifest: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("physics/spin_torque_provenance.v1.json"))
                .expect("spin-torque manifest"),
        )
        .expect("manifest JSON");
        assert_eq!(manifest, *provenance);
        fs::remove_dir_all(output_dir).expect("remove fixture");
    }

    #[test]
    fn metadata_persists_artifact_pipeline_writer_timing() {
        let problem = fullmag_ir::ProblemIR::bootstrap_example();
        let plan = test_fem_execution_plan();
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-pipeline-summary-{}-{}",
            std::process::id(),
            unique_suffix
        ));
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 2,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        };
        let streamed = ArtifactPipelineSummary {
            scalar_rows_written: 3,
            field_snapshots_written: 2,
            writer_jobs_completed: 5,
            artifact_writer_job_wall_time_ns: 110,
            scalar_row_writer_wall_time_ns: 30,
            field_snapshot_writer_wall_time_ns: 80,
            native_field_snapshot_writer_wall_time_ns: 0,
            autosave_root: None,
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, Some(&streamed))
            .expect("artifact write should preserve pipeline timing");

        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata should exist"),
        )
        .expect("metadata should parse");
        let pipeline = &metadata["artifact_pipeline"];
        assert_eq!(pipeline["scalar_rows_written"], 3);
        assert_eq!(pipeline["field_snapshots_written"], 2);
        assert_eq!(pipeline["writer_jobs_completed"], 5);
        assert_eq!(pipeline["artifact_writer_job_wall_time_ns"], 110);
        assert_eq!(pipeline["scalar_row_writer_wall_time_ns"], 30);
        assert_eq!(pipeline["field_snapshot_writer_wall_time_ns"], 80);
        assert_eq!(pipeline["native_field_snapshot_writer_wall_time_ns"], 0);

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn fem_element_material_artifact_preserves_location_and_values() {
        let mut plan = test_fem_execution_plan();
        plan.common.material_field_plans = vec![MaterialFieldPlan {
            object_id: "free".to_string(),
            parameter: MaterialParameterNameIR::Aex,
            source_kind: MaterialFieldSourceKind::Override,
            realization_location: MaterialFieldLocationIR::Element,
            requires_sampling: false,
            requires_mesh_revision: true,
            warnings: Vec::new(),
            realization_method: Some("conformal_domain_element_sampling".to_string()),
            statistics: None,
        }];
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan should be FEM");
        };
        fem.material.a_field = None;
        fem.a_element_field = Some(vec![13e-12]);
        let prepared = build_material_field_artifacts(&plan).expect("element coefficient artifact");
        assert_eq!(
            prepared.files.len(),
            1,
            "element fields must not be silently omitted"
        );
        let asset: fullmag_ir::MaterialFieldAssetIR =
            serde_json::from_slice(&prepared.files[0].bytes).expect("material field artifact");
        assert_eq!(asset.location, MaterialFieldLocationIR::Element);
        assert_eq!(asset.values, vec![13e-12]);
        assert_eq!(asset.unit, "J/m");
        assert_eq!(asset.min, 13e-12);
        assert_eq!(asset.max, 13e-12);
        assert_eq!(asset.mean, 13e-12);
        assert_eq!(prepared.metadata_assets[0]["location"], "element");
        assert_eq!(prepared.metadata_assets[0]["values"], serde_json::json!([]));
    }

    #[test]
    fn write_artifacts_persists_fem_material_field_asset_files() {
        let problem = fullmag_ir::ProblemIR::bootstrap_example();
        let mut plan = test_fem_execution_plan();
        plan.common.material_field_plans = vec![MaterialFieldPlan {
            object_id: "free".to_string(),
            parameter: MaterialParameterNameIR::Ms,
            source_kind: MaterialFieldSourceKind::Override,
            realization_location: MaterialFieldLocationIR::Node,
            requires_sampling: false,
            requires_mesh_revision: true,
            warnings: Vec::new(),
            realization_method: Some("fem_nodal_material_field".to_string()),
            statistics: Some(MaterialFieldStatisticsIR {
                sample_count: 4,
                min: 700e3,
                max: 730e3,
                mean: 715e3,
            }),
        }];
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan should be FEM");
        };
        fem.material.ms_field = Some(vec![700e3, 710e3, 720e3, 730e3]);
        let prepared = build_material_field_artifacts(&plan)
            .expect("FEM material fields should build without filesystem output");
        assert_eq!(prepared.metadata_assets.len(), 1);
        assert_eq!(prepared.files.len(), 1);

        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-material-fields-{}-{}",
            std::process::id(),
            unique_suffix
        ));
        assert!(!output_dir.exists(), "pure preparation must not write files");
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                ..Default::default()
            },
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("material-field artifacts should be written");

        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata should exist"),
        )
        .expect("metadata should parse");
        let assets = metadata["material_field_assets"]
            .as_array()
            .expect("metadata should carry material_field_assets");
        assert_eq!(assets, &prepared.metadata_assets);
        assert_eq!(assets.len(), 1);
        assert_eq!(assets[0]["asset_id"], "free_ms_node");
        assert_eq!(
            assets[0]["artifact_path"],
            "material-fields/free_ms_node.json"
        );
        assert_eq!(assets[0]["values"].as_array().map(Vec::len), Some(0));
        assert_eq!(
            assets[0]["artifact_path"],
            prepared.files[0].relative_path
        );
        assert_eq!(
            fs::read(output_dir.join(&prepared.files[0].relative_path))
                .expect("FEM material-field artifact should exist"),
            prepared.files[0].bytes,
            "legacy writer must preserve exact bytes returned by the pure FEM builder"
        );

        let artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("material-fields/free_ms_node.json"))
                .expect("material-field asset artifact should exist"),
        )
        .expect("material-field artifact should parse");
        assert_eq!(artifact["asset_id"], "free_ms_node");
        assert_eq!(artifact["values"].as_array().map(Vec::len), Some(4));
        assert_eq!(artifact["min"], 700e3);
        assert_eq!(artifact["max"], 730e3);
        assert_eq!(artifact["mean"], 715e3);

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn demag_profile_metadata_includes_timing_breakdown() {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.enable_demag = true;
            fem.demag_realization = Some(fullmag_ir::ResolvedFemDemagIR::PoissonRobin);
        }

        let metadata = demag_runtime_metadata(
            &plan,
            &ExecutionProvenance::default(),
            &[StepStats {
                demag_wall_time_ns: 29,
                demag_assemble_wall_time_ns: 3,
                demag_solve_wall_time_ns: 5,
                demag_solver_setup_wall_time_ns: 17,
                demag_solver_apply_wall_time_ns: 19,
                demag_solver_setup_reused: true,
                demag_amg_relax_type: 6,
                demag_amg_coarsening: 10,
                demag_amg_interpolation: 7,
                demag_amg_aggressive_coarsening: 2,
                demag_amg_strength_threshold: 0.25,
                demag_amg_strength_threshold_is_set: true,
                demag_amg_max_levels: 42,
                demag_amg_max_levels_is_set: true,
                demag_recover_wall_time_ns: 7,
                demag_energy_wall_time_ns: 11,
                poisson_iterations: 13,
                poisson_final_residual: 1.0e-8,
                ..StepStats::default()
            }],
        );

        assert_eq!(metadata["timings_ns"]["assemble"], 3);
        assert_eq!(metadata["timings_ns"]["solve"], 5);
        assert_eq!(metadata["timings_ns"]["solver_setup"], 17);
        assert_eq!(metadata["timings_ns"]["solver_apply"], 19);
        assert_eq!(metadata["timings_ns"]["recover"], 7);
        assert_eq!(metadata["timings_ns"]["energy"], 11);
        assert_eq!(metadata["timings_ns"]["total"], 29);
        assert_eq!(metadata["solver_setup_reused"], true);
        assert_eq!(metadata["actual_iterations"], 13);
        assert_eq!(metadata["final_residual_norm"], 1.0e-8);
        assert_eq!(metadata["relative_tolerance"], 1.0e-8);
        assert_eq!(metadata["absolute_tolerance"], serde_json::Value::Null);
        assert_eq!(metadata["max_iterations"], 500);
        assert_eq!(metadata["print_level"], 0);
        assert_eq!(metadata["policy_source"], "resolved_default");
        assert_eq!(metadata["amg_profile"]["provider"], "mfem_hypre_boomeramg");
        assert_eq!(metadata["amg_profile"]["relax_type"], 6);
        assert_eq!(metadata["amg_profile"]["coarsening"], 10);
        assert_eq!(metadata["amg_profile"]["interpolation"], 7);
        assert_eq!(metadata["amg_profile"]["aggressive_coarsening"], 2);
        assert_eq!(metadata["amg_profile"]["strength_threshold"], 0.25);
        assert_eq!(metadata["amg_profile"]["max_levels"], 42);

        let explicit_zero = demag_amg_profile_metadata(
            "AMG",
            Some(&StepStats {
                demag_amg_strength_threshold: 0.0,
                demag_amg_strength_threshold_is_set: true,
                demag_amg_max_levels: 0,
                demag_amg_max_levels_is_set: true,
                ..StepStats::default()
            }),
        );
        assert_eq!(explicit_zero["strength_threshold"], 0.0);
        assert_eq!(explicit_zero["max_levels"], 0);

        let unset = demag_amg_profile_metadata("AMG", Some(&StepStats::default()));
        assert_eq!(unset["strength_threshold"], serde_json::Value::Null);
        assert_eq!(unset["max_levels"], serde_json::Value::Null);
        assert_eq!(metadata["requested_linear_solver"], serde_json::Value::Null);
        assert_eq!(
            metadata["requested_preconditioner"],
            serde_json::Value::Null
        );
        assert_eq!(
            metadata["requested_relative_tolerance"],
            serde_json::Value::Null
        );
        assert_eq!(
            metadata["requested_absolute_tolerance"],
            serde_json::Value::Null
        );
        assert_eq!(
            metadata["requested_max_iterations"],
            serde_json::Value::Null
        );
        assert_eq!(metadata["requested_print_level"], serde_json::Value::Null);
    }

    #[test]
    fn demag_profile_metadata_exposes_periodic_reduced_poisson_contract() {
        let mut plan = test_periodic_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.enable_demag = true;
            fem.demag_realization = Some(fullmag_ir::ResolvedFemDemagIR::PoissonRobin);
        }

        let metadata = demag_runtime_metadata(&plan, &ExecutionProvenance::default(), &[]);

        assert_eq!(metadata["model"], "airbox");
        assert_eq!(
            metadata["magnetostatic_boundary_model"],
            "periodic_airbox_k0"
        );
        assert_eq!(metadata["boundary_variant"], "robin");
        assert_eq!(metadata["poisson_operator"], "pbc_reduced_poisson");
        assert_eq!(metadata["periodic_reduction"]["enabled"], true);
        assert_eq!(metadata["periodic_reduction"]["method"], "P^T A P");
        assert_eq!(metadata["periodic_reduction"]["node_pair_count"], 2);
        assert_eq!(metadata["periodic_reduction"]["boundary_pair_count"], 2);
        assert_eq!(
            metadata["periodic_reduction"]["node_pair_counts_by_id"]["x_faces"],
            1
        );
        assert_eq!(
            metadata["periodic_reduction"]["boundary_pair_counts_by_id"]["y_faces"],
            1
        );
        assert_eq!(
            metadata["periodic_reduction"]["periodic_boundary_markers_excluded_from_robin"],
            true
        );
    }

    #[test]
    fn demag_profile_metadata_distinguishes_explicit_policy_from_resolved_policy() {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.enable_demag = true;
            fem.demag_solver_policy = Some(fullmag_ir::FemLinearSolverPolicy {
                solver: "GMRES".to_string(),
                preconditioner: "JACOBI".to_string(),
                rtol: 1.0e-6,
                atol: Some(1.0e-20),
                max_iterations: 77,
                print_level: 2,
            });
        }
        let mut provenance = ExecutionProvenance::default();
        provenance.fem_poisson_demag = Some(crate::types::FemPoissonDemagProvenance {
            linear_solver: "CG".to_string(),
            preconditioner: "AMG".to_string(),
            rtol: 1.0e-8,
            max_iterations: 500,
            ..Default::default()
        });

        let metadata = demag_runtime_metadata(&plan, &provenance, &[]);

        assert_eq!(metadata["policy_source"], "explicit");
        assert_eq!(metadata["requested_linear_solver"], "GMRES");
        assert_eq!(metadata["requested_preconditioner"], "JACOBI");
        assert_eq!(metadata["requested_relative_tolerance"], 1.0e-6);
        assert_eq!(metadata["requested_absolute_tolerance"], 1.0e-20);
        assert_eq!(metadata["requested_max_iterations"], 77);
        assert_eq!(metadata["requested_print_level"], 2);
        assert_eq!(metadata["linear_solver"], "CG");
        assert_eq!(metadata["preconditioner"], "AMG");
        assert_eq!(metadata["relative_tolerance"], 1.0e-8);
        assert_eq!(metadata["max_iterations"], 500);
    }

    #[test]
    fn demag_profile_metadata_omits_amg_profile_for_non_amg_policy() {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.enable_demag = true;
            fem.demag_solver_policy = Some(fullmag_ir::FemLinearSolverPolicy {
                preconditioner: "JACOBI".to_string(),
                ..Default::default()
            });
        }

        let metadata = demag_runtime_metadata(&plan, &ExecutionProvenance::default(), &[]);

        assert_eq!(metadata["preconditioner"], "JACOBI");
        assert_eq!(metadata["amg_profile"], serde_json::Value::Null);
    }

    #[test]
    fn fem_cpu_relaxation_qualification_metadata_carries_reproducibility_contract() {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.enable_demag = true;
            fem.demag_realization = Some(fullmag_ir::ResolvedFemDemagIR::PoissonRobin);
            fem.material.uniaxial_anisotropy = Some(0.5e6);
            fem.material.anisotropy_axis = Some([0.0, 0.0, 1.0]);
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::LlgOverdamped,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(100),
                    max_relaxation_time_s: None,
                },
            });
        }
        let provenance = ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            mfem_device: Some("cpu".to_string()),
            fem_assembly_mode: Some("legacy_sparse".to_string()),
            fem_execution_mode: Some("cpu_native".to_string()),
            fem_data_residency: Some("host_source_of_truth".to_string()),
            uses_cuda_kernels: Some(false),
            uses_gpu_poisson: Some(false),
            ..ExecutionProvenance::default()
        };
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 100,
                    e_ex: 1.0,
                    e_demag: 2.0,
                    e_ani: 3.0,
                    e_total: 6.0,
                    max_torque_Apm: 4.0e-4,
                    demag_solver_setup_reused: true,
                    poisson_iterations: 13,
                    poisson_final_residual: 1.0e-8,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: Some(fullmag_ir::StageCompletionIR {
                    status: "completed".to_string(),
                    converged: true,
                    reason: Some(fullmag_ir::StageStopReason::Torque),
                    metric: Some(fullmag_ir::StageMetricKind::MaxTorqueApm),
                    metric_name: Some("max_torque_apm".to_string()),
                    metric_value: Some(4.0e-4),
                    threshold: Some(1.0e-3),
                }),
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: provenance.clone(),
        };
        let demag_runtime = demag_runtime_metadata(&plan, &provenance, &executed.result.steps);

        let metadata = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &provenance,
            &demag_runtime,
            &executed,
        );

        assert_eq!(
            metadata["schema_version"],
            "fem_cpu_relaxation_qualification.v1"
        );
        assert_eq!(
            metadata["benchmark_gate_version"],
            "fem_cpu_no_pbc_adaptive.v1"
        );
        assert_eq!(
            metadata["physics_terms"],
            serde_json::json!(["exchange", "demag", "anisotropy_uniaxial"])
        );
        assert_eq!(
            metadata["solver_mesh_signature"].as_str().unwrap().len(),
            64
        );
        assert_eq!(metadata["demag_policy"]["linear_solver"], "CG");
        assert_eq!(metadata["assembly_mode"], "legacy_sparse");
        assert_eq!(metadata["relaxation_algorithm"], "llg_overdamped");
        assert_eq!(metadata["stop_reason"], "torque");
        assert_eq!(metadata["final_energy_terms_j"]["E_ex"], 1.0);
        assert_eq!(metadata["final_energy_terms_j"]["E_demag"], 2.0);
        assert_eq!(metadata["final_energy_terms_j"]["E_ani"], 3.0);
        assert_eq!(metadata["final_torque_apm"], 4.0e-4);
        assert_eq!(metadata["norm_defect"], 0.0);

        let typed: crate::types::FemCpuRelaxationQualificationMetadata =
            serde_json::from_value(metadata).expect("qualification metadata should be typed");
        assert_eq!(typed.schema_version, "fem_cpu_relaxation_qualification.v1");
        assert_eq!(typed.demag_policy.linear_solver.as_deref(), Some("CG"));
        assert_eq!(typed.final_energy_terms_j.e_total, 6.0);
    }

    #[test]
    fn fem_cpu_relaxation_qualification_metadata_reports_direct_minimizer_policy() {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::ProjectedGradientBb,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(10),
                    max_relaxation_time_s: None,
                },
            });
        }
        let provenance = ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            fdm_gpu_execution_receipt: None,
            resolved_energy_minimizer: Some("projected_gradient_bb".to_string()),
            energy_minimizer_realization: Some("native_mfem_pgbb".to_string()),
            fem_assembly_mode: Some("legacy_sparse".to_string()),
            fem_gpu_qualification_status: None,
            ..ExecutionProvenance::default()
        };
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 3,
                    e_ex: 1.0,
                    e_total: 1.0,
                    max_torque_Apm: 2.0e-4,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: Some(fullmag_ir::StageCompletionIR {
                    status: "completed".to_string(),
                    converged: false,
                    reason: Some(fullmag_ir::StageStopReason::MaxSteps),
                    metric: Some(fullmag_ir::StageMetricKind::Steps),
                    metric_name: Some("step".to_string()),
                    metric_value: Some(4.0),
                    threshold: Some(4.0),
                }),
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: provenance.clone(),
        };
        let demag_runtime = demag_runtime_metadata(&plan, &provenance, &executed.result.steps);

        let metadata = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &provenance,
            &demag_runtime,
            &executed,
        );

        assert_eq!(metadata["relaxation_algorithm"], "projected_gradient_bb");
        assert_eq!(
            metadata["algorithm_policy"]["realization"],
            "native_mfem_pgbb"
        );
        assert_eq!(
            metadata["algorithm_policy"]["metric"],
            "mu0_ms_fem_lumped_volume"
        );
        assert_eq!(metadata["algorithm_policy"]["gradient_units"], "A/m");
        assert_eq!(
            metadata["algorithm_policy"]["gradient_metric"],
            "mu0_ms_fem_lumped_volume"
        );
        assert_eq!(metadata["algorithm_policy"]["armijo_derivative_units"], "J");
        assert_eq!(
            metadata["algorithm_policy"]["search_direction_units"],
            "A/m"
        );
        assert_eq!(
            metadata["algorithm_policy"]["line_search_step_units"],
            "m/A"
        );
        assert_eq!(metadata["algorithm_policy"]["armijo_slope_units"], "J A/m");
        assert_eq!(metadata["algorithm_policy"]["armijo_decrement_units"], "J");
        assert_eq!(
            metadata["algorithm_policy"]["preconditioner"],
            "exchange_plus_mass_tangent_gradient"
        );
        assert_eq!(
            metadata["algorithm_policy"]["step_update"],
            "alternating_bb1_bb2"
        );
        assert_eq!(
            metadata["algorithm_policy"]["gpu_status"],
            serde_json::Value::Null
        );

        let typed: crate::types::FemCpuRelaxationQualificationMetadata =
            serde_json::from_value(metadata).expect("qualification metadata should be typed");
        let policy = typed
            .algorithm_policy
            .expect("direct minimizer metadata must carry an algorithm policy");
        assert_eq!(
            policy.linear_solver_policy.as_deref(),
            Some("serial MFEM CG production default; HyprePCG/BoomerAMG explicit opt-in")
        );

        let requested_only = ExecutionProvenance {
            requested_energy_minimizer: Some("projected_gradient_bb".to_string()),
            resolved_energy_minimizer: None,
            ..provenance.clone()
        };
        let unresolved_metadata = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &requested_only,
            &demag_runtime,
            &executed,
        );
        assert!(unresolved_metadata["algorithm_policy"]["metric"].is_null());
        assert!(unresolved_metadata["algorithm_policy"]["gradient_metric"].is_null());
        assert!(unresolved_metadata["algorithm_policy"]["armijo_derivative_units"].is_null());
        assert!(unresolved_metadata["algorithm_policy"]["gradient_units"].is_null());
        assert!(unresolved_metadata["algorithm_policy"]["armijo_slope_units"].is_null());

        let bogus_realization = ExecutionProvenance {
            energy_minimizer_realization: Some("bogus_native_realization".to_string()),
            ..provenance.clone()
        };
        let bogus_metadata = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &bogus_realization,
            &demag_runtime,
            &executed,
        );
        assert!(bogus_metadata["algorithm_policy"]["metric"].is_null());
        assert!(bogus_metadata["algorithm_policy"]["gradient_metric"].is_null());
        assert!(bogus_metadata["algorithm_policy"]["armijo_derivative_units"].is_null());
    }

    #[test]
    fn fem_cpu_relaxation_qualification_metadata_reports_tpi_energy_weighted_armijo_contract() {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::TangentPlaneImplicit,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(4),
                    max_relaxation_time_s: None,
                },
            });
        }
        let provenance = ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            requested_energy_minimizer: Some("tangent_plane_implicit".to_string()),
            resolved_energy_minimizer: Some("tangent_plane_implicit".to_string()),
            energy_minimizer_realization: Some("native_mfem_tpi".to_string()),
            fem_assembly_mode: Some("legacy_sparse".to_string()),
            ..ExecutionProvenance::default()
        };
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 4,
                    e_total: 1.0,
                    max_torque_Apm: 2.0e-4,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: provenance.clone(),
        };
        let demag_runtime = demag_runtime_metadata(&plan, &provenance, &executed.result.steps);
        let metadata = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &provenance,
            &demag_runtime,
            &executed,
        );
        let policy = &metadata["algorithm_policy"];
        assert_eq!(policy["metric"], "mu0_ms_fem_lumped_volume");
        assert_eq!(policy["gradient_metric"], "mu0_ms_fem_lumped_volume");
        assert_eq!(policy["gradient_units"], "A/m");
        assert_eq!(policy["search_direction_units"], "A/m");
        assert_eq!(policy["line_search_step_units"], "m/A");
        assert_eq!(policy["armijo_slope_units"], "J A/m");
        assert_eq!(policy["armijo_decrement_units"], "J");
        assert_eq!(policy["armijo_derivative_units"], "J");

        let requested_only = ExecutionProvenance {
            resolved_energy_minimizer: None,
            ..provenance.clone()
        };
        let unresolved = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &requested_only,
            &demag_runtime,
            &executed,
        );
        assert!(unresolved["algorithm_policy"]["metric"].is_null());
        assert!(unresolved["algorithm_policy"]["armijo_derivative_units"].is_null());

        let bogus_realization = ExecutionProvenance {
            energy_minimizer_realization: Some("bogus_native_realization".to_string()),
            ..provenance
        };
        let bogus = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &bogus_realization,
            &demag_runtime,
            &executed,
        );
        assert!(bogus["algorithm_policy"]["metric"].is_null());
        assert!(bogus["algorithm_policy"]["gradient_metric"].is_null());
        assert!(bogus["algorithm_policy"]["armijo_derivative_units"].is_null());
    }

    #[test]
    fn fem_cpu_relaxation_qualification_metadata_reports_nonlinear_cg_update_policy() {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::NonlinearCg,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(10),
                    max_relaxation_time_s: None,
                },
            });
        }
        let provenance = ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            resolved_energy_minimizer: Some("nonlinear_cg".to_string()),
            energy_minimizer_realization: Some("native_mfem_nonlinear_cg".to_string()),
            fem_assembly_mode: Some("legacy_sparse".to_string()),
            fem_gpu_qualification_status: None,
            ..ExecutionProvenance::default()
        };
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 3,
                    e_ex: 1.0,
                    e_total: 1.0,
                    max_torque_Apm: 2.0e-4,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: Some(fullmag_ir::StageCompletionIR {
                    status: "completed".to_string(),
                    converged: false,
                    reason: Some(fullmag_ir::StageStopReason::MaxSteps),
                    metric: Some(fullmag_ir::StageMetricKind::Steps),
                    metric_name: Some("step".to_string()),
                    metric_value: Some(4.0),
                    threshold: Some(4.0),
                }),
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: provenance.clone(),
        };
        let demag_runtime = demag_runtime_metadata(&plan, &provenance, &executed.result.steps);

        let metadata = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &provenance,
            &demag_runtime,
            &executed,
        );

        assert_eq!(metadata["relaxation_algorithm"], "nonlinear_cg");
        assert_eq!(
            metadata["algorithm_policy"]["direction_update"],
            "polak_ribiere_plus_projected_restart"
        );
        assert_eq!(
            metadata["algorithm_policy"]["line_search"],
            "native_armijo_backtracking_pr_plus_restart"
        );
    }

    #[test]
    fn fem_relaxation_norm_defect_ignores_shared_domain_airbox_nodes() {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::NonlinearCg,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(10),
                    max_relaxation_time_s: None,
                },
            });
            fem.domain_mesh_mode = FemDomainMeshModeIR::SharedDomainMeshWithAir;
            fem.mesh_parts = vec![
                FemMeshPartIR {
                    id: "part:body".to_string(),
                    label: "body".to_string(),
                    role: FemMeshPartRole::MagneticObject,
                    object_id: Some("body".to_string()),
                    geometry_id: Some("body_geom".to_string()),
                    material_id: None,
                    element_selector: FemMeshPartSelector::ElementRange { start: 0, count: 0 },
                    boundary_face_selector: FemMeshPartSelector::BoundaryFaceRange {
                        start: 0,
                        count: 0,
                    },
                    node_selector: FemMeshPartSelector::NodeRange { start: 0, count: 1 },
                    boundary_face_indices: Vec::new(),
                    node_indices: vec![0],
                    facet_global_ordinals: Vec::new(),
                    bounds_min: None,
                    bounds_max: None,
                    parent_id: None,
                },
                FemMeshPartIR {
                    id: "part:__air__".to_string(),
                    label: "Airbox".to_string(),
                    role: FemMeshPartRole::Air,
                    object_id: None,
                    geometry_id: None,
                    material_id: None,
                    element_selector: FemMeshPartSelector::ElementRange { start: 0, count: 0 },
                    boundary_face_selector: FemMeshPartSelector::BoundaryFaceRange {
                        start: 0,
                        count: 0,
                    },
                    node_selector: FemMeshPartSelector::NodeRange { start: 1, count: 3 },
                    boundary_face_indices: Vec::new(),
                    node_indices: vec![1, 2, 3],
                    facet_global_ordinals: Vec::new(),
                    bounds_min: None,
                    bounds_max: None,
                    parent_id: None,
                },
            ];
        }
        let provenance = ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            energy_minimizer_realization: None,
            fem_assembly_mode: Some("legacy_sparse".to_string()),
            ..ExecutionProvenance::default()
        };
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 3,
                    e_ex: 1.0,
                    e_total: 1.0,
                    max_torque_Apm: 2.0e-4,
                    ..StepStats::default()
                }],
                final_magnetization: vec![
                    [1.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0],
                ],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: provenance.clone(),
        };
        let demag_runtime = demag_runtime_metadata(&plan, &provenance, &executed.result.steps);

        let metadata = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &provenance,
            &demag_runtime,
            &executed,
        );

        assert_eq!(metadata["norm_defect"], 0.0);
    }

    #[test]
    fn metadata_reports_fem_gpu_direct_minimizer_qualification_policy() {
        let mut problem = fem_execution_problem("gpu", ExecutionMode::Strict);
        problem.problem_meta.name = "gpu_ncg_relax_metadata".to_string();
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::NonlinearCg,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(4),
                    max_relaxation_time_s: None,
                },
            });
        }
        let provenance = ExecutionProvenance {
            execution_engine: "fem_native_gpu".to_string(),
            precision: "double".to_string(),
            mfem_version: Some("4.8".to_string()),
            hypre_version: Some("2.32.0".to_string()),
            requested_energy_minimizer: Some("nonlinear_cg".to_string()),
            resolved_energy_minimizer: Some("nonlinear_cg".to_string()),
            energy_minimizer_realization: Some("native_cuda_nonlinear_cg".to_string()),
            fem_execution_mode: Some("all_in_gpu_legacy_sparse".to_string()),
            fem_gpu_qualification_status: Some("production_executable".to_string()),
            fem_exchange_operator_mode: Some("legacy_sparse_gpu".to_string()),
            fem_data_residency: Some("device_source_of_truth".to_string()),
            uses_cuda_kernels: Some(true),
            uses_gpu_poisson: Some(true),
            fem_demag_operator_mode: Some("device_hypre_poisson".to_string()),
            hot_loop_exchange_host_sync_count: Some(0),
            hot_loop_compute_host_sync_count: Some(3),
            hot_loop_control_scalar_d2h_bytes: Some(0),
            hot_loop_control_scalar_host_sync_count: Some(0),
            ..ExecutionProvenance::default()
        };
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 4,
                    e_ex: 1.0,
                    e_demag: 2.0,
                    e_total: 3.0,
                    max_torque_Apm: 2.0e-4,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: Some(fullmag_ir::StageCompletionIR {
                    status: "completed".to_string(),
                    converged: false,
                    reason: Some(fullmag_ir::StageStopReason::MaxSteps),
                    metric: Some(fullmag_ir::StageMetricKind::Steps),
                    metric_name: Some("step".to_string()),
                    metric_value: Some(4.0),
                    threshold: Some(4.0),
                }),
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: provenance.clone(),
        };
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fem-gpu-relax-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("GPU relaxation metadata artifacts should be written");
        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata should exist"),
        )
        .expect("metadata should parse");
        let qualification = &metadata["fem_gpu_relaxation_qualification"];
        assert_eq!(
            qualification["schema_version"],
            "fem_gpu_relaxation_qualification.v1"
        );
        assert_eq!(qualification["relaxation_algorithm"], "nonlinear_cg");
        assert_eq!(
            qualification["algorithm_policy"]["line_search"],
            "native_armijo_backtracking_pr_plus_restart"
        );
        assert_eq!(
            qualification["algorithm_policy"]["metric"],
            "mu0_ms_fem_lumped_volume"
        );
        assert_eq!(qualification["algorithm_policy"]["gradient_units"], "A/m");
        assert_eq!(
            qualification["algorithm_policy"]["search_direction_units"],
            "A/m"
        );
        assert_eq!(
            qualification["algorithm_policy"]["line_search_step_units"],
            "m/A"
        );
        assert_eq!(
            qualification["algorithm_policy"]["armijo_slope_units"],
            "J A/m"
        );
        assert_eq!(
            qualification["algorithm_policy"]["armijo_decrement_units"],
            "J"
        );
        assert_eq!(
            qualification["algorithm_policy"]["gradient_policy"],
            "device_tangent_gradient"
        );
        assert_eq!(
            qualification["device_policy"]["exchange_operator_mode"],
            "legacy_sparse_gpu"
        );
        assert_eq!(
            qualification["device_policy"]["hot_loop_exchange_host_sync_count"],
            0
        );
        assert_eq!(qualification["stop_reason"], "max_steps");
        assert_eq!(qualification["stop_metric_name"], "step");
        assert_eq!(qualification["stop_metric_value"], 4.0);
        assert_eq!(qualification["stop_threshold"], 4.0);
        assert_eq!(qualification["final_energy_terms_j"]["E_ex"], 1.0);
        assert_eq!(qualification["final_energy_terms_j"]["E_demag"], 2.0);
        assert_eq!(qualification["final_energy_terms_j"]["E_total"], 3.0);
        assert_eq!(qualification["final_torque_apm"], 2.0e-4);
        let bogus_realization = ExecutionProvenance {
            energy_minimizer_realization: Some("bogus_native_realization".to_string()),
            ..provenance
        };
        let bogus = fem_gpu_relaxation_qualification_metadata(&plan, &bogus_realization, &executed);
        assert!(bogus["algorithm_policy"]["metric"].is_null());
        assert!(bogus["algorithm_policy"]["gradient_metric"].is_null());
        assert!(bogus["algorithm_policy"]["armijo_derivative_units"].is_null());
        assert_eq!(qualification["norm_defect"], 0.0);

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn metadata_reports_fem_llg_overdamped_relaxation_policy() {
        let mut problem = fem_execution_problem("gpu", ExecutionMode::Strict);
        problem.problem_meta.name = "gpu_llg_relax_metadata".to_string();
        let mut gpu_plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut gpu_plan.backend_plan {
            fem.relaxation = Some(fullmag_ir::RelaxationControlIR {
                algorithm: fullmag_ir::RelaxationAlgorithmIR::LlgOverdamped,
                stop: fullmag_ir::RelaxStopIR {
                    torque_tolerance_apm: Some(1.0e-3),
                    energy_tolerance_j: None,
                    max_steps: Some(4),
                    max_relaxation_time_s: None,
                },
            });
        }
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 4,
                    e_ex: 1.0,
                    e_demag: 2.0,
                    e_total: 3.0,
                    max_torque_Apm: 2.0e-4,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_native_gpu".to_string(),
                precision: "double".to_string(),
                mfem_version: Some("4.8".to_string()),
                hypre_version: Some("2.32.0".to_string()),
                requested_integrator: Some("heun".to_string()),
                resolved_integrator: Some("heun".to_string()),
                requested_energy_minimizer: Some("llg_overdamped".to_string()),
                resolved_energy_minimizer: Some("llg_overdamped".to_string()),
                energy_minimizer_realization: Some("native_llg_time_integrator".to_string()),
                llg_mode: Some("pure_damping".to_string()),
                fem_execution_mode: Some("all_in_gpu_legacy_sparse".to_string()),
                fem_gpu_qualification_status: Some("production_executable".to_string()),
                fem_exchange_operator_mode: Some("legacy_sparse_gpu".to_string()),
                fem_data_residency: Some("device_source_of_truth".to_string()),
                uses_cuda_kernels: Some(true),
                uses_gpu_poisson: Some(true),
                fem_demag_operator_mode: Some("device_hypre_poisson".to_string()),
                hot_loop_exchange_host_sync_count: Some(0),
                hot_loop_compute_host_sync_count: Some(3),
                hot_loop_control_scalar_d2h_bytes: Some(0),
                hot_loop_control_scalar_host_sync_count: Some(0),
                ..ExecutionProvenance::default()
            },
        };
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fem-gpu-llg-relax-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        write_artifacts(&output_dir, &problem, &gpu_plan, &executed, None)
            .expect("GPU LLG relaxation metadata artifacts should be written");
        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata should exist"),
        )
        .expect("metadata should parse");
        let qualification = &metadata["fem_gpu_relaxation_qualification"];
        assert_eq!(
            qualification["schema_version"],
            "fem_gpu_relaxation_qualification.v1"
        );
        assert_eq!(qualification["relaxation_algorithm"], "llg_overdamped");
        assert_eq!(
            qualification["algorithm_policy"]["realization"],
            "native_llg_time_integrator"
        );
        assert_eq!(qualification["algorithm_policy"]["time_integrator"], "heun");
        assert_eq!(
            qualification["algorithm_policy"]["precession_policy"],
            "disabled_pure_damping"
        );
        assert_eq!(
            qualification["algorithm_policy"]["rhs_policy"],
            "llg_overdamped_rhs"
        );

        let cpu_plan = gpu_plan.clone();
        let cpu_provenance = ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            requested_integrator: Some("heun".to_string()),
            resolved_integrator: Some("heun".to_string()),
            requested_energy_minimizer: Some("llg_overdamped".to_string()),
            resolved_energy_minimizer: Some("llg_overdamped".to_string()),
            energy_minimizer_realization: Some("native_llg_time_integrator".to_string()),
            llg_mode: Some("pure_damping".to_string()),
            fem_assembly_mode: Some("legacy_sparse".to_string()),
            fem_gpu_qualification_status: Some("production_executable".to_string()),
            ..ExecutionProvenance::default()
        };
        let demag_runtime =
            demag_runtime_metadata(&cpu_plan, &cpu_provenance, &executed.result.steps);
        let cpu_executed = ExecutedRun {
            provenance: cpu_provenance.clone(),
            ..executed.clone()
        };
        let cpu_qualification = fem_cpu_relaxation_qualification_metadata(
            &cpu_plan,
            &cpu_provenance,
            &demag_runtime,
            &cpu_executed,
        );
        assert_eq!(cpu_qualification["relaxation_algorithm"], "llg_overdamped");
        assert_eq!(
            cpu_qualification["algorithm_policy"]["realization"],
            "native_llg_time_integrator"
        );
        assert_eq!(
            cpu_qualification["algorithm_policy"]["precession_policy"],
            "disabled_pure_damping"
        );

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn fem_cpu_relaxation_qualification_metadata_reports_cubic_anisotropy_term() {
        let mut plan = test_fem_execution_plan();
        if let BackendPlanIR::Fem(fem) = &mut plan.backend_plan {
            fem.enable_demag = true;
            fem.demag_realization = Some(fullmag_ir::ResolvedFemDemagIR::PoissonRobin);
            fem.material.cubic_anisotropy_kc1 = Some(4.8e4);
            fem.material.cubic_anisotropy_axis1 = Some([1.0, 0.0, 0.0]);
            fem.material.cubic_anisotropy_axis2 = Some([0.0, 1.0, 0.0]);
        }
        let provenance = ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            mfem_device: Some("cpu".to_string()),
            fem_assembly_mode: Some("legacy_sparse".to_string()),
            fem_execution_mode: Some("cpu_native".to_string()),
            fem_data_residency: Some("host_source_of_truth".to_string()),
            uses_cuda_kernels: Some(false),
            uses_gpu_poisson: Some(false),
            ..ExecutionProvenance::default()
        };
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 2,
                    e_ex: 1.0,
                    e_demag: 2.0,
                    e_ani: 3.0,
                    e_total: 6.0,
                    demag_solver_setup_reused: true,
                    poisson_iterations: 8,
                    poisson_final_residual: 5.0e-9,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: provenance.clone(),
        };
        let demag_runtime = demag_runtime_metadata(&plan, &provenance, &executed.result.steps);

        let metadata = fem_cpu_relaxation_qualification_metadata(
            &plan,
            &provenance,
            &demag_runtime,
            &executed,
        );

        assert_eq!(
            metadata["physics_terms"],
            serde_json::json!(["exchange", "demag", "anisotropy_cubic"])
        );
    }

    #[test]
    fn fdm_field_layout_reports_active_mask_counts() {
        let layout = field_layout(&test_execution_plan(Some(vec![
            true, true, false, false, true, false, true, false,
        ])));
        assert_eq!(layout["backend"], "fdm");
        assert_eq!(layout["origin_m"], serde_json::json!([0.0, 0.0, 0.0]));
        assert_eq!(layout["total_cell_count"], 8);
        assert_eq!(layout["active_mask_present"], true);
        assert_eq!(layout["active_cell_count"], 4);
        assert_eq!(layout["inactive_cell_count"], 4);
        assert_eq!(layout["active_fraction"], serde_json::json!(0.5));
    }

    #[test]
    fn fdm_field_layout_defaults_to_full_domain_without_mask() {
        let layout = field_layout(&test_execution_plan(None));
        assert_eq!(layout["active_mask_present"], false);
        assert_eq!(layout["active_cell_count"], 8);
        assert_eq!(layout["inactive_cell_count"], 0);
        assert_eq!(layout["active_fraction"], serde_json::json!(1.0));
        assert!(layout["grid_fingerprint"].as_str().is_some());
    }

    #[test]
    fn final_magnetization_artifact_binds_layout_and_sample_identity() {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time")
            .as_nanos();
        let root = std::env::temp_dir().join(format!(
            "fullmag-state-identity-{}-{unique}",
            std::process::id()
        ));
        fs::create_dir_all(&root).expect("create state identity fixture");

        let plan = test_execution_plan(None);
        let context = FieldArtifactContext {
            problem_name: "state-identity".into(),
            ir_version: "v0".into(),
            source_hash: Some("source-bound".into()),
            execution_mode: ExecutionMode::Strict,
            layout: field_layout(&plan),
            magnetization_field_semantics: Ok(None),
            execution_resolution: None,
        };
        let path = root.join("m_final.json");
        write_field_file(
            &path,
            &context,
            &ExecutionProvenance::default(),
            "m",
            8,
            8.0e-12,
            1.0e-12,
            &[[1.0, 0.0, 0.0]; 8],
        )
        .expect("write final magnetization field");
        let field: serde_json::Value =
            serde_json::from_slice(&fs::read(&path).expect("read field artifact"))
                .expect("parse field artifact JSON");
        let layout_bytes = serde_json::to_vec(&context.layout).expect("serialize layout");
        assert_eq!(
            field["state_identity"]["schema_version"],
            "magnetization_state.v1"
        );
        assert_eq!(field["state_identity"]["backend"], "fdm");
        assert_eq!(
            field["state_identity"]["layout_sha256"],
            format!("{:x}", Sha256::digest(layout_bytes))
        );
        assert_eq!(field["state_identity"]["sample_count"], 8);

        fs::remove_dir_all(root).expect("remove state identity fixture");
    }

    #[test]
    fn fem_p1_magnetization_artifact_emits_typed_semantics_only_for_m() {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time")
            .as_nanos();
        let root = std::env::temp_dir().join(format!(
            "fullmag-fem-p1-field-semantics-{}-{unique}",
            std::process::id()
        ));
        fs::create_dir_all(&root).expect("create FEM field semantics fixture");

        let plan = test_fem_execution_plan();
        let context = build_field_context(
            &fullmag_ir::ProblemIR::bootstrap_example(),
            &plan,
        );
        assert!(context.magnetization_field_semantics.is_ok());
        assert!(context
            .magnetization_field_semantics
            .as_ref()
            .expect("FEM magnetization semantics result")
            .is_some());

        let magnetization_path = root.join("m_final.json");
        write_field_file(
            &magnetization_path,
            &context,
            &ExecutionProvenance::default(),
            "m",
            4,
            4.0e-12,
            1.0e-12,
            &[[1.0, 0.0, 0.0]; 4],
        )
        .expect("write FEM magnetization field");
        let magnetization: serde_json::Value = serde_json::from_slice(
            &fs::read(&magnetization_path).expect("read FEM magnetization field"),
        )
        .expect("parse FEM magnetization field");
        assert_eq!(
            magnetization["layout"]["field_semantics"]["format"],
            fullmag_quantities::fem_state_field::FEM_P1_MAGNETIZATION_FIELD_SEMANTICS_FORMAT
        );
        assert_eq!(
            magnetization["state_identity"]["schema_version"],
            "magnetization_state.v1"
        );
        let layout_bytes = serde_json::to_vec(&magnetization["layout"])
            .expect("serialize FEM magnetization layout");
        assert_eq!(
            magnetization["state_identity"]["layout_sha256"],
            format!("{:x}", Sha256::digest(layout_bytes))
        );

        let field_path = root.join("H_eff_final.json");
        write_field_file(
            &field_path,
            &context,
            &ExecutionProvenance::default(),
            "H_eff",
            4,
            4.0e-12,
            1.0e-12,
            &[[0.0, 0.0, 0.0]; 4],
        )
        .expect("write FEM effective field");
        let field: serde_json::Value =
            serde_json::from_slice(&fs::read(&field_path).expect("read FEM effective field"))
                .expect("parse FEM effective field");
        assert!(field["layout"].get("field_semantics").is_none());
        assert!(field.get("state_identity").is_none());

        fs::remove_dir_all(root).expect("remove FEM field semantics fixture");
    }

    #[test]
    fn fem_magnetization_writer_rejects_semantics_error_but_other_fields_continue() {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time")
            .as_nanos();
        let root = std::env::temp_dir().join(format!(
            "fullmag-fem-p1-field-semantics-error-{}-{unique}",
            std::process::id()
        ));
        fs::create_dir_all(&root).expect("create FEM field semantics error fixture");

        let context = FieldArtifactContext {
            problem_name: "fem-p1-semantics-error".into(),
            ir_version: "v0".into(),
            source_hash: None,
            execution_mode: ExecutionMode::Strict,
            layout: serde_json::json!({"backend": "fem"}),
            magnetization_field_semantics: Err("invalid FEM mesh".into()),
            execution_resolution: None,
        };
        let error = write_field_file(
            &root.join("m_final.json"),
            &context,
            &ExecutionProvenance::default(),
            "m",
            1,
            0.0,
            1.0e-12,
            &[[1.0, 0.0, 0.0]],
        )
        .expect_err("m must reject an unavailable semantics result");
        assert_eq!(error.kind(), ErrorKind::InvalidData);
        assert!(error
            .to_string()
            .contains("FEM magnetization field semantics unavailable"));

        let other_path = root.join("H_eff_final.json");
        write_field_file(
            &other_path,
            &context,
            &ExecutionProvenance::default(),
            "H_eff",
            1,
            0.0,
            1.0e-12,
            &[[0.0, 0.0, 0.0]],
        )
        .expect("other observables must not consume m semantics errors");
        let other: serde_json::Value = serde_json::from_slice(
            &fs::read(&other_path).expect("read effective field after semantics error"),
        )
        .expect("parse effective field after semantics error");
        assert!(other["layout"].get("field_semantics").is_none());

        fs::remove_dir_all(root).expect("remove FEM field semantics error fixture");
    }

    #[test]
    fn fem_p1_magnetization_factory_rejects_invalid_execution_mesh() {
        let mut plan = test_fem_execution_plan();
        {
            let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
                panic!("test plan must be FEM");
            };
            fem.mesh.nodes[3] = [0.0, 0.0, 0.0];
        }

        let error = fem_p1_magnetization_field_semantics(&plan)
            .expect_err("invalid FEM geometry must not receive field semantics");
        assert!(error.contains("degenerate tetra volume"), "{error}");
    }

    #[test]
    fn fem_p1_magnetization_factory_uses_runtime_marker_normalization_for_support() {
        let mut plan = test_fem_execution_plan();
        let expected_mask = {
            let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
                panic!("test plan must be FEM");
            };
            fem.mesh.nodes.push([2.0, 0.0, 0.0]);
            fem.mesh.set_tet4_cells(vec![[0, 1, 2, 3], [1, 2, 3, 4]]);
            fem.mesh.element_markers = vec![1, 0];
            fem.object_segments.clear();
            fem.region_materials = vec![fullmag_ir::FemRegionMaterialIR {
                object_id: "free".to_string(),
                material: fem.material.clone(),
                element_marker: 1,
            }];

            let normalized_markers = normalized_runtime_element_markers(fem)
                .expect("region-material markers should normalize");
            crate::preview::mesh_quantity_active_mask_with_element_markers(
                "m",
                &fem.mesh,
                &normalized_markers,
            )
            .expect("magnetization support mask")
        };
        let semantics = fem_p1_magnetization_field_semantics(&plan)
            .expect("valid region-material mesh should produce semantics")
            .expect("FEM H1/P1 semantics should be present");
        assert_eq!(semantics.active_node_mask, expected_mask);
        assert_eq!(semantics.active_node_mask, vec![true, true, true, true, false]);

        let mut all_zero_plan = test_fem_execution_plan();
        {
            let BackendPlanIR::Fem(all_zero_fem) = &mut all_zero_plan.backend_plan else {
                panic!("test plan must be FEM");
            };
            all_zero_fem.mesh.element_markers = vec![0];
        }
        let all_zero_semantics = fem_p1_magnetization_field_semantics(&all_zero_plan)
            .expect("all-zero marker fallback should be accepted by runtime normalization")
            .expect("all-zero mesh should keep a quantitative FEM field");
        assert_eq!(all_zero_semantics.active_node_mask, vec![true; 4]);

        let mut ambiguous_plan = test_fem_execution_plan();
        {
            let BackendPlanIR::Fem(ambiguous_fem) = &mut ambiguous_plan.backend_plan else {
                panic!("test plan must be FEM");
            };
            ambiguous_fem.mesh.nodes.push([2.0, 0.0, 0.0]);
            ambiguous_fem
                .mesh
                .set_tet4_cells(vec![[0, 1, 2, 3], [1, 2, 3, 4]]);
            ambiguous_fem.mesh.element_markers = vec![1, 2];
            ambiguous_fem.object_segments.clear();
        }
        let error = fem_p1_magnetization_field_semantics(&ambiguous_plan)
            .expect_err("ambiguous positive markers must not receive semantics");
        assert!(error.contains("ambiguous FEM magnetic region contract"), "{error}");
    }

    #[test]
    fn fem_prescribed_current_transport_artifact_uses_solve_region_nodes() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem
            .current_modules
            .push(fullmag_ir::CurrentModuleIR::CurrentTransport {
                name: "drive".to_string(),
                model: fullmag_ir::CurrentTransportModelIR::PrescribedDensity,
                current_density: Some([0.0, 0.0, 5e10]),
                solve_region: Some("pillar_region".to_string()),
                conductivity_s_per_m: None,
                coupling: fullmag_ir::TransportCouplingIR::OneWay,
                time_envelope: None,
                definition: None,
            });
        problem.regions = vec![fullmag_ir::RegionIR {
            name: "pillar_region".to_string(),
            geometry: "pillar".to_string(),
        }];
        let plan = test_fem_execution_plan();
        let context = build_field_context(&problem, &plan);
        let provenance = crate::types::ExecutionProvenance {
            charge_transport: None,
            transport_modules: Vec::new(),
            fdm_gpu_transport_telemetry: None,
            fdm_cpu_state_layout: None,
            fdm_gpu_execution_receipt: None,
            fdm_gpu_step_transaction_telemetry: None,
            fdm_gpu_observation_policy: None,
            fdm_gpu_endpoint_cache_telemetry: None,
            cpu_fixed_coupling: None,
            fdm_cpu_step_transaction_telemetry: None,
            fdm_cpu_evaluation_telemetry: None,
            fdm_fft_execution: None,
            fem_gpu_execution_receipt: None,
            fem_gpu_minimizer_execution_receipt: None,
            executed_physics_kinds: Vec::new(),
            executed_physics_module_ids: Vec::new(),
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            demag_operator_kind: None,
            fft_backend: None,
            device_name: None,
            compute_capability: None,
            cuda_driver_version: None,
            cuda_runtime_version: None,
            lossy_fallback_used: false,
            ignored_terms: Vec::new(),
            random_seed: None,
            resolved_fallback: None,
            fem_eigen_execution_resolution: None,
            fem_eigen_native_execution_attestation: None,
            fem_crossover_decision: None,
            requested_integrator: None,
            resolved_integrator: None,
            requested_energy_minimizer: None,
            resolved_energy_minimizer: None,
            energy_minimizer_realization: None,
            fem_direct_minimizer_policy: None,
            requested_demag_realization: None,
            resolved_demag_realization: None,
            timestep_policy: None,
            fdm_multilayer_transfer_telemetry: None,
            fdm_multilayer_stage_telemetry: None,
            dt_policy: None,
            llg_mode: None,
            mfem_device: None,
            mfem_version: None,
            hypre_version: None,
            demag_refresh_interval_s: None,
            fem_assembly_mode: None,
            fem_execution_mode: None,
            fem_gpu_qualification_status: None,
            fem_exchange_operator_mode: None,
            fem_data_residency: None,
            uses_cuda_kernels: None,
            uses_gpu_poisson: None,
            fem_demag_operator_mode: None,
            hypre_execution_policy: None,
            demag_residency: None,
            hot_loop_host_sync_count: None,
            hot_loop_exchange_h2d_bytes: None,
            hot_loop_exchange_d2h_bytes: None,
            hot_loop_exchange_host_sync_count: None,
            hot_loop_compute_h2d_bytes: None,
            hot_loop_compute_d2h_bytes: None,
            hot_loop_compute_host_sync_count: None,
            hot_loop_control_scalar_d2h_bytes: None,
            hot_loop_control_scalar_host_sync_count: None,
            fem_gpu_state_allocated: None,
            fem_gpu_state_node_count: None,
            fem_gpu_state_dof_len: None,
            fem_gpu_state_stage_count: None,
            fem_gpu_state_device_bytes: None,
            fem_gpu_state_reduction_workspace_bytes: None,
            fem_gpu_rk_exchange_only_enabled: None,
            fem_gpu_rk_stage_count: None,
            fem_gpu_rk_uses_cuda_kernels: None,
            fem_gpu_rk_allows_exchange_host_sync: None,
            fem_gpu_rk_stage_exchange_device_resident: None,
            fem_gpu_rk_block_reason: None,
            requested_cpu_threads: None,
            resolved_cpu_threads: None,
            requested_fem_omp_threads: None,
            effective_fem_omp_threads: None,
            fem_poisson_demag: None,
            fem_bem_demag: None,
        };
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fem-current-transport-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        write_prescribed_current_transport_artifacts(
            &output_dir,
            &problem,
            &plan,
            &context,
            &provenance,
        )
        .expect("fem current transport artifact should be written");

        let artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("current_transport/drive.json"))
                .expect("artifact should exist"),
        )
        .expect("artifact should parse");
        assert_eq!(artifact["coverage"], "solve_region_nodes");
        assert_eq!(artifact["layout"]["backend"], "fem");
        let values = artifact["values"].as_array().expect("values should exist");
        assert_eq!(values.len(), 4);
        assert_eq!(values[0], serde_json::json!([0.0, 0.0, 5e10]));

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn fem_prescribed_current_transport_artifact_uses_mesh_part_node_indices() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem
            .current_modules
            .push(fullmag_ir::CurrentModuleIR::CurrentTransport {
                name: "drive".to_string(),
                model: fullmag_ir::CurrentTransportModelIR::PrescribedDensity,
                current_density: Some([0.0, 0.0, 5e10]),
                solve_region: Some("pillar_region".to_string()),
                conductivity_s_per_m: None,
                coupling: fullmag_ir::TransportCouplingIR::OneWay,
                time_envelope: None,
                definition: None,
            });
        problem.regions = vec![fullmag_ir::RegionIR {
            name: "pillar_region".to_string(),
            geometry: "pillar".to_string(),
        }];
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.mesh.nodes = vec![
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
            [1.0, 1.0, 0.0],
            [1.0, 0.0, 1.0],
        ];
        fem.mesh.set_tet4_cells(vec![[1, 3, 5, 4]]);
        fem.mesh.set_tri3_facets(vec![[1, 3, 5]]);
        fem.initial_magnetization = vec![[1.0, 0.0, 0.0]; 6];
        fem.object_segments[0].node_start = 0;
        fem.object_segments[0].node_count = 3;
        fem.mesh_parts = vec![FemMeshPartIR {
            id: "free".to_string(),
            label: "free".to_string(),
            role: FemMeshPartRole::MagneticObject,
            object_id: Some("free".to_string()),
            geometry_id: Some("pillar".to_string()),
            material_id: None,
            element_selector: FemMeshPartSelector::ElementRange { start: 0, count: 1 },
            boundary_face_selector: FemMeshPartSelector::BoundaryFaceRange { start: 0, count: 1 },
            node_selector: FemMeshPartSelector::NodeRange { start: 0, count: 3 },
            boundary_face_indices: vec![0],
            node_indices: vec![1, 3, 4, 5],
            facet_global_ordinals: vec![0],
            bounds_min: Some([0.0, 0.0, 0.0]),
            bounds_max: Some([1.0, 1.0, 1.0]),
            parent_id: None,
        }];
        let context = build_field_context(&problem, &plan);
        let provenance = crate::types::ExecutionProvenance {
            execution_engine: "fem_cpu_native".to_string(),
            precision: "double".to_string(),
            ..Default::default()
        };
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fem-current-transport-indices-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        write_prescribed_current_transport_artifacts(
            &output_dir,
            &problem,
            &plan,
            &context,
            &provenance,
        )
        .expect("fem current transport artifact should be written");

        let artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("current_transport/drive.json"))
                .expect("artifact should exist"),
        )
        .expect("artifact should parse");
        let values = artifact["values"].as_array().expect("values should exist");
        assert_eq!(values.len(), 6);
        assert_eq!(values[0], serde_json::json!([0.0, 0.0, 0.0]));
        assert_eq!(values[1], serde_json::json!([0.0, 0.0, 5e10]));
        assert_eq!(values[2], serde_json::json!([0.0, 0.0, 0.0]));
        assert_eq!(values[3], serde_json::json!([0.0, 0.0, 5e10]));
        assert_eq!(values[4], serde_json::json!([0.0, 0.0, 5e10]));
        assert_eq!(values[5], serde_json::json!([0.0, 0.0, 5e10]));

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn periodic_pairs_artifact_reports_pair_diagnostics() {
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.mesh.nodes = vec![
            [0.0, 0.0, 0.0],
            [1.0e-6, 0.0, 0.0],
            [0.0, 1.0e-6, 0.0],
            [1.0e-6, 1.0e-6, 0.0],
            [0.0, 0.0, 1.0e-6],
            [1.0e-6, 0.0, 1.0e-6],
            [1.0e-6, 1.0e-6, 0.0],
        ];
        fem.mesh
            .set_tet4_cells(vec![[0, 1, 2, 3], [0, 1, 4, 5], [1, 4, 5, 6]]);
        fem.mesh.element_markers = vec![1, 0, 0];
        fem.mesh.set_tri3_facets(vec![[0, 2, 4], [1, 5, 3]]);
        fem.mesh.boundary_markers = vec![10, 11];
        fem.mesh.periodic_boundary_pairs = vec![fullmag_ir::MeshPeriodicBoundaryPairIR {
            pair_id: "x_periodic".to_string(),
            source_marker: Some("x_min".to_string()),
            destination_marker: Some("x_max".to_string()),
            marker_a: 10,
            marker_b: 11,
            translation: Some([1.0e-6, 0.0, 0.0]),
            tolerance: Some(1.0e-12),
            axis_hint: Some("x".to_string()),
            orientation: Some("same".to_string()),
            pairing_policy: Some("explicit_node_pairs".to_string()),
        }];
        fem.mesh.periodic_node_pairs = vec![
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_periodic".to_string(),
                node_a: 0,
                node_b: 1,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_periodic".to_string(),
                node_a: 2,
                node_b: 3,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_periodic".to_string(),
                node_a: 4,
                node_b: 5,
            },
        ];

        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-periodic-pairs-{}-{}",
            std::process::id(),
            unique_suffix
        ));
        let prepared = build_periodic_pairs_artifact(&plan, Some(46))
            .expect("periodic pairs artifact should build without filesystem output")
            .expect("periodic mesh should produce a periodic pairs artifact");
        assert!(!output_dir.exists(), "pure preparation must not write files");
        assert_eq!(prepared.relative_path, "mesh/periodic_pairs.v1.json");

        write_periodic_pairs_artifact(&output_dir, &plan, Some(46))
            .expect("periodic pairs artifact should be written");
        assert_eq!(
            fs::read(output_dir.join(&prepared.relative_path))
                .expect("periodic pairs artifact should exist"),
            prepared.bytes,
            "legacy wrapper must write the exact bytes returned by the pure builder"
        );

        let artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("mesh/periodic_pairs.v1.json"))
                .expect("periodic pairs artifact should exist"),
        )
        .expect("periodic pairs artifact should parse");
        assert_eq!(artifact["schema_version"], "periodic_pairs.v1");
        assert_eq!(artifact["artifact_path"], "mesh/periodic_pairs.v1.json");
        assert_eq!(artifact["validation_status"], "ok");
        assert!(artifact["mesh_generation_id"].as_str().is_some());
        assert_eq!(artifact["source_scene_revision"], 46);
        assert!(artifact["certificate_fingerprint"].as_str().is_some());
        assert_eq!(artifact["certificate_status"], "accepted");
        assert!(artifact["certificate"]["marker_map_fingerprint"]
            .as_str()
            .is_some());
        assert!(artifact["certificate"]["material_realization_fingerprint"]
            .as_str()
            .is_some());
        assert_eq!(artifact["pair_count"], 1);
        assert_eq!(artifact["paired_node_count"], 3);
        assert_eq!(artifact["pairs"][0]["pair_id"], "x_periodic");
        assert_eq!(artifact["pairs"][0]["paired_node_count"], 3);
        assert_eq!(artifact["pairs"][0]["unpaired_source_node_count"], 0);
        assert_eq!(artifact["pairs"][0]["unpaired_destination_node_count"], 0);
        assert_eq!(
            artifact["pairs"][0]["domain_node_pair_counts"],
            serde_json::json!({"magnetic": 2, "airbox": 1})
        );
        let face_pair = &artifact["pairs"][0]["boundary_face_pairs"][0];
        assert_eq!(face_pair["face_a"], 0);
        assert_eq!(face_pair["face_b"], 1);
        assert_eq!(
            face_pair["translation_m"],
            serde_json::json!([1.0e-6, 0.0, 0.0])
        );
        assert_eq!(face_pair["normal_dot"], -1.0);
        assert_eq!(face_pair["orientation"], "opposed_normals");
        assert_eq!(
            face_pair["vertex_pairs"],
            serde_json::json!([[0, 1], [2, 3], [4, 5]])
        );
        assert_eq!(face_pair["translation_residual_m"], 0.0);
        assert_eq!(face_pair["area_residual_m2"], 0.0);
        assert_eq!(
            artifact["pairs"][0]["node_pairs"],
            serde_json::json!([
                {"node_a": 0, "node_b": 1},
                {"node_a": 2, "node_b": 3},
                {"node_a": 4, "node_b": 5},
            ])
        );
        assert_eq!(artifact["pairs"][0]["max_residual_m"], 0.0);
        assert_eq!(artifact["pairs"][0]["status"], "valid");

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn periodic_certificate_identity_rejects_stale_topology_fingerprint() {
        let mesh = fullmag_ir::MeshIR {
            mesh_name: "identity-test".to_string(),
            nodes: Vec::new(),
            cells: fullmag_ir::FemConnectivityIR::from_tet4(Vec::new()),
            element_markers: Vec::new(),
            facets: fullmag_ir::FemFacetConnectivityIR::from_tri3(Vec::new()),
            boundary_markers: Vec::new(),
            periodic_boundary_pairs: Vec::new(),
            periodic_node_pairs: Vec::new(),
            per_domain_quality: std::collections::HashMap::new(),
        };
        let certificate = fullmag_ir::PeriodicMeshCertificateV6IR {
            schema_version: "periodic_mesh_certificate.v6".to_string(),
            certificate_status: "accepted".to_string(),
            topology_fingerprint: "sha256:stale".to_string(),
            axis_pairs: Vec::new(),
            magnetic_class_count: 0,
            magnetic_pair_count: 0,
            scalar_class_count: 0,
            scalar_pair_count: 0,
            magnetic_equivalence_classes_sha256: "sha256:empty".to_string(),
            scalar_equivalence_classes_sha256: "sha256:empty".to_string(),
            translation_residual_max_m: 0.0,
            orientation_residual_max: 0.0,
            normal_mismatch_max: 0.0,
            boundary_topology_match: true,
            fe_order_match: true,
            material_region_match: true,
            corner_edge_cycle_unique: true,
            edge_class_count: 0,
            corner_class_count: 0,
            max_commutation_residual_m: 0.0,
            m0_seam_mismatch_max: 0.0,
            h_demag0_seam_mismatch_max: 0.0,
            marker_map_fingerprint: "sha256:empty".to_string(),
            material_realization_fingerprint: "sha256:empty".to_string(),
            region_class_count: 0,
            max_material_residual: 0.0,
        };
        let errors = validate_periodic_certificate_identity(&mesh, certificate)
            .expect_err("stale certificate identity must fail closed");
        assert!(errors
            .iter()
            .any(|error| error.contains("topology fingerprint")));
    }

    #[test]
    fn periodic_pairs_artifact_rejects_uncertified_face_orientation() {
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.mesh.nodes = vec![
            [0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [1.0, 0.0, 1.0],
            [2.0, 0.0, 0.0],
            [2.0, 1.0, 0.0],
            [3.0, 0.0, 1.0],
        ];
        fem.mesh.set_tet4_cells(Vec::new());
        fem.mesh.set_tri3_facets(vec![[0, 1, 2], [3, 4, 5]]);
        fem.mesh.boundary_markers = vec![10, 11];
        fem.mesh.periodic_boundary_pairs = vec![fullmag_ir::MeshPeriodicBoundaryPairIR {
            pair_id: "diagonal_faces".to_string(),
            source_marker: Some("source".to_string()),
            destination_marker: Some("destination".to_string()),
            marker_a: 10,
            marker_b: 11,
            translation: Some([2.0, 0.0, 0.0]),
            tolerance: Some(1.0e-12),
            axis_hint: Some("x".to_string()),
            orientation: Some("mirrored".to_string()),
            pairing_policy: Some("explicit_node_pairs".to_string()),
        }];
        fem.mesh.periodic_node_pairs = vec![
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "diagonal_faces".to_string(),
                node_a: 0,
                node_b: 3,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "diagonal_faces".to_string(),
                node_a: 1,
                node_b: 4,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "diagonal_faces".to_string(),
                node_a: 2,
                node_b: 5,
            },
        ];

        let boundary_pair = &fem.mesh.periodic_boundary_pairs[0];
        let face_pairs = mesh_periodic_boundary_face_pairs(&fem.mesh, boundary_pair);
        assert_eq!(face_pairs.len(), 1);
        assert_eq!(face_pairs[0]["face_a"], 0);
        assert_eq!(face_pairs[0]["face_b"], 1);
        let normal_dot = face_pairs[0]["normal_dot"]
            .as_f64()
            .expect("face normal dot should be numeric");
        assert!((normal_dot - 1.0).abs() < 1.0e-12);

        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-periodic-uncertified-{}",
            std::process::id()
        ));
        write_periodic_pairs_artifact(&output_dir, &plan, None)
            .expect("periodic pairs artifact should record failed certificate evidence");
        let artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("mesh/periodic_pairs.v1.json"))
                .expect("periodic pairs artifact should exist"),
        )
        .expect("periodic pairs artifact should parse");
        assert_eq!(artifact["validation_status"], "failed");
        assert_eq!(artifact["certificate_status"], "rejected");
        assert_ne!(artifact["pairs"][0]["status"], "valid");
        assert!(artifact["pairs"][0]["boundary_face_pairs"]
            .as_array()
            .unwrap()
            .is_empty());

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn periodic_face_pairs_use_explicit_node_bijection_not_centroid() {
        let mut plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.mesh.nodes = vec![
            [0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [1.0, 0.0, 1.0],
            [2.0, 0.0, 0.0],
            [2.0, 1.0, 0.0],
            [3.0, 0.0, 1.0],
            [2.2, 0.0, 0.0],
            [2.3, 0.5, 0.5],
            [2.5, 0.5, 0.5],
        ];
        fem.mesh
            .set_tri3_facets(vec![[0, 1, 2], [6, 7, 8], [3, 5, 4]]);
        fem.mesh.boundary_markers = vec![10, 11, 11];
        let boundary_pair = fullmag_ir::MeshPeriodicBoundaryPairIR {
            pair_id: "diagonal_faces".to_string(),
            source_marker: None,
            destination_marker: None,
            marker_a: 10,
            marker_b: 11,
            translation: Some([2.0, 0.0, 0.0]),
            tolerance: Some(1.0e-12),
            axis_hint: Some("x".to_string()),
            orientation: None,
            pairing_policy: Some("explicit_node_pairs".to_string()),
        };
        fem.mesh.periodic_node_pairs = vec![
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "diagonal_faces".to_string(),
                node_a: 0,
                node_b: 3,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "diagonal_faces".to_string(),
                node_a: 1,
                node_b: 4,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "diagonal_faces".to_string(),
                node_a: 2,
                node_b: 5,
            },
        ];

        assert_eq!(
            mesh_periodic_boundary_face_index_pairs(&fem.mesh, &boundary_pair),
            vec![(0, 2)]
        );
    }

    #[test]
    fn periodic_pairs_artifact_supports_fem_frequency_response_plan() {
        let mut base_plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut base_plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.mesh.nodes = vec![
            [0.0, 0.0, 0.0],
            [40.0e-9, 0.0, 0.0],
            [40.0e-9, 20.0e-9, 0.0],
            [0.0, 20.0e-9, 0.0],
            [0.0, 0.0, 10.0e-9],
            [40.0e-9, 0.0, 10.0e-9],
            [40.0e-9, 20.0e-9, 10.0e-9],
            [0.0, 20.0e-9, 10.0e-9],
        ];
        fem.mesh.set_tri3_facets(vec![[0, 3, 7], [1, 6, 2]]);
        fem.mesh.boundary_markers = vec![10, 11];
        fem.mesh.periodic_boundary_pairs = vec![fullmag_ir::MeshPeriodicBoundaryPairIR {
            pair_id: "x_faces".to_string(),
            source_marker: Some("x_min".to_string()),
            destination_marker: Some("x_max".to_string()),
            marker_a: 10,
            marker_b: 11,
            translation: Some([40.0e-9, 0.0, 0.0]),
            tolerance: Some(1.0e-12),
            axis_hint: Some("x".to_string()),
            orientation: Some("same".to_string()),
            pairing_policy: Some("explicit_node_pairs".to_string()),
        }];
        fem.mesh.periodic_node_pairs = vec![
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 0,
                node_b: 1,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 3,
                node_b: 2,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 7,
                node_b: 6,
            },
        ];

        let common = base_plan.common;
        let output_plan = base_plan.output_plan;
        let provenance = base_plan.provenance;
        let BackendPlanIR::Fem(fem) = base_plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        let plan = ExecutionPlanIR {
            common,
            backend_plan: BackendPlanIR::FemFrequencyResponse(
                fullmag_ir::FemFrequencyResponsePlanIR {
                    mesh_build_report: None,
                    mesh_name: fem.mesh_name,
                    mesh_source: fem.mesh_source,
                    mesh: fem.mesh,
                    object_segments: fem.object_segments,
                    mesh_parts: fem.mesh_parts,
                    domain_mesh_mode: fem.domain_mesh_mode,
                    domain_mesh_workflow_mode: None,
                    domain_frame: fem.domain_frame,
                    fe_order: fem.fe_order,
                    hmax: fem.hmax,
                    equilibrium_magnetization: fem.initial_magnetization,
                    material: fem.material,
                    operator: fullmag_ir::EigenOperatorConfigIR {
                        kind: fullmag_ir::EigenOperatorIR::LinearizedLlg,
                        include_demag: false,
                    },
                    equilibrium: fullmag_ir::EquilibriumSourceIR::Provided,
                    k_sampling: None,
                    normalization: fullmag_ir::FrequencyResponseNormalizationIR::UnitMaxAmplitude,
                    damping_policy: fullmag_ir::EigenDampingPolicyIR::Include,
                    spin_wave_bc: fullmag_ir::SpinWaveBoundaryConditionIR::Config(
                        fullmag_ir::SpinWaveBoundaryConfigIR {
                            kind: fullmag_ir::SpinWaveBoundaryKindIR::Periodic,
                            boundary_pair_id: Some("x_faces".to_string()),
                            pair_ids: Vec::new(),
                            phase_convention: fullmag_ir::PhaseConventionIR::default(),
                            surface_anisotropy_ks: None,
                            surface_anisotropy_axis: None,
                        },
                    ),
                    magnetostatic_bc: fullmag_ir::MagnetostaticBoundaryConditionIR::default(),
                    excitation: fullmag_ir::FrequencyExcitationIR {
                        field_au_per_m: [0.0, 0.0, 1.0],
                        phase_rad: 0.0,
                    },
                    frequencies_hz: fullmag_ir::FrequencySweepIR {
                        values_hz: vec![1.0e9, 2.0e9],
                    },
                    solver_policy: None,
                    enable_exchange: fem.enable_exchange,
                    enable_demag: fem.enable_demag,
                    interfacial_dmi: fem.interfacial_dmi,
                    dmi_interface_normal: fem.dmi_interface_normal,
                    bulk_dmi: fem.bulk_dmi,
                    external_field: fem.external_field,
                    gyromagnetic_ratio: fem.gyromagnetic_ratio,
                    precision: fem.precision,
                    requested_device: fullmag_ir::ExecutionDevice::Cpu,
                    exchange_bc: fem.exchange_bc,
                    demag_realization: fem.demag_realization,
                    air_box_config: fem.air_box_config,
                    demag_solver_policy: None,
                    periodic_constraint_sets: Vec::new(),
                    equilibrium_provenance: None,
                },
            ),
            output_plan,
            provenance,
        };

        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-frequency-response-periodic-pairs-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        write_periodic_pairs_artifact(&output_dir, &plan, None)
            .expect("frequency-response periodic pairs artifact should be written");

        let artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("mesh/periodic_pairs.v1.json"))
                .expect("periodic pairs artifact should exist"),
        )
        .expect("periodic pairs artifact should parse");
        assert_eq!(artifact["schema_version"], "periodic_pairs.v1");
        assert_eq!(artifact["artifact_path"], "mesh/periodic_pairs.v1.json");
        assert_eq!(artifact["validation_status"], "ok");
        assert_eq!(artifact["pair_count"], 1);
        assert_eq!(artifact["paired_node_count"], 3);
        assert_eq!(artifact["pairs"][0]["pair_id"], "x_faces");
        assert_eq!(artifact["pairs"][0]["paired_node_count"], 3);
        assert_eq!(artifact["pairs"][0]["status"], "valid");

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn write_artifacts_persists_frequency_response_periodic_pairs() {
        let mut base_plan = test_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut base_plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        fem.mesh.nodes = vec![
            [0.0, 0.0, 0.0],
            [40.0e-9, 0.0, 0.0],
            [40.0e-9, 20.0e-9, 0.0],
            [0.0, 20.0e-9, 0.0],
            [0.0, 0.0, 10.0e-9],
            [40.0e-9, 0.0, 10.0e-9],
            [40.0e-9, 20.0e-9, 10.0e-9],
            [0.0, 20.0e-9, 10.0e-9],
        ];
        fem.mesh.set_tri3_facets(vec![[0, 3, 7], [1, 6, 2]]);
        fem.mesh.boundary_markers = vec![10, 11];
        fem.mesh.periodic_boundary_pairs = vec![fullmag_ir::MeshPeriodicBoundaryPairIR {
            pair_id: "x_faces".to_string(),
            source_marker: Some("x_min".to_string()),
            destination_marker: Some("x_max".to_string()),
            marker_a: 10,
            marker_b: 11,
            translation: Some([40.0e-9, 0.0, 0.0]),
            tolerance: Some(1.0e-12),
            axis_hint: Some("x".to_string()),
            orientation: Some("same".to_string()),
            pairing_policy: Some("explicit_node_pairs".to_string()),
        }];
        fem.mesh.periodic_node_pairs = vec![
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 0,
                node_b: 1,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 3,
                node_b: 2,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 7,
                node_b: 6,
            },
        ];

        let common = base_plan.common;
        let output_plan = base_plan.output_plan;
        let provenance = base_plan.provenance;
        let BackendPlanIR::Fem(fem) = base_plan.backend_plan else {
            panic!("test plan must be FEM");
        };
        let plan = ExecutionPlanIR {
            common,
            backend_plan: BackendPlanIR::FemFrequencyResponse(
                fullmag_ir::FemFrequencyResponsePlanIR {
                    mesh_build_report: None,
                    mesh_name: fem.mesh_name,
                    mesh_source: fem.mesh_source,
                    mesh: fem.mesh,
                    object_segments: fem.object_segments,
                    mesh_parts: fem.mesh_parts,
                    domain_mesh_mode: fem.domain_mesh_mode,
                    domain_mesh_workflow_mode: None,
                    domain_frame: fem.domain_frame,
                    fe_order: fem.fe_order,
                    hmax: fem.hmax,
                    equilibrium_magnetization: fem.initial_magnetization,
                    material: fem.material,
                    operator: fullmag_ir::EigenOperatorConfigIR {
                        kind: fullmag_ir::EigenOperatorIR::LinearizedLlg,
                        include_demag: false,
                    },
                    equilibrium: fullmag_ir::EquilibriumSourceIR::Provided,
                    k_sampling: None,
                    normalization: fullmag_ir::FrequencyResponseNormalizationIR::UnitMaxAmplitude,
                    damping_policy: fullmag_ir::EigenDampingPolicyIR::Include,
                    spin_wave_bc: fullmag_ir::SpinWaveBoundaryConditionIR::Config(
                        fullmag_ir::SpinWaveBoundaryConfigIR {
                            kind: fullmag_ir::SpinWaveBoundaryKindIR::Periodic,
                            boundary_pair_id: Some("x_faces".to_string()),
                            pair_ids: Vec::new(),
                            phase_convention: fullmag_ir::PhaseConventionIR::default(),
                            surface_anisotropy_ks: None,
                            surface_anisotropy_axis: None,
                        },
                    ),
                    magnetostatic_bc: fullmag_ir::MagnetostaticBoundaryConditionIR::default(),
                    excitation: fullmag_ir::FrequencyExcitationIR {
                        field_au_per_m: [0.0, 0.0, 1.0],
                        phase_rad: 0.0,
                    },
                    frequencies_hz: fullmag_ir::FrequencySweepIR {
                        values_hz: vec![1.0e9],
                    },
                    solver_policy: None,
                    enable_exchange: fem.enable_exchange,
                    enable_demag: false,
                    interfacial_dmi: fem.interfacial_dmi,
                    dmi_interface_normal: fem.dmi_interface_normal,
                    bulk_dmi: fem.bulk_dmi,
                    external_field: fem.external_field,
                    gyromagnetic_ratio: fem.gyromagnetic_ratio,
                    precision: fem.precision,
                    requested_device: fullmag_ir::ExecutionDevice::Cpu,
                    exchange_bc: fem.exchange_bc,
                    demag_realization: None,
                    air_box_config: None,
                    demag_solver_policy: None,
                    periodic_constraint_sets: Vec::new(),
                    equilibrium_provenance: None,
                },
            ),
            output_plan,
            provenance,
        };
        let problem = fullmag_ir::ProblemIR::bootstrap_example();
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: vec![[1.0, 0.0, 0.0]; 8],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 8],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "runner.frequency_response_test".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        };
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-frequency-response-write-periodic-pairs-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("frequency-response artifact write should succeed");

        let artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("mesh/periodic_pairs.v1.json"))
                .expect("periodic pairs artifact should exist"),
        )
        .expect("periodic pairs artifact should parse");
        assert_eq!(artifact["schema_version"], "periodic_pairs.v1");
        assert_eq!(artifact["pairs"][0]["pair_id"], "x_faces");
        assert_eq!(artifact["pairs"][0]["paired_node_count"], 3);
        assert_eq!(artifact["pairs"][0]["status"], "valid");

        let native_output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-frequency-response-native-periodic-pairs-{}-{}",
            std::process::id(),
            unique_suffix
        ));
        let native_mesh_dir = native_output_dir.join("mesh");
        fs::create_dir_all(&native_mesh_dir).expect("native mesh artifact dir should exist");
        fs::write(
            native_mesh_dir.join("periodic_pairs.v1.json"),
            serde_json::to_string_pretty(&serde_json::json!({
                "schema_version": "periodic_pairs.v1",
                "source": "native_fem_frequency_domain_static_periodic",
                "validation_status": "ok",
                "pair_count": 4,
                "paired_node_count": 8,
                "unpaired_source_count": 0,
                "unpaired_destination_count": 0,
                "max_translation_residual_m": 0.0,
                "residual_diagnostics": {
                    "static_periodic_frame_max_mismatch": 0.0,
                    "static_periodic_drive_max_mismatch": 0.0
                },
                "pairs": [
                    {
                        "pair_id": "static-periodic-0000",
                        "source_marker": "node:0",
                        "destination_marker": "node:1",
                        "translation_residual_m": 0.0,
                        "validation_status": "ok"
                    }
                ]
            }))
            .expect("native periodic pairs fixture should serialize"),
        )
        .expect("native periodic pairs fixture should be written");
        let native_executed = ExecutedRun {
            provenance: ExecutionProvenance {
                execution_engine: "native_fem.frequency_domain.production_cpu".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
            ..executed.clone()
        };

        write_artifacts(&native_output_dir, &problem, &plan, &native_executed, None)
            .expect("native frequency-response artifact write should preserve backend artifact");

        let native_artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(native_output_dir.join("mesh/periodic_pairs.v1.json"))
                .expect("native periodic pairs artifact should still exist"),
        )
        .expect("native periodic pairs artifact should parse");
        assert_eq!(
            native_artifact["source"],
            "native_fem_frequency_domain_static_periodic"
        );
        assert_eq!(native_artifact["pair_count"], 4);
        assert_eq!(
            native_artifact["pairs"][0]["pair_id"],
            "static-periodic-0000"
        );

        fs::remove_dir_all(native_output_dir)
            .expect("native temporary artifact directory should be removable");
        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn write_artifacts_persists_h_oe_field_snapshot() {
        let problem = fullmag_ir::ProblemIR::bootstrap_example();
        let plan = test_execution_plan(Some(vec![
            true, true, false, false, true, false, true, false,
        ]));
        let provenance = ExecutionProvenance {
            charge_transport: None,
            transport_modules: Vec::new(),
            fdm_gpu_transport_telemetry: None,
            fdm_cpu_state_layout: None,
            fdm_gpu_execution_receipt: None,
            fdm_gpu_step_transaction_telemetry: None,
            fdm_gpu_observation_policy: None,
            fdm_gpu_endpoint_cache_telemetry: None,
            cpu_fixed_coupling: None,
            fdm_cpu_step_transaction_telemetry: None,
            fdm_cpu_evaluation_telemetry: None,
            fdm_fft_execution: None,
            fem_gpu_execution_receipt: None,
            fem_gpu_minimizer_execution_receipt: None,
            executed_physics_kinds: Vec::new(),
            executed_physics_module_ids: Vec::new(),
            execution_engine: "fdm_gpu_native".to_string(),
            precision: "double".to_string(),
            demag_operator_kind: None,
            fft_backend: None,
            device_name: Some("test-gpu".to_string()),
            compute_capability: Some("9.0".to_string()),
            cuda_driver_version: Some(12040),
            cuda_runtime_version: Some(12040),
            lossy_fallback_used: false,
            ignored_terms: Vec::new(),
            random_seed: None,
            resolved_fallback: None,
            fem_eigen_execution_resolution: None,
            fem_eigen_native_execution_attestation: None,
            fem_crossover_decision: None,
            requested_integrator: None,
            resolved_integrator: None,
            requested_energy_minimizer: None,
            resolved_energy_minimizer: None,
            energy_minimizer_realization: None,
            fem_direct_minimizer_policy: None,
            requested_demag_realization: None,
            resolved_demag_realization: None,
            timestep_policy: None,
            fdm_multilayer_transfer_telemetry: None,
            fdm_multilayer_stage_telemetry: None,
            dt_policy: None,
            llg_mode: None,
            mfem_device: None,
            mfem_version: None,
            hypre_version: None,
            demag_refresh_interval_s: None,
            fem_assembly_mode: None,
            fem_execution_mode: None,
            fem_gpu_qualification_status: None,
            fem_exchange_operator_mode: None,
            fem_data_residency: None,
            uses_cuda_kernels: None,
            uses_gpu_poisson: None,
            fem_demag_operator_mode: None,
            hypre_execution_policy: None,
            demag_residency: None,
            hot_loop_host_sync_count: None,
            hot_loop_exchange_h2d_bytes: None,
            hot_loop_exchange_d2h_bytes: None,
            hot_loop_exchange_host_sync_count: None,
            hot_loop_compute_h2d_bytes: None,
            hot_loop_compute_d2h_bytes: None,
            hot_loop_compute_host_sync_count: None,
            hot_loop_control_scalar_d2h_bytes: None,
            hot_loop_control_scalar_host_sync_count: None,
            fem_gpu_state_allocated: None,
            fem_gpu_state_node_count: None,
            fem_gpu_state_dof_len: None,
            fem_gpu_state_stage_count: None,
            fem_gpu_state_device_bytes: None,
            fem_gpu_state_reduction_workspace_bytes: None,
            fem_gpu_rk_exchange_only_enabled: None,
            fem_gpu_rk_stage_count: None,
            fem_gpu_rk_uses_cuda_kernels: None,
            fem_gpu_rk_allows_exchange_host_sync: None,
            fem_gpu_rk_stage_exchange_device_resident: None,
            fem_gpu_rk_block_reason: None,
            requested_cpu_threads: None,
            resolved_cpu_threads: None,
            requested_fem_omp_threads: None,
            effective_fem_omp_threads: None,
            fem_poisson_demag: None,
            fem_bem_demag: None,
        };
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-h-oe-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 1,
                    time: 1.0e-13,
                    dt: 1.0e-13,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 8],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 8],
            field_snapshots: vec![FieldSnapshot {
                name: "H_oe".to_string(),
                step: 1,
                time: 1.0e-13,
                solver_dt: 1.0e-13,
                component_count: 3,
                component_order: "xyz".into(),
                location: "sample".into(),
                scope: "full".into(),
                revision: (1 as u64).saturating_add(1),
                values: FieldSnapshot::flatten_vec3(vec![
                    [0.0, 0.0, 1.0],
                    [0.0, 1.0, 0.0],
                    [0.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0],
                    [1.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0],
                    [-1.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0],
                ]),
            }],
            field_snapshot_count: 1,
            auxiliary_artifacts: Vec::new(),
            provenance,
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("H_oe artifact write should succeed");

        let field_json: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("fields/H_oe/step_000001.json"))
                .expect("H_oe artifact should exist"),
        )
        .expect("H_OE artifact should parse");
        assert_eq!(field_json["observable"], "H_oe");
        assert_eq!(field_json["unit"], "A/m");
        assert_eq!(field_json["step"], 1);
        assert_eq!(field_json["layout"]["backend"], "fdm");
        assert_eq!(field_json["values"][0], serde_json::json!([0.0, 0.0, 1.0]));
        assert_eq!(field_json["values"][6], serde_json::json!([-1.0, 0.0, 0.0]));

        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata should exist"),
        )
        .expect("metadata should parse");
        assert_eq!(metadata["field_snapshots"], 1);
        let build_identity = &metadata["build_identity"];
        assert_eq!(
            build_identity["git_commit"].as_str().map(str::len),
            Some(40)
        );
        assert!(matches!(
            build_identity["worktree_state"].as_str(),
            Some("clean" | "dirty" | "unknown")
        ));
        let source_snapshot = build_identity["source_snapshot_sha256"].as_str();
        assert!(
            source_snapshot == Some("unknown")
                || source_snapshot.is_some_and(|value| value.len() == 64)
        );

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn metadata_copies_periodic_antidot_relaxation_runtime_provenance() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.problem_meta.name = "fem_periodic_antidot_relax_air_gap".to_string();
        problem.pbc = Some(fullmag_ir::FdmPeriodicityIR {
            axes: [
                fullmag_ir::AxisBoundary::Periodic,
                fullmag_ir::AxisBoundary::Periodic,
                fullmag_ir::AxisBoundary::Open,
            ],
            demag: fullmag_ir::FdmDemagPeriodicityIR::PeriodicAirboxK0,
            image_counts: None,
        });
        problem.problem_meta.runtime_metadata.insert(
            "periodic_antidot_relaxation".to_string(),
            serde_json::json!({
                "scenario": "air_gap",
                "exchange_coupled_across_periods": false,
                "magnetostatic_pbc": "periodic_airbox_k0",
                "periodic_pair_ids": ["x_faces", "y_faces"],
                "film_size_m": [2.0e-7, 2.0e-7, 1.0e-8],
                "universe_size_m": [3.2e-7, 3.2e-7, 9.0e-8],
                "lateral_air_gap_m": [1.2e-7, 1.2e-7],
            }),
        );
        let plan = test_periodic_fem_execution_plan();
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-periodic-antidot-relaxation-metadata-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 4,
                    max_torque_T: 1.0e-3,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("artifact write should preserve periodic antidot metadata");

        let metadata: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("metadata.json")).expect("metadata should exist"),
        )
        .expect("metadata should parse");
        assert_eq!(
            metadata["periodic_antidot_relaxation"]["scenario"],
            "air_gap"
        );
        assert_eq!(
            metadata["periodic_antidot_relaxation"]["magnetostatic_pbc"],
            "periodic_airbox_k0"
        );
        assert_eq!(
            metadata["periodic_antidot_relaxation"]["periodic_pair_ids"],
            serde_json::json!(["x_faces", "y_faces"])
        );
        assert_eq!(
            metadata["pbc"],
            serde_json::json!({
                "axes": ["periodic", "periodic", "open"],
                "demag": "periodic_airbox_k0",
            })
        );
        assert_eq!(metadata["mesh"]["periodic_boundary_pair_count"], 2);
        assert_eq!(metadata["mesh"]["periodic_node_pair_count"], 2);
        assert_eq!(
            metadata["mesh"]["periodic_boundary_pair_counts_by_id"]["x_faces"],
            1
        );
        assert_eq!(
            metadata["mesh"]["periodic_node_pair_counts_by_id"]["y_faces"],
            1
        );

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn supercell_runtime_metadata_writes_fem_node_geometry_artifact() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.problem_meta.name =
            "fem_periodic_antidot_relax_exchange_coupled_supercell_3x3".to_string();
        problem.problem_meta.runtime_metadata.insert(
            "periodic_antidot_relaxation".to_string(),
            serde_json::json!({
                "scenario": "exchange_coupled",
                "exchange_coupled_across_periods": true,
                "magnetostatic_pbc": "periodic_airbox_k0",
                "periodic_pair_ids": ["x_faces", "y_faces"],
                "film_size_m": [2.0e-7, 2.0e-7, 1.0e-8],
                "universe_size_m": [6.0e-7, 6.0e-7, 9.0e-8],
                "lateral_air_gap_m": [0.0, 0.0],
                "supercell_repeat": [3, 3],
            }),
        );
        let plan = test_fem_execution_plan();
        let prepared = build_fem_supercell_node_geometry_artifact(&problem, &plan)
            .expect("node geometry should build without filesystem output")
            .expect("supercell metadata should produce node geometry");
        assert_eq!(prepared.relative_path, "mesh/node_geometry.v1.json");
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-supercell-node-geometry-{}-{}",
            std::process::id(),
            unique_suffix
        ));
        assert!(!output_dir.exists(), "pure preparation must not write files");
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("supercell node geometry artifact should write");
        assert_eq!(
            fs::read(output_dir.join(&prepared.relative_path))
                .expect("node geometry artifact should exist"),
            prepared.bytes,
            "write_artifacts must preserve exact bytes returned by the pure node-geometry builder"
        );

        let artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("mesh/node_geometry.v1.json"))
                .expect("node geometry artifact should exist"),
        )
        .expect("node geometry artifact should parse");
        assert_eq!(artifact["schema_version"], "fem_mesh_node_geometry.v1");
        assert_eq!(artifact["artifact_path"], "mesh/node_geometry.v1.json");
        assert_eq!(artifact["node_count"], 4);
        assert_eq!(artifact["nodes_m"][1], serde_json::json!([1.0, 0.0, 0.0]));
        assert_eq!(
            artifact["magnetic_node_mask"],
            serde_json::json!([true, true, true, true])
        );
        assert_eq!(artifact["magnetic_node_count"], 4);
        assert_eq!(artifact["field_cell_alignment"]["H_demag"], "node_index");
        assert_eq!(artifact["field_cell_alignment"]["H_eff"], "node_index");
        assert_eq!(artifact["field_cell_alignment"]["demag_phi"], "node_index");

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn primitive_periodic_antidot_does_not_write_supercell_node_geometry_artifact() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.problem_meta.name = "fem_periodic_antidot_relax_exchange_coupled".to_string();
        problem.problem_meta.runtime_metadata.insert(
            "periodic_antidot_relaxation".to_string(),
            serde_json::json!({
                "scenario": "exchange_coupled",
                "exchange_coupled_across_periods": true,
                "magnetostatic_pbc": "periodic_airbox_k0",
                "periodic_pair_ids": ["x_faces", "y_faces"],
                "film_size_m": [2.0e-7, 2.0e-7, 1.0e-8],
                "universe_size_m": [2.0e-7, 2.0e-7, 9.0e-8],
                "lateral_air_gap_m": [0.0, 0.0],
            }),
        );
        let plan = test_fem_execution_plan();
        assert!(build_fem_supercell_node_geometry_artifact(&problem, &plan)
            .expect("primitive cell should validate without filesystem output")
            .is_none());
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-primitive-node-geometry-{}-{}",
            std::process::id(),
            unique_suffix
        ));
        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: Vec::new(),
                final_magnetization: vec![[1.0, 0.0, 0.0]; 4],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 4],
            field_snapshots: Vec::new(),
            field_snapshot_count: 0,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("primitive artifacts should write");

        assert!(!output_dir.join("mesh/node_geometry.v1.json").exists());

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn fdm_field_component_snapshots_use_base_observable_units() {
        let problem = fullmag_ir::ProblemIR::bootstrap_example();
        let plan = test_execution_plan(None);
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fdm-components-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 1,
                    time: 1.0e-13,
                    dt: 1.0e-13,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 8],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 8],
            field_snapshots: vec![
                FieldSnapshot {
                    name: "m.x".to_string(),
                    step: 1,
                    time: 1.0e-13,
                    solver_dt: 1.0e-13,
                    component_count: 3,
                    component_order: "xyz".into(),
                    location: "sample".into(),
                    scope: "full".into(),
                    revision: (1 as u64).saturating_add(1),
                    values: FieldSnapshot::flatten_vec3(vec![[1.0, 0.0, 0.0]; 8]),
                },
                FieldSnapshot {
                    name: "H_eff.z".to_string(),
                    step: 1,
                    time: 1.0e-13,
                    solver_dt: 1.0e-13,
                    component_count: 3,
                    component_order: "xyz".into(),
                    location: "sample".into(),
                    scope: "full".into(),
                    revision: (1 as u64).saturating_add(1),
                    values: FieldSnapshot::flatten_vec3(vec![[5.0, 0.0, 0.0]; 8]),
                },
                FieldSnapshot {
                    name: "torque".to_string(),
                    step: 1,
                    time: 1.0e-13,
                    solver_dt: 1.0e-13,
                    component_count: 3,
                    component_order: "xyz".into(),
                    location: "sample".into(),
                    scope: "full".into(),
                    revision: (1 as u64).saturating_add(1),
                    values: FieldSnapshot::flatten_vec3(vec![[0.0, 0.0, 2.0e-3]; 8]),
                },
            ],
            field_snapshot_count: 3,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "cpu_reference".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("component artifacts should be written");

        let m_x: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("fields/m.x/step_000001.json"))
                .expect("m.x artifact should exist"),
        )
        .expect("m.x artifact should parse");
        assert_eq!(m_x["unit"], "dimensionless");

        let h_eff_z: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("fields/H_eff.z/step_000001.json"))
                .expect("H_eff.z artifact should exist"),
        )
        .expect("H_eff.z artifact should parse");
        assert_eq!(h_eff_z["unit"], "A/m");

        let torque: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("fields/torque/step_000001.json"))
                .expect("torque artifact should exist"),
        )
        .expect("torque artifact should parse");
        assert_eq!(torque["unit"], "T");

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn fdm_multilayer_field_snapshots_are_written_per_layer() {
        let problem = fullmag_ir::ProblemIR::bootstrap_example();
        let plan = test_multilayer_execution_plan();
        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-artifacts-fdm-multilayer-fields-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 1,
                    time: 1.0e-13,
                    dt: 1.0e-13,
                    ..StepStats::default()
                }],
                final_magnetization: vec![
                    [1.0, 0.0, 0.0],
                    [0.9, 0.1, 0.0],
                    [0.0, 1.0, 0.0],
                    [0.0, 0.9, 0.1],
                ],
                completion: None,
            },
            initial_magnetization: vec![
                [1.0, 0.0, 0.0],
                [1.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 1.0, 0.0],
            ],
            field_snapshots: vec![FieldSnapshot {
                name: "m".to_string(),
                step: 1,
                time: 1.0e-13,
                solver_dt: 1.0e-13,
                component_count: 3,
                component_order: "xyz".into(),
                location: "sample".into(),
                scope: "full".into(),
                revision: (1 as u64).saturating_add(1),
                values: FieldSnapshot::flatten_vec3(vec![
                    [1.0, 0.0, 0.0],
                    [0.9, 0.1, 0.0],
                    [0.0, 1.0, 0.0],
                    [0.0, 0.9, 0.1],
                ]),
            }],
            field_snapshot_count: 1,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "cuda_assisted_multilayer".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("multilayer artifact write should succeed");

        let manifest: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("fields/m/manifest.json"))
                .expect("multilayer field manifest should exist"),
        )
        .expect("multilayer field manifest should parse");
        assert_eq!(
            manifest["schema_version"],
            "fdm_multilayer_field_manifest.v1"
        );
        assert_eq!(manifest["observable"], "m");
        assert_eq!(manifest["storage_layout"], "per_layer_json");
        assert_eq!(manifest["layers"][0]["id"], "bottom");
        assert_eq!(manifest["layers"][0]["directory"], "layer-bottom");
        assert_eq!(manifest["layers"][0]["value_offset"], 0);
        assert_eq!(manifest["layers"][0]["value_count"], 2);
        assert_eq!(
            manifest["layers"][0]["native_origin"],
            serde_json::json!([0.0, 0.0, 0.0])
        );
        assert_eq!(manifest["layers"][1]["id"], "top");
        assert_eq!(manifest["layers"][1]["directory"], "layer-top");
        assert_eq!(manifest["layers"][1]["value_offset"], 2);
        assert_eq!(manifest["layers"][1]["value_count"], 2);
        assert_eq!(
            manifest["layers"][1]["native_origin"],
            serde_json::json!([0.0, 0.0, 4e-9])
        );

        let bottom: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("fields/m/layer-bottom/step_000001.json"))
                .expect("bottom layer field snapshot should exist"),
        )
        .expect("bottom layer snapshot should parse");
        assert_eq!(bottom["layer"]["id"], "bottom");
        assert_eq!(bottom["values"].as_array().expect("values").len(), 2);
        assert_eq!(bottom["values"][0], serde_json::json!([1.0, 0.0, 0.0]));
        assert_eq!(bottom["values"][1], serde_json::json!([0.9, 0.1, 0.0]));

        let top: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("fields/m/layer-top/step_000001.json"))
                .expect("top layer field snapshot should exist"),
        )
        .expect("top layer snapshot should parse");
        assert_eq!(top["layer"]["id"], "top");
        assert_eq!(top["values"].as_array().expect("values").len(), 2);
        assert_eq!(top["values"][0], serde_json::json!([0.0, 1.0, 0.0]));
        assert_eq!(top["values"][1], serde_json::json!([0.0, 0.9, 0.1]));

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }

    #[test]
    fn write_artifacts_persists_static_pbc_demag_seam_diagnostics() {
        let mut problem = fullmag_ir::ProblemIR::bootstrap_example();
        problem.problem_meta.name = "fem_periodic_antidot_relax_air_gap".to_string();
        problem.pbc = Some(fullmag_ir::FdmPeriodicityIR {
            axes: [
                fullmag_ir::AxisBoundary::Periodic,
                fullmag_ir::AxisBoundary::Periodic,
                fullmag_ir::AxisBoundary::Open,
            ],
            demag: fullmag_ir::FdmDemagPeriodicityIR::PeriodicAirboxK0,
            image_counts: None,
        });
        let mut plan = test_periodic_fem_execution_plan();
        let BackendPlanIR::Fem(fem) = &mut plan.backend_plan else {
            panic!("test plan should be FEM");
        };
        fem.enable_demag = true;
        fem.material.saturation_magnetisation = 800e3;
        fem.mesh.nodes = vec![
            [0.0, 0.0, 0.0],
            [40.0e-9, 0.0, 0.0],
            [40.0e-9, 20.0e-9, 0.0],
            [0.0, 20.0e-9, 0.0],
            [0.0, 0.0, 10.0e-9],
            [40.0e-9, 0.0, 10.0e-9],
            [40.0e-9, 20.0e-9, 10.0e-9],
            [0.0, 20.0e-9, 10.0e-9],
        ];
        fem.mesh.set_tet4_cells(vec![[0, 1, 2, 4], [3, 5, 6, 7]]);
        fem.mesh.element_markers = vec![1, 1];
        fem.mesh.set_tri3_facets(vec![
            [0, 3, 7],
            [0, 7, 4],
            [1, 5, 6],
            [1, 6, 2],
            [0, 4, 5],
            [0, 5, 1],
            [3, 2, 6],
            [3, 6, 7],
        ]);
        fem.mesh.boundary_markers = vec![1, 1, 2, 2, 3, 3, 4, 4];
        fem.mesh.periodic_boundary_pairs = vec![
            fullmag_ir::MeshPeriodicBoundaryPairIR {
                pair_id: "x_faces".to_string(),
                source_marker: Some("x_min".to_string()),
                destination_marker: Some("x_max".to_string()),
                marker_a: 1,
                marker_b: 2,
                translation: Some([40.0e-9, 0.0, 0.0]),
                tolerance: Some(1.0e-12),
                axis_hint: Some("x".to_string()),
                orientation: Some("opposed_normals".to_string()),
                pairing_policy: Some("explicit_node_pairs".to_string()),
            },
            fullmag_ir::MeshPeriodicBoundaryPairIR {
                pair_id: "y_faces".to_string(),
                source_marker: Some("y_min".to_string()),
                destination_marker: Some("y_max".to_string()),
                marker_a: 3,
                marker_b: 4,
                translation: Some([0.0, 20.0e-9, 0.0]),
                tolerance: Some(1.0e-12),
                axis_hint: Some("y".to_string()),
                orientation: Some("opposed_normals".to_string()),
                pairing_policy: Some("explicit_node_pairs".to_string()),
            },
        ];
        fem.mesh.periodic_node_pairs = vec![
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 0,
                node_b: 1,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 3,
                node_b: 2,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 4,
                node_b: 5,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "x_faces".to_string(),
                node_a: 7,
                node_b: 6,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "y_faces".to_string(),
                node_a: 0,
                node_b: 3,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "y_faces".to_string(),
                node_a: 1,
                node_b: 2,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "y_faces".to_string(),
                node_a: 4,
                node_b: 7,
            },
            fullmag_ir::MeshPeriodicNodePairIR {
                pair_id: "y_faces".to_string(),
                node_a: 5,
                node_b: 6,
            },
        ];

        let unique_suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("clock drift")
            .as_nanos();
        let output_dir = std::env::temp_dir().join(format!(
            "fullmag-static-pbc-demag-seams-{}-{}",
            std::process::id(),
            unique_suffix
        ));

        let executed = ExecutedRun {
            result: RunResult {
                status: RunStatus::Completed,
                steps: vec![StepStats {
                    step: 4,
                    time: 2.0e-12,
                    dt: 5.0e-13,
                    e_demag: 1.0e-21,
                    ..StepStats::default()
                }],
                final_magnetization: vec![[1.0, 0.0, 0.0]; 8],
                completion: None,
            },
            initial_magnetization: vec![[1.0, 0.0, 0.0]; 8],
            field_snapshots: vec![
                FieldSnapshot {
                    name: "H_demag".to_string(),
                    step: 4,
                    time: 2.0e-12,
                    solver_dt: 5.0e-13,
                    component_count: 3,
                    component_order: "xyz".into(),
                    location: "sample".into(),
                    scope: "full".into(),
                    revision: (4 as u64).saturating_add(1),
                    values: FieldSnapshot::flatten_vec3(vec![[10.0, 2.0, 0.0]; 8]),
                },
                FieldSnapshot {
                    name: "demag_phi".to_string(),
                    step: 4,
                    time: 2.0e-12,
                    solver_dt: 5.0e-13,
                    component_count: 3,
                    component_order: "xyz".into(),
                    location: "sample".into(),
                    scope: "full".into(),
                    revision: (4 as u64).saturating_add(1),
                    values: FieldSnapshot::flatten_vec3(vec![
                        [1.0e-6, 0.0, 0.0],
                        [3.0e-6, 0.0, 0.0],
                        [3.0e-6, 0.0, 0.0],
                        [1.0e-6, 0.0, 0.0],
                        [1.0e-6, 0.0, 0.0],
                        [3.0e-6, 0.0, 0.0],
                        [3.0e-6, 0.0, 0.0],
                        [1.0e-6, 0.0, 0.0],
                    ]),
                },
            ],
            field_snapshot_count: 2,
            auxiliary_artifacts: Vec::new(),
            provenance: ExecutionProvenance {
                execution_engine: "fem_cpu_native".to_string(),
                precision: "double".to_string(),
                ..ExecutionProvenance::default()
            },
        };

        write_artifacts(&output_dir, &problem, &plan, &executed, None)
            .expect("artifact write should persist static PBC demag seam diagnostics");

        let artifact: serde_json::Value = serde_json::from_str(
            &fs::read_to_string(output_dir.join("diagnostics/fem_static_pbc_demag_seams.v1.json"))
                .expect("static PBC demag seam diagnostics artifact should exist"),
        )
        .expect("static PBC demag seam diagnostics artifact should parse");
        assert_eq!(artifact["schema_version"], "fem_static_pbc_demag_seams.v1");
        assert_eq!(
            artifact["artifact_path"],
            "diagnostics/fem_static_pbc_demag_seams.v1.json"
        );
        assert_eq!(artifact["status"], "ok");
        assert_eq!(artifact["step"], 4);
        assert_eq!(
            artifact["pair_diagnostics"].as_array().map(Vec::len),
            Some(2)
        );
        assert_eq!(artifact["pair_diagnostics"][0]["pair_id"], "x_faces");
        assert_eq!(artifact["pair_diagnostics"][0]["m_seam_max"], 0.0);
        assert_eq!(artifact["pair_diagnostics"][0]["h_demag_seam_max_Apm"], 0.0);
        assert_eq!(
            artifact["pair_diagnostics"][0]["demag_phi_seam_max_after_offset_A"],
            0.0
        );
        assert_eq!(
            artifact["pair_diagnostics"][0]["b_normal_flux_seam_max_T"],
            0.0
        );
        assert_eq!(
            artifact["pair_diagnostics"][0]["side_magnetic_charge_sum_abs_Am"],
            0.0
        );

        fs::remove_dir_all(output_dir).expect("temporary artifact directory should be removable");
    }
}
